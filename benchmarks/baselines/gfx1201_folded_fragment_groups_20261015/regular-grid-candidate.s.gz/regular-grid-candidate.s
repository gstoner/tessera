
/home/angstorms/scratch/gfx1201-m256-attribution-20261015/guarded-bulk-n-strategy/production-grid-proof/isa/candidate.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

Disassembly of section .text:

0000000000001b00 <tessera_rocm_folded_matmul_a870cecb1991940b>:
	s_clause 0x1                                               // 000000001B00: BF850001
	s_load_b128 s[8:11], s[0:1], 0xc8                          // 000000001B04: F4004200 F80000C8
	s_load_b64 s[2:3], s[0:1], 0xd8                            // 000000001B0C: F4002080 F80000D8
	s_mov_b32 s6, ttmp9                                        // 000000001B14: BE860075
	s_ashr_i32 s7, ttmp9, 31                                   // 000000001B18: 86079F75
	s_wait_kmcnt 0x0                                           // 000000001B1C: BFC70000
	s_add_nc_u64 s[4:5], s[10:11], 63                          // 000000001B20: A984BF0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000001B24: BF870499
	s_lshr_b64 s[4:5], s[4:5], 4                               // 000000001B28: 85848404
	s_and_b32 s13, s5, 0xfffffff                               // 000000001B2C: 8B0DFF05 0FFFFFFF
	s_and_b32 s12, s4, -4                                      // 000000001B34: 8B0CC404
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000001B38: BF870499
	s_or_b64 s[4:5], s[6:7], s[12:13]                          // 000000001B3C: 8C840C06
	s_cmp_lg_u32 s5, 0                                         // 000000001B40: BF078005
	s_mov_b32 s5, 0                                            // 000000001B44: BE850080
	s_cbranch_scc0 111                                         // 000000001B48: BFA1006F <tessera_rocm_folded_matmul_a870cecb1991940b+0x208>
	s_cvt_f32_u32 s4, s12                                      // 000000001B4C: BE84650C
	s_cvt_f32_u32 s14, s13                                     // 000000001B50: BE8E650D
	s_sub_nc_u64 s[16:17], 0, s[12:13]                         // 000000001B54: AA100C80
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000001B58: BF87059A
	s_fmac_f32 s4, s14, 0x4f800000                             // 000000001B5C: A384FF0E 4F800000
	v_s_rcp_f32 s4, s4                                         // 000000001B64: D6840004 02010004
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000001B6C: BF870525
	s_mul_f32 s4, s4, 0x5f7ffffc                               // 000000001B70: A204FF04 5F7FFFFC
	s_wait_alu depctr_sa_sdst(0)                               // 000000001B78: BF88FF9E
	s_mul_f32 s14, s4, 0x2f800000                              // 000000001B7C: A20EFF04 2F800000
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000001B84: BF87059B
	s_trunc_f32 s14, s14                                       // 000000001B88: BE8E620E
	s_fmac_f32 s4, s14, 0xcf800000                             // 000000001B8C: A384FF0E CF800000
	s_cvt_u32_f32 s15, s14                                     // 000000001B94: BE8F670E
	s_wait_alu depctr_sa_sdst(0)                               // 000000001B98: BF88FF9E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000001B9C: BF870599
	s_cvt_u32_f32 s14, s4                                      // 000000001BA0: BE8E6704
	s_mul_u64 s[18:19], s[16:17], s[14:15]                     // 000000001BA4: AA920E10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001BA8: BF870009
	s_mul_hi_u32 s21, s14, s19                                 // 000000001BAC: 9695130E
	s_mul_i32 s20, s14, s19                                    // 000000001BB0: 9614130E
	s_mul_hi_u32 s4, s14, s18                                  // 000000001BB4: 9684120E
	s_mul_i32 s23, s15, s18                                    // 000000001BB8: 9617120F
	s_wait_alu depctr_sa_sdst(0)                               // 000000001BBC: BF88FF9E
	s_add_nc_u64 s[20:21], s[4:5], s[20:21]                    // 000000001BC0: A9941404
	s_mul_hi_u32 s22, s15, s18                                 // 000000001BC4: 9696120F
	s_mul_hi_u32 s24, s15, s19                                 // 000000001BC8: 9698130F
	s_add_co_u32 s4, s20, s23                                  // 000000001BCC: 80041714
	s_add_co_ci_u32 s4, s21, s22                               // 000000001BD0: 82041615
	s_mul_i32 s18, s15, s19                                    // 000000001BD4: 9612130F
	s_add_co_ci_u32 s19, s24, 0                                // 000000001BD8: 82138018
	s_wait_alu depctr_sa_sdst(0)                               // 000000001BDC: BF88FF9E
	s_add_nc_u64 s[18:19], s[4:5], s[18:19]                    // 000000001BE0: A9921204
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000001BE4: BF8704A9
	s_add_co_u32 s14, s14, s18                                 // 000000001BE8: 800E120E
	s_add_co_ci_u32 s15, s15, s19                              // 000000001BEC: 820F130F
	s_mul_u64 s[16:17], s[16:17], s[14:15]                     // 000000001BF0: AA900E10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001BF4: BF870009
	s_mul_hi_u32 s19, s14, s17                                 // 000000001BF8: 9693110E
	s_mul_i32 s18, s14, s17                                    // 000000001BFC: 9612110E
	s_mul_hi_u32 s4, s14, s16                                  // 000000001C00: 9684100E
	s_mul_i32 s21, s15, s16                                    // 000000001C04: 9615100F
	s_wait_alu depctr_sa_sdst(0)                               // 000000001C08: BF88FF9E
	s_add_nc_u64 s[18:19], s[4:5], s[18:19]                    // 000000001C0C: A9921204
	s_mul_hi_u32 s20, s15, s16                                 // 000000001C10: 9694100F
	s_mul_hi_u32 s22, s15, s17                                 // 000000001C14: 9696110F
	s_add_co_u32 s4, s18, s21                                  // 000000001C18: 80041512
	s_add_co_ci_u32 s4, s19, s20                               // 000000001C1C: 82041413
	s_mul_i32 s16, s15, s17                                    // 000000001C20: 9610110F
	s_add_co_ci_u32 s17, s22, 0                                // 000000001C24: 82118016
	s_wait_alu depctr_sa_sdst(0)                               // 000000001C28: BF88FF9E
	s_add_nc_u64 s[16:17], s[4:5], s[16:17]                    // 000000001C2C: A9901004
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001C30: BF870009
	s_add_co_u32 s14, s14, s16                                 // 000000001C34: 800E100E
	s_add_co_ci_u32 s16, s15, s17                              // 000000001C38: 8210110F
	s_mul_hi_u32 s4, s6, s14                                   // 000000001C3C: 96840E06
	s_mul_hi_u32 s17, s7, s14                                  // 000000001C40: 96910E07
	s_mul_i32 s18, s7, s14                                     // 000000001C44: 96120E07
	s_mul_hi_u32 s15, s6, s16                                  // 000000001C48: 968F1006
	s_mul_i32 s14, s6, s16                                     // 000000001C4C: 960E1006
	s_mul_hi_u32 s19, s7, s16                                  // 000000001C50: 96931007
	s_wait_alu depctr_sa_sdst(0)                               // 000000001C54: BF88FF9E
	s_add_nc_u64 s[14:15], s[4:5], s[14:15]                    // 000000001C58: A98E0E04
	s_mul_i32 s16, s7, s16                                     // 000000001C5C: 96101007
	s_add_co_u32 s4, s14, s18                                  // 000000001C60: 8004120E
	s_add_co_ci_u32 s4, s15, s17                               // 000000001C64: 8204110F
	s_add_co_ci_u32 s17, s19, 0                                // 000000001C68: 82118013
	s_wait_alu depctr_sa_sdst(0)                               // 000000001C6C: BF88FF9E
	s_add_nc_u64 s[14:15], s[4:5], s[16:17]                    // 000000001C70: A98E1004
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000001C74: BF870499
	s_mul_u64 s[16:17], s[12:13], s[14:15]                     // 000000001C78: AA900E0C
	s_sub_co_u32 s4, s6, s16                                   // 000000001C7C: 80841006
	s_cselect_b32 s16, -1, 0                                   // 000000001C80: 981080C1
	s_sub_co_i32 s18, s7, s17                                  // 000000001C84: 81921107
	s_cmp_lg_u32 s16, 0                                        // 000000001C88: BF078010
	s_sub_co_ci_u32 s18, s18, s13                              // 000000001C8C: 82920D12
	s_wait_alu depctr_sa_sdst(0)                               // 000000001C90: BF88FF9E
	s_sub_co_u32 s19, s4, s12                                  // 000000001C94: 80930C04
	s_sub_co_ci_u32 s18, s18, 0                                // 000000001C98: 82928012
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001C9C: BF870009
	s_cmp_ge_u32 s18, s13                                      // 000000001CA0: BF090D12
	s_cselect_b32 s20, -1, 0                                   // 000000001CA4: 981480C1
	s_cmp_ge_u32 s19, s12                                      // 000000001CA8: BF090C13
	s_cselect_b32 s21, -1, 0                                   // 000000001CAC: 981580C1
	s_cmp_eq_u32 s18, s13                                      // 000000001CB0: BF060D12
	s_add_nc_u64 s[18:19], s[14:15], 1                         // 000000001CB4: A992810E
	s_cselect_b32 s22, s21, s20                                // 000000001CB8: 98161415
	s_add_nc_u64 s[20:21], s[14:15], 2                         // 000000001CBC: A994820E
	s_cmp_lg_u32 s22, 0                                        // 000000001CC0: BF078016
	s_cselect_b32 s18, s20, s18                                // 000000001CC4: 98121214
	s_cselect_b32 s19, s21, s19                                // 000000001CC8: 98131315
	s_cmp_lg_u32 s16, 0                                        // 000000001CCC: BF078010
	s_sub_co_ci_u32 s16, s7, s17                               // 000000001CD0: 82901107
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001CD4: BF870009
	s_cmp_ge_u32 s16, s13                                      // 000000001CD8: BF090D10
	s_cselect_b32 s17, -1, 0                                   // 000000001CDC: 981180C1
	s_cmp_ge_u32 s4, s12                                       // 000000001CE0: BF090C04
	s_cselect_b32 s4, -1, 0                                    // 000000001CE4: 980480C1
	s_cmp_eq_u32 s16, s13                                      // 000000001CE8: BF060D10
	s_wait_alu depctr_sa_sdst(0)                               // 000000001CEC: BF88FF9E
	s_cselect_b32 s4, s4, s17                                  // 000000001CF0: 98041104
	s_wait_alu depctr_sa_sdst(0)                               // 000000001CF4: BF88FF9E
	s_cmp_lg_u32 s4, 0                                         // 000000001CF8: BF078004
	s_cselect_b32 s15, s19, s15                                // 000000001CFC: 980F0F13
	s_cselect_b32 s14, s18, s14                                // 000000001D00: 980E0E12
	s_branch 1                                                 // 000000001D04: BFA00001 <tessera_rocm_folded_matmul_a870cecb1991940b+0x20c>
	s_mov_b32 s5, -1                                           // 000000001D08: BE8500C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001D0C: BF870009
	s_and_b32 s4, s5, exec_lo                                  // 000000001D10: 8B047E05
	s_cselect_b32 s4, 1, 0                                     // 000000001D14: 98048081
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D18: BF88FF9E
	s_cmp_lg_u32 s4, 1                                         // 000000001D1C: BF078104
	s_cbranch_scc1 32                                          // 000000001D20: BFA20020 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2a4>
	v_cvt_f32_u32_e32 v1, s12                                  // 000000001D24: 7E020C0C
	s_sub_co_i32 s5, 0, s12                                    // 000000001D28: 81850C80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000001D2C: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 000000001D30: 7E025701
	v_mul_f32_e32 v1, 0x4f7ffffe, v1                           // 000000001D34: 100202FF 4F7FFFFE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000001D3C: BF870091
	v_cvt_u32_f32_e32 v1, v1                                   // 000000001D40: 7E020F01
	v_readfirstlane_b32 s4, v1                                 // 000000001D44: 7E080501
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D48: BF88FF9E
	s_mul_i32 s5, s5, s4                                       // 000000001D4C: 96050405
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D50: BF88FF9E
	s_mul_hi_u32 s5, s4, s5                                    // 000000001D54: 96850504
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D58: BF88FF9E
	s_add_co_i32 s4, s4, s5                                    // 000000001D5C: 81040504
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D60: BF88FF9E
	s_mul_hi_u32 s4, s6, s4                                    // 000000001D64: 96840406
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D68: BF88FF9E
	s_mul_i32 s5, s4, s12                                      // 000000001D6C: 96050C04
	s_add_co_i32 s14, s4, 1                                    // 000000001D70: 810E8104
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D74: BF88FF9E
	s_sub_co_i32 s5, s6, s5                                    // 000000001D78: 81850506
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D7C: BF88FF9E
	s_sub_co_i32 s15, s5, s12                                  // 000000001D80: 818F0C05
	s_cmp_ge_u32 s5, s12                                       // 000000001D84: BF090C05
	s_cselect_b32 s4, s14, s4                                  // 000000001D88: 9804040E
	s_cselect_b32 s5, s15, s5                                  // 000000001D8C: 9805050F
	s_wait_alu depctr_sa_sdst(0)                               // 000000001D90: BF88FF9E
	s_add_co_i32 s14, s4, 1                                    // 000000001D94: 810E8104
	s_cmp_ge_u32 s5, s12                                       // 000000001D98: BF090C05
	s_mov_b32 s15, 0                                           // 000000001D9C: BE8F0080
	s_cselect_b32 s14, s14, s4                                 // 000000001DA0: 980E040E
	s_add_nc_u64 s[16:17], s[8:9], 0xff                        // 000000001DA4: A990FF08 000000FF
	s_lshl_b64 s[4:5], s[14:15], 2                             // 000000001DAC: 8484820E
	s_lshr_b64 s[16:17], s[16:17], 8                           // 000000001DB0: 85908810
	s_mul_u64 s[12:13], s[14:15], s[12:13]                     // 000000001DB4: AA8C0C0E
	s_wait_alu depctr_sa_sdst(0)                               // 000000001DB8: BF88FF9E
	s_sub_nc_u64 s[16:17], s[16:17], s[4:5]                    // 000000001DBC: AA100410
	s_sub_nc_u64 s[6:7], s[6:7], s[12:13]                      // 000000001DC0: AA060C06
	v_cmp_lt_u64_e64 s18, s[16:17], 4                          // 000000001DC4: D4590012 02010810
	s_mov_b32 s15, 0                                           // 000000001DCC: BE8F0080
	s_and_b32 s12, s18, exec_lo                                // 000000001DD0: 8B0C7E12
	s_cselect_b32 s13, s17, 0                                  // 000000001DD4: 980D8011
	s_cselect_b32 s12, s16, 4                                  // 000000001DD8: 980C8410
	s_cmp_lg_u32 s7, 0                                         // 000000001DDC: BF078007
	s_cbranch_scc0 119                                         // 000000001DE0: BFA10077 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4c0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000001DE4: BF88FF9E
	s_cvt_f32_u32 s14, s12                                     // 000000001DE8: BE8E650C
	s_cvt_f32_u32 s16, s13                                     // 000000001DEC: BE90650D
	s_sub_nc_u64 s[18:19], 0, s[12:13]                         // 000000001DF0: AA120C80
	s_wait_alu depctr_sa_sdst(0)                               // 000000001DF4: BF88FF9E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000001DF8: BF870599
	s_fmac_f32 s14, s16, 0x4f800000                            // 000000001DFC: A38EFF10 4F800000
	v_s_rcp_f32 s14, s14                                       // 000000001E04: D684000E 0201000E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000001E0C: BF870525
	s_mul_f32 s14, s14, 0x5f7ffffc                             // 000000001E10: A20EFF0E 5F7FFFFC
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E18: BF88FF9E
	s_mul_f32 s16, s14, 0x2f800000                             // 000000001E1C: A210FF0E 2F800000
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E24: BF88FF9E
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000001E28: BF87052A
	s_trunc_f32 s16, s16                                       // 000000001E2C: BE906210
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E30: BF88FF9E
	s_fmac_f32 s14, s16, 0xcf800000                            // 000000001E34: A38EFF10 CF800000
	s_cvt_u32_f32 s17, s16                                     // 000000001E3C: BE916710
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E40: BF88FF9E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000001E44: BF870529
	s_cvt_u32_f32 s16, s14                                     // 000000001E48: BE90670E
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E4C: BF88FF9E
	s_mul_u64 s[20:21], s[18:19], s[16:17]                     // 000000001E50: AA941012
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001E54: BF870009
	s_mul_hi_u32 s23, s16, s21                                 // 000000001E58: 96971510
	s_mul_i32 s22, s16, s21                                    // 000000001E5C: 96161510
	s_mul_hi_u32 s14, s16, s20                                 // 000000001E60: 968E1410
	s_mul_i32 s25, s17, s20                                    // 000000001E64: 96191411
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E68: BF88FF9E
	s_add_nc_u64 s[22:23], s[14:15], s[22:23]                  // 000000001E6C: A996160E
	s_mul_hi_u32 s24, s17, s20                                 // 000000001E70: 96981411
	s_mul_hi_u32 s26, s17, s21                                 // 000000001E74: 969A1511
	s_add_co_u32 s14, s22, s25                                 // 000000001E78: 800E1916
	s_add_co_ci_u32 s14, s23, s24                              // 000000001E7C: 820E1817
	s_mul_i32 s20, s17, s21                                    // 000000001E80: 96141511
	s_add_co_ci_u32 s21, s26, 0                                // 000000001E84: 8215801A
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E88: BF88FF9E
	s_add_nc_u64 s[20:21], s[14:15], s[20:21]                  // 000000001E8C: A994140E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000001E90: BF8704C9
	s_add_co_u32 s16, s16, s20                                 // 000000001E94: 80101410
	s_add_co_ci_u32 s17, s17, s21                              // 000000001E98: 82111511
	s_wait_alu depctr_sa_sdst(0)                               // 000000001E9C: BF88FF9E
	s_mul_u64 s[18:19], s[18:19], s[16:17]                     // 000000001EA0: AA921012
	s_mul_hi_u32 s21, s16, s19                                 // 000000001EA4: 96951310
	s_mul_i32 s20, s16, s19                                    // 000000001EA8: 96141310
	s_mul_hi_u32 s14, s16, s18                                 // 000000001EAC: 968E1210
	s_mul_i32 s23, s17, s18                                    // 000000001EB0: 96171211
	s_wait_alu depctr_sa_sdst(0)                               // 000000001EB4: BF88FF9E
	s_add_nc_u64 s[20:21], s[14:15], s[20:21]                  // 000000001EB8: A994140E
	s_mul_hi_u32 s22, s17, s18                                 // 000000001EBC: 96961211
	s_mul_hi_u32 s24, s17, s19                                 // 000000001EC0: 96981311
	s_add_co_u32 s14, s20, s23                                 // 000000001EC4: 800E1714
	s_add_co_ci_u32 s14, s21, s22                              // 000000001EC8: 820E1615
	s_mul_i32 s18, s17, s19                                    // 000000001ECC: 96121311
	s_add_co_ci_u32 s19, s24, 0                                // 000000001ED0: 82138018
	s_wait_alu depctr_sa_sdst(0)                               // 000000001ED4: BF88FF9E
	s_add_nc_u64 s[18:19], s[14:15], s[18:19]                  // 000000001ED8: A992120E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001EDC: BF870009
	s_add_co_u32 s16, s16, s18                                 // 000000001EE0: 80101210
	s_add_co_ci_u32 s18, s17, s19                              // 000000001EE4: 82121311
	s_wait_alu depctr_sa_sdst(0)                               // 000000001EE8: BF88FF9E
	s_mul_hi_u32 s14, s6, s16                                  // 000000001EEC: 968E1006
	s_mul_hi_u32 s19, s7, s16                                  // 000000001EF0: 96931007
	s_mul_i32 s20, s7, s16                                     // 000000001EF4: 96141007
	s_mul_hi_u32 s17, s6, s18                                  // 000000001EF8: 96911206
	s_mul_i32 s16, s6, s18                                     // 000000001EFC: 96101206
	s_mul_hi_u32 s21, s7, s18                                  // 000000001F00: 96951207
	s_wait_alu depctr_sa_sdst(0)                               // 000000001F04: BF88FF9E
	s_add_nc_u64 s[16:17], s[14:15], s[16:17]                  // 000000001F08: A990100E
	s_mul_i32 s18, s7, s18                                     // 000000001F0C: 96121207
	s_wait_alu depctr_sa_sdst(0)                               // 000000001F10: BF88FF9E
	s_add_co_u32 s14, s16, s20                                 // 000000001F14: 800E1410
	s_add_co_ci_u32 s14, s17, s19                              // 000000001F18: 820E1311
	s_add_co_ci_u32 s19, s21, 0                                // 000000001F1C: 82138015
	s_wait_alu depctr_sa_sdst(0)                               // 000000001F20: BF88FF9E
	s_add_nc_u64 s[16:17], s[14:15], s[18:19]                  // 000000001F24: A990120E
	s_wait_alu depctr_sa_sdst(0)                               // 000000001F28: BF88FF9E
	s_mul_u64 s[18:19], s[12:13], s[16:17]                     // 000000001F2C: AA92100C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001F30: BF870009
	s_sub_co_u32 s14, s6, s18                                  // 000000001F34: 808E1206
	s_cselect_b32 s18, -1, 0                                   // 000000001F38: 981280C1
	s_sub_co_i32 s20, s7, s19                                  // 000000001F3C: 81941307
	s_cmp_lg_u32 s18, 0                                        // 000000001F40: BF078012
	s_sub_co_ci_u32 s20, s20, s13                              // 000000001F44: 82940D14
	s_wait_alu depctr_sa_sdst(0)                               // 000000001F48: BF88FF9E
	s_sub_co_u32 s21, s14, s12                                 // 000000001F4C: 80950C0E
	s_sub_co_ci_u32 s20, s20, 0                                // 000000001F50: 82948014
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001F54: BF870009
	s_cmp_ge_u32 s20, s13                                      // 000000001F58: BF090D14
	s_cselect_b32 s22, -1, 0                                   // 000000001F5C: 981680C1
	s_cmp_ge_u32 s21, s12                                      // 000000001F60: BF090C15
	s_cselect_b32 s23, -1, 0                                   // 000000001F64: 981780C1
	s_cmp_eq_u32 s20, s13                                      // 000000001F68: BF060D14
	s_add_nc_u64 s[20:21], s[16:17], 1                         // 000000001F6C: A9948110
	s_cselect_b32 s24, s23, s22                                // 000000001F70: 98181617
	s_add_nc_u64 s[22:23], s[16:17], 2                         // 000000001F74: A9968210
	s_cmp_lg_u32 s24, 0                                        // 000000001F78: BF078018
	s_cselect_b32 s20, s22, s20                                // 000000001F7C: 98141416
	s_cselect_b32 s21, s23, s21                                // 000000001F80: 98151517
	s_cmp_lg_u32 s18, 0                                        // 000000001F84: BF078012
	s_sub_co_ci_u32 s18, s7, s19                               // 000000001F88: 82921307
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001F8C: BF870009
	s_cmp_ge_u32 s18, s13                                      // 000000001F90: BF090D12
	s_cselect_b32 s19, -1, 0                                   // 000000001F94: 981380C1
	s_cmp_ge_u32 s14, s12                                      // 000000001F98: BF090C0E
	s_cselect_b32 s14, -1, 0                                   // 000000001F9C: 980E80C1
	s_cmp_eq_u32 s18, s13                                      // 000000001FA0: BF060D12
	s_wait_alu depctr_sa_sdst(0)                               // 000000001FA4: BF88FF9E
	s_cselect_b32 s14, s14, s19                                // 000000001FA8: 980E130E
	s_wait_alu depctr_sa_sdst(0)                               // 000000001FAC: BF88FF9E
	s_cmp_lg_u32 s14, 0                                        // 000000001FB0: BF07800E
	s_cselect_b32 s17, s21, s17                                // 000000001FB4: 98111115
	s_cselect_b32 s16, s20, s16                                // 000000001FB8: 98101014
	s_branch 1                                                 // 000000001FBC: BFA00001 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4c4>
	s_mov_b32 s15, -1                                          // 000000001FC0: BE8F00C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000001FC4: BF870009
	s_and_b32 s14, s15, exec_lo                                // 000000001FC8: 8B0E7E0F
	s_cselect_b32 s14, 1, 0                                    // 000000001FCC: 980E8081
	s_wait_alu depctr_sa_sdst(0)                               // 000000001FD0: BF88FF9E
	s_cmp_lg_u32 s14, 1                                        // 000000001FD4: BF07810E
	s_cbranch_scc1 33                                          // 000000001FD8: BFA20021 <tessera_rocm_folded_matmul_a870cecb1991940b+0x560>
	v_cvt_f32_u32_e32 v1, s12                                  // 000000001FDC: 7E020C0C
	s_sub_co_i32 s15, 0, s12                                   // 000000001FE0: 818F0C80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000001FE4: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 000000001FE8: 7E025701
	v_mul_f32_e32 v1, 0x4f7ffffe, v1                           // 000000001FEC: 100202FF 4F7FFFFE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000001FF4: BF870091
	v_cvt_u32_f32_e32 v1, v1                                   // 000000001FF8: 7E020F01
	v_readfirstlane_b32 s14, v1                                // 000000001FFC: 7E1C0501
	s_wait_alu depctr_sa_sdst(0)                               // 000000002000: BF88FF9E
	s_mul_i32 s15, s15, s14                                    // 000000002004: 960F0E0F
	s_wait_alu depctr_sa_sdst(0)                               // 000000002008: BF88FF9E
	s_mul_hi_u32 s15, s14, s15                                 // 00000000200C: 968F0F0E
	s_wait_alu depctr_sa_sdst(0)                               // 000000002010: BF88FF9E
	s_add_co_i32 s14, s14, s15                                 // 000000002014: 810E0F0E
	s_wait_alu depctr_sa_sdst(0)                               // 000000002018: BF88FF9E
	s_mul_hi_u32 s14, s6, s14                                  // 00000000201C: 968E0E06
	s_wait_alu depctr_sa_sdst(0)                               // 000000002020: BF88FF9E
	s_mul_i32 s15, s14, s12                                    // 000000002024: 960F0C0E
	s_add_co_i32 s16, s14, 1                                   // 000000002028: 8110810E
	s_wait_alu depctr_sa_sdst(0)                               // 00000000202C: BF88FF9E
	s_sub_co_i32 s15, s6, s15                                  // 000000002030: 818F0F06
	s_wait_alu depctr_sa_sdst(0)                               // 000000002034: BF88FF9E
	s_sub_co_i32 s17, s15, s12                                 // 000000002038: 81910C0F
	s_cmp_ge_u32 s15, s12                                      // 00000000203C: BF090C0F
	s_cselect_b32 s14, s16, s14                                // 000000002040: 980E0E10
	s_wait_alu depctr_sa_sdst(0)                               // 000000002044: BF88FF9E
	s_cselect_b32 s15, s17, s15                                // 000000002048: 980F0F11
	s_add_co_i32 s16, s14, 1                                   // 00000000204C: 8110810E
	s_wait_alu depctr_sa_sdst(0)                               // 000000002050: BF88FF9E
	s_cmp_ge_u32 s15, s12                                      // 000000002054: BF090C0F
	s_mov_b32 s17, 0                                           // 000000002058: BE910080
	s_cselect_b32 s16, s16, s14                                // 00000000205C: 98100E10
	s_load_b64 s[18:19], s[0:1], 0x8                           // 000000002060: F4002480 F8000008
	s_mul_u64 s[12:13], s[16:17], s[12:13]                     // 000000002068: AA8C0C10
	v_lshrrev_b32_e32 v11, 2, v0                               // 00000000206C: 32160082
	s_wait_alu depctr_sa_sdst(0)                               // 000000002070: BF88FF9E
	s_sub_nc_u64 s[6:7], s[6:7], s[12:13]                      // 000000002074: AA060C06
	s_load_b64 s[12:13], s[0:1], 0x30                          // 000000002078: F4002300 F8000030
	s_add_nc_u64 s[4:5], s[6:7], s[4:5]                        // 000000002080: A9840406
	v_dual_mov_b32 v56, 0 :: v_dual_lshlrev_b32 v1, 4, v0      // 000000002084: CA220080 38000084
	s_wait_alu depctr_sa_sdst(0)                               // 00000000208C: BF88FF9E
	s_lshl_b64 s[6:7], s[4:5], 8                               // 000000002090: 84868804
	s_lshl_b64 s[14:15], s[16:17], 6                           // 000000002094: 848E8610
	v_or_b32_e32 v2, s6, v11                                   // 000000002098: 38041606
	v_dual_mov_b32 v57, v56 :: v_dual_and_b32 v76, 48, v1      // 00000000209C: CA240138 394C02B0
	s_wait_alu depctr_sa_sdst(0)                               // 0000000020A4: BF88FF9E
	v_or_b32_e32 v9, s14, v11                                  // 0000000020A8: 3812160E
	s_mul_i32 s4, s7, s2                                       // 0000000020AC: 96040207
	v_or_b32_e32 v3, 64, v2                                    // 0000000020B0: 380604C0
	v_or_b32_e32 v5, 0x80, v2                                  // 0000000020B4: 380A04FF 00000080
	v_or_b32_e32 v7, 0xc0, v2                                  // 0000000020BC: 380E04FF 000000C0
	v_mul_lo_u32 v12, v2, s3                                   // 0000000020C4: D72C000C 02000702
	v_mul_lo_u32 v15, v9, s3                                   // 0000000020CC: D72C000F 02000709
	s_wait_kmcnt 0x0                                           // 0000000020D4: BFC70000
	v_mad_co_u64_u32 v[1:2], null, v2, s2, s[18:19]            // 0000000020D8: D6FE7C01 00480502
	v_mul_lo_u32 v13, v3, s3                                   // 0000000020E0: D72C000D 02000703
	v_mad_co_u64_u32 v[3:4], null, v3, s2, s[18:19]            // 0000000020E8: D6FE7C03 00480503
	v_mul_lo_u32 v14, v5, s3                                   // 0000000020F0: D72C000E 02000705
	v_mad_co_u64_u32 v[5:6], null, v5, s2, s[18:19]            // 0000000020F8: D6FE7C05 00480505
	v_mul_lo_u32 v16, v7, s3                                   // 000000002100: D72C0010 02000707
	v_mad_co_u64_u32 v[7:8], null, v7, s2, s[18:19]            // 000000002108: D6FE7C07 00480507
	v_mad_co_u64_u32 v[9:10], null, v9, s2, s[12:13]           // 000000002110: D6FE7C09 00300509
	s_wait_alu depctr_sa_sdst(0)                               // 000000002118: BF88FF9E
	v_add3_u32 v2, s4, v2, v12                                 // 00000000211C: D6550002 04320404
	v_add_co_u32 v64, vcc_lo, v1, v76                          // 000000002124: D7006A40 02029901
	v_add3_u32 v4, s4, v4, v13                                 // 00000000212C: D6550004 04360804
	v_add3_u32 v6, s4, v6, v14                                 // 000000002134: D6550006 043A0C04
	s_delay_alu instid0(VALU_DEP_4)                            // 00000000213C: BF870004
	v_add_co_ci_u32_e64 v65, null, 0, v2, vcc_lo               // 000000002140: D5207C41 01AA0480
	v_add_co_u32 v66, vcc_lo, v3, v76                          // 000000002148: D7006A42 02029903
	s_mul_i32 s5, s15, s2                                      // 000000002150: 9605020F
	v_add3_u32 v1, s4, v8, v16                                 // 000000002154: D6550001 04421004
	s_wait_alu depctr_va_vcc(0)                                // 00000000215C: BF88FF9D
	v_add_co_ci_u32_e64 v67, null, 0, v4, vcc_lo               // 000000002160: D5207C43 01AA0880
	v_add_co_u32 v68, vcc_lo, v5, v76                          // 000000002168: D7006A44 02029905
	s_wait_alu depctr_sa_sdst(0)                               // 000000002170: BF88FF9E
	v_add3_u32 v2, s5, v10, v15                                // 000000002174: D6550002 043E1405
	s_wait_alu depctr_va_vcc(0)                                // 00000000217C: BF88FF9D
	v_add_co_ci_u32_e64 v69, null, 0, v6, vcc_lo               // 000000002180: D5207C45 01AA0C80
	v_add_co_u32 v70, vcc_lo, v7, v76                          // 000000002188: D7006A46 02029907
	s_wait_alu depctr_va_vcc(0)                                // 000000002190: BF88FF9D
	v_add_co_ci_u32_e64 v71, null, 0, v1, vcc_lo               // 000000002194: D5207C47 01AA0280
	v_add_co_u32 v74, vcc_lo, v9, v76                          // 00000000219C: D7006A4A 02029909
	s_wait_alu depctr_va_vcc(0)                                // 0000000021A4: BF88FF9D
	v_add_co_ci_u32_e64 v75, null, 0, v2, vcc_lo               // 0000000021A8: D5207C4B 01AA0480
	s_clause 0x3                                               // 0000000021B0: BF850003
	global_load_b128 v[82:85], v[64:65], off                   // 0000000021B4: EE05C07C 00000052 00000040
	global_load_b128 v[86:89], v[66:67], off                   // 0000000021C0: EE05C07C 00000056 00000042
	global_load_b128 v[90:93], v[68:69], off                   // 0000000021CC: EE05C07C 0000005A 00000044
	global_load_b128 v[94:97], v[70:71], off                   // 0000000021D8: EE05C07C 0000005E 00000046
	global_load_b128 v[98:101], v[74:75], off                  // 0000000021E4: EE05C07C 00000062 0000004A
	v_mul_u32_u24_e32 v6, 0x50, v11                            // 0000000021F0: 160C16FF 00000050
	v_dual_mov_b32 v59, v56 :: v_dual_and_b32 v78, 15, v0      // 0000000021F8: CA240138 3B4E008F
	v_dual_mov_b32 v61, v56 :: v_dual_and_b32 v72, 0xc0, v0    // 000000002200: CA240138 3D4800FF 000000C0
	v_dual_mov_b32 v58, v56 :: v_dual_and_b32 v81, 32, v0      // 00000000220C: CA240138 3A5000A0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000002214: BF870004
	v_add_nc_u32_e32 v76, v6, v76                              // 000000002218: 4A989906
	v_lshrrev_b32_e32 v1, 1, v0                                // 00000000221C: 32020081
	v_dual_mov_b32 v63, v56 :: v_dual_and_b32 v2, 0xcf, v0     // 000000002220: CA240138 3F0200FF 000000CF
	v_dual_mov_b32 v25, v56 :: v_dual_and_b32 v0, 47, v0       // 00000000222C: CA240138 190000AF
	v_or_b32_e32 v80, 16, v72                                  // 000000002234: 38A09090
	v_or_b32_e32 v102, 32, v72                                 // 000000002238: 38CC90A0
	v_or_b32_e32 v128, 48, v72                                 // 00000000223C: 390090B0
	v_or3_b32 v160, v78, v81, 16                               // 000000002240: D65800A0 0242A34E
	v_dual_mov_b32 v60, v56 :: v_dual_and_b32 v73, 8, v1       // 000000002248: CA240138 3C480288
	v_mul_u32_u24_e32 v79, 0x50, v0                            // 000000002250: 169E00FF 00000050
	v_or_b32_e32 v103, v80, v78                                // 000000002258: 38CE9D50
	v_mul_u32_u24_e32 v77, 0x50, v2                            // 00000000225C: 169A04FF 00000050
	v_dual_mov_b32 v62, v56 :: v_dual_mov_b32 v27, v56         // 000000002264: CA100138 3E1A0138
	s_delay_alu instid0(VALU_DEP_4)                            // 00000000226C: BF870004
	v_or_b32_e32 v79, v73, v79                                 // 000000002270: 389E9F49
	v_dual_mov_b32 v24, v56 :: v_dual_mov_b32 v29, v56         // 000000002274: CA100138 181C0138
	v_dual_mov_b32 v26, v56 :: v_dual_mov_b32 v31, v56         // 00000000227C: CA100138 1A1E0138
	v_dual_mov_b32 v28, v56 :: v_dual_mov_b32 v49, v56         // 000000002284: CA100138 1C300138
	v_dual_mov_b32 v30, v56 :: v_dual_mov_b32 v51, v56         // 00000000228C: CA100138 1E320138
	v_dual_mov_b32 v48, v56 :: v_dual_mov_b32 v53, v56         // 000000002294: CA100138 30340138
	v_dual_mov_b32 v50, v56 :: v_dual_mov_b32 v55, v56         // 00000000229C: CA100138 32360138
	v_dual_mov_b32 v52, v56 :: v_dual_mov_b32 v17, v56         // 0000000022A4: CA100138 34100138
	v_dual_mov_b32 v54, v56 :: v_dual_mov_b32 v19, v56         // 0000000022AC: CA100138 36120138
	v_dual_mov_b32 v16, v56 :: v_dual_mov_b32 v21, v56         // 0000000022B4: CA100138 10140138
	v_dual_mov_b32 v18, v56 :: v_dual_mov_b32 v23, v56         // 0000000022BC: CA100138 12160138
	v_dual_mov_b32 v20, v56 :: v_dual_mov_b32 v41, v56         // 0000000022C4: CA100138 14280138
	v_dual_mov_b32 v22, v56 :: v_dual_mov_b32 v43, v56         // 0000000022CC: CA100138 162A0138
	v_dual_mov_b32 v40, v56 :: v_dual_mov_b32 v45, v56         // 0000000022D4: CA100138 282C0138
	v_dual_mov_b32 v42, v56 :: v_dual_mov_b32 v47, v56         // 0000000022DC: CA100138 2A2E0138
	v_dual_mov_b32 v44, v56 :: v_dual_mov_b32 v9, v56          // 0000000022E4: CA100138 2C080138
	v_dual_mov_b32 v46, v56 :: v_dual_mov_b32 v11, v56         // 0000000022EC: CA100138 2E0A0138
	v_dual_mov_b32 v8, v56 :: v_dual_mov_b32 v13, v56          // 0000000022F4: CA100138 080C0138
	v_dual_mov_b32 v10, v56 :: v_dual_mov_b32 v15, v56         // 0000000022FC: CA100138 0A0E0138
	v_dual_mov_b32 v12, v56 :: v_dual_mov_b32 v33, v56         // 000000002304: CA100138 0C200138
	v_dual_mov_b32 v14, v56 :: v_dual_mov_b32 v35, v56         // 00000000230C: CA100138 0E220138
	v_dual_mov_b32 v32, v56 :: v_dual_mov_b32 v37, v56         // 000000002314: CA100138 20240138
	v_dual_mov_b32 v34, v56 :: v_dual_mov_b32 v39, v56         // 00000000231C: CA100138 22260138
	v_dual_mov_b32 v36, v56 :: v_dual_mov_b32 v1, v56          // 000000002324: CA100138 24000138
	v_dual_mov_b32 v38, v56 :: v_dual_mov_b32 v3, v56          // 00000000232C: CA100138 26020138
	v_dual_mov_b32 v0, v56 :: v_dual_mov_b32 v5, v56           // 000000002334: CA100138 00040138
	v_dual_mov_b32 v2, v56 :: v_dual_mov_b32 v7, v56           // 00000000233C: CA100138 02060138
	v_dual_mov_b32 v4, v56 :: v_dual_add_nc_u32 v79, 0x5000, v79// 000000002344: CA200138 044E9EFF 00005000
	v_or_b32_e32 v77, v73, v77                                 // 000000002350: 389A9B49
	s_movk_i32 s4, 0xffc0                                      // 000000002354: B004FFC0
	s_mov_b32 s5, -1                                           // 000000002358: BE8500C1
	s_lshr_b64 s[12:13], s[2:3], 6                             // 00000000235C: 858C8602
	s_mov_b64 s[16:17], 64                                     // 000000002360: BE9001C0
	s_wait_alu depctr_sa_sdst(0)                               // 000000002364: BF88FF9E
	s_add_nc_u64 s[18:19], s[2:3], s[4:5]                      // 000000002368: A9920402
	s_wait_loadcnt 0x4                                         // 00000000236C: BFC00004
	ds_store_b128 v76, v[82:85]                                // 000000002370: DB7C0000 0000524C
	s_wait_loadcnt 0x3                                         // 000000002378: BFC00003
	ds_store_b128 v76, v[86:89] offset:5120                    // 00000000237C: DB7C1400 0000564C
	s_wait_loadcnt 0x2                                         // 000000002384: BFC00002
	ds_store_b128 v76, v[90:93] offset:10240                   // 000000002388: DB7C2800 00005A4C
	s_wait_loadcnt 0x1                                         // 000000002390: BFC00001
	ds_store_b128 v76, v[94:97] offset:15360                   // 000000002394: DB7C3C00 00005E4C
	s_wait_loadcnt 0x0                                         // 00000000239C: BFC00000
	ds_store_b128 v76, v[98:101] offset:20480                  // 0000000023A0: DB7C5000 0000624C
	v_or_b32_e32 v82, v102, v78                                // 0000000023A8: 38A49D66
	v_or_b32_e32 v83, v128, v78                                // 0000000023AC: 38A69D80
	v_mul_u32_u24_e32 v84, 0x50, v160                          // 0000000023B0: 16A940FF 00000050
	s_wait_dscnt 0x0                                           // 0000000023B8: BFC60000
	s_barrier_signal -1                                        // 0000000023BC: BE804EC1
	v_mul_u32_u24_e32 v85, 0x50, v103                          // 0000000023C0: 16AACEFF 00000050
	v_mul_u32_u24_e32 v86, 0x50, v82                           // 0000000023C8: 16ACA4FF 00000050
	v_mul_u32_u24_e32 v87, 0x50, v83                           // 0000000023D0: 16AEA6FF 00000050
	v_or_b32_e32 v88, v84, v73                                 // 0000000023D8: 38B09354
	v_mov_b32_e32 v6, v56                                      // 0000000023DC: 7E0C0338
	v_or_b32_e32 v82, v85, v73                                 // 0000000023E0: 38A49355
	v_or_b32_e32 v83, v86, v73                                 // 0000000023E4: 38A69356
	v_or_b32_e32 v84, v87, v73                                 // 0000000023E8: 38A89357
	v_add_nc_u32_e32 v85, 0x5000, v88                          // 0000000023EC: 4AAAB0FF 00005000
	s_barrier_wait 0xffff                                      // 0000000023F4: BF94FFFF
	s_wait_alu depctr_sa_sdst(0)                               // 0000000023F8: BF88FF9E
	v_cmp_lt_u64_e64 s2, s[16:17], s[18:19]                    // 0000000023FC: D4590002 02002410
	ds_load_2addr_b64 v[107:110], v77 offset1:2                // 000000002404: D9DC0200 6B00004D
	ds_load_2addr_b64 v[111:114], v79 offset1:2                // 00000000240C: D9DC0200 6F00004F
	ds_load_2addr_b64 v[115:118], v85 offset1:2                // 000000002414: D9DC0200 73000055
	ds_load_2addr_b64 v[119:122], v82 offset1:2                // 00000000241C: D9DC0200 77000052
	ds_load_2addr_b64 v[123:126], v83 offset1:2                // 000000002424: D9DC0200 7B000053
	s_and_b32 s2, s2, exec_lo                                  // 00000000242C: 8B027E02
	s_cselect_b32 s5, s16, s18                                 // 000000002430: 98051210
	s_cselect_b32 s20, s17, s19                                // 000000002434: 98141311
	s_wait_alu depctr_sa_sdst(0)                               // 000000002438: BF88FF9E
	v_add_co_u32 v86, vcc_lo, v64, s5                          // 00000000243C: D7006A56 02000B40
	v_add_co_u32 v90, s2, v66, s5                              // 000000002444: D700025A 02000B42
	v_add_co_u32 v94, s3, v68, s5                              // 00000000244C: D700035E 02000B44
	v_add_co_u32 v98, s4, v70, s5                              // 000000002454: D7000462 02000B46
	v_add_co_u32 v103, s5, v74, s5                             // 00000000245C: D7000567 02000B4A
	s_wait_alu depctr_va_vcc(0)                                // 000000002464: BF88FF9D
	v_add_co_ci_u32_e64 v87, null, s20, v65, vcc_lo            // 000000002468: D5207C57 01AA8214
	s_wait_alu depctr_va_sdst(0)                               // 000000002470: BF88F19F
	v_add_co_ci_u32_e64 v91, null, s20, v67, s2                // 000000002474: D5207C5B 000A8614
	v_add_co_ci_u32_e64 v95, null, s20, v69, s3                // 00000000247C: D5207C5F 000E8A14
	v_add_co_ci_u32_e64 v99, null, s20, v71, s4                // 000000002484: D5207C63 00128E14
	v_add_co_ci_u32_e64 v104, null, s20, v75, s5               // 00000000248C: D5207C68 00169614
	s_clause 0x3                                               // 000000002494: BF850003
	global_load_b128 v[86:89], v[86:87], off                   // 000000002498: EE05C07C 00000056 00000056
	global_load_b128 v[90:93], v[90:91], off                   // 0000000024A4: EE05C07C 0000005A 0000005A
	global_load_b128 v[94:97], v[94:95], off                   // 0000000024B0: EE05C07C 0000005E 0000005E
	global_load_b128 v[98:101], v[98:99], off                  // 0000000024BC: EE05C07C 00000062 00000062
	global_load_b128 v[103:106], v[103:104], off               // 0000000024C8: EE05C07C 00000067 00000067
	ds_load_2addr_b64 v[129:132], v84 offset1:2                // 0000000024D4: D9DC0200 81000054
	s_wait_dscnt 0x4                                           // 0000000024DC: BFC60004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[107:108], v[111:112], v[56:63]// 0000000024E0: CC464038 1CE2DF6B
	s_wait_dscnt 0x3                                           // 0000000024E8: BFC60003
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[107:108], v[115:116], v[24:31]// 0000000024EC: CC464018 1C62E76B
	s_wait_dscnt 0x2                                           // 0000000024F4: BFC60002
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[119:120], v[111:112], v[48:55]// 0000000024F8: CC464030 1CC2DF77
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[119:120], v[115:116], v[16:23]// 000000002500: CC464010 1C42E777
	s_wait_dscnt 0x1                                           // 000000002508: BFC60001
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[123:124], v[111:112], v[40:47]// 00000000250C: CC464028 1CA2DF7B
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[123:124], v[115:116], v[8:15]// 000000002514: CC464008 1C22E77B
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[109:110], v[113:114], v[56:63]// 00000000251C: CC464038 1CE2E36D
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[109:110], v[117:118], v[24:31]// 000000002524: CC464018 1C62EB6D
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[121:122], v[113:114], v[48:55]// 00000000252C: CC464030 1CC2E379
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[121:122], v[117:118], v[16:23]// 000000002534: CC464010 1C42EB79
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[125:126], v[113:114], v[40:47]// 00000000253C: CC464028 1CA2E37D
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[125:126], v[117:118], v[8:15]// 000000002544: CC464008 1C22EB7D
	s_add_nc_u64 s[12:13], s[12:13], -1                        // 00000000254C: A98CC10C
	s_add_nc_u64 s[16:17], s[16:17], 64                        // 000000002550: A990C010
	s_wait_alu depctr_sa_sdst(0)                               // 000000002554: BF88FF9E
	s_cmp_lg_u64 s[12:13], 0                                   // 000000002558: BF11800C
	s_wait_dscnt 0x0                                           // 00000000255C: BFC60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[129:130], v[111:112], v[32:39]// 000000002560: CC464020 1C82DF81
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[129:130], v[115:116], v[0:7]// 000000002568: CC464000 1C02E781
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000002570: BF870112
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[131:132], v[113:114], v[32:39]// 000000002574: CC464020 1C82E383
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[131:132], v[117:118], v[0:7]// 00000000257C: CC464000 1C02EB83
	ds_load_2addr_b64 v[107:110], v77 offset0:4 offset1:6      // 000000002584: D9DC0604 6B00004D
	ds_load_2addr_b64 v[111:114], v79 offset0:4 offset1:6      // 00000000258C: D9DC0604 6F00004F
	ds_load_2addr_b64 v[115:118], v85 offset0:4 offset1:6      // 000000002594: D9DC0604 73000055
	ds_load_2addr_b64 v[119:122], v82 offset0:4 offset1:6      // 00000000259C: D9DC0604 77000052
	ds_load_2addr_b64 v[123:126], v83 offset0:4 offset1:6      // 0000000025A4: D9DC0604 7B000053
	ds_load_2addr_b64 v[129:132], v84 offset0:4 offset1:6      // 0000000025AC: D9DC0604 81000054
	s_wait_dscnt 0x0                                           // 0000000025B4: BFC60000
	s_barrier_signal -1                                        // 0000000025B8: BE804EC1
	s_barrier_wait 0xffff                                      // 0000000025BC: BF94FFFF
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[107:108], v[111:112], v[56:63]// 0000000025C0: CC464038 1CE2DF6B
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[107:108], v[115:116], v[24:31]// 0000000025C8: CC464018 1C62E76B
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[119:120], v[111:112], v[48:55]// 0000000025D0: CC464030 1CC2DF77
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[119:120], v[115:116], v[16:23]// 0000000025D8: CC464010 1C42E777
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[123:124], v[111:112], v[40:47]// 0000000025E0: CC464028 1CA2DF7B
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[123:124], v[115:116], v[8:15]// 0000000025E8: CC464008 1C22E77B
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[129:130], v[111:112], v[32:39]// 0000000025F0: CC464020 1C82DF81
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[129:130], v[115:116], v[0:7]// 0000000025F8: CC464000 1C02E781
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[109:110], v[113:114], v[56:63]// 000000002600: CC464038 1CE2E36D
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[109:110], v[117:118], v[24:31]// 000000002608: CC464018 1C62EB6D
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[121:122], v[113:114], v[48:55]// 000000002610: CC464030 1CC2E379
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[121:122], v[117:118], v[16:23]// 000000002618: CC464010 1C42EB79
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[125:126], v[113:114], v[40:47]// 000000002620: CC464028 1CA2E37D
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[125:126], v[117:118], v[8:15]// 000000002628: CC464008 1C22EB7D
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[131:132], v[113:114], v[32:39]// 000000002630: CC464020 1C82E383
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[131:132], v[117:118], v[0:7]// 000000002638: CC464000 1C02EB83
	s_wait_loadcnt 0x4                                         // 000000002640: BFC00004
	ds_store_b128 v76, v[86:89]                                // 000000002644: DB7C0000 0000564C
	s_wait_loadcnt 0x3                                         // 00000000264C: BFC00003
	ds_store_b128 v76, v[90:93] offset:5120                    // 000000002650: DB7C1400 00005A4C
	s_wait_loadcnt 0x2                                         // 000000002658: BFC00002
	ds_store_b128 v76, v[94:97] offset:10240                   // 00000000265C: DB7C2800 00005E4C
	s_wait_loadcnt 0x1                                         // 000000002664: BFC00001
	ds_store_b128 v76, v[98:101] offset:15360                  // 000000002668: DB7C3C00 0000624C
	s_wait_loadcnt 0x0                                         // 000000002670: BFC00000
	ds_store_b128 v76, v[103:106] offset:20480                 // 000000002674: DB7C5000 0000674C
	s_wait_dscnt 0x0                                           // 00000000267C: BFC60000
	s_barrier_signal -1                                        // 000000002680: BE804EC1
	s_barrier_wait 0xffff                                      // 000000002684: BF94FFFF
	s_cbranch_scc1 65371                                       // 000000002688: BFA2FF5B <tessera_rocm_folded_matmul_a870cecb1991940b+0x8f8>
	s_load_b64 s[12:13], s[0:1], 0x58                          // 00000000268C: F4002300 F8000058
	v_or_b32_e32 v74, s6, v72                                  // 000000002694: 38949006
	v_or3_b32 v79, s15, 0, 0                                   // 000000002698: D658004F 0201000F
	v_or3_b32 v78, s14, v78, v81                               // 0000000026A0: D658004E 05469C0E
	v_mov_b32_e32 v65, s7                                      // 0000000026A8: 7E820207
	s_mov_b32 s5, 0                                            // 0000000026AC: BE850080
	v_or_b32_e32 v76, v74, v73                                 // 0000000026B0: 3898934A
	v_mov_b32_e32 v77, s7                                      // 0000000026B4: 7E9A0207
	v_cmp_gt_u64_e64 s3, s[10:11], v[78:79]                    // 0000000026B8: D45C0003 02029C0A
	v_mov_b32_e32 v75, s7                                      // 0000000026C0: 7E960207
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000026C4: BF870094
	v_or_b32_e32 v64, 7, v76                                   // 0000000026C8: 38809887
	v_cmp_gt_u64_e32 vcc_lo, s[8:9], v[64:65]                  // 0000000026CC: 7CB88008
	s_wait_kmcnt 0x0                                           // 0000000026D0: BFC70000
	s_and_b32 s4, s12, 15                                      // 0000000026D4: 8B048F0C
	s_and_b32 s2, s3, vcc_lo                                   // 0000000026D8: 8B026A03
	s_wait_alu depctr_sa_sdst(0)                               // 0000000026DC: BF88FF9E
	s_cmp_eq_u64 s[4:5], 0                                     // 0000000026E0: BF108004
	s_cselect_b32 s22, -1, 0                                   // 0000000026E4: 981680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000026E8: BF870009
	s_and_b32 s2, s22, s2                                      // 0000000026EC: 8B020216
	s_wait_alu depctr_sa_sdst(0)                               // 0000000026F0: BF88FF9E
	s_xor_b32 s2, s2, -1                                       // 0000000026F4: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 0000000026F8: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 0000000026FC: BE842002
	s_wait_alu depctr_sa_sdst(0)                               // 000000002700: BF88FF9E
	s_xor_b32 s5, exec_lo, s4                                  // 000000002704: 8D05047E
	s_cbranch_execz 138                                        // 000000002708: BFA5008A <tessera_rocm_folded_matmul_a870cecb1991940b+0xe34>
	v_cmp_gt_i64_e64 s2, s[8:9], v[76:77]                      // 00000000270C: D4540002 02029808
	v_or_b32_e32 v66, 1, v76                                   // 000000002714: 38849881
	v_mov_b32_e32 v67, v77                                     // 000000002718: 7E86034D
	v_or_b32_e32 v69, 2, v76                                   // 00000000271C: 388A9882
	v_mov_b32_e32 v70, v77                                     // 000000002720: 7E8C034D
	v_or_b32_e32 v83, 3, v76                                   // 000000002724: 38A69883
	s_wait_alu depctr_va_sdst(0)                               // 000000002728: BF88F19F
	v_cndmask_b32_e64 v68, 0, v77, s2                          // 00000000272C: D5010044 000A9A80
	v_cmp_gt_i64_e64 s4, s[8:9], v[66:67]                      // 000000002734: D4540004 02028408
	v_cndmask_b32_e64 v67, 0, v76, s2                          // 00000000273C: D5010043 000A9880
	v_cmp_gt_i64_e64 s2, s[8:9], v[69:70]                      // 000000002744: D4540002 02028A08
	v_mov_b32_e32 v84, v77                                     // 00000000274C: 7EA8034D
	v_or_b32_e32 v85, 5, v76                                   // 000000002750: 38AA9885
	v_mov_b32_e32 v86, v77                                     // 000000002754: 7EAC034D
	s_wait_alu depctr_va_sdst(0)                               // 000000002758: BF88F19F
	v_cndmask_b32_e64 v81, 0, v66, s4                          // 00000000275C: D5010051 00128480
	v_lshlrev_b64_e32 v[66:67], 2, v[67:68]                    // 000000002764: 3E848682
	v_cndmask_b32_e64 v68, 0, v69, s2                          // 000000002768: D5010044 000A8A80
	v_cndmask_b32_e64 v69, 0, v77, s2                          // 000000002770: D5010045 000A9A80
	v_cndmask_b32_e64 v82, 0, v77, s4                          // 000000002778: D5010052 00129A80
	v_cmp_gt_i64_e64 s2, s[8:9], v[83:84]                      // 000000002780: D4540002 0202A608
	v_add_co_u32 v66, s4, s12, v66                             // 000000002788: D7000442 0202840C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000002790: BF870214
	v_lshlrev_b64_e32 v[68:69], 2, v[68:69]                    // 000000002794: 3E888882
	v_lshlrev_b64_e32 v[70:71], 2, v[81:82]                    // 000000002798: 3E8CA282
	s_wait_alu depctr_va_sdst(0)                               // 00000000279C: BF88F19F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000027A0: BF870004
	v_cndmask_b32_e64 v81, 0, v83, s2                          // 0000000027A4: D5010051 000AA680
	v_or_b32_e32 v83, 4, v76                                   // 0000000027AC: 38A69884
	v_cndmask_b32_e64 v82, 0, v77, s2                          // 0000000027B0: D5010052 000A9A80
	v_add_co_ci_u32_e64 v67, null, s13, v67, s4                // 0000000027B8: D5207C43 0012860D
	v_add_co_u32 v87, s2, s12, v68                             // 0000000027C0: D7000257 0202880C
	v_add_co_u32 v70, s4, s12, v70                             // 0000000027C8: D7000446 02028C0C
	s_wait_alu depctr_va_sdst(0)                               // 0000000027D0: BF88F19F
	v_add_co_ci_u32_e64 v88, null, s13, v69, s2                // 0000000027D4: D5207C58 000A8A0D
	v_cmp_gt_i64_e64 s2, s[8:9], v[83:84]                      // 0000000027DC: D4540002 0202A608
	v_add_co_ci_u32_e64 v71, null, s13, v71, s4                // 0000000027E4: D5207C47 00128E0D
	v_lshlrev_b64_e32 v[68:69], 2, v[81:82]                    // 0000000027EC: 3E88A282
	v_cmp_gt_i64_e64 s4, s[8:9], v[85:86]                      // 0000000027F0: D4540004 0202AA08
	v_or_b32_e32 v81, 6, v76                                   // 0000000027F8: 38A29886
	v_mov_b32_e32 v82, v77                                     // 0000000027FC: 7EA4034D
	s_wait_alu depctr_va_sdst(0)                               // 000000002800: BF88F19F
	v_cndmask_b32_e64 v83, 0, v83, s2                          // 000000002804: D5010053 000AA680
	v_cndmask_b32_e64 v84, 0, v77, s2                          // 00000000280C: D5010054 000A9A80
	v_cndmask_b32_e64 v85, 0, v85, s4                          // 000000002814: D5010055 0012AA80
	v_cmp_gt_i64_e64 s2, s[8:9], v[81:82]                      // 00000000281C: D4540002 0202A208
	v_cndmask_b32_e64 v86, 0, v77, s4                          // 000000002824: D5010056 00129A80
	v_add_co_u32 v89, s4, s12, v68                             // 00000000282C: D7000459 0202880C
	s_wait_alu depctr_va_sdst(0)                               // 000000002834: BF88F19F
	v_add_co_ci_u32_e64 v90, null, s13, v69, s4                // 000000002838: D5207C5A 00128A0D
	v_lshlrev_b64_e32 v[68:69], 2, v[83:84]                    // 000000002840: 3E88A682
	v_lshlrev_b64_e32 v[82:83], 2, v[85:86]                    // 000000002844: 3EA4AA82
	v_cndmask_b32_e64 v84, 0, v81, s2                          // 000000002848: D5010054 000AA280
	v_cndmask_b32_e64 v85, 0, v77, s2                          // 000000002850: D5010055 000A9A80
	v_cmp_gt_i64_e64 s2, s[8:9], v[64:65]                      // 000000002858: D4540002 02028008
	v_add_co_u32 v91, s4, s12, v68                             // 000000002860: D700045B 0202880C
	s_wait_alu depctr_va_sdst(0)                               // 000000002868: BF88F19F
	v_add_co_ci_u32_e64 v92, null, s13, v69, s4                // 00000000286C: D5207C5C 00128A0D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000002874: BF870003
	v_cndmask_b32_e64 v65, 0, v65, s2                          // 000000002878: D5010041 000A8280
	v_cndmask_b32_e64 v64, 0, v64, s2                          // 000000002880: D5010040 000A8080
	v_lshlrev_b64_e32 v[68:69], 2, v[84:85]                    // 000000002888: 3E88A882
	v_add_co_u32 v81, s2, s12, v82                             // 00000000288C: D7000251 0202A40C
	s_wait_alu depctr_va_sdst(0)                               // 000000002894: BF88F19F
	v_add_co_ci_u32_e64 v82, null, s13, v83, s2                // 000000002898: D5207C52 000AA60D
	v_lshlrev_b64_e32 v[64:65], 2, v[64:65]                    // 0000000028A0: 3E808082
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000028A4: BF8701B4
	v_add_co_u32 v83, s2, s12, v68                             // 0000000028A8: D7000253 0202880C
	s_wait_alu depctr_va_sdst(0)                               // 0000000028B0: BF88F19F
	v_add_co_ci_u32_e64 v84, null, s13, v69, s2                // 0000000028B4: D5207C54 000A8A0D
	v_add_co_u32 v85, s2, s12, v64                             // 0000000028BC: D7000255 0202800C
	s_wait_alu depctr_va_sdst(0)                               // 0000000028C4: BF88F19F
	v_add_co_ci_u32_e64 v86, null, s13, v65, s2                // 0000000028C8: D5207C56 000A820D
	s_clause 0x7                                               // 0000000028D0: BF850007
	global_load_b32 v68, v[66:67], off                         // 0000000028D4: EE05007C 00000044 00000042
	global_load_b32 v69, v[70:71], off                         // 0000000028E0: EE05007C 00000045 00000046
	global_load_b32 v70, v[87:88], off                         // 0000000028EC: EE05007C 00000046 00000057
	global_load_b32 v71, v[89:90], off                         // 0000000028F8: EE05007C 00000047 00000059
	global_load_b32 v64, v[91:92], off                         // 000000002904: EE05007C 00000040 0000005B
	global_load_b32 v65, v[81:82], off                         // 000000002910: EE05007C 00000041 00000051
	global_load_b32 v66, v[83:84], off                         // 00000000291C: EE05007C 00000042 00000053
	global_load_b32 v67, v[85:86], off                         // 000000002928: EE05007C 00000043 00000055
	s_wait_alu depctr_sa_sdst(0)                               // 000000002934: BF88FF9E
	s_or_saveexec_b32 s4, s5                                   // 000000002938: BE842205
	v_lshlrev_b64_e32 v[114:115], 2, v[76:77]                  // 00000000293C: 3EE49882
	s_wait_alu depctr_sa_sdst(0)                               // 000000002940: BF88FF9E
	s_xor_b32 exec_lo, exec_lo, s4                             // 000000002944: 8D7E047E
	s_cbranch_execz 15                                         // 000000002948: BFA5000F <tessera_rocm_folded_matmul_a870cecb1991940b+0xe88>
	s_wait_loadcnt 0x3                                         // 00000000294C: BFC00003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002950: BF870001
	v_add_co_u32 v64, s2, s12, v114                            // 000000002954: D7000240 0202E40C
	s_wait_loadcnt 0x2                                         // 00000000295C: BFC00002
	s_wait_alu depctr_va_sdst(0)                               // 000000002960: BF88F19F
	v_add_co_ci_u32_e64 v65, null, s13, v115, s2               // 000000002964: D5207C41 000AE60D
	global_load_b128 v[68:71], v[64:65], off                   // 00000000296C: EE05C07C 00000044 00000040
	s_wait_loadcnt 0x1                                         // 000000002978: BFC00001
	global_load_b128 v[64:67], v[64:65], off offset:16         // 00000000297C: EE05C07C 00000040 00001040
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002988: 8C7E047E
	s_load_b64 s[16:17], s[0:1], 0x80                          // 00000000298C: F4002400 F8000080
	v_cmp_gt_i64_e64 s2, s[10:11], v[78:79]                    // 000000002994: D4540002 02029C0A
	s_wait_alu depctr_va_sdst(0)                               // 00000000299C: BF88F19F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000029A0: BF870131
	v_cndmask_b32_e64 v82, 0, v78, s2                          // 0000000029A4: D5010052 000A9C80
	v_cndmask_b32_e64 v81, 0, v79, s2                          // 0000000029AC: D5010051 000A9E80
	s_wait_kmcnt 0x0                                           // 0000000029B4: BFC70000
	v_add_co_u32 v152, s2, s16, v82                            // 0000000029B8: D7000298 0202A410
	s_wait_alu depctr_va_sdst(0)                               // 0000000029C0: BF88F19F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000029C4: BF8700C2
	v_add_co_ci_u32_e64 v153, null, s17, v81, s2               // 0000000029C8: D5207C99 000AA211
	global_load_u8 v81, v[152:153], off                        // 0000000029D0: EE04007C 00000051 00000098
	s_wait_loadcnt 0x0                                         // 0000000029DC: BFC00000
	v_lshlrev_b32_e32 v82, 23, v81                             // 0000000029E0: 30A4A297
	v_mul_f32_e32 v81, v68, v82                                // 0000000029E4: 10A2A544
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000029E8: BF870001
	v_cmp_class_f32_e64 s2, v81, 0x198                         // 0000000029EC: D47E0002 0201FF51 00000198
	v_mul_f32_e32 v81, v56, v81                                // 0000000029F8: 10A2A338
	s_xor_b32 s2, s2, -1                                       // 0000000029FC: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A00: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002A04: BE842002
	s_cbranch_execnz 3327                                      // 000000002A08: BFA60CFF <tessera_rocm_folded_matmul_a870cecb1991940b+0x4308>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A0C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002A10: 8C7E047E
	v_mul_f32_e32 v56, v69, v82                                // 000000002A14: 1070A545
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002A18: BF870001
	v_cmp_class_f32_e64 s2, v56, 0x198                         // 000000002A1C: D47E0002 0201FF38 00000198
	v_mul_f32_e32 v56, v57, v56                                // 000000002A28: 10707139
	s_xor_b32 s2, s2, -1                                       // 000000002A2C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A30: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002A34: BE842002
	s_cbranch_execnz 3333                                      // 000000002A38: BFA60D05 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4350>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A3C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002A40: 8C7E047E
	v_mul_f32_e32 v57, v70, v82                                // 000000002A44: 1072A546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002A48: BF870001
	v_cmp_class_f32_e64 s2, v57, 0x198                         // 000000002A4C: D47E0002 0201FF39 00000198
	v_mul_f32_e32 v57, v58, v57                                // 000000002A58: 1072733A
	s_xor_b32 s2, s2, -1                                       // 000000002A5C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A60: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002A64: BE842002
	s_cbranch_execnz 3339                                      // 000000002A68: BFA60D0B <tessera_rocm_folded_matmul_a870cecb1991940b+0x4398>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A6C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002A70: 8C7E047E
	v_mul_f32_e32 v58, v71, v82                                // 000000002A74: 1074A547
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002A78: BF870001
	v_cmp_class_f32_e64 s2, v58, 0x198                         // 000000002A7C: D47E0002 0201FF3A 00000198
	v_mul_f32_e32 v58, v59, v58                                // 000000002A88: 1074753B
	s_xor_b32 s2, s2, -1                                       // 000000002A8C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A90: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002A94: BE842002
	s_cbranch_execnz 3345                                      // 000000002A98: BFA60D11 <tessera_rocm_folded_matmul_a870cecb1991940b+0x43e0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002A9C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002AA0: 8C7E047E
	v_mul_f32_e32 v59, v64, v82                                // 000000002AA4: 1076A540
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002AA8: BF870001
	v_cmp_class_f32_e64 s2, v59, 0x198                         // 000000002AAC: D47E0002 0201FF3B 00000198
	v_mul_f32_e32 v59, v60, v59                                // 000000002AB8: 1076773C
	s_xor_b32 s2, s2, -1                                       // 000000002ABC: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002AC0: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002AC4: BE842002
	s_cbranch_execnz 3351                                      // 000000002AC8: BFA60D17 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4428>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002ACC: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002AD0: 8C7E047E
	v_mul_f32_e32 v60, v65, v82                                // 000000002AD4: 1078A541
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002AD8: BF870001
	v_cmp_class_f32_e64 s2, v60, 0x198                         // 000000002ADC: D47E0002 0201FF3C 00000198
	v_mul_f32_e32 v68, v61, v60                                // 000000002AE8: 1088793D
	s_xor_b32 s2, s2, -1                                       // 000000002AEC: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002AF0: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002AF4: BE842002
	s_cbranch_execnz 3357                                      // 000000002AF8: BFA60D1D <tessera_rocm_folded_matmul_a870cecb1991940b+0x4470>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002AFC: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002B00: 8C7E047E
	v_mul_f32_e32 v60, v66, v82                                // 000000002B04: 1078A542
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002B08: BF870001
	v_cmp_class_f32_e64 s2, v60, 0x198                         // 000000002B0C: D47E0002 0201FF3C 00000198
	v_mul_f32_e32 v61, v62, v60                                // 000000002B18: 107A793E
	s_xor_b32 s2, s2, -1                                       // 000000002B1C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002B20: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002B24: BE842002
	s_cbranch_execnz 3363                                      // 000000002B28: BFA60D23 <tessera_rocm_folded_matmul_a870cecb1991940b+0x44b8>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002B2C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002B30: 8C7E047E
	v_mul_f32_e32 v60, v67, v82                                // 000000002B34: 1078A543
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002B38: BF870001
	v_cmp_class_f32_e64 s2, v60, 0x198                         // 000000002B3C: D47E0002 0201FF3C 00000198
	v_mul_f32_e32 v60, v63, v60                                // 000000002B48: 1078793F
	s_xor_b32 s2, s2, -1                                       // 000000002B4C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000002B50: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000002B54: BE842002
	s_cbranch_execnz 3369                                      // 000000002B58: BFA60D29 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4500>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002B5C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000002B60: 8C7E047E
	s_load_b64 s[20:21], s[0:1], 0xa8                          // 000000002B64: F4002500 F80000A8
	v_mul_lo_u32 v64, v77, s10                                 // 000000002B6C: D72C0040 0200154D
	v_mul_lo_u32 v66, v76, s11                                 // 000000002B74: D72C0042 0200174C
	v_mad_co_u64_u32 v[62:63], null, v76, s10, 0               // 000000002B7C: D6FE7C3E 0200154C
	v_lshlrev_b64_e32 v[158:159], 1, v[78:79]                  // 000000002B84: 3F3C9C81
	v_or_b32_e32 v67, 0x400000, v81                            // 000000002B88: 3886A2FF 00400000
	v_bfe_u32 v69, v56, 16, 1                                  // 000000002B90: D6100045 02052138
	v_or_b32_e32 v70, 0x400000, v56                            // 000000002B98: 388C70FF 00400000
	s_lshl_b64 s[18:19], s[10:11], 1                           // 000000002BA0: 8492810A
	v_cmp_u_f32_e64 s1, v60, v60                               // 000000002BA4: D4180001 0202793C
	v_or_b32_e32 v163, 1, v73                                  // 000000002BAC: 39469281
	v_add3_u32 v63, v63, v66, v64                              // 000000002BB0: D655003F 0502853F
	v_bfe_u32 v66, v81, 16, 1                                  // 000000002BB8: D6100042 02052151
	v_add3_u32 v69, v69, v56, 0x7fff                           // 000000002BC0: D6550045 03FE7145 00007FFF
	v_or_b32_e32 v64, s6, v80                                  // 000000002BCC: 3880A006
	v_or_b32_e32 v162, 2, v73                                  // 000000002BD0: 39449282
	v_lshlrev_b64_e32 v[62:63], 1, v[62:63]                    // 000000002BD4: 3E7C7C81
	v_add3_u32 v66, v66, v81, 0x7fff                           // 000000002BD8: D6550042 03FEA342 00007FFF
	v_or_b32_e32 v165, 3, v73                                  // 000000002BE4: 394A9283
	v_or_b32_e32 v86, v64, v73                                 // 000000002BE8: 38AC9340
	v_or_b32_e32 v164, 4, v73                                  // 000000002BEC: 39489284
	v_or_b32_e32 v167, 5, v73                                  // 000000002BF0: 394E9285
	s_wait_kmcnt 0x0                                           // 000000002BF4: BFC70000
	v_add_co_u32 v62, s0, s20, v62                             // 000000002BF8: D700003E 02027C14
	s_delay_alu instid0(VALU_DEP_1)                            // 000000002C00: BF870001
	v_add_co_ci_u32_e64 v63, null, s21, v63, s0                // 000000002C04: D5207C3F 00027E15
	v_cmp_u_f32_e64 s0, v81, v81                               // 000000002C0C: D4180000 0202A351
	v_or_b32_e32 v166, 6, v73                                  // 000000002C14: 394C9286
	v_or_b32_e32 v168, 7, v73                                  // 000000002C18: 39509287
	v_mov_b32_e32 v65, s7                                      // 000000002C1C: 7E820207
	v_mov_b32_e32 v87, s7                                      // 000000002C20: 7EAE0207
	s_wait_alu depctr_va_sdst(0)                               // 000000002C24: BF88F19F
	v_cndmask_b32_e64 v66, v66, v67, s0                        // 000000002C28: D5010042 00028742
	v_add_co_u32 v78, s0, v62, v158                            // 000000002C30: D700004E 02033D3E
	s_wait_alu depctr_va_sdst(0)                               // 000000002C38: BF88F19F
	v_add_co_ci_u32_e64 v79, null, v63, v159, s0               // 000000002C3C: D5207C4F 00033F3F
	v_cmp_u_f32_e64 s0, v56, v56                               // 000000002C44: D4180000 02027138
	v_bfe_u32 v67, v57, 16, 1                                  // 000000002C4C: D6100043 02052139
	v_or_b32_e32 v92, v64, v163                                // 000000002C54: 38B94740
	global_store_d16_hi_b16 v[78:79], v66, off                 // 000000002C58: EE09407C 21000000 0000004E
	v_or_b32_e32 v88, v64, v162                                // 000000002C64: 38B14540
	s_wait_alu depctr_va_sdst(0)                               // 000000002C68: BF88F19F
	v_cndmask_b32_e64 v56, v69, v70, s0                        // 000000002C6C: D5010038 00028D45
	s_wait_alu depctr_sa_sdst(0)                               // 000000002C74: BF88FF9E
	v_add_co_u32 v62, s0, v62, s18                             // 000000002C78: D700003E 0200253E
	s_wait_alu depctr_va_sdst(0)                               // 000000002C80: BF88F19F
	v_add_co_ci_u32_e64 v63, null, s19, v63, s0                // 000000002C84: D5207C3F 00027E13
	v_add3_u32 v66, v67, v57, 0x7fff                           // 000000002C8C: D6550042 03FE7343 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000002C98: BF8701A3
	v_add_co_u32 v82, s0, v62, v158                            // 000000002C9C: D7000052 02033D3E
	s_wait_alu depctr_va_sdst(0)                               // 000000002CA4: BF88F19F
	v_add_co_ci_u32_e64 v83, null, v63, v159, s0               // 000000002CA8: D5207C53 00033F3F
	v_or_b32_e32 v67, 0x400000, v57                            // 000000002CB0: 388672FF 00400000
	v_cmp_u_f32_e64 s0, v57, v57                               // 000000002CB8: D4180000 02027339
	v_bfe_u32 v57, v58, 16, 1                                  // 000000002CC0: D6100039 0205213A
	global_store_d16_hi_b16 v[82:83], v56, off                 // 000000002CC8: EE09407C 1C000000 00000052
	v_or_b32_e32 v80, v64, v165                                // 000000002CD4: 38A14B40
	v_or_b32_e32 v70, v64, v164                                // 000000002CD8: 388D4940
	s_wait_alu depctr_va_sdst(0)                               // 000000002CDC: BF88F19F
	v_cndmask_b32_e64 v56, v66, v67, s0                        // 000000002CE0: D5010038 00028742
	v_add_co_u32 v62, s0, v62, s18                             // 000000002CE8: D700003E 0200253E
	s_wait_alu depctr_va_sdst(0)                               // 000000002CF0: BF88F19F
	v_add_co_ci_u32_e64 v63, null, s19, v63, s0                // 000000002CF4: D5207C3F 00027E13
	v_add3_u32 v57, v57, v58, 0x7fff                           // 000000002CFC: D6550039 03FE7539 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000002D08: BF870003
	v_add_co_u32 v84, s0, v62, v158                            // 000000002D0C: D7000054 02033D3E
	v_or_b32_e32 v66, 0x400000, v58                            // 000000002D14: 388474FF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000002D1C: BF88F19F
	v_add_co_ci_u32_e64 v85, null, v63, v159, s0               // 000000002D20: D5207C55 00033F3F
	v_cmp_u_f32_e64 s0, v58, v58                               // 000000002D28: D4180000 0202753A
	global_store_d16_hi_b16 v[84:85], v56, off                 // 000000002D30: EE09407C 1C000000 00000054
	s_wait_alu depctr_va_sdst(0)                               // 000000002D3C: BF88F19F
	v_cndmask_b32_e64 v57, v57, v66, s0                        // 000000002D40: D5010039 00028539
	v_add_co_u32 v58, s0, v62, s18                             // 000000002D48: D700003A 0200253E
	s_wait_alu depctr_va_sdst(0)                               // 000000002D50: BF88F19F
	v_add_co_ci_u32_e64 v62, null, s19, v63, s0                // 000000002D54: D5207C3E 00027E13
	v_bfe_u32 v63, v59, 16, 1                                  // 000000002D5C: D610003F 0205213B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000002D64: BF8701A3
	v_add_co_u32 v90, s0, v58, v158                            // 000000002D68: D700005A 02033D3A
	s_wait_alu depctr_va_sdst(0)                               // 000000002D70: BF88F19F
	v_add_co_ci_u32_e64 v91, null, v62, v159, s0               // 000000002D74: D5207C5B 00033F3E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000002D7C: BF870003
	v_add3_u32 v56, v63, v59, 0x7fff                           // 000000002D80: D6550038 03FE773F 00007FFF
	v_or_b32_e32 v63, 0x400000, v59                            // 000000002D8C: 387E76FF 00400000
	v_cmp_u_f32_e64 s0, v59, v59                               // 000000002D94: D4180000 0202773B
	global_store_d16_hi_b16 v[90:91], v57, off                 // 000000002D9C: EE09407C 1C800000 0000005A
	v_bfe_u32 v57, v68, 16, 1                                  // 000000002DA8: D6100039 02052144
	v_or_b32_e32 v66, v64, v166                                // 000000002DB0: 38854D40
	s_wait_alu depctr_va_sdst(0)                               // 000000002DB4: BF88F19F
	v_cndmask_b32_e64 v56, v56, v63, s0                        // 000000002DB8: D5010038 00027F38
	v_add_co_u32 v58, s0, v58, s18                             // 000000002DC0: D700003A 0200253A
	s_wait_alu depctr_va_sdst(0)                               // 000000002DC8: BF88F19F
	v_add_co_ci_u32_e64 v59, null, s19, v62, s0                // 000000002DCC: D5207C3B 00027C13
	v_add3_u32 v57, v57, v68, 0x7fff                           // 000000002DD4: D6550039 03FE8939 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000002DE0: BF870003
	v_add_co_u32 v96, s0, v58, v158                            // 000000002DE4: D7000060 02033D3A
	v_or_b32_e32 v62, 0x400000, v68                            // 000000002DEC: 387C88FF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000002DF4: BF88F19F
	v_add_co_ci_u32_e64 v97, null, v59, v159, s0               // 000000002DF8: D5207C61 00033F3B
	v_cmp_u_f32_e64 s0, v68, v68                               // 000000002E00: D4180000 02028944
	v_or_b32_e32 v63, 0x400000, v60                            // 000000002E08: 387E78FF 00400000
	v_or_b32_e32 v68, v64, v167                                // 000000002E10: 38894F40
	global_store_d16_hi_b16 v[96:97], v56, off                 // 000000002E14: EE09407C 1C000000 00000060
	v_or_b32_e32 v64, v64, v168                                // 000000002E20: 38815140
	s_wait_alu depctr_va_sdst(0)                               // 000000002E24: BF88F19F
	v_cndmask_b32_e64 v57, v57, v62, s0                        // 000000002E28: D5010039 00027D39
	v_add_co_u32 v58, s0, v58, s18                             // 000000002E30: D700003A 0200253A
	s_wait_alu depctr_va_sdst(0)                               // 000000002E38: BF88F19F
	v_add_co_ci_u32_e64 v59, null, s19, v59, s0                // 000000002E3C: D5207C3B 00027613
	v_bfe_u32 v62, v61, 16, 1                                  // 000000002E44: D610003E 0205213D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000002E4C: BF8701A3
	v_add_co_u32 v94, s0, v58, v158                            // 000000002E50: D700005E 02033D3A
	s_wait_alu depctr_va_sdst(0)                               // 000000002E58: BF88F19F
	v_add_co_ci_u32_e64 v95, null, v59, v159, s0               // 000000002E5C: D5207C5F 00033F3B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000002E64: BF870003
	v_add3_u32 v56, v62, v61, 0x7fff                           // 000000002E68: D6550038 03FE7B3E 00007FFF
	v_or_b32_e32 v62, 0x400000, v61                            // 000000002E74: 387C7AFF 00400000
	v_cmp_u_f32_e64 s0, v61, v61                               // 000000002E7C: D4180000 02027B3D
	global_store_d16_hi_b16 v[94:95], v57, off                 // 000000002E84: EE09407C 1C800000 0000005E
	v_mov_b32_e32 v57, s7                                      // 000000002E90: 7E720207
	s_wait_alu depctr_va_sdst(0)                               // 000000002E94: BF88F19F
	v_cndmask_b32_e64 v61, v56, v62, s0                        // 000000002E98: D501003D 00027D38
	v_bfe_u32 v56, v60, 16, 1                                  // 000000002EA0: D6100038 0205213C
	v_add_co_u32 v58, s0, v58, s18                             // 000000002EA8: D700003A 0200253A
	s_wait_alu depctr_va_sdst(0)                               // 000000002EB0: BF88F19F
	v_add_co_ci_u32_e64 v59, null, s19, v59, s0                // 000000002EB4: D5207C3B 00027613
	s_delay_alu instid0(VALU_DEP_3)                            // 000000002EBC: BF870003
	v_add3_u32 v62, v56, v60, 0x7fff                           // 000000002EC0: D655003E 03FE7938 00007FFF
	v_or_b32_e32 v56, 7, v86                                   // 000000002ECC: 3870AC87
	v_add_co_u32 v98, s0, v58, v158                            // 000000002ED0: D7000062 02033D3A
	s_wait_alu depctr_va_sdst(0)                               // 000000002ED8: BF88F19F
	v_add_co_ci_u32_e64 v99, null, v59, v159, s0               // 000000002EDC: D5207C63 00033F3B
	v_add_co_u32 v58, s0, v58, s18                             // 000000002EE4: D700003A 0200253A
	s_wait_alu depctr_va_sdst(0)                               // 000000002EEC: BF88F19F
	v_add_co_ci_u32_e64 v59, null, s19, v59, s0                // 000000002EF0: D5207C3B 00027613
	v_cmp_gt_u64_e64 s0, s[8:9], v[56:57]                      // 000000002EF8: D45C0000 02027008
	v_cndmask_b32_e64 v56, v62, v63, s1                        // 000000002F00: D5010038 00067F3E
	v_add_co_u32 v100, s1, v58, v158                           // 000000002F08: D7000164 02033D3A
	s_wait_alu depctr_va_sdst(0)                               // 000000002F10: BF88F19F
	v_add_co_ci_u32_e64 v101, null, v59, v159, s1              // 000000002F14: D5207C65 00073F3B
	s_and_b32 s1, s3, s0                                       // 000000002F1C: 8B010003
	global_store_d16_hi_b16 v[98:99], v61, off                 // 000000002F20: EE09407C 1E800000 00000062
	s_wait_alu depctr_sa_sdst(0)                               // 000000002F2C: BF88FF9E
	s_and_b32 s1, s22, s1                                      // 000000002F30: 8B010116
	global_store_d16_hi_b16 v[100:101], v56, off               // 000000002F34: EE09407C 1C000000 00000064
	s_wait_alu depctr_sa_sdst(0)                               // 000000002F40: BF88FF9E
	s_xor_b32 s1, s1, -1                                       // 000000002F44: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 000000002F48: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 000000002F4C: BE822001
	s_wait_alu depctr_sa_sdst(0)                               // 000000002F50: BF88FF9E
	s_xor_b32 s4, exec_lo, s2                                  // 000000002F54: 8D04027E
	s_cbranch_execz 133                                        // 000000002F58: BFA50085 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1670>
	v_mov_b32_e32 v93, v65                                     // 000000002F5C: 7EBA0341
	v_cmp_gt_i64_e64 s1, s[8:9], v[86:87]                      // 000000002F60: D4540001 0202AC08
	v_mov_b32_e32 v89, v65                                     // 000000002F68: 7EB20341
	v_mov_b32_e32 v81, v65                                     // 000000002F6C: 7EA20341
	v_mov_b32_e32 v71, v65                                     // 000000002F70: 7E8E0341
	v_cmp_gt_i64_e64 s2, s[8:9], v[92:93]                      // 000000002F74: D4540002 0202B808
	v_mov_b32_e32 v69, v65                                     // 000000002F7C: 7E8A0341
	s_wait_alu depctr_va_sdst(0)                               // 000000002F80: BF88F19F
	v_cndmask_b32_e64 v57, 0, v87, s1                          // 000000002F84: D5010039 0006AE80
	v_cndmask_b32_e64 v56, 0, v86, s1                          // 000000002F8C: D5010038 0006AC80
	v_cmp_gt_i64_e64 s1, s[8:9], v[88:89]                      // 000000002F94: D4540001 0202B008
	v_mov_b32_e32 v67, v65                                     // 000000002F9C: 7E860341
	v_cndmask_b32_e64 v59, 0, v65, s2                          // 000000002FA0: D501003B 000A8280
	v_cndmask_b32_e64 v58, 0, v92, s2                          // 000000002FA8: D501003A 000AB880
	v_lshlrev_b64_e32 v[56:57], 2, v[56:57]                    // 000000002FB0: 3E707082
	v_cmp_gt_i64_e64 s2, s[8:9], v[80:81]                      // 000000002FB4: D4540002 0202A008
	s_wait_alu depctr_va_sdst(0)                               // 000000002FBC: BF88F19F
	v_cndmask_b32_e64 v61, 0, v65, s1                          // 000000002FC0: D501003D 00068280
	v_cndmask_b32_e64 v60, 0, v88, s1                          // 000000002FC8: D501003C 0006B080
	v_lshlrev_b64_e32 v[58:59], 2, v[58:59]                    // 000000002FD0: 3E747482
	v_add_co_u32 v56, s1, s12, v56                             // 000000002FD4: D7000138 0202700C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000002FDC: BF870233
	v_lshlrev_b64_e32 v[60:61], 2, v[60:61]                    // 000000002FE0: 3E787882
	s_wait_alu depctr_va_sdst(0)                               // 000000002FE4: BF88F19F
	v_add_co_ci_u32_e64 v57, null, s13, v57, s1                // 000000002FE8: D5207C39 0006720D
	v_add_co_u32 v58, s1, s12, v58                             // 000000002FF0: D700013A 0202740C
	v_cndmask_b32_e64 v63, 0, v65, s2                          // 000000002FF8: D501003F 000A8280
	v_cndmask_b32_e64 v62, 0, v80, s2                          // 000000003000: D501003E 000AA080
	s_wait_alu depctr_va_sdst(0)                               // 000000003008: BF88F19F
	v_add_co_ci_u32_e64 v59, null, s13, v59, s1                // 00000000300C: D5207C3B 0006760D
	v_cmp_gt_i64_e64 s1, s[8:9], v[70:71]                      // 000000003014: D4540001 02028C08
	v_add_co_u32 v103, s2, s12, v60                            // 00000000301C: D7000267 0202780C
	s_wait_alu depctr_va_sdst(0)                               // 000000003024: BF88F19F
	v_add_co_ci_u32_e64 v104, null, s13, v61, s2               // 000000003028: D5207C68 000A7A0D
	v_cmp_gt_i64_e64 s2, s[8:9], v[68:69]                      // 000000003030: D4540002 02028808
	v_lshlrev_b64_e32 v[60:61], 2, v[62:63]                    // 000000003038: 3E787C82
	v_cndmask_b32_e64 v63, 0, v65, s1                          // 00000000303C: D501003F 00068280
	v_cndmask_b32_e64 v62, 0, v70, s1                          // 000000003044: D501003E 00068C80
	v_cmp_gt_i64_e64 s1, s[8:9], v[66:67]                      // 00000000304C: D4540001 02028408
	s_wait_alu depctr_va_sdst(0)                               // 000000003054: BF88F19F
	v_cndmask_b32_e64 v106, 0, v65, s2                         // 000000003058: D501006A 000A8280
	v_cndmask_b32_e64 v105, 0, v68, s2                         // 000000003060: D5010069 000A8880
	v_add_co_u32 v107, s2, s12, v60                            // 000000003068: D700026B 0202780C
	s_wait_alu depctr_va_sdst(0)                               // 000000003070: BF88F19F
	v_add_co_ci_u32_e64 v108, null, s13, v61, s2               // 000000003074: D5207C6C 000A7A0D
	v_lshlrev_b64_e32 v[60:61], 2, v[62:63]                    // 00000000307C: 3E787C82
	v_lshlrev_b64_e32 v[62:63], 2, v[105:106]                  // 000000003080: 3E7CD282
	v_cndmask_b32_e64 v106, 0, v65, s1                         // 000000003084: D501006A 00068280
	v_cndmask_b32_e64 v105, 0, v66, s1                         // 00000000308C: D5010069 00068480
	v_cmp_gt_i64_e64 s1, s[8:9], v[64:65]                      // 000000003094: D4540001 02028008
	v_add_co_u32 v109, s2, s12, v60                            // 00000000309C: D700026D 0202780C
	s_wait_alu depctr_va_sdst(0)                               // 0000000030A4: BF88F19F
	v_add_co_ci_u32_e64 v110, null, s13, v61, s2               // 0000000030A8: D5207C6E 000A7A0D
	v_lshlrev_b64_e32 v[60:61], 2, v[105:106]                  // 0000000030B0: 3E78D282
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000030B4: BF8701D4
	v_cndmask_b32_e64 v106, 0, v65, s1                         // 0000000030B8: D501006A 00068280
	v_cndmask_b32_e64 v105, 0, v64, s1                         // 0000000030C0: D5010069 00068080
	v_add_co_u32 v111, s1, s12, v62                            // 0000000030C8: D700016F 02027C0C
	s_wait_alu depctr_va_sdst(0)                               // 0000000030D0: BF88F19F
	v_add_co_ci_u32_e64 v112, null, s13, v63, s1               // 0000000030D4: D5207C70 00067E0D
	v_lshlrev_b64_e32 v[62:63], 2, v[105:106]                  // 0000000030DC: 3E7CD282
	v_add_co_u32 v105, s1, s12, v60                            // 0000000030E0: D7000169 0202780C
	s_wait_alu depctr_va_sdst(0)                               // 0000000030E8: BF88F19F
	v_add_co_ci_u32_e64 v106, null, s13, v61, s1               // 0000000030EC: D5207C6A 00067A0D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000030F4: BF870003
	v_add_co_u32 v116, s1, s12, v62                            // 0000000030F8: D7000174 02027C0C
	s_wait_alu depctr_va_sdst(0)                               // 000000003100: BF88F19F
	v_add_co_ci_u32_e64 v117, null, s13, v63, s1               // 000000003104: D5207C75 00067E0D
	s_clause 0x7                                               // 00000000310C: BF850007
	global_load_b32 v60, v[56:57], off                         // 000000003110: EE05007C 0000003C 00000038
	global_load_b32 v61, v[58:59], off                         // 00000000311C: EE05007C 0000003D 0000003A
	global_load_b32 v62, v[103:104], off                       // 000000003128: EE05007C 0000003E 00000067
	global_load_b32 v63, v[107:108], off                       // 000000003134: EE05007C 0000003F 0000006B
	global_load_b32 v56, v[109:110], off                       // 000000003140: EE05007C 00000038 0000006D
	global_load_b32 v57, v[111:112], off                       // 00000000314C: EE05007C 00000039 0000006F
	global_load_b32 v58, v[105:106], off                       // 000000003158: EE05007C 0000003A 00000069
	global_load_b32 v59, v[116:117], off                       // 000000003164: EE05007C 0000003B 00000074
	s_wait_alu depctr_sa_sdst(0)                               // 000000003170: BF88FF9E
	s_and_not1_saveexec_b32 s2, s4                             // 000000003174: BE823004
	s_cbranch_execz 28                                         // 000000003178: BFA5001C <tessera_rocm_folded_matmul_a870cecb1991940b+0x16ec>
	s_wait_loadcnt 0x3                                         // 00000000317C: BFC00003
	v_add_co_u32 v56, s1, s6, v72                              // 000000003180: D7000138 02029006
	s_wait_loadcnt 0x2                                         // 000000003188: BFC00002
	s_wait_alu depctr_va_sdst(0)                               // 00000000318C: BF88F19F
	v_add_co_ci_u32_e64 v57, null, s7, 0, s1                   // 000000003190: D5207C39 00050007
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000003198: BF870122
	v_add_co_u32 v56, s1, v56, v73                             // 00000000319C: D7000138 02029338
	s_wait_alu depctr_va_sdst(0)                               // 0000000031A4: BF88F19F
	v_add_co_ci_u32_e64 v57, null, 0, v57, s1                  // 0000000031A8: D5207C39 00067280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000031B0: BF870091
	v_lshlrev_b64_e32 v[56:57], 2, v[56:57]                    // 0000000031B4: 3E707082
	v_add_co_u32 v56, s1, s12, v56                             // 0000000031B8: D7000138 0202700C
	s_wait_alu depctr_va_sdst(0)                               // 0000000031C0: BF88F19F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000031C4: BF870002
	v_add_co_ci_u32_e64 v57, null, s13, v57, s1                // 0000000031C8: D5207C39 0006720D
	global_load_b128 v[60:63], v[56:57], off offset:64         // 0000000031D0: EE05C07C 0000003C 00004038
	s_wait_loadcnt 0x1                                         // 0000000031DC: BFC00001
	global_load_b128 v[56:59], v[56:57], off offset:80         // 0000000031E0: EE05C07C 00000038 00005038
	s_wait_alu depctr_sa_sdst(0)                               // 0000000031EC: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000031F0: 8C7E027E
	global_load_u8 v67, v[152:153], off                        // 0000000031F4: EE04007C 00000043 00000098
	s_wait_loadcnt 0x0                                         // 000000003200: BFC00000
	v_lshlrev_b32_e32 v69, 23, v67                             // 000000003204: 308A8697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000003208: BF870091
	v_mul_f32_e32 v67, v60, v69                                // 00000000320C: 10868B3C
	v_cmp_class_f32_e64 s1, v67, 0x198                         // 000000003210: D47E0001 0201FF43 00000198
	v_mul_f32_e32 v67, v48, v67                                // 00000000321C: 10868730
	s_xor_b32 s1, s1, -1                                       // 000000003220: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 000000003224: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 000000003228: BE822001
	s_cbranch_execnz 2950                                      // 00000000322C: BFA60B86 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4548>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003230: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 000000003234: 8C7E027E
	v_mul_f32_e32 v48, v61, v69                                // 000000003238: 10608B3D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000323C: BF870001
	v_cmp_class_f32_e64 s1, v48, 0x198                         // 000000003240: D47E0001 0201FF30 00000198
	v_mul_f32_e32 v48, v49, v48                                // 00000000324C: 10606131
	s_xor_b32 s1, s1, -1                                       // 000000003250: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 000000003254: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 000000003258: BE822001
	s_cbranch_execnz 2956                                      // 00000000325C: BFA60B8C <tessera_rocm_folded_matmul_a870cecb1991940b+0x4590>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003260: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 000000003264: 8C7E027E
	v_mul_f32_e32 v49, v62, v69                                // 000000003268: 10628B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000326C: BF870001
	v_cmp_class_f32_e64 s1, v49, 0x198                         // 000000003270: D47E0001 0201FF31 00000198
	v_mul_f32_e32 v49, v50, v49                                // 00000000327C: 10626332
	s_xor_b32 s1, s1, -1                                       // 000000003280: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 000000003284: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 000000003288: BE822001
	s_cbranch_execnz 2962                                      // 00000000328C: BFA60B92 <tessera_rocm_folded_matmul_a870cecb1991940b+0x45d8>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003290: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 000000003294: 8C7E027E
	v_mul_f32_e32 v50, v63, v69                                // 000000003298: 10648B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000329C: BF870001
	v_cmp_class_f32_e64 s1, v50, 0x198                         // 0000000032A0: D47E0001 0201FF32 00000198
	v_mul_f32_e32 v50, v51, v50                                // 0000000032AC: 10646533
	s_xor_b32 s1, s1, -1                                       // 0000000032B0: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 0000000032B4: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 0000000032B8: BE822001
	s_cbranch_execnz 2968                                      // 0000000032BC: BFA60B98 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4620>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000032C0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000032C4: 8C7E027E
	v_mul_f32_e32 v51, v56, v69                                // 0000000032C8: 10668B38
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000032CC: BF870001
	v_cmp_class_f32_e64 s1, v51, 0x198                         // 0000000032D0: D47E0001 0201FF33 00000198
	v_mul_f32_e32 v51, v52, v51                                // 0000000032DC: 10666734
	s_xor_b32 s1, s1, -1                                       // 0000000032E0: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 0000000032E4: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 0000000032E8: BE822001
	s_cbranch_execnz 2974                                      // 0000000032EC: BFA60B9E <tessera_rocm_folded_matmul_a870cecb1991940b+0x4668>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000032F0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000032F4: 8C7E027E
	v_mul_f32_e32 v52, v57, v69                                // 0000000032F8: 10688B39
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000032FC: BF870001
	v_cmp_class_f32_e64 s1, v52, 0x198                         // 000000003300: D47E0001 0201FF34 00000198
	v_mul_f32_e32 v52, v53, v52                                // 00000000330C: 10686935
	s_xor_b32 s1, s1, -1                                       // 000000003310: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 000000003314: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 000000003318: BE822001
	s_cbranch_execnz 2980                                      // 00000000331C: BFA60BA4 <tessera_rocm_folded_matmul_a870cecb1991940b+0x46b0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003320: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 000000003324: 8C7E027E
	v_mul_f32_e32 v53, v58, v69                                // 000000003328: 106A8B3A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000332C: BF870001
	v_cmp_class_f32_e64 s1, v53, 0x198                         // 000000003330: D47E0001 0201FF35 00000198
	v_mul_f32_e32 v60, v54, v53                                // 00000000333C: 10786B36
	s_xor_b32 s1, s1, -1                                       // 000000003340: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 000000003344: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 000000003348: BE822001
	s_cbranch_execnz 2986                                      // 00000000334C: BFA60BAA <tessera_rocm_folded_matmul_a870cecb1991940b+0x46f8>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003350: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 000000003354: 8C7E027E
	v_mul_f32_e32 v53, v59, v69                                // 000000003358: 106A8B3B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000335C: BF870001
	v_cmp_class_f32_e64 s1, v53, 0x198                         // 000000003360: D47E0001 0201FF35 00000198
	v_mul_f32_e32 v53, v55, v53                                // 00000000336C: 106A6B37
	s_xor_b32 s1, s1, -1                                       // 000000003370: 8D01C101
	s_wait_alu depctr_sa_sdst(0)                               // 000000003374: BF88FF9E
	s_and_saveexec_b32 s2, s1                                  // 000000003378: BE822001
	s_cbranch_execnz 2992                                      // 00000000337C: BFA60BB0 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4740>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003380: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s2                              // 000000003384: 8C7E027E
	v_mul_lo_u32 v56, v87, s10                                 // 000000003388: D72C0038 02001557
	v_mul_lo_u32 v58, v86, s11                                 // 000000003390: D72C003A 02001756
	v_mad_co_u64_u32 v[54:55], null, v86, s10, 0               // 000000003398: D6FE7C36 02001556
	v_bfe_u32 v59, v67, 16, 1                                  // 0000000033A0: D610003B 02052143
	v_or_b32_e32 v61, 0x400000, v67                            // 0000000033A8: 387A86FF 00400000
	v_cmp_u_f32_e64 s1, v67, v67                               // 0000000033B0: D4180001 02028743
	v_or_b32_e32 v62, 0x400000, v48                            // 0000000033B8: 387C60FF 00400000
	v_cmp_u_f32_e64 s2, v53, v53                               // 0000000033C0: D4180002 02026B35
	v_add3_u32 v59, v59, v67, 0x7fff                           // 0000000033C8: D655003B 03FE873B 00007FFF
	v_mov_b32_e32 v57, s7                                      // 0000000033D4: 7E720207
	v_add3_u32 v55, v55, v58, v56                              // 0000000033D8: D6550037 04E27537
	v_bfe_u32 v58, v48, 16, 1                                  // 0000000033E0: D610003A 02052130
	v_or_b32_e32 v56, s6, v102                                 // 0000000033E8: 3870CC06
	s_wait_alu depctr_va_sdst(0)                               // 0000000033EC: BF88F19F
	v_cndmask_b32_e64 v59, v59, v61, s1                        // 0000000033F0: D501003B 00067B3B
	v_or_b32_e32 v61, 0x400000, v49                            // 0000000033F8: 387A62FF 00400000
	v_lshlrev_b64_e32 v[54:55], 1, v[54:55]                    // 000000003400: 3E6C6C81
	v_add3_u32 v58, v58, v48, 0x7fff                           // 000000003404: D655003A 03FE613A 00007FFF
	v_or_b32_e32 v106, v56, v73                                // 000000003410: 38D49338
	v_mov_b32_e32 v107, s7                                     // 000000003414: 7ED60207
	v_or_b32_e32 v116, v56, v163                               // 000000003418: 38E94738
	v_or_b32_e32 v108, v56, v162                               // 00000000341C: 38D94538
	v_add_co_u32 v54, s1, s20, v54                             // 000000003420: D7000136 02026C14
	s_wait_alu depctr_va_sdst(0)                               // 000000003428: BF88F19F
	v_add_co_ci_u32_e64 v55, null, s21, v55, s1                // 00000000342C: D5207C37 00066E15
	v_cmp_u_f32_e64 s1, v48, v48                               // 000000003434: D4180001 02026130
	v_or_b32_e32 v102, v56, v165                               // 00000000343C: 38CD4B38
	s_wait_alu depctr_va_sdst(0)                               // 000000003440: BF88F19F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000003444: BF870002
	v_cndmask_b32_e64 v48, v58, v62, s1                        // 000000003448: D5010030 00067D3A
	v_add_co_u32 v104, s1, v54, v158                           // 000000003450: D7000168 02033D36
	s_wait_alu depctr_va_sdst(0)                               // 000000003458: BF88F19F
	v_add_co_ci_u32_e64 v105, null, v55, v159, s1              // 00000000345C: D5207C69 00073F37
	v_add_co_u32 v54, s1, v54, s18                             // 000000003464: D7000136 02002536
	v_bfe_u32 v58, v49, 16, 1                                  // 00000000346C: D610003A 02052131
	s_wait_alu depctr_va_sdst(0)                               // 000000003474: BF88F19F
	v_add_co_ci_u32_e64 v55, null, s19, v55, s1                // 000000003478: D5207C37 00066E13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000003480: BF870193
	v_add_co_u32 v110, s1, v54, v158                           // 000000003484: D700016E 02033D36
	v_add3_u32 v58, v58, v49, 0x7fff                           // 00000000348C: D655003A 03FE633A 00007FFF
	s_wait_alu depctr_va_sdst(0)                               // 000000003498: BF88F19F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000000349C: BF870143
	v_add_co_ci_u32_e64 v111, null, v55, v159, s1              // 0000000034A0: D5207C6F 00073F37
	v_cmp_u_f32_e64 s1, v49, v49                               // 0000000034A8: D4180001 02026331
	v_or_b32_e32 v62, v56, v164                                // 0000000034B0: 387D4938
	s_wait_alu depctr_va_sdst(0)                               // 0000000034B4: BF88F19F
	v_cndmask_b32_e64 v49, v58, v61, s1                        // 0000000034B8: D5010031 00067B3A
	v_add_co_u32 v54, s1, v54, s18                             // 0000000034C0: D7000136 02002536
	s_wait_alu depctr_va_sdst(0)                               // 0000000034C8: BF88F19F
	v_add_co_ci_u32_e64 v55, null, s19, v55, s1                // 0000000034CC: D5207C37 00066E13
	v_bfe_u32 v58, v50, 16, 1                                  // 0000000034D4: D610003A 02052132
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000034DC: BF8701A3
	v_add_co_u32 v112, s1, v54, v158                           // 0000000034E0: D7000170 02033D36
	s_wait_alu depctr_va_sdst(0)                               // 0000000034E8: BF88F19F
	v_add_co_ci_u32_e64 v113, null, v55, v159, s1              // 0000000034EC: D5207C71 00073F37
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000034F4: BF870003
	v_add3_u32 v58, v58, v50, 0x7fff                           // 0000000034F8: D655003A 03FE653A 00007FFF
	v_or_b32_e32 v61, 0x400000, v50                            // 000000003504: 387A64FF 00400000
	v_cmp_u_f32_e64 s1, v50, v50                               // 00000000350C: D4180001 02026532
	s_clause 0x2                                               // 000000003514: BF850002
	global_store_d16_hi_b16 v[104:105], v59, off               // 000000003518: EE09407C 1D800000 00000068
	global_store_d16_hi_b16 v[110:111], v48, off               // 000000003524: EE09407C 18000000 0000006E
	global_store_d16_hi_b16 v[112:113], v49, off               // 000000003530: EE09407C 18800000 00000070
	v_bfe_u32 v49, v51, 16, 1                                  // 00000000353C: D6100031 02052133
	s_wait_alu depctr_va_sdst(0)                               // 000000003544: BF88F19F
	v_cndmask_b32_e64 v48, v58, v61, s1                        // 000000003548: D5010030 00067B3A
	v_add_co_u32 v50, s1, v54, s18                             // 000000003550: D7000132 02002536
	s_wait_alu depctr_va_sdst(0)                               // 000000003558: BF88F19F
	v_add_co_ci_u32_e64 v54, null, s19, v55, s1                // 00000000355C: D5207C36 00066E13
	v_add3_u32 v49, v49, v51, 0x7fff                           // 000000003564: D6550031 03FE6731 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000003570: BF870003
	v_add_co_u32 v118, s1, v50, v158                           // 000000003574: D7000176 02033D32
	v_or_b32_e32 v55, 0x400000, v51                            // 00000000357C: 386E66FF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000003584: BF88F19F
	v_add_co_ci_u32_e64 v119, null, v54, v159, s1              // 000000003588: D5207C77 00073F36
	v_cmp_u_f32_e64 s1, v51, v51                               // 000000003590: D4180001 02026733
	v_bfe_u32 v51, v52, 16, 1                                  // 000000003598: D6100033 02052134
	v_or_b32_e32 v58, v56, v166                                // 0000000035A0: 38754D38
	s_wait_alu depctr_va_sdst(0)                               // 0000000035A4: BF88F19F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000035A8: BF8701D3
	v_cndmask_b32_e64 v49, v49, v55, s1                        // 0000000035AC: D5010031 00066F31
	v_add_co_u32 v50, s1, v50, s18                             // 0000000035B4: D7000132 02002532
	s_wait_alu depctr_va_sdst(0)                               // 0000000035BC: BF88F19F
	v_add_co_ci_u32_e64 v54, null, s19, v54, s1                // 0000000035C0: D5207C36 00066C13
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000035C8: D6550033 03FE6933 00007FFF
	v_add_co_u32 v122, s1, v50, v158                           // 0000000035D4: D700017A 02033D32
	v_or_b32_e32 v55, 0x400000, v52                            // 0000000035DC: 386E68FF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 0000000035E4: BF88F19F
	v_add_co_ci_u32_e64 v123, null, v54, v159, s1              // 0000000035E8: D5207C7B 00073F36
	v_cmp_u_f32_e64 s1, v52, v52                               // 0000000035F0: D4180001 02026934
	s_wait_alu depctr_va_sdst(0)                               // 0000000035F8: BF88F19F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000035FC: BF8701D1
	v_cndmask_b32_e64 v51, v51, v55, s1                        // 000000003600: D5010033 00066F33
	v_add_co_u32 v50, s1, v50, s18                             // 000000003608: D7000132 02002532
	s_wait_alu depctr_va_sdst(0)                               // 000000003610: BF88F19F
	v_add_co_ci_u32_e64 v52, null, s19, v54, s1                // 000000003614: D5207C34 00066C13
	v_bfe_u32 v54, v60, 16, 1                                  // 00000000361C: D6100036 0205213C
	v_add_co_u32 v120, s1, v50, v158                           // 000000003624: D7000178 02033D32
	s_wait_alu depctr_va_sdst(0)                               // 00000000362C: BF88F19F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000003630: BF870193
	v_add_co_ci_u32_e64 v121, null, v52, v159, s1              // 000000003634: D5207C79 00073F34
	v_add3_u32 v54, v54, v60, 0x7fff                           // 00000000363C: D6550036 03FE7936 00007FFF
	v_or_b32_e32 v55, 0x400000, v60                            // 000000003648: 386E78FF 00400000
	v_cmp_u_f32_e64 s1, v60, v60                               // 000000003650: D4180001 0202793C
	s_clause 0x2                                               // 000000003658: BF850002
	global_store_d16_hi_b16 v[118:119], v48, off               // 00000000365C: EE09407C 18000000 00000076
	global_store_d16_hi_b16 v[122:123], v49, off               // 000000003668: EE09407C 18800000 0000007A
	global_store_d16_hi_b16 v[120:121], v51, off               // 000000003674: EE09407C 19800000 00000078
	v_bfe_u32 v48, v53, 16, 1                                  // 000000003680: D6100030 02052135
	v_mov_b32_e32 v49, s7                                      // 000000003688: 7E620207
	v_or_b32_e32 v60, v56, v167                                // 00000000368C: 38794F38
	s_wait_alu depctr_va_sdst(0)                               // 000000003690: BF88F19F
	v_cndmask_b32_e64 v51, v54, v55, s1                        // 000000003694: D5010033 00066F36
	v_add_co_u32 v50, s1, v50, s18                             // 00000000369C: D7000132 02002532
	s_wait_alu depctr_va_sdst(0)                               // 0000000036A4: BF88F19F
	v_add_co_ci_u32_e64 v52, null, s19, v52, s1                // 0000000036A8: D5207C34 00066813
	v_add3_u32 v54, v48, v53, 0x7fff                           // 0000000036B0: D6550036 03FE6B30 00007FFF
	v_or_b32_e32 v48, 7, v106                                  // 0000000036BC: 3860D487
	v_add_co_u32 v124, s1, v50, v158                           // 0000000036C0: D700017C 02033D32
	s_wait_alu depctr_va_sdst(0)                               // 0000000036C8: BF88F19F
	v_add_co_ci_u32_e64 v125, null, v52, v159, s1              // 0000000036CC: D5207C7D 00073F34
	v_add_co_u32 v50, s1, v50, s18                             // 0000000036D4: D7000132 02002532
	v_or_b32_e32 v55, 0x400000, v53                            // 0000000036DC: 386E6AFF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 0000000036E4: BF88F19F
	v_add_co_ci_u32_e64 v52, null, s19, v52, s1                // 0000000036E8: D5207C34 00066813
	v_cmp_gt_u64_e64 s1, s[8:9], v[48:49]                      // 0000000036F0: D45C0001 02026008
	v_or_b32_e32 v56, v56, v168                                // 0000000036F8: 38715138
	v_cndmask_b32_e64 v48, v54, v55, s2                        // 0000000036FC: D5010030 000A6F36
	v_add_co_u32 v126, s2, v50, v158                           // 000000003704: D700027E 02033D32
	s_wait_alu depctr_va_sdst(0)                               // 00000000370C: BF88F19F
	v_add_co_ci_u32_e64 v127, null, v52, v159, s2              // 000000003710: D5207C7F 000B3F34
	s_and_b32 s2, s3, s1                                       // 000000003718: 8B020103
	global_store_d16_hi_b16 v[124:125], v51, off               // 00000000371C: EE09407C 19800000 0000007C
	s_wait_alu depctr_sa_sdst(0)                               // 000000003728: BF88FF9E
	s_and_b32 s2, s22, s2                                      // 00000000372C: 8B020216
	global_store_d16_hi_b16 v[126:127], v48, off               // 000000003730: EE09407C 18000000 0000007E
	s_wait_alu depctr_sa_sdst(0)                               // 00000000373C: BF88FF9E
	s_xor_b32 s2, s2, -1                                       // 000000003740: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003744: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003748: BE842002
	s_wait_alu depctr_sa_sdst(0)                               // 00000000374C: BF88FF9E
	s_xor_b32 s5, exec_lo, s4                                  // 000000003750: 8D05047E
	s_cbranch_execz 133                                        // 000000003754: BFA50085 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1e6c>
	v_mov_b32_e32 v117, v57                                    // 000000003758: 7EEA0339
	v_cmp_gt_i64_e64 s2, s[8:9], v[106:107]                    // 00000000375C: D4540002 0202D408
	v_mov_b32_e32 v109, v57                                    // 000000003764: 7EDA0339
	v_mov_b32_e32 v103, v57                                    // 000000003768: 7ECE0339
	v_mov_b32_e32 v63, v57                                     // 00000000376C: 7E7E0339
	v_cmp_gt_i64_e64 s4, s[8:9], v[116:117]                    // 000000003770: D4540004 0202E808
	v_mov_b32_e32 v61, v57                                     // 000000003778: 7E7A0339
	s_wait_alu depctr_va_sdst(0)                               // 00000000377C: BF88F19F
	v_cndmask_b32_e64 v49, 0, v107, s2                         // 000000003780: D5010031 000AD680
	v_cndmask_b32_e64 v48, 0, v106, s2                         // 000000003788: D5010030 000AD480
	v_cmp_gt_i64_e64 s2, s[8:9], v[108:109]                    // 000000003790: D4540002 0202D808
	v_mov_b32_e32 v59, v57                                     // 000000003798: 7E760339
	v_cndmask_b32_e64 v51, 0, v57, s4                          // 00000000379C: D5010033 00127280
	v_cndmask_b32_e64 v50, 0, v116, s4                         // 0000000037A4: D5010032 0012E880
	v_lshlrev_b64_e32 v[48:49], 2, v[48:49]                    // 0000000037AC: 3E606082
	v_cmp_gt_i64_e64 s4, s[8:9], v[102:103]                    // 0000000037B0: D4540004 0202CC08
	s_wait_alu depctr_va_sdst(0)                               // 0000000037B8: BF88F19F
	v_cndmask_b32_e64 v53, 0, v57, s2                          // 0000000037BC: D5010035 000A7280
	v_cndmask_b32_e64 v52, 0, v108, s2                         // 0000000037C4: D5010034 000AD880
	v_lshlrev_b64_e32 v[50:51], 2, v[50:51]                    // 0000000037CC: 3E646482
	v_add_co_u32 v48, s2, s12, v48                             // 0000000037D0: D7000230 0202600C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000037D8: BF870233
	v_lshlrev_b64_e32 v[52:53], 2, v[52:53]                    // 0000000037DC: 3E686882
	s_wait_alu depctr_va_sdst(0)                               // 0000000037E0: BF88F19F
	v_add_co_ci_u32_e64 v49, null, s13, v49, s2                // 0000000037E4: D5207C31 000A620D
	v_add_co_u32 v50, s2, s12, v50                             // 0000000037EC: D7000232 0202640C
	v_cndmask_b32_e64 v55, 0, v57, s4                          // 0000000037F4: D5010037 00127280
	v_cndmask_b32_e64 v54, 0, v102, s4                         // 0000000037FC: D5010036 0012CC80
	s_wait_alu depctr_va_sdst(0)                               // 000000003804: BF88F19F
	v_add_co_ci_u32_e64 v51, null, s13, v51, s2                // 000000003808: D5207C33 000A660D
	v_cmp_gt_i64_e64 s2, s[8:9], v[62:63]                      // 000000003810: D4540002 02027C08
	v_add_co_u32 v129, s4, s12, v52                            // 000000003818: D7000481 0202680C
	s_wait_alu depctr_va_sdst(0)                               // 000000003820: BF88F19F
	v_add_co_ci_u32_e64 v130, null, s13, v53, s4               // 000000003824: D5207C82 00126A0D
	v_cmp_gt_i64_e64 s4, s[8:9], v[60:61]                      // 00000000382C: D4540004 02027808
	v_lshlrev_b64_e32 v[52:53], 2, v[54:55]                    // 000000003834: 3E686C82
	v_cndmask_b32_e64 v55, 0, v57, s2                          // 000000003838: D5010037 000A7280
	v_cndmask_b32_e64 v54, 0, v62, s2                          // 000000003840: D5010036 000A7C80
	v_cmp_gt_i64_e64 s2, s[8:9], v[58:59]                      // 000000003848: D4540002 02027408
	s_wait_alu depctr_va_sdst(0)                               // 000000003850: BF88F19F
	v_cndmask_b32_e64 v132, 0, v57, s4                         // 000000003854: D5010084 00127280
	v_cndmask_b32_e64 v131, 0, v60, s4                         // 00000000385C: D5010083 00127880
	v_add_co_u32 v133, s4, s12, v52                            // 000000003864: D7000485 0202680C
	s_wait_alu depctr_va_sdst(0)                               // 00000000386C: BF88F19F
	v_add_co_ci_u32_e64 v134, null, s13, v53, s4               // 000000003870: D5207C86 00126A0D
	v_lshlrev_b64_e32 v[52:53], 2, v[54:55]                    // 000000003878: 3E686C82
	v_lshlrev_b64_e32 v[54:55], 2, v[131:132]                  // 00000000387C: 3E6D0682
	v_cndmask_b32_e64 v132, 0, v57, s2                         // 000000003880: D5010084 000A7280
	v_cndmask_b32_e64 v131, 0, v58, s2                         // 000000003888: D5010083 000A7480
	v_cmp_gt_i64_e64 s2, s[8:9], v[56:57]                      // 000000003890: D4540002 02027008
	v_add_co_u32 v135, s4, s12, v52                            // 000000003898: D7000487 0202680C
	s_wait_alu depctr_va_sdst(0)                               // 0000000038A0: BF88F19F
	v_add_co_ci_u32_e64 v136, null, s13, v53, s4               // 0000000038A4: D5207C88 00126A0D
	v_lshlrev_b64_e32 v[52:53], 2, v[131:132]                  // 0000000038AC: 3E690682
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000038B0: BF8701D4
	v_cndmask_b32_e64 v132, 0, v57, s2                         // 0000000038B4: D5010084 000A7280
	v_cndmask_b32_e64 v131, 0, v56, s2                         // 0000000038BC: D5010083 000A7080
	v_add_co_u32 v137, s2, s12, v54                            // 0000000038C4: D7000289 02026C0C
	s_wait_alu depctr_va_sdst(0)                               // 0000000038CC: BF88F19F
	v_add_co_ci_u32_e64 v138, null, s13, v55, s2               // 0000000038D0: D5207C8A 000A6E0D
	v_lshlrev_b64_e32 v[54:55], 2, v[131:132]                  // 0000000038D8: 3E6D0682
	v_add_co_u32 v131, s2, s12, v52                            // 0000000038DC: D7000283 0202680C
	s_wait_alu depctr_va_sdst(0)                               // 0000000038E4: BF88F19F
	v_add_co_ci_u32_e64 v132, null, s13, v53, s2               // 0000000038E8: D5207C84 000A6A0D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000038F0: BF870003
	v_add_co_u32 v139, s2, s12, v54                            // 0000000038F4: D700028B 02026C0C
	s_wait_alu depctr_va_sdst(0)                               // 0000000038FC: BF88F19F
	v_add_co_ci_u32_e64 v140, null, s13, v55, s2               // 000000003900: D5207C8C 000A6E0D
	s_clause 0x7                                               // 000000003908: BF850007
	global_load_b32 v52, v[48:49], off                         // 00000000390C: EE05007C 00000034 00000030
	global_load_b32 v53, v[50:51], off                         // 000000003918: EE05007C 00000035 00000032
	global_load_b32 v54, v[129:130], off                       // 000000003924: EE05007C 00000036 00000081
	global_load_b32 v55, v[133:134], off                       // 000000003930: EE05007C 00000037 00000085
	global_load_b32 v48, v[135:136], off                       // 00000000393C: EE05007C 00000030 00000087
	global_load_b32 v49, v[137:138], off                       // 000000003948: EE05007C 00000031 00000089
	global_load_b32 v50, v[131:132], off                       // 000000003954: EE05007C 00000032 00000083
	global_load_b32 v51, v[139:140], off                       // 000000003960: EE05007C 00000033 0000008B
	s_wait_alu depctr_sa_sdst(0)                               // 00000000396C: BF88FF9E
	s_and_not1_saveexec_b32 s4, s5                             // 000000003970: BE843005
	s_cbranch_execz 28                                         // 000000003974: BFA5001C <tessera_rocm_folded_matmul_a870cecb1991940b+0x1ee8>
	s_wait_loadcnt 0x3                                         // 000000003978: BFC00003
	v_add_co_u32 v48, s2, s6, v72                              // 00000000397C: D7000230 02029006
	s_wait_loadcnt 0x2                                         // 000000003984: BFC00002
	s_wait_alu depctr_va_sdst(0)                               // 000000003988: BF88F19F
	v_add_co_ci_u32_e64 v49, null, s7, 0, s2                   // 00000000398C: D5207C31 00090007
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000003994: BF870122
	v_add_co_u32 v48, s2, v48, v73                             // 000000003998: D7000230 02029330
	s_wait_alu depctr_va_sdst(0)                               // 0000000039A0: BF88F19F
	v_add_co_ci_u32_e64 v49, null, 0, v49, s2                  // 0000000039A4: D5207C31 000A6280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000039AC: BF870091
	v_lshlrev_b64_e32 v[48:49], 2, v[48:49]                    // 0000000039B0: 3E606082
	v_add_co_u32 v48, s2, s12, v48                             // 0000000039B4: D7000230 0202600C
	s_wait_alu depctr_va_sdst(0)                               // 0000000039BC: BF88F19F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000039C0: BF870002
	v_add_co_ci_u32_e64 v49, null, s13, v49, s2                // 0000000039C4: D5207C31 000A620D
	global_load_b128 v[52:55], v[48:49], off offset:128        // 0000000039CC: EE05C07C 00000034 00008030
	s_wait_loadcnt 0x1                                         // 0000000039D8: BFC00001
	global_load_b128 v[48:51], v[48:49], off offset:144        // 0000000039DC: EE05C07C 00000030 00009030
	s_wait_alu depctr_sa_sdst(0)                               // 0000000039E8: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000039EC: 8C7E047E
	global_load_u8 v59, v[152:153], off                        // 0000000039F0: EE04007C 0000003B 00000098
	s_wait_loadcnt 0x0                                         // 0000000039FC: BFC00000
	v_lshlrev_b32_e32 v61, 23, v59                             // 000000003A00: 307A7697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000003A04: BF870091
	v_mul_f32_e32 v59, v52, v61                                // 000000003A08: 10767B34
	v_cmp_class_f32_e64 s2, v59, 0x198                         // 000000003A0C: D47E0002 0201FF3B 00000198
	v_mul_f32_e32 v59, v40, v59                                // 000000003A18: 10767728
	s_xor_b32 s2, s2, -1                                       // 000000003A1C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003A20: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003A24: BE842002
	s_cbranch_execnz 2583                                      // 000000003A28: BFA60A17 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4788>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003A2C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003A30: 8C7E047E
	v_mul_f32_e32 v40, v53, v61                                // 000000003A34: 10507B35
	s_delay_alu instid0(VALU_DEP_1)                            // 000000003A38: BF870001
	v_cmp_class_f32_e64 s2, v40, 0x198                         // 000000003A3C: D47E0002 0201FF28 00000198
	v_mul_f32_e32 v40, v41, v40                                // 000000003A48: 10505129
	s_xor_b32 s2, s2, -1                                       // 000000003A4C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003A50: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003A54: BE842002
	s_cbranch_execnz 2589                                      // 000000003A58: BFA60A1D <tessera_rocm_folded_matmul_a870cecb1991940b+0x47d0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003A5C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003A60: 8C7E047E
	v_mul_f32_e32 v41, v54, v61                                // 000000003A64: 10527B36
	s_delay_alu instid0(VALU_DEP_1)                            // 000000003A68: BF870001
	v_cmp_class_f32_e64 s2, v41, 0x198                         // 000000003A6C: D47E0002 0201FF29 00000198
	v_mul_f32_e32 v41, v42, v41                                // 000000003A78: 1052532A
	s_xor_b32 s2, s2, -1                                       // 000000003A7C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003A80: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003A84: BE842002
	s_cbranch_execnz 2595                                      // 000000003A88: BFA60A23 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4818>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003A8C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003A90: 8C7E047E
	v_mul_f32_e32 v42, v55, v61                                // 000000003A94: 10547B37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000003A98: BF870001
	v_cmp_class_f32_e64 s2, v42, 0x198                         // 000000003A9C: D47E0002 0201FF2A 00000198
	v_mul_f32_e32 v42, v43, v42                                // 000000003AA8: 1054552B
	s_xor_b32 s2, s2, -1                                       // 000000003AAC: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003AB0: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003AB4: BE842002
	s_cbranch_execnz 2601                                      // 000000003AB8: BFA60A29 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4860>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003ABC: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003AC0: 8C7E047E
	v_mul_f32_e32 v43, v48, v61                                // 000000003AC4: 10567B30
	s_delay_alu instid0(VALU_DEP_1)                            // 000000003AC8: BF870001
	v_cmp_class_f32_e64 s2, v43, 0x198                         // 000000003ACC: D47E0002 0201FF2B 00000198
	v_mul_f32_e32 v43, v44, v43                                // 000000003AD8: 1056572C
	s_xor_b32 s2, s2, -1                                       // 000000003ADC: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003AE0: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003AE4: BE842002
	s_cbranch_execnz 2607                                      // 000000003AE8: BFA60A2F <tessera_rocm_folded_matmul_a870cecb1991940b+0x48a8>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003AEC: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003AF0: 8C7E047E
	v_mul_f32_e32 v44, v49, v61                                // 000000003AF4: 10587B31
	s_delay_alu instid0(VALU_DEP_1)                            // 000000003AF8: BF870001
	v_cmp_class_f32_e64 s2, v44, 0x198                         // 000000003AFC: D47E0002 0201FF2C 00000198
	v_mul_f32_e32 v44, v45, v44                                // 000000003B08: 1058592D
	s_xor_b32 s2, s2, -1                                       // 000000003B0C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003B10: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003B14: BE842002
	s_cbranch_execnz 2613                                      // 000000003B18: BFA60A35 <tessera_rocm_folded_matmul_a870cecb1991940b+0x48f0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003B1C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003B20: 8C7E047E
	v_mul_f32_e32 v45, v50, v61                                // 000000003B24: 105A7B32
	s_delay_alu instid0(VALU_DEP_1)                            // 000000003B28: BF870001
	v_cmp_class_f32_e64 s2, v45, 0x198                         // 000000003B2C: D47E0002 0201FF2D 00000198
	v_mul_f32_e32 v52, v46, v45                                // 000000003B38: 10685B2E
	s_xor_b32 s2, s2, -1                                       // 000000003B3C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003B40: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003B44: BE842002
	s_cbranch_execnz 2619                                      // 000000003B48: BFA60A3B <tessera_rocm_folded_matmul_a870cecb1991940b+0x4938>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003B4C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003B50: 8C7E047E
	v_mul_f32_e32 v45, v51, v61                                // 000000003B54: 105A7B33
	s_delay_alu instid0(VALU_DEP_1)                            // 000000003B58: BF870001
	v_cmp_class_f32_e64 s2, v45, 0x198                         // 000000003B5C: D47E0002 0201FF2D 00000198
	v_mul_f32_e32 v45, v47, v45                                // 000000003B68: 105A5B2F
	s_xor_b32 s2, s2, -1                                       // 000000003B6C: 8D02C102
	s_wait_alu depctr_sa_sdst(0)                               // 000000003B70: BF88FF9E
	s_and_saveexec_b32 s4, s2                                  // 000000003B74: BE842002
	s_cbranch_execnz 2625                                      // 000000003B78: BFA60A41 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4980>
	s_wait_alu depctr_sa_sdst(0)                               // 000000003B7C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000003B80: 8C7E047E
	v_mul_lo_u32 v48, v107, s10                                // 000000003B84: D72C0030 0200156B
	v_mul_lo_u32 v50, v106, s11                                // 000000003B8C: D72C0032 0200176A
	v_mad_co_u64_u32 v[46:47], null, v106, s10, 0              // 000000003B94: D6FE7C2E 0200156A
	v_bfe_u32 v51, v59, 16, 1                                  // 000000003B9C: D6100033 0205213B
	v_or_b32_e32 v53, 0x400000, v59                            // 000000003BA4: 386A76FF 00400000
	v_cmp_u_f32_e64 s2, v59, v59                               // 000000003BAC: D4180002 0202773B
	v_or_b32_e32 v54, 0x400000, v40                            // 000000003BB4: 386C50FF 00400000
	v_cmp_u_f32_e64 s4, v45, v45                               // 000000003BBC: D4180004 02025B2D
	v_add3_u32 v51, v51, v59, 0x7fff                           // 000000003BC4: D6550033 03FE7733 00007FFF
	v_mov_b32_e32 v49, s7                                      // 000000003BD0: 7E620207
	v_add3_u32 v47, v47, v50, v48                              // 000000003BD4: D655002F 04C2652F
	v_bfe_u32 v50, v40, 16, 1                                  // 000000003BDC: D6100032 02052128
	v_or_b32_e32 v48, s6, v128                                 // 000000003BE4: 38610006
	s_wait_alu depctr_va_sdst(0)                               // 000000003BE8: BF88F19F
	v_cndmask_b32_e64 v51, v51, v53, s2                        // 000000003BEC: D5010033 000A6B33
	v_or_b32_e32 v53, 0x400000, v41                            // 000000003BF4: 386A52FF 00400000
	v_lshlrev_b64_e32 v[46:47], 1, v[46:47]                    // 000000003BFC: 3E5C5C81
	v_add3_u32 v50, v50, v40, 0x7fff                           // 000000003C00: D6550032 03FE5132 00007FFF
	v_or_b32_e32 v132, v48, v73                                // 000000003C0C: 39089330
	v_mov_b32_e32 v133, s7                                     // 000000003C10: 7F0A0207
	v_or_b32_e32 v140, v48, v163                               // 000000003C14: 39194730
	v_or_b32_e32 v134, v48, v162                               // 000000003C18: 390D4530
	v_add_co_u32 v46, s2, s20, v46                             // 000000003C1C: D700022E 02025C14
	s_wait_alu depctr_va_sdst(0)                               // 000000003C24: BF88F19F
	v_add_co_ci_u32_e64 v47, null, s21, v47, s2                // 000000003C28: D5207C2F 000A5E15
	v_cmp_u_f32_e64 s2, v40, v40                               // 000000003C30: D4180002 02025128
	v_or_b32_e32 v128, v48, v165                               // 000000003C38: 39014B30
	s_wait_alu depctr_va_sdst(0)                               // 000000003C3C: BF88F19F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000003C40: BF870002
	v_cndmask_b32_e64 v40, v50, v54, s2                        // 000000003C44: D5010028 000A6D32
	v_add_co_u32 v130, s2, v46, v158                           // 000000003C4C: D7000282 02033D2E
	s_wait_alu depctr_va_sdst(0)                               // 000000003C54: BF88F19F
	v_add_co_ci_u32_e64 v131, null, v47, v159, s2              // 000000003C58: D5207C83 000B3F2F
	v_add_co_u32 v46, s2, v46, s18                             // 000000003C60: D700022E 0200252E
	v_bfe_u32 v50, v41, 16, 1                                  // 000000003C68: D6100032 02052129
	s_wait_alu depctr_va_sdst(0)                               // 000000003C70: BF88F19F
	v_add_co_ci_u32_e64 v47, null, s19, v47, s2                // 000000003C74: D5207C2F 000A5E13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000003C7C: BF870193
	v_add_co_u32 v136, s2, v46, v158                           // 000000003C80: D7000288 02033D2E
	v_add3_u32 v50, v50, v41, 0x7fff                           // 000000003C88: D6550032 03FE5332 00007FFF
	s_wait_alu depctr_va_sdst(0)                               // 000000003C94: BF88F19F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000003C98: BF870143
	v_add_co_ci_u32_e64 v137, null, v47, v159, s2              // 000000003C9C: D5207C89 000B3F2F
	v_cmp_u_f32_e64 s2, v41, v41                               // 000000003CA4: D4180002 02025329
	v_or_b32_e32 v54, v48, v164                                // 000000003CAC: 386D4930
	s_wait_alu depctr_va_sdst(0)                               // 000000003CB0: BF88F19F
	v_cndmask_b32_e64 v41, v50, v53, s2                        // 000000003CB4: D5010029 000A6B32
	v_add_co_u32 v46, s2, v46, s18                             // 000000003CBC: D700022E 0200252E
	s_wait_alu depctr_va_sdst(0)                               // 000000003CC4: BF88F19F
	v_add_co_ci_u32_e64 v47, null, s19, v47, s2                // 000000003CC8: D5207C2F 000A5E13
	v_bfe_u32 v50, v42, 16, 1                                  // 000000003CD0: D6100032 0205212A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000003CD8: BF8701A3
	v_add_co_u32 v138, s2, v46, v158                           // 000000003CDC: D700028A 02033D2E
	s_wait_alu depctr_va_sdst(0)                               // 000000003CE4: BF88F19F
	v_add_co_ci_u32_e64 v139, null, v47, v159, s2              // 000000003CE8: D5207C8B 000B3F2F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000003CF0: BF870003
	v_add3_u32 v50, v50, v42, 0x7fff                           // 000000003CF4: D6550032 03FE5532 00007FFF
	v_or_b32_e32 v53, 0x400000, v42                            // 000000003D00: 386A54FF 00400000
	v_cmp_u_f32_e64 s2, v42, v42                               // 000000003D08: D4180002 0202552A
	s_clause 0x2                                               // 000000003D10: BF850002
	global_store_d16_hi_b16 v[130:131], v51, off               // 000000003D14: EE09407C 19800000 00000082
	global_store_d16_hi_b16 v[136:137], v40, off               // 000000003D20: EE09407C 14000000 00000088
	global_store_d16_hi_b16 v[138:139], v41, off               // 000000003D2C: EE09407C 14800000 0000008A
	v_bfe_u32 v41, v43, 16, 1                                  // 000000003D38: D6100029 0205212B
	s_wait_alu depctr_va_sdst(0)                               // 000000003D40: BF88F19F
	v_cndmask_b32_e64 v40, v50, v53, s2                        // 000000003D44: D5010028 000A6B32
	v_add_co_u32 v42, s2, v46, s18                             // 000000003D4C: D700022A 0200252E
	s_wait_alu depctr_va_sdst(0)                               // 000000003D54: BF88F19F
	v_add_co_ci_u32_e64 v46, null, s19, v47, s2                // 000000003D58: D5207C2E 000A5E13
	v_add3_u32 v41, v41, v43, 0x7fff                           // 000000003D60: D6550029 03FE5729 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000003D6C: BF870003
	v_add_co_u32 v142, s2, v42, v158                           // 000000003D70: D700028E 02033D2A
	v_or_b32_e32 v47, 0x400000, v43                            // 000000003D78: 385E56FF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000003D80: BF88F19F
	v_add_co_ci_u32_e64 v143, null, v46, v159, s2              // 000000003D84: D5207C8F 000B3F2E
	v_cmp_u_f32_e64 s2, v43, v43                               // 000000003D8C: D4180002 0202572B
	v_bfe_u32 v43, v44, 16, 1                                  // 000000003D94: D610002B 0205212C
	v_or_b32_e32 v50, v48, v166                                // 000000003D9C: 38654D30
	s_wait_alu depctr_va_sdst(0)                               // 000000003DA0: BF88F19F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000003DA4: BF8701D3
	v_cndmask_b32_e64 v41, v41, v47, s2                        // 000000003DA8: D5010029 000A5F29
	v_add_co_u32 v42, s2, v42, s18                             // 000000003DB0: D700022A 0200252A
	s_wait_alu depctr_va_sdst(0)                               // 000000003DB8: BF88F19F
	v_add_co_ci_u32_e64 v46, null, s19, v46, s2                // 000000003DBC: D5207C2E 000A5C13
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000003DC4: D655002B 03FE592B 00007FFF
	v_add_co_u32 v146, s2, v42, v158                           // 000000003DD0: D7000292 02033D2A
	v_or_b32_e32 v47, 0x400000, v44                            // 000000003DD8: 385E58FF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000003DE0: BF88F19F
	v_add_co_ci_u32_e64 v147, null, v46, v159, s2              // 000000003DE4: D5207C93 000B3F2E
	v_cmp_u_f32_e64 s2, v44, v44                               // 000000003DEC: D4180002 0202592C
	s_wait_alu depctr_va_sdst(0)                               // 000000003DF4: BF88F19F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000003DF8: BF8701D1
	v_cndmask_b32_e64 v43, v43, v47, s2                        // 000000003DFC: D501002B 000A5F2B
	v_add_co_u32 v42, s2, v42, s18                             // 000000003E04: D700022A 0200252A
	s_wait_alu depctr_va_sdst(0)                               // 000000003E0C: BF88F19F
	v_add_co_ci_u32_e64 v44, null, s19, v46, s2                // 000000003E10: D5207C2C 000A5C13
	v_bfe_u32 v46, v52, 16, 1                                  // 000000003E18: D610002E 02052134
	v_add_co_u32 v144, s2, v42, v158                           // 000000003E20: D7000290 02033D2A
	s_wait_alu depctr_va_sdst(0)                               // 000000003E28: BF88F19F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000003E2C: BF870193
	v_add_co_ci_u32_e64 v145, null, v44, v159, s2              // 000000003E30: D5207C91 000B3F2C
	v_add3_u32 v46, v46, v52, 0x7fff                           // 000000003E38: D655002E 03FE692E 00007FFF
	v_or_b32_e32 v47, 0x400000, v52                            // 000000003E44: 385E68FF 00400000
	v_cmp_u_f32_e64 s2, v52, v52                               // 000000003E4C: D4180002 02026934
	s_clause 0x2                                               // 000000003E54: BF850002
	global_store_d16_hi_b16 v[142:143], v40, off               // 000000003E58: EE09407C 14000000 0000008E
	global_store_d16_hi_b16 v[146:147], v41, off               // 000000003E64: EE09407C 14800000 00000092
	global_store_d16_hi_b16 v[144:145], v43, off               // 000000003E70: EE09407C 15800000 00000090
	v_bfe_u32 v40, v45, 16, 1                                  // 000000003E7C: D6100028 0205212D
	v_mov_b32_e32 v41, s7                                      // 000000003E84: 7E520207
	v_or_b32_e32 v52, v48, v167                                // 000000003E88: 38694F30
	s_wait_alu depctr_va_sdst(0)                               // 000000003E8C: BF88F19F
	v_cndmask_b32_e64 v43, v46, v47, s2                        // 000000003E90: D501002B 000A5F2E
	v_add_co_u32 v42, s2, v42, s18                             // 000000003E98: D700022A 0200252A
	s_wait_alu depctr_va_sdst(0)                               // 000000003EA0: BF88F19F
	v_add_co_ci_u32_e64 v44, null, s19, v44, s2                // 000000003EA4: D5207C2C 000A5813
	v_add3_u32 v46, v40, v45, 0x7fff                           // 000000003EAC: D655002E 03FE5B28 00007FFF
	v_or_b32_e32 v40, 7, v132                                  // 000000003EB8: 38510887
	v_add_co_u32 v148, s2, v42, v158                           // 000000003EBC: D7000294 02033D2A
	s_wait_alu depctr_va_sdst(0)                               // 000000003EC4: BF88F19F
	v_add_co_ci_u32_e64 v149, null, v44, v159, s2              // 000000003EC8: D5207C95 000B3F2C
	v_add_co_u32 v42, s2, v42, s18                             // 000000003ED0: D700022A 0200252A
	v_or_b32_e32 v47, 0x400000, v45                            // 000000003ED8: 385E5AFF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000003EE0: BF88F19F
	v_add_co_ci_u32_e64 v44, null, s19, v44, s2                // 000000003EE4: D5207C2C 000A5813
	v_cmp_gt_u64_e64 s2, s[8:9], v[40:41]                      // 000000003EEC: D45C0002 02025008
	v_or_b32_e32 v48, v48, v168                                // 000000003EF4: 38615130
	v_cndmask_b32_e64 v40, v46, v47, s4                        // 000000003EF8: D5010028 00125F2E
	v_add_co_u32 v150, s4, v42, v158                           // 000000003F00: D7000496 02033D2A
	s_wait_alu depctr_va_sdst(0)                               // 000000003F08: BF88F19F
	v_add_co_ci_u32_e64 v151, null, v44, v159, s4              // 000000003F0C: D5207C97 00133F2C
	s_and_b32 s3, s3, s2                                       // 000000003F14: 8B030203
	global_store_d16_hi_b16 v[148:149], v43, off               // 000000003F18: EE09407C 15800000 00000094
	s_wait_alu depctr_sa_sdst(0)                               // 000000003F24: BF88FF9E
	s_and_b32 s3, s22, s3                                      // 000000003F28: 8B030316
	global_store_d16_hi_b16 v[150:151], v40, off               // 000000003F2C: EE09407C 14000000 00000096
	s_wait_alu depctr_sa_sdst(0)                               // 000000003F38: BF88FF9E
	s_xor_b32 s3, s3, -1                                       // 000000003F3C: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 000000003F40: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 000000003F44: BE842003
	s_wait_alu depctr_sa_sdst(0)                               // 000000003F48: BF88FF9E
	s_xor_b32 s5, exec_lo, s4                                  // 000000003F4C: 8D05047E
	s_cbranch_execz 133                                        // 000000003F50: BFA50085 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2668>
	v_mov_b32_e32 v141, v49                                    // 000000003F54: 7F1A0331
	v_cmp_gt_i64_e64 s3, s[8:9], v[132:133]                    // 000000003F58: D4540003 02030808
	v_mov_b32_e32 v135, v49                                    // 000000003F60: 7F0E0331
	v_mov_b32_e32 v129, v49                                    // 000000003F64: 7F020331
	v_mov_b32_e32 v55, v49                                     // 000000003F68: 7E6E0331
	v_cmp_gt_i64_e64 s4, s[8:9], v[140:141]                    // 000000003F6C: D4540004 02031808
	v_mov_b32_e32 v53, v49                                     // 000000003F74: 7E6A0331
	s_wait_alu depctr_va_sdst(0)                               // 000000003F78: BF88F19F
	v_cndmask_b32_e64 v41, 0, v133, s3                         // 000000003F7C: D5010029 000F0A80
	v_cndmask_b32_e64 v40, 0, v132, s3                         // 000000003F84: D5010028 000F0880
	v_cmp_gt_i64_e64 s3, s[8:9], v[134:135]                    // 000000003F8C: D4540003 02030C08
	v_mov_b32_e32 v51, v49                                     // 000000003F94: 7E660331
	v_cndmask_b32_e64 v43, 0, v49, s4                          // 000000003F98: D501002B 00126280
	v_cndmask_b32_e64 v42, 0, v140, s4                         // 000000003FA0: D501002A 00131880
	v_lshlrev_b64_e32 v[40:41], 2, v[40:41]                    // 000000003FA8: 3E505082
	v_cmp_gt_i64_e64 s4, s[8:9], v[128:129]                    // 000000003FAC: D4540004 02030008
	s_wait_alu depctr_va_sdst(0)                               // 000000003FB4: BF88F19F
	v_cndmask_b32_e64 v45, 0, v49, s3                          // 000000003FB8: D501002D 000E6280
	v_cndmask_b32_e64 v44, 0, v134, s3                         // 000000003FC0: D501002C 000F0C80
	v_lshlrev_b64_e32 v[42:43], 2, v[42:43]                    // 000000003FC8: 3E545482
	v_add_co_u32 v40, s3, s12, v40                             // 000000003FCC: D7000328 0202500C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000003FD4: BF870233
	v_lshlrev_b64_e32 v[44:45], 2, v[44:45]                    // 000000003FD8: 3E585882
	s_wait_alu depctr_va_sdst(0)                               // 000000003FDC: BF88F19F
	v_add_co_ci_u32_e64 v41, null, s13, v41, s3                // 000000003FE0: D5207C29 000E520D
	v_add_co_u32 v42, s3, s12, v42                             // 000000003FE8: D700032A 0202540C
	v_cndmask_b32_e64 v47, 0, v49, s4                          // 000000003FF0: D501002F 00126280
	v_cndmask_b32_e64 v46, 0, v128, s4                         // 000000003FF8: D501002E 00130080
	s_wait_alu depctr_va_sdst(0)                               // 000000004000: BF88F19F
	v_add_co_ci_u32_e64 v43, null, s13, v43, s3                // 000000004004: D5207C2B 000E560D
	v_cmp_gt_i64_e64 s3, s[8:9], v[54:55]                      // 00000000400C: D4540003 02026C08
	v_add_co_u32 v154, s4, s12, v44                            // 000000004014: D700049A 0202580C
	s_wait_alu depctr_va_sdst(0)                               // 00000000401C: BF88F19F
	v_add_co_ci_u32_e64 v155, null, s13, v45, s4               // 000000004020: D5207C9B 00125A0D
	v_cmp_gt_i64_e64 s4, s[8:9], v[52:53]                      // 000000004028: D4540004 02026808
	v_lshlrev_b64_e32 v[44:45], 2, v[46:47]                    // 000000004030: 3E585C82
	v_cndmask_b32_e64 v47, 0, v49, s3                          // 000000004034: D501002F 000E6280
	v_cndmask_b32_e64 v46, 0, v54, s3                          // 00000000403C: D501002E 000E6C80
	v_cmp_gt_i64_e64 s3, s[8:9], v[50:51]                      // 000000004044: D4540003 02026408
	s_wait_alu depctr_va_sdst(0)                               // 00000000404C: BF88F19F
	v_cndmask_b32_e64 v157, 0, v49, s4                         // 000000004050: D501009D 00126280
	v_cndmask_b32_e64 v156, 0, v52, s4                         // 000000004058: D501009C 00126880
	v_add_co_u32 v169, s4, s12, v44                            // 000000004060: D70004A9 0202580C
	s_wait_alu depctr_va_sdst(0)                               // 000000004068: BF88F19F
	v_add_co_ci_u32_e64 v170, null, s13, v45, s4               // 00000000406C: D5207CAA 00125A0D
	v_lshlrev_b64_e32 v[44:45], 2, v[46:47]                    // 000000004074: 3E585C82
	v_lshlrev_b64_e32 v[46:47], 2, v[156:157]                  // 000000004078: 3E5D3882
	v_cndmask_b32_e64 v157, 0, v49, s3                         // 00000000407C: D501009D 000E6280
	v_cndmask_b32_e64 v156, 0, v50, s3                         // 000000004084: D501009C 000E6480
	v_cmp_gt_i64_e64 s3, s[8:9], v[48:49]                      // 00000000408C: D4540003 02026008
	v_add_co_u32 v171, s4, s12, v44                            // 000000004094: D70004AB 0202580C
	s_wait_alu depctr_va_sdst(0)                               // 00000000409C: BF88F19F
	v_add_co_ci_u32_e64 v172, null, s13, v45, s4               // 0000000040A0: D5207CAC 00125A0D
	v_lshlrev_b64_e32 v[44:45], 2, v[156:157]                  // 0000000040A8: 3E593882
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000040AC: BF8701D4
	v_cndmask_b32_e64 v157, 0, v49, s3                         // 0000000040B0: D501009D 000E6280
	v_cndmask_b32_e64 v156, 0, v48, s3                         // 0000000040B8: D501009C 000E6080
	v_add_co_u32 v173, s3, s12, v46                            // 0000000040C0: D70003AD 02025C0C
	s_wait_alu depctr_va_sdst(0)                               // 0000000040C8: BF88F19F
	v_add_co_ci_u32_e64 v174, null, s13, v47, s3               // 0000000040CC: D5207CAE 000E5E0D
	v_lshlrev_b64_e32 v[46:47], 2, v[156:157]                  // 0000000040D4: 3E5D3882
	v_add_co_u32 v156, s3, s12, v44                            // 0000000040D8: D700039C 0202580C
	s_wait_alu depctr_va_sdst(0)                               // 0000000040E0: BF88F19F
	v_add_co_ci_u32_e64 v157, null, s13, v45, s3               // 0000000040E4: D5207C9D 000E5A0D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000040EC: BF870003
	v_add_co_u32 v175, s3, s12, v46                            // 0000000040F0: D70003AF 02025C0C
	s_wait_alu depctr_va_sdst(0)                               // 0000000040F8: BF88F19F
	v_add_co_ci_u32_e64 v176, null, s13, v47, s3               // 0000000040FC: D5207CB0 000E5E0D
	s_clause 0x7                                               // 000000004104: BF850007
	global_load_b32 v44, v[40:41], off                         // 000000004108: EE05007C 0000002C 00000028
	global_load_b32 v45, v[42:43], off                         // 000000004114: EE05007C 0000002D 0000002A
	global_load_b32 v46, v[154:155], off                       // 000000004120: EE05007C 0000002E 0000009A
	global_load_b32 v47, v[169:170], off                       // 00000000412C: EE05007C 0000002F 000000A9
	global_load_b32 v40, v[171:172], off                       // 000000004138: EE05007C 00000028 000000AB
	global_load_b32 v41, v[173:174], off                       // 000000004144: EE05007C 00000029 000000AD
	global_load_b32 v42, v[156:157], off                       // 000000004150: EE05007C 0000002A 0000009C
	global_load_b32 v43, v[175:176], off                       // 00000000415C: EE05007C 0000002B 000000AF
	s_wait_alu depctr_sa_sdst(0)                               // 000000004168: BF88FF9E
	s_and_not1_saveexec_b32 s4, s5                             // 00000000416C: BE843005
	s_cbranch_execz 28                                         // 000000004170: BFA5001C <tessera_rocm_folded_matmul_a870cecb1991940b+0x26e4>
	s_wait_loadcnt 0x3                                         // 000000004174: BFC00003
	v_add_co_u32 v40, s3, s6, v72                              // 000000004178: D7000328 02029006
	s_wait_loadcnt 0x2                                         // 000000004180: BFC00002
	s_wait_alu depctr_va_sdst(0)                               // 000000004184: BF88F19F
	v_add_co_ci_u32_e64 v41, null, s7, 0, s3                   // 000000004188: D5207C29 000D0007
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000004190: BF870122
	v_add_co_u32 v40, s3, v40, v73                             // 000000004194: D7000328 02029328
	s_wait_alu depctr_va_sdst(0)                               // 00000000419C: BF88F19F
	v_add_co_ci_u32_e64 v41, null, 0, v41, s3                  // 0000000041A0: D5207C29 000E5280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000041A8: BF870091
	v_lshlrev_b64_e32 v[40:41], 2, v[40:41]                    // 0000000041AC: 3E505082
	v_add_co_u32 v40, s3, s12, v40                             // 0000000041B0: D7000328 0202500C
	s_wait_alu depctr_va_sdst(0)                               // 0000000041B8: BF88F19F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000041BC: BF870002
	v_add_co_ci_u32_e64 v41, null, s13, v41, s3                // 0000000041C0: D5207C29 000E520D
	global_load_b128 v[44:47], v[40:41], off offset:192        // 0000000041C8: EE05C07C 0000002C 0000C028
	s_wait_loadcnt 0x1                                         // 0000000041D4: BFC00001
	global_load_b128 v[40:43], v[40:41], off offset:208        // 0000000041D8: EE05C07C 00000028 0000D028
	s_wait_alu depctr_sa_sdst(0)                               // 0000000041E4: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000041E8: 8C7E047E
	global_load_u8 v51, v[152:153], off                        // 0000000041EC: EE04007C 00000033 00000098
	s_wait_loadcnt 0x0                                         // 0000000041F8: BFC00000
	v_lshlrev_b32_e32 v53, 23, v51                             // 0000000041FC: 306A6697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000004200: BF870091
	v_mul_f32_e32 v51, v44, v53                                // 000000004204: 10666B2C
	v_cmp_class_f32_e64 s3, v51, 0x198                         // 000000004208: D47E0003 0201FF33 00000198
	v_mul_f32_e32 v51, v32, v51                                // 000000004214: 10666720
	s_xor_b32 s3, s3, -1                                       // 000000004218: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 00000000421C: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 000000004220: BE842003
	s_cbranch_execnz 2216                                      // 000000004224: BFA608A8 <tessera_rocm_folded_matmul_a870cecb1991940b+0x49c8>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004228: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000422C: 8C7E047E
	v_mul_f32_e32 v32, v45, v53                                // 000000004230: 10406B2D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004234: BF870001
	v_cmp_class_f32_e64 s3, v32, 0x198                         // 000000004238: D47E0003 0201FF20 00000198
	v_mul_f32_e32 v32, v33, v32                                // 000000004244: 10404121
	s_xor_b32 s3, s3, -1                                       // 000000004248: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 00000000424C: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 000000004250: BE842003
	s_cbranch_execnz 2222                                      // 000000004254: BFA608AE <tessera_rocm_folded_matmul_a870cecb1991940b+0x4a10>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004258: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000425C: 8C7E047E
	v_mul_f32_e32 v33, v46, v53                                // 000000004260: 10426B2E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004264: BF870001
	v_cmp_class_f32_e64 s3, v33, 0x198                         // 000000004268: D47E0003 0201FF21 00000198
	v_mul_f32_e32 v33, v34, v33                                // 000000004274: 10424322
	s_xor_b32 s3, s3, -1                                       // 000000004278: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 00000000427C: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 000000004280: BE842003
	s_cbranch_execnz 2228                                      // 000000004284: BFA608B4 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4a58>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004288: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000428C: 8C7E047E
	v_mul_f32_e32 v34, v47, v53                                // 000000004290: 10446B2F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004294: BF870001
	v_cmp_class_f32_e64 s3, v34, 0x198                         // 000000004298: D47E0003 0201FF22 00000198
	v_mul_f32_e32 v34, v35, v34                                // 0000000042A4: 10444523
	s_xor_b32 s3, s3, -1                                       // 0000000042A8: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 0000000042AC: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 0000000042B0: BE842003
	s_cbranch_execnz 2234                                      // 0000000042B4: BFA608BA <tessera_rocm_folded_matmul_a870cecb1991940b+0x4aa0>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000042B8: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000042BC: 8C7E047E
	v_mul_f32_e32 v35, v40, v53                                // 0000000042C0: 10466B28
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000042C4: BF870001
	v_cmp_class_f32_e64 s3, v35, 0x198                         // 0000000042C8: D47E0003 0201FF23 00000198
	v_mul_f32_e32 v35, v36, v35                                // 0000000042D4: 10464724
	s_xor_b32 s3, s3, -1                                       // 0000000042D8: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 0000000042DC: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 0000000042E0: BE842003
	s_cbranch_execnz 2240                                      // 0000000042E4: BFA608C0 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4ae8>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000042E8: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000042EC: 8C7E047E
	v_mul_f32_e32 v36, v41, v53                                // 0000000042F0: 10486B29
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000042F4: BF870001
	v_cmp_class_f32_e64 s3, v36, 0x198                         // 0000000042F8: D47E0003 0201FF24 00000198
	v_mul_f32_e32 v36, v37, v36                                // 000000004304: 10484925
	s_xor_b32 s3, s3, -1                                       // 000000004308: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 00000000430C: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 000000004310: BE842003
	s_cbranch_execnz 2246                                      // 000000004314: BFA608C6 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4b30>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004318: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000431C: 8C7E047E
	v_mul_f32_e32 v37, v42, v53                                // 000000004320: 104A6B2A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004324: BF870001
	v_cmp_class_f32_e64 s3, v37, 0x198                         // 000000004328: D47E0003 0201FF25 00000198
	v_mul_f32_e32 v55, v38, v37                                // 000000004334: 106E4B26
	s_xor_b32 s3, s3, -1                                       // 000000004338: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 00000000433C: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 000000004340: BE842003
	s_cbranch_execnz 2252                                      // 000000004344: BFA608CC <tessera_rocm_folded_matmul_a870cecb1991940b+0x4b78>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004348: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000434C: 8C7E047E
	v_mul_f32_e32 v37, v43, v53                                // 000000004350: 104A6B2B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004354: BF870001
	v_cmp_class_f32_e64 s3, v37, 0x198                         // 000000004358: D47E0003 0201FF25 00000198
	v_mul_f32_e32 v37, v39, v37                                // 000000004364: 104A4B27
	s_xor_b32 s3, s3, -1                                       // 000000004368: 8D03C103
	s_wait_alu depctr_sa_sdst(0)                               // 00000000436C: BF88FF9E
	s_and_saveexec_b32 s4, s3                                  // 000000004370: BE842003
	s_cbranch_execnz 2258                                      // 000000004374: BFA608D2 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4bc0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004378: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000437C: 8C7E047E
	v_mul_lo_u32 v40, v133, s10                                // 000000004380: D72C0028 02001585
	v_mul_lo_u32 v41, v132, s11                                // 000000004388: D72C0029 02001784
	v_mad_co_u64_u32 v[38:39], null, v132, s10, 0              // 000000004390: D6FE7C26 02001584
	v_bfe_u32 v42, v51, 16, 1                                  // 000000004398: D610002A 02052133
	v_cmp_u_f32_e64 s3, v51, v51                               // 0000000043A0: D4180003 02026733
	v_or_b32_e32 v43, 0x400000, v32                            // 0000000043A8: 385640FF 00400000
	v_bfe_u32 v46, v33, 16, 1                                  // 0000000043B0: D610002E 02052121
	v_mov_b32_e32 v161, s15                                    // 0000000043B8: 7F42020F
	v_add3_u32 v42, v42, v51, 0x7fff                           // 0000000043BC: D655002A 03FE672A 00007FFF
	v_or_b32_e32 v160, s14, v160                               // 0000000043C8: 3941400E
	v_add3_u32 v39, v39, v41, v40                              // 0000000043CC: D6550027 04A25327
	v_or_b32_e32 v40, 0x400000, v51                            // 0000000043D4: 385066FF 00400000
	v_bfe_u32 v41, v32, 16, 1                                  // 0000000043DC: D6100029 02052120
	v_or_b32_e32 v51, 0x400000, v36                            // 0000000043E4: 386648FF 00400000
	v_cmp_u_f32_e64 s4, v37, v37                               // 0000000043EC: D4180004 02024B25
	v_lshlrev_b64_e32 v[38:39], 1, v[38:39]                    // 0000000043F4: 3E4C4C81
	s_wait_alu depctr_va_sdst(0)                               // 0000000043F8: BF88F19F
	v_cndmask_b32_e64 v40, v42, v40, s3                        // 0000000043FC: D5010028 000E512A
	v_add3_u32 v41, v41, v32, 0x7fff                           // 000000004404: D6550029 03FE4129 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000004410: BF8700D3
	v_add_co_u32 v38, s3, s20, v38                             // 000000004414: D7000326 02024C14
	s_wait_alu depctr_va_sdst(0)                               // 00000000441C: BF88F19F
	v_add_co_ci_u32_e64 v39, null, s21, v39, s3                // 000000004420: D5207C27 000E4E15
	v_cmp_u_f32_e64 s3, v32, v32                               // 000000004428: D4180003 02024120
	s_wait_alu depctr_va_sdst(0)                               // 000000004430: BF88F19F
	v_cndmask_b32_e64 v32, v41, v43, s3                        // 000000004434: D5010020 000E5729
	v_add_co_u32 v41, s3, v38, s18                             // 00000000443C: D7000329 02002526
	s_wait_alu depctr_va_sdst(0)                               // 000000004444: BF88F19F
	v_add_co_ci_u32_e64 v47, null, s19, v39, s3                // 000000004448: D5207C2F 000E4E13
	v_add_co_u32 v44, s3, v38, v158                            // 000000004450: D700032C 02033D26
	s_wait_alu depctr_va_sdst(0)                               // 000000004458: BF88F19F
	v_add_co_ci_u32_e64 v45, null, v39, v159, s3               // 00000000445C: D5207C2D 000F3F27
	v_add_co_u32 v42, s3, v41, v158                            // 000000004464: D700032A 02033D29
	s_wait_alu depctr_va_sdst(0)                               // 00000000446C: BF88F19F
	v_add_co_ci_u32_e64 v43, null, v47, v159, s3               // 000000004470: D5207C2B 000F3F2F
	v_add3_u32 v38, v46, v33, 0x7fff                           // 000000004478: D6550026 03FE432E 00007FFF
	v_or_b32_e32 v39, 0x400000, v33                            // 000000004484: 384E42FF 00400000
	v_cmp_u_f32_e64 s3, v33, v33                               // 00000000448C: D4180003 02024321
	s_clause 0x1                                               // 000000004494: BF850001
	global_store_d16_hi_b16 v[44:45], v40, off                 // 000000004498: EE09407C 14000000 0000002C
	global_store_d16_hi_b16 v[42:43], v32, off                 // 0000000044A4: EE09407C 10000000 0000002A
	v_bfe_u32 v33, v34, 16, 1                                  // 0000000044B0: D6100021 02052122
	v_or_b32_e32 v40, 0x400000, v34                            // 0000000044B8: 385044FF 00400000
	v_or_b32_e32 v46, 0x400000, v35                            // 0000000044C0: 385C46FF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 0000000044C8: BF88F19F
	v_cndmask_b32_e64 v32, v38, v39, s3                        // 0000000044CC: D5010020 000E4F26
	v_add_co_u32 v38, s3, v41, s18                             // 0000000044D4: D7000326 02002529
	s_wait_alu depctr_va_sdst(0)                               // 0000000044DC: BF88F19F
	v_add_co_ci_u32_e64 v39, null, s19, v47, s3                // 0000000044E0: D5207C27 000E5E13
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000044E8: D6550021 03FE4521 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000044F4: BF8701A3
	v_add_co_u32 v152, s3, v38, v158                           // 0000000044F8: D7000398 02033D26
	s_wait_alu depctr_va_sdst(0)                               // 000000004500: BF88F19F
	v_add_co_ci_u32_e64 v153, null, v39, v159, s3              // 000000004504: D5207C99 000F3F27
	v_cmp_u_f32_e64 s3, v34, v34                               // 00000000450C: D4180003 02024522
	v_bfe_u32 v34, v35, 16, 1                                  // 000000004514: D6100022 02052123
	s_wait_alu depctr_va_sdst(0)                               // 00000000451C: BF88F19F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000004520: BF8701D2
	v_cndmask_b32_e64 v33, v33, v40, s3                        // 000000004524: D5010021 000E5121
	v_add_co_u32 v38, s3, v38, s18                             // 00000000452C: D7000326 02002526
	s_wait_alu depctr_va_sdst(0)                               // 000000004534: BF88F19F
	v_add_co_ci_u32_e64 v39, null, s19, v39, s3                // 000000004538: D5207C27 000E4E13
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000004540: D6550022 03FE4722 00007FFF
	v_add_co_u32 v40, s3, v38, v158                            // 00000000454C: D7000328 02033D26
	s_wait_alu depctr_va_sdst(0)                               // 000000004554: BF88F19F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000004558: BF8700B3
	v_add_co_ci_u32_e64 v41, null, v39, v159, s3               // 00000000455C: D5207C29 000F3F27
	v_cmp_u_f32_e64 s3, v35, v35                               // 000000004564: D4180003 02024723
	s_wait_alu depctr_va_sdst(0)                               // 00000000456C: BF88F19F
	v_cndmask_b32_e64 v34, v34, v46, s3                        // 000000004570: D5010022 000E5D22
	v_add_co_u32 v35, s3, v38, s18                             // 000000004578: D7000323 02002526
	s_wait_alu depctr_va_sdst(0)                               // 000000004580: BF88F19F
	v_add_co_ci_u32_e64 v38, null, s19, v39, s3                // 000000004584: D5207C26 000E4E13
	v_bfe_u32 v39, v36, 16, 1                                  // 00000000458C: D6100027 02052124
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000004594: BF8701A3
	v_add_co_u32 v46, s3, v35, v158                            // 000000004598: D700032E 02033D23
	s_wait_alu depctr_va_sdst(0)                               // 0000000045A0: BF88F19F
	v_add_co_ci_u32_e64 v47, null, v38, v159, s3               // 0000000045A4: D5207C2F 000F3F26
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000045AC: BF870003
	v_add3_u32 v39, v39, v36, 0x7fff                           // 0000000045B0: D6550027 03FE4927 00007FFF
	v_cmp_u_f32_e64 s3, v36, v36                               // 0000000045BC: D4180003 02024924
	s_clause 0x2                                               // 0000000045C4: BF850002
	global_store_d16_hi_b16 v[152:153], v32, off               // 0000000045C8: EE09407C 10000000 00000098
	global_store_d16_hi_b16 v[40:41], v33, off                 // 0000000045D4: EE09407C 10800000 00000028
	global_store_d16_hi_b16 v[46:47], v34, off                 // 0000000045E0: EE09407C 11000000 0000002E
	v_bfe_u32 v33, v55, 16, 1                                  // 0000000045EC: D6100021 02052137
	v_or_b32_e32 v36, 0x400000, v55                            // 0000000045F4: 38486EFF 00400000
	s_wait_alu depctr_va_sdst(0)                               // 0000000045FC: BF88F19F
	v_cndmask_b32_e64 v32, v39, v51, s3                        // 000000004600: D5010020 000E6727
	v_add_co_u32 v34, s3, v35, s18                             // 000000004608: D7000322 02002523
	s_wait_alu depctr_va_sdst(0)                               // 000000004610: BF88F19F
	v_add_co_ci_u32_e64 v35, null, s19, v38, s3                // 000000004614: D5207C23 000E4C13
	v_add3_u32 v33, v33, v55, 0x7fff                           // 00000000461C: D6550021 03FE6F21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000004628: BF8701A3
	v_add_co_u32 v154, s3, v34, v158                           // 00000000462C: D700039A 02033D22
	s_wait_alu depctr_va_sdst(0)                               // 000000004634: BF88F19F
	v_add_co_ci_u32_e64 v155, null, v35, v159, s3              // 000000004638: D5207C9B 000F3F23
	v_cmp_u_f32_e64 s3, v55, v55                               // 000000004640: D4180003 02026F37
	v_or_b32_e32 v38, 0x400000, v37                            // 000000004648: 384C4AFF 00400000
	global_store_d16_hi_b16 v[154:155], v32, off               // 000000004650: EE09407C 10000000 0000009A
	s_wait_alu depctr_va_sdst(0)                               // 00000000465C: BF88F19F
	v_cndmask_b32_e64 v33, v33, v36, s3                        // 000000004660: D5010021 000E4921
	v_add_co_u32 v34, s3, v34, s18                             // 000000004668: D7000322 02002522
	s_wait_alu depctr_va_sdst(0)                               // 000000004670: BF88F19F
	v_add_co_ci_u32_e64 v35, null, s19, v35, s3                // 000000004674: D5207C23 000E4613
	v_bfe_u32 v36, v37, 16, 1                                  // 00000000467C: D6100024 02052125
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000004684: BF8701A3
	v_add_co_u32 v156, s3, v34, v158                           // 000000004688: D700039C 02033D22
	s_wait_alu depctr_va_sdst(0)                               // 000000004690: BF88F19F
	v_add_co_ci_u32_e64 v157, null, v35, v159, s3              // 000000004694: D5207C9D 000F3F23
	v_add_co_u32 v34, s3, v34, s18                             // 00000000469C: D7000322 02002522
	v_add3_u32 v36, v36, v37, 0x7fff                           // 0000000046A4: D6550024 03FE4B24 00007FFF
	s_wait_alu depctr_va_sdst(0)                               // 0000000046B0: BF88F19F
	v_add_co_ci_u32_e64 v35, null, s19, v35, s3                // 0000000046B4: D5207C23 000E4613
	v_cmp_gt_u64_e64 s3, s[10:11], v[160:161]                  // 0000000046BC: D45C0003 0203400A
	global_store_d16_hi_b16 v[156:157], v33, off               // 0000000046C4: EE09407C 10800000 0000009C
	v_cndmask_b32_e64 v36, v36, v38, s4                        // 0000000046D0: D5010024 00124D24
	v_add_co_u32 v158, s4, v34, v158                           // 0000000046D8: D700049E 02033D22
	s_wait_alu depctr_va_sdst(0)                               // 0000000046E0: BF88F19F
	v_add_co_ci_u32_e64 v159, null, v35, v159, s4              // 0000000046E4: D5207C9F 00133F23
	s_and_b32 s4, s3, vcc_lo                                   // 0000000046EC: 8B046A03
	s_wait_alu depctr_sa_sdst(0)                               // 0000000046F0: BF88FF9E
	s_and_b32 s4, s22, s4                                      // 0000000046F4: 8B040416
	global_store_d16_hi_b16 v[158:159], v36, off               // 0000000046F8: EE09407C 12000000 0000009E
	s_wait_alu depctr_sa_sdst(0)                               // 000000004704: BF88FF9E
	s_xor_b32 s4, s4, -1                                       // 000000004708: 8D04C104
	s_wait_alu depctr_sa_sdst(0)                               // 00000000470C: BF88FF9E
	s_and_saveexec_b32 s5, s4                                  // 000000004710: BE852004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004714: BF88FF9E
	s_xor_b32 s14, exec_lo, s5                                 // 000000004718: 8D0E057E
	s_cbranch_execz 124                                        // 00000000471C: BFA5007C <tessera_rocm_folded_matmul_a870cecb1991940b+0x2e10>
	v_or_b32_e32 v32, v74, v163                                // 000000004720: 3841474A
	v_mov_b32_e32 v33, v75                                     // 000000004724: 7E42034B
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[76:77]                  // 000000004728: 7CA89808
	v_or_b32_e32 v34, v74, v162                                // 00000000472C: 3845454A
	v_mov_b32_e32 v35, v75                                     // 000000004730: 7E46034B
	v_or_b32_e32 v36, v74, v165                                // 000000004734: 38494B4A
	v_cmp_gt_i64_e64 s4, s[8:9], v[32:33]                      // 000000004738: D4540004 02024008
	v_mov_b32_e32 v37, v75                                     // 000000004740: 7E4A034B
	s_wait_alu depctr_va_vcc(0)                                // 000000004744: BF88FF9D
	v_dual_cndmask_b32 v77, 0, v77 :: v_dual_cndmask_b32 v76, 0, v76// 000000004748: CA529A80 4D4C9880
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[34:35]                  // 000000004750: 7CA84408
	v_or_b32_e32 v38, v74, v164                                // 000000004754: 384D494A
	s_wait_alu depctr_va_sdst(0)                               // 000000004758: BF88F19F
	v_cndmask_b32_e64 v33, 0, v75, s4                          // 00000000475C: D5010021 00129680
	v_cndmask_b32_e64 v32, 0, v32, s4                          // 000000004764: D5010020 00124080
	v_lshlrev_b64_e32 v[76:77], 2, v[76:77]                    // 00000000476C: 3E989882
	v_mov_b32_e32 v39, v75                                     // 000000004770: 7E4E034B
	s_wait_alu depctr_va_vcc(0)                                // 000000004774: BF88FF9D
	v_dual_cndmask_b32 v35, 0, v75 :: v_dual_cndmask_b32 v34, 0, v34// 000000004778: CA529680 23224480
	v_lshlrev_b64_e32 v[32:33], 2, v[32:33]                    // 000000004780: 3E404082
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[36:37]                  // 000000004784: 7CA84808
	v_or_b32_e32 v114, v74, v167                               // 000000004788: 38E54F4A
	v_mov_b32_e32 v115, v75                                    // 00000000478C: 7EE6034B
	v_add_co_u32 v76, s4, s12, v76                             // 000000004790: D700044C 0202980C
	s_wait_alu depctr_va_sdst(0)                               // 000000004798: BF88F19F
	v_add_co_ci_u32_e64 v77, null, s13, v77, s4                // 00000000479C: D5207C4D 00129A0D
	v_add_co_u32 v32, s4, s12, v32                             // 0000000047A4: D7000420 0202400C
	s_wait_alu depctr_va_vcc(0)                                // 0000000047AC: BF88FF9D
	v_dual_cndmask_b32 v37, 0, v75 :: v_dual_cndmask_b32 v36, 0, v36// 0000000047B0: CA529680 25244880
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[38:39]                  // 0000000047B8: 7CA84C08
	v_or_b32_e32 v162, v74, v166                               // 0000000047BC: 39454D4A
	v_mov_b32_e32 v163, v75                                    // 0000000047C0: 7F46034B
	s_wait_alu depctr_va_sdst(0)                               // 0000000047C4: BF88F19F
	v_add_co_ci_u32_e64 v33, null, s13, v33, s4                // 0000000047C8: D5207C21 0012420D
	v_cmp_gt_i64_e64 s4, s[8:9], v[114:115]                    // 0000000047D0: D4540004 0202E408
	v_lshlrev_b64_e32 v[36:37], 2, v[36:37]                    // 0000000047D8: 3E484882
	s_wait_alu depctr_va_vcc(0)                                // 0000000047DC: BF88FF9D
	v_dual_cndmask_b32 v39, 0, v75 :: v_dual_cndmask_b32 v38, 0, v38// 0000000047E0: CA529680 27264C80
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[162:163]                // 0000000047E8: 7CA94408
	v_or_b32_e32 v74, v74, v168                                // 0000000047EC: 3895514A
	s_wait_alu depctr_va_sdst(0)                               // 0000000047F0: BF88F19F
	v_cndmask_b32_e64 v115, 0, v75, s4                         // 0000000047F4: D5010073 00129680
	v_cndmask_b32_e64 v114, 0, v114, s4                        // 0000000047FC: D5010072 0012E480
	v_add_co_u32 v163, s4, s12, v36                            // 000000004804: D70004A3 0202480C
	s_wait_alu depctr_va_sdst(0)                               // 00000000480C: BF88F19F
	v_add_co_ci_u32_e64 v164, null, s13, v37, s4               // 000000004810: D5207CA4 00124A0D
	v_lshlrev_b64_e32 v[36:37], 2, v[38:39]                    // 000000004818: 3E484C82
	v_lshlrev_b64_e32 v[38:39], 2, v[114:115]                  // 00000000481C: 3E4CE482
	s_wait_alu depctr_va_vcc(0)                                // 000000004820: BF88FF9D
	v_dual_cndmask_b32 v115, 0, v75 :: v_dual_cndmask_b32 v114, 0, v162// 000000004824: CA529680 73734480
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[74:75]                  // 00000000482C: 7CA89408
	v_lshlrev_b64_e32 v[34:35], 2, v[34:35]                    // 000000004830: 3E444482
	v_add_co_u32 v165, s4, s12, v36                            // 000000004834: D70004A5 0202480C
	s_wait_alu depctr_va_sdst(0)                               // 00000000483C: BF88F19F
	v_add_co_ci_u32_e64 v166, null, s13, v37, s4               // 000000004840: D5207CA6 00124A0D
	s_wait_alu depctr_va_vcc(0)                                // 000000004848: BF88FF9D
	v_dual_cndmask_b32 v75, 0, v75 :: v_dual_cndmask_b32 v74, 0, v74// 00000000484C: CA529680 4B4A9480
	v_lshlrev_b64_e32 v[36:37], 2, v[114:115]                  // 000000004854: 3E48E482
	v_add_co_u32 v114, vcc_lo, s12, v38                        // 000000004858: D7006A72 02024C0C
	s_wait_alu depctr_va_vcc(0)                                // 000000004860: BF88FF9D
	v_add_co_ci_u32_e64 v115, null, s13, v39, vcc_lo           // 000000004864: D5207C73 01AA4E0D
	v_lshlrev_b64_e32 v[38:39], 2, v[74:75]                    // 00000000486C: 3E4C9482
	v_add_co_u32 v34, s5, s12, v34                             // 000000004870: D7000522 0202440C
	v_add_co_u32 v74, vcc_lo, s12, v36                         // 000000004878: D7006A4A 0202480C
	s_wait_alu depctr_va_sdst(0)                               // 000000004880: BF88F19F
	v_add_co_ci_u32_e64 v35, null, s13, v35, s5                // 000000004884: D5207C23 0016460D
	s_wait_alu depctr_va_vcc(0)                                // 00000000488C: BF88FF9D
	v_add_co_ci_u32_e64 v75, null, s13, v37, vcc_lo            // 000000004890: D5207C4B 01AA4A0D
	v_add_co_u32 v167, vcc_lo, s12, v38                        // 000000004898: D7006AA7 02024C0C
	s_wait_alu depctr_va_vcc(0)                                // 0000000048A0: BF88FF9D
	v_add_co_ci_u32_e64 v168, null, s13, v39, vcc_lo           // 0000000048A4: D5207CA8 01AA4E0D
	s_clause 0x7                                               // 0000000048AC: BF850007
	global_load_b32 v36, v[76:77], off                         // 0000000048B0: EE05007C 00000024 0000004C
	global_load_b32 v37, v[32:33], off                         // 0000000048BC: EE05007C 00000025 00000020
	global_load_b32 v38, v[34:35], off                         // 0000000048C8: EE05007C 00000026 00000022
	global_load_b32 v39, v[163:164], off                       // 0000000048D4: EE05007C 00000027 000000A3
	global_load_b32 v32, v[165:166], off                       // 0000000048E0: EE05007C 00000020 000000A5
	global_load_b32 v33, v[114:115], off                       // 0000000048EC: EE05007C 00000021 00000072
	global_load_b32 v34, v[74:75], off                         // 0000000048F8: EE05007C 00000022 0000004A
	global_load_b32 v35, v[167:168], off                       // 000000004904: EE05007C 00000023 000000A7
	s_wait_alu depctr_sa_sdst(0)                               // 000000004910: BF88FF9E
	s_and_not1_saveexec_b32 s4, s14                            // 000000004914: BE84300E
	s_cbranch_execz 14                                         // 000000004918: BFA5000E <tessera_rocm_folded_matmul_a870cecb1991940b+0x2e54>
	s_wait_loadcnt 0x3                                         // 00000000491C: BFC00003
	v_add_co_u32 v32, vcc_lo, s12, v114                        // 000000004920: D7006A20 0202E40C
	s_wait_loadcnt 0x2                                         // 000000004928: BFC00002
	s_wait_alu depctr_va_vcc(0)                                // 00000000492C: BF88FF9D
	v_add_co_ci_u32_e64 v33, null, s13, v115, vcc_lo           // 000000004930: D5207C21 01AAE60D
	global_load_b128 v[36:39], v[32:33], off                   // 000000004938: EE05C07C 00000024 00000020
	s_wait_loadcnt 0x1                                         // 000000004944: BFC00001
	global_load_b128 v[32:35], v[32:33], off offset:16         // 000000004948: EE05C07C 00000020 00001020
	s_wait_alu depctr_sa_sdst(0)                               // 000000004954: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004958: 8C7E047E
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[160:161]              // 00000000495C: 7CA9400A
	s_wait_alu depctr_va_vcc(0)                                // 000000004960: BF88FF9D
	v_cndmask_b32_e32 v53, 0, v160, vcc_lo                     // 000000004964: 026B4080
	v_cndmask_b32_e32 v51, 0, v161, vcc_lo                     // 000000004968: 02674280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000000496C: BF870122
	v_add_co_u32 v75, vcc_lo, s16, v53                         // 000000004970: D7006A4B 02026A10
	s_wait_alu depctr_va_vcc(0)                                // 000000004978: BF88FF9D
	v_add_co_ci_u32_e64 v76, null, s17, v51, vcc_lo            // 00000000497C: D5207C4C 01AA6611
	global_load_u8 v51, v[75:76], off                          // 000000004984: EE04007C 00000033 0000004B
	s_wait_loadcnt 0x0                                         // 000000004990: BFC00000
	v_lshlrev_b32_e32 v53, 23, v51                             // 000000004994: 306A6697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000004998: BF870091
	v_mul_f32_e32 v51, v36, v53                                // 00000000499C: 10666B24
	v_cmp_class_f32_e64 s4, v51, 0x198                         // 0000000049A0: D47E0004 0201FF33 00000198
	v_mul_f32_e32 v51, v24, v51                                // 0000000049AC: 10666718
	s_xor_b32 s5, s4, -1                                       // 0000000049B0: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 0000000049B4: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 0000000049B8: BE842005
	s_cbranch_execnz 1874                                      // 0000000049BC: BFA60752 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4c08>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000049C0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000049C4: 8C7E047E
	v_mul_f32_e32 v24, v37, v53                                // 0000000049C8: 10306B25
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000049CC: BF870001
	v_cmp_class_f32_e64 s4, v24, 0x198                         // 0000000049D0: D47E0004 0201FF18 00000198
	v_mul_f32_e32 v24, v25, v24                                // 0000000049DC: 10303119
	s_xor_b32 s5, s4, -1                                       // 0000000049E0: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 0000000049E4: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 0000000049E8: BE842005
	s_cbranch_execnz 1879                                      // 0000000049EC: BFA60757 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4c4c>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000049F0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000049F4: 8C7E047E
	v_mul_f32_e32 v25, v38, v53                                // 0000000049F8: 10326B26
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000049FC: BF870001
	v_cmp_class_f32_e64 s4, v25, 0x198                         // 000000004A00: D47E0004 0201FF19 00000198
	v_mul_f32_e32 v25, v26, v25                                // 000000004A0C: 1032331A
	s_xor_b32 s5, s4, -1                                       // 000000004A10: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 000000004A14: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 000000004A18: BE842005
	s_cbranch_execnz 1884                                      // 000000004A1C: BFA6075C <tessera_rocm_folded_matmul_a870cecb1991940b+0x4c90>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004A20: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004A24: 8C7E047E
	v_mul_f32_e32 v26, v39, v53                                // 000000004A28: 10346B27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004A2C: BF870001
	v_cmp_class_f32_e64 s4, v26, 0x198                         // 000000004A30: D47E0004 0201FF1A 00000198
	v_mul_f32_e32 v26, v27, v26                                // 000000004A3C: 1034351B
	s_xor_b32 s5, s4, -1                                       // 000000004A40: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 000000004A44: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 000000004A48: BE842005
	s_cbranch_execnz 1889                                      // 000000004A4C: BFA60761 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4cd4>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004A50: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004A54: 8C7E047E
	v_mul_f32_e32 v27, v32, v53                                // 000000004A58: 10366B20
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004A5C: BF870001
	v_cmp_class_f32_e64 s4, v27, 0x198                         // 000000004A60: D47E0004 0201FF1B 00000198
	v_mul_f32_e32 v27, v28, v27                                // 000000004A6C: 1036371C
	s_xor_b32 s5, s4, -1                                       // 000000004A70: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 000000004A74: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 000000004A78: BE842005
	s_cbranch_execnz 1894                                      // 000000004A7C: BFA60766 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4d18>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004A80: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004A84: 8C7E047E
	v_mul_f32_e32 v28, v33, v53                                // 000000004A88: 10386B21
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004A8C: BF870001
	v_cmp_class_f32_e64 s4, v28, 0x198                         // 000000004A90: D47E0004 0201FF1C 00000198
	v_mul_f32_e32 v28, v29, v28                                // 000000004A9C: 1038391D
	s_xor_b32 s5, s4, -1                                       // 000000004AA0: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 000000004AA4: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 000000004AA8: BE842005
	s_cbranch_execnz 1899                                      // 000000004AAC: BFA6076B <tessera_rocm_folded_matmul_a870cecb1991940b+0x4d5c>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004AB0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004AB4: 8C7E047E
	v_mul_f32_e32 v29, v34, v53                                // 000000004AB8: 103A6B22
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004ABC: BF870001
	v_cmp_class_f32_e64 s4, v29, 0x198                         // 000000004AC0: D47E0004 0201FF1D 00000198
	v_mul_f32_e32 v29, v30, v29                                // 000000004ACC: 103A3B1E
	s_xor_b32 s5, s4, -1                                       // 000000004AD0: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 000000004AD4: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 000000004AD8: BE842005
	s_cbranch_execnz 1904                                      // 000000004ADC: BFA60770 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4da0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004AE0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004AE4: 8C7E047E
	v_mul_f32_e32 v30, v35, v53                                // 000000004AE8: 103C6B23
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004AEC: BF870001
	v_cmp_class_f32_e64 s4, v30, 0x198                         // 000000004AF0: D47E0004 0201FF1E 00000198
	v_mul_f32_e32 v30, v31, v30                                // 000000004AFC: 103C3D1F
	s_xor_b32 s5, s4, -1                                       // 000000004B00: 8D05C104
	s_wait_alu depctr_sa_sdst(0)                               // 000000004B04: BF88FF9E
	s_and_saveexec_b32 s4, s5                                  // 000000004B08: BE842005
	s_cbranch_execnz 1909                                      // 000000004B0C: BFA60775 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4de4>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004B10: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004B14: 8C7E047E
	v_bfe_u32 v31, v51, 16, 1                                  // 000000004B18: D610001F 02052133
	v_bfe_u32 v32, v24, 16, 1                                  // 000000004B20: D6100020 02052118
	v_or_b32_e32 v33, 0x400000, v51                            // 000000004B28: 384266FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v51, v51                           // 000000004B30: 7C306733
	v_or_b32_e32 v34, 0x400000, v24                            // 000000004B34: 384430FF 00400000
	v_add3_u32 v31, v31, v51, 0x7fff                           // 000000004B3C: D655001F 03FE671F 00007FFF
	v_add3_u32 v32, v32, v24, 0x7fff                           // 000000004B48: D6550020 03FE3120 00007FFF
	v_bfe_u32 v35, v25, 16, 1                                  // 000000004B54: D6100023 02052119
	s_and_b32 s0, s3, s0                                       // 000000004B5C: 8B000003
	s_wait_alu depctr_sa_sdst(0)                               // 000000004B60: BF88FF9E
	s_and_b32 s0, s22, s0                                      // 000000004B64: 8B000016
	s_wait_alu depctr_va_vcc(0)                                // 000000004B68: BF88FF9D
	v_cndmask_b32_e32 v31, v31, v33, vcc_lo                    // 000000004B6C: 023E431F
	v_cmp_u_f32_e32 vcc_lo, v24, v24                           // 000000004B70: 7C303118
	v_bfe_u32 v33, v27, 16, 1                                  // 000000004B74: D6100021 0205211B
	s_wait_alu depctr_sa_sdst(0)                               // 000000004B7C: BF88FF9E
	s_xor_b32 s0, s0, -1                                       // 000000004B80: 8D00C100
	s_wait_alu depctr_va_vcc(0)                                // 000000004B84: BF88FF9D
	v_cndmask_b32_e32 v24, v32, v34, vcc_lo                    // 000000004B88: 02304520
	v_bfe_u32 v32, v26, 16, 1                                  // 000000004B8C: D6100020 0205211A
	v_add3_u32 v34, v35, v25, 0x7fff                           // 000000004B94: D6550022 03FE3323 00007FFF
	s_clause 0x1                                               // 000000004BA0: BF850001
	global_store_d16_hi_b16 v[78:79], v31, off offset:32       // 000000004BA4: EE09407C 0F800000 0000204E
	global_store_d16_hi_b16 v[82:83], v24, off offset:32       // 000000004BB0: EE09407C 0C000000 00002052
	v_or_b32_e32 v24, 0x400000, v25                            // 000000004BBC: 383032FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v25, v25                           // 000000004BC4: 7C303319
	v_add3_u32 v31, v32, v26, 0x7fff                           // 000000004BC8: D655001F 03FE3520 00007FFF
	v_or_b32_e32 v32, 0x400000, v26                            // 000000004BD4: 384034FF 00400000
	v_add3_u32 v33, v33, v27, 0x7fff                           // 000000004BDC: D6550021 03FE3721 00007FFF
	v_or_b32_e32 v35, 0x400000, v27                            // 000000004BE8: 384636FF 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000004BF0: BF88FF9D
	v_cndmask_b32_e32 v24, v34, v24, vcc_lo                    // 000000004BF4: 02303122
	v_cmp_u_f32_e32 vcc_lo, v26, v26                           // 000000004BF8: 7C30351A
	global_store_d16_hi_b16 v[84:85], v24, off offset:32       // 000000004BFC: EE09407C 0C000000 00002054
	s_wait_alu depctr_va_vcc(0)                                // 000000004C08: BF88FF9D
	v_cndmask_b32_e32 v25, v31, v32, vcc_lo                    // 000000004C0C: 0232411F
	v_cmp_u_f32_e32 vcc_lo, v27, v27                           // 000000004C10: 7C30371B
	v_bfe_u32 v24, v28, 16, 1                                  // 000000004C14: D6100018 0205211C
	v_or_b32_e32 v27, 0x400000, v28                            // 000000004C1C: 383638FF 00400000
	v_or_b32_e32 v31, 0x400000, v29                            // 000000004C24: 383E3AFF 00400000
	global_store_d16_hi_b16 v[90:91], v25, off offset:32       // 000000004C2C: EE09407C 0C800000 0000205A
	s_wait_alu depctr_va_vcc(0)                                // 000000004C38: BF88FF9D
	v_cndmask_b32_e32 v26, v33, v35, vcc_lo                    // 000000004C3C: 02344721
	v_bfe_u32 v25, v29, 16, 1                                  // 000000004C40: D6100019 0205211D
	v_add3_u32 v24, v24, v28, 0x7fff                           // 000000004C48: D6550018 03FE3918 00007FFF
	v_cmp_u_f32_e32 vcc_lo, v28, v28                           // 000000004C54: 7C30391C
	v_or_b32_e32 v32, 0x400000, v30                            // 000000004C58: 38403CFF 00400000
	global_store_d16_hi_b16 v[96:97], v26, off offset:32       // 000000004C60: EE09407C 0D000000 00002060
	v_bfe_u32 v26, v30, 16, 1                                  // 000000004C6C: D610001A 0205211E
	v_add3_u32 v25, v25, v29, 0x7fff                           // 000000004C74: D6550019 03FE3B19 00007FFF
	s_wait_alu depctr_va_vcc(0)                                // 000000004C80: BF88FF9D
	v_cndmask_b32_e32 v24, v24, v27, vcc_lo                    // 000000004C84: 02303718
	v_cmp_u_f32_e32 vcc_lo, v29, v29                           // 000000004C88: 7C303B1D
	v_add3_u32 v26, v26, v30, 0x7fff                           // 000000004C8C: D655001A 03FE3D1A 00007FFF
	global_store_d16_hi_b16 v[94:95], v24, off offset:32       // 000000004C98: EE09407C 0C000000 0000205E
	s_wait_alu depctr_va_vcc(0)                                // 000000004CA4: BF88FF9D
	v_cndmask_b32_e32 v25, v25, v31, vcc_lo                    // 000000004CA8: 02323F19
	v_cmp_u_f32_e32 vcc_lo, v30, v30                           // 000000004CAC: 7C303D1E
	global_store_d16_hi_b16 v[98:99], v25, off offset:32       // 000000004CB0: EE09407C 0C800000 00002062
	s_wait_alu depctr_va_vcc(0)                                // 000000004CBC: BF88FF9D
	v_cndmask_b32_e32 v26, v26, v32, vcc_lo                    // 000000004CC0: 0234411A
	global_store_d16_hi_b16 v[100:101], v26, off offset:32     // 000000004CC4: EE09407C 0D000000 00002064
	s_wait_alu depctr_sa_sdst(0)                               // 000000004CD0: BF88FF9E
	s_and_saveexec_b32 s4, s0                                  // 000000004CD4: BE842000
	s_wait_alu depctr_sa_sdst(0)                               // 000000004CD8: BF88FF9E
	s_xor_b32 s5, exec_lo, s4                                  // 000000004CDC: 8D05047E
	s_cbranch_execz 119                                        // 000000004CE0: BFA50077 <tessera_rocm_folded_matmul_a870cecb1991940b+0x33c0>
	v_mov_b32_e32 v93, v65                                     // 000000004CE4: 7EBA0341
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[86:87]                  // 000000004CE8: 7CA8AC08
	v_mov_b32_e32 v89, v65                                     // 000000004CEC: 7EB20341
	v_mov_b32_e32 v81, v65                                     // 000000004CF0: 7EA20341
	v_mov_b32_e32 v71, v65                                     // 000000004CF4: 7E8E0341
	v_cmp_gt_i64_e64 s0, s[8:9], v[92:93]                      // 000000004CF8: D4540000 0202B808
	v_mov_b32_e32 v69, v65                                     // 000000004D00: 7E8A0341
	s_wait_alu depctr_va_vcc(0)                                // 000000004D04: BF88FF9D
	v_dual_cndmask_b32 v25, 0, v87 :: v_dual_cndmask_b32 v24, 0, v86// 000000004D08: CA52AE80 1918AC80
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[88:89]                  // 000000004D10: 7CA8B008
	v_mov_b32_e32 v67, v65                                     // 000000004D14: 7E860341
	s_wait_alu depctr_va_sdst(0)                               // 000000004D18: BF88F19F
	v_cndmask_b32_e64 v27, 0, v65, s0                          // 000000004D1C: D501001B 00028280
	v_cndmask_b32_e64 v26, 0, v92, s0                          // 000000004D24: D501001A 0002B880
	v_lshlrev_b64_e32 v[24:25], 2, v[24:25]                    // 000000004D2C: 3E303082
	s_wait_alu depctr_va_vcc(0)                                // 000000004D30: BF88FF9D
	v_dual_cndmask_b32 v29, 0, v65 :: v_dual_cndmask_b32 v28, 0, v88// 000000004D34: CA528280 1D1CB080
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[80:81]                  // 000000004D3C: 7CA8A008
	v_lshlrev_b64_e32 v[26:27], 2, v[26:27]                    // 000000004D40: 3E343482
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000004D44: BF870214
	v_add_co_u32 v24, s0, s12, v24                             // 000000004D48: D7000018 0202300C
	v_lshlrev_b64_e32 v[28:29], 2, v[28:29]                    // 000000004D50: 3E383882
	s_wait_alu depctr_va_sdst(0)                               // 000000004D54: BF88F19F
	v_add_co_ci_u32_e64 v25, null, s13, v25, s0                // 000000004D58: D5207C19 0002320D
	s_wait_alu depctr_va_vcc(0)                                // 000000004D60: BF88FF9D
	v_dual_cndmask_b32 v31, 0, v65 :: v_dual_cndmask_b32 v30, 0, v80// 000000004D64: CA528280 1F1EA080
	v_add_co_u32 v26, s0, s12, v26                             // 000000004D6C: D700001A 0202340C
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[70:71]                  // 000000004D74: 7CA88C08
	v_add_co_u32 v32, s4, s12, v28                             // 000000004D78: D7000420 0202380C
	s_wait_alu depctr_va_sdst(0)                               // 000000004D80: BF88F19F
	v_add_co_ci_u32_e64 v27, null, s13, v27, s0                // 000000004D84: D5207C1B 0002360D
	v_cmp_gt_i64_e64 s0, s[8:9], v[68:69]                      // 000000004D8C: D4540000 02028808
	v_add_co_ci_u32_e64 v33, null, s13, v29, s4                // 000000004D94: D5207C21 00123A0D
	v_lshlrev_b64_e32 v[28:29], 2, v[30:31]                    // 000000004D9C: 3E383C82
	s_wait_alu depctr_va_vcc(0)                                // 000000004DA0: BF88FF9D
	v_dual_cndmask_b32 v31, 0, v65 :: v_dual_cndmask_b32 v30, 0, v70// 000000004DA4: CA528280 1F1E8C80
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[66:67]                  // 000000004DAC: 7CA88408
	s_wait_alu depctr_va_sdst(0)                               // 000000004DB0: BF88F19F
	v_cndmask_b32_e64 v35, 0, v65, s0                          // 000000004DB4: D5010023 00028280
	v_cndmask_b32_e64 v34, 0, v68, s0                          // 000000004DBC: D5010022 00028880
	v_add_co_u32 v36, s0, s12, v28                             // 000000004DC4: D7000024 0202380C
	s_wait_alu depctr_va_sdst(0)                               // 000000004DCC: BF88F19F
	v_add_co_ci_u32_e64 v37, null, s13, v29, s0                // 000000004DD0: D5207C25 00023A0D
	v_lshlrev_b64_e32 v[28:29], 2, v[30:31]                    // 000000004DD8: 3E383C82
	v_lshlrev_b64_e32 v[30:31], 2, v[34:35]                    // 000000004DDC: 3E3C4482
	s_wait_alu depctr_va_vcc(0)                                // 000000004DE0: BF88FF9D
	v_dual_cndmask_b32 v35, 0, v65 :: v_dual_cndmask_b32 v34, 0, v66// 000000004DE4: CA528280 23228480
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[64:65]                  // 000000004DEC: 7CA88008
	s_delay_alu instid0(VALU_DEP_4)                            // 000000004DF0: BF870004
	v_add_co_u32 v38, s0, s12, v28                             // 000000004DF4: D7000026 0202380C
	s_wait_alu depctr_va_sdst(0)                               // 000000004DFC: BF88F19F
	v_add_co_ci_u32_e64 v39, null, s13, v29, s0                // 000000004E00: D5207C27 00023A0D
	v_lshlrev_b64_e32 v[28:29], 2, v[34:35]                    // 000000004E08: 3E384482
	s_wait_alu depctr_va_vcc(0)                                // 000000004E0C: BF88FF9D
	v_dual_cndmask_b32 v35, 0, v65 :: v_dual_cndmask_b32 v34, 0, v64// 000000004E10: CA528280 23228080
	v_add_co_u32 v63, vcc_lo, s12, v30                         // 000000004E18: D7006A3F 02023C0C
	s_wait_alu depctr_va_vcc(0)                                // 000000004E20: BF88FF9D
	v_add_co_ci_u32_e64 v64, null, s13, v31, vcc_lo            // 000000004E24: D5207C40 01AA3E0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000004E2C: BF8701C3
	v_lshlrev_b64_e32 v[30:31], 2, v[34:35]                    // 000000004E30: 3E3C4482
	v_add_co_u32 v34, vcc_lo, s12, v28                         // 000000004E34: D7006A22 0202380C
	s_wait_alu depctr_va_vcc(0)                                // 000000004E3C: BF88FF9D
	v_add_co_ci_u32_e64 v35, null, s13, v29, vcc_lo            // 000000004E40: D5207C23 01AA3A0D
	v_add_co_u32 v65, vcc_lo, s12, v30                         // 000000004E48: D7006A41 02023C0C
	s_wait_alu depctr_va_vcc(0)                                // 000000004E50: BF88FF9D
	v_add_co_ci_u32_e64 v66, null, s13, v31, vcc_lo            // 000000004E54: D5207C42 01AA3E0D
	s_clause 0x7                                               // 000000004E5C: BF850007
	global_load_b32 v28, v[24:25], off                         // 000000004E60: EE05007C 0000001C 00000018
	global_load_b32 v29, v[26:27], off                         // 000000004E6C: EE05007C 0000001D 0000001A
	global_load_b32 v30, v[32:33], off                         // 000000004E78: EE05007C 0000001E 00000020
	global_load_b32 v31, v[36:37], off                         // 000000004E84: EE05007C 0000001F 00000024
	global_load_b32 v24, v[38:39], off                         // 000000004E90: EE05007C 00000018 00000026
	global_load_b32 v25, v[63:64], off                         // 000000004E9C: EE05007C 00000019 0000003F
	global_load_b32 v26, v[34:35], off                         // 000000004EA8: EE05007C 0000001A 00000022
	global_load_b32 v27, v[65:66], off                         // 000000004EB4: EE05007C 0000001B 00000041
	s_wait_alu depctr_sa_sdst(0)                               // 000000004EC0: BF88FF9E
	s_and_not1_saveexec_b32 s0, s5                             // 000000004EC4: BE803005
	s_cbranch_execz 28                                         // 000000004EC8: BFA5001C <tessera_rocm_folded_matmul_a870cecb1991940b+0x343c>
	s_wait_loadcnt 0x3                                         // 000000004ECC: BFC00003
	v_add_co_u32 v24, s4, s6, v72                              // 000000004ED0: D7000418 02029006
	s_wait_loadcnt 0x2                                         // 000000004ED8: BFC00002
	s_wait_alu depctr_va_sdst(0)                               // 000000004EDC: BF88F19F
	v_add_co_ci_u32_e64 v25, null, s7, 0, s4                   // 000000004EE0: D5207C19 00110007
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000004EE8: BF870122
	v_add_co_u32 v24, vcc_lo, v24, v73                         // 000000004EEC: D7006A18 02029318
	s_wait_alu depctr_va_vcc(0)                                // 000000004EF4: BF88FF9D
	v_add_co_ci_u32_e64 v25, null, 0, v25, vcc_lo              // 000000004EF8: D5207C19 01AA3280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000004F00: BF870091
	v_lshlrev_b64_e32 v[24:25], 2, v[24:25]                    // 000000004F04: 3E303082
	v_add_co_u32 v24, vcc_lo, s12, v24                         // 000000004F08: D7006A18 0202300C
	s_wait_alu depctr_va_vcc(0)                                // 000000004F10: BF88FF9D
	s_delay_alu instid0(VALU_DEP_2)                            // 000000004F14: BF870002
	v_add_co_ci_u32_e64 v25, null, s13, v25, vcc_lo            // 000000004F18: D5207C19 01AA320D
	global_load_b128 v[28:31], v[24:25], off offset:64         // 000000004F20: EE05C07C 0000001C 00004018
	s_wait_loadcnt 0x1                                         // 000000004F2C: BFC00001
	global_load_b128 v[24:27], v[24:25], off offset:80         // 000000004F30: EE05C07C 00000018 00005018
	s_wait_alu depctr_sa_sdst(0)                               // 000000004F3C: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000004F40: 8C7E007E
	global_load_u8 v32, v[75:76], off                          // 000000004F44: EE04007C 00000020 0000004B
	s_wait_loadcnt 0x0                                         // 000000004F50: BFC00000
	v_lshlrev_b32_e32 v33, 23, v32                             // 000000004F54: 30424097
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000004F58: BF870091
	v_mul_f32_e32 v32, v28, v33                                // 000000004F5C: 1040431C
	v_cmp_class_f32_e64 s0, v32, 0x198                         // 000000004F60: D47E0000 0201FF20 00000198
	v_mul_f32_e32 v32, v16, v32                                // 000000004F6C: 10404110
	s_xor_b32 s4, s0, -1                                       // 000000004F70: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000004F74: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 000000004F78: BE802004
	s_cbranch_execnz 1642                                      // 000000004F7C: BFA6066A <tessera_rocm_folded_matmul_a870cecb1991940b+0x4e28>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004F80: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000004F84: 8C7E007E
	v_mul_f32_e32 v16, v29, v33                                // 000000004F88: 1020431D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004F8C: BF870001
	v_cmp_class_f32_e64 s0, v16, 0x198                         // 000000004F90: D47E0000 0201FF10 00000198
	v_mul_f32_e32 v16, v17, v16                                // 000000004F9C: 10202111
	s_xor_b32 s4, s0, -1                                       // 000000004FA0: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000004FA4: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 000000004FA8: BE802004
	s_cbranch_execnz 1647                                      // 000000004FAC: BFA6066F <tessera_rocm_folded_matmul_a870cecb1991940b+0x4e6c>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004FB0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000004FB4: 8C7E007E
	v_mul_f32_e32 v17, v30, v33                                // 000000004FB8: 1022431E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004FBC: BF870001
	v_cmp_class_f32_e64 s0, v17, 0x198                         // 000000004FC0: D47E0000 0201FF11 00000198
	v_mul_f32_e32 v17, v18, v17                                // 000000004FCC: 10222312
	s_xor_b32 s4, s0, -1                                       // 000000004FD0: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000004FD4: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 000000004FD8: BE802004
	s_cbranch_execnz 1652                                      // 000000004FDC: BFA60674 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4eb0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000004FE0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000004FE4: 8C7E007E
	v_mul_f32_e32 v18, v31, v33                                // 000000004FE8: 1024431F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000004FEC: BF870001
	v_cmp_class_f32_e64 s0, v18, 0x198                         // 000000004FF0: D47E0000 0201FF12 00000198
	v_mul_f32_e32 v18, v19, v18                                // 000000004FFC: 10242513
	s_xor_b32 s4, s0, -1                                       // 000000005000: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005004: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 000000005008: BE802004
	s_cbranch_execnz 1657                                      // 00000000500C: BFA60679 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4ef4>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005010: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005014: 8C7E007E
	v_mul_f32_e32 v19, v24, v33                                // 000000005018: 10264318
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000501C: BF870001
	v_cmp_class_f32_e64 s0, v19, 0x198                         // 000000005020: D47E0000 0201FF13 00000198
	v_mul_f32_e32 v19, v20, v19                                // 00000000502C: 10262714
	s_xor_b32 s4, s0, -1                                       // 000000005030: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005034: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 000000005038: BE802004
	s_cbranch_execnz 1662                                      // 00000000503C: BFA6067E <tessera_rocm_folded_matmul_a870cecb1991940b+0x4f38>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005040: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005044: 8C7E007E
	v_mul_f32_e32 v20, v25, v33                                // 000000005048: 10284319
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000504C: BF870001
	v_cmp_class_f32_e64 s0, v20, 0x198                         // 000000005050: D47E0000 0201FF14 00000198
	v_mul_f32_e32 v20, v21, v20                                // 00000000505C: 10282915
	s_xor_b32 s4, s0, -1                                       // 000000005060: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005064: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 000000005068: BE802004
	s_cbranch_execnz 1667                                      // 00000000506C: BFA60683 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4f7c>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005070: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005074: 8C7E007E
	v_mul_f32_e32 v21, v26, v33                                // 000000005078: 102A431A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000507C: BF870001
	v_cmp_class_f32_e64 s0, v21, 0x198                         // 000000005080: D47E0000 0201FF15 00000198
	v_mul_f32_e32 v21, v22, v21                                // 00000000508C: 102A2B16
	s_xor_b32 s4, s0, -1                                       // 000000005090: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005094: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 000000005098: BE802004
	s_cbranch_execnz 1672                                      // 00000000509C: BFA60688 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4fc0>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000050A0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000050A4: 8C7E007E
	v_mul_f32_e32 v22, v27, v33                                // 0000000050A8: 102C431B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000050AC: BF870001
	v_cmp_class_f32_e64 s0, v22, 0x198                         // 0000000050B0: D47E0000 0201FF16 00000198
	v_mul_f32_e32 v22, v23, v22                                // 0000000050BC: 102C2D17
	s_xor_b32 s4, s0, -1                                       // 0000000050C0: 8D04C100
	s_wait_alu depctr_sa_sdst(0)                               // 0000000050C4: BF88FF9E
	s_and_saveexec_b32 s0, s4                                  // 0000000050C8: BE802004
	s_cbranch_execnz 1677                                      // 0000000050CC: BFA6068D <tessera_rocm_folded_matmul_a870cecb1991940b+0x5004>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000050D0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000050D4: 8C7E007E
	v_bfe_u32 v23, v32, 16, 1                                  // 0000000050D8: D6100017 02052120
	v_bfe_u32 v24, v16, 16, 1                                  // 0000000050E0: D6100018 02052110
	v_or_b32_e32 v25, 0x400000, v32                            // 0000000050E8: 383240FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v32, v32                           // 0000000050F0: 7C304120
	v_or_b32_e32 v26, 0x400000, v16                            // 0000000050F4: 383420FF 00400000
	v_add3_u32 v23, v23, v32, 0x7fff                           // 0000000050FC: D6550017 03FE4117 00007FFF
	v_add3_u32 v24, v24, v16, 0x7fff                           // 000000005108: D6550018 03FE2118 00007FFF
	v_bfe_u32 v27, v17, 16, 1                                  // 000000005114: D610001B 02052111
	s_and_b32 s0, s3, s1                                       // 00000000511C: 8B000103
	s_wait_alu depctr_sa_sdst(0)                               // 000000005120: BF88FF9E
	s_and_b32 s0, s22, s0                                      // 000000005124: 8B000016
	s_wait_alu depctr_va_vcc(0)                                // 000000005128: BF88FF9D
	v_cndmask_b32_e32 v23, v23, v25, vcc_lo                    // 00000000512C: 022E3317
	v_cmp_u_f32_e32 vcc_lo, v16, v16                           // 000000005130: 7C302110
	v_bfe_u32 v25, v19, 16, 1                                  // 000000005134: D6100019 02052113
	s_wait_alu depctr_sa_sdst(0)                               // 00000000513C: BF88FF9E
	s_xor_b32 s0, s0, -1                                       // 000000005140: 8D00C100
	s_wait_alu depctr_va_vcc(0)                                // 000000005144: BF88FF9D
	v_cndmask_b32_e32 v16, v24, v26, vcc_lo                    // 000000005148: 02203518
	v_bfe_u32 v24, v18, 16, 1                                  // 00000000514C: D6100018 02052112
	v_add3_u32 v26, v27, v17, 0x7fff                           // 000000005154: D655001A 03FE231B 00007FFF
	s_clause 0x1                                               // 000000005160: BF850001
	global_store_d16_hi_b16 v[104:105], v23, off offset:32     // 000000005164: EE09407C 0B800000 00002068
	global_store_d16_hi_b16 v[110:111], v16, off offset:32     // 000000005170: EE09407C 08000000 0000206E
	v_or_b32_e32 v16, 0x400000, v17                            // 00000000517C: 382022FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v17, v17                           // 000000005184: 7C302311
	v_add3_u32 v23, v24, v18, 0x7fff                           // 000000005188: D6550017 03FE2518 00007FFF
	v_or_b32_e32 v24, 0x400000, v18                            // 000000005194: 383024FF 00400000
	v_add3_u32 v25, v25, v19, 0x7fff                           // 00000000519C: D6550019 03FE2719 00007FFF
	v_or_b32_e32 v27, 0x400000, v19                            // 0000000051A8: 383626FF 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000051B0: BF88FF9D
	v_cndmask_b32_e32 v16, v26, v16, vcc_lo                    // 0000000051B4: 0220211A
	v_cmp_u_f32_e32 vcc_lo, v18, v18                           // 0000000051B8: 7C302512
	global_store_d16_hi_b16 v[112:113], v16, off offset:32     // 0000000051BC: EE09407C 08000000 00002070
	s_wait_alu depctr_va_vcc(0)                                // 0000000051C8: BF88FF9D
	v_cndmask_b32_e32 v17, v23, v24, vcc_lo                    // 0000000051CC: 02223117
	v_cmp_u_f32_e32 vcc_lo, v19, v19                           // 0000000051D0: 7C302713
	v_bfe_u32 v16, v20, 16, 1                                  // 0000000051D4: D6100010 02052114
	v_or_b32_e32 v19, 0x400000, v20                            // 0000000051DC: 382628FF 00400000
	v_or_b32_e32 v23, 0x400000, v21                            // 0000000051E4: 382E2AFF 00400000
	global_store_d16_hi_b16 v[118:119], v17, off offset:32     // 0000000051EC: EE09407C 08800000 00002076
	s_wait_alu depctr_va_vcc(0)                                // 0000000051F8: BF88FF9D
	v_cndmask_b32_e32 v18, v25, v27, vcc_lo                    // 0000000051FC: 02243719
	v_bfe_u32 v17, v21, 16, 1                                  // 000000005200: D6100011 02052115
	v_add3_u32 v16, v16, v20, 0x7fff                           // 000000005208: D6550010 03FE2910 00007FFF
	v_cmp_u_f32_e32 vcc_lo, v20, v20                           // 000000005214: 7C302914
	v_or_b32_e32 v24, 0x400000, v22                            // 000000005218: 38302CFF 00400000
	global_store_d16_hi_b16 v[122:123], v18, off offset:32     // 000000005220: EE09407C 09000000 0000207A
	v_bfe_u32 v18, v22, 16, 1                                  // 00000000522C: D6100012 02052116
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000005234: D6550011 03FE2B11 00007FFF
	s_wait_alu depctr_va_vcc(0)                                // 000000005240: BF88FF9D
	v_cndmask_b32_e32 v16, v16, v19, vcc_lo                    // 000000005244: 02202710
	v_cmp_u_f32_e32 vcc_lo, v21, v21                           // 000000005248: 7C302B15
	v_add3_u32 v18, v18, v22, 0x7fff                           // 00000000524C: D6550012 03FE2D12 00007FFF
	global_store_d16_hi_b16 v[120:121], v16, off offset:32     // 000000005258: EE09407C 08000000 00002078
	s_wait_alu depctr_va_vcc(0)                                // 000000005264: BF88FF9D
	v_cndmask_b32_e32 v17, v17, v23, vcc_lo                    // 000000005268: 02222F11
	v_cmp_u_f32_e32 vcc_lo, v22, v22                           // 00000000526C: 7C302D16
	global_store_d16_hi_b16 v[124:125], v17, off offset:32     // 000000005270: EE09407C 08800000 0000207C
	s_wait_alu depctr_va_vcc(0)                                // 00000000527C: BF88FF9D
	v_cndmask_b32_e32 v18, v18, v24, vcc_lo                    // 000000005280: 02243112
	global_store_d16_hi_b16 v[126:127], v18, off offset:32     // 000000005284: EE09407C 09000000 0000207E
	s_wait_alu depctr_sa_sdst(0)                               // 000000005290: BF88FF9E
	s_and_saveexec_b32 s1, s0                                  // 000000005294: BE812000
	s_wait_alu depctr_sa_sdst(0)                               // 000000005298: BF88FF9E
	s_xor_b32 s4, exec_lo, s1                                  // 00000000529C: 8D04017E
	s_cbranch_execz 119                                        // 0000000052A0: BFA50077 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3980>
	v_mov_b32_e32 v117, v57                                    // 0000000052A4: 7EEA0339
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[106:107]                // 0000000052A8: 7CA8D408
	v_mov_b32_e32 v109, v57                                    // 0000000052AC: 7EDA0339
	v_mov_b32_e32 v103, v57                                    // 0000000052B0: 7ECE0339
	v_mov_b32_e32 v63, v57                                     // 0000000052B4: 7E7E0339
	v_cmp_gt_i64_e64 s0, s[8:9], v[116:117]                    // 0000000052B8: D4540000 0202E808
	v_mov_b32_e32 v61, v57                                     // 0000000052C0: 7E7A0339
	s_wait_alu depctr_va_vcc(0)                                // 0000000052C4: BF88FF9D
	v_dual_cndmask_b32 v17, 0, v107 :: v_dual_cndmask_b32 v16, 0, v106// 0000000052C8: CA52D680 1110D480
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[108:109]                // 0000000052D0: 7CA8D808
	v_mov_b32_e32 v59, v57                                     // 0000000052D4: 7E760339
	s_wait_alu depctr_va_sdst(0)                               // 0000000052D8: BF88F19F
	v_cndmask_b32_e64 v19, 0, v57, s0                          // 0000000052DC: D5010013 00027280
	v_cndmask_b32_e64 v18, 0, v116, s0                         // 0000000052E4: D5010012 0002E880
	v_lshlrev_b64_e32 v[16:17], 2, v[16:17]                    // 0000000052EC: 3E202082
	s_wait_alu depctr_va_vcc(0)                                // 0000000052F0: BF88FF9D
	v_dual_cndmask_b32 v21, 0, v57 :: v_dual_cndmask_b32 v20, 0, v108// 0000000052F4: CA527280 1514D880
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[102:103]                // 0000000052FC: 7CA8CC08
	v_lshlrev_b64_e32 v[18:19], 2, v[18:19]                    // 000000005300: 3E242482
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000005304: BF870214
	v_add_co_u32 v16, s0, s12, v16                             // 000000005308: D7000010 0202200C
	v_lshlrev_b64_e32 v[20:21], 2, v[20:21]                    // 000000005310: 3E282882
	s_wait_alu depctr_va_sdst(0)                               // 000000005314: BF88F19F
	v_add_co_ci_u32_e64 v17, null, s13, v17, s0                // 000000005318: D5207C11 0002220D
	s_wait_alu depctr_va_vcc(0)                                // 000000005320: BF88FF9D
	v_dual_cndmask_b32 v23, 0, v57 :: v_dual_cndmask_b32 v22, 0, v102// 000000005324: CA527280 1716CC80
	v_add_co_u32 v18, s0, s12, v18                             // 00000000532C: D7000012 0202240C
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[62:63]                  // 000000005334: 7CA87C08
	v_add_co_u32 v24, s1, s12, v20                             // 000000005338: D7000118 0202280C
	s_wait_alu depctr_va_sdst(0)                               // 000000005340: BF88F19F
	v_add_co_ci_u32_e64 v19, null, s13, v19, s0                // 000000005344: D5207C13 0002260D
	v_cmp_gt_i64_e64 s0, s[8:9], v[60:61]                      // 00000000534C: D4540000 02027808
	v_add_co_ci_u32_e64 v25, null, s13, v21, s1                // 000000005354: D5207C19 00062A0D
	v_lshlrev_b64_e32 v[20:21], 2, v[22:23]                    // 00000000535C: 3E282C82
	s_wait_alu depctr_va_vcc(0)                                // 000000005360: BF88FF9D
	v_dual_cndmask_b32 v23, 0, v57 :: v_dual_cndmask_b32 v22, 0, v62// 000000005364: CA527280 17167C80
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[58:59]                  // 00000000536C: 7CA87408
	s_wait_alu depctr_va_sdst(0)                               // 000000005370: BF88F19F
	v_cndmask_b32_e64 v27, 0, v57, s0                          // 000000005374: D501001B 00027280
	v_cndmask_b32_e64 v26, 0, v60, s0                          // 00000000537C: D501001A 00027880
	v_add_co_u32 v28, s0, s12, v20                             // 000000005384: D700001C 0202280C
	s_wait_alu depctr_va_sdst(0)                               // 00000000538C: BF88F19F
	v_add_co_ci_u32_e64 v29, null, s13, v21, s0                // 000000005390: D5207C1D 00022A0D
	v_lshlrev_b64_e32 v[20:21], 2, v[22:23]                    // 000000005398: 3E282C82
	v_lshlrev_b64_e32 v[22:23], 2, v[26:27]                    // 00000000539C: 3E2C3482
	s_wait_alu depctr_va_vcc(0)                                // 0000000053A0: BF88FF9D
	v_dual_cndmask_b32 v27, 0, v57 :: v_dual_cndmask_b32 v26, 0, v58// 0000000053A4: CA527280 1B1A7480
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[56:57]                  // 0000000053AC: 7CA87008
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000053B0: BF870004
	v_add_co_u32 v30, s0, s12, v20                             // 0000000053B4: D700001E 0202280C
	s_wait_alu depctr_va_sdst(0)                               // 0000000053BC: BF88F19F
	v_add_co_ci_u32_e64 v31, null, s13, v21, s0                // 0000000053C0: D5207C1F 00022A0D
	v_lshlrev_b64_e32 v[20:21], 2, v[26:27]                    // 0000000053C8: 3E283482
	s_wait_alu depctr_va_vcc(0)                                // 0000000053CC: BF88FF9D
	v_dual_cndmask_b32 v27, 0, v57 :: v_dual_cndmask_b32 v26, 0, v56// 0000000053D0: CA527280 1B1A7080
	v_add_co_u32 v32, vcc_lo, s12, v22                         // 0000000053D8: D7006A20 02022C0C
	s_wait_alu depctr_va_vcc(0)                                // 0000000053E0: BF88FF9D
	v_add_co_ci_u32_e64 v33, null, s13, v23, vcc_lo            // 0000000053E4: D5207C21 01AA2E0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000053EC: BF8701C3
	v_lshlrev_b64_e32 v[22:23], 2, v[26:27]                    // 0000000053F0: 3E2C3482
	v_add_co_u32 v26, vcc_lo, s12, v20                         // 0000000053F4: D7006A1A 0202280C
	s_wait_alu depctr_va_vcc(0)                                // 0000000053FC: BF88FF9D
	v_add_co_ci_u32_e64 v27, null, s13, v21, vcc_lo            // 000000005400: D5207C1B 01AA2A0D
	v_add_co_u32 v34, vcc_lo, s12, v22                         // 000000005408: D7006A22 02022C0C
	s_wait_alu depctr_va_vcc(0)                                // 000000005410: BF88FF9D
	v_add_co_ci_u32_e64 v35, null, s13, v23, vcc_lo            // 000000005414: D5207C23 01AA2E0D
	s_clause 0x7                                               // 00000000541C: BF850007
	global_load_b32 v20, v[16:17], off                         // 000000005420: EE05007C 00000014 00000010
	global_load_b32 v21, v[18:19], off                         // 00000000542C: EE05007C 00000015 00000012
	global_load_b32 v22, v[24:25], off                         // 000000005438: EE05007C 00000016 00000018
	global_load_b32 v23, v[28:29], off                         // 000000005444: EE05007C 00000017 0000001C
	global_load_b32 v16, v[30:31], off                         // 000000005450: EE05007C 00000010 0000001E
	global_load_b32 v17, v[32:33], off                         // 00000000545C: EE05007C 00000011 00000020
	global_load_b32 v18, v[26:27], off                         // 000000005468: EE05007C 00000012 0000001A
	global_load_b32 v19, v[34:35], off                         // 000000005474: EE05007C 00000013 00000022
	s_wait_alu depctr_sa_sdst(0)                               // 000000005480: BF88FF9E
	s_and_not1_saveexec_b32 s0, s4                             // 000000005484: BE803004
	s_cbranch_execz 28                                         // 000000005488: BFA5001C <tessera_rocm_folded_matmul_a870cecb1991940b+0x39fc>
	s_wait_loadcnt 0x3                                         // 00000000548C: BFC00003
	v_add_co_u32 v16, s1, s6, v72                              // 000000005490: D7000110 02029006
	s_wait_loadcnt 0x2                                         // 000000005498: BFC00002
	s_wait_alu depctr_va_sdst(0)                               // 00000000549C: BF88F19F
	v_add_co_ci_u32_e64 v17, null, s7, 0, s1                   // 0000000054A0: D5207C11 00050007
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000054A8: BF870122
	v_add_co_u32 v16, vcc_lo, v16, v73                         // 0000000054AC: D7006A10 02029310
	s_wait_alu depctr_va_vcc(0)                                // 0000000054B4: BF88FF9D
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 0000000054B8: D5207C11 01AA2280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000054C0: BF870091
	v_lshlrev_b64_e32 v[16:17], 2, v[16:17]                    // 0000000054C4: 3E202082
	v_add_co_u32 v16, vcc_lo, s12, v16                         // 0000000054C8: D7006A10 0202200C
	s_wait_alu depctr_va_vcc(0)                                // 0000000054D0: BF88FF9D
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000054D4: BF870002
	v_add_co_ci_u32_e64 v17, null, s13, v17, vcc_lo            // 0000000054D8: D5207C11 01AA220D
	global_load_b128 v[20:23], v[16:17], off offset:128        // 0000000054E0: EE05C07C 00000014 00008010
	s_wait_loadcnt 0x1                                         // 0000000054EC: BFC00001
	global_load_b128 v[16:19], v[16:17], off offset:144        // 0000000054F0: EE05C07C 00000010 00009010
	s_wait_alu depctr_sa_sdst(0)                               // 0000000054FC: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005500: 8C7E007E
	global_load_u8 v24, v[75:76], off                          // 000000005504: EE04007C 00000018 0000004B
	s_wait_loadcnt 0x0                                         // 000000005510: BFC00000
	v_lshlrev_b32_e32 v25, 23, v24                             // 000000005514: 30323097
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005518: BF870091
	v_mul_f32_e32 v24, v20, v25                                // 00000000551C: 10303314
	v_cmp_class_f32_e64 s0, v24, 0x198                         // 000000005520: D47E0000 0201FF18 00000198
	v_mul_f32_e32 v24, v8, v24                                 // 00000000552C: 10303108
	s_xor_b32 s1, s0, -1                                       // 000000005530: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005534: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005538: BE802001
	s_cbranch_execnz 1410                                      // 00000000553C: BFA60582 <tessera_rocm_folded_matmul_a870cecb1991940b+0x5048>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005540: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005544: 8C7E007E
	v_mul_f32_e32 v8, v21, v25                                 // 000000005548: 10103315
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000554C: BF870001
	v_cmp_class_f32_e64 s0, v8, 0x198                          // 000000005550: D47E0000 0201FF08 00000198
	v_mul_f32_e32 v8, v9, v8                                   // 00000000555C: 10101109
	s_xor_b32 s1, s0, -1                                       // 000000005560: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005564: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005568: BE802001
	s_cbranch_execnz 1415                                      // 00000000556C: BFA60587 <tessera_rocm_folded_matmul_a870cecb1991940b+0x508c>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005570: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005574: 8C7E007E
	v_mul_f32_e32 v9, v22, v25                                 // 000000005578: 10123316
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000557C: BF870001
	v_cmp_class_f32_e64 s0, v9, 0x198                          // 000000005580: D47E0000 0201FF09 00000198
	v_mul_f32_e32 v9, v10, v9                                  // 00000000558C: 1012130A
	s_xor_b32 s1, s0, -1                                       // 000000005590: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005594: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005598: BE802001
	s_cbranch_execnz 1420                                      // 00000000559C: BFA6058C <tessera_rocm_folded_matmul_a870cecb1991940b+0x50d0>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000055A0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000055A4: 8C7E007E
	v_mul_f32_e32 v10, v23, v25                                // 0000000055A8: 10143317
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000055AC: BF870001
	v_cmp_class_f32_e64 s0, v10, 0x198                         // 0000000055B0: D47E0000 0201FF0A 00000198
	v_mul_f32_e32 v10, v11, v10                                // 0000000055BC: 1014150B
	s_xor_b32 s1, s0, -1                                       // 0000000055C0: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 0000000055C4: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 0000000055C8: BE802001
	s_cbranch_execnz 1425                                      // 0000000055CC: BFA60591 <tessera_rocm_folded_matmul_a870cecb1991940b+0x5114>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000055D0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000055D4: 8C7E007E
	v_mul_f32_e32 v11, v16, v25                                // 0000000055D8: 10163310
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000055DC: BF870001
	v_cmp_class_f32_e64 s0, v11, 0x198                         // 0000000055E0: D47E0000 0201FF0B 00000198
	v_mul_f32_e32 v11, v12, v11                                // 0000000055EC: 1016170C
	s_xor_b32 s1, s0, -1                                       // 0000000055F0: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 0000000055F4: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 0000000055F8: BE802001
	s_cbranch_execnz 1430                                      // 0000000055FC: BFA60596 <tessera_rocm_folded_matmul_a870cecb1991940b+0x5158>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005600: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005604: 8C7E007E
	v_mul_f32_e32 v12, v17, v25                                // 000000005608: 10183311
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000560C: BF870001
	v_cmp_class_f32_e64 s0, v12, 0x198                         // 000000005610: D47E0000 0201FF0C 00000198
	v_mul_f32_e32 v12, v13, v12                                // 00000000561C: 1018190D
	s_xor_b32 s1, s0, -1                                       // 000000005620: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005624: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005628: BE802001
	s_cbranch_execnz 1435                                      // 00000000562C: BFA6059B <tessera_rocm_folded_matmul_a870cecb1991940b+0x519c>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005630: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005634: 8C7E007E
	v_mul_f32_e32 v13, v18, v25                                // 000000005638: 101A3312
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000563C: BF870001
	v_cmp_class_f32_e64 s0, v13, 0x198                         // 000000005640: D47E0000 0201FF0D 00000198
	v_mul_f32_e32 v13, v14, v13                                // 00000000564C: 101A1B0E
	s_xor_b32 s1, s0, -1                                       // 000000005650: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005654: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005658: BE802001
	s_cbranch_execnz 1440                                      // 00000000565C: BFA605A0 <tessera_rocm_folded_matmul_a870cecb1991940b+0x51e0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005660: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005664: 8C7E007E
	v_mul_f32_e32 v14, v19, v25                                // 000000005668: 101C3313
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000566C: BF870001
	v_cmp_class_f32_e64 s0, v14, 0x198                         // 000000005670: D47E0000 0201FF0E 00000198
	v_mul_f32_e32 v14, v15, v14                                // 00000000567C: 101C1D0F
	s_xor_b32 s1, s0, -1                                       // 000000005680: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005684: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005688: BE802001
	s_cbranch_execnz 1445                                      // 00000000568C: BFA605A5 <tessera_rocm_folded_matmul_a870cecb1991940b+0x5224>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005690: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005694: 8C7E007E
	v_bfe_u32 v15, v24, 16, 1                                  // 000000005698: D610000F 02052118
	v_bfe_u32 v16, v8, 16, 1                                   // 0000000056A0: D6100010 02052108
	v_or_b32_e32 v17, 0x400000, v24                            // 0000000056A8: 382230FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v24, v24                           // 0000000056B0: 7C303118
	v_or_b32_e32 v18, 0x400000, v8                             // 0000000056B4: 382410FF 00400000
	v_add3_u32 v15, v15, v24, 0x7fff                           // 0000000056BC: D655000F 03FE310F 00007FFF
	v_add3_u32 v16, v16, v8, 0x7fff                            // 0000000056C8: D6550010 03FE1110 00007FFF
	v_bfe_u32 v19, v9, 16, 1                                   // 0000000056D4: D6100013 02052109
	s_and_b32 s0, s3, s2                                       // 0000000056DC: 8B000203
	s_wait_alu depctr_sa_sdst(0)                               // 0000000056E0: BF88FF9E
	s_and_b32 s0, s22, s0                                      // 0000000056E4: 8B000016
	s_wait_alu depctr_va_vcc(0)                                // 0000000056E8: BF88FF9D
	v_cndmask_b32_e32 v15, v15, v17, vcc_lo                    // 0000000056EC: 021E230F
	v_cmp_u_f32_e32 vcc_lo, v8, v8                             // 0000000056F0: 7C301108
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000056F4: D6100011 0205210B
	s_wait_alu depctr_sa_sdst(0)                               // 0000000056FC: BF88FF9E
	s_xor_b32 s0, s0, -1                                       // 000000005700: 8D00C100
	s_wait_alu depctr_va_vcc(0)                                // 000000005704: BF88FF9D
	v_cndmask_b32_e32 v8, v16, v18, vcc_lo                     // 000000005708: 02102510
	v_bfe_u32 v16, v10, 16, 1                                  // 00000000570C: D6100010 0205210A
	v_add3_u32 v18, v19, v9, 0x7fff                            // 000000005714: D6550012 03FE1313 00007FFF
	s_clause 0x1                                               // 000000005720: BF850001
	global_store_d16_hi_b16 v[130:131], v15, off offset:32     // 000000005724: EE09407C 07800000 00002082
	global_store_d16_hi_b16 v[136:137], v8, off offset:32      // 000000005730: EE09407C 04000000 00002088
	v_or_b32_e32 v8, 0x400000, v9                              // 00000000573C: 381012FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v9, v9                             // 000000005744: 7C301309
	v_add3_u32 v15, v16, v10, 0x7fff                           // 000000005748: D655000F 03FE1510 00007FFF
	v_or_b32_e32 v16, 0x400000, v10                            // 000000005754: 382014FF 00400000
	v_add3_u32 v17, v17, v11, 0x7fff                           // 00000000575C: D6550011 03FE1711 00007FFF
	v_or_b32_e32 v19, 0x400000, v11                            // 000000005768: 382616FF 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000005770: BF88FF9D
	v_cndmask_b32_e32 v8, v18, v8, vcc_lo                      // 000000005774: 02101112
	v_cmp_u_f32_e32 vcc_lo, v10, v10                           // 000000005778: 7C30150A
	global_store_d16_hi_b16 v[138:139], v8, off offset:32      // 00000000577C: EE09407C 04000000 0000208A
	s_wait_alu depctr_va_vcc(0)                                // 000000005788: BF88FF9D
	v_cndmask_b32_e32 v9, v15, v16, vcc_lo                     // 00000000578C: 0212210F
	v_cmp_u_f32_e32 vcc_lo, v11, v11                           // 000000005790: 7C30170B
	v_bfe_u32 v8, v12, 16, 1                                   // 000000005794: D6100008 0205210C
	v_or_b32_e32 v11, 0x400000, v12                            // 00000000579C: 381618FF 00400000
	v_or_b32_e32 v15, 0x400000, v13                            // 0000000057A4: 381E1AFF 00400000
	global_store_d16_hi_b16 v[142:143], v9, off offset:32      // 0000000057AC: EE09407C 04800000 0000208E
	s_wait_alu depctr_va_vcc(0)                                // 0000000057B8: BF88FF9D
	v_cndmask_b32_e32 v10, v17, v19, vcc_lo                    // 0000000057BC: 02142711
	v_bfe_u32 v9, v13, 16, 1                                   // 0000000057C0: D6100009 0205210D
	v_add3_u32 v8, v8, v12, 0x7fff                             // 0000000057C8: D6550008 03FE1908 00007FFF
	v_cmp_u_f32_e32 vcc_lo, v12, v12                           // 0000000057D4: 7C30190C
	v_or_b32_e32 v16, 0x400000, v14                            // 0000000057D8: 38201CFF 00400000
	global_store_d16_hi_b16 v[146:147], v10, off offset:32     // 0000000057E0: EE09407C 05000000 00002092
	v_bfe_u32 v10, v14, 16, 1                                  // 0000000057EC: D610000A 0205210E
	v_add3_u32 v9, v9, v13, 0x7fff                             // 0000000057F4: D6550009 03FE1B09 00007FFF
	s_wait_alu depctr_va_vcc(0)                                // 000000005800: BF88FF9D
	v_cndmask_b32_e32 v8, v8, v11, vcc_lo                      // 000000005804: 02101708
	v_cmp_u_f32_e32 vcc_lo, v13, v13                           // 000000005808: 7C301B0D
	v_add3_u32 v10, v10, v14, 0x7fff                           // 00000000580C: D655000A 03FE1D0A 00007FFF
	global_store_d16_hi_b16 v[144:145], v8, off offset:32      // 000000005818: EE09407C 04000000 00002090
	s_wait_alu depctr_va_vcc(0)                                // 000000005824: BF88FF9D
	v_cndmask_b32_e32 v9, v9, v15, vcc_lo                      // 000000005828: 02121F09
	v_cmp_u_f32_e32 vcc_lo, v14, v14                           // 00000000582C: 7C301D0E
	global_store_d16_hi_b16 v[148:149], v9, off offset:32      // 000000005830: EE09407C 04800000 00002094
	s_wait_alu depctr_va_vcc(0)                                // 00000000583C: BF88FF9D
	v_cndmask_b32_e32 v10, v10, v16, vcc_lo                    // 000000005840: 0214210A
	global_store_d16_hi_b16 v[150:151], v10, off offset:32     // 000000005844: EE09407C 05000000 00002096
	s_wait_alu depctr_sa_sdst(0)                               // 000000005850: BF88FF9E
	s_and_saveexec_b32 s1, s0                                  // 000000005854: BE812000
	s_wait_alu depctr_sa_sdst(0)                               // 000000005858: BF88FF9E
	s_xor_b32 s2, exec_lo, s1                                  // 00000000585C: 8D02017E
	s_cbranch_execz 119                                        // 000000005860: BFA50077 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3f40>
	v_mov_b32_e32 v141, v49                                    // 000000005864: 7F1A0331
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[132:133]                // 000000005868: 7CA90808
	v_mov_b32_e32 v135, v49                                    // 00000000586C: 7F0E0331
	v_mov_b32_e32 v129, v49                                    // 000000005870: 7F020331
	v_mov_b32_e32 v55, v49                                     // 000000005874: 7E6E0331
	v_cmp_gt_i64_e64 s0, s[8:9], v[140:141]                    // 000000005878: D4540000 02031808
	v_mov_b32_e32 v53, v49                                     // 000000005880: 7E6A0331
	s_wait_alu depctr_va_vcc(0)                                // 000000005884: BF88FF9D
	v_dual_cndmask_b32 v9, 0, v133 :: v_dual_cndmask_b32 v8, 0, v132// 000000005888: CA530A80 09090880
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[134:135]                // 000000005890: 7CA90C08
	v_mov_b32_e32 v51, v49                                     // 000000005894: 7E660331
	s_wait_alu depctr_va_sdst(0)                               // 000000005898: BF88F19F
	v_cndmask_b32_e64 v11, 0, v49, s0                          // 00000000589C: D501000B 00026280
	v_cndmask_b32_e64 v10, 0, v140, s0                         // 0000000058A4: D501000A 00031880
	v_lshlrev_b64_e32 v[8:9], 2, v[8:9]                        // 0000000058AC: 3E101082
	s_wait_alu depctr_va_vcc(0)                                // 0000000058B0: BF88FF9D
	v_dual_cndmask_b32 v13, 0, v49 :: v_dual_cndmask_b32 v12, 0, v134// 0000000058B4: CA526280 0D0D0C80
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[128:129]                // 0000000058BC: 7CA90008
	v_lshlrev_b64_e32 v[10:11], 2, v[10:11]                    // 0000000058C0: 3E141482
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000058C4: BF870214
	v_add_co_u32 v8, s0, s12, v8                               // 0000000058C8: D7000008 0202100C
	v_lshlrev_b64_e32 v[12:13], 2, v[12:13]                    // 0000000058D0: 3E181882
	s_wait_alu depctr_va_sdst(0)                               // 0000000058D4: BF88F19F
	v_add_co_ci_u32_e64 v9, null, s13, v9, s0                  // 0000000058D8: D5207C09 0002120D
	s_wait_alu depctr_va_vcc(0)                                // 0000000058E0: BF88FF9D
	v_dual_cndmask_b32 v15, 0, v49 :: v_dual_cndmask_b32 v14, 0, v128// 0000000058E4: CA526280 0F0F0080
	v_add_co_u32 v10, s0, s12, v10                             // 0000000058EC: D700000A 0202140C
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[54:55]                  // 0000000058F4: 7CA86C08
	v_add_co_u32 v16, s1, s12, v12                             // 0000000058F8: D7000110 0202180C
	s_wait_alu depctr_va_sdst(0)                               // 000000005900: BF88F19F
	v_add_co_ci_u32_e64 v11, null, s13, v11, s0                // 000000005904: D5207C0B 0002160D
	v_cmp_gt_i64_e64 s0, s[8:9], v[52:53]                      // 00000000590C: D4540000 02026808
	v_add_co_ci_u32_e64 v17, null, s13, v13, s1                // 000000005914: D5207C11 00061A0D
	v_lshlrev_b64_e32 v[12:13], 2, v[14:15]                    // 00000000591C: 3E181C82
	s_wait_alu depctr_va_vcc(0)                                // 000000005920: BF88FF9D
	v_dual_cndmask_b32 v15, 0, v49 :: v_dual_cndmask_b32 v14, 0, v54// 000000005924: CA526280 0F0E6C80
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[50:51]                  // 00000000592C: 7CA86408
	s_wait_alu depctr_va_sdst(0)                               // 000000005930: BF88F19F
	v_cndmask_b32_e64 v19, 0, v49, s0                          // 000000005934: D5010013 00026280
	v_cndmask_b32_e64 v18, 0, v52, s0                          // 00000000593C: D5010012 00026880
	v_add_co_u32 v20, s0, s12, v12                             // 000000005944: D7000014 0202180C
	s_wait_alu depctr_va_sdst(0)                               // 00000000594C: BF88F19F
	v_add_co_ci_u32_e64 v21, null, s13, v13, s0                // 000000005950: D5207C15 00021A0D
	v_lshlrev_b64_e32 v[12:13], 2, v[14:15]                    // 000000005958: 3E181C82
	v_lshlrev_b64_e32 v[14:15], 2, v[18:19]                    // 00000000595C: 3E1C2482
	s_wait_alu depctr_va_vcc(0)                                // 000000005960: BF88FF9D
	v_dual_cndmask_b32 v19, 0, v49 :: v_dual_cndmask_b32 v18, 0, v50// 000000005964: CA526280 13126480
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[48:49]                  // 00000000596C: 7CA86008
	s_delay_alu instid0(VALU_DEP_4)                            // 000000005970: BF870004
	v_add_co_u32 v22, s0, s12, v12                             // 000000005974: D7000016 0202180C
	s_wait_alu depctr_va_sdst(0)                               // 00000000597C: BF88F19F
	v_add_co_ci_u32_e64 v23, null, s13, v13, s0                // 000000005980: D5207C17 00021A0D
	v_lshlrev_b64_e32 v[12:13], 2, v[18:19]                    // 000000005988: 3E182482
	s_wait_alu depctr_va_vcc(0)                                // 00000000598C: BF88FF9D
	v_dual_cndmask_b32 v19, 0, v49 :: v_dual_cndmask_b32 v18, 0, v48// 000000005990: CA526280 13126080
	v_add_co_u32 v24, vcc_lo, s12, v14                         // 000000005998: D7006A18 02021C0C
	s_wait_alu depctr_va_vcc(0)                                // 0000000059A0: BF88FF9D
	v_add_co_ci_u32_e64 v25, null, s13, v15, vcc_lo            // 0000000059A4: D5207C19 01AA1E0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000059AC: BF8701C3
	v_lshlrev_b64_e32 v[14:15], 2, v[18:19]                    // 0000000059B0: 3E1C2482
	v_add_co_u32 v18, vcc_lo, s12, v12                         // 0000000059B4: D7006A12 0202180C
	s_wait_alu depctr_va_vcc(0)                                // 0000000059BC: BF88FF9D
	v_add_co_ci_u32_e64 v19, null, s13, v13, vcc_lo            // 0000000059C0: D5207C13 01AA1A0D
	v_add_co_u32 v26, vcc_lo, s12, v14                         // 0000000059C8: D7006A1A 02021C0C
	s_wait_alu depctr_va_vcc(0)                                // 0000000059D0: BF88FF9D
	v_add_co_ci_u32_e64 v27, null, s13, v15, vcc_lo            // 0000000059D4: D5207C1B 01AA1E0D
	s_clause 0x7                                               // 0000000059DC: BF850007
	global_load_b32 v12, v[8:9], off                           // 0000000059E0: EE05007C 0000000C 00000008
	global_load_b32 v13, v[10:11], off                         // 0000000059EC: EE05007C 0000000D 0000000A
	global_load_b32 v14, v[16:17], off                         // 0000000059F8: EE05007C 0000000E 00000010
	global_load_b32 v15, v[20:21], off                         // 000000005A04: EE05007C 0000000F 00000014
	global_load_b32 v8, v[22:23], off                          // 000000005A10: EE05007C 00000008 00000016
	global_load_b32 v9, v[24:25], off                          // 000000005A1C: EE05007C 00000009 00000018
	global_load_b32 v10, v[18:19], off                         // 000000005A28: EE05007C 0000000A 00000012
	global_load_b32 v11, v[26:27], off                         // 000000005A34: EE05007C 0000000B 0000001A
	s_wait_alu depctr_sa_sdst(0)                               // 000000005A40: BF88FF9E
	s_and_not1_saveexec_b32 s0, s2                             // 000000005A44: BE803002
	s_cbranch_execz 28                                         // 000000005A48: BFA5001C <tessera_rocm_folded_matmul_a870cecb1991940b+0x3fbc>
	s_wait_loadcnt 0x3                                         // 000000005A4C: BFC00003
	v_add_co_u32 v8, s1, s6, v72                               // 000000005A50: D7000108 02029006
	s_wait_loadcnt 0x2                                         // 000000005A58: BFC00002
	s_wait_alu depctr_va_sdst(0)                               // 000000005A5C: BF88F19F
	v_add_co_ci_u32_e64 v9, null, s7, 0, s1                    // 000000005A60: D5207C09 00050007
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000005A68: BF870122
	v_add_co_u32 v8, vcc_lo, v8, v73                           // 000000005A6C: D7006A08 02029308
	s_wait_alu depctr_va_vcc(0)                                // 000000005A74: BF88FF9D
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 000000005A78: D5207C09 01AA1280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005A80: BF870091
	v_lshlrev_b64_e32 v[8:9], 2, v[8:9]                        // 000000005A84: 3E101082
	v_add_co_u32 v8, vcc_lo, s12, v8                           // 000000005A88: D7006A08 0202100C
	s_wait_alu depctr_va_vcc(0)                                // 000000005A90: BF88FF9D
	s_delay_alu instid0(VALU_DEP_2)                            // 000000005A94: BF870002
	v_add_co_ci_u32_e64 v9, null, s13, v9, vcc_lo              // 000000005A98: D5207C09 01AA120D
	global_load_b128 v[12:15], v[8:9], off offset:192          // 000000005AA0: EE05C07C 0000000C 0000C008
	s_wait_loadcnt 0x1                                         // 000000005AAC: BFC00001
	global_load_b128 v[8:11], v[8:9], off offset:208           // 000000005AB0: EE05C07C 00000008 0000D008
	s_wait_alu depctr_sa_sdst(0)                               // 000000005ABC: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005AC0: 8C7E007E
	global_load_u8 v16, v[75:76], off                          // 000000005AC4: EE04007C 00000010 0000004B
	s_wait_loadcnt 0x0                                         // 000000005AD0: BFC00000
	v_lshlrev_b32_e32 v17, 23, v16                             // 000000005AD4: 30222097
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005AD8: BF870091
	v_mul_f32_e32 v16, v12, v17                                // 000000005ADC: 1020230C
	v_cmp_class_f32_e64 s0, v16, 0x198                         // 000000005AE0: D47E0000 0201FF10 00000198
	v_mul_f32_e32 v16, v0, v16                                 // 000000005AEC: 10202100
	s_xor_b32 s1, s0, -1                                       // 000000005AF0: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005AF4: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005AF8: BE802001
	s_cbranch_execnz 1178                                      // 000000005AFC: BFA6049A <tessera_rocm_folded_matmul_a870cecb1991940b+0x5268>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005B00: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005B04: 8C7E007E
	v_mul_f32_e32 v0, v13, v17                                 // 000000005B08: 1000230D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005B0C: BF870001
	v_cmp_class_f32_e64 s0, v0, 0x198                          // 000000005B10: D47E0000 0201FF00 00000198
	v_mul_f32_e32 v0, v1, v0                                   // 000000005B1C: 10000101
	s_xor_b32 s1, s0, -1                                       // 000000005B20: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005B24: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005B28: BE802001
	s_cbranch_execnz 1183                                      // 000000005B2C: BFA6049F <tessera_rocm_folded_matmul_a870cecb1991940b+0x52ac>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005B30: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005B34: 8C7E007E
	v_mul_f32_e32 v1, v14, v17                                 // 000000005B38: 1002230E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005B3C: BF870001
	v_cmp_class_f32_e64 s0, v1, 0x198                          // 000000005B40: D47E0000 0201FF01 00000198
	v_mul_f32_e32 v1, v2, v1                                   // 000000005B4C: 10020302
	s_xor_b32 s1, s0, -1                                       // 000000005B50: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005B54: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005B58: BE802001
	s_cbranch_execnz 1188                                      // 000000005B5C: BFA604A4 <tessera_rocm_folded_matmul_a870cecb1991940b+0x52f0>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005B60: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005B64: 8C7E007E
	v_mul_f32_e32 v2, v15, v17                                 // 000000005B68: 1004230F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005B6C: BF870001
	v_cmp_class_f32_e64 s0, v2, 0x198                          // 000000005B70: D47E0000 0201FF02 00000198
	v_mul_f32_e32 v2, v3, v2                                   // 000000005B7C: 10040503
	s_xor_b32 s1, s0, -1                                       // 000000005B80: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005B84: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005B88: BE802001
	s_cbranch_execnz 1193                                      // 000000005B8C: BFA604A9 <tessera_rocm_folded_matmul_a870cecb1991940b+0x5334>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005B90: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005B94: 8C7E007E
	v_mul_f32_e32 v3, v8, v17                                  // 000000005B98: 10062308
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005B9C: BF870001
	v_cmp_class_f32_e64 s0, v3, 0x198                          // 000000005BA0: D47E0000 0201FF03 00000198
	v_mul_f32_e32 v3, v4, v3                                   // 000000005BAC: 10060704
	s_xor_b32 s1, s0, -1                                       // 000000005BB0: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005BB4: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005BB8: BE802001
	s_cbranch_execnz 1198                                      // 000000005BBC: BFA604AE <tessera_rocm_folded_matmul_a870cecb1991940b+0x5378>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005BC0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005BC4: 8C7E007E
	v_mul_f32_e32 v4, v9, v17                                  // 000000005BC8: 10082309
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005BCC: BF870001
	v_cmp_class_f32_e64 s0, v4, 0x198                          // 000000005BD0: D47E0000 0201FF04 00000198
	v_mul_f32_e32 v4, v5, v4                                   // 000000005BDC: 10080905
	s_xor_b32 s1, s0, -1                                       // 000000005BE0: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005BE4: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005BE8: BE802001
	s_cbranch_execnz 1203                                      // 000000005BEC: BFA604B3 <tessera_rocm_folded_matmul_a870cecb1991940b+0x53bc>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005BF0: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005BF4: 8C7E007E
	v_mul_f32_e32 v5, v10, v17                                 // 000000005BF8: 100A230A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005BFC: BF870001
	v_cmp_class_f32_e64 s0, v5, 0x198                          // 000000005C00: D47E0000 0201FF05 00000198
	v_mul_f32_e32 v5, v6, v5                                   // 000000005C0C: 100A0B06
	s_xor_b32 s1, s0, -1                                       // 000000005C10: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005C14: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005C18: BE802001
	s_cbranch_execnz 1208                                      // 000000005C1C: BFA604B8 <tessera_rocm_folded_matmul_a870cecb1991940b+0x5400>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005C20: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005C24: 8C7E007E
	v_mul_f32_e32 v6, v11, v17                                 // 000000005C28: 100C230B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005C2C: BF870001
	v_cmp_class_f32_e64 s0, v6, 0x198                          // 000000005C30: D47E0000 0201FF06 00000198
	v_mul_f32_e32 v6, v7, v6                                   // 000000005C3C: 100C0D07
	s_xor_b32 s1, s0, -1                                       // 000000005C40: 8D01C100
	s_wait_alu depctr_sa_sdst(0)                               // 000000005C44: BF88FF9E
	s_and_saveexec_b32 s0, s1                                  // 000000005C48: BE802001
	s_cbranch_execnz 1213                                      // 000000005C4C: BFA604BD <tessera_rocm_folded_matmul_a870cecb1991940b+0x5444>
	s_wait_alu depctr_sa_sdst(0)                               // 000000005C50: BF88FF9E
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005C54: 8C7E007E
	v_bfe_u32 v7, v16, 16, 1                                   // 000000005C58: D6100007 02052110
	v_or_b32_e32 v8, 0x400000, v16                             // 000000005C60: 381020FF 00400000
	v_bfe_u32 v9, v0, 16, 1                                    // 000000005C68: D6100009 02052100
	v_cmp_u_f32_e32 vcc_lo, v16, v16                           // 000000005C70: 7C302110
	v_or_b32_e32 v10, 0x400000, v0                             // 000000005C74: 381400FF 00400000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000005C7C: D6550007 03FE2107 00007FFF
	v_bfe_u32 v11, v1, 16, 1                                   // 000000005C88: D610000B 02052101
	v_add3_u32 v9, v9, v0, 0x7fff                              // 000000005C90: D6550009 03FE0109 00007FFF
	v_or_b32_e32 v12, 0x400000, v1                             // 000000005C9C: 381802FF 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000005CA4: BF88FF9D
	v_cndmask_b32_e32 v7, v7, v8, vcc_lo                       // 000000005CA8: 020E1107
	v_cmp_u_f32_e32 vcc_lo, v0, v0                             // 000000005CAC: 7C300100
	v_bfe_u32 v8, v2, 16, 1                                    // 000000005CB0: D6100008 02052102
	v_add3_u32 v11, v11, v1, 0x7fff                            // 000000005CB8: D655000B 03FE030B 00007FFF
	global_store_d16_hi_b16 v[44:45], v7, off offset:32        // 000000005CC4: EE09407C 03800000 0000202C
	s_wait_alu depctr_va_vcc(0)                                // 000000005CD0: BF88FF9D
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 000000005CD4: 02001509
	v_cmp_u_f32_e32 vcc_lo, v1, v1                             // 000000005CD8: 7C300301
	v_bfe_u32 v7, v3, 16, 1                                    // 000000005CDC: D6100007 02052103
	v_or_b32_e32 v9, 0x400000, v5                              // 000000005CE4: 38120AFF 00400000
	v_or_b32_e32 v10, 0x400000, v6                             // 000000005CEC: 38140CFF 00400000
	global_store_d16_hi_b16 v[42:43], v0, off offset:32        // 000000005CF4: EE09407C 00000000 0000202A
	s_wait_alu depctr_va_vcc(0)                                // 000000005D00: BF88FF9D
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                     // 000000005D04: 0202190B
	v_add3_u32 v0, v8, v2, 0x7fff                              // 000000005D08: D6550000 03FE0508 00007FFF
	v_or_b32_e32 v8, 0x400000, v2                              // 000000005D14: 381004FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v2, v2                             // 000000005D1C: 7C300502
	v_bfe_u32 v2, v4, 16, 1                                    // 000000005D20: D6100002 02052104
	global_store_d16_hi_b16 v[152:153], v1, off offset:32      // 000000005D28: EE09407C 00800000 00002098
	v_add3_u32 v1, v7, v3, 0x7fff                              // 000000005D34: D6550001 03FE0707 00007FFF
	v_or_b32_e32 v7, 0x400000, v3                              // 000000005D40: 380E06FF 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000005D48: BF88FF9D
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 000000005D4C: 02001100
	v_cmp_u_f32_e32 vcc_lo, v3, v3                             // 000000005D50: 7C300703
	v_bfe_u32 v8, v5, 16, 1                                    // 000000005D54: D6100008 02052105
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000005D5C: D6550002 03FE0902 00007FFF
	v_bfe_u32 v3, v6, 16, 1                                    // 000000005D68: D6100003 02052106
	s_wait_alu depctr_va_vcc(0)                                // 000000005D70: BF88FF9D
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 000000005D74: 02020F01
	v_or_b32_e32 v7, 0x400000, v4                              // 000000005D78: 380E08FF 00400000
	v_cmp_u_f32_e32 vcc_lo, v4, v4                             // 000000005D80: 7C300904
	v_add3_u32 v8, v8, v5, 0x7fff                              // 000000005D84: D6550008 03FE0B08 00007FFF
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000005D90: D6550003 03FE0D03 00007FFF
	s_wait_alu depctr_va_vcc(0)                                // 000000005D9C: BF88FF9D
	v_cndmask_b32_e32 v2, v2, v7, vcc_lo                       // 000000005DA0: 02040F02
	v_cmp_u_f32_e32 vcc_lo, v5, v5                             // 000000005DA4: 7C300B05
	s_wait_alu depctr_va_vcc(0)                                // 000000005DA8: BF88FF9D
	v_cndmask_b32_e32 v4, v8, v9, vcc_lo                       // 000000005DAC: 02081308
	v_cmp_u_f32_e32 vcc_lo, v6, v6                             // 000000005DB0: 7C300D06
	s_wait_alu depctr_va_vcc(0)                                // 000000005DB4: BF88FF9D
	v_cndmask_b32_e32 v3, v3, v10, vcc_lo                      // 000000005DB8: 02061503
	s_clause 0x3                                               // 000000005DBC: BF850003
	global_store_d16_hi_b16 v[40:41], v0, off offset:32        // 000000005DC0: EE09407C 00000000 00002028
	global_store_d16_hi_b16 v[46:47], v1, off offset:32        // 000000005DCC: EE09407C 00800000 0000202E
	global_store_d16_hi_b16 v[154:155], v2, off offset:32      // 000000005DD8: EE09407C 01000000 0000209A
	global_store_d16_hi_b16 v[156:157], v4, off offset:32      // 000000005DE4: EE09407C 02000000 0000209C
	global_store_d16_hi_b16 v[158:159], v3, off offset:32      // 000000005DF0: EE09407C 01800000 0000209E
	s_nop 0                                                    // 000000005DFC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000005E00: BFB60003
	s_endpgm                                                   // 000000005E04: BFB00000
	v_cvt_f64_f32_e32 v[83:84], v56                            // 000000005E08: 7EA62138
	v_cvt_f64_f32_e32 v[85:86], v82                            // 000000005E0C: 7EAA2152
	v_cvt_f64_f32_e32 v[87:88], v68                            // 000000005E10: 7EAE2144
	v_cmp_eq_f32_e64 s2, 0, v56                                // 000000005E14: D4120002 02027080
	v_cmp_class_f32_e64 s5, v68, 0x1f8                         // 000000005E1C: D47E0005 0201FF44 000001F8
	s_and_b32 s2, s2, s5                                       // 000000005E28: 8B020502
	v_mul_f64_e32 v[83:84], v[83:84], v[85:86]                 // 000000005E2C: 0CA6AB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005E30: BF870091
	v_mul_f64_e32 v[83:84], v[83:84], v[87:88]                 // 000000005E34: 0CA6AF53
	v_cvt_f32_f64_e32 v81, v[83:84]                            // 000000005E38: 7EA21F53
	s_wait_alu depctr_sa_sdst(0)                               // 000000005E3C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005E40: BF870001
	v_cndmask_b32_e64 v81, v81, 0, s2                          // 000000005E44: D5010051 00090151
	s_branch 62191                                             // 000000005E4C: BFA0F2EF <tessera_rocm_folded_matmul_a870cecb1991940b+0xf0c>
	v_cvt_f64_f32_e32 v[83:84], v57                            // 000000005E50: 7EA62139
	v_cvt_f64_f32_e32 v[85:86], v82                            // 000000005E54: 7EAA2152
	v_cvt_f64_f32_e32 v[87:88], v69                            // 000000005E58: 7EAE2145
	v_cmp_eq_f32_e64 s2, 0, v57                                // 000000005E5C: D4120002 02027280
	v_cmp_class_f32_e64 s5, v69, 0x1f8                         // 000000005E64: D47E0005 0201FF45 000001F8
	s_and_b32 s2, s2, s5                                       // 000000005E70: 8B020502
	v_mul_f64_e32 v[83:84], v[83:84], v[85:86]                 // 000000005E74: 0CA6AB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005E78: BF870091
	v_mul_f64_e32 v[83:84], v[83:84], v[87:88]                 // 000000005E7C: 0CA6AF53
	v_cvt_f32_f64_e32 v56, v[83:84]                            // 000000005E80: 7E701F53
	s_wait_alu depctr_sa_sdst(0)                               // 000000005E84: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005E88: BF870001
	v_cndmask_b32_e64 v56, v56, 0, s2                          // 000000005E8C: D5010038 00090138
	s_branch 62185                                             // 000000005E94: BFA0F2E9 <tessera_rocm_folded_matmul_a870cecb1991940b+0xf3c>
	v_cvt_f64_f32_e32 v[68:69], v58                            // 000000005E98: 7E88213A
	v_cvt_f64_f32_e32 v[83:84], v82                            // 000000005E9C: 7EA62152
	v_cvt_f64_f32_e32 v[85:86], v70                            // 000000005EA0: 7EAA2146
	v_cmp_eq_f32_e64 s2, 0, v58                                // 000000005EA4: D4120002 02027480
	v_cmp_class_f32_e64 s5, v70, 0x1f8                         // 000000005EAC: D47E0005 0201FF46 000001F8
	s_and_b32 s2, s2, s5                                       // 000000005EB8: 8B020502
	v_mul_f64_e32 v[68:69], v[68:69], v[83:84]                 // 000000005EBC: 0C88A744
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005EC0: BF870091
	v_mul_f64_e32 v[68:69], v[68:69], v[85:86]                 // 000000005EC4: 0C88AB44
	v_cvt_f32_f64_e32 v57, v[68:69]                            // 000000005EC8: 7E721F44
	s_wait_alu depctr_sa_sdst(0)                               // 000000005ECC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005ED0: BF870001
	v_cndmask_b32_e64 v57, v57, 0, s2                          // 000000005ED4: D5010039 00090139
	s_branch 62179                                             // 000000005EDC: BFA0F2E3 <tessera_rocm_folded_matmul_a870cecb1991940b+0xf6c>
	v_cvt_f64_f32_e32 v[68:69], v59                            // 000000005EE0: 7E88213B
	v_cvt_f64_f32_e32 v[83:84], v82                            // 000000005EE4: 7EA62152
	v_cvt_f64_f32_e32 v[85:86], v71                            // 000000005EE8: 7EAA2147
	v_cmp_eq_f32_e64 s2, 0, v59                                // 000000005EEC: D4120002 02027680
	v_cmp_class_f32_e64 s5, v71, 0x1f8                         // 000000005EF4: D47E0005 0201FF47 000001F8
	s_and_b32 s2, s2, s5                                       // 000000005F00: 8B020502
	v_mul_f64_e32 v[68:69], v[68:69], v[83:84]                 // 000000005F04: 0C88A744
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005F08: BF870091
	v_mul_f64_e32 v[68:69], v[68:69], v[85:86]                 // 000000005F0C: 0C88AB44
	v_cvt_f32_f64_e32 v58, v[68:69]                            // 000000005F10: 7E741F44
	s_wait_alu depctr_sa_sdst(0)                               // 000000005F14: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005F18: BF870001
	v_cndmask_b32_e64 v58, v58, 0, s2                          // 000000005F1C: D501003A 0009013A
	s_branch 62173                                             // 000000005F24: BFA0F2DD <tessera_rocm_folded_matmul_a870cecb1991940b+0xf9c>
	v_cvt_f64_f32_e32 v[68:69], v60                            // 000000005F28: 7E88213C
	v_cvt_f64_f32_e32 v[70:71], v82                            // 000000005F2C: 7E8C2152
	v_cvt_f64_f32_e32 v[83:84], v64                            // 000000005F30: 7EA62140
	v_cmp_eq_f32_e64 s2, 0, v60                                // 000000005F34: D4120002 02027880
	v_cmp_class_f32_e64 s5, v64, 0x1f8                         // 000000005F3C: D47E0005 0201FF40 000001F8
	s_and_b32 s2, s2, s5                                       // 000000005F48: 8B020502
	v_mul_f64_e32 v[68:69], v[68:69], v[70:71]                 // 000000005F4C: 0C888D44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005F50: BF870091
	v_mul_f64_e32 v[68:69], v[68:69], v[83:84]                 // 000000005F54: 0C88A744
	v_cvt_f32_f64_e32 v59, v[68:69]                            // 000000005F58: 7E761F44
	s_wait_alu depctr_sa_sdst(0)                               // 000000005F5C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005F60: BF870001
	v_cndmask_b32_e64 v59, v59, 0, s2                          // 000000005F64: D501003B 0009013B
	s_branch 62167                                             // 000000005F6C: BFA0F2D7 <tessera_rocm_folded_matmul_a870cecb1991940b+0xfcc>
	v_cvt_f64_f32_e32 v[68:69], v61                            // 000000005F70: 7E88213D
	v_cvt_f64_f32_e32 v[70:71], v82                            // 000000005F74: 7E8C2152
	v_cvt_f64_f32_e32 v[83:84], v65                            // 000000005F78: 7EA62141
	v_cmp_eq_f32_e64 s2, 0, v61                                // 000000005F7C: D4120002 02027A80
	v_cmp_class_f32_e64 s5, v65, 0x1f8                         // 000000005F84: D47E0005 0201FF41 000001F8
	s_and_b32 s2, s2, s5                                       // 000000005F90: 8B020502
	v_mul_f64_e32 v[68:69], v[68:69], v[70:71]                 // 000000005F94: 0C888D44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005F98: BF870091
	v_mul_f64_e32 v[68:69], v[68:69], v[83:84]                 // 000000005F9C: 0C88A744
	v_cvt_f32_f64_e32 v60, v[68:69]                            // 000000005FA0: 7E781F44
	s_wait_alu depctr_sa_sdst(0)                               // 000000005FA4: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005FA8: BF870001
	v_cndmask_b32_e64 v68, v60, 0, s2                          // 000000005FAC: D5010044 0009013C
	s_branch 62161                                             // 000000005FB4: BFA0F2D1 <tessera_rocm_folded_matmul_a870cecb1991940b+0xffc>
	v_cvt_f64_f32_e32 v[60:61], v62                            // 000000005FB8: 7E78213E
	v_cvt_f64_f32_e32 v[64:65], v82                            // 000000005FBC: 7E802152
	v_cvt_f64_f32_e32 v[69:70], v66                            // 000000005FC0: 7E8A2142
	v_cmp_eq_f32_e64 s2, 0, v62                                // 000000005FC4: D4120002 02027C80
	v_cmp_class_f32_e64 s5, v66, 0x1f8                         // 000000005FCC: D47E0005 0201FF42 000001F8
	s_and_b32 s2, s2, s5                                       // 000000005FD8: 8B020502
	v_mul_f64_e32 v[60:61], v[60:61], v[64:65]                 // 000000005FDC: 0C78813C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000005FE0: BF870091
	v_mul_f64_e32 v[60:61], v[60:61], v[69:70]                 // 000000005FE4: 0C788B3C
	v_cvt_f32_f64_e32 v60, v[60:61]                            // 000000005FE8: 7E781F3C
	s_wait_alu depctr_sa_sdst(0)                               // 000000005FEC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000005FF0: BF870001
	v_cndmask_b32_e64 v61, v60, 0, s2                          // 000000005FF4: D501003D 0009013C
	s_branch 62155                                             // 000000005FFC: BFA0F2CB <tessera_rocm_folded_matmul_a870cecb1991940b+0x102c>
	v_cvt_f64_f32_e32 v[64:65], v63                            // 000000006000: 7E80213F
	v_cvt_f64_f32_e32 v[69:70], v82                            // 000000006004: 7E8A2152
	v_cvt_f64_f32_e32 v[82:83], v67                            // 000000006008: 7EA42143
	v_cmp_eq_f32_e64 s2, 0, v63                                // 00000000600C: D4120002 02027E80
	v_cmp_class_f32_e64 s5, v67, 0x1f8                         // 000000006014: D47E0005 0201FF43 000001F8
	s_and_b32 s2, s2, s5                                       // 000000006020: 8B020502
	v_mul_f64_e32 v[64:65], v[64:65], v[69:70]                 // 000000006024: 0C808B40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006028: BF870091
	v_mul_f64_e32 v[64:65], v[64:65], v[82:83]                 // 00000000602C: 0C80A540
	v_cvt_f32_f64_e32 v60, v[64:65]                            // 000000006030: 7E781F40
	s_wait_alu depctr_sa_sdst(0)                               // 000000006034: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006038: BF870001
	v_cndmask_b32_e64 v60, v60, 0, s2                          // 00000000603C: D501003C 0009013C
	s_branch 62149                                             // 000000006044: BFA0F2C5 <tessera_rocm_folded_matmul_a870cecb1991940b+0x105c>
	v_cvt_f64_f32_e32 v[103:104], v48                          // 000000006048: 7ECE2130
	v_cvt_f64_f32_e32 v[105:106], v69                          // 00000000604C: 7ED22145
	v_cvt_f64_f32_e32 v[107:108], v60                          // 000000006050: 7ED6213C
	v_cmp_eq_f32_e64 s1, 0, v48                                // 000000006054: D4120001 02026080
	v_cmp_class_f32_e64 s4, v60, 0x1f8                         // 00000000605C: D47E0004 0201FF3C 000001F8
	s_and_b32 s1, s1, s4                                       // 000000006068: 8B010401
	v_mul_f64_e32 v[103:104], v[103:104], v[105:106]           // 00000000606C: 0CCED367
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006070: BF870091
	v_mul_f64_e32 v[103:104], v[103:104], v[107:108]           // 000000006074: 0CCED767
	v_cvt_f32_f64_e32 v67, v[103:104]                          // 000000006078: 7E861F67
	s_wait_alu depctr_sa_sdst(0)                               // 00000000607C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006080: BF870001
	v_cndmask_b32_e64 v67, v67, 0, s1                          // 000000006084: D5010043 00050143
	s_branch 62568                                             // 00000000608C: BFA0F468 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1730>
	v_cvt_f64_f32_e32 v[103:104], v49                          // 000000006090: 7ECE2131
	v_cvt_f64_f32_e32 v[105:106], v69                          // 000000006094: 7ED22145
	v_cvt_f64_f32_e32 v[107:108], v61                          // 000000006098: 7ED6213D
	v_cmp_eq_f32_e64 s1, 0, v49                                // 00000000609C: D4120001 02026280
	v_cmp_class_f32_e64 s4, v61, 0x1f8                         // 0000000060A4: D47E0004 0201FF3D 000001F8
	s_and_b32 s1, s1, s4                                       // 0000000060B0: 8B010401
	v_mul_f64_e32 v[103:104], v[103:104], v[105:106]           // 0000000060B4: 0CCED367
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000060B8: BF870091
	v_mul_f64_e32 v[103:104], v[103:104], v[107:108]           // 0000000060BC: 0CCED767
	v_cvt_f32_f64_e32 v48, v[103:104]                          // 0000000060C0: 7E601F67
	s_wait_alu depctr_sa_sdst(0)                               // 0000000060C4: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000060C8: BF870001
	v_cndmask_b32_e64 v48, v48, 0, s1                          // 0000000060CC: D5010030 00050130
	s_branch 62562                                             // 0000000060D4: BFA0F462 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1760>
	v_cvt_f64_f32_e32 v[60:61], v50                            // 0000000060D8: 7E782132
	v_cvt_f64_f32_e32 v[103:104], v69                          // 0000000060DC: 7ECE2145
	v_cvt_f64_f32_e32 v[105:106], v62                          // 0000000060E0: 7ED2213E
	v_cmp_eq_f32_e64 s1, 0, v50                                // 0000000060E4: D4120001 02026480
	v_cmp_class_f32_e64 s4, v62, 0x1f8                         // 0000000060EC: D47E0004 0201FF3E 000001F8
	s_and_b32 s1, s1, s4                                       // 0000000060F8: 8B010401
	v_mul_f64_e32 v[60:61], v[60:61], v[103:104]               // 0000000060FC: 0C78CF3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006100: BF870091
	v_mul_f64_e32 v[60:61], v[60:61], v[105:106]               // 000000006104: 0C78D33C
	v_cvt_f32_f64_e32 v49, v[60:61]                            // 000000006108: 7E621F3C
	s_wait_alu depctr_sa_sdst(0)                               // 00000000610C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006110: BF870001
	v_cndmask_b32_e64 v49, v49, 0, s1                          // 000000006114: D5010031 00050131
	s_branch 62556                                             // 00000000611C: BFA0F45C <tessera_rocm_folded_matmul_a870cecb1991940b+0x1790>
	v_cvt_f64_f32_e32 v[60:61], v51                            // 000000006120: 7E782133
	v_cvt_f64_f32_e32 v[103:104], v69                          // 000000006124: 7ECE2145
	v_cvt_f64_f32_e32 v[105:106], v63                          // 000000006128: 7ED2213F
	v_cmp_eq_f32_e64 s1, 0, v51                                // 00000000612C: D4120001 02026680
	v_cmp_class_f32_e64 s4, v63, 0x1f8                         // 000000006134: D47E0004 0201FF3F 000001F8
	s_and_b32 s1, s1, s4                                       // 000000006140: 8B010401
	v_mul_f64_e32 v[60:61], v[60:61], v[103:104]               // 000000006144: 0C78CF3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006148: BF870091
	v_mul_f64_e32 v[60:61], v[60:61], v[105:106]               // 00000000614C: 0C78D33C
	v_cvt_f32_f64_e32 v50, v[60:61]                            // 000000006150: 7E641F3C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006154: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006158: BF870001
	v_cndmask_b32_e64 v50, v50, 0, s1                          // 00000000615C: D5010032 00050132
	s_branch 62550                                             // 000000006164: BFA0F456 <tessera_rocm_folded_matmul_a870cecb1991940b+0x17c0>
	v_cvt_f64_f32_e32 v[60:61], v52                            // 000000006168: 7E782134
	v_cvt_f64_f32_e32 v[62:63], v69                            // 00000000616C: 7E7C2145
	v_cvt_f64_f32_e32 v[103:104], v56                          // 000000006170: 7ECE2138
	v_cmp_eq_f32_e64 s1, 0, v52                                // 000000006174: D4120001 02026880
	v_cmp_class_f32_e64 s4, v56, 0x1f8                         // 00000000617C: D47E0004 0201FF38 000001F8
	s_and_b32 s1, s1, s4                                       // 000000006188: 8B010401
	v_mul_f64_e32 v[60:61], v[60:61], v[62:63]                 // 00000000618C: 0C787D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006190: BF870091
	v_mul_f64_e32 v[60:61], v[60:61], v[103:104]               // 000000006194: 0C78CF3C
	v_cvt_f32_f64_e32 v51, v[60:61]                            // 000000006198: 7E661F3C
	s_wait_alu depctr_sa_sdst(0)                               // 00000000619C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000061A0: BF870001
	v_cndmask_b32_e64 v51, v51, 0, s1                          // 0000000061A4: D5010033 00050133
	s_branch 62544                                             // 0000000061AC: BFA0F450 <tessera_rocm_folded_matmul_a870cecb1991940b+0x17f0>
	v_cvt_f64_f32_e32 v[60:61], v53                            // 0000000061B0: 7E782135
	v_cvt_f64_f32_e32 v[62:63], v69                            // 0000000061B4: 7E7C2145
	v_cvt_f64_f32_e32 v[103:104], v57                          // 0000000061B8: 7ECE2139
	v_cmp_eq_f32_e64 s1, 0, v53                                // 0000000061BC: D4120001 02026A80
	v_cmp_class_f32_e64 s4, v57, 0x1f8                         // 0000000061C4: D47E0004 0201FF39 000001F8
	s_and_b32 s1, s1, s4                                       // 0000000061D0: 8B010401
	v_mul_f64_e32 v[60:61], v[60:61], v[62:63]                 // 0000000061D4: 0C787D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000061D8: BF870091
	v_mul_f64_e32 v[60:61], v[60:61], v[103:104]               // 0000000061DC: 0C78CF3C
	v_cvt_f32_f64_e32 v52, v[60:61]                            // 0000000061E0: 7E681F3C
	s_wait_alu depctr_sa_sdst(0)                               // 0000000061E4: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000061E8: BF870001
	v_cndmask_b32_e64 v52, v52, 0, s1                          // 0000000061EC: D5010034 00050134
	s_branch 62538                                             // 0000000061F4: BFA0F44A <tessera_rocm_folded_matmul_a870cecb1991940b+0x1820>
	v_cvt_f64_f32_e32 v[56:57], v54                            // 0000000061F8: 7E702136
	v_cvt_f64_f32_e32 v[60:61], v69                            // 0000000061FC: 7E782145
	v_cvt_f64_f32_e32 v[62:63], v58                            // 000000006200: 7E7C213A
	v_cmp_eq_f32_e64 s1, 0, v54                                // 000000006204: D4120001 02026C80
	v_cmp_class_f32_e64 s4, v58, 0x1f8                         // 00000000620C: D47E0004 0201FF3A 000001F8
	s_and_b32 s1, s1, s4                                       // 000000006218: 8B010401
	v_mul_f64_e32 v[56:57], v[56:57], v[60:61]                 // 00000000621C: 0C707938
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006220: BF870091
	v_mul_f64_e32 v[56:57], v[56:57], v[62:63]                 // 000000006224: 0C707D38
	v_cvt_f32_f64_e32 v53, v[56:57]                            // 000000006228: 7E6A1F38
	s_wait_alu depctr_sa_sdst(0)                               // 00000000622C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006230: BF870001
	v_cndmask_b32_e64 v60, v53, 0, s1                          // 000000006234: D501003C 00050135
	s_branch 62532                                             // 00000000623C: BFA0F444 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1850>
	v_cvt_f64_f32_e32 v[53:54], v55                            // 000000006240: 7E6A2137
	v_cvt_f64_f32_e32 v[56:57], v69                            // 000000006244: 7E702145
	v_cvt_f64_f32_e32 v[61:62], v59                            // 000000006248: 7E7A213B
	v_cmp_eq_f32_e64 s1, 0, v55                                // 00000000624C: D4120001 02026E80
	v_cmp_class_f32_e64 s4, v59, 0x1f8                         // 000000006254: D47E0004 0201FF3B 000001F8
	s_and_b32 s1, s1, s4                                       // 000000006260: 8B010401
	v_mul_f64_e32 v[53:54], v[53:54], v[56:57]                 // 000000006264: 0C6A7135
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006268: BF870091
	v_mul_f64_e32 v[53:54], v[53:54], v[61:62]                 // 00000000626C: 0C6A7B35
	v_cvt_f32_f64_e32 v53, v[53:54]                            // 000000006270: 7E6A1F35
	s_wait_alu depctr_sa_sdst(0)                               // 000000006274: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006278: BF870001
	v_cndmask_b32_e64 v53, v53, 0, s1                          // 00000000627C: D5010035 00050135
	s_branch 62526                                             // 000000006284: BFA0F43E <tessera_rocm_folded_matmul_a870cecb1991940b+0x1880>
	v_cvt_f64_f32_e32 v[129:130], v40                          // 000000006288: 7F022128
	v_cvt_f64_f32_e32 v[131:132], v61                          // 00000000628C: 7F06213D
	v_cvt_f64_f32_e32 v[133:134], v52                          // 000000006290: 7F0A2134
	v_cmp_eq_f32_e64 s2, 0, v40                                // 000000006294: D4120002 02025080
	v_cmp_class_f32_e64 s5, v52, 0x1f8                         // 00000000629C: D47E0005 0201FF34 000001F8
	s_and_b32 s2, s2, s5                                       // 0000000062A8: 8B020502
	v_mul_f64_e32 v[129:130], v[129:130], v[131:132]           // 0000000062AC: 0D030781
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000062B0: BF870091
	v_mul_f64_e32 v[129:130], v[129:130], v[133:134]           // 0000000062B4: 0D030B81
	v_cvt_f32_f64_e32 v59, v[129:130]                          // 0000000062B8: 7E761F81
	s_wait_alu depctr_sa_sdst(0)                               // 0000000062BC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000062C0: BF870001
	v_cndmask_b32_e64 v59, v59, 0, s2                          // 0000000062C4: D501003B 0009013B
	s_branch 62935                                             // 0000000062CC: BFA0F5D7 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1f2c>
	v_cvt_f64_f32_e32 v[129:130], v41                          // 0000000062D0: 7F022129
	v_cvt_f64_f32_e32 v[131:132], v61                          // 0000000062D4: 7F06213D
	v_cvt_f64_f32_e32 v[133:134], v53                          // 0000000062D8: 7F0A2135
	v_cmp_eq_f32_e64 s2, 0, v41                                // 0000000062DC: D4120002 02025280
	v_cmp_class_f32_e64 s5, v53, 0x1f8                         // 0000000062E4: D47E0005 0201FF35 000001F8
	s_and_b32 s2, s2, s5                                       // 0000000062F0: 8B020502
	v_mul_f64_e32 v[129:130], v[129:130], v[131:132]           // 0000000062F4: 0D030781
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000062F8: BF870091
	v_mul_f64_e32 v[129:130], v[129:130], v[133:134]           // 0000000062FC: 0D030B81
	v_cvt_f32_f64_e32 v40, v[129:130]                          // 000000006300: 7E501F81
	s_wait_alu depctr_sa_sdst(0)                               // 000000006304: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006308: BF870001
	v_cndmask_b32_e64 v40, v40, 0, s2                          // 00000000630C: D5010028 00090128
	s_branch 62929                                             // 000000006314: BFA0F5D1 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1f5c>
	v_cvt_f64_f32_e32 v[52:53], v42                            // 000000006318: 7E68212A
	v_cvt_f64_f32_e32 v[129:130], v61                          // 00000000631C: 7F02213D
	v_cvt_f64_f32_e32 v[131:132], v54                          // 000000006320: 7F062136
	v_cmp_eq_f32_e64 s2, 0, v42                                // 000000006324: D4120002 02025480
	v_cmp_class_f32_e64 s5, v54, 0x1f8                         // 00000000632C: D47E0005 0201FF36 000001F8
	s_and_b32 s2, s2, s5                                       // 000000006338: 8B020502
	v_mul_f64_e32 v[52:53], v[52:53], v[129:130]               // 00000000633C: 0C690334
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006340: BF870091
	v_mul_f64_e32 v[52:53], v[52:53], v[131:132]               // 000000006344: 0C690734
	v_cvt_f32_f64_e32 v41, v[52:53]                            // 000000006348: 7E521F34
	s_wait_alu depctr_sa_sdst(0)                               // 00000000634C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006350: BF870001
	v_cndmask_b32_e64 v41, v41, 0, s2                          // 000000006354: D5010029 00090129
	s_branch 62923                                             // 00000000635C: BFA0F5CB <tessera_rocm_folded_matmul_a870cecb1991940b+0x1f8c>
	v_cvt_f64_f32_e32 v[52:53], v43                            // 000000006360: 7E68212B
	v_cvt_f64_f32_e32 v[129:130], v61                          // 000000006364: 7F02213D
	v_cvt_f64_f32_e32 v[131:132], v55                          // 000000006368: 7F062137
	v_cmp_eq_f32_e64 s2, 0, v43                                // 00000000636C: D4120002 02025680
	v_cmp_class_f32_e64 s5, v55, 0x1f8                         // 000000006374: D47E0005 0201FF37 000001F8
	s_and_b32 s2, s2, s5                                       // 000000006380: 8B020502
	v_mul_f64_e32 v[52:53], v[52:53], v[129:130]               // 000000006384: 0C690334
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006388: BF870091
	v_mul_f64_e32 v[52:53], v[52:53], v[131:132]               // 00000000638C: 0C690734
	v_cvt_f32_f64_e32 v42, v[52:53]                            // 000000006390: 7E541F34
	s_wait_alu depctr_sa_sdst(0)                               // 000000006394: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006398: BF870001
	v_cndmask_b32_e64 v42, v42, 0, s2                          // 00000000639C: D501002A 0009012A
	s_branch 62917                                             // 0000000063A4: BFA0F5C5 <tessera_rocm_folded_matmul_a870cecb1991940b+0x1fbc>
	v_cvt_f64_f32_e32 v[52:53], v44                            // 0000000063A8: 7E68212C
	v_cvt_f64_f32_e32 v[54:55], v61                            // 0000000063AC: 7E6C213D
	v_cvt_f64_f32_e32 v[129:130], v48                          // 0000000063B0: 7F022130
	v_cmp_eq_f32_e64 s2, 0, v44                                // 0000000063B4: D4120002 02025880
	v_cmp_class_f32_e64 s5, v48, 0x1f8                         // 0000000063BC: D47E0005 0201FF30 000001F8
	s_and_b32 s2, s2, s5                                       // 0000000063C8: 8B020502
	v_mul_f64_e32 v[52:53], v[52:53], v[54:55]                 // 0000000063CC: 0C686D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000063D0: BF870091
	v_mul_f64_e32 v[52:53], v[52:53], v[129:130]               // 0000000063D4: 0C690334
	v_cvt_f32_f64_e32 v43, v[52:53]                            // 0000000063D8: 7E561F34
	s_wait_alu depctr_sa_sdst(0)                               // 0000000063DC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000063E0: BF870001
	v_cndmask_b32_e64 v43, v43, 0, s2                          // 0000000063E4: D501002B 0009012B
	s_branch 62911                                             // 0000000063EC: BFA0F5BF <tessera_rocm_folded_matmul_a870cecb1991940b+0x1fec>
	v_cvt_f64_f32_e32 v[52:53], v45                            // 0000000063F0: 7E68212D
	v_cvt_f64_f32_e32 v[54:55], v61                            // 0000000063F4: 7E6C213D
	v_cvt_f64_f32_e32 v[129:130], v49                          // 0000000063F8: 7F022131
	v_cmp_eq_f32_e64 s2, 0, v45                                // 0000000063FC: D4120002 02025A80
	v_cmp_class_f32_e64 s5, v49, 0x1f8                         // 000000006404: D47E0005 0201FF31 000001F8
	s_and_b32 s2, s2, s5                                       // 000000006410: 8B020502
	v_mul_f64_e32 v[52:53], v[52:53], v[54:55]                 // 000000006414: 0C686D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006418: BF870091
	v_mul_f64_e32 v[52:53], v[52:53], v[129:130]               // 00000000641C: 0C690334
	v_cvt_f32_f64_e32 v44, v[52:53]                            // 000000006420: 7E581F34
	s_wait_alu depctr_sa_sdst(0)                               // 000000006424: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006428: BF870001
	v_cndmask_b32_e64 v44, v44, 0, s2                          // 00000000642C: D501002C 0009012C
	s_branch 62905                                             // 000000006434: BFA0F5B9 <tessera_rocm_folded_matmul_a870cecb1991940b+0x201c>
	v_cvt_f64_f32_e32 v[48:49], v46                            // 000000006438: 7E60212E
	v_cvt_f64_f32_e32 v[52:53], v61                            // 00000000643C: 7E68213D
	v_cvt_f64_f32_e32 v[54:55], v50                            // 000000006440: 7E6C2132
	v_cmp_eq_f32_e64 s2, 0, v46                                // 000000006444: D4120002 02025C80
	v_cmp_class_f32_e64 s5, v50, 0x1f8                         // 00000000644C: D47E0005 0201FF32 000001F8
	s_and_b32 s2, s2, s5                                       // 000000006458: 8B020502
	v_mul_f64_e32 v[48:49], v[48:49], v[52:53]                 // 00000000645C: 0C606930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006460: BF870091
	v_mul_f64_e32 v[48:49], v[48:49], v[54:55]                 // 000000006464: 0C606D30
	v_cvt_f32_f64_e32 v45, v[48:49]                            // 000000006468: 7E5A1F30
	s_wait_alu depctr_sa_sdst(0)                               // 00000000646C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006470: BF870001
	v_cndmask_b32_e64 v52, v45, 0, s2                          // 000000006474: D5010034 0009012D
	s_branch 62899                                             // 00000000647C: BFA0F5B3 <tessera_rocm_folded_matmul_a870cecb1991940b+0x204c>
	v_cvt_f64_f32_e32 v[45:46], v47                            // 000000006480: 7E5A212F
	v_cvt_f64_f32_e32 v[48:49], v61                            // 000000006484: 7E60213D
	v_cvt_f64_f32_e32 v[53:54], v51                            // 000000006488: 7E6A2133
	v_cmp_eq_f32_e64 s2, 0, v47                                // 00000000648C: D4120002 02025E80
	v_cmp_class_f32_e64 s5, v51, 0x1f8                         // 000000006494: D47E0005 0201FF33 000001F8
	s_and_b32 s2, s2, s5                                       // 0000000064A0: 8B020502
	v_mul_f64_e32 v[45:46], v[45:46], v[48:49]                 // 0000000064A4: 0C5A612D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000064A8: BF870091
	v_mul_f64_e32 v[45:46], v[45:46], v[53:54]                 // 0000000064AC: 0C5A6B2D
	v_cvt_f32_f64_e32 v45, v[45:46]                            // 0000000064B0: 7E5A1F2D
	s_wait_alu depctr_sa_sdst(0)                               // 0000000064B4: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000064B8: BF870001
	v_cndmask_b32_e64 v45, v45, 0, s2                          // 0000000064BC: D501002D 0009012D
	s_branch 62893                                             // 0000000064C4: BFA0F5AD <tessera_rocm_folded_matmul_a870cecb1991940b+0x207c>
	v_cvt_f64_f32_e32 v[152:153], v32                          // 0000000064C8: 7F302120
	v_cvt_f64_f32_e32 v[154:155], v53                          // 0000000064CC: 7F342135
	v_cvt_f64_f32_e32 v[156:157], v44                          // 0000000064D0: 7F38212C
	v_cmp_eq_f32_e64 s3, 0, v32                                // 0000000064D4: D4120003 02024080
	v_cmp_class_f32_e64 s5, v44, 0x1f8                         // 0000000064DC: D47E0005 0201FF2C 000001F8
	s_and_b32 s3, s3, s5                                       // 0000000064E8: 8B030503
	v_mul_f64_e32 v[152:153], v[152:153], v[154:155]           // 0000000064EC: 0D313598
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000064F0: BF870091
	v_mul_f64_e32 v[152:153], v[152:153], v[156:157]           // 0000000064F4: 0D313998
	v_cvt_f32_f64_e32 v51, v[152:153]                          // 0000000064F8: 7E661F98
	s_wait_alu depctr_sa_sdst(0)                               // 0000000064FC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006500: BF870001
	v_cndmask_b32_e64 v51, v51, 0, s3                          // 000000006504: D5010033 000D0133
	s_branch 63302                                             // 00000000650C: BFA0F746 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2728>
	v_cvt_f64_f32_e32 v[152:153], v33                          // 000000006510: 7F302121
	v_cvt_f64_f32_e32 v[154:155], v53                          // 000000006514: 7F342135
	v_cvt_f64_f32_e32 v[156:157], v45                          // 000000006518: 7F38212D
	v_cmp_eq_f32_e64 s3, 0, v33                                // 00000000651C: D4120003 02024280
	v_cmp_class_f32_e64 s5, v45, 0x1f8                         // 000000006524: D47E0005 0201FF2D 000001F8
	s_and_b32 s3, s3, s5                                       // 000000006530: 8B030503
	v_mul_f64_e32 v[152:153], v[152:153], v[154:155]           // 000000006534: 0D313598
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006538: BF870091
	v_mul_f64_e32 v[152:153], v[152:153], v[156:157]           // 00000000653C: 0D313998
	v_cvt_f32_f64_e32 v32, v[152:153]                          // 000000006540: 7E401F98
	s_wait_alu depctr_sa_sdst(0)                               // 000000006544: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006548: BF870001
	v_cndmask_b32_e64 v32, v32, 0, s3                          // 00000000654C: D5010020 000D0120
	s_branch 63296                                             // 000000006554: BFA0F740 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2758>
	v_cvt_f64_f32_e32 v[44:45], v34                            // 000000006558: 7E582122
	v_cvt_f64_f32_e32 v[152:153], v53                          // 00000000655C: 7F302135
	v_cvt_f64_f32_e32 v[154:155], v46                          // 000000006560: 7F34212E
	v_cmp_eq_f32_e64 s3, 0, v34                                // 000000006564: D4120003 02024480
	v_cmp_class_f32_e64 s5, v46, 0x1f8                         // 00000000656C: D47E0005 0201FF2E 000001F8
	s_and_b32 s3, s3, s5                                       // 000000006578: 8B030503
	v_mul_f64_e32 v[44:45], v[44:45], v[152:153]               // 00000000657C: 0C59312C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006580: BF870091
	v_mul_f64_e32 v[44:45], v[44:45], v[154:155]               // 000000006584: 0C59352C
	v_cvt_f32_f64_e32 v33, v[44:45]                            // 000000006588: 7E421F2C
	s_wait_alu depctr_sa_sdst(0)                               // 00000000658C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006590: BF870001
	v_cndmask_b32_e64 v33, v33, 0, s3                          // 000000006594: D5010021 000D0121
	s_branch 63290                                             // 00000000659C: BFA0F73A <tessera_rocm_folded_matmul_a870cecb1991940b+0x2788>
	v_cvt_f64_f32_e32 v[44:45], v35                            // 0000000065A0: 7E582123
	v_cvt_f64_f32_e32 v[152:153], v53                          // 0000000065A4: 7F302135
	v_cvt_f64_f32_e32 v[154:155], v47                          // 0000000065A8: 7F34212F
	v_cmp_eq_f32_e64 s3, 0, v35                                // 0000000065AC: D4120003 02024680
	v_cmp_class_f32_e64 s5, v47, 0x1f8                         // 0000000065B4: D47E0005 0201FF2F 000001F8
	s_and_b32 s3, s3, s5                                       // 0000000065C0: 8B030503
	v_mul_f64_e32 v[44:45], v[44:45], v[152:153]               // 0000000065C4: 0C59312C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000065C8: BF870091
	v_mul_f64_e32 v[44:45], v[44:45], v[154:155]               // 0000000065CC: 0C59352C
	v_cvt_f32_f64_e32 v34, v[44:45]                            // 0000000065D0: 7E441F2C
	s_wait_alu depctr_sa_sdst(0)                               // 0000000065D4: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000065D8: BF870001
	v_cndmask_b32_e64 v34, v34, 0, s3                          // 0000000065DC: D5010022 000D0122
	s_branch 63284                                             // 0000000065E4: BFA0F734 <tessera_rocm_folded_matmul_a870cecb1991940b+0x27b8>
	v_cvt_f64_f32_e32 v[44:45], v36                            // 0000000065E8: 7E582124
	v_cvt_f64_f32_e32 v[46:47], v53                            // 0000000065EC: 7E5C2135
	v_cvt_f64_f32_e32 v[152:153], v40                          // 0000000065F0: 7F302128
	v_cmp_eq_f32_e64 s3, 0, v36                                // 0000000065F4: D4120003 02024880
	v_cmp_class_f32_e64 s5, v40, 0x1f8                         // 0000000065FC: D47E0005 0201FF28 000001F8
	s_and_b32 s3, s3, s5                                       // 000000006608: 8B030503
	v_mul_f64_e32 v[44:45], v[44:45], v[46:47]                 // 00000000660C: 0C585D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006610: BF870091
	v_mul_f64_e32 v[44:45], v[44:45], v[152:153]               // 000000006614: 0C59312C
	v_cvt_f32_f64_e32 v35, v[44:45]                            // 000000006618: 7E461F2C
	s_wait_alu depctr_sa_sdst(0)                               // 00000000661C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006620: BF870001
	v_cndmask_b32_e64 v35, v35, 0, s3                          // 000000006624: D5010023 000D0123
	s_branch 63278                                             // 00000000662C: BFA0F72E <tessera_rocm_folded_matmul_a870cecb1991940b+0x27e8>
	v_cvt_f64_f32_e32 v[44:45], v37                            // 000000006630: 7E582125
	v_cvt_f64_f32_e32 v[46:47], v53                            // 000000006634: 7E5C2135
	v_cvt_f64_f32_e32 v[152:153], v41                          // 000000006638: 7F302129
	v_cmp_eq_f32_e64 s3, 0, v37                                // 00000000663C: D4120003 02024A80
	v_cmp_class_f32_e64 s5, v41, 0x1f8                         // 000000006644: D47E0005 0201FF29 000001F8
	s_and_b32 s3, s3, s5                                       // 000000006650: 8B030503
	v_mul_f64_e32 v[44:45], v[44:45], v[46:47]                 // 000000006654: 0C585D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006658: BF870091
	v_mul_f64_e32 v[44:45], v[44:45], v[152:153]               // 00000000665C: 0C59312C
	v_cvt_f32_f64_e32 v36, v[44:45]                            // 000000006660: 7E481F2C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006664: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006668: BF870001
	v_cndmask_b32_e64 v36, v36, 0, s3                          // 00000000666C: D5010024 000D0124
	s_branch 63272                                             // 000000006674: BFA0F728 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2818>
	v_cvt_f64_f32_e32 v[40:41], v38                            // 000000006678: 7E502126
	v_cvt_f64_f32_e32 v[44:45], v53                            // 00000000667C: 7E582135
	v_cvt_f64_f32_e32 v[46:47], v42                            // 000000006680: 7E5C212A
	v_cmp_eq_f32_e64 s3, 0, v38                                // 000000006684: D4120003 02024C80
	v_cmp_class_f32_e64 s5, v42, 0x1f8                         // 00000000668C: D47E0005 0201FF2A 000001F8
	s_and_b32 s3, s3, s5                                       // 000000006698: 8B030503
	v_mul_f64_e32 v[40:41], v[40:41], v[44:45]                 // 00000000669C: 0C505928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000066A0: BF870091
	v_mul_f64_e32 v[40:41], v[40:41], v[46:47]                 // 0000000066A4: 0C505D28
	v_cvt_f32_f64_e32 v37, v[40:41]                            // 0000000066A8: 7E4A1F28
	s_wait_alu depctr_sa_sdst(0)                               // 0000000066AC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000066B0: BF870001
	v_cndmask_b32_e64 v55, v37, 0, s3                          // 0000000066B4: D5010037 000D0125
	s_branch 63266                                             // 0000000066BC: BFA0F722 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2848>
	v_cvt_f64_f32_e32 v[37:38], v39                            // 0000000066C0: 7E4A2127
	v_cvt_f64_f32_e32 v[40:41], v53                            // 0000000066C4: 7E502135
	v_cvt_f64_f32_e32 v[44:45], v43                            // 0000000066C8: 7E58212B
	v_cmp_eq_f32_e64 s3, 0, v39                                // 0000000066CC: D4120003 02024E80
	v_cmp_class_f32_e64 s5, v43, 0x1f8                         // 0000000066D4: D47E0005 0201FF2B 000001F8
	s_and_b32 s3, s3, s5                                       // 0000000066E0: 8B030503
	v_mul_f64_e32 v[37:38], v[37:38], v[40:41]                 // 0000000066E4: 0C4A5125
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000066E8: BF870091
	v_mul_f64_e32 v[37:38], v[37:38], v[44:45]                 // 0000000066EC: 0C4A5925
	v_cvt_f32_f64_e32 v37, v[37:38]                            // 0000000066F0: 7E4A1F25
	s_wait_alu depctr_sa_sdst(0)                               // 0000000066F4: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000066F8: BF870001
	v_cndmask_b32_e64 v37, v37, 0, s3                          // 0000000066FC: D5010025 000D0125
	s_branch 63260                                             // 000000006704: BFA0F71C <tessera_rocm_folded_matmul_a870cecb1991940b+0x2878>
	v_cvt_f64_f32_e32 v[114:115], v24                          // 000000006708: 7EE42118
	v_cvt_f64_f32_e32 v[160:161], v53                          // 00000000670C: 7F402135
	v_cvt_f64_f32_e32 v[162:163], v36                          // 000000006710: 7F442124
	v_cmp_eq_f32_e32 vcc_lo, 0, v24                            // 000000006714: 7C243080
	v_cmp_class_f32_e64 s5, v36, 0x1f8                         // 000000006718: D47E0005 0201FF24 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 000000006724: 8B05056A
	v_mul_f64_e32 v[114:115], v[114:115], v[160:161]           // 000000006728: 0CE54172
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000672C: BF870091
	v_mul_f64_e32 v[114:115], v[114:115], v[162:163]           // 000000006730: 0CE54572
	v_cvt_f32_f64_e32 v51, v[114:115]                          // 000000006734: 7E661F72
	s_wait_alu depctr_sa_sdst(0)                               // 000000006738: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000673C: BF870001
	v_cndmask_b32_e64 v51, v51, 0, s5                          // 000000006740: D5010033 00150133
	s_branch 63645                                             // 000000006748: BFA0F89D <tessera_rocm_folded_matmul_a870cecb1991940b+0x2ec0>
	v_cvt_f64_f32_e32 v[114:115], v25                          // 00000000674C: 7EE42119
	v_cvt_f64_f32_e32 v[160:161], v53                          // 000000006750: 7F402135
	v_cvt_f64_f32_e32 v[162:163], v37                          // 000000006754: 7F442125
	v_cmp_eq_f32_e32 vcc_lo, 0, v25                            // 000000006758: 7C243280
	v_cmp_class_f32_e64 s5, v37, 0x1f8                         // 00000000675C: D47E0005 0201FF25 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 000000006768: 8B05056A
	v_mul_f64_e32 v[114:115], v[114:115], v[160:161]           // 00000000676C: 0CE54172
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006770: BF870091
	v_mul_f64_e32 v[114:115], v[114:115], v[162:163]           // 000000006774: 0CE54572
	v_cvt_f32_f64_e32 v24, v[114:115]                          // 000000006778: 7E301F72
	s_wait_alu depctr_sa_sdst(0)                               // 00000000677C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006780: BF870001
	v_cndmask_b32_e64 v24, v24, 0, s5                          // 000000006784: D5010018 00150118
	s_branch 63640                                             // 00000000678C: BFA0F898 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2ef0>
	v_cvt_f64_f32_e32 v[36:37], v26                            // 000000006790: 7E48211A
	v_cvt_f64_f32_e32 v[114:115], v53                          // 000000006794: 7EE42135
	v_cvt_f64_f32_e32 v[160:161], v38                          // 000000006798: 7F402126
	v_cmp_eq_f32_e32 vcc_lo, 0, v26                            // 00000000679C: 7C243480
	v_cmp_class_f32_e64 s5, v38, 0x1f8                         // 0000000067A0: D47E0005 0201FF26 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 0000000067AC: 8B05056A
	v_mul_f64_e32 v[36:37], v[36:37], v[114:115]               // 0000000067B0: 0C48E524
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000067B4: BF870091
	v_mul_f64_e32 v[36:37], v[36:37], v[160:161]               // 0000000067B8: 0C494124
	v_cvt_f32_f64_e32 v25, v[36:37]                            // 0000000067BC: 7E321F24
	s_wait_alu depctr_sa_sdst(0)                               // 0000000067C0: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000067C4: BF870001
	v_cndmask_b32_e64 v25, v25, 0, s5                          // 0000000067C8: D5010019 00150119
	s_branch 63635                                             // 0000000067D0: BFA0F893 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2f20>
	v_cvt_f64_f32_e32 v[36:37], v27                            // 0000000067D4: 7E48211B
	v_cvt_f64_f32_e32 v[114:115], v53                          // 0000000067D8: 7EE42135
	v_cvt_f64_f32_e32 v[160:161], v39                          // 0000000067DC: 7F402127
	v_cmp_eq_f32_e32 vcc_lo, 0, v27                            // 0000000067E0: 7C243680
	v_cmp_class_f32_e64 s5, v39, 0x1f8                         // 0000000067E4: D47E0005 0201FF27 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 0000000067F0: 8B05056A
	v_mul_f64_e32 v[36:37], v[36:37], v[114:115]               // 0000000067F4: 0C48E524
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000067F8: BF870091
	v_mul_f64_e32 v[36:37], v[36:37], v[160:161]               // 0000000067FC: 0C494124
	v_cvt_f32_f64_e32 v26, v[36:37]                            // 000000006800: 7E341F24
	s_wait_alu depctr_sa_sdst(0)                               // 000000006804: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006808: BF870001
	v_cndmask_b32_e64 v26, v26, 0, s5                          // 00000000680C: D501001A 0015011A
	s_branch 63630                                             // 000000006814: BFA0F88E <tessera_rocm_folded_matmul_a870cecb1991940b+0x2f50>
	v_cvt_f64_f32_e32 v[36:37], v28                            // 000000006818: 7E48211C
	v_cvt_f64_f32_e32 v[38:39], v53                            // 00000000681C: 7E4C2135
	v_cvt_f64_f32_e32 v[114:115], v32                          // 000000006820: 7EE42120
	v_cmp_eq_f32_e32 vcc_lo, 0, v28                            // 000000006824: 7C243880
	v_cmp_class_f32_e64 s5, v32, 0x1f8                         // 000000006828: D47E0005 0201FF20 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 000000006834: 8B05056A
	v_mul_f64_e32 v[36:37], v[36:37], v[38:39]                 // 000000006838: 0C484D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000683C: BF870091
	v_mul_f64_e32 v[36:37], v[36:37], v[114:115]               // 000000006840: 0C48E524
	v_cvt_f32_f64_e32 v27, v[36:37]                            // 000000006844: 7E361F24
	s_wait_alu depctr_sa_sdst(0)                               // 000000006848: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000684C: BF870001
	v_cndmask_b32_e64 v27, v27, 0, s5                          // 000000006850: D501001B 0015011B
	s_branch 63625                                             // 000000006858: BFA0F889 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2f80>
	v_cvt_f64_f32_e32 v[36:37], v29                            // 00000000685C: 7E48211D
	v_cvt_f64_f32_e32 v[38:39], v53                            // 000000006860: 7E4C2135
	v_cvt_f64_f32_e32 v[114:115], v33                          // 000000006864: 7EE42121
	v_cmp_eq_f32_e32 vcc_lo, 0, v29                            // 000000006868: 7C243A80
	v_cmp_class_f32_e64 s5, v33, 0x1f8                         // 00000000686C: D47E0005 0201FF21 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 000000006878: 8B05056A
	v_mul_f64_e32 v[36:37], v[36:37], v[38:39]                 // 00000000687C: 0C484D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006880: BF870091
	v_mul_f64_e32 v[36:37], v[36:37], v[114:115]               // 000000006884: 0C48E524
	v_cvt_f32_f64_e32 v28, v[36:37]                            // 000000006888: 7E381F24
	s_wait_alu depctr_sa_sdst(0)                               // 00000000688C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006890: BF870001
	v_cndmask_b32_e64 v28, v28, 0, s5                          // 000000006894: D501001C 0015011C
	s_branch 63620                                             // 00000000689C: BFA0F884 <tessera_rocm_folded_matmul_a870cecb1991940b+0x2fb0>
	v_cvt_f64_f32_e32 v[32:33], v30                            // 0000000068A0: 7E40211E
	v_cvt_f64_f32_e32 v[36:37], v53                            // 0000000068A4: 7E482135
	v_cvt_f64_f32_e32 v[38:39], v34                            // 0000000068A8: 7E4C2122
	v_cmp_eq_f32_e32 vcc_lo, 0, v30                            // 0000000068AC: 7C243C80
	v_cmp_class_f32_e64 s5, v34, 0x1f8                         // 0000000068B0: D47E0005 0201FF22 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 0000000068BC: 8B05056A
	v_mul_f64_e32 v[32:33], v[32:33], v[36:37]                 // 0000000068C0: 0C404920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000068C4: BF870091
	v_mul_f64_e32 v[32:33], v[32:33], v[38:39]                 // 0000000068C8: 0C404D20
	v_cvt_f32_f64_e32 v29, v[32:33]                            // 0000000068CC: 7E3A1F20
	s_wait_alu depctr_sa_sdst(0)                               // 0000000068D0: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000068D4: BF870001
	v_cndmask_b32_e64 v29, v29, 0, s5                          // 0000000068D8: D501001D 0015011D
	s_branch 63615                                             // 0000000068E0: BFA0F87F <tessera_rocm_folded_matmul_a870cecb1991940b+0x2fe0>
	v_cvt_f64_f32_e32 v[32:33], v31                            // 0000000068E4: 7E40211F
	v_cvt_f64_f32_e32 v[36:37], v53                            // 0000000068E8: 7E482135
	v_cvt_f64_f32_e32 v[38:39], v35                            // 0000000068EC: 7E4C2123
	v_cmp_eq_f32_e32 vcc_lo, 0, v31                            // 0000000068F0: 7C243E80
	v_cmp_class_f32_e64 s5, v35, 0x1f8                         // 0000000068F4: D47E0005 0201FF23 000001F8
	s_and_b32 s5, vcc_lo, s5                                   // 000000006900: 8B05056A
	v_mul_f64_e32 v[32:33], v[32:33], v[36:37]                 // 000000006904: 0C404920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006908: BF870091
	v_mul_f64_e32 v[32:33], v[32:33], v[38:39]                 // 00000000690C: 0C404D20
	v_cvt_f32_f64_e32 v30, v[32:33]                            // 000000006910: 7E3C1F20
	s_wait_alu depctr_sa_sdst(0)                               // 000000006914: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006918: BF870001
	v_cndmask_b32_e64 v30, v30, 0, s5                          // 00000000691C: D501001E 0015011E
	s_branch 63610                                             // 000000006924: BFA0F87A <tessera_rocm_folded_matmul_a870cecb1991940b+0x3010>
	v_cvt_f64_f32_e32 v[34:35], v16                            // 000000006928: 7E442110
	v_cvt_f64_f32_e32 v[36:37], v33                            // 00000000692C: 7E482121
	v_cvt_f64_f32_e32 v[38:39], v28                            // 000000006930: 7E4C211C
	v_cmp_eq_f32_e32 vcc_lo, 0, v16                            // 000000006934: 7C242080
	v_cmp_class_f32_e64 s4, v28, 0x1f8                         // 000000006938: D47E0004 0201FF1C 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 000000006944: 8B04046A
	v_mul_f64_e32 v[34:35], v[34:35], v[36:37]                 // 000000006948: 0C444922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000694C: BF870091
	v_mul_f64_e32 v[34:35], v[34:35], v[38:39]                 // 000000006950: 0C444D22
	v_cvt_f32_f64_e32 v32, v[34:35]                            // 000000006954: 7E401F22
	s_wait_alu depctr_sa_sdst(0)                               // 000000006958: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000695C: BF870001
	v_cndmask_b32_e64 v32, v32, 0, s4                          // 000000006960: D5010020 00110120
	s_branch 63877                                             // 000000006968: BFA0F985 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3480>
	v_cvt_f64_f32_e32 v[34:35], v17                            // 00000000696C: 7E442111
	v_cvt_f64_f32_e32 v[36:37], v33                            // 000000006970: 7E482121
	v_cvt_f64_f32_e32 v[38:39], v29                            // 000000006974: 7E4C211D
	v_cmp_eq_f32_e32 vcc_lo, 0, v17                            // 000000006978: 7C242280
	v_cmp_class_f32_e64 s4, v29, 0x1f8                         // 00000000697C: D47E0004 0201FF1D 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 000000006988: 8B04046A
	v_mul_f64_e32 v[34:35], v[34:35], v[36:37]                 // 00000000698C: 0C444922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006990: BF870091
	v_mul_f64_e32 v[34:35], v[34:35], v[38:39]                 // 000000006994: 0C444D22
	v_cvt_f32_f64_e32 v16, v[34:35]                            // 000000006998: 7E201F22
	s_wait_alu depctr_sa_sdst(0)                               // 00000000699C: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000069A0: BF870001
	v_cndmask_b32_e64 v16, v16, 0, s4                          // 0000000069A4: D5010010 00110110
	s_branch 63872                                             // 0000000069AC: BFA0F980 <tessera_rocm_folded_matmul_a870cecb1991940b+0x34b0>
	v_cvt_f64_f32_e32 v[28:29], v18                            // 0000000069B0: 7E382112
	v_cvt_f64_f32_e32 v[34:35], v33                            // 0000000069B4: 7E442121
	v_cvt_f64_f32_e32 v[36:37], v30                            // 0000000069B8: 7E48211E
	v_cmp_eq_f32_e32 vcc_lo, 0, v18                            // 0000000069BC: 7C242480
	v_cmp_class_f32_e64 s4, v30, 0x1f8                         // 0000000069C0: D47E0004 0201FF1E 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 0000000069CC: 8B04046A
	v_mul_f64_e32 v[28:29], v[28:29], v[34:35]                 // 0000000069D0: 0C38451C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000069D4: BF870091
	v_mul_f64_e32 v[28:29], v[28:29], v[36:37]                 // 0000000069D8: 0C38491C
	v_cvt_f32_f64_e32 v17, v[28:29]                            // 0000000069DC: 7E221F1C
	s_wait_alu depctr_sa_sdst(0)                               // 0000000069E0: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000069E4: BF870001
	v_cndmask_b32_e64 v17, v17, 0, s4                          // 0000000069E8: D5010011 00110111
	s_branch 63867                                             // 0000000069F0: BFA0F97B <tessera_rocm_folded_matmul_a870cecb1991940b+0x34e0>
	v_cvt_f64_f32_e32 v[28:29], v19                            // 0000000069F4: 7E382113
	v_cvt_f64_f32_e32 v[34:35], v33                            // 0000000069F8: 7E442121
	v_cvt_f64_f32_e32 v[36:37], v31                            // 0000000069FC: 7E48211F
	v_cmp_eq_f32_e32 vcc_lo, 0, v19                            // 000000006A00: 7C242680
	v_cmp_class_f32_e64 s4, v31, 0x1f8                         // 000000006A04: D47E0004 0201FF1F 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 000000006A10: 8B04046A
	v_mul_f64_e32 v[28:29], v[28:29], v[34:35]                 // 000000006A14: 0C38451C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006A18: BF870091
	v_mul_f64_e32 v[28:29], v[28:29], v[36:37]                 // 000000006A1C: 0C38491C
	v_cvt_f32_f64_e32 v18, v[28:29]                            // 000000006A20: 7E241F1C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006A24: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006A28: BF870001
	v_cndmask_b32_e64 v18, v18, 0, s4                          // 000000006A2C: D5010012 00110112
	s_branch 63862                                             // 000000006A34: BFA0F976 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3510>
	v_cvt_f64_f32_e32 v[28:29], v20                            // 000000006A38: 7E382114
	v_cvt_f64_f32_e32 v[30:31], v33                            // 000000006A3C: 7E3C2121
	v_cvt_f64_f32_e32 v[34:35], v24                            // 000000006A40: 7E442118
	v_cmp_eq_f32_e32 vcc_lo, 0, v20                            // 000000006A44: 7C242880
	v_cmp_class_f32_e64 s4, v24, 0x1f8                         // 000000006A48: D47E0004 0201FF18 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 000000006A54: 8B04046A
	v_mul_f64_e32 v[28:29], v[28:29], v[30:31]                 // 000000006A58: 0C383D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006A5C: BF870091
	v_mul_f64_e32 v[28:29], v[28:29], v[34:35]                 // 000000006A60: 0C38451C
	v_cvt_f32_f64_e32 v19, v[28:29]                            // 000000006A64: 7E261F1C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006A68: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006A6C: BF870001
	v_cndmask_b32_e64 v19, v19, 0, s4                          // 000000006A70: D5010013 00110113
	s_branch 63857                                             // 000000006A78: BFA0F971 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3540>
	v_cvt_f64_f32_e32 v[28:29], v21                            // 000000006A7C: 7E382115
	v_cvt_f64_f32_e32 v[30:31], v33                            // 000000006A80: 7E3C2121
	v_cvt_f64_f32_e32 v[34:35], v25                            // 000000006A84: 7E442119
	v_cmp_eq_f32_e32 vcc_lo, 0, v21                            // 000000006A88: 7C242A80
	v_cmp_class_f32_e64 s4, v25, 0x1f8                         // 000000006A8C: D47E0004 0201FF19 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 000000006A98: 8B04046A
	v_mul_f64_e32 v[28:29], v[28:29], v[30:31]                 // 000000006A9C: 0C383D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006AA0: BF870091
	v_mul_f64_e32 v[28:29], v[28:29], v[34:35]                 // 000000006AA4: 0C38451C
	v_cvt_f32_f64_e32 v20, v[28:29]                            // 000000006AA8: 7E281F1C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006AAC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006AB0: BF870001
	v_cndmask_b32_e64 v20, v20, 0, s4                          // 000000006AB4: D5010014 00110114
	s_branch 63852                                             // 000000006ABC: BFA0F96C <tessera_rocm_folded_matmul_a870cecb1991940b+0x3570>
	v_cvt_f64_f32_e32 v[24:25], v22                            // 000000006AC0: 7E302116
	v_cvt_f64_f32_e32 v[28:29], v33                            // 000000006AC4: 7E382121
	v_cvt_f64_f32_e32 v[30:31], v26                            // 000000006AC8: 7E3C211A
	v_cmp_eq_f32_e32 vcc_lo, 0, v22                            // 000000006ACC: 7C242C80
	v_cmp_class_f32_e64 s4, v26, 0x1f8                         // 000000006AD0: D47E0004 0201FF1A 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 000000006ADC: 8B04046A
	v_mul_f64_e32 v[24:25], v[24:25], v[28:29]                 // 000000006AE0: 0C303918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006AE4: BF870091
	v_mul_f64_e32 v[24:25], v[24:25], v[30:31]                 // 000000006AE8: 0C303D18
	v_cvt_f32_f64_e32 v21, v[24:25]                            // 000000006AEC: 7E2A1F18
	s_wait_alu depctr_sa_sdst(0)                               // 000000006AF0: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006AF4: BF870001
	v_cndmask_b32_e64 v21, v21, 0, s4                          // 000000006AF8: D5010015 00110115
	s_branch 63847                                             // 000000006B00: BFA0F967 <tessera_rocm_folded_matmul_a870cecb1991940b+0x35a0>
	v_cvt_f64_f32_e32 v[24:25], v23                            // 000000006B04: 7E302117
	v_cvt_f64_f32_e32 v[28:29], v33                            // 000000006B08: 7E382121
	v_cvt_f64_f32_e32 v[30:31], v27                            // 000000006B0C: 7E3C211B
	v_cmp_eq_f32_e32 vcc_lo, 0, v23                            // 000000006B10: 7C242E80
	v_cmp_class_f32_e64 s4, v27, 0x1f8                         // 000000006B14: D47E0004 0201FF1B 000001F8
	s_and_b32 s4, vcc_lo, s4                                   // 000000006B20: 8B04046A
	v_mul_f64_e32 v[24:25], v[24:25], v[28:29]                 // 000000006B24: 0C303918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006B28: BF870091
	v_mul_f64_e32 v[24:25], v[24:25], v[30:31]                 // 000000006B2C: 0C303D18
	v_cvt_f32_f64_e32 v22, v[24:25]                            // 000000006B30: 7E2C1F18
	s_wait_alu depctr_sa_sdst(0)                               // 000000006B34: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006B38: BF870001
	v_cndmask_b32_e64 v22, v22, 0, s4                          // 000000006B3C: D5010016 00110116
	s_branch 63842                                             // 000000006B44: BFA0F962 <tessera_rocm_folded_matmul_a870cecb1991940b+0x35d0>
	v_cvt_f64_f32_e32 v[26:27], v8                             // 000000006B48: 7E342108
	v_cvt_f64_f32_e32 v[28:29], v25                            // 000000006B4C: 7E382119
	v_cvt_f64_f32_e32 v[30:31], v20                            // 000000006B50: 7E3C2114
	v_cmp_eq_f32_e32 vcc_lo, 0, v8                             // 000000006B54: 7C241080
	v_cmp_class_f32_e64 s1, v20, 0x1f8                         // 000000006B58: D47E0001 0201FF14 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006B64: 8B01016A
	v_mul_f64_e32 v[26:27], v[26:27], v[28:29]                 // 000000006B68: 0C34391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006B6C: BF870091
	v_mul_f64_e32 v[26:27], v[26:27], v[30:31]                 // 000000006B70: 0C343D1A
	v_cvt_f32_f64_e32 v24, v[26:27]                            // 000000006B74: 7E301F1A
	s_wait_alu depctr_sa_sdst(0)                               // 000000006B78: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006B7C: BF870001
	v_cndmask_b32_e64 v24, v24, 0, s1                          // 000000006B80: D5010018 00050118
	s_branch 64109                                             // 000000006B88: BFA0FA6D <tessera_rocm_folded_matmul_a870cecb1991940b+0x3a40>
	v_cvt_f64_f32_e32 v[26:27], v9                             // 000000006B8C: 7E342109
	v_cvt_f64_f32_e32 v[28:29], v25                            // 000000006B90: 7E382119
	v_cvt_f64_f32_e32 v[30:31], v21                            // 000000006B94: 7E3C2115
	v_cmp_eq_f32_e32 vcc_lo, 0, v9                             // 000000006B98: 7C241280
	v_cmp_class_f32_e64 s1, v21, 0x1f8                         // 000000006B9C: D47E0001 0201FF15 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006BA8: 8B01016A
	v_mul_f64_e32 v[26:27], v[26:27], v[28:29]                 // 000000006BAC: 0C34391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006BB0: BF870091
	v_mul_f64_e32 v[26:27], v[26:27], v[30:31]                 // 000000006BB4: 0C343D1A
	v_cvt_f32_f64_e32 v8, v[26:27]                             // 000000006BB8: 7E101F1A
	s_wait_alu depctr_sa_sdst(0)                               // 000000006BBC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006BC0: BF870001
	v_cndmask_b32_e64 v8, v8, 0, s1                            // 000000006BC4: D5010008 00050108
	s_branch 64104                                             // 000000006BCC: BFA0FA68 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3a70>
	v_cvt_f64_f32_e32 v[20:21], v10                            // 000000006BD0: 7E28210A
	v_cvt_f64_f32_e32 v[26:27], v25                            // 000000006BD4: 7E342119
	v_cvt_f64_f32_e32 v[28:29], v22                            // 000000006BD8: 7E382116
	v_cmp_eq_f32_e32 vcc_lo, 0, v10                            // 000000006BDC: 7C241480
	v_cmp_class_f32_e64 s1, v22, 0x1f8                         // 000000006BE0: D47E0001 0201FF16 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006BEC: 8B01016A
	v_mul_f64_e32 v[20:21], v[20:21], v[26:27]                 // 000000006BF0: 0C283514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006BF4: BF870091
	v_mul_f64_e32 v[20:21], v[20:21], v[28:29]                 // 000000006BF8: 0C283914
	v_cvt_f32_f64_e32 v9, v[20:21]                             // 000000006BFC: 7E121F14
	s_wait_alu depctr_sa_sdst(0)                               // 000000006C00: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006C04: BF870001
	v_cndmask_b32_e64 v9, v9, 0, s1                            // 000000006C08: D5010009 00050109
	s_branch 64099                                             // 000000006C10: BFA0FA63 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3aa0>
	v_cvt_f64_f32_e32 v[20:21], v11                            // 000000006C14: 7E28210B
	v_cvt_f64_f32_e32 v[26:27], v25                            // 000000006C18: 7E342119
	v_cvt_f64_f32_e32 v[28:29], v23                            // 000000006C1C: 7E382117
	v_cmp_eq_f32_e32 vcc_lo, 0, v11                            // 000000006C20: 7C241680
	v_cmp_class_f32_e64 s1, v23, 0x1f8                         // 000000006C24: D47E0001 0201FF17 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006C30: 8B01016A
	v_mul_f64_e32 v[20:21], v[20:21], v[26:27]                 // 000000006C34: 0C283514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006C38: BF870091
	v_mul_f64_e32 v[20:21], v[20:21], v[28:29]                 // 000000006C3C: 0C283914
	v_cvt_f32_f64_e32 v10, v[20:21]                            // 000000006C40: 7E141F14
	s_wait_alu depctr_sa_sdst(0)                               // 000000006C44: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006C48: BF870001
	v_cndmask_b32_e64 v10, v10, 0, s1                          // 000000006C4C: D501000A 0005010A
	s_branch 64094                                             // 000000006C54: BFA0FA5E <tessera_rocm_folded_matmul_a870cecb1991940b+0x3ad0>
	v_cvt_f64_f32_e32 v[20:21], v12                            // 000000006C58: 7E28210C
	v_cvt_f64_f32_e32 v[22:23], v25                            // 000000006C5C: 7E2C2119
	v_cvt_f64_f32_e32 v[26:27], v16                            // 000000006C60: 7E342110
	v_cmp_eq_f32_e32 vcc_lo, 0, v12                            // 000000006C64: 7C241880
	v_cmp_class_f32_e64 s1, v16, 0x1f8                         // 000000006C68: D47E0001 0201FF10 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006C74: 8B01016A
	v_mul_f64_e32 v[20:21], v[20:21], v[22:23]                 // 000000006C78: 0C282D14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006C7C: BF870091
	v_mul_f64_e32 v[20:21], v[20:21], v[26:27]                 // 000000006C80: 0C283514
	v_cvt_f32_f64_e32 v11, v[20:21]                            // 000000006C84: 7E161F14
	s_wait_alu depctr_sa_sdst(0)                               // 000000006C88: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006C8C: BF870001
	v_cndmask_b32_e64 v11, v11, 0, s1                          // 000000006C90: D501000B 0005010B
	s_branch 64089                                             // 000000006C98: BFA0FA59 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3b00>
	v_cvt_f64_f32_e32 v[20:21], v13                            // 000000006C9C: 7E28210D
	v_cvt_f64_f32_e32 v[22:23], v25                            // 000000006CA0: 7E2C2119
	v_cvt_f64_f32_e32 v[26:27], v17                            // 000000006CA4: 7E342111
	v_cmp_eq_f32_e32 vcc_lo, 0, v13                            // 000000006CA8: 7C241A80
	v_cmp_class_f32_e64 s1, v17, 0x1f8                         // 000000006CAC: D47E0001 0201FF11 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006CB8: 8B01016A
	v_mul_f64_e32 v[20:21], v[20:21], v[22:23]                 // 000000006CBC: 0C282D14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006CC0: BF870091
	v_mul_f64_e32 v[20:21], v[20:21], v[26:27]                 // 000000006CC4: 0C283514
	v_cvt_f32_f64_e32 v12, v[20:21]                            // 000000006CC8: 7E181F14
	s_wait_alu depctr_sa_sdst(0)                               // 000000006CCC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006CD0: BF870001
	v_cndmask_b32_e64 v12, v12, 0, s1                          // 000000006CD4: D501000C 0005010C
	s_branch 64084                                             // 000000006CDC: BFA0FA54 <tessera_rocm_folded_matmul_a870cecb1991940b+0x3b30>
	v_cvt_f64_f32_e32 v[16:17], v14                            // 000000006CE0: 7E20210E
	v_cvt_f64_f32_e32 v[20:21], v25                            // 000000006CE4: 7E282119
	v_cvt_f64_f32_e32 v[22:23], v18                            // 000000006CE8: 7E2C2112
	v_cmp_eq_f32_e32 vcc_lo, 0, v14                            // 000000006CEC: 7C241C80
	v_cmp_class_f32_e64 s1, v18, 0x1f8                         // 000000006CF0: D47E0001 0201FF12 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006CFC: 8B01016A
	v_mul_f64_e32 v[16:17], v[16:17], v[20:21]                 // 000000006D00: 0C202910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006D04: BF870091
	v_mul_f64_e32 v[16:17], v[16:17], v[22:23]                 // 000000006D08: 0C202D10
	v_cvt_f32_f64_e32 v13, v[16:17]                            // 000000006D0C: 7E1A1F10
	s_wait_alu depctr_sa_sdst(0)                               // 000000006D10: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006D14: BF870001
	v_cndmask_b32_e64 v13, v13, 0, s1                          // 000000006D18: D501000D 0005010D
	s_branch 64079                                             // 000000006D20: BFA0FA4F <tessera_rocm_folded_matmul_a870cecb1991940b+0x3b60>
	v_cvt_f64_f32_e32 v[16:17], v15                            // 000000006D24: 7E20210F
	v_cvt_f64_f32_e32 v[20:21], v25                            // 000000006D28: 7E282119
	v_cvt_f64_f32_e32 v[22:23], v19                            // 000000006D2C: 7E2C2113
	v_cmp_eq_f32_e32 vcc_lo, 0, v15                            // 000000006D30: 7C241E80
	v_cmp_class_f32_e64 s1, v19, 0x1f8                         // 000000006D34: D47E0001 0201FF13 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006D40: 8B01016A
	v_mul_f64_e32 v[16:17], v[16:17], v[20:21]                 // 000000006D44: 0C202910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006D48: BF870091
	v_mul_f64_e32 v[16:17], v[16:17], v[22:23]                 // 000000006D4C: 0C202D10
	v_cvt_f32_f64_e32 v14, v[16:17]                            // 000000006D50: 7E1C1F10
	s_wait_alu depctr_sa_sdst(0)                               // 000000006D54: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006D58: BF870001
	v_cndmask_b32_e64 v14, v14, 0, s1                          // 000000006D5C: D501000E 0005010E
	s_branch 64074                                             // 000000006D64: BFA0FA4A <tessera_rocm_folded_matmul_a870cecb1991940b+0x3b90>
	v_cvt_f64_f32_e32 v[18:19], v0                             // 000000006D68: 7E242100
	v_cvt_f64_f32_e32 v[20:21], v17                            // 000000006D6C: 7E282111
	v_cvt_f64_f32_e32 v[22:23], v12                            // 000000006D70: 7E2C210C
	v_cmp_eq_f32_e32 vcc_lo, 0, v0                             // 000000006D74: 7C240080
	v_cmp_class_f32_e64 s1, v12, 0x1f8                         // 000000006D78: D47E0001 0201FF0C 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006D84: 8B01016A
	v_mul_f64_e32 v[18:19], v[18:19], v[20:21]                 // 000000006D88: 0C242912
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006D8C: BF870091
	v_mul_f64_e32 v[18:19], v[18:19], v[22:23]                 // 000000006D90: 0C242D12
	v_cvt_f32_f64_e32 v16, v[18:19]                            // 000000006D94: 7E201F12
	s_wait_alu depctr_sa_sdst(0)                               // 000000006D98: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006D9C: BF870001
	v_cndmask_b32_e64 v16, v16, 0, s1                          // 000000006DA0: D5010010 00050110
	s_branch 64341                                             // 000000006DA8: BFA0FB55 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4000>
	v_cvt_f64_f32_e32 v[18:19], v1                             // 000000006DAC: 7E242101
	v_cvt_f64_f32_e32 v[20:21], v17                            // 000000006DB0: 7E282111
	v_cvt_f64_f32_e32 v[22:23], v13                            // 000000006DB4: 7E2C210D
	v_cmp_eq_f32_e32 vcc_lo, 0, v1                             // 000000006DB8: 7C240280
	v_cmp_class_f32_e64 s1, v13, 0x1f8                         // 000000006DBC: D47E0001 0201FF0D 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006DC8: 8B01016A
	v_mul_f64_e32 v[18:19], v[18:19], v[20:21]                 // 000000006DCC: 0C242912
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006DD0: BF870091
	v_mul_f64_e32 v[18:19], v[18:19], v[22:23]                 // 000000006DD4: 0C242D12
	v_cvt_f32_f64_e32 v0, v[18:19]                             // 000000006DD8: 7E001F12
	s_wait_alu depctr_sa_sdst(0)                               // 000000006DDC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006DE0: BF870001
	v_cndmask_b32_e64 v0, v0, 0, s1                            // 000000006DE4: D5010000 00050100
	s_branch 64336                                             // 000000006DEC: BFA0FB50 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4030>
	v_cvt_f64_f32_e32 v[12:13], v2                             // 000000006DF0: 7E182102
	v_cvt_f64_f32_e32 v[18:19], v17                            // 000000006DF4: 7E242111
	v_cvt_f64_f32_e32 v[20:21], v14                            // 000000006DF8: 7E28210E
	v_cmp_eq_f32_e32 vcc_lo, 0, v2                             // 000000006DFC: 7C240480
	v_cmp_class_f32_e64 s1, v14, 0x1f8                         // 000000006E00: D47E0001 0201FF0E 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006E0C: 8B01016A
	v_mul_f64_e32 v[12:13], v[12:13], v[18:19]                 // 000000006E10: 0C18250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006E14: BF870091
	v_mul_f64_e32 v[12:13], v[12:13], v[20:21]                 // 000000006E18: 0C18290C
	v_cvt_f32_f64_e32 v1, v[12:13]                             // 000000006E1C: 7E021F0C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006E20: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006E24: BF870001
	v_cndmask_b32_e64 v1, v1, 0, s1                            // 000000006E28: D5010001 00050101
	s_branch 64331                                             // 000000006E30: BFA0FB4B <tessera_rocm_folded_matmul_a870cecb1991940b+0x4060>
	v_cvt_f64_f32_e32 v[12:13], v3                             // 000000006E34: 7E182103
	v_cvt_f64_f32_e32 v[18:19], v17                            // 000000006E38: 7E242111
	v_cvt_f64_f32_e32 v[20:21], v15                            // 000000006E3C: 7E28210F
	v_cmp_eq_f32_e32 vcc_lo, 0, v3                             // 000000006E40: 7C240680
	v_cmp_class_f32_e64 s1, v15, 0x1f8                         // 000000006E44: D47E0001 0201FF0F 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006E50: 8B01016A
	v_mul_f64_e32 v[12:13], v[12:13], v[18:19]                 // 000000006E54: 0C18250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006E58: BF870091
	v_mul_f64_e32 v[12:13], v[12:13], v[20:21]                 // 000000006E5C: 0C18290C
	v_cvt_f32_f64_e32 v2, v[12:13]                             // 000000006E60: 7E041F0C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006E64: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006E68: BF870001
	v_cndmask_b32_e64 v2, v2, 0, s1                            // 000000006E6C: D5010002 00050102
	s_branch 64326                                             // 000000006E74: BFA0FB46 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4090>
	v_cvt_f64_f32_e32 v[12:13], v4                             // 000000006E78: 7E182104
	v_cvt_f64_f32_e32 v[14:15], v17                            // 000000006E7C: 7E1C2111
	v_cvt_f64_f32_e32 v[18:19], v8                             // 000000006E80: 7E242108
	v_cmp_eq_f32_e32 vcc_lo, 0, v4                             // 000000006E84: 7C240880
	v_cmp_class_f32_e64 s1, v8, 0x1f8                          // 000000006E88: D47E0001 0201FF08 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006E94: 8B01016A
	v_mul_f64_e32 v[12:13], v[12:13], v[14:15]                 // 000000006E98: 0C181D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006E9C: BF870091
	v_mul_f64_e32 v[12:13], v[12:13], v[18:19]                 // 000000006EA0: 0C18250C
	v_cvt_f32_f64_e32 v3, v[12:13]                             // 000000006EA4: 7E061F0C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006EA8: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006EAC: BF870001
	v_cndmask_b32_e64 v3, v3, 0, s1                            // 000000006EB0: D5010003 00050103
	s_branch 64321                                             // 000000006EB8: BFA0FB41 <tessera_rocm_folded_matmul_a870cecb1991940b+0x40c0>
	v_cvt_f64_f32_e32 v[12:13], v5                             // 000000006EBC: 7E182105
	v_cvt_f64_f32_e32 v[14:15], v17                            // 000000006EC0: 7E1C2111
	v_cvt_f64_f32_e32 v[18:19], v9                             // 000000006EC4: 7E242109
	v_cmp_eq_f32_e32 vcc_lo, 0, v5                             // 000000006EC8: 7C240A80
	v_cmp_class_f32_e64 s1, v9, 0x1f8                          // 000000006ECC: D47E0001 0201FF09 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006ED8: 8B01016A
	v_mul_f64_e32 v[12:13], v[12:13], v[14:15]                 // 000000006EDC: 0C181D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006EE0: BF870091
	v_mul_f64_e32 v[12:13], v[12:13], v[18:19]                 // 000000006EE4: 0C18250C
	v_cvt_f32_f64_e32 v4, v[12:13]                             // 000000006EE8: 7E081F0C
	s_wait_alu depctr_sa_sdst(0)                               // 000000006EEC: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006EF0: BF870001
	v_cndmask_b32_e64 v4, v4, 0, s1                            // 000000006EF4: D5010004 00050104
	s_branch 64316                                             // 000000006EFC: BFA0FB3C <tessera_rocm_folded_matmul_a870cecb1991940b+0x40f0>
	v_cvt_f64_f32_e32 v[8:9], v6                               // 000000006F00: 7E102106
	v_cvt_f64_f32_e32 v[12:13], v17                            // 000000006F04: 7E182111
	v_cvt_f64_f32_e32 v[14:15], v10                            // 000000006F08: 7E1C210A
	v_cmp_eq_f32_e32 vcc_lo, 0, v6                             // 000000006F0C: 7C240C80
	v_cmp_class_f32_e64 s1, v10, 0x1f8                         // 000000006F10: D47E0001 0201FF0A 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006F1C: 8B01016A
	v_mul_f64_e32 v[8:9], v[8:9], v[12:13]                     // 000000006F20: 0C101908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006F24: BF870091
	v_mul_f64_e32 v[8:9], v[8:9], v[14:15]                     // 000000006F28: 0C101D08
	v_cvt_f32_f64_e32 v5, v[8:9]                               // 000000006F2C: 7E0A1F08
	s_wait_alu depctr_sa_sdst(0)                               // 000000006F30: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006F34: BF870001
	v_cndmask_b32_e64 v5, v5, 0, s1                            // 000000006F38: D5010005 00050105
	s_branch 64311                                             // 000000006F40: BFA0FB37 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4120>
	v_cvt_f64_f32_e32 v[8:9], v7                               // 000000006F44: 7E102107
	v_cvt_f64_f32_e32 v[12:13], v17                            // 000000006F48: 7E182111
	v_cvt_f64_f32_e32 v[14:15], v11                            // 000000006F4C: 7E1C210B
	v_cmp_eq_f32_e32 vcc_lo, 0, v7                             // 000000006F50: 7C240E80
	v_cmp_class_f32_e64 s1, v11, 0x1f8                         // 000000006F54: D47E0001 0201FF0B 000001F8
	s_and_b32 s1, vcc_lo, s1                                   // 000000006F60: 8B01016A
	v_mul_f64_e32 v[8:9], v[8:9], v[12:13]                     // 000000006F64: 0C101908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000006F68: BF870091
	v_mul_f64_e32 v[8:9], v[8:9], v[14:15]                     // 000000006F6C: 0C101D08
	v_cvt_f32_f64_e32 v6, v[8:9]                               // 000000006F70: 7E0C1F08
	s_wait_alu depctr_sa_sdst(0)                               // 000000006F74: BF88FF9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000006F78: BF870001
	v_cndmask_b32_e64 v6, v6, 0, s1                            // 000000006F7C: D5010006 00050106
	s_branch 64306                                             // 000000006F84: BFA0FB32 <tessera_rocm_folded_matmul_a870cecb1991940b+0x4150>
	s_code_end                                                 // 000000006F88: BF9F0000
	s_code_end                                                 // 000000006F8C: BF9F0000
	s_code_end                                                 // 000000006F90: BF9F0000
	s_code_end                                                 // 000000006F94: BF9F0000
	s_code_end                                                 // 000000006F98: BF9F0000
	s_code_end                                                 // 000000006F9C: BF9F0000
	s_code_end                                                 // 000000006FA0: BF9F0000
	s_code_end                                                 // 000000006FA4: BF9F0000
	s_code_end                                                 // 000000006FA8: BF9F0000
	s_code_end                                                 // 000000006FAC: BF9F0000
	s_code_end                                                 // 000000006FB0: BF9F0000
	s_code_end                                                 // 000000006FB4: BF9F0000
	s_code_end                                                 // 000000006FB8: BF9F0000
	s_code_end                                                 // 000000006FBC: BF9F0000
	s_code_end                                                 // 000000006FC0: BF9F0000
	s_code_end                                                 // 000000006FC4: BF9F0000
	s_code_end                                                 // 000000006FC8: BF9F0000
	s_code_end                                                 // 000000006FCC: BF9F0000
	s_code_end                                                 // 000000006FD0: BF9F0000
	s_code_end                                                 // 000000006FD4: BF9F0000
	s_code_end                                                 // 000000006FD8: BF9F0000
	s_code_end                                                 // 000000006FDC: BF9F0000
	s_code_end                                                 // 000000006FE0: BF9F0000
	s_code_end                                                 // 000000006FE4: BF9F0000
	s_code_end                                                 // 000000006FE8: BF9F0000
	s_code_end                                                 // 000000006FEC: BF9F0000
	s_code_end                                                 // 000000006FF0: BF9F0000
	s_code_end                                                 // 000000006FF4: BF9F0000
	s_code_end                                                 // 000000006FF8: BF9F0000
	s_code_end                                                 // 000000006FFC: BF9F0000
	s_code_end                                                 // 000000007000: BF9F0000
	s_code_end                                                 // 000000007004: BF9F0000
	s_code_end                                                 // 000000007008: BF9F0000
	s_code_end                                                 // 00000000700C: BF9F0000
	s_code_end                                                 // 000000007010: BF9F0000
	s_code_end                                                 // 000000007014: BF9F0000
	s_code_end                                                 // 000000007018: BF9F0000
	s_code_end                                                 // 00000000701C: BF9F0000
	s_code_end                                                 // 000000007020: BF9F0000
	s_code_end                                                 // 000000007024: BF9F0000
	s_code_end                                                 // 000000007028: BF9F0000
	s_code_end                                                 // 00000000702C: BF9F0000
	s_code_end                                                 // 000000007030: BF9F0000
	s_code_end                                                 // 000000007034: BF9F0000
	s_code_end                                                 // 000000007038: BF9F0000
	s_code_end                                                 // 00000000703C: BF9F0000
	s_code_end                                                 // 000000007040: BF9F0000
	s_code_end                                                 // 000000007044: BF9F0000
	s_code_end                                                 // 000000007048: BF9F0000
	s_code_end                                                 // 00000000704C: BF9F0000
	s_code_end                                                 // 000000007050: BF9F0000
	s_code_end                                                 // 000000007054: BF9F0000
	s_code_end                                                 // 000000007058: BF9F0000
	s_code_end                                                 // 00000000705C: BF9F0000
	s_code_end                                                 // 000000007060: BF9F0000
	s_code_end                                                 // 000000007064: BF9F0000
	s_code_end                                                 // 000000007068: BF9F0000
	s_code_end                                                 // 00000000706C: BF9F0000
	s_code_end                                                 // 000000007070: BF9F0000
	s_code_end                                                 // 000000007074: BF9F0000
	s_code_end                                                 // 000000007078: BF9F0000
	s_code_end                                                 // 00000000707C: BF9F0000
	s_code_end                                                 // 000000007080: BF9F0000
	s_code_end                                                 // 000000007084: BF9F0000
	s_code_end                                                 // 000000007088: BF9F0000
	s_code_end                                                 // 00000000708C: BF9F0000
	s_code_end                                                 // 000000007090: BF9F0000
	s_code_end                                                 // 000000007094: BF9F0000
	s_code_end                                                 // 000000007098: BF9F0000
	s_code_end                                                 // 00000000709C: BF9F0000
	s_code_end                                                 // 0000000070A0: BF9F0000
	s_code_end                                                 // 0000000070A4: BF9F0000
	s_code_end                                                 // 0000000070A8: BF9F0000
	s_code_end                                                 // 0000000070AC: BF9F0000
	s_code_end                                                 // 0000000070B0: BF9F0000
	s_code_end                                                 // 0000000070B4: BF9F0000
	s_code_end                                                 // 0000000070B8: BF9F0000
	s_code_end                                                 // 0000000070BC: BF9F0000
	s_code_end                                                 // 0000000070C0: BF9F0000
	s_code_end                                                 // 0000000070C4: BF9F0000
	s_code_end                                                 // 0000000070C8: BF9F0000
	s_code_end                                                 // 0000000070CC: BF9F0000
	s_code_end                                                 // 0000000070D0: BF9F0000
	s_code_end                                                 // 0000000070D4: BF9F0000
	s_code_end                                                 // 0000000070D8: BF9F0000
	s_code_end                                                 // 0000000070DC: BF9F0000
	s_code_end                                                 // 0000000070E0: BF9F0000
	s_code_end                                                 // 0000000070E4: BF9F0000
	s_code_end                                                 // 0000000070E8: BF9F0000
	s_code_end                                                 // 0000000070EC: BF9F0000
	s_code_end                                                 // 0000000070F0: BF9F0000
	s_code_end                                                 // 0000000070F4: BF9F0000
	s_code_end                                                 // 0000000070F8: BF9F0000
	s_code_end                                                 // 0000000070FC: BF9F0000
	s_code_end                                                 // 000000007100: BF9F0000
	s_code_end                                                 // 000000007104: BF9F0000
	s_code_end                                                 // 000000007108: BF9F0000
	s_code_end                                                 // 00000000710C: BF9F0000
	s_code_end                                                 // 000000007110: BF9F0000
	s_code_end                                                 // 000000007114: BF9F0000
	s_code_end                                                 // 000000007118: BF9F0000
	s_code_end                                                 // 00000000711C: BF9F0000
	s_code_end                                                 // 000000007120: BF9F0000
	s_code_end                                                 // 000000007124: BF9F0000
	s_code_end                                                 // 000000007128: BF9F0000
	s_code_end                                                 // 00000000712C: BF9F0000
	s_code_end                                                 // 000000007130: BF9F0000
	s_code_end                                                 // 000000007134: BF9F0000
	s_code_end                                                 // 000000007138: BF9F0000
	s_code_end                                                 // 00000000713C: BF9F0000
	s_code_end                                                 // 000000007140: BF9F0000
	s_code_end                                                 // 000000007144: BF9F0000
	s_code_end                                                 // 000000007148: BF9F0000
	s_code_end                                                 // 00000000714C: BF9F0000
	s_code_end                                                 // 000000007150: BF9F0000
	s_code_end                                                 // 000000007154: BF9F0000
	s_code_end                                                 // 000000007158: BF9F0000
	s_code_end                                                 // 00000000715C: BF9F0000
	s_code_end                                                 // 000000007160: BF9F0000
	s_code_end                                                 // 000000007164: BF9F0000
	s_code_end                                                 // 000000007168: BF9F0000
	s_code_end                                                 // 00000000716C: BF9F0000
	s_code_end                                                 // 000000007170: BF9F0000
	s_code_end                                                 // 000000007174: BF9F0000
	s_code_end                                                 // 000000007178: BF9F0000
	s_code_end                                                 // 00000000717C: BF9F0000
