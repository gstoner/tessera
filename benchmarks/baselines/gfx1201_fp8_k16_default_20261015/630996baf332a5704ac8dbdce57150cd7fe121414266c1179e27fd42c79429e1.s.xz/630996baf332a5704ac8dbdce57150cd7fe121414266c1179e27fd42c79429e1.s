
/tmp/tmpw40ocanh.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

disassembly of section .text:

0000000000001b00 <tessera_rocm_scaled_matmul_db789d6585c8dc9d>:
	s_clause 0x6                                               // 000000001b00: bf850006
	s_load_b128 s[36:39], s[0:1], 0xc8                         // 000000001b04: f4004900 f80000c8
	s_load_b64 s[46:47], s[0:1], 0xd8                          // 000000001b0c: f4002b80 f80000d8
	s_load_b64 s[40:41], s[0:1], 0xa8                          // 000000001b14: f4002a00 f80000a8
	s_load_b64 s[48:49], s[0:1], 0x8                           // 000000001b1c: f4002c00 f8000008
	s_load_b64 s[50:51], s[0:1], 0x30                          // 000000001b24: f4002c80 f8000030
	s_load_b64 s[52:53], s[0:1], 0x58                          // 000000001b2c: f4002d00 f8000058
	s_load_b64 s[60:61], s[0:1], 0x80                          // 000000001b34: f4002f00 f8000080
	s_mov_b32 s2, ttmp9                                        // 000000001b3c: be820075
	s_mov_b32 s4, ttmp7                                        // 000000001b40: be840073
	s_ashr_i32 s3, ttmp9, 31                                   // 000000001b44: 86039f75
	s_ashr_i32 s5, ttmp7, 31                                   // 000000001b48: 86059f73
	s_lshl_b64 s[56:57], s[2:3], 4                             // 000000001b4c: 84b88402
	s_lshl_b64 s[54:55], s[4:5], 4                             // 000000001b50: 84b68404
	s_add_nc_u64 s[2:3], s[56:57], 16                          // 000000001b54: a9829038
	s_add_nc_u64 s[0:1], s[54:55], 16                          // 000000001b58: a9809036
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v23, 15, v0        // 000000001b5c: ca240080 1816008f
	v_mov_b32_e32 v4, s57                                      // 000000001b64: 7e080239
	v_bfe_u32 v15, v0, 4, 1                                    // 000000001b68: d610000f 02050900
	s_delay_alu instid0(valu_dep_3)                            // 000000001b70: bf870003
	v_or_b32_e32 v3, s56, v23                                  // 000000001b74: 38062e38
	s_wait_kmcnt 0x0                                           // 000000001b78: bfc70000
	v_cmp_gt_i64_e64 s0, s[0:1], s[36:37]                      // 000000001b7c: d4540000 02004800
	v_cmp_gt_i64_e64 s1, s[2:3], s[38:39]                      // 000000001b84: d4540001 02004c02
	v_cmp_gt_i64_e64 s35, s[46:47], 31                         // 000000001b8c: d4540023 02013e2e
	s_lshr_b64 s[58:59], s[46:47], 4                           // 000000001b94: 85ba842e
	s_and_b32 s42, s46, -16                                    // 000000001b98: 8b2ad02e
	s_mov_b32 s43, s47                                         // 000000001b9c: beab002f
	s_and_b32 s44, s46, 0xffffffe0                             // 000000001ba0: 8b2cff2e ffffffe0
	s_or_b32 s0, s0, s1                                        // 000000001ba8: 8c000100
	s_mov_b32 s45, s47                                         // 000000001bac: bead002f
	s_wait_alu depctr_sa_sdst(0)                               // 000000001bb0: bf88ff9e
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000001bb4: 8b6a007e
	s_cbranch_vccz 1326                                        // 000000001bb8: bfa3052e <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x1574>
	v_dual_mov_b32 v6, s55 :: v_dual_mov_b32 v17, 0            // 000000001bbc: ca100037 06100080
	v_or_b32_e32 v5, s54, v23                                  // 000000001bc4: 380a2e36
	s_and_b32 s0, s35, exec_lo                                 // 000000001bc8: 8b007e23
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v19, 0              // 000000001bcc: ca100080 02120080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v1, 0              // 000000001bd4: ca100080 10000080
	s_delay_alu instid0(valu_dep_3)                            // 000000001bdc: bf870003
	v_cmp_gt_i64_e64 s0, s[36:37], v[5:6]                      // 000000001be0: d4540000 02020a24
	v_mov_b32_e32 v18, 0                                       // 000000001be8: 7e240280
	v_mov_b32_e32 v20, 0                                       // 000000001bec: 7e280280
	s_cselect_b32 s1, 1, 0                                     // 000000001bf0: 98018081
	s_wait_alu depctr_sa_sdst(0)                               // 000000001bf4: bf88ff9e
	s_cmp_lg_u32 s1, 1                                         // 000000001bf8: bf078101
	s_cbranch_scc1 1297                                        // 000000001bfc: bfa20511 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x1544>
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v0, 3, v15      // 000000001c00: ca220080 01001e83
	v_cmp_gt_i64_e64 s1, s[38:39], v[3:4]                      // 000000001c08: d4540001 02020626
	v_dual_mov_b32 v12, s55 :: v_dual_mov_b32 v17, s55         // 000000001c10: ca100037 0c100037
	s_delay_alu instid0(valu_dep_3)                            // 000000001c18: bf870003
	v_or_b32_e32 v9, s54, v0                                   // 000000001c1c: 38120036
	v_mov_b32_e32 v10, s55                                     // 000000001c20: 7e140237
	s_lshl_b64 s[62:63], s[38:39], 2                           // 000000001c24: 84be8226
	v_cndmask_b32_e64 v8, 0, v4, s1                            // 000000001c28: d5010008 00060880
	v_cndmask_b32_e64 v7, 0, v3, s1                            // 000000001c30: d5010007 00060680
	v_or_b32_e32 v11, 1, v9                                    // 000000001c38: 38161281
	v_or_b32_e32 v13, 2, v9                                    // 000000001c3c: 381a1282
	v_mov_b32_e32 v14, s55                                     // 000000001c40: 7e1c0237
	v_or_b32_e32 v16, 4, v9                                    // 000000001c44: 38201284
	v_lshlrev_b64_e32 v[7:8], 2, v[7:8]                        // 000000001c48: 3e0e0e82
	v_cmp_gt_i64_e64 s2, s[36:37], v[11:12]                    // 000000001c4c: d4540002 02021624
	v_or_b32_e32 v12, 6, v9                                    // 000000001c54: 38181286
	s_lshl_b64 s[64:65], s[38:39], 3                           // 000000001c58: 84c08326
	s_mov_b64 s[66:67], 0                                      // 000000001c5c: bec20180
	s_mov_b64 s[68:69], s[52:53]                               // 000000001c60: bec40134
	v_cndmask_b32_e64 v18, 0, v11, s2                          // 000000001c64: d5010012 000a1680
	v_mov_b32_e32 v11, s55                                     // 000000001c6c: 7e160237
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[9:10]                 // 000000001c70: 7ca81224
	v_or_b32_e32 v10, 3, v9                                    // 000000001c74: 38141283
	v_cndmask_b32_e64 v20, 0, s55, s2                          // 000000001c78: d5010014 00086e80
	v_cmp_gt_i64_e64 s2, s[36:37], v[16:17]                    // 000000001c80: d4540002 02022024
	v_mul_lo_u32 v28, v18, s59                                 // 000000001c88: d72c001c 02007712
	v_cndmask_b32_e32 v2, 0, v9, vcc_lo                        // 000000001c90: 02041280
	v_cndmask_b32_e64 v19, 0, s55, vcc_lo                      // 000000001c94: d5010013 01a86e80
	v_add_co_u32 v7, vcc_lo, s60, v7                           // 000000001c9c: d7006a07 02020e3c
	s_wait_alu depctr_va_vcc(0)                                // 000000001ca4: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s61, v8, vcc_lo              // 000000001ca8: d5207c08 01aa103d
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[13:14]                // 000000001cb0: 7ca81a24
	s_wait_alu depctr_va_sdst(0)                               // 000000001cb4: bf88f19f
	v_cndmask_b32_e64 v26, 0, v16, s2                          // 000000001cb8: d501001a 000a2080
	v_cndmask_b32_e64 v27, 0, s55, s2                          // 000000001cc0: d501001b 00086e80
	s_wait_alu depctr_va_vcc(0)                                // 000000001cc8: bf88ff9d
	v_cndmask_b32_e32 v21, 0, v13, vcc_lo                      // 000000001ccc: 022a1a80
	v_cndmask_b32_e64 v22, 0, s55, vcc_lo                      // 000000001cd0: d5010016 01a86e80
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[10:11]                // 000000001cd8: 7ca81424
	v_mov_b32_e32 v13, s55                                     // 000000001cdc: 7e1a0237
	v_mad_co_u64_u32 v[16:17], null, v2, s58, 0                // 000000001ce0: d6fe7c10 02007502
	s_wait_alu depctr_va_vcc(0)                                // 000000001ce8: bf88ff9d
	v_cndmask_b32_e32 v24, 0, v10, vcc_lo                      // 000000001cec: 02301480
	v_or_b32_e32 v10, 5, v9                                    // 000000001cf0: 38141285
	v_cndmask_b32_e64 v25, 0, s55, vcc_lo                      // 000000001cf4: d5010019 01a86e80
	v_cmp_gt_i64_e64 s2, s[36:37], v[12:13]                    // 000000001cfc: d4540002 02021824
	v_or_b32_e32 v13, 7, v9                                    // 000000001d04: 381a1287
	v_mul_lo_u32 v9, v2, s59                                   // 000000001d08: d72c0009 02007702
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[10:11]                // 000000001d10: 7ca81424
	v_mul_lo_u32 v2, v19, s58                                  // 000000001d14: d72c0002 02007513
	s_wait_alu depctr_va_sdst(0)                               // 000000001d1c: bf88f19f
	v_cndmask_b32_e64 v33, 0, v12, s2                          // 000000001d20: d5010021 000a1880
	v_mad_co_u64_u32 v[11:12], null, v18, s58, 0               // 000000001d28: d6fe7c0b 02007512
	v_mul_lo_u32 v18, v20, s58                                 // 000000001d30: d72c0012 02007514
	s_wait_alu depctr_va_vcc(0)                                // 000000001d38: bf88ff9d
	v_cndmask_b32_e32 v31, 0, v10, vcc_lo                      // 000000001d3c: 023e1480
	v_cndmask_b32_e64 v32, 0, s55, vcc_lo                      // 000000001d40: d5010020 01a86e80
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[13:14]                // 000000001d48: 7ca81a24
	v_mul_lo_u32 v20, v21, s59                                 // 000000001d4c: d72c0014 02007715
	v_cndmask_b32_e64 v34, 0, s55, s2                          // 000000001d54: d5010022 00086e80
	v_add3_u32 v17, v17, v9, v2                                // 000000001d5c: d6550011 040a1311
	v_add_co_u32 v2, s2, s56, v23                              // 000000001d64: d7000202 02022e38
	s_wait_alu depctr_va_vcc(0)                                // 000000001d6c: bf88ff9d
	v_cndmask_b32_e32 v35, 0, v13, vcc_lo                      // 000000001d70: 02461a80
	v_mad_co_u64_u32 v[13:14], null, v21, s58, 0               // 000000001d74: d6fe7c0d 02007515
	v_mul_lo_u32 v21, v22, s58                                 // 000000001d7c: d72c0015 02007516
	s_wait_alu depctr_va_sdst(0)                               // 000000001d84: bf88f19f
	v_add_co_ci_u32_e64 v19, null, s57, 0, s2                  // 000000001d88: d5207c13 00090039
	v_add3_u32 v12, v12, v28, v18                              // 000000001d90: d655000c 044a390c
	v_lshlrev_b64_e32 v[16:17], 2, v[16:17]                    // 000000001d98: 3e202082
	v_mad_co_u64_u32 v[9:10], null, s46, v2, v[0:1]            // 000000001d9c: d6fe7c09 0402042e
	s_delay_alu instid0(valu_dep_4)                            // 000000001da4: bf870004
	v_mul_lo_u32 v29, s46, v19                                 // 000000001da8: d72c001d 0202262e
	v_mad_co_u64_u32 v[18:19], null, v24, s58, 0               // 000000001db0: d6fe7c12 02007518
	v_add3_u32 v14, v14, v20, v21                              // 000000001db8: d655000e 0456290e
	v_mul_lo_u32 v20, v24, s59                                 // 000000001dc0: d72c0014 02007718
	v_mul_lo_u32 v24, v25, s58                                 // 000000001dc8: d72c0018 02007519
	v_mul_lo_u32 v2, s47, v2                                   // 000000001dd0: d72c0002 0202042f
	v_lshlrev_b64_e32 v[11:12], 2, v[11:12]                    // 000000001dd8: 3e161682
	v_cndmask_b32_e64 v36, 0, s55, vcc_lo                      // 000000001ddc: d5010024 01a86e80
	v_add_co_u32 v21, vcc_lo, v16, 4                           // 000000001de4: d7006a15 02010910
	s_wait_alu depctr_va_vcc(0)                                // 000000001dec: bf88ff9d
	v_add_co_ci_u32_e64 v22, null, 0, v17, vcc_lo              // 000000001df0: d5207c16 01aa2280
	v_add3_u32 v19, v19, v20, v24                              // 000000001df8: d6550013 04622913
	v_lshlrev_b64_e32 v[13:14], 2, v[13:14]                    // 000000001e00: 3e1a1a82
	v_add_co_u32 v25, vcc_lo, v11, 4                           // 000000001e04: d7006a19 0201090b
	v_add3_u32 v10, v2, v10, v29                               // 000000001e0c: d655000a 04761502
	v_mul_lo_u32 v2, v26, s59                                  // 000000001e14: d72c0002 0200771a
	v_mad_co_u64_u32 v[16:17], null, v26, s58, 0               // 000000001e1c: d6fe7c10 0200751a
	v_mul_lo_u32 v20, v27, s58                                 // 000000001e24: d72c0014 0200751b
	s_wait_alu depctr_va_vcc(0)                                // 000000001e2c: bf88ff9d
	v_add_co_ci_u32_e64 v26, null, 0, v12, vcc_lo              // 000000001e30: d5207c1a 01aa1880
	v_lshlrev_b64_e32 v[11:12], 2, v[18:19]                    // 000000001e38: 3e162482
	v_add_co_u32 v27, vcc_lo, v13, 4                           // 000000001e3c: d7006a1b 0201090d
	s_wait_alu depctr_va_vcc(0)                                // 000000001e44: bf88ff9d
	v_add_co_ci_u32_e64 v28, null, 0, v14, vcc_lo              // 000000001e48: d5207c1c 01aa1c80
	v_add3_u32 v17, v17, v2, v20                               // 000000001e50: d6550011 04520511
	s_delay_alu instid0(valu_dep_4)                            // 000000001e58: bf870004
	v_add_co_u32 v29, vcc_lo, v11, 4                           // 000000001e5c: d7006a1d 0201090b
	s_wait_alu depctr_va_vcc(0)                                // 000000001e64: bf88ff9d
	v_add_co_ci_u32_e64 v30, null, 0, v12, vcc_lo              // 000000001e68: d5207c1e 01aa1880
	v_mul_lo_u32 v2, v31, s59                                  // 000000001e70: d72c0002 0200771f
	v_mad_co_u64_u32 v[11:12], null, v31, s58, 0               // 000000001e78: d6fe7c0b 0200751f
	v_mul_lo_u32 v20, v32, s58                                 // 000000001e80: d72c0014 02007520
	v_lshlrev_b64_e32 v[13:14], 2, v[16:17]                    // 000000001e88: 3e1a2082
	v_mul_lo_u32 v24, v33, s59                                 // 000000001e8c: d72c0018 02007721
	v_mad_co_u64_u32 v[16:17], null, v33, s58, 0               // 000000001e94: d6fe7c10 02007521
	v_mul_lo_u32 v33, v34, s58                                 // 000000001e9c: d72c0021 02007522
	v_mul_lo_u32 v34, v35, s59                                 // 000000001ea4: d72c0022 02007723
	v_mad_co_u64_u32 v[18:19], null, v35, s58, 0               // 000000001eac: d6fe7c12 02007523
	v_mul_lo_u32 v35, v36, s58                                 // 000000001eb4: d72c0023 02007524
	v_add3_u32 v12, v12, v2, v20                               // 000000001ebc: d655000c 0452050c
	v_add_co_u32 v2, s2, s54, v23                              // 000000001ec4: d7000202 02022e36
	s_wait_alu depctr_va_sdst(0)                               // 000000001ecc: bf88f19f
	v_add_co_ci_u32_e64 v20, null, s55, 0, s2                  // 000000001ed0: d5207c14 00090037
	s_delay_alu instid0(valu_dep_3)                            // 000000001ed8: bf870003
	v_lshlrev_b64_e32 v[11:12], 2, v[11:12]                    // 000000001edc: 3e161682
	v_add3_u32 v17, v17, v24, v33                              // 000000001ee0: d6550011 04863111
	v_add3_u32 v19, v19, v34, v35                              // 000000001ee8: d6550013 048e4513
	v_add_co_u32 v31, vcc_lo, v13, 4                           // 000000001ef0: d7006a1f 0201090d
	s_wait_alu depctr_va_vcc(0)                                // 000000001ef8: bf88ff9d
	v_add_co_ci_u32_e64 v32, null, 0, v14, vcc_lo              // 000000001efc: d5207c20 01aa1c80
	v_add_co_u32 v33, vcc_lo, v11, 4                           // 000000001f04: d7006a21 0201090b
	v_lshlrev_b64_e32 v[13:14], 2, v[16:17]                    // 000000001f0c: 3e1a2082
	s_wait_alu depctr_va_vcc(0)                                // 000000001f10: bf88ff9d
	v_add_co_ci_u32_e64 v34, null, 0, v12, vcc_lo              // 000000001f14: d5207c22 01aa1880
	v_lshlrev_b64_e32 v[16:17], 2, v[18:19]                    // 000000001f1c: 3e202482
	v_mad_co_u64_u32 v[11:12], null, s46, v2, v[0:1]           // 000000001f20: d6fe7c0b 0402042e
	v_mul_lo_u32 v18, s46, v20                                 // 000000001f28: d72c0012 0202282e
	v_mul_lo_u32 v2, s47, v2                                   // 000000001f30: d72c0002 0202042f
	v_add_co_u32 v35, vcc_lo, v13, 4                           // 000000001f38: d7006a23 0201090d
	s_wait_alu depctr_va_vcc(0)                                // 000000001f40: bf88ff9d
	v_add_co_ci_u32_e64 v36, null, 0, v14, vcc_lo              // 000000001f44: d5207c24 01aa1c80
	v_add_co_u32 v37, vcc_lo, v16, 4                           // 000000001f4c: d7006a25 02010910
	s_wait_alu depctr_va_vcc(0)                                // 000000001f54: bf88ff9d
	v_add_co_ci_u32_e64 v38, null, 0, v17, vcc_lo              // 000000001f58: d5207c26 01aa2280
	v_add3_u32 v12, v2, v12, v18                               // 000000001f60: d655000c 044a1902
	v_dual_mov_b32 v20, v1 :: v_dual_mov_b32 v19, v1           // 000000001f68: ca100101 14120101
	v_dual_mov_b32 v18, v1 :: v_dual_mov_b32 v17, v1           // 000000001f70: ca100101 12100101
	v_mov_b32_e32 v16, v1                                      // 000000001f78: 7e200301
	v_mov_b32_e32 v2, v1                                       // 000000001f7c: 7e040301
	v_mov_b32_e32 v24, v1                                      // 000000001f80: 7e300301
	v_add_co_u32 v13, s2, v0, s66                              // 000000001f84: d700020d 02008500
	s_wait_alu depctr_va_sdst(0)                               // 000000001f8c: bf88f19f
	v_add_co_ci_u32_e64 v14, null, 0, s67, s2                  // 000000001f90: d5207c0e 00088680
	global_load_b32 v79, v[7:8], off                           // 000000001f98: ee05007c 0000004f 00000007
	v_add_co_u32 v41, vcc_lo, v13, 1                           // 000000001fa4: d7006a29 0201030d
	s_wait_alu depctr_va_vcc(0)                                // 000000001fac: bf88ff9d
	v_add_co_ci_u32_e64 v42, null, 0, v14, vcc_lo              // 000000001fb0: d5207c2a 01aa1c80
	v_add_co_u32 v39, vcc_lo, v11, s66                         // 000000001fb8: d7006a27 0200850b
	v_cmp_gt_i64_e64 s9, s[46:47], v[13:14]                    // 000000001fc0: d4540009 02021a2e
	s_wait_alu depctr_va_vcc(0)                                // 000000001fc8: bf88ff9d
	v_add_co_ci_u32_e64 v40, null, s67, v12, vcc_lo            // 000000001fcc: d5207c28 01aa1843
	v_cmp_gt_i64_e64 s10, s[46:47], v[41:42]                   // 000000001fd4: d454000a 0202522e
	v_add_co_u32 v41, vcc_lo, v39, 1                           // 000000001fdc: d7006a29 02010327
	s_wait_alu depctr_va_vcc(0)                                // 000000001fe4: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001fe8: bf870003
	v_add_co_ci_u32_e64 v42, null, 0, v40, vcc_lo              // 000000001fec: d5207c2a 01aa5080
	s_and_b32 vcc_lo, s0, s9                                   // 000000001ff4: 8b6a0900
	s_and_b32 s2, s0, s10                                      // 000000001ff8: 8b020a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000001ffc: bf88ff9e
	v_dual_cndmask_b32 v43, 0, v40 :: v_dual_cndmask_b32 v44, 0, v39// 000000002000: ca525080 2b2c4e80
	v_cndmask_b32_e64 v46, 0, v41, s2                          // 000000002008: d501002e 000a5280
	v_cndmask_b32_e64 v45, 0, v42, s2                          // 000000002010: d501002d 000a5480
	s_and_b32 s9, s1, s9                                       // 000000002018: 8b090901
	s_and_b32 s10, s1, s10                                     // 00000000201c: 8b0a0a01
	v_add_co_u32 v41, s3, s48, v44                             // 000000002020: d7000329 02025830
	s_wait_alu depctr_va_sdst(0)                               // 000000002028: bf88f19f
	v_add_co_ci_u32_e64 v42, null, s49, v43, s3                // 00000000202c: d5207c2a 000e5631
	v_add_co_u32 v43, s3, s48, v46                             // 000000002034: d700032b 02025c30
	s_wait_alu depctr_va_sdst(0)                               // 00000000203c: bf88f19f
	v_add_co_ci_u32_e64 v44, null, s49, v45, s3                // 000000002040: d5207c2c 000e5a31
	v_add_co_u32 v45, s3, v13, 2                               // 000000002048: d700032d 0201050d
	s_wait_alu depctr_va_sdst(0)                               // 000000002050: bf88f19f
	v_add_co_ci_u32_e64 v46, null, 0, v14, s3                  // 000000002054: d5207c2e 000e1c80
	v_add_co_u32 v47, s3, v13, 3                               // 00000000205c: d700032f 0201070d
	s_wait_alu depctr_va_sdst(0)                               // 000000002064: bf88f19f
	v_add_co_ci_u32_e64 v48, null, 0, v14, s3                  // 000000002068: d5207c30 000e1c80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002070: bf8701a3
	v_cmp_gt_i64_e64 s11, s[46:47], v[45:46]                   // 000000002074: d454000b 02025a2e
	v_add_co_u32 v49, s3, v39, 2                               // 00000000207c: d7000331 02010527
	v_cmp_gt_i64_e64 s13, s[46:47], v[47:48]                   // 000000002084: d454000d 02025e2e
	s_wait_alu depctr_va_sdst(0)                               // 00000000208c: bf88f19f
	v_add_co_ci_u32_e64 v50, null, 0, v40, s3                  // 000000002090: d5207c32 000e5080
	v_add_co_u32 v45, s3, v39, 3                               // 000000002098: d700032d 02010727
	s_and_b32 s4, s0, s11                                      // 0000000020a0: 8b040b00
	v_add_co_ci_u32_e64 v46, null, 0, v40, s3                  // 0000000020a4: d5207c2e 000e5080
	s_wait_alu depctr_sa_sdst(0)                               // 0000000020ac: bf88ff9e
	v_cndmask_b32_e64 v48, 0, v49, s4                          // 0000000020b0: d5010030 00126280
	s_and_b32 s3, s0, s13                                      // 0000000020b8: 8b030d00
	v_cndmask_b32_e64 v47, 0, v50, s4                          // 0000000020bc: d501002f 00126480
	s_wait_alu depctr_sa_sdst(0)                               // 0000000020c4: bf88ff9e
	v_cndmask_b32_e64 v50, 0, v45, s3                          // 0000000020c8: d5010032 000e5a80
	v_cndmask_b32_e64 v49, 0, v46, s3                          // 0000000020d0: d5010031 000e5c80
	v_add_co_u32 v45, s5, s48, v48                             // 0000000020d8: d700052d 02026030
	s_wait_alu depctr_va_sdst(0)                               // 0000000020e0: bf88f19f
	v_add_co_ci_u32_e64 v46, null, s49, v47, s5                // 0000000020e4: d5207c2e 00165e31
	v_add_co_u32 v47, s5, s48, v50                             // 0000000020ec: d700052f 02026430
	s_wait_alu depctr_va_sdst(0)                               // 0000000020f4: bf88f19f
	v_add_co_ci_u32_e64 v48, null, s49, v49, s5                // 0000000020f8: d5207c30 00166231
	v_add_co_u32 v49, s5, v13, 4                               // 000000002100: d7000531 0201090d
	s_wait_alu depctr_va_sdst(0)                               // 000000002108: bf88f19f
	v_add_co_ci_u32_e64 v50, null, 0, v14, s5                  // 00000000210c: d5207c32 00161c80
	v_add_co_u32 v51, s5, v13, 5                               // 000000002114: d7000533 02010b0d
	s_wait_alu depctr_va_sdst(0)                               // 00000000211c: bf88f19f
	v_add_co_ci_u32_e64 v52, null, 0, v14, s5                  // 000000002120: d5207c34 00161c80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002128: bf8701a3
	v_cmp_gt_i64_e64 s14, s[46:47], v[49:50]                   // 00000000212c: d454000e 0202622e
	v_add_co_u32 v53, s5, v39, 4                               // 000000002134: d7000535 02010927
	v_cmp_gt_i64_e64 s15, s[46:47], v[51:52]                   // 00000000213c: d454000f 0202662e
	s_wait_alu depctr_va_sdst(0)                               // 000000002144: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v40, s5                  // 000000002148: d5207c36 00165080
	v_add_co_u32 v49, s5, v39, 5                               // 000000002150: d7000531 02010b27
	s_wait_alu depctr_va_sdst(0)                               // 000000002158: bf88f19f
	v_add_co_ci_u32_e64 v50, null, 0, v40, s5                  // 00000000215c: d5207c32 00165080
	s_and_b32 s5, s0, s14                                      // 000000002164: 8b050e00
	s_and_b32 s6, s0, s15                                      // 000000002168: 8b060f00
	s_wait_alu depctr_sa_sdst(0)                               // 00000000216c: bf88ff9e
	v_cndmask_b32_e64 v52, 0, v53, s5                          // 000000002170: d5010034 00166a80
	v_cndmask_b32_e64 v51, 0, v54, s5                          // 000000002178: d5010033 00166c80
	v_cndmask_b32_e64 v54, 0, v49, s6                          // 000000002180: d5010036 001a6280
	v_cndmask_b32_e64 v53, 0, v50, s6                          // 000000002188: d5010035 001a6480
	s_delay_alu instid0(valu_dep_4)                            // 000000002190: bf870004
	v_add_co_u32 v49, s7, s48, v52                             // 000000002194: d7000731 02026830
	s_wait_alu depctr_va_sdst(0)                               // 00000000219c: bf88f19f
	v_add_co_ci_u32_e64 v50, null, s49, v51, s7                // 0000000021a0: d5207c32 001e6631
	v_add_co_u32 v51, s7, s48, v54                             // 0000000021a8: d7000733 02026c30
	s_wait_alu depctr_va_sdst(0)                               // 0000000021b0: bf88f19f
	v_add_co_ci_u32_e64 v52, null, s49, v53, s7                // 0000000021b4: d5207c34 001e6a31
	v_add_co_u32 v53, s7, v13, 6                               // 0000000021bc: d7000735 02010d0d
	s_wait_alu depctr_va_sdst(0)                               // 0000000021c4: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v14, s7                  // 0000000021c8: d5207c36 001e1c80
	v_add_co_u32 v55, s7, v13, 7                               // 0000000021d0: d7000737 02010f0d
	s_wait_alu depctr_va_sdst(0)                               // 0000000021d8: bf88f19f
	v_add_co_ci_u32_e64 v56, null, 0, v14, s7                  // 0000000021dc: d5207c38 001e1c80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 0000000021e4: bf8701a3
	v_cmp_gt_i64_e64 s16, s[46:47], v[53:54]                   // 0000000021e8: d4540010 02026a2e
	v_add_co_u32 v57, s7, v39, 6                               // 0000000021f0: d7000739 02010d27
	v_cmp_gt_i64_e64 s17, s[46:47], v[55:56]                   // 0000000021f8: d4540011 02026e2e
	s_wait_alu depctr_va_sdst(0)                               // 000000002200: bf88f19f
	v_add_co_ci_u32_e64 v58, null, 0, v40, s7                  // 000000002204: d5207c3a 001e5080
	v_add_co_u32 v53, s7, v39, 7                               // 00000000220c: d7000735 02010f27
	s_wait_alu depctr_va_sdst(0)                               // 000000002214: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v40, s7                  // 000000002218: d5207c36 001e5080
	s_and_b32 s7, s0, s16                                      // 000000002220: 8b071000
	s_and_b32 s8, s0, s17                                      // 000000002224: 8b081100
	s_wait_alu depctr_sa_sdst(0)                               // 000000002228: bf88ff9e
	v_cndmask_b32_e64 v56, 0, v57, s7                          // 00000000222c: d5010038 001e7280
	v_cndmask_b32_e64 v55, 0, v58, s7                          // 000000002234: d5010037 001e7480
	v_cndmask_b32_e64 v58, 0, v53, s8                          // 00000000223c: d501003a 00226a80
	v_cndmask_b32_e64 v57, 0, v54, s8                          // 000000002244: d5010039 00226c80
	s_delay_alu instid0(valu_dep_4)                            // 00000000224c: bf870004
	v_add_co_u32 v53, s12, s48, v56                            // 000000002250: d7000c35 02027030
	s_wait_alu depctr_va_sdst(0)                               // 000000002258: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s49, v55, s12               // 00000000225c: d5207c36 00326e31
	v_add_co_u32 v55, s12, s48, v58                            // 000000002264: d7000c37 02027430
	s_wait_alu depctr_va_sdst(0)                               // 00000000226c: bf88f19f
	v_add_co_ci_u32_e64 v56, null, s49, v57, s12               // 000000002270: d5207c38 00327231
	v_add_co_u32 v75, s12, v9, s66                             // 000000002278: d7000c4b 02008509
	s_wait_alu depctr_va_sdst(0)                               // 000000002280: bf88f19f
	v_add_co_ci_u32_e64 v76, null, s67, v10, s12               // 000000002284: d5207c4c 00321443
	s_clause 0x7                                               // 00000000228c: bf850007
	global_load_d16_u8 v41, v[41:42], off                      // 000000002290: ee07807c 00000029 00000029
	global_load_d16_hi_u8 v41, v[43:44], off                   // 00000000229c: ee08407c 00000029 0000002b
	global_load_d16_u8 v42, v[45:46], off                      // 0000000022a8: ee07807c 0000002a 0000002d
	global_load_d16_hi_u8 v42, v[47:48], off                   // 0000000022b4: ee08407c 0000002a 0000002f
	global_load_d16_u8 v43, v[49:50], off                      // 0000000022c0: ee07807c 0000002b 00000031
	global_load_d16_hi_u8 v43, v[51:52], off                   // 0000000022cc: ee08407c 0000002b 00000033
	global_load_d16_u8 v44, v[53:54], off                      // 0000000022d8: ee07807c 0000002c 00000035
	global_load_d16_hi_u8 v44, v[55:56], off                   // 0000000022e4: ee08407c 0000002c 00000037
	v_add_co_u32 v45, s12, v75, 1                              // 0000000022f0: d7000c2d 0201034b
	s_wait_alu depctr_va_sdst(0)                               // 0000000022f8: bf88f19f
	v_add_co_ci_u32_e64 v46, null, 0, v76, s12                 // 0000000022fc: d5207c2e 00329880
	v_cndmask_b32_e64 v48, 0, v75, s9                          // 000000002304: d5010030 00269680
	v_cndmask_b32_e64 v47, 0, v76, s9                          // 00000000230c: d501002f 00269880
	v_cndmask_b32_e64 v50, 0, v45, s10                         // 000000002314: d5010032 002a5a80
	s_delay_alu instid0(valu_dep_4)                            // 00000000231c: bf870004
	v_cndmask_b32_e64 v49, 0, v46, s10                         // 000000002320: d5010031 002a5c80
	s_add_nc_u64 s[66:67], s[66:67], 32                        // 000000002328: a9c2a042
	v_add_co_u32 v45, s12, s50, v48                            // 00000000232c: d7000c2d 02026032
	s_wait_alu depctr_va_sdst(0)                               // 000000002334: bf88f19f
	v_add_co_ci_u32_e64 v46, null, s51, v47, s12               // 000000002338: d5207c2e 00325e33
	v_add_co_u32 v47, s12, s50, v50                            // 000000002340: d7000c2f 02026432
	s_wait_alu depctr_va_sdst(0)                               // 000000002348: bf88f19f
	v_add_co_ci_u32_e64 v48, null, s51, v49, s12               // 00000000234c: d5207c30 00326233
	v_add_co_u32 v49, s12, v75, 2                              // 000000002354: d7000c31 0201054b
	s_wait_alu depctr_va_sdst(0)                               // 00000000235c: bf88f19f
	v_add_co_ci_u32_e64 v50, null, 0, v76, s12                 // 000000002360: d5207c32 00329880
	v_add_co_u32 v51, s12, v75, 3                              // 000000002368: d7000c33 0201074b
	s_wait_alu depctr_va_sdst(0)                               // 000000002370: bf88f19f
	v_add_co_ci_u32_e64 v52, null, 0, v76, s12                 // 000000002374: d5207c34 00329880
	s_and_b32 s12, s1, s11                                     // 00000000237c: 8b0c0b01
	s_and_b32 s11, s1, s13                                     // 000000002380: 8b0b0d01
	s_wait_alu depctr_sa_sdst(0)                               // 000000002384: bf88ff9e
	v_cndmask_b32_e64 v49, 0, v49, s12                         // 000000002388: d5010031 00326280
	v_cndmask_b32_e64 v50, 0, v50, s12                         // 000000002390: d5010032 00326480
	v_cndmask_b32_e64 v51, 0, v51, s11                         // 000000002398: d5010033 002e6680
	v_cndmask_b32_e64 v52, 0, v52, s11                         // 0000000023a0: d5010034 002e6880
	s_delay_alu instid0(valu_dep_4)                            // 0000000023a8: bf870004
	v_add_co_u32 v49, s13, s50, v49                            // 0000000023ac: d7000d31 02026232
	s_wait_alu depctr_va_sdst(0)                               // 0000000023b4: bf88f19f
	v_add_co_ci_u32_e64 v50, null, s51, v50, s13               // 0000000023b8: d5207c32 00366433
	v_add_co_u32 v51, s13, s50, v51                            // 0000000023c0: d7000d33 02026632
	s_wait_alu depctr_va_sdst(0)                               // 0000000023c8: bf88f19f
	v_add_co_ci_u32_e64 v52, null, s51, v52, s13               // 0000000023cc: d5207c34 00366833
	v_add_co_u32 v53, s13, v75, 4                              // 0000000023d4: d7000d35 0201094b
	s_wait_alu depctr_va_sdst(0)                               // 0000000023dc: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v76, s13                 // 0000000023e0: d5207c36 00369880
	v_add_co_u32 v55, s13, v75, 5                              // 0000000023e8: d7000d37 02010b4b
	s_wait_alu depctr_va_sdst(0)                               // 0000000023f0: bf88f19f
	v_add_co_ci_u32_e64 v56, null, 0, v76, s13                 // 0000000023f4: d5207c38 00369880
	s_and_b32 s13, s1, s14                                     // 0000000023fc: 8b0d0e01
	s_and_b32 s14, s1, s15                                     // 000000002400: 8b0e0f01
	s_wait_alu depctr_sa_sdst(0)                               // 000000002404: bf88ff9e
	v_cndmask_b32_e64 v53, 0, v53, s13                         // 000000002408: d5010035 00366a80
	v_cndmask_b32_e64 v54, 0, v54, s13                         // 000000002410: d5010036 00366c80
	v_cndmask_b32_e64 v55, 0, v55, s14                         // 000000002418: d5010037 003a6e80
	v_cndmask_b32_e64 v56, 0, v56, s14                         // 000000002420: d5010038 003a7080
	s_delay_alu instid0(valu_dep_4)                            // 000000002428: bf870004
	v_add_co_u32 v53, s15, s50, v53                            // 00000000242c: d7000f35 02026a32
	s_wait_alu depctr_va_sdst(0)                               // 000000002434: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s51, v54, s15               // 000000002438: d5207c36 003e6c33
	v_add_co_u32 v55, s15, s50, v55                            // 000000002440: d7000f37 02026e32
	s_wait_alu depctr_va_sdst(0)                               // 000000002448: bf88f19f
	v_add_co_ci_u32_e64 v56, null, s51, v56, s15               // 00000000244c: d5207c38 003e7033
	v_add_co_u32 v57, s15, v75, 6                              // 000000002454: d7000f39 02010d4b
	s_wait_alu depctr_va_sdst(0)                               // 00000000245c: bf88f19f
	v_add_co_ci_u32_e64 v58, null, 0, v76, s15                 // 000000002460: d5207c3a 003e9880
	v_add_co_u32 v59, s15, v75, 7                              // 000000002468: d7000f3b 02010f4b
	s_wait_alu depctr_va_sdst(0)                               // 000000002470: bf88f19f
	v_add_co_ci_u32_e64 v60, null, 0, v76, s15                 // 000000002474: d5207c3c 003e9880
	s_and_b32 s15, s1, s16                                     // 00000000247c: 8b0f1001
	s_and_b32 s16, s1, s17                                     // 000000002480: 8b101101
	s_wait_alu depctr_sa_sdst(0)                               // 000000002484: bf88ff9e
	v_cndmask_b32_e64 v57, 0, v57, s15                         // 000000002488: d5010039 003e7280
	v_cndmask_b32_e64 v58, 0, v58, s15                         // 000000002490: d501003a 003e7480
	v_cndmask_b32_e64 v59, 0, v59, s16                         // 000000002498: d501003b 00427680
	v_cndmask_b32_e64 v60, 0, v60, s16                         // 0000000024a0: d501003c 00427880
	s_delay_alu instid0(valu_dep_4)                            // 0000000024a8: bf870004
	v_add_co_u32 v57, s17, s50, v57                            // 0000000024ac: d7001139 02027232
	s_wait_alu depctr_va_sdst(0)                               // 0000000024b4: bf88f19f
	v_add_co_ci_u32_e64 v58, null, s51, v58, s17               // 0000000024b8: d5207c3a 00467433
	v_add_co_u32 v59, s17, s50, v59                            // 0000000024c0: d700113b 02027632
	s_wait_alu depctr_va_sdst(0)                               // 0000000024c8: bf88f19f
	v_add_co_ci_u32_e64 v60, null, s51, v60, s17               // 0000000024cc: d5207c3c 00467833
	s_clause 0x7                                               // 0000000024d4: bf850007
	global_load_d16_u8 v45, v[45:46], off                      // 0000000024d8: ee07807c 0000002d 0000002d
	global_load_d16_hi_u8 v45, v[47:48], off                   // 0000000024e4: ee08407c 0000002d 0000002f
	global_load_d16_u8 v46, v[49:50], off                      // 0000000024f0: ee07807c 0000002e 00000031
	global_load_d16_hi_u8 v46, v[51:52], off                   // 0000000024fc: ee08407c 0000002e 00000033
	global_load_d16_u8 v47, v[53:54], off                      // 000000002508: ee07807c 0000002f 00000035
	global_load_d16_hi_u8 v47, v[55:56], off                   // 000000002514: ee08407c 0000002f 00000037
	global_load_d16_u8 v48, v[57:58], off                      // 000000002520: ee07807c 00000030 00000039
	global_load_d16_hi_u8 v48, v[59:60], off                   // 00000000252c: ee08407c 00000030 0000003b
	v_add_co_u32 v49, s17, s68, v21                            // 000000002538: d7001131 02022a44
	s_wait_alu depctr_va_sdst(0)                               // 000000002540: bf88f19f
	v_add_co_ci_u32_e64 v50, null, s69, v22, s17               // 000000002544: d5207c32 00462c45
	v_add_co_u32 v51, s17, s68, v25                            // 00000000254c: d7001133 02023244
	s_wait_alu depctr_va_sdst(0)                               // 000000002554: bf88f19f
	v_add_co_ci_u32_e64 v52, null, s69, v26, s17               // 000000002558: d5207c34 00463445
	v_add_co_u32 v53, s17, s68, v27                            // 000000002560: d7001135 02023644
	s_wait_alu depctr_va_sdst(0)                               // 000000002568: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s69, v28, s17               // 00000000256c: d5207c36 00463845
	v_add_co_u32 v55, s17, s68, v29                            // 000000002574: d7001137 02023a44
	s_wait_alu depctr_va_sdst(0)                               // 00000000257c: bf88f19f
	v_add_co_ci_u32_e64 v56, null, s69, v30, s17               // 000000002580: d5207c38 00463c45
	v_add_co_u32 v57, s17, s68, v31                            // 000000002588: d7001139 02023e44
	s_wait_alu depctr_va_sdst(0)                               // 000000002590: bf88f19f
	v_add_co_ci_u32_e64 v58, null, s69, v32, s17               // 000000002594: d5207c3a 00464045
	v_add_co_u32 v59, s17, s68, v33                            // 00000000259c: d700113b 02024244
	s_wait_alu depctr_va_sdst(0)                               // 0000000025a4: bf88f19f
	v_add_co_ci_u32_e64 v60, null, s69, v34, s17               // 0000000025a8: d5207c3c 00464445
	s_clause 0x5                                               // 0000000025b0: bf850005
	global_load_b64 v[61:62], v[49:50], off offset:-4          // 0000000025b4: ee05407c 0000003d fffffc31
	global_load_b64 v[63:64], v[51:52], off offset:-4          // 0000000025c0: ee05407c 0000003f fffffc33
	global_load_b64 v[65:66], v[53:54], off offset:-4          // 0000000025cc: ee05407c 00000041 fffffc35
	global_load_b64 v[55:56], v[55:56], off offset:-4          // 0000000025d8: ee05407c 00000037 fffffc37
	global_load_b64 v[57:58], v[57:58], off offset:-4          // 0000000025e4: ee05407c 00000039 fffffc39
	global_load_b64 v[59:60], v[59:60], off offset:-4          // 0000000025f0: ee05407c 0000003b fffffc3b
	v_add_co_u32 v49, s17, v13, 16                             // 0000000025fc: d7001131 0201210d
	s_wait_alu depctr_va_sdst(0)                               // 000000002604: bf88f19f
	v_add_co_ci_u32_e64 v50, null, 0, v14, s17                 // 000000002608: d5207c32 00461c80
	v_add_co_u32 v51, s17, v13, 17                             // 000000002610: d7001133 0201230d
	s_wait_alu depctr_va_sdst(0)                               // 000000002618: bf88f19f
	v_add_co_ci_u32_e64 v52, null, 0, v14, s17                 // 00000000261c: d5207c34 00461c80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002624: bf8701a3
	v_cmp_gt_i64_e64 s25, s[46:47], v[49:50]                   // 000000002628: d4540019 0202622e
	v_add_co_u32 v53, s17, v39, 16                             // 000000002630: d7001135 02012127
	v_cmp_gt_i64_e64 s26, s[46:47], v[51:52]                   // 000000002638: d454001a 0202662e
	s_wait_alu depctr_va_sdst(0)                               // 000000002640: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v40, s17                 // 000000002644: d5207c36 00465080
	v_add_co_u32 v49, s17, v39, 17                             // 00000000264c: d7001131 02012327
	s_wait_alu depctr_va_sdst(0)                               // 000000002654: bf88f19f
	v_add_co_ci_u32_e64 v50, null, 0, v40, s17                 // 000000002658: d5207c32 00465080
	s_and_b32 s17, s0, s25                                     // 000000002660: 8b111900
	s_and_b32 s18, s0, s26                                     // 000000002664: 8b121a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002668: bf88ff9e
	v_cndmask_b32_e64 v52, 0, v53, s17                         // 00000000266c: d5010034 00466a80
	v_cndmask_b32_e64 v51, 0, v54, s17                         // 000000002674: d5010033 00466c80
	v_cndmask_b32_e64 v54, 0, v49, s18                         // 00000000267c: d5010036 004a6280
	v_cndmask_b32_e64 v53, 0, v50, s18                         // 000000002684: d5010035 004a6480
	s_and_b32 s25, s1, s25                                     // 00000000268c: 8b191901
	v_add_co_u32 v49, s19, s48, v52                            // 000000002690: d7001331 02026830
	s_wait_alu depctr_va_sdst(0)                               // 000000002698: bf88f19f
	v_add_co_ci_u32_e64 v50, null, s49, v51, s19               // 00000000269c: d5207c32 004e6631
	v_add_co_u32 v51, s19, s48, v54                            // 0000000026a4: d7001333 02026c30
	s_wait_alu depctr_va_sdst(0)                               // 0000000026ac: bf88f19f
	v_add_co_ci_u32_e64 v52, null, s49, v53, s19               // 0000000026b0: d5207c34 004e6a31
	v_add_co_u32 v53, s19, v13, 18                             // 0000000026b8: d7001335 0201250d
	s_wait_alu depctr_va_sdst(0)                               // 0000000026c0: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v14, s19                 // 0000000026c4: d5207c36 004e1c80
	v_add_co_u32 v67, s19, v13, 19                             // 0000000026cc: d7001343 0201270d
	s_wait_alu depctr_va_sdst(0)                               // 0000000026d4: bf88f19f
	v_add_co_ci_u32_e64 v68, null, 0, v14, s19                 // 0000000026d8: d5207c44 004e1c80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 0000000026e0: bf8701a3
	v_cmp_gt_i64_e64 s27, s[46:47], v[53:54]                   // 0000000026e4: d454001b 02026a2e
	v_add_co_u32 v69, s19, v39, 18                             // 0000000026ec: d7001345 02012527
	v_cmp_gt_i64_e64 s28, s[46:47], v[67:68]                   // 0000000026f4: d454001c 0202862e
	s_wait_alu depctr_va_sdst(0)                               // 0000000026fc: bf88f19f
	v_add_co_ci_u32_e64 v70, null, 0, v40, s19                 // 000000002700: d5207c46 004e5080
	v_add_co_u32 v53, s19, v39, 19                             // 000000002708: d7001335 02012727
	s_and_b32 s20, s0, s27                                     // 000000002710: 8b141b00
	v_add_co_ci_u32_e64 v54, null, 0, v40, s19                 // 000000002714: d5207c36 004e5080
	s_wait_alu depctr_sa_sdst(0)                               // 00000000271c: bf88ff9e
	v_cndmask_b32_e64 v68, 0, v69, s20                         // 000000002720: d5010044 00528a80
	s_and_b32 s19, s0, s28                                     // 000000002728: 8b131c00
	v_cndmask_b32_e64 v67, 0, v70, s20                         // 00000000272c: d5010043 00528c80
	s_wait_alu depctr_sa_sdst(0)                               // 000000002734: bf88ff9e
	v_cndmask_b32_e64 v70, 0, v53, s19                         // 000000002738: d5010046 004e6a80
	v_cndmask_b32_e64 v69, 0, v54, s19                         // 000000002740: d5010045 004e6c80
	v_add_co_u32 v53, s21, s48, v68                            // 000000002748: d7001535 02028830
	s_wait_alu depctr_va_sdst(0)                               // 000000002750: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s49, v67, s21               // 000000002754: d5207c36 00568631
	v_add_co_u32 v67, s21, s48, v70                            // 00000000275c: d7001543 02028c30
	s_wait_alu depctr_va_sdst(0)                               // 000000002764: bf88f19f
	v_add_co_ci_u32_e64 v68, null, s49, v69, s21               // 000000002768: d5207c44 00568a31
	v_add_co_u32 v69, s21, v13, 20                             // 000000002770: d7001545 0201290d
	s_wait_alu depctr_va_sdst(0)                               // 000000002778: bf88f19f
	v_add_co_ci_u32_e64 v70, null, 0, v14, s21                 // 00000000277c: d5207c46 00561c80
	v_add_co_u32 v71, s21, v13, 21                             // 000000002784: d7001547 02012b0d
	s_wait_alu depctr_va_sdst(0)                               // 00000000278c: bf88f19f
	v_add_co_ci_u32_e64 v72, null, 0, v14, s21                 // 000000002790: d5207c48 00561c80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002798: bf8701a3
	v_cmp_gt_i64_e64 s29, s[46:47], v[69:70]                   // 00000000279c: d454001d 02028a2e
	v_add_co_u32 v73, s21, v39, 20                             // 0000000027a4: d7001549 02012927
	v_cmp_gt_i64_e64 s30, s[46:47], v[71:72]                   // 0000000027ac: d454001e 02028e2e
	s_wait_alu depctr_va_sdst(0)                               // 0000000027b4: bf88f19f
	v_add_co_ci_u32_e64 v74, null, 0, v40, s21                 // 0000000027b8: d5207c4a 00565080
	v_add_co_u32 v69, s21, v39, 21                             // 0000000027c0: d7001545 02012b27
	s_wait_alu depctr_va_sdst(0)                               // 0000000027c8: bf88f19f
	v_add_co_ci_u32_e64 v70, null, 0, v40, s21                 // 0000000027cc: d5207c46 00565080
	s_and_b32 s21, s0, s29                                     // 0000000027d4: 8b151d00
	s_and_b32 s22, s0, s30                                     // 0000000027d8: 8b161e00
	s_wait_alu depctr_sa_sdst(0)                               // 0000000027dc: bf88ff9e
	v_cndmask_b32_e64 v72, 0, v73, s21                         // 0000000027e0: d5010048 00569280
	v_cndmask_b32_e64 v71, 0, v74, s21                         // 0000000027e8: d5010047 00569480
	v_cndmask_b32_e64 v74, 0, v69, s22                         // 0000000027f0: d501004a 005a8a80
	v_cndmask_b32_e64 v73, 0, v70, s22                         // 0000000027f8: d5010049 005a8c80
	s_and_b32 s26, s1, s26                                     // 000000002800: 8b1a1a01
	v_add_co_u32 v69, s23, s48, v72                            // 000000002804: d7001745 02029030
	s_wait_alu depctr_va_sdst(0)                               // 00000000280c: bf88f19f
	v_add_co_ci_u32_e64 v70, null, s49, v71, s23               // 000000002810: d5207c46 005e8e31
	v_add_co_u32 v71, s23, s48, v74                            // 000000002818: d7001747 02029430
	s_wait_alu depctr_va_sdst(0)                               // 000000002820: bf88f19f
	v_add_co_ci_u32_e64 v72, null, s49, v73, s23               // 000000002824: d5207c48 005e9231
	v_add_co_u32 v73, s23, v13, 22                             // 00000000282c: d7001749 02012d0d
	s_wait_alu depctr_va_sdst(0)                               // 000000002834: bf88f19f
	v_add_co_ci_u32_e64 v74, null, 0, v14, s23                 // 000000002838: d5207c4a 005e1c80
	v_add_co_u32 v13, s23, v13, 23                             // 000000002840: d700170d 02012f0d
	s_wait_alu depctr_va_sdst(0)                               // 000000002848: bf88f19f
	v_add_co_ci_u32_e64 v14, null, 0, v14, s23                 // 00000000284c: d5207c0e 005e1c80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002854: bf8701a3
	v_cmp_gt_i64_e64 s31, s[46:47], v[73:74]                   // 000000002858: d454001f 0202922e
	v_add_co_u32 v77, s23, v39, 22                             // 000000002860: d700174d 02012d27
	v_cmp_gt_i64_e64 s33, s[46:47], v[13:14]                   // 000000002868: d4540021 02021a2e
	s_wait_alu depctr_va_sdst(0)                               // 000000002870: bf88f19f
	v_add_co_ci_u32_e64 v78, null, 0, v40, s23                 // 000000002874: d5207c4e 005e5080
	v_add_co_u32 v13, s23, v39, 23                             // 00000000287c: d700170d 02012f27
	s_wait_alu depctr_va_sdst(0)                               // 000000002884: bf88f19f
	v_add_co_ci_u32_e64 v14, null, 0, v40, s23                 // 000000002888: d5207c0e 005e5080
	s_and_b32 s23, s0, s31                                     // 000000002890: 8b171f00
	s_and_b32 s24, s0, s33                                     // 000000002894: 8b182100
	s_wait_alu depctr_sa_sdst(0)                               // 000000002898: bf88ff9e
	v_cndmask_b32_e64 v39, 0, v77, s23                         // 00000000289c: d5010027 005e9a80
	v_cndmask_b32_e64 v40, 0, v78, s23                         // 0000000028a4: d5010028 005e9c80
	v_cndmask_b32_e64 v13, 0, v13, s24                         // 0000000028ac: d501000d 00621a80
	v_cndmask_b32_e64 v14, 0, v14, s24                         // 0000000028b4: d501000e 00621c80
	s_and_b32 s27, s1, s27                                     // 0000000028bc: 8b1b1b01
	v_add_co_u32 v39, s34, s48, v39                            // 0000000028c0: d7002227 02024e30
	s_wait_alu depctr_va_sdst(0)                               // 0000000028c8: bf88f19f
	v_add_co_ci_u32_e64 v40, null, s49, v40, s34               // 0000000028cc: d5207c28 008a5031
	v_add_co_u32 v73, s34, s48, v13                            // 0000000028d4: d7002249 02021a30
	s_wait_alu depctr_va_sdst(0)                               // 0000000028dc: bf88f19f
	v_add_co_ci_u32_e64 v74, null, s49, v14, s34               // 0000000028e0: d5207c4a 008a1c31
	s_clause 0x7                                               // 0000000028e8: bf850007
	global_load_d16_u8 v13, v[49:50], off                      // 0000000028ec: ee07807c 0000000d 00000031
	global_load_d16_hi_u8 v13, v[51:52], off                   // 0000000028f8: ee08407c 0000000d 00000033
	global_load_d16_u8 v14, v[53:54], off                      // 000000002904: ee07807c 0000000e 00000035
	global_load_d16_hi_u8 v14, v[67:68], off                   // 000000002910: ee08407c 0000000e 00000043
	global_load_d16_u8 v49, v[69:70], off                      // 00000000291c: ee07807c 00000031 00000045
	global_load_d16_hi_u8 v49, v[71:72], off                   // 000000002928: ee08407c 00000031 00000047
	global_load_d16_u8 v50, v[39:40], off                      // 000000002934: ee07807c 00000032 00000027
	global_load_d16_hi_u8 v50, v[73:74], off                   // 000000002940: ee08407c 00000032 00000049
	v_add_co_u32 v39, s34, v75, 16                             // 00000000294c: d7002227 0201214b
	s_wait_alu depctr_va_sdst(0)                               // 000000002954: bf88f19f
	v_add_co_ci_u32_e64 v40, null, 0, v76, s34                 // 000000002958: d5207c28 008a9880
	v_add_co_u32 v51, s34, v75, 17                             // 000000002960: d7002233 0201234b
	s_wait_alu depctr_va_sdst(0)                               // 000000002968: bf88f19f
	v_add_co_ci_u32_e64 v52, null, 0, v76, s34                 // 00000000296c: d5207c34 008a9880
	v_cndmask_b32_e64 v39, 0, v39, s25                         // 000000002974: d5010027 00664e80
	v_cndmask_b32_e64 v40, 0, v40, s25                         // 00000000297c: d5010028 00665080
	v_cndmask_b32_e64 v51, 0, v51, s26                         // 000000002984: d5010033 006a6680
	s_delay_alu instid0(valu_dep_4)                            // 00000000298c: bf870004
	v_cndmask_b32_e64 v53, 0, v52, s26                         // 000000002990: d5010035 006a6880
	s_and_b32 s28, s1, s28                                     // 000000002998: 8b1c1c01
	v_add_co_u32 v39, s34, s50, v39                            // 00000000299c: d7002227 02024e32
	s_wait_alu depctr_va_sdst(0)                               // 0000000029a4: bf88f19f
	v_add_co_ci_u32_e64 v40, null, s51, v40, s34               // 0000000029a8: d5207c28 008a5033
	v_add_co_u32 v52, s34, s50, v51                            // 0000000029b0: d7002234 02026632
	s_wait_alu depctr_va_sdst(0)                               // 0000000029b8: bf88f19f
	v_add_co_ci_u32_e64 v53, null, s51, v53, s34               // 0000000029bc: d5207c35 008a6a33
	v_add_co_u32 v51, s34, v75, 18                             // 0000000029c4: d7002233 0201254b
	s_wait_alu depctr_va_sdst(0)                               // 0000000029cc: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v76, s34                 // 0000000029d0: d5207c36 008a9880
	v_add_co_u32 v67, s34, v75, 19                             // 0000000029d8: d7002243 0201274b
	s_wait_alu depctr_va_sdst(0)                               // 0000000029e0: bf88f19f
	v_add_co_ci_u32_e64 v68, null, 0, v76, s34                 // 0000000029e4: d5207c44 008a9880
	s_wait_alu depctr_sa_sdst(0)                               // 0000000029ec: bf88ff9e
	v_cndmask_b32_e64 v51, 0, v51, s27                         // 0000000029f0: d5010033 006e6680
	v_cndmask_b32_e64 v54, 0, v54, s27                         // 0000000029f8: d5010036 006e6c80
	v_cndmask_b32_e64 v69, 0, v67, s28                         // 000000002a00: d5010045 00728680
	v_cndmask_b32_e64 v70, 0, v68, s28                         // 000000002a08: d5010046 00728880
	s_and_b32 s29, s1, s29                                     // 000000002a10: 8b1d1d01
	v_add_co_u32 v67, s34, s50, v51                            // 000000002a14: d7002243 02026632
	s_wait_alu depctr_va_sdst(0)                               // 000000002a1c: bf88f19f
	v_add_co_ci_u32_e64 v68, null, s51, v54, s34               // 000000002a20: d5207c44 008a6c33
	v_add_co_u32 v69, s34, s50, v69                            // 000000002a28: d7002245 02028a32
	s_wait_alu depctr_va_sdst(0)                               // 000000002a30: bf88f19f
	v_add_co_ci_u32_e64 v70, null, s51, v70, s34               // 000000002a34: d5207c46 008a8c33
	v_add_co_u32 v51, s34, v75, 20                             // 000000002a3c: d7002233 0201294b
	s_wait_alu depctr_va_sdst(0)                               // 000000002a44: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v76, s34                 // 000000002a48: d5207c36 008a9880
	v_add_co_u32 v71, s34, v75, 21                             // 000000002a50: d7002247 02012b4b
	s_wait_alu depctr_va_sdst(0)                               // 000000002a58: bf88f19f
	v_add_co_ci_u32_e64 v72, null, 0, v76, s34                 // 000000002a5c: d5207c48 008a9880
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a64: bf88ff9e
	v_cndmask_b32_e64 v51, 0, v51, s29                         // 000000002a68: d5010033 00766680
	s_and_b32 s30, s1, s30                                     // 000000002a70: 8b1e1e01
	v_cndmask_b32_e64 v54, 0, v54, s29                         // 000000002a74: d5010036 00766c80
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a7c: bf88ff9e
	v_cndmask_b32_e64 v73, 0, v71, s30                         // 000000002a80: d5010049 007a8e80
	v_cndmask_b32_e64 v74, 0, v72, s30                         // 000000002a88: d501004a 007a9080
	v_add_co_u32 v71, s34, s50, v51                            // 000000002a90: d7002247 02026632
	s_wait_alu depctr_va_sdst(0)                               // 000000002a98: bf88f19f
	v_add_co_ci_u32_e64 v72, null, s51, v54, s34               // 000000002a9c: d5207c48 008a6c33
	v_add_co_u32 v73, s34, s50, v73                            // 000000002aa4: d7002249 02029232
	s_wait_alu depctr_va_sdst(0)                               // 000000002aac: bf88f19f
	v_add_co_ci_u32_e64 v74, null, s51, v74, s34               // 000000002ab0: d5207c4a 008a9433
	v_add_co_u32 v51, s34, v75, 23                             // 000000002ab8: d7002233 02012f4b
	s_wait_alu depctr_va_sdst(0)                               // 000000002ac0: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v76, s34                 // 000000002ac4: d5207c36 008a9880
	v_add_co_u32 v75, s34, v75, 22                             // 000000002acc: d700224b 02012d4b
	s_and_b32 s33, s1, s33                                     // 000000002ad4: 8b212101
	v_add_co_ci_u32_e64 v76, null, 0, v76, s34                 // 000000002ad8: d5207c4c 008a9880
	s_wait_alu depctr_sa_sdst(0)                               // 000000002ae0: bf88ff9e
	v_cndmask_b32_e64 v51, 0, v51, s33                         // 000000002ae4: d5010033 00866680
	s_and_b32 s31, s1, s31                                     // 000000002aec: 8b1f1f01
	v_cndmask_b32_e64 v54, 0, v54, s33                         // 000000002af0: d5010036 00866c80
	s_wait_alu depctr_sa_sdst(0)                               // 000000002af8: bf88ff9e
	v_cndmask_b32_e64 v77, 0, v75, s31                         // 000000002afc: d501004d 007e9680
	v_cndmask_b32_e64 v78, 0, v76, s31                         // 000000002b04: d501004e 007e9880
	v_add_co_u32 v75, s34, s50, v51                            // 000000002b0c: d700224b 02026632
	s_wait_alu depctr_va_sdst(0)                               // 000000002b14: bf88f19f
	v_add_co_ci_u32_e64 v76, null, s51, v54, s34               // 000000002b18: d5207c4c 008a6c33
	v_add_co_u32 v77, s34, s50, v77                            // 000000002b20: d700224d 02029a32
	s_wait_alu depctr_va_sdst(0)                               // 000000002b28: bf88f19f
	v_add_co_ci_u32_e64 v78, null, s51, v78, s34               // 000000002b2c: d5207c4e 008a9c33
	s_clause 0x7                                               // 000000002b34: bf850007
	global_load_d16_u8 v51, v[39:40], off                      // 000000002b38: ee07807c 00000033 00000027
	global_load_d16_hi_u8 v51, v[52:53], off                   // 000000002b44: ee08407c 00000033 00000034
	global_load_d16_u8 v52, v[67:68], off                      // 000000002b50: ee07807c 00000034 00000043
	global_load_d16_hi_u8 v52, v[75:76], off                   // 000000002b5c: ee08407c 00000034 0000004b
	global_load_d16_u8 v53, v[77:78], off                      // 000000002b68: ee07807c 00000035 0000004d
	global_load_d16_hi_u8 v53, v[73:74], off                   // 000000002b74: ee08407c 00000035 00000049
	global_load_d16_u8 v54, v[71:72], off                      // 000000002b80: ee07807c 00000036 00000047
	global_load_d16_hi_u8 v54, v[69:70], off                   // 000000002b8c: ee08407c 00000036 00000045
	v_add_co_u32 v39, s34, s68, v35                            // 000000002b98: d7002227 02024644
	s_wait_alu depctr_va_sdst(0)                               // 000000002ba0: bf88f19f
	v_add_co_ci_u32_e64 v40, null, s69, v36, s34               // 000000002ba4: d5207c28 008a4845
	v_add_co_u32 v67, s34, s68, v37                            // 000000002bac: d7002243 02024a44
	s_wait_alu depctr_va_sdst(0)                               // 000000002bb4: bf88f19f
	v_add_co_ci_u32_e64 v68, null, s69, v38, s34               // 000000002bb8: d5207c44 008a4c45
	v_add_co_u32 v69, s34, v7, s62                             // 000000002bc0: d7002245 02007d07
	s_wait_alu depctr_va_sdst(0)                               // 000000002bc8: bf88f19f
	v_add_co_ci_u32_e64 v70, null, s63, v8, s34                // 000000002bcc: d5207c46 008a103f
	s_clause 0x1                                               // 000000002bd4: bf850001
	global_load_b64 v[71:72], v[39:40], off offset:-4          // 000000002bd8: ee05407c 00000047 fffffc27
	global_load_b64 v[67:68], v[67:68], off offset:-4          // 000000002be4: ee05407c 00000043 fffffc43
	global_load_b32 v73, v[69:70], off                         // 000000002bf0: ee05007c 00000049 00000045
	s_wait_loadcnt 0x25                                        // 000000002bfc: bfc00025
	v_cndmask_b16 v39.l, 0, v42.l, s4                          // 000000002c00: d65d0027 00125480
	s_wait_loadcnt 0x21                                        // 000000002c08: bfc00021
	v_cndmask_b16 v39.h, 0, v44.h, s8                          // 000000002c0c: d65d5027 00225880
	v_cndmask_b16 v40.l, 0, v44.l, s7                          // 000000002c14: d65d0028 001e5880
	v_cndmask_b16 v40.h, 0, v43.h, s6                          // 000000002c1c: d65d5028 001a5680
	v_cndmask_b16 v42.l, 0, v43.l, s5                          // 000000002c24: d65d002a 00165680
	v_cndmask_b16 v42.h, 0, v42.h, s3                          // 000000002c2c: d65d502a 000e5480
	v_lshlrev_b16 v39.h, 8, v39.h op_sel:[0,1,1]               // 000000002c34: d7385027 02024e88
	v_and_b16 v40.l, 0xff, v40.l                               // 000000002c3c: d7620028 020250ff 000000ff
	v_lshlrev_b16 v40.h, 8, v40.h op_sel:[0,1,1]               // 000000002c48: d7385028 02025088
	v_and_b16 v42.l, 0xff, v42.l                               // 000000002c50: d762002a 020254ff 000000ff
	v_lshlrev_b16 v42.h, 8, v42.h op_sel:[0,1,1]               // 000000002c5c: d738502a 02025488
	v_and_b16 v39.l, 0xff, v39.l                               // 000000002c64: d7620027 02024eff 000000ff
	v_cndmask_b16 v41.l, 0, v41.l, vcc_lo                      // 000000002c70: d65d0029 01aa5280
	v_cndmask_b16 v41.h, 0, v41.h, s2                          // 000000002c78: d65d5029 000a5280
	v_or_b16 v70.h, v40.l, v39.h op_sel:[0,1,1]                // 000000002c80: d7635046 02024f28
	v_or_b16 v70.l, v42.l, v40.h op_sel:[0,1,0]                // 000000002c88: d7631046 0202512a
	v_or_b16 v69.h, v39.l, v42.h op_sel:[0,1,1]                // 000000002c90: d7635045 02025527
	v_and_b16 v39.l, 0xff, v41.l                               // 000000002c98: d7620027 020252ff 000000ff
	v_lshlrev_b16 v39.h, 8, v41.h op_sel:[0,1,1]               // 000000002ca4: d7385027 02025288
	v_cmp_ge_i64_e64 s2, s[66:67], s[44:45]                    // 000000002cac: d4560002 02005842
	v_add_co_u32 v7, vcc_lo, v7, s64                           // 000000002cb4: d7006a07 02008107
	s_wait_alu depctr_va_vcc(0)                                // 000000002cbc: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s65, v8, vcc_lo              // 000000002cc0: d5207c08 01aa1041
	v_or_b16 v69.l, v39.l, v39.h op_sel:[0,1,0]                // 000000002cc8: d7631045 02024f27
	s_delay_alu instid0(valu_dep_4)                            // 000000002cd0: bf870004
	s_and_b32 vcc_lo, exec_lo, s2                              // 000000002cd4: 8b6a027e
	s_add_nc_u64 s[68:69], s[68:69], 8                         // 000000002cd8: a9c48844
	s_wait_loadcnt 0x1f                                        // 000000002cdc: bfc0001f
	v_cndmask_b16 v40.l, 0, v45.l, s9                          // 000000002ce0: d65d0028 00265a80
	v_cndmask_b16 v40.h, 0, v45.h, s10                         // 000000002ce8: d65d5028 002a5a80
	s_wait_loadcnt 0x1d                                        // 000000002cf0: bfc0001d
	v_cndmask_b16 v41.l, 0, v46.l, s12                         // 000000002cf4: d65d0029 00325c80
	v_cndmask_b16 v43.h, 0, v46.h, s11                         // 000000002cfc: d65d502b 002e5c80
	s_wait_loadcnt 0x1b                                        // 000000002d04: bfc0001b
	v_cndmask_b16 v43.l, 0, v47.l, s13                         // 000000002d08: d65d002b 00365e80
	v_cndmask_b16 v42.h, 0, v47.h, s14                         // 000000002d10: d65d502a 003a5e80
	s_wait_loadcnt 0x19                                        // 000000002d18: bfc00019
	v_cndmask_b16 v42.l, 0, v48.l, s15                         // 000000002d1c: d65d002a 003e6080
	v_cndmask_b16 v41.h, 0, v48.h, s16                         // 000000002d24: d65d5029 00426080
	v_lshlrev_b16 v43.h, 8, v43.h op_sel:[0,1,1]               // 000000002d2c: d738502b 02025688
	v_and_b16 v43.l, 0xff, v43.l                               // 000000002d34: d762002b 020256ff 000000ff
	v_lshlrev_b16 v42.h, 8, v42.h op_sel:[0,1,1]               // 000000002d40: d738502a 02025488
	v_and_b16 v42.l, 0xff, v42.l                               // 000000002d48: d762002a 020254ff 000000ff
	v_lshlrev_b16 v41.h, 8, v41.h op_sel:[0,1,1]               // 000000002d54: d7385029 02025288
	v_and_b16 v41.l, 0xff, v41.l                               // 000000002d5c: d7620029 020252ff 000000ff
	v_and_b16 v40.l, 0xff, v40.l                               // 000000002d68: d7620028 020250ff 000000ff
	v_lshlrev_b16 v40.h, 8, v40.h op_sel:[0,1,1]               // 000000002d74: d7385028 02025088
	v_or_b16 v48.l, v43.l, v42.h op_sel:[0,1,0]                // 000000002d7c: d7631030 0202552b
	v_or_b16 v48.h, v42.l, v41.h op_sel:[0,1,1]                // 000000002d84: d7635030 0202532a
	v_or_b16 v47.h, v41.l, v43.h op_sel:[0,1,1]                // 000000002d8c: d763502f 02025729
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_1)// 000000002d94: bf870094
	v_or_b16 v47.l, v40.l, v40.h op_sel:[0,1,0]                // 000000002d98: d763102f 02025128
	v_wmma_f32_16x16x16_fp8_fp8 v[39:46], v[69:70], v[47:48], 0// 000000002da0: cc464027 1a025f45
	s_wait_loadcnt 0x16                                        // 000000002da8: bfc00016
	v_dual_mul_f32 v47, v61, v79 :: v_dual_mul_f32 v48, v79, v65// 000000002dac: c8c69f3d 2f30834f
	s_wait_loadcnt 0x15                                        // 000000002db4: bfc00015
	v_mul_f32_e32 v55, v79, v55                                // 000000002db8: 106e6f4f
	s_wait_loadcnt 0x14                                        // 000000002dbc: bfc00014
	v_mul_f32_e32 v57, v79, v57                                // 000000002dc0: 1072734f
	v_mul_f32_e32 v39, v39, v47                                // 000000002dc4: 104e5f27
	v_mul_f32_e32 v47, v79, v63                                // 000000002dc8: 105e7f4f
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000002dcc: bf870112
	v_add_f32_e32 v61, v1, v39                                 // 000000002dd0: 067a4f01
	v_mul_f32_e32 v1, v40, v47                                 // 000000002dd4: 10025f28
	v_dual_mul_f32 v39, v41, v48 :: v_dual_mul_f32 v40, v42, v55// 000000002dd8: c8c66129 27286f2a
	v_mul_f32_e32 v41, v43, v57                                // 000000002de0: 1052732b
	s_wait_loadcnt 0x13                                        // 000000002de4: bfc00013
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002de8: bf870193
	v_dual_mul_f32 v42, v79, v59 :: v_dual_add_f32 v43, v20, v1// 000000002dec: c8c8774f 2a2a0314
	v_add_f32_e32 v55, v19, v39                                // 000000002df4: 066e4f13
	v_add_f32_e32 v57, v18, v40                                // 000000002df8: 06725112
	s_delay_alu instid0(valu_dep_3)                            // 000000002dfc: bf870003
	v_dual_add_f32 v41, v17, v41 :: v_dual_mul_f32 v42, v44, v42// 000000002e00: c9065311 292a552c
	s_wait_loadcnt 0x11                                        // 000000002e08: bfc00011
	v_cndmask_b16 v13.l, 0, v13.l, s17                         // 000000002e0c: d65d000d 00461a80
	v_cndmask_b16 v13.h, 0, v13.h, s18                         // 000000002e14: d65d500d 004a1a80
	s_wait_loadcnt 0xf                                         // 000000002e1c: bfc0000f
	v_cndmask_b16 v1.l, 0, v14.l, s20                          // 000000002e20: d65d0001 00521c80
	v_cndmask_b16 v14.h, 0, v14.h, s19                         // 000000002e28: d65d500e 004e1c80
	s_wait_loadcnt 0xd                                         // 000000002e30: bfc0000d
	v_cndmask_b16 v17.h, 0, v49.l, s21                         // 000000002e34: d65d4011 00566280
	v_cndmask_b16 v17.l, 0, v49.h, s22                         // 000000002e3c: d65d1011 005a6280
	s_wait_loadcnt 0xb                                         // 000000002e44: bfc0000b
	v_cndmask_b16 v14.l, 0, v50.l, s23                         // 000000002e48: d65d000e 005e6480
	v_cndmask_b16 v1.h, 0, v50.h, s24                          // 000000002e50: d65d5001 00626480
	v_lshlrev_b16 v14.h, 8, v14.h op_sel:[0,1,1]               // 000000002e58: d738500e 02021c88
	v_and_b16 v17.h, 0xff, v17.h op_sel:[0,1,1]                // 000000002e60: d7625011 020222ff 000000ff
	v_lshlrev_b16 v17.l, 8, v17.l                              // 000000002e6c: d7380011 02022288
	v_and_b16 v14.l, 0xff, v14.l                               // 000000002e74: d762000e 02021cff 000000ff
	v_lshlrev_b16 v1.h, 8, v1.h op_sel:[0,1,1]                 // 000000002e80: d7385001 02020288
	v_and_b16 v1.l, 0xff, v1.l                                 // 000000002e88: d7620001 020202ff 000000ff
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 000000002e94: bf870194
	v_or_b16 v20.l, v17.h, v17.l op_sel:[1,0,0]                // 000000002e98: d7630814 02022311
	v_or_b16 v20.h, v14.l, v1.h op_sel:[0,1,1]                 // 000000002ea0: d7635014 0202030e
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_1)// 000000002ea8: bf8700b3
	v_or_b16 v19.h, v1.l, v14.h op_sel:[0,1,1]                 // 000000002eac: d7635013 02021d01
	v_lshlrev_b16 v1.l, 8, v13.h op_sel:[0,1,0]                // 000000002eb4: d7381001 02021a88
	v_and_b16 v1.h, 0xff, v13.l op_sel:[0,0,1]                 // 000000002ebc: d7624001 02021aff 000000ff
	v_or_b16 v19.l, v1.h, v1.l op_sel:[1,0,0]                  // 000000002ec8: d7630813 02020301
	s_wait_loadcnt 0x9                                         // 000000002ed0: bfc00009
	v_cndmask_b16 v13.l, 0, v51.l, s25                         // 000000002ed4: d65d000d 00666680
	v_cndmask_b16 v13.h, 0, v51.h, s26                         // 000000002edc: d65d500d 006a6680
	s_wait_loadcnt 0x7                                         // 000000002ee4: bfc00007
	v_cndmask_b16 v14.l, 0, v52.l, s27                         // 000000002ee8: d65d000e 006e6880
	v_cndmask_b16 v14.h, 0, v52.h, s33                         // 000000002ef0: d65d500e 00866880
	s_wait_loadcnt 0x5                                         // 000000002ef8: bfc00005
	v_cndmask_b16 v17.l, 0, v53.l, s31                         // 000000002efc: d65d0011 007e6a80
	v_cndmask_b16 v17.h, 0, v53.h, s30                         // 000000002f04: d65d5011 007a6a80
	s_wait_loadcnt 0x3                                         // 000000002f0c: bfc00003
	v_cndmask_b16 v18.l, 0, v54.l, s29                         // 000000002f10: d65d0012 00766c80
	v_cndmask_b16 v18.h, 0, v54.h, s28                         // 000000002f18: d65d5012 00726c80
	v_lshlrev_b16 v14.h, 8, v14.h op_sel:[0,1,1]               // 000000002f20: d738500e 02021c88
	v_and_b16 v17.l, 0xff, v17.l                               // 000000002f28: d7620011 020222ff 000000ff
	v_lshlrev_b16 v17.h, 8, v17.h op_sel:[0,1,1]               // 000000002f34: d7385011 02022288
	v_and_b16 v18.l, 0xff, v18.l                               // 000000002f3c: d7620012 020224ff 000000ff
	v_lshlrev_b16 v18.h, 8, v18.h op_sel:[0,1,1]               // 000000002f48: d7385012 02022488
	v_and_b16 v14.l, 0xff, v14.l                               // 000000002f50: d762000e 02021cff 000000ff
	v_lshlrev_b16 v13.h, 8, v13.h op_sel:[0,1,1]               // 000000002f5c: d738500d 02021a88
	v_and_b16 v13.l, 0xff, v13.l                               // 000000002f64: d762000d 02021aff 000000ff
	v_or_b16 v40.h, v17.l, v14.h op_sel:[0,1,1]                // 000000002f70: d7635028 02021d11
	v_or_b16 v40.l, v18.l, v17.h op_sel:[0,1,0]                // 000000002f78: d7631028 02022312
	v_or_b16 v39.h, v14.l, v18.h op_sel:[0,1,1]                // 000000002f80: d7635027 0202250e
	s_wait_loadcnt 0x2                                         // 000000002f88: bfc00002
	v_mul_f32_e32 v1, v79, v71                                 // 000000002f8c: 10028f4f
	v_or_b16 v39.l, v13.l, v13.h op_sel:[0,1,0]                // 000000002f90: d7631027 02021b0d
	s_wait_loadcnt 0x1                                         // 000000002f98: bfc00001
	v_mul_f32_e32 v14, v79, v67                                // 000000002f9c: 101c874f
	s_wait_loadcnt 0x0                                         // 000000002fa0: bfc00000
	v_mul_f32_e32 v18, v73, v66                                // 000000002fa4: 10248549
	v_dual_add_f32 v13, v16, v42 :: v_dual_mul_f32 v16, v62, v73// 000000002fa8: c9065510 0d10933e
	v_wmma_f32_16x16x16_fp8_fp8 v[47:54], v[19:20], v[39:40], 0// 000000002fb0: cc46402f 1a024f13
	v_dual_mul_f32 v1, v45, v1 :: v_dual_mul_f32 v14, v46, v14 // 000000002fb8: c8c6032d 010e1d2e
	v_mul_f32_e32 v39, v73, v68                                // 000000002fc0: 104e8949
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_4)// 000000002fc4: bf870213
	v_mul_f32_e32 v18, v49, v18                                // 000000002fc8: 10242531
	v_mul_f32_e32 v16, v47, v16                                // 000000002fcc: 1020212f
	s_delay_alu instid0(valu_dep_4) | instskip(skip_1) | instid1(valu_dep_4)// 000000002fd0: bf870224
	v_add_f32_e32 v2, v2, v1                                   // 000000002fd4: 06040302
	v_add_f32_e32 v14, v24, v14                                // 000000002fd8: 061c1d18
	v_dual_mul_f32 v24, v73, v72 :: v_dual_add_f32 v19, v55, v18// 000000002fdc: c8c89149 18122537
	s_delay_alu instid0(valu_dep_4) | instskip(skip_1) | instid1(valu_dep_3)// 000000002fe4: bf8701a4
	v_add_f32_e32 v1, v61, v16                                 // 000000002fe8: 0602213d
	v_dual_mul_f32 v16, v73, v56 :: v_dual_mul_f32 v39, v54, v39// 000000002fec: c8c67149 10264f36
	v_mul_f32_e32 v24, v53, v24                                // 000000002ff4: 10303135
	v_mul_f32_e32 v17, v73, v64                                // 000000002ff8: 10228149
	v_mul_f32_e32 v18, v73, v60                                // 000000002ffc: 10247949
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000003000: bf870214
	v_mul_f32_e32 v16, v50, v16                                // 000000003004: 10202132
	v_add_f32_e32 v2, v2, v24                                  // 000000003008: 06043102
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 00000000300c: bf870214
	v_dual_add_f32 v24, v14, v39 :: v_dual_mul_f32 v17, v48, v17// 000000003010: c9064f0e 18102330
	v_mul_f32_e32 v40, v52, v18                                // 000000003018: 10502534
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 00000000301c: bf870194
	v_add_f32_e32 v18, v57, v16                                // 000000003020: 06242139
	v_dual_add_f32 v20, v43, v17 :: v_dual_mul_f32 v17, v73, v58// 000000003024: c906232b 14107549
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 00000000302c: bf870091
	v_dual_add_f32 v16, v13, v40 :: v_dual_mul_f32 v17, v51, v17// 000000003030: c906510d 10102333
	v_add_f32_e32 v17, v41, v17                                // 000000003038: 06222329
	s_wait_alu depctr_sa_sdst(0)                               // 00000000303c: bf88ff9e
	s_cbranch_vccz 64464                                       // 000000003040: bfa3fbd0 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x484>
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v9, 3, v15     // 000000003044: ca220080 0a081e83
	v_cmp_lt_i64_e64 s0, s[44:45], s[42:43]                    // 00000000304c: d4510000 0200542c
	s_delay_alu instid0(valu_dep_2)                            // 000000003054: bf870002
	v_or_b32_e32 v7, s54, v9                                   // 000000003058: 380e1236
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000305c: 8b6a007e
	s_wait_alu depctr_sa_sdst(0)                               // 000000003060: bf88ff9e
	s_cbranch_vccnz 6                                          // 000000003064: bfa40006 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x1580>
	v_mov_b32_e32 v8, s55                                      // 000000003068: 7e100237
	s_mov_b32 s0, 0                                            // 00000000306c: be800080
	s_branch 4                                                 // 000000003070: bfa00004 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x1584>
	s_mov_b32 s0, 0                                            // 000000003074: be800080
	s_cbranch_execnz 1147                                      // 000000003078: bfa6047b <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2768>
	s_branch 2204                                              // 00000000307c: bfa0089c <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x37f0>
	s_mov_b32 s0, -1                                           // 000000003080: be8000c1
	s_wait_alu depctr_sa_sdst(0)                               // 000000003084: bf88ff9e
	s_and_b32 s0, s0, exec_lo                                  // 000000003088: 8b007e00
	s_cselect_b32 s0, 1, 0                                     // 00000000308c: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 000000003090: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000003094: bf078100
	s_cbranch_scc1 810                                         // 000000003098: bfa2032a <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2244>
	v_mov_b32_e32 v8, s55                                      // 00000000309c: 7e100237
	v_or_b32_e32 v13, 1, v7                                    // 0000000030a0: 381a0e81
	v_or_b32_e32 v21, 2, v7                                    // 0000000030a4: 382a0e82
	v_mov_b32_e32 v22, s55                                     // 0000000030a8: 7e2c0237
	v_cmp_gt_i64_e64 s0, s[38:39], v[3:4]                      // 0000000030ac: d4540000 02020626
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[7:8]                  // 0000000030b4: 7ca80e24
	v_or_b32_e32 v25, 3, v7                                    // 0000000030b8: 38320e83
	v_cmp_gt_i64_e64 s1, s[36:37], v[5:6]                      // 0000000030bc: d4540001 02020a24
	v_or_b32_e32 v35, 7, v7                                    // 0000000030c4: 38460e87
	s_mov_b64 s[12:13], s[44:45]                               // 0000000030c8: be8c012c
	v_cndmask_b32_e64 v12, 0, v4, s0                           // 0000000030cc: d501000c 00020880
	s_wait_alu depctr_va_vcc(0)                                // 0000000030d4: bf88ff9d
	v_dual_cndmask_b32 v11, 0, v7 :: v_dual_mov_b32 v14, s55   // 0000000030d8: ca500e80 0b0e0037
	v_cndmask_b32_e32 v0, 0, v8, vcc_lo                        // 0000000030e0: 02001080
	v_mov_b32_e32 v26, s55                                     // 0000000030e4: 7e340237
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_4)// 0000000030e8: bf870213
	v_mad_co_u64_u32 v[27:28], null, s58, v11, 0               // 0000000030ec: d6fe7c1b 0202163a
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[13:14]                // 0000000030f4: 7ca81a24
	v_mul_lo_u32 v14, s59, v11                                 // 0000000030f8: d72c000e 0202163b
	v_cndmask_b32_e64 v11, 0, v3, s0                           // 000000003100: d501000b 00020680
	s_wait_alu depctr_va_vcc(0)                                // 000000003108: bf88ff9d
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 00000000310c: 021a1a80
	v_mul_lo_u32 v0, s58, v0                                   // 000000003110: d72c0000 0202003a
	v_cndmask_b32_e32 v29, 0, v8, vcc_lo                       // 000000003118: 023a1080
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[21:22]                // 00000000311c: 7ca82a24
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 000000003120: bf870194
	v_mul_lo_u32 v31, s59, v13                                 // 000000003124: d72c001f 02021a3b
	v_mul_lo_u32 v22, s58, v29                                 // 00000000312c: d72c0016 02023a3a
	v_mad_co_u64_u32 v[29:30], null, s58, v13, 0               // 000000003134: d6fe7c1d 02021a3a
	v_add3_u32 v28, v28, v0, v14                               // 00000000313c: d655001c 043a011c
	s_wait_alu depctr_va_vcc(0)                                // 000000003144: bf88ff9d
	v_dual_cndmask_b32 v32, 0, v8 :: v_dual_cndmask_b32 v21, 0, v21// 000000003148: ca521080 20142a80
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[25:26]                // 000000003150: 7ca83224
	v_lshlrev_b64_e32 v[13:14], 2, v[11:12]                    // 000000003154: 3e1a1682
	v_lshlrev_b64_e32 v[5:6], 2, v[27:28]                      // 000000003158: 3e0a3682
	s_delay_alu instid0(valu_dep_4)                            // 00000000315c: bf870004
	v_mul_lo_u32 v11, s59, v21                                 // 000000003160: d72c000b 02022a3b
	v_add3_u32 v30, v30, v22, v31                              // 000000003168: d655001e 047e2d1e
	s_wait_alu depctr_va_vcc(0)                                // 000000003170: bf88ff9d
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000003174: 02323280
	v_mul_lo_u32 v26, s58, v32                                 // 000000003178: d72c001a 0202403a
	v_add_co_u32 v0, s2, s52, v5                               // 000000003180: d7000200 02020a34
	s_wait_alu depctr_va_sdst(0)                               // 000000003188: bf88f19f
	v_add_co_ci_u32_e64 v12, null, s53, v6, s2                 // 00000000318c: d5207c0c 000a0c35
	v_mad_co_u64_u32 v[5:6], null, s58, v21, 0                 // 000000003194: d6fe7c05 02022a3a
	v_cndmask_b32_e32 v27, 0, v8, vcc_lo                       // 00000000319c: 02361080
	v_lshlrev_b64_e32 v[21:22], 2, v[29:30]                    // 0000000031a0: 3e2a3a82
	v_add_co_u32 v13, vcc_lo, s60, v13                         // 0000000031a4: d7006a0d 02021a3c
	s_wait_alu depctr_va_vcc(0)                                // 0000000031ac: bf88ff9d
	v_add_co_ci_u32_e64 v14, null, s61, v14, vcc_lo            // 0000000031b0: d5207c0e 01aa1c3d
	v_mul_lo_u32 v31, s58, v27                                 // 0000000031b8: d72c001f 0202363a
	v_add3_u32 v6, v6, v26, v11                                // 0000000031c0: d6550006 042e3506
	v_mul_lo_u32 v11, s59, v25                                 // 0000000031c8: d72c000b 0202323b
	v_mad_co_u64_u32 v[27:28], null, s58, v25, 0               // 0000000031d0: d6fe7c1b 0202323a
	v_or_b32_e32 v25, 4, v7                                    // 0000000031d8: 38320e84
	v_mov_b32_e32 v26, s55                                     // 0000000031dc: 7e340237
	v_add_co_u32 v21, vcc_lo, s52, v21                         // 0000000031e0: d7006a15 02022a34
	s_wait_alu depctr_va_vcc(0)                                // 0000000031e8: bf88ff9d
	v_add_co_ci_u32_e64 v22, null, s53, v22, vcc_lo            // 0000000031ec: d5207c16 01aa2c35
	s_delay_alu instid0(valu_dep_3)                            // 0000000031f4: bf870003
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[25:26]                // 0000000031f8: 7ca83224
	v_or_b32_e32 v29, 5, v7                                    // 0000000031fc: 383a0e85
	v_mov_b32_e32 v30, s55                                     // 000000003200: 7e3c0237
	v_lshlrev_b64_e32 v[5:6], 2, v[5:6]                        // 000000003204: 3e0a0a82
	v_add3_u32 v28, v28, v31, v11                              // 000000003208: d655001c 042e3f1c
	s_wait_alu depctr_va_vcc(0)                                // 000000003210: bf88ff9d
	v_cndmask_b32_e32 v11, 0, v8, vcc_lo                       // 000000003214: 02161080
	v_cndmask_b32_e32 v31, 0, v25, vcc_lo                      // 000000003218: 023e3280
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[29:30]                // 00000000321c: 7ca83a24
	v_add_co_u32 v25, s2, s52, v5                              // 000000003220: d7000219 02020a34
	s_wait_alu depctr_va_sdst(0)                               // 000000003228: bf88f19f
	v_add_co_ci_u32_e64 v26, null, s53, v6, s2                 // 00000000322c: d5207c1a 000a0c35
	v_lshlrev_b64_e32 v[5:6], 2, v[27:28]                      // 000000003234: 3e0a3682
	s_wait_alu depctr_va_vcc(0)                                // 000000003238: bf88ff9d
	v_dual_cndmask_b32 v27, 0, v8 :: v_dual_cndmask_b32 v28, 0, v29// 00000000323c: ca521080 1b1c3a80
	v_or_b32_e32 v29, 6, v7                                    // 000000003244: 383a0e86
	v_mul_lo_u32 v37, s59, v31                                 // 000000003248: d72c0025 02023e3b
	v_mul_lo_u32 v11, s58, v11                                 // 000000003250: d72c000b 0202163a
	v_mad_co_u64_u32 v[31:32], null, s58, v31, 0               // 000000003258: d6fe7c1f 02023e3a
	v_mul_lo_u32 v38, s59, v28                                 // 000000003260: d72c0026 0202383b
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[29:30]                // 000000003268: 7ca83a24
	v_mov_b32_e32 v36, s55                                     // 00000000326c: 7e480237
	v_mul_lo_u32 v39, s58, v27                                 // 000000003270: d72c0027 0202363a
	v_mad_co_u64_u32 v[33:34], null, s58, v28, 0               // 000000003278: d6fe7c21 0202383a
	v_add_co_u32 v27, s2, s52, v5                              // 000000003280: d700021b 02020a34
	s_wait_alu depctr_va_sdst(0)                               // 000000003288: bf88f19f
	v_add_co_ci_u32_e64 v28, null, s53, v6, s2                 // 00000000328c: d5207c1c 000a0c35
	v_add3_u32 v32, v32, v11, v37                              // 000000003294: d6550020 04961720
	s_wait_alu depctr_va_vcc(0)                                // 00000000329c: bf88ff9d
	v_cndmask_b32_e32 v11, 0, v8, vcc_lo                       // 0000000032a0: 02161080
	v_cmp_gt_i64_e64 s2, s[36:37], v[35:36]                    // 0000000032a4: d4540002 02024624
	v_add3_u32 v34, v34, v39, v38                              // 0000000032ac: d6550022 049a4f22
	v_cndmask_b32_e32 v29, 0, v29, vcc_lo                      // 0000000032b4: 023a3a80
	v_lshlrev_b64_e32 v[5:6], 2, v[31:32]                      // 0000000032b8: 3e0a3e82
	v_mul_lo_u32 v11, s58, v11                                 // 0000000032bc: d72c000b 0202163a
	s_wait_alu depctr_va_sdst(0)                               // 0000000032c4: bf88f19f
	v_cndmask_b32_e64 v30, 0, v8, s2                           // 0000000032c8: d501001e 000a1080
	v_cndmask_b32_e64 v35, 0, v35, s2                          // 0000000032d0: d5010023 000a4680
	v_lshlrev_b64_e32 v[31:32], 2, v[33:34]                    // 0000000032d8: 3e3e4282
	v_mul_lo_u32 v37, s59, v29                                 // 0000000032dc: d72c0025 02023a3b
	v_mad_co_u64_u32 v[33:34], null, s58, v29, 0               // 0000000032e4: d6fe7c21 02023a3a
	v_mul_lo_u32 v39, s58, v30                                 // 0000000032ec: d72c0027 02023c3a
	v_mul_lo_u32 v38, s59, v35                                 // 0000000032f4: d72c0026 0202463b
	v_mad_co_u64_u32 v[35:36], null, s58, v35, 0               // 0000000032fc: d6fe7c23 0202463a
	v_add_co_u32 v29, vcc_lo, s52, v5                          // 000000003304: d7006a1d 02020a34
	v_add_co_u32 v5, s2, s54, v23                              // 00000000330c: d7000205 02022e36
	s_wait_alu depctr_va_vcc(0)                                // 000000003314: bf88ff9d
	v_add_co_ci_u32_e64 v30, null, s53, v6, vcc_lo             // 000000003318: d5207c1e 01aa0c35
	v_add3_u32 v34, v34, v11, v37                              // 000000003320: d6550022 04961722
	s_wait_alu depctr_va_sdst(0)                               // 000000003328: bf88f19f
	v_add_co_ci_u32_e64 v6, null, s55, 0, s2                   // 00000000332c: d5207c06 00090037
	v_add_co_u32 v11, s2, s56, v23                             // 000000003334: d700020b 02022e38
	v_add3_u32 v36, v36, v39, v38                              // 00000000333c: d6550024 049a4f24
	s_wait_alu depctr_va_sdst(0)                               // 000000003344: bf88f19f
	v_add_co_ci_u32_e64 v37, null, s57, 0, s2                  // 000000003348: d5207c25 00090039
	v_lshlrev_b64_e32 v[33:34], 2, v[33:34]                    // 000000003350: 3e424282
	v_mul_lo_u32 v38, s46, v6                                  // 000000003354: d72c0026 02020c2e
	v_lshlrev_b64_e32 v[35:36], 2, v[35:36]                    // 00000000335c: 3e464682
	v_mul_lo_u32 v39, s47, v5                                  // 000000003360: d72c0027 02020a2f
	v_mad_co_u64_u32 v[5:6], null, s46, v5, v[9:10]            // 000000003368: d6fe7c05 04260a2e
	v_mul_lo_u32 v37, s46, v37                                 // 000000003370: d72c0025 02024a2e
	v_mul_lo_u32 v40, s47, v11                                 // 000000003378: d72c0028 0202162f
	v_mad_co_u64_u32 v[10:11], null, s46, v11, v[9:10]         // 000000003380: d6fe7c0a 0426162e
	v_add_co_u32 v31, vcc_lo, s52, v31                         // 000000003388: d7006a1f 02023e34
	s_wait_alu depctr_va_vcc(0)                                // 000000003390: bf88ff9d
	v_add_co_ci_u32_e64 v32, null, s53, v32, vcc_lo            // 000000003394: d5207c20 01aa4035
	v_add_co_u32 v33, vcc_lo, s52, v33                         // 00000000339c: d7006a21 02024234
	s_wait_alu depctr_va_vcc(0)                                // 0000000033a4: bf88ff9d
	v_add_co_ci_u32_e64 v34, null, s53, v34, vcc_lo            // 0000000033a8: d5207c22 01aa4435
	v_add_co_u32 v35, vcc_lo, s52, v35                         // 0000000033b0: d7006a23 02024634
	s_wait_alu depctr_va_vcc(0)                                // 0000000033b8: bf88ff9d
	v_add_co_ci_u32_e64 v36, null, s53, v36, vcc_lo            // 0000000033bc: d5207c24 01aa4835
	v_add3_u32 v6, v39, v6, v38                                // 0000000033c4: d6550006 049a0d27
	v_add3_u32 v11, v40, v11, v37                              // 0000000033cc: d655000b 04961728
	s_wait_alu depctr_sa_sdst(0)                               // 0000000033d4: bf88ff9e
	v_add_co_u32 v41, s2, v9, s12                              // 0000000033d8: d7000229 02001909
	s_wait_alu depctr_va_sdst(0)                               // 0000000033e0: bf88f19f
	v_add_co_ci_u32_e64 v42, null, 0, s13, s2                  // 0000000033e4: d5207c2a 00081a80
	v_add_co_u32 v45, vcc_lo, v5, s12                          // 0000000033ec: d7006a2d 02001905
	s_wait_alu depctr_va_vcc(0)                                // 0000000033f4: bf88ff9d
	v_add_co_ci_u32_e64 v46, null, s13, v6, vcc_lo             // 0000000033f8: d5207c2e 01aa0c0d
	s_delay_alu instid0(valu_dep_3)                            // 000000003400: bf870003
	v_cmp_gt_i64_e32 vcc_lo, s[46:47], v[41:42]                // 000000003404: 7ca8522e
	s_and_b32 s2, s1, vcc_lo                                   // 000000003408: 8b026a01
	s_and_b32 vcc_lo, s0, vcc_lo                               // 00000000340c: 8b6a6a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000003410: bf88ff9e
	v_cndmask_b32_e64 v37, 0, v45, s2                          // 000000003414: d5010025 000a5a80
	v_cndmask_b32_e64 v38, 0, v46, s2                          // 00000000341c: d5010026 000a5c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000003424: bf870122
	v_add_co_u32 v37, s3, s48, v37                             // 000000003428: d7000325 02024a30
	s_wait_alu depctr_va_sdst(0)                               // 000000003430: bf88f19f
	v_add_co_ci_u32_e64 v38, null, s49, v38, s3                // 000000003434: d5207c26 000e4c31
	global_load_d16_u8 v37, v[37:38], off                      // 00000000343c: ee07807c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003448: bfc00000
	v_cndmask_b16 v37.l, 0, v37.l, s2                          // 00000000344c: d65d0025 000a4a80
	v_add_co_u32 v40, s2, v45, 1                               // 000000003454: d7000228 0201032d
	s_wait_alu depctr_va_sdst(0)                               // 00000000345c: bf88f19f
	v_add_co_ci_u32_e64 v43, null, 0, v46, s2                  // 000000003460: d5207c2b 000a5c80
	v_add_co_u32 v38, s2, v41, 1                               // 000000003468: d7000226 02010329
	s_wait_alu depctr_va_sdst(0)                               // 000000003470: bf88f19f
	v_add_co_ci_u32_e64 v39, null, 0, v42, s2                  // 000000003474: d5207c27 000a5480
	v_and_b16 v37.l, 0xff, v37.l                               // 00000000347c: d7620025 02024aff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000003488: bf870152
	v_cmp_gt_i64_e64 s2, s[46:47], v[38:39]                    // 00000000348c: d4540002 02024c2e
	s_and_b32 s3, s1, s2                                       // 000000003494: 8b030201
	s_wait_alu depctr_sa_sdst(0)                               // 000000003498: bf88ff9e
	v_cndmask_b32_e64 v38, 0, v40, s3                          // 00000000349c: d5010026 000e5080
	v_cndmask_b32_e64 v39, 0, v43, s3                          // 0000000034a4: d5010027 000e5680
	v_add_co_u32 v38, s4, s48, v38                             // 0000000034ac: d7000426 02024c30
	s_wait_alu depctr_va_sdst(0)                               // 0000000034b4: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 0000000034b8: bf870002
	v_add_co_ci_u32_e64 v39, null, s49, v39, s4                // 0000000034bc: d5207c27 00124e31
	global_load_d16_hi_u8 v37, v[38:39], off                   // 0000000034c4: ee08407c 00000025 00000026
	s_wait_loadcnt 0x0                                         // 0000000034d0: bfc00000
	v_cndmask_b16 v37.h, 0, v37.h, s3                          // 0000000034d4: d65d5025 000e4a80
	v_add_co_u32 v40, s3, v45, 2                               // 0000000034dc: d7000328 0201052d
	s_wait_alu depctr_va_sdst(0)                               // 0000000034e4: bf88f19f
	v_add_co_ci_u32_e64 v43, null, 0, v46, s3                  // 0000000034e8: d5207c2b 000e5c80
	v_add_co_u32 v38, s3, v41, 2                               // 0000000034f0: d7000326 02010529
	s_wait_alu depctr_va_sdst(0)                               // 0000000034f8: bf88f19f
	v_add_co_ci_u32_e64 v39, null, 0, v42, s3                  // 0000000034fc: d5207c27 000e5480
	v_lshlrev_b16 v37.h, 8, v37.h op_sel:[0,1,1]               // 000000003504: d7385025 02024a88
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 00000000350c: bf870152
	v_cmp_gt_i64_e64 s3, s[46:47], v[38:39]                    // 000000003510: d4540003 02024c2e
	s_and_b32 s4, s1, s3                                       // 000000003518: 8b040301
	s_wait_alu depctr_sa_sdst(0)                               // 00000000351c: bf88ff9e
	v_cndmask_b32_e64 v38, 0, v40, s4                          // 000000003520: d5010026 00125080
	v_cndmask_b32_e64 v39, 0, v43, s4                          // 000000003528: d5010027 00125680
	v_add_co_u32 v38, s5, s48, v38                             // 000000003530: d7000526 02024c30
	s_wait_alu depctr_va_sdst(0)                               // 000000003538: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 00000000353c: bf870002
	v_add_co_ci_u32_e64 v39, null, s49, v39, s5                // 000000003540: d5207c27 00164e31
	global_load_d16_u8 v38, v[38:39], off                      // 000000003548: ee07807c 00000026 00000026
	s_wait_loadcnt 0x0                                         // 000000003554: bfc00000
	v_cndmask_b16 v38.l, 0, v38.l, s4                          // 000000003558: d65d0026 00124c80
	v_add_co_u32 v43, s4, v45, 3                               // 000000003560: d700042b 0201072d
	s_wait_alu depctr_va_sdst(0)                               // 000000003568: bf88f19f
	v_add_co_ci_u32_e64 v44, null, 0, v46, s4                  // 00000000356c: d5207c2c 00125c80
	v_add_co_u32 v39, s4, v41, 3                               // 000000003574: d7000427 02010729
	s_wait_alu depctr_va_sdst(0)                               // 00000000357c: bf88f19f
	v_add_co_ci_u32_e64 v40, null, 0, v42, s4                  // 000000003580: d5207c28 00125480
	v_and_b16 v38.l, 0xff, v38.l                               // 000000003588: d7620026 02024cff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000003594: bf870152
	v_cmp_gt_i64_e64 s4, s[46:47], v[39:40]                    // 000000003598: d4540004 02024e2e
	s_and_b32 s5, s1, s4                                       // 0000000035a0: 8b050401
	s_wait_alu depctr_sa_sdst(0)                               // 0000000035a4: bf88ff9e
	v_cndmask_b32_e64 v39, 0, v43, s5                          // 0000000035a8: d5010027 00165680
	v_cndmask_b32_e64 v40, 0, v44, s5                          // 0000000035b0: d5010028 00165880
	v_add_co_u32 v39, s6, s48, v39                             // 0000000035b8: d7000627 02024e30
	s_wait_alu depctr_va_sdst(0)                               // 0000000035c0: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 0000000035c4: bf870002
	v_add_co_ci_u32_e64 v40, null, s49, v40, s6                // 0000000035c8: d5207c28 001a5031
	global_load_d16_hi_u8 v38, v[39:40], off                   // 0000000035d0: ee08407c 00000026 00000027
	s_wait_loadcnt 0x0                                         // 0000000035dc: bfc00000
	v_cndmask_b16 v38.h, 0, v38.h, s5                          // 0000000035e0: d65d5026 00164c80
	v_add_co_u32 v43, s5, v45, 4                               // 0000000035e8: d700052b 0201092d
	s_wait_alu depctr_va_sdst(0)                               // 0000000035f0: bf88f19f
	v_add_co_ci_u32_e64 v44, null, 0, v46, s5                  // 0000000035f4: d5207c2c 00165c80
	v_add_co_u32 v39, s5, v41, 4                               // 0000000035fc: d7000527 02010929
	s_wait_alu depctr_va_sdst(0)                               // 000000003604: bf88f19f
	v_add_co_ci_u32_e64 v40, null, 0, v42, s5                  // 000000003608: d5207c28 00165480
	v_lshlrev_b16 v38.h, 8, v38.h op_sel:[0,1,1]               // 000000003610: d7385026 02024c88
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000003618: bf870152
	v_cmp_gt_i64_e64 s5, s[46:47], v[39:40]                    // 00000000361c: d4540005 02024e2e
	s_and_b32 s6, s1, s5                                       // 000000003624: 8b060501
	s_wait_alu depctr_sa_sdst(0)                               // 000000003628: bf88ff9e
	v_cndmask_b32_e64 v39, 0, v43, s6                          // 00000000362c: d5010027 001a5680
	v_cndmask_b32_e64 v40, 0, v44, s6                          // 000000003634: d5010028 001a5880
	v_add_co_u32 v39, s7, s48, v39                             // 00000000363c: d7000727 02024e30
	s_wait_alu depctr_va_sdst(0)                               // 000000003644: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000003648: bf870002
	v_add_co_ci_u32_e64 v40, null, s49, v40, s7                // 00000000364c: d5207c28 001e5031
	global_load_d16_u8 v39, v[39:40], off                      // 000000003654: ee07807c 00000027 00000027
	s_wait_loadcnt 0x0                                         // 000000003660: bfc00000
	v_cndmask_b16 v39.l, 0, v39.l, s6                          // 000000003664: d65d0027 001a4e80
	v_add_co_u32 v40, s6, v45, 5                               // 00000000366c: d7000628 02010b2d
	s_wait_alu depctr_va_sdst(0)                               // 000000003674: bf88f19f
	v_add_co_ci_u32_e64 v47, null, 0, v46, s6                  // 000000003678: d5207c2f 001a5c80
	v_add_co_u32 v43, s6, v41, 5                               // 000000003680: d700062b 02010b29
	s_wait_alu depctr_va_sdst(0)                               // 000000003688: bf88f19f
	v_add_co_ci_u32_e64 v44, null, 0, v42, s6                  // 00000000368c: d5207c2c 001a5480
	v_and_b16 v39.l, 0xff, v39.l                               // 000000003694: d7620027 02024eff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 0000000036a0: bf870152
	v_cmp_gt_i64_e64 s6, s[46:47], v[43:44]                    // 0000000036a4: d4540006 0202562e
	s_and_b32 s7, s1, s6                                       // 0000000036ac: 8b070601
	s_wait_alu depctr_sa_sdst(0)                               // 0000000036b0: bf88ff9e
	v_cndmask_b32_e64 v40, 0, v40, s7                          // 0000000036b4: d5010028 001e5080
	v_cndmask_b32_e64 v44, 0, v47, s7                          // 0000000036bc: d501002c 001e5e80
	v_add_co_u32 v43, s8, s48, v40                             // 0000000036c4: d700082b 02025030
	s_wait_alu depctr_va_sdst(0)                               // 0000000036cc: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 0000000036d0: bf870002
	v_add_co_ci_u32_e64 v44, null, s49, v44, s8                // 0000000036d4: d5207c2c 00225831
	global_load_d16_hi_u8 v39, v[43:44], off                   // 0000000036dc: ee08407c 00000027 0000002b
	s_wait_loadcnt 0x0                                         // 0000000036e8: bfc00000
	v_cndmask_b16 v39.h, 0, v39.h, s7                          // 0000000036ec: d65d5027 001e4e80
	v_add_co_u32 v40, s7, v45, 6                               // 0000000036f4: d7000728 02010d2d
	s_wait_alu depctr_va_sdst(0)                               // 0000000036fc: bf88f19f
	v_add_co_ci_u32_e64 v47, null, 0, v46, s7                  // 000000003700: d5207c2f 001e5c80
	v_add_co_u32 v43, s7, v41, 6                               // 000000003708: d700072b 02010d29
	s_wait_alu depctr_va_sdst(0)                               // 000000003710: bf88f19f
	v_add_co_ci_u32_e64 v44, null, 0, v42, s7                  // 000000003714: d5207c2c 001e5480
	v_lshlrev_b16 v39.h, 8, v39.h op_sel:[0,1,1]               // 00000000371c: d7385027 02024e88
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000003724: bf870152
	v_cmp_gt_i64_e64 s7, s[46:47], v[43:44]                    // 000000003728: d4540007 0202562e
	s_and_b32 s8, s1, s7                                       // 000000003730: 8b080701
	s_wait_alu depctr_sa_sdst(0)                               // 000000003734: bf88ff9e
	v_cndmask_b32_e64 v40, 0, v40, s8                          // 000000003738: d5010028 00225080
	v_cndmask_b32_e64 v44, 0, v47, s8                          // 000000003740: d501002c 00225e80
	v_add_co_u32 v43, s9, s48, v40                             // 000000003748: d700092b 02025030
	s_wait_alu depctr_va_sdst(0)                               // 000000003750: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000003754: bf870002
	v_add_co_ci_u32_e64 v44, null, s49, v44, s9                // 000000003758: d5207c2c 00265831
	global_load_d16_u8 v40, v[43:44], off                      // 000000003760: ee07807c 00000028 0000002b
	s_wait_loadcnt 0x0                                         // 00000000376c: bfc00000
	v_cndmask_b16 v40.l, 0, v40.l, s8                          // 000000003770: d65d0028 00225080
	v_add_co_u32 v43, s8, v45, 7                               // 000000003778: d700082b 02010f2d
	s_wait_alu depctr_va_sdst(0)                               // 000000003780: bf88f19f
	v_add_co_ci_u32_e64 v44, null, 0, v46, s8                  // 000000003784: d5207c2c 00225c80
	v_add_co_u32 v41, s8, v41, 7                               // 00000000378c: d7000829 02010f29
	s_wait_alu depctr_va_sdst(0)                               // 000000003794: bf88f19f
	v_add_co_ci_u32_e64 v42, null, 0, v42, s8                  // 000000003798: d5207c2a 00225480
	v_or_b16 v45.h, v38.l, v38.h op_sel:[0,1,1]                // 0000000037a0: d763502d 02024d26
	v_or_b16 v45.l, v37.l, v37.h op_sel:[0,1,0]                // 0000000037a8: d763102d 02024b25
	v_or_b16 v46.l, v39.l, v39.h op_sel:[0,1,0]                // 0000000037b0: d763102e 02024f27
	s_delay_alu instid0(valu_dep_4)                            // 0000000037b8: bf870004
	v_cmp_gt_i64_e64 s8, s[46:47], v[41:42]                    // 0000000037bc: d4540008 0202522e
	v_and_b16 v40.l, 0xff, v40.l                               // 0000000037c4: d7620028 020250ff 000000ff
	s_and_b32 s9, s1, s8                                       // 0000000037d0: 8b090801
	s_wait_alu depctr_sa_sdst(0)                               // 0000000037d4: bf88ff9e
	v_cndmask_b32_e64 v41, 0, v43, s9                          // 0000000037d8: d5010029 00265680
	v_cndmask_b32_e64 v42, 0, v44, s9                          // 0000000037e0: d501002a 00265880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000037e8: bf870122
	v_add_co_u32 v41, s10, s48, v41                            // 0000000037ec: d7000a29 02025230
	s_wait_alu depctr_va_sdst(0)                               // 0000000037f4: bf88f19f
	v_add_co_ci_u32_e64 v42, null, s49, v42, s10               // 0000000037f8: d5207c2a 002a5431
	global_load_d16_hi_u8 v40, v[41:42], off                   // 000000003800: ee08407c 00000028 00000029
	s_wait_loadcnt 0x0                                         // 00000000380c: bfc00000
	v_cndmask_b16 v40.h, 0, v40.h, s9                          // 000000003810: d65d5028 00265080
	v_add_co_u32 v42, s9, v10, s12                             // 000000003818: d700092a 0200190a
	s_wait_alu depctr_va_sdst(0)                               // 000000003820: bf88f19f
	v_add_co_ci_u32_e64 v43, null, s13, v11, s9                // 000000003824: d5207c2b 0026160d
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_2)// 00000000382c: bf870113
	v_lshlrev_b16 v40.h, 8, v40.h op_sel:[0,1,1]               // 000000003830: d7385028 02025088
	v_dual_cndmask_b32 v37, 0, v42 :: v_dual_cndmask_b32 v38, 0, v43// 000000003838: ca525480 25265680
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003840: bf870112
	v_or_b16 v46.h, v40.l, v40.h op_sel:[0,1,1]                // 000000003844: d763502e 02025128
	v_add_co_u32 v37, s9, s50, v37                             // 00000000384c: d7000925 02024a32
	s_wait_alu depctr_va_sdst(0)                               // 000000003854: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000003858: bf870003
	v_add_co_ci_u32_e64 v38, null, s51, v38, s9                // 00000000385c: d5207c26 00264c33
	global_load_d16_u8 v37, v[37:38], off                      // 000000003864: ee07807c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003870: bfc00000
	v_cndmask_b16 v37.l, 0, v37.l, vcc_lo                      // 000000003874: d65d0025 01aa4a80
	v_add_co_u32 v38, vcc_lo, v42, 1                           // 00000000387c: d7006a26 0201032a
	s_wait_alu depctr_va_vcc(0)                                // 000000003884: bf88ff9d
	v_add_co_ci_u32_e64 v39, null, 0, v43, vcc_lo              // 000000003888: d5207c27 01aa5680
	s_and_b32 vcc_lo, s0, s2                                   // 000000003890: 8b6a0200
	v_and_b16 v37.l, 0xff, v37.l                               // 000000003894: d7620025 02024aff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000038a0: bf88ff9e
	v_dual_cndmask_b32 v38, 0, v38 :: v_dual_cndmask_b32 v39, 0, v39// 0000000038a4: ca524c80 26264e80
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 0000000038ac: bf870121
	v_add_co_u32 v38, s2, s50, v38                             // 0000000038b0: d7000226 02024c32
	s_wait_alu depctr_va_sdst(0)                               // 0000000038b8: bf88f19f
	v_add_co_ci_u32_e64 v39, null, s51, v39, s2                // 0000000038bc: d5207c27 000a4e33
	global_load_d16_hi_u8 v37, v[38:39], off                   // 0000000038c4: ee08407c 00000025 00000026
	s_wait_loadcnt 0x0                                         // 0000000038d0: bfc00000
	v_cndmask_b16 v37.h, 0, v37.h, vcc_lo                      // 0000000038d4: d65d5025 01aa4a80
	v_add_co_u32 v38, vcc_lo, v42, 2                           // 0000000038dc: d7006a26 0201052a
	s_wait_alu depctr_va_vcc(0)                                // 0000000038e4: bf88ff9d
	v_add_co_ci_u32_e64 v39, null, 0, v43, vcc_lo              // 0000000038e8: d5207c27 01aa5680
	s_and_b32 vcc_lo, s0, s3                                   // 0000000038f0: 8b6a0300
	v_lshlrev_b16 v37.h, 8, v37.h op_sel:[0,1,1]               // 0000000038f4: d7385025 02024a88
	s_wait_alu depctr_sa_sdst(0)                               // 0000000038fc: bf88ff9e
	v_dual_cndmask_b32 v38, 0, v38 :: v_dual_cndmask_b32 v39, 0, v39// 000000003900: ca524c80 26264e80
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003908: bf870112
	v_or_b16 v47.l, v37.l, v37.h op_sel:[0,1,0]                // 00000000390c: d763102f 02024b25
	v_add_co_u32 v38, s2, s50, v38                             // 000000003914: d7000226 02024c32
	s_wait_alu depctr_va_sdst(0)                               // 00000000391c: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000003920: bf870003
	v_add_co_ci_u32_e64 v39, null, s51, v39, s2                // 000000003924: d5207c27 000a4e33
	global_load_d16_u8 v38, v[38:39], off                      // 00000000392c: ee07807c 00000026 00000026
	s_wait_loadcnt 0x0                                         // 000000003938: bfc00000
	v_cndmask_b16 v38.l, 0, v38.l, vcc_lo                      // 00000000393c: d65d0026 01aa4c80
	v_add_co_u32 v39, vcc_lo, v42, 3                           // 000000003944: d7006a27 0201072a
	s_wait_alu depctr_va_vcc(0)                                // 00000000394c: bf88ff9d
	v_add_co_ci_u32_e64 v40, null, 0, v43, vcc_lo              // 000000003950: d5207c28 01aa5680
	s_and_b32 vcc_lo, s0, s4                                   // 000000003958: 8b6a0400
	v_and_b16 v38.l, 0xff, v38.l                               // 00000000395c: d7620026 02024cff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003968: bf88ff9e
	v_dual_cndmask_b32 v39, 0, v39 :: v_dual_cndmask_b32 v40, 0, v40// 00000000396c: ca524e80 27285080
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000003974: bf870121
	v_add_co_u32 v39, s2, s50, v39                             // 000000003978: d7000227 02024e32
	s_wait_alu depctr_va_sdst(0)                               // 000000003980: bf88f19f
	v_add_co_ci_u32_e64 v40, null, s51, v40, s2                // 000000003984: d5207c28 000a5033
	global_load_d16_hi_u8 v38, v[39:40], off                   // 00000000398c: ee08407c 00000026 00000027
	s_wait_loadcnt 0x0                                         // 000000003998: bfc00000
	v_cndmask_b16 v38.h, 0, v38.h, vcc_lo                      // 00000000399c: d65d5026 01aa4c80
	v_add_co_u32 v39, vcc_lo, v42, 4                           // 0000000039a4: d7006a27 0201092a
	s_wait_alu depctr_va_vcc(0)                                // 0000000039ac: bf88ff9d
	v_add_co_ci_u32_e64 v40, null, 0, v43, vcc_lo              // 0000000039b0: d5207c28 01aa5680
	s_and_b32 vcc_lo, s0, s5                                   // 0000000039b8: 8b6a0500
	v_lshlrev_b16 v38.h, 8, v38.h op_sel:[0,1,1]               // 0000000039bc: d7385026 02024c88
	s_wait_alu depctr_sa_sdst(0)                               // 0000000039c4: bf88ff9e
	v_dual_cndmask_b32 v39, 0, v39 :: v_dual_cndmask_b32 v40, 0, v40// 0000000039c8: ca524e80 27285080
	s_lshr_b64 s[4:5], s[12:13], 2                             // 0000000039d0: 8584820c
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 0000000039d4: bf870112
	v_or_b16 v47.h, v38.l, v38.h op_sel:[0,1,1]                // 0000000039d8: d763502f 02024d26
	v_add_co_u32 v39, s2, s50, v39                             // 0000000039e0: d7000227 02024e32
	s_wait_alu depctr_va_sdst(0)                               // 0000000039e8: bf88f19f
	v_add_co_ci_u32_e64 v40, null, s51, v40, s2                // 0000000039ec: d5207c28 000a5033
	global_load_d16_u8 v39, v[39:40], off                      // 0000000039f4: ee07807c 00000027 00000027
	s_wait_loadcnt 0x0                                         // 000000003a00: bfc00000
	v_cndmask_b16 v39.l, 0, v39.l, vcc_lo                      // 000000003a04: d65d0027 01aa4e80
	v_add_co_u32 v40, vcc_lo, v42, 5                           // 000000003a0c: d7006a28 02010b2a
	s_wait_alu depctr_va_vcc(0)                                // 000000003a14: bf88ff9d
	v_add_co_ci_u32_e64 v41, null, 0, v43, vcc_lo              // 000000003a18: d5207c29 01aa5680
	s_and_b32 vcc_lo, s0, s6                                   // 000000003a20: 8b6a0600
	v_and_b16 v39.l, 0xff, v39.l                               // 000000003a24: d7620027 02024eff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003a30: bf88ff9e
	v_dual_cndmask_b32 v40, 0, v40 :: v_dual_cndmask_b32 v41, 0, v41// 000000003a34: ca525080 28285280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000003a3c: bf870121
	v_add_co_u32 v40, s2, s50, v40                             // 000000003a40: d7000228 02025032
	s_wait_alu depctr_va_sdst(0)                               // 000000003a48: bf88f19f
	v_add_co_ci_u32_e64 v41, null, s51, v41, s2                // 000000003a4c: d5207c29 000a5233
	global_load_d16_hi_u8 v39, v[40:41], off                   // 000000003a54: ee08407c 00000027 00000028
	s_wait_loadcnt 0x0                                         // 000000003a60: bfc00000
	v_cndmask_b16 v39.h, 0, v39.h, vcc_lo                      // 000000003a64: d65d5027 01aa4e80
	v_add_co_u32 v40, vcc_lo, v42, 6                           // 000000003a6c: d7006a28 02010d2a
	s_wait_alu depctr_va_vcc(0)                                // 000000003a74: bf88ff9d
	v_add_co_ci_u32_e64 v41, null, 0, v43, vcc_lo              // 000000003a78: d5207c29 01aa5680
	s_and_b32 vcc_lo, s0, s7                                   // 000000003a80: 8b6a0700
	v_lshlrev_b16 v39.h, 8, v39.h op_sel:[0,1,1]               // 000000003a84: d7385027 02024e88
	s_wait_alu depctr_sa_sdst(0)                               // 000000003a8c: bf88ff9e
	v_dual_cndmask_b32 v40, 0, v40 :: v_dual_cndmask_b32 v41, 0, v41// 000000003a90: ca525080 28285280
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003a98: bf870112
	v_or_b16 v48.l, v39.l, v39.h op_sel:[0,1,0]                // 000000003a9c: d7631030 02024f27
	v_add_co_u32 v40, s2, s50, v40                             // 000000003aa4: d7000228 02025032
	s_wait_alu depctr_va_sdst(0)                               // 000000003aac: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000003ab0: bf870003
	v_add_co_ci_u32_e64 v41, null, s51, v41, s2                // 000000003ab4: d5207c29 000a5233
	global_load_d16_u8 v40, v[40:41], off                      // 000000003abc: ee07807c 00000028 00000028
	s_wait_loadcnt 0x0                                         // 000000003ac8: bfc00000
	v_cndmask_b16 v40.l, 0, v40.l, vcc_lo                      // 000000003acc: d65d0028 01aa5080
	v_add_co_u32 v41, vcc_lo, v42, 7                           // 000000003ad4: d7006a29 02010f2a
	s_wait_alu depctr_va_vcc(0)                                // 000000003adc: bf88ff9d
	v_add_co_ci_u32_e64 v42, null, 0, v43, vcc_lo              // 000000003ae0: d5207c2a 01aa5680
	s_and_b32 vcc_lo, s0, s8                                   // 000000003ae8: 8b6a0800
	v_and_b16 v40.l, 0xff, v40.l                               // 000000003aec: d7620028 020250ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003af8: bf88ff9e
	v_dual_cndmask_b32 v41, 0, v41 :: v_dual_cndmask_b32 v42, 0, v42// 000000003afc: ca525280 292a5480
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000003b04: bf870121
	v_add_co_u32 v41, s2, s50, v41                             // 000000003b08: d7000229 02025232
	s_wait_alu depctr_va_sdst(0)                               // 000000003b10: bf88f19f
	v_add_co_ci_u32_e64 v42, null, s51, v42, s2                // 000000003b14: d5207c2a 000a5433
	s_lshr_b64 s[2:3], s[12:13], 4                             // 000000003b1c: 8582840c
	s_add_nc_u64 s[12:13], s[12:13], 16                        // 000000003b20: a98c900c
	s_wait_alu depctr_sa_sdst(0)                               // 000000003b24: bf88ff9e
	s_mul_u64 s[2:3], s[2:3], s[38:39]                         // 000000003b28: aa822602
	global_load_d16_hi_u8 v40, v[41:42], off                   // 000000003b2c: ee08407c 00000028 00000029
	s_wait_alu depctr_sa_sdst(0)                               // 000000003b38: bf88ff9e
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000003b3c: 84828202
	s_wait_loadcnt 0x0                                         // 000000003b40: bfc00000
	v_cndmask_b16 v40.h, 0, v40.h, vcc_lo                      // 000000003b44: d65d5028 01aa5080
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003b4c: bf870091
	v_lshlrev_b16 v40.h, 8, v40.h op_sel:[0,1,1]               // 000000003b50: d7385028 02025088
	v_or_b16 v48.h, v40.l, v40.h op_sel:[0,1,1]                // 000000003b58: d7635030 02025128
	s_delay_alu instid0(valu_dep_1)                            // 000000003b60: bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[37:44], v[45:46], v[47:48], 0// 000000003b64: cc464025 1a025f2d
	v_add_co_u32 v45, vcc_lo, v0, s4                           // 000000003b6c: d7006a2d 02000900
	s_wait_alu depctr_va_vcc(0)                                // 000000003b74: bf88ff9d
	v_add_co_ci_u32_e64 v46, null, s5, v12, vcc_lo             // 000000003b78: d5207c2e 01aa1805
	global_load_b32 v47, v[45:46], off                         // 000000003b80: ee05007c 0000002f 0000002d
	s_wait_alu depctr_sa_sdst(0)                               // 000000003b8c: bf88ff9e
	v_add_co_u32 v45, vcc_lo, v13, s2                          // 000000003b90: d7006a2d 0200050d
	s_wait_alu depctr_va_vcc(0)                                // 000000003b98: bf88ff9d
	v_add_co_ci_u32_e64 v46, null, s3, v14, vcc_lo             // 000000003b9c: d5207c2e 01aa1c03
	v_cmp_lt_i64_e64 s2, s[12:13], s[42:43]                    // 000000003ba4: d4510002 0200540c
	global_load_b32 v48, v[45:46], off                         // 000000003bac: ee05007c 00000030 0000002d
	s_wait_loadcnt 0x0                                         // 000000003bb8: bfc00000
	v_mul_f32_e32 v45, v47, v48                                // 000000003bbc: 105a612f
	s_delay_alu instid0(valu_dep_1) | instskip(skip_3) | instid1(valu_dep_3)// 000000003bc0: bf8701c1
	v_mul_f32_e32 v37, v37, v45                                // 000000003bc4: 104a5b25
	v_add_co_u32 v45, vcc_lo, v21, s4                          // 000000003bc8: d7006a2d 02000915
	s_wait_alu depctr_va_vcc(0)                                // 000000003bd0: bf88ff9d
	v_add_co_ci_u32_e64 v46, null, s5, v22, vcc_lo             // 000000003bd4: d5207c2e 01aa2c05
	v_add_f32_e32 v1, v1, v37                                  // 000000003bdc: 06024b01
	global_load_b32 v37, v[45:46], off                         // 000000003be0: ee05007c 00000025 0000002d
	s_wait_loadcnt 0x0                                         // 000000003bec: bfc00000
	v_mul_f32_e32 v37, v48, v37                                // 000000003bf0: 104a4b30
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003bf4: bf870091
	v_mul_f32_e32 v37, v38, v37                                // 000000003bf8: 104a4b26
	v_add_f32_e32 v20, v20, v37                                // 000000003bfc: 06284b14
	v_add_co_u32 v37, vcc_lo, v25, s4                          // 000000003c00: d7006a25 02000919
	s_wait_alu depctr_va_vcc(0)                                // 000000003c08: bf88ff9d
	v_add_co_ci_u32_e64 v38, null, s5, v26, vcc_lo             // 000000003c0c: d5207c26 01aa3405
	global_load_b32 v37, v[37:38], off                         // 000000003c14: ee05007c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003c20: bfc00000
	v_mul_f32_e32 v37, v48, v37                                // 000000003c24: 104a4b30
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003c28: bf870091
	v_mul_f32_e32 v37, v39, v37                                // 000000003c2c: 104a4b27
	v_add_f32_e32 v19, v19, v37                                // 000000003c30: 06264b13
	v_add_co_u32 v37, vcc_lo, v27, s4                          // 000000003c34: d7006a25 0200091b
	s_wait_alu depctr_va_vcc(0)                                // 000000003c3c: bf88ff9d
	v_add_co_ci_u32_e64 v38, null, s5, v28, vcc_lo             // 000000003c40: d5207c26 01aa3805
	global_load_b32 v37, v[37:38], off                         // 000000003c48: ee05007c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003c54: bfc00000
	v_mul_f32_e32 v37, v48, v37                                // 000000003c58: 104a4b30
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003c5c: bf870091
	v_mul_f32_e32 v37, v40, v37                                // 000000003c60: 104a4b28
	v_add_f32_e32 v18, v18, v37                                // 000000003c64: 06244b12
	v_add_co_u32 v37, vcc_lo, v29, s4                          // 000000003c68: d7006a25 0200091d
	s_wait_alu depctr_va_vcc(0)                                // 000000003c70: bf88ff9d
	v_add_co_ci_u32_e64 v38, null, s5, v30, vcc_lo             // 000000003c74: d5207c26 01aa3c05
	global_load_b32 v37, v[37:38], off                         // 000000003c7c: ee05007c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003c88: bfc00000
	v_mul_f32_e32 v37, v48, v37                                // 000000003c8c: 104a4b30
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003c90: bf870091
	v_mul_f32_e32 v37, v41, v37                                // 000000003c94: 104a4b29
	v_add_f32_e32 v17, v17, v37                                // 000000003c98: 06224b11
	v_add_co_u32 v37, vcc_lo, v31, s4                          // 000000003c9c: d7006a25 0200091f
	s_wait_alu depctr_va_vcc(0)                                // 000000003ca4: bf88ff9d
	v_add_co_ci_u32_e64 v38, null, s5, v32, vcc_lo             // 000000003ca8: d5207c26 01aa4005
	global_load_b32 v37, v[37:38], off                         // 000000003cb0: ee05007c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003cbc: bfc00000
	v_mul_f32_e32 v37, v48, v37                                // 000000003cc0: 104a4b30
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003cc4: bf870091
	v_mul_f32_e32 v37, v42, v37                                // 000000003cc8: 104a4b2a
	v_add_f32_e32 v16, v16, v37                                // 000000003ccc: 06204b10
	v_add_co_u32 v37, vcc_lo, v33, s4                          // 000000003cd0: d7006a25 02000921
	s_wait_alu depctr_va_vcc(0)                                // 000000003cd8: bf88ff9d
	v_add_co_ci_u32_e64 v38, null, s5, v34, vcc_lo             // 000000003cdc: d5207c26 01aa4405
	global_load_b32 v37, v[37:38], off                         // 000000003ce4: ee05007c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003cf0: bfc00000
	v_mul_f32_e32 v37, v48, v37                                // 000000003cf4: 104a4b30
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003cf8: bf870091
	v_mul_f32_e32 v37, v43, v37                                // 000000003cfc: 104a4b2b
	v_add_f32_e32 v2, v2, v37                                  // 000000003d00: 06044b02
	v_add_co_u32 v37, vcc_lo, v35, s4                          // 000000003d04: d7006a25 02000923
	s_wait_alu depctr_va_vcc(0)                                // 000000003d0c: bf88ff9d
	v_add_co_ci_u32_e64 v38, null, s5, v36, vcc_lo             // 000000003d10: d5207c26 01aa4805
	s_and_b32 vcc_lo, exec_lo, s2                              // 000000003d18: 8b6a027e
	global_load_b32 v37, v[37:38], off                         // 000000003d1c: ee05007c 00000025 00000025
	s_wait_loadcnt 0x0                                         // 000000003d28: bfc00000
	v_mul_f32_e32 v37, v48, v37                                // 000000003d2c: 104a4b30
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003d30: bf870091
	v_mul_f32_e32 v37, v44, v37                                // 000000003d34: 104a4b2c
	v_add_f32_e32 v24, v24, v37                                // 000000003d38: 06304b18
	s_wait_alu depctr_sa_sdst(0)                               // 000000003d3c: bf88ff9e
	s_cbranch_vccnz 64932                                      // 000000003d40: bfa4fda4 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x18d4>
	v_mul_lo_u32 v0, s39, v7                                   // 000000003d44: d72c0000 02020e27
	v_mul_lo_u32 v9, s38, v8                                   // 000000003d4c: d72c0009 02021026
	v_mad_co_u64_u32 v[5:6], null, s38, v7, 0                  // 000000003d54: d6fe7c05 02020e26
	v_sub_co_u32 v7, vcc_lo, s36, v7                           // 000000003d5c: d7016a07 02020e24
	s_wait_alu depctr_va_vcc(0)                                // 000000003d64: bf88ff9d
	v_sub_co_ci_u32_e64 v8, null, s37, v8, vcc_lo              // 000000003d68: d5217c08 01aa1025
	v_cmp_gt_i64_e32 vcc_lo, s[38:39], v[3:4]                  // 000000003d70: 7ca80626
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 000000003d74: bf870194
	v_add3_u32 v6, v6, v9, v0                                  // 000000003d78: d6550006 04021306
	v_cmp_lt_i64_e64 s0, 0, v[7:8]                             // 000000003d80: d4510000 02020e80
	s_delay_alu instid0(valu_dep_2)                            // 000000003d88: bf870002
	v_lshlrev_b64_e32 v[5:6], 1, v[5:6]                        // 000000003d8c: 3e0a0a81
	s_and_b32 s0, s0, vcc_lo                                   // 000000003d90: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000003d94: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000003d98: be812000
	s_cbranch_execz 28                                         // 000000003d9c: bfa5001c <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2310>
	v_lshlrev_b64_e32 v[9:10], 1, v[3:4]                       // 000000003da0: 3e120681
	v_add_co_u32 v11, s0, s40, v5                              // 000000003da4: d700000b 02020a28
	v_bfe_u32 v0, v1, 16, 1                                    // 000000003dac: d6100000 02052101
	s_wait_alu depctr_va_sdst(0)                               // 000000003db4: bf88f19f
	v_add_co_ci_u32_e64 v12, null, s41, v6, s0                 // 000000003db8: d5207c0c 00020c29
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000003dc0: bf870193
	v_add_co_u32 v9, s0, v11, v9                               // 000000003dc4: d7000009 0202130b
	v_add3_u32 v0, v0, v1, 0x7fff                              // 000000003dcc: d6550000 03fe0300 00007fff
	v_or_b32_e32 v13, 0x400000, v1                             // 000000003dd8: 381a02ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000003de0: bf88f19f
	v_add_co_ci_u32_e64 v10, null, v12, v10, s0                // 000000003de4: d5207c0a 0002150c
	v_cmp_u_f32_e64 s0, v1, v1                                 // 000000003dec: d4180000 02020301
	s_wait_alu depctr_va_sdst(0)                               // 000000003df4: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000003df8: bf870001
	v_cndmask_b32_e64 v0, v0, v13, s0                          // 000000003dfc: d5010000 00021b00
	global_store_d16_hi_b16 v[9:10], v0, off                   // 000000003e04: ee09407c 00000000 00000009
	s_wait_alu depctr_sa_sdst(0)                               // 000000003e10: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000003e14: 8c7e017e
	v_cmp_lt_i64_e64 s0, 1, v[7:8]                             // 000000003e18: d4510000 02020e81
	s_and_b32 s0, s0, vcc_lo                                   // 000000003e20: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000003e24: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000003e28: be812000
	s_cbranch_execz 35                                         // 000000003e2c: bfa50023 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x23bc>
	v_add_co_u32 v9, s0, s40, v5                               // 000000003e30: d7000009 02020a28
	s_wait_alu depctr_va_sdst(0)                               // 000000003e38: bf88f19f
	v_add_co_ci_u32_e64 v10, null, s41, v6, s0                 // 000000003e3c: d5207c0a 00020c29
	s_lshl_b64 s[2:3], s[38:39], 1                             // 000000003e44: 84828126
	v_lshlrev_b64_e32 v[0:1], 1, v[3:4]                        // 000000003e48: 3e000681
	s_wait_alu depctr_sa_sdst(0)                               // 000000003e4c: bf88ff9e
	v_add_co_u32 v9, s0, v9, s2                                // 000000003e50: d7000009 02000509
	v_bfe_u32 v11, v20, 16, 1                                  // 000000003e58: d610000b 02052114
	s_wait_alu depctr_va_sdst(0)                               // 000000003e60: bf88f19f
	v_add_co_ci_u32_e64 v10, null, s3, v10, s0                 // 000000003e64: d5207c0a 00021403
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000003e6c: bf870193
	v_add_co_u32 v0, s0, v9, v0                                // 000000003e70: d7000000 02020109
	v_add3_u32 v11, v11, v20, 0x7fff                           // 000000003e78: d655000b 03fe290b 00007fff
	v_or_b32_e32 v12, 0x400000, v20                            // 000000003e84: 381828ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000003e8c: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v10, v1, s0                  // 000000003e90: d5207c01 0002030a
	v_cmp_u_f32_e64 s0, v20, v20                               // 000000003e98: d4180000 02022914
	s_wait_alu depctr_va_sdst(0)                               // 000000003ea0: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000003ea4: bf870001
	v_cndmask_b32_e64 v9, v11, v12, s0                         // 000000003ea8: d5010009 0002190b
	global_store_d16_hi_b16 v[0:1], v9, off                    // 000000003eb0: ee09407c 04800000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000003ebc: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000003ec0: 8c7e017e
	v_cmp_lt_i64_e64 s0, 2, v[7:8]                             // 000000003ec4: d4510000 02020e82
	s_and_b32 s0, s0, vcc_lo                                   // 000000003ecc: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000003ed0: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000003ed4: be812000
	s_cbranch_execz 34                                         // 000000003ed8: bfa50022 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2464>
	v_add_co_u32 v11, s0, s40, v5                              // 000000003edc: d700000b 02020a28
	v_bfe_u32 v0, v19, 16, 1                                   // 000000003ee4: d6100000 02052113
	s_wait_alu depctr_va_sdst(0)                               // 000000003eec: bf88f19f
	v_add_co_ci_u32_e64 v12, null, s41, v6, s0                 // 000000003ef0: d5207c0c 00020c29
	s_lshl_b64 s[2:3], s[38:39], 2                             // 000000003ef8: 84828226
	v_or_b32_e32 v9, 0x400000, v19                             // 000000003efc: 381226ff 00400000
	s_wait_alu depctr_sa_sdst(0)                               // 000000003f04: bf88ff9e
	v_add_co_u32 v11, s0, v11, s2                              // 000000003f08: d700000b 0200050b
	v_add3_u32 v10, v0, v19, 0x7fff                            // 000000003f10: d655000a 03fe2700 00007fff
	v_lshlrev_b64_e32 v[0:1], 1, v[3:4]                        // 000000003f1c: 3e000681
	s_wait_alu depctr_va_sdst(0)                               // 000000003f20: bf88f19f
	v_add_co_ci_u32_e64 v12, null, s3, v12, s0                 // 000000003f24: d5207c0c 00021803
	v_cmp_u_f32_e64 s0, v19, v19                               // 000000003f2c: d4180000 02022713
	s_wait_alu depctr_va_sdst(0)                               // 000000003f34: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000003f38: bf870001
	v_cndmask_b32_e64 v9, v10, v9, s0                          // 000000003f3c: d5010009 0002130a
	v_add_co_u32 v0, s0, v11, v0                               // 000000003f44: d7000000 0202010b
	s_wait_alu depctr_va_sdst(0)                               // 000000003f4c: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v12, v1, s0                  // 000000003f50: d5207c01 0002030c
	global_store_d16_hi_b16 v[0:1], v9, off                    // 000000003f58: ee09407c 04800000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000003f64: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000003f68: 8c7e017e
	v_cmp_lt_i64_e64 s0, 3, v[7:8]                             // 000000003f6c: d4510000 02020e83
	s_and_b32 s0, s0, vcc_lo                                   // 000000003f74: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000003f78: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000003f7c: be812000
	s_cbranch_execz 33                                         // 000000003f80: bfa50021 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2508>
	v_add_co_u32 v0, s0, s40, v5                               // 000000003f84: d7000000 02020a28
	s_wait_alu depctr_va_sdst(0)                               // 000000003f8c: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s41, v6, s0                  // 000000003f90: d5207c01 00020c29
	v_bfe_u32 v9, v18, 16, 1                                   // 000000003f98: d6100009 02052112
	v_or_b32_e32 v12, 0x400000, v18                            // 000000003fa0: 381824ff 00400000
	v_cmp_u_f32_e64 s0, v18, v18                               // 000000003fa8: d4180000 02022512
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000003fb0: bf870214
	v_mad_co_u64_u32 v[0:1], null, s38, 6, v[0:1]              // 000000003fb4: d6fe7c00 04010c26
	v_add3_u32 v13, v9, v18, 0x7fff                            // 000000003fbc: d655000d 03fe2509 00007fff
	s_wait_alu depctr_va_sdst(0)                               // 000000003fc8: bf88f19f
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_3)// 000000003fcc: bf870191
	v_cndmask_b32_e64 v12, v13, v12, s0                        // 000000003fd0: d501000c 0002190d
	v_mad_co_u64_u32 v[9:10], null, s39, 6, v[1:2]             // 000000003fd8: d6fe7c09 04050c27
	v_lshlrev_b64_e32 v[10:11], 1, v[3:4]                      // 000000003fe0: 3e140681
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000003fe4: bf870121
	v_add_co_u32 v0, s0, v0, v10                               // 000000003fe8: d7000000 02021500
	s_wait_alu depctr_va_sdst(0)                               // 000000003ff0: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v9, v11, s0                  // 000000003ff4: d5207c01 00021709
	global_store_d16_hi_b16 v[0:1], v12, off                   // 000000003ffc: ee09407c 06000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000004008: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 00000000400c: 8c7e017e
	v_cmp_lt_i64_e64 s0, 4, v[7:8]                             // 000000004010: d4510000 02020e84
	s_and_b32 s0, s0, vcc_lo                                   // 000000004018: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 00000000401c: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000004020: be812000
	s_cbranch_execz 34                                         // 000000004024: bfa50022 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x25b0>
	v_add_co_u32 v11, s0, s40, v5                              // 000000004028: d700000b 02020a28
	v_bfe_u32 v0, v17, 16, 1                                   // 000000004030: d6100000 02052111
	s_wait_alu depctr_va_sdst(0)                               // 000000004038: bf88f19f
	v_add_co_ci_u32_e64 v12, null, s41, v6, s0                 // 00000000403c: d5207c0c 00020c29
	s_lshl_b64 s[2:3], s[38:39], 3                             // 000000004044: 84828326
	v_or_b32_e32 v9, 0x400000, v17                             // 000000004048: 381222ff 00400000
	s_wait_alu depctr_sa_sdst(0)                               // 000000004050: bf88ff9e
	v_add_co_u32 v11, s0, v11, s2                              // 000000004054: d700000b 0200050b
	v_add3_u32 v10, v0, v17, 0x7fff                            // 00000000405c: d655000a 03fe2300 00007fff
	v_lshlrev_b64_e32 v[0:1], 1, v[3:4]                        // 000000004068: 3e000681
	s_wait_alu depctr_va_sdst(0)                               // 00000000406c: bf88f19f
	v_add_co_ci_u32_e64 v12, null, s3, v12, s0                 // 000000004070: d5207c0c 00021803
	v_cmp_u_f32_e64 s0, v17, v17                               // 000000004078: d4180000 02022311
	s_wait_alu depctr_va_sdst(0)                               // 000000004080: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004084: bf870001
	v_cndmask_b32_e64 v9, v10, v9, s0                          // 000000004088: d5010009 0002130a
	v_add_co_u32 v0, s0, v11, v0                               // 000000004090: d7000000 0202010b
	s_wait_alu depctr_va_sdst(0)                               // 000000004098: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v12, v1, s0                  // 00000000409c: d5207c01 0002030c
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000000040a4: ee09407c 04800000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 0000000040b0: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000040b4: 8c7e017e
	v_cmp_lt_i64_e64 s0, 5, v[7:8]                             // 0000000040b8: d4510000 02020e85
	s_and_b32 s0, s0, vcc_lo                                   // 0000000040c0: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 0000000040c4: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 0000000040c8: be812000
	s_cbranch_execz 33                                         // 0000000040cc: bfa50021 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2654>
	v_add_co_u32 v0, s0, s40, v5                               // 0000000040d0: d7000000 02020a28
	s_wait_alu depctr_va_sdst(0)                               // 0000000040d8: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s41, v6, s0                  // 0000000040dc: d5207c01 00020c29
	v_bfe_u32 v9, v16, 16, 1                                   // 0000000040e4: d6100009 02052110
	v_or_b32_e32 v12, 0x400000, v16                            // 0000000040ec: 381820ff 00400000
	v_cmp_u_f32_e64 s0, v16, v16                               // 0000000040f4: d4180000 02022110
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 0000000040fc: bf870214
	v_mad_co_u64_u32 v[0:1], null, s38, 10, v[0:1]             // 000000004100: d6fe7c00 04011426
	v_add3_u32 v13, v9, v16, 0x7fff                            // 000000004108: d655000d 03fe2109 00007fff
	s_wait_alu depctr_va_sdst(0)                               // 000000004114: bf88f19f
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_3)// 000000004118: bf870191
	v_cndmask_b32_e64 v12, v13, v12, s0                        // 00000000411c: d501000c 0002190d
	v_mad_co_u64_u32 v[9:10], null, s39, 10, v[1:2]            // 000000004124: d6fe7c09 04051427
	v_lshlrev_b64_e32 v[10:11], 1, v[3:4]                      // 00000000412c: 3e140681
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000004130: bf870121
	v_add_co_u32 v0, s0, v0, v10                               // 000000004134: d7000000 02021500
	s_wait_alu depctr_va_sdst(0)                               // 00000000413c: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v9, v11, s0                  // 000000004140: d5207c01 00021709
	global_store_d16_hi_b16 v[0:1], v12, off                   // 000000004148: ee09407c 06000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000004154: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000004158: 8c7e017e
	v_cmp_lt_i64_e64 s0, 6, v[7:8]                             // 00000000415c: d4510000 02020e86
	s_and_b32 s0, s0, vcc_lo                                   // 000000004164: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000004168: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 00000000416c: be812000
	s_cbranch_execz 33                                         // 000000004170: bfa50021 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x26f8>
	v_add_co_u32 v0, s0, s40, v5                               // 000000004174: d7000000 02020a28
	s_wait_alu depctr_va_sdst(0)                               // 00000000417c: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s41, v6, s0                  // 000000004180: d5207c01 00020c29
	v_bfe_u32 v9, v2, 16, 1                                    // 000000004188: d6100009 02052102
	v_or_b32_e32 v12, 0x400000, v2                             // 000000004190: 381804ff 00400000
	v_cmp_u_f32_e64 s0, v2, v2                                 // 000000004198: d4180000 02020502
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 0000000041a0: bf870214
	v_mad_co_u64_u32 v[0:1], null, s38, 12, v[0:1]             // 0000000041a4: d6fe7c00 04011826
	v_add3_u32 v13, v9, v2, 0x7fff                             // 0000000041ac: d655000d 03fe0509 00007fff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_3)// 0000000041b8: bf8701b2
	v_mad_co_u64_u32 v[9:10], null, s39, 12, v[1:2]            // 0000000041bc: d6fe7c09 04051827
	v_lshlrev_b64_e32 v[10:11], 1, v[3:4]                      // 0000000041c4: 3e140681
	s_wait_alu depctr_va_sdst(0)                               // 0000000041c8: bf88f19f
	v_cndmask_b32_e64 v2, v13, v12, s0                         // 0000000041cc: d5010002 0002190d
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_3)// 0000000041d4: bf8701a2
	v_add_co_u32 v0, s0, v0, v10                               // 0000000041d8: d7000000 02021500
	s_wait_alu depctr_va_sdst(0)                               // 0000000041e0: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v9, v11, s0                  // 0000000041e4: d5207c01 00021709
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000000041ec: ee09407c 01000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 0000000041f8: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000041fc: 8c7e017e
	v_cmp_lt_i64_e64 s0, 7, v[7:8]                             // 000000004200: d4510000 02020e87
	s_mov_b32 s1, 0                                            // 000000004208: be810080
	s_and_b32 s2, s0, vcc_lo                                   // 00000000420c: 8b026a00
	s_mov_b32 s0, 0                                            // 000000004210: be800080
	s_wait_alu depctr_sa_sdst(0)                               // 000000004214: bf88ff9e
	s_and_saveexec_b32 s3, s2                                  // 000000004218: be832002
	s_wait_alu depctr_sa_sdst(0)                               // 00000000421c: bf88ff9e
	s_xor_b32 s2, exec_lo, s3                                  // 000000004220: 8d02037e
	v_add_co_u32 v0, vcc_lo, s40, v5                           // 000000004224: d7006a00 02020a28
	s_wait_alu depctr_va_vcc(0)                                // 00000000422c: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s41, v6, vcc_lo              // 000000004230: d5207c01 01aa0c29
	s_mov_b32 s0, exec_lo                                      // 000000004238: be80007e
	v_mad_co_u64_u32 v[0:1], null, s38, 14, v[0:1]             // 00000000423c: d6fe7c00 04011c26
	s_delay_alu instid0(valu_dep_1)                            // 000000004244: bf870001
	v_mad_co_u64_u32 v[1:2], null, s39, 14, v[1:2]             // 000000004248: d6fe7c01 04051c27
	s_wait_alu depctr_sa_sdst(0)                               // 000000004250: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s2                              // 000000004254: 8c7e027e
	s_delay_alu instid0(salu_cycle_1)                          // 000000004258: bf870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000000425c: 8b6a017e
	s_wait_alu depctr_sa_sdst(0)                               // 000000004260: bf88ff9e
	s_cbranch_vccz 1058                                        // 000000004264: bfa30422 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x37f0>
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000004268: ca100080 18180080
	s_and_b32 s0, s35, exec_lo                                 // 000000004270: 8b007e23
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v27, 0              // 000000004274: ca100080 001a0080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 00000000427c: ca100080 02000080
	v_mov_b32_e32 v26, 0                                       // 000000004284: 7e340280
	v_mov_b32_e32 v28, 0                                       // 000000004288: 7e380280
	s_cselect_b32 s0, 1, 0                                     // 00000000428c: 98008081
	v_cmp_gt_i64_e32 vcc_lo, s[38:39], v[3:4]                  // 000000004290: 7ca80626
	s_wait_alu depctr_sa_sdst(0)                               // 000000004294: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000004298: bf078100
	s_cbranch_scc1 409                                         // 00000000429c: bfa20199 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2e04>
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v0, 3, v15      // 0000000042a0: ca220080 01001e83
	s_wait_alu depctr_va_vcc(0)                                // 0000000042a8: bf88ff9d
	v_dual_cndmask_b32 v6, 0, v4 :: v_dual_cndmask_b32 v5, 0, v3// 0000000042ac: ca520880 06040680
	v_dual_mov_b32 v8, s55 :: v_dual_mov_b32 v9, s55           // 0000000042b4: ca100037 08080037
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 0000000042bc: bf870223
	v_or_b32_e32 v7, s54, v0                                   // 0000000042c0: 380e0036
	v_mov_b32_e32 v14, s55                                     // 0000000042c4: 7e1c0237
	v_lshlrev_b64_e32 v[5:6], 2, v[5:6]                        // 0000000042c8: 3e0a0a82
	v_mov_b32_e32 v12, s55                                     // 0000000042cc: 7e180237
	v_mov_b32_e32 v10, s55                                     // 0000000042d0: 7e140237
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[7:8]                  // 0000000042d4: 7ca80e24
	v_or_b32_e32 v8, 1, v7                                     // 0000000042d8: 38100e81
	v_or_b32_e32 v13, 4, v7                                    // 0000000042dc: 381a0e84
	v_add_co_u32 v5, s0, s60, v5                               // 0000000042e0: d7000005 02020a3c
	s_wait_alu depctr_va_sdst(0)                               // 0000000042e8: bf88f19f
	v_add_co_ci_u32_e64 v6, null, s61, v6, s0                  // 0000000042ec: d5207c06 00020c3d
	v_cmp_gt_i64_e64 s0, s[36:37], v[8:9]                      // 0000000042f4: d4540000 02021024
	v_or_b32_e32 v11, 3, v7                                    // 0000000042fc: 38160e83
	v_or_b32_e32 v9, 2, v7                                     // 000000004300: 38120e82
	s_wait_alu depctr_va_vcc(0)                                // 000000004304: bf88ff9d
	v_cndmask_b32_e32 v2, 0, v7, vcc_lo                        // 000000004308: 02040e80
	v_cndmask_b32_e64 v16, 0, s55, vcc_lo                      // 00000000430c: d5010010 01a86e80
	s_mov_b64 s[4:5], 0                                        // 000000004314: be840180
	s_wait_alu depctr_va_sdst(0)                               // 000000004318: bf88f19f
	v_cndmask_b32_e64 v17, 0, v8, s0                           // 00000000431c: d5010011 00021080
	v_cndmask_b32_e64 v18, 0, s55, s0                          // 000000004324: d5010012 00006e80
	v_cmp_gt_i64_e64 s0, s[36:37], v[13:14]                    // 00000000432c: d4540000 02021a24
	v_or_b32_e32 v8, 5, v7                                     // 000000004334: 38100e85
	s_mov_b64 s[6:7], s[52:53]                                 // 000000004338: be860134
	v_mul_lo_u32 v34, v18, s58                                 // 00000000433c: d72c0022 02007512
	v_cndmask_b32_e64 v29, 0, v13, s0                          // 000000004344: d501001d 00021a80
	v_mov_b32_e32 v13, s55                                     // 00000000434c: 7e1a0237
	v_cmp_gt_i64_e64 s1, s[36:37], v[11:12]                    // 000000004350: d4540001 02021624
	v_cndmask_b32_e64 v32, 0, s55, s0                          // 000000004358: d5010020 00006e80
	v_or_b32_e32 v12, 7, v7                                    // 000000004360: 38180e87
	s_wait_alu depctr_va_sdst(0)                               // 000000004364: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000004368: bf870003
	v_cndmask_b32_e64 v26, 0, v11, s1                          // 00000000436c: d501001a 00061680
	v_mov_b32_e32 v11, s55                                     // 000000004374: 7e160237
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[9:10]                 // 000000004378: 7ca81224
	v_or_b32_e32 v10, 6, v7                                    // 00000000437c: 38140e86
	v_add_co_u32 v7, s0, s56, v23                              // 000000004380: d7000007 02022e38
	s_wait_alu depctr_va_sdst(0)                               // 000000004388: bf88f19f
	v_add_co_ci_u32_e64 v19, null, s57, 0, s0                  // 00000000438c: d5207c13 00010039
	s_wait_alu depctr_va_vcc(0)                                // 000000004394: bf88ff9d
	v_dual_cndmask_b32 v20, 0, v9 :: v_dual_mov_b32 v9, s55    // 000000004398: ca501280 14080037
	v_cndmask_b32_e64 v22, 0, s55, vcc_lo                      // 0000000043a0: d5010016 01a86e80
	v_cndmask_b32_e64 v28, 0, s55, s1                          // 0000000043a8: d501001c 00046e80
	v_cmp_gt_i64_e64 s1, s[36:37], v[12:13]                    // 0000000043b0: d4540001 02021824
	v_mad_co_u64_u32 v[13:14], null, s46, v7, v[0:1]           // 0000000043b8: d6fe7c0d 04020e2e
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[8:9]                  // 0000000043c0: 7ca81024
	v_mul_lo_u32 v9, s46, v19                                  // 0000000043c4: d72c0009 0202262e
	v_mul_lo_u32 v7, s47, v7                                   // 0000000043cc: d72c0007 02020e2f
	v_cmp_gt_i64_e64 s0, s[36:37], v[10:11]                    // 0000000043d4: d4540000 02021424
	v_mul_lo_u32 v33, v2, s59                                  // 0000000043dc: d72c0021 02007702
	s_wait_alu depctr_va_sdst(0)                               // 0000000043e4: bf88f19f
	v_cndmask_b32_e64 v19, 0, v12, s1                          // 0000000043e8: d5010013 00061880
	s_wait_alu depctr_va_vcc(0)                                // 0000000043f0: bf88ff9d
	v_cndmask_b32_e32 v24, 0, v8, vcc_lo                       // 0000000043f4: 02301080
	v_cndmask_b32_e64 v30, 0, s55, s1                          // 0000000043f8: d501001e 00046e80
	v_cndmask_b32_e64 v27, 0, s55, vcc_lo                      // 000000004400: d501001b 01a86e80
	v_cndmask_b32_e64 v21, 0, v10, s0                          // 000000004408: d5010015 00021480
	v_add3_u32 v8, v7, v14, v9                                 // 000000004410: d6550008 04261d07
	v_add_co_u32 v14, s2, s54, v23                             // 000000004418: d700020e 02022e36
	v_mad_co_u64_u32 v[9:10], null, v2, s58, 0                 // 000000004420: d6fe7c09 02007502
	v_mul_lo_u32 v2, v16, s58                                  // 000000004428: d72c0002 02007510
	s_wait_alu depctr_va_sdst(0)                               // 000000004430: bf88f19f
	v_add_co_ci_u32_e64 v31, null, s55, 0, s2                  // 000000004434: d5207c1f 00090037
	v_mad_co_u64_u32 v[11:12], null, s46, v14, v[0:1]          // 00000000443c: d6fe7c0b 04021c2e
	v_add_co_u32 v7, vcc_lo, s50, v13                          // 000000004444: d7006a07 02021a32
	s_delay_alu instid0(valu_dep_3)                            // 00000000444c: bf870003
	v_mul_lo_u32 v0, s46, v31                                  // 000000004450: d72c0000 02023e2e
	v_mul_lo_u32 v31, s47, v14                                 // 000000004458: d72c001f 02021c2f
	v_add3_u32 v10, v10, v33, v2                               // 000000004460: d655000a 040a430a
	v_mul_lo_u32 v2, v19, s59                                  // 000000004468: d72c0002 02007713
	v_mad_co_u64_u32 v[13:14], null, v19, s58, 0               // 000000004470: d6fe7c0d 02007513
	v_mul_lo_u32 v30, v30, s58                                 // 000000004478: d72c001e 0200751e
	v_cndmask_b32_e64 v25, 0, s55, s0                          // 000000004480: d5010019 00006e80
	v_lshlrev_b64_e32 v[18:19], 2, v[9:10]                     // 000000004488: 3e241282
	s_wait_alu depctr_va_vcc(0)                                // 00000000448c: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s51, v8, vcc_lo              // 000000004490: d5207c08 01aa1033
	v_add3_u32 v0, v31, v12, v0                                // 000000004498: d6550000 0402191f
	v_add_co_u32 v9, vcc_lo, s48, v11                          // 0000000044a0: d7006a09 02021630
	v_add3_u32 v14, v14, v2, v30                               // 0000000044a8: d655000e 047a050e
	v_mul_lo_u32 v2, v25, s58                                  // 0000000044b0: d72c0002 02007519
	s_wait_alu depctr_va_vcc(0)                                // 0000000044b8: bf88ff9d
	v_add_co_ci_u32_e64 v10, null, s49, v0, vcc_lo             // 0000000044bc: d5207c0a 01aa0031
	v_add_co_u32 v11, vcc_lo, v18, 4                           // 0000000044c4: d7006a0b 02010912
	s_wait_alu depctr_va_vcc(0)                                // 0000000044cc: bf88ff9d
	v_add_co_ci_u32_e64 v12, null, 0, v19, vcc_lo              // 0000000044d0: d5207c0c 01aa2680
	v_mul_lo_u32 v0, v21, s59                                  // 0000000044d8: d72c0000 02007715
	v_mad_co_u64_u32 v[18:19], null, v21, s58, 0               // 0000000044e0: d6fe7c12 02007515
	v_mul_lo_u32 v25, v20, s59                                 // 0000000044e8: d72c0019 02007714
	v_mad_co_u64_u32 v[20:21], null, v20, s58, 0               // 0000000044f0: d6fe7c14 02007514
	v_mul_lo_u32 v22, v22, s58                                 // 0000000044f8: d72c0016 02007516
	v_mul_lo_u32 v33, v17, s59                                 // 000000004500: d72c0021 02007711
	v_mad_co_u64_u32 v[16:17], null, v17, s58, 0               // 000000004508: d6fe7c10 02007511
	v_lshlrev_b64_e32 v[13:14], 2, v[13:14]                    // 000000004510: 3e1a1a82
	v_mul_lo_u32 v28, v28, s58                                 // 000000004514: d72c001c 0200751c
	v_add3_u32 v19, v19, v0, v2                                // 00000000451c: d6550013 040a0113
	v_mul_lo_u32 v0, v24, s59                                  // 000000004524: d72c0000 02007718
	v_mul_lo_u32 v2, v27, s58                                  // 00000000452c: d72c0002 0200751b
	v_add3_u32 v21, v21, v25, v22                              // 000000004534: d6550015 045a3315
	v_mad_co_u64_u32 v[24:25], null, v24, s58, 0               // 00000000453c: d6fe7c18 02007518
	v_add3_u32 v17, v17, v33, v34                              // 000000004544: d6550011 048a4311
	v_mul_lo_u32 v22, v26, s59                                 // 00000000454c: d72c0016 0200771a
	v_mad_co_u64_u32 v[26:27], null, v26, s58, 0               // 000000004554: d6fe7c1a 0200751a
	v_mad_co_u64_u32 v[30:31], null, v29, s58, 0               // 00000000455c: d6fe7c1e 0200751d
	v_lshlrev_b64_e32 v[18:19], 2, v[18:19]                    // 000000004564: 3e242482
	v_lshlrev_b64_e32 v[16:17], 2, v[16:17]                    // 000000004568: 3e202082
	v_add_co_u32 v13, vcc_lo, v13, 4                           // 00000000456c: d7006a0d 0201090d
	v_add3_u32 v25, v25, v0, v2                                // 000000004574: d6550019 040a0119
	v_mul_lo_u32 v0, v29, s59                                  // 00000000457c: d72c0000 0200771d
	v_mul_lo_u32 v2, v32, s58                                  // 000000004584: d72c0002 02007520
	v_lshlrev_b64_e32 v[20:21], 2, v[20:21]                    // 00000000458c: 3e282882
	s_wait_alu depctr_va_vcc(0)                                // 000000004590: bf88ff9d
	v_add_co_ci_u32_e64 v14, null, 0, v14, vcc_lo              // 000000004594: d5207c0e 01aa1c80
	v_add_co_u32 v16, vcc_lo, v16, 4                           // 00000000459c: d7006a10 02010910
	v_lshlrev_b64_e32 v[24:25], 2, v[24:25]                    // 0000000045a4: 3e303082
	v_add3_u32 v27, v27, v22, v28                              // 0000000045a8: d655001b 04722d1b
	s_wait_alu depctr_va_vcc(0)                                // 0000000045b0: bf88ff9d
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 0000000045b4: d5207c11 01aa2280
	v_add_co_u32 v18, vcc_lo, v18, 4                           // 0000000045bc: d7006a12 02010912
	v_add3_u32 v31, v31, v0, v2                                // 0000000045c4: d655001f 040a011f
	s_wait_alu depctr_va_vcc(0)                                // 0000000045cc: bf88ff9d
	v_add_co_ci_u32_e64 v19, null, 0, v19, vcc_lo              // 0000000045d0: d5207c13 01aa2680
	v_add_co_u32 v20, vcc_lo, v20, 4                           // 0000000045d8: d7006a14 02010914
	s_wait_alu depctr_va_vcc(0)                                // 0000000045e0: bf88ff9d
	v_add_co_ci_u32_e64 v21, null, 0, v21, vcc_lo              // 0000000045e4: d5207c15 01aa2a80
	v_lshlrev_b64_e32 v[26:27], 2, v[26:27]                    // 0000000045ec: 3e343482
	v_add_co_u32 v22, vcc_lo, v24, 4                           // 0000000045f0: d7006a16 02010918
	s_wait_alu depctr_va_vcc(0)                                // 0000000045f8: bf88ff9d
	v_add_co_ci_u32_e64 v29, null, 0, v25, vcc_lo              // 0000000045fc: d5207c1d 01aa3280
	v_lshlrev_b64_e32 v[24:25], 2, v[30:31]                    // 000000004604: 3e303c82
	s_delay_alu instid0(valu_dep_4) | instskip(skip_3) | instid1(valu_dep_4)// 000000004608: bf870244
	v_add_co_u32 v30, vcc_lo, v26, 4                           // 00000000460c: d7006a1e 0201091a
	s_wait_alu depctr_va_vcc(0)                                // 000000004614: bf88ff9d
	v_add_co_ci_u32_e64 v31, null, 0, v27, vcc_lo              // 000000004618: d5207c1f 01aa3680
	v_mov_b32_e32 v28, v1                                      // 000000004620: 7e380301
	v_add_co_u32 v32, vcc_lo, v24, 4                           // 000000004624: d7006a20 02010918
	s_wait_alu depctr_va_vcc(0)                                // 00000000462c: bf88ff9d
	v_add_co_ci_u32_e64 v33, null, 0, v25, vcc_lo              // 000000004630: d5207c21 01aa3280
	v_dual_mov_b32 v27, v1 :: v_dual_mov_b32 v26, v1           // 000000004638: ca100101 1b1a0101
	v_dual_mov_b32 v25, v1 :: v_dual_mov_b32 v2, v1            // 000000004640: ca100101 19020101
	v_mov_b32_e32 v0, v1                                       // 000000004648: 7e000301
	v_mov_b32_e32 v24, v1                                      // 00000000464c: 7e300301
	s_lshl_b64 s[0:1], s[38:39], 2                             // 000000004650: 84808226
	s_lshl_b64 s[2:3], s[38:39], 3                             // 000000004654: 84828326
	s_wait_alu depctr_sa_sdst(0)                               // 000000004658: bf88ff9e
	v_add_co_u32 v34, vcc_lo, s6, v11                          // 00000000465c: d7006a22 02021606
	s_wait_alu depctr_va_vcc(0)                                // 000000004664: bf88ff9d
	v_add_co_ci_u32_e64 v35, null, s7, v12, vcc_lo             // 000000004668: d5207c23 01aa1807
	v_add_co_u32 v36, vcc_lo, s6, v16                          // 000000004670: d7006a24 02022006
	s_wait_alu depctr_va_vcc(0)                                // 000000004678: bf88ff9d
	v_add_co_ci_u32_e64 v37, null, s7, v17, vcc_lo             // 00000000467c: d5207c25 01aa2207
	v_add_co_u32 v38, vcc_lo, s6, v20                          // 000000004684: d7006a26 02022806
	s_wait_alu depctr_va_vcc(0)                                // 00000000468c: bf88ff9d
	v_add_co_ci_u32_e64 v39, null, s7, v21, vcc_lo             // 000000004690: d5207c27 01aa2a07
	v_add_co_u32 v40, vcc_lo, s6, v30                          // 000000004698: d7006a28 02023c06
	s_wait_alu depctr_va_vcc(0)                                // 0000000046a0: bf88ff9d
	v_add_co_ci_u32_e64 v41, null, s7, v31, vcc_lo             // 0000000046a4: d5207c29 01aa3e07
	v_add_co_u32 v42, vcc_lo, s6, v32                          // 0000000046ac: d7006a2a 02024006
	s_wait_alu depctr_va_vcc(0)                                // 0000000046b4: bf88ff9d
	v_add_co_ci_u32_e64 v43, null, s7, v33, vcc_lo             // 0000000046b8: d5207c2b 01aa4207
	v_add_co_u32 v44, vcc_lo, s6, v22                          // 0000000046c0: d7006a2c 02022c06
	s_wait_alu depctr_va_vcc(0)                                // 0000000046c8: bf88ff9d
	v_add_co_ci_u32_e64 v45, null, s7, v29, vcc_lo             // 0000000046cc: d5207c2d 01aa3a07
	v_add_co_u32 v46, vcc_lo, s6, v18                          // 0000000046d4: d7006a2e 02022406
	s_wait_alu depctr_va_vcc(0)                                // 0000000046dc: bf88ff9d
	v_add_co_ci_u32_e64 v47, null, s7, v19, vcc_lo             // 0000000046e0: d5207c2f 01aa2607
	v_add_co_u32 v48, vcc_lo, s6, v13                          // 0000000046e8: d7006a30 02021a06
	s_wait_alu depctr_va_vcc(0)                                // 0000000046f0: bf88ff9d
	v_add_co_ci_u32_e64 v49, null, s7, v14, vcc_lo             // 0000000046f4: d5207c31 01aa1c07
	v_add_co_u32 v58, vcc_lo, v5, s0                           // 0000000046fc: d7006a3a 02000105
	global_load_b32 v76, v[5:6], off                           // 000000004704: ee05007c 0000004c 00000005
	s_clause 0x1                                               // 000000004710: bf850001
	global_load_b64 v[50:51], v[9:10], off                     // 000000004714: ee05407c 00000032 00000009
	global_load_b64 v[52:53], v[9:10], off offset:16           // 000000004720: ee05407c 00000034 00001009
	s_clause 0x1                                               // 00000000472c: bf850001
	global_load_b64 v[54:55], v[7:8], off                      // 000000004730: ee05407c 00000036 00000007
	global_load_b64 v[56:57], v[7:8], off offset:16            // 00000000473c: ee05407c 00000038 00001007
	s_wait_alu depctr_va_vcc(0)                                // 000000004748: bf88ff9d
	v_add_co_ci_u32_e64 v59, null, s1, v6, vcc_lo              // 00000000474c: d5207c3b 01aa0c01
	s_clause 0x7                                               // 000000004754: bf850007
	global_load_b64 v[60:61], v[34:35], off offset:-4          // 000000004758: ee05407c 0000003c fffffc22
	global_load_b64 v[62:63], v[36:37], off offset:-4          // 000000004764: ee05407c 0000003e fffffc24
	global_load_b64 v[64:65], v[38:39], off offset:-4          // 000000004770: ee05407c 00000040 fffffc26
	global_load_b64 v[66:67], v[40:41], off offset:-4          // 00000000477c: ee05407c 00000042 fffffc28
	global_load_b64 v[68:69], v[42:43], off offset:-4          // 000000004788: ee05407c 00000044 fffffc2a
	global_load_b64 v[70:71], v[44:45], off offset:-4          // 000000004794: ee05407c 00000046 fffffc2c
	global_load_b64 v[72:73], v[46:47], off offset:-4          // 0000000047a0: ee05407c 00000048 fffffc2e
	global_load_b64 v[74:75], v[48:49], off offset:-4          // 0000000047ac: ee05407c 0000004a fffffc30
	global_load_b32 v58, v[58:59], off                         // 0000000047b8: ee05007c 0000003a 0000003a
	v_add_co_u32 v5, vcc_lo, v5, s2                            // 0000000047c4: d7006a05 02000505
	s_add_nc_u64 s[4:5], s[4:5], 32                            // 0000000047cc: a984a004
	s_wait_alu depctr_va_vcc(0)                                // 0000000047d0: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000000047d4: d5207c06 01aa0c03
	v_add_co_u32 v7, vcc_lo, v7, 32                            // 0000000047dc: d7006a07 02014107
	s_wait_alu depctr_sa_sdst(0)                               // 0000000047e4: bf88ff9e
	v_cmp_ge_i64_e64 s8, s[4:5], s[44:45]                      // 0000000047e8: d4560008 02005804
	s_wait_alu depctr_va_vcc(0)                                // 0000000047f0: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 0000000047f4: d5207c08 01aa1080
	v_add_co_u32 v9, vcc_lo, v9, 32                            // 0000000047fc: d7006a09 02014109
	s_wait_alu depctr_va_vcc(0)                                // 000000004804: bf88ff9d
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000004808: d5207c0a 01aa1480
	s_and_b32 vcc_lo, exec_lo, s8                              // 000000004810: 8b6a087e
	s_add_nc_u64 s[6:7], s[6:7], 8                             // 000000004814: a9868806
	s_wait_loadcnt 0xa                                         // 000000004818: bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[34:41], v[50:51], v[54:55], 0// 00000000481c: cc464022 1a026d32
	s_wait_loadcnt 0x9                                         // 000000004824: bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[52:53], v[56:57], 0// 000000004828: cc46402a 1a027134
	s_wait_loadcnt 0x0                                         // 000000004830: bfc00000
	v_dual_mul_f32 v50, v60, v76 :: v_dual_mul_f32 v59, v61, v58// 000000004834: c8c6993c 323a753d
	v_dual_mul_f32 v51, v76, v62 :: v_dual_mul_f32 v52, v76, v64// 00000000483c: c8c67d4c 3334814c
	v_dual_mul_f32 v53, v76, v66 :: v_dual_mul_f32 v54, v76, v68// 000000004844: c8c6854c 3536894c
	v_dual_mul_f32 v55, v76, v70 :: v_dual_mul_f32 v56, v76, v72// 00000000484c: c8c68d4c 3738914c
	v_dual_mul_f32 v57, v76, v74 :: v_dual_mul_f32 v60, v58, v63// 000000004854: c8c6954c 393c7f3a
	v_dual_mul_f32 v61, v58, v65 :: v_dual_mul_f32 v62, v58, v67// 00000000485c: c8c6833a 3d3e873a
	v_dual_mul_f32 v63, v58, v69 :: v_dual_mul_f32 v64, v58, v71// 000000004864: c8c68b3a 3f408f3a
	v_dual_mul_f32 v65, v58, v73 :: v_dual_mul_f32 v58, v58, v75// 00000000486c: c8c6933a 413a973a
	v_dual_mul_f32 v34, v34, v50 :: v_dual_mul_f32 v35, v35, v51// 000000004874: c8c66522 22226723
	v_dual_mul_f32 v36, v36, v52 :: v_dual_mul_f32 v37, v37, v53// 00000000487c: c8c66924 24246b25
	v_dual_mul_f32 v38, v38, v54 :: v_dual_mul_f32 v39, v39, v55// 000000004884: c8c66d26 26266f27
	v_dual_mul_f32 v40, v40, v56 :: v_dual_mul_f32 v41, v41, v57// 00000000488c: c8c67128 28287329
	v_dual_mul_f32 v42, v42, v59 :: v_dual_mul_f32 v43, v43, v60// 000000004894: c8c6772a 2a2a792b
	v_dual_mul_f32 v44, v44, v61 :: v_dual_mul_f32 v45, v45, v62// 00000000489c: c8c67b2c 2c2c7d2d
	v_dual_mul_f32 v46, v46, v63 :: v_dual_mul_f32 v47, v47, v64// 0000000048a4: c8c67f2e 2e2e812f
	v_dual_mul_f32 v48, v48, v65 :: v_dual_mul_f32 v49, v49, v58// 0000000048ac: c8c68330 30307531
	v_dual_add_f32 v1, v1, v34 :: v_dual_add_f32 v28, v28, v35 // 0000000048b4: c9084501 011c471c
	v_dual_add_f32 v27, v27, v36 :: v_dual_add_f32 v26, v26, v37// 0000000048bc: c908491b 1b1a4b1a
	v_dual_add_f32 v25, v25, v38 :: v_dual_add_f32 v2, v2, v39 // 0000000048c4: c9084d19 19024f02
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000048cc: bf870193
	v_dual_add_f32 v0, v0, v40 :: v_dual_add_f32 v1, v1, v42   // 0000000048d0: c9085100 00005501
	v_dual_add_f32 v24, v24, v41 :: v_dual_add_f32 v27, v27, v44// 0000000048d8: c9085318 181a591b
	s_delay_alu instid0(valu_dep_3)                            // 0000000048e0: bf870003
	v_dual_add_f32 v28, v28, v43 :: v_dual_add_f32 v25, v25, v46// 0000000048e4: c908571c 1c185d19
	v_add_f32_e32 v26, v26, v45                                // 0000000048ec: 06345b1a
	v_add_f32_e32 v2, v2, v47                                  // 0000000048f0: 06045f02
	v_add_f32_e32 v0, v0, v48                                  // 0000000048f4: 06006100
	v_add_f32_e32 v24, v24, v49                                // 0000000048f8: 06306318
	s_wait_alu depctr_sa_sdst(0)                               // 0000000048fc: bf88ff9e
	s_cbranch_vccz 65365                                       // 000000004900: bfa3ff55 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2b58>
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v21, 3, v15    // 000000004904: ca220080 16141e83
	v_cmp_lt_i64_e64 s0, s[44:45], s[42:43]                    // 00000000490c: d4510000 0200542c
	s_delay_alu instid0(valu_dep_2)                            // 000000004914: bf870002
	v_or_b32_e32 v5, s54, v21                                  // 000000004918: 380a2a36
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000000491c: 8b6a007e
	s_wait_alu depctr_sa_sdst(0)                               // 000000004920: bf88ff9e
	s_cbranch_vccnz 17                                         // 000000004924: bfa40011 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2e6c>
	v_mov_b32_e32 v6, s55                                      // 000000004928: 7e0c0237
	v_or_b32_e32 v11, 1, v5                                    // 00000000492c: 38160a81
	v_or_b32_e32 v9, 2, v5                                     // 000000004930: 38120a82
	v_or_b32_e32 v7, 3, v5                                     // 000000004934: 380e0a83
	v_mov_b32_e32 v12, s55                                     // 000000004938: 7e180237
	v_mov_b32_e32 v10, s55                                     // 00000000493c: 7e140237
	v_mov_b32_e32 v8, s55                                      // 000000004940: 7e100237
	v_or_b32_e32 v15, 4, v5                                    // 000000004944: 381e0a84
	v_mov_b32_e32 v16, s55                                     // 000000004948: 7e200237
	v_or_b32_e32 v13, 5, v5                                    // 00000000494c: 381a0a85
	v_mov_b32_e32 v14, s55                                     // 000000004950: 7e1c0237
	v_or_b32_e32 v17, 6, v5                                    // 000000004954: 38220a86
	v_mov_b32_e32 v18, s55                                     // 000000004958: 7e240237
	v_or_b32_e32 v19, 7, v5                                    // 00000000495c: 38260a87
	v_mov_b32_e32 v20, s55                                     // 000000004960: 7e280237
	s_mov_b32 s0, 0                                            // 000000004964: be800080
	s_branch 1                                                 // 000000004968: bfa00001 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x2e70>
	s_mov_b32 s0, -1                                           // 00000000496c: be8000c1
	s_wait_alu depctr_sa_sdst(0)                               // 000000004970: bf88ff9e
	s_and_b32 s0, s0, exec_lo                                  // 000000004974: 8b007e00
	s_cselect_b32 s0, 1, 0                                     // 000000004978: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 00000000497c: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000004980: bf078100
	s_cbranch_scc1 355                                         // 000000004984: bfa20163 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x3414>
	v_mov_b32_e32 v6, s55                                      // 000000004988: 7e0c0237
	v_or_b32_e32 v11, 1, v5                                    // 00000000498c: 38160a81
	v_or_b32_e32 v9, 2, v5                                     // 000000004990: 38120a82
	v_cmp_gt_i64_e64 s0, s[38:39], v[3:4]                      // 000000004994: d4540000 02020626
	v_or_b32_e32 v7, 3, v5                                     // 00000000499c: 380e0a83
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[5:6]                  // 0000000049a0: 7ca80a24
	s_wait_alu depctr_va_sdst(0)                               // 0000000049a4: bf88f19f
	s_delay_alu instid0(valu_dep_3) | instskip(skip_4) | instid1(valu_dep_3)// 0000000049a8: bf8701d3
	v_cndmask_b32_e64 v14, 0, v4, s0                           // 0000000049ac: d501000e 00020880
	s_wait_alu depctr_va_vcc(0)                                // 0000000049b4: bf88ff9d
	v_dual_cndmask_b32 v13, 0, v5 :: v_dual_mov_b32 v12, s55   // 0000000049b8: ca500a80 0d0c0037
	v_cndmask_b32_e32 v8, 0, v6, vcc_lo                        // 0000000049c0: 02100c80
	v_mov_b32_e32 v10, s55                                     // 0000000049c4: 7e140237
	v_mul_lo_u32 v18, s59, v13                                 // 0000000049c8: d72c0012 02021a3b
	s_delay_alu instid0(valu_dep_4)                            // 0000000049d0: bf870004
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[11:12]                // 0000000049d4: 7ca81624
	v_mad_co_u64_u32 v[15:16], null, s58, v13, 0               // 0000000049d8: d6fe7c0f 02021a3a
	v_cndmask_b32_e64 v13, 0, v3, s0                           // 0000000049e0: d501000d 00020680
	s_wait_alu depctr_va_vcc(0)                                // 0000000049e8: bf88ff9d
	v_dual_cndmask_b32 v19, 0, v6 :: v_dual_cndmask_b32 v20, 0, v11// 0000000049ec: ca520c80 13141680
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[9:10]                 // 0000000049f4: 7ca81224
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000049f8: bf870193
	v_lshlrev_b64_e32 v[13:14], 2, v[13:14]                    // 0000000049fc: 3e1a1a82
	v_mul_lo_u32 v19, s58, v19                                 // 000000004a00: d72c0013 0202263a
	s_delay_alu instid0(valu_dep_4) | instskip(skip_4) | instid1(valu_dep_3)// 000000004a08: bf8701d4
	v_mul_lo_u32 v29, s59, v20                                 // 000000004a0c: d72c001d 0202283b
	s_wait_alu depctr_va_vcc(0)                                // 000000004a14: bf88ff9d
	v_cndmask_b32_e32 v31, 0, v9, vcc_lo                       // 000000004a18: 023e1280
	v_mul_lo_u32 v17, s58, v8                                  // 000000004a1c: d72c0011 0202103a
	v_mov_b32_e32 v8, s55                                      // 000000004a24: 7e100237
	v_mul_lo_u32 v34, s59, v31                                 // 000000004a28: d72c0022 02023e3b
	s_delay_alu instid0(valu_dep_3) | instskip(skip_3) | instid1(valu_dep_4)// 000000004a30: bf870243
	v_add3_u32 v16, v16, v17, v18                              // 000000004a34: d6550010 044a2310
	v_mad_co_u64_u32 v[17:18], null, s58, v20, 0               // 000000004a3c: d6fe7c11 0202283a
	v_cndmask_b32_e32 v20, 0, v6, vcc_lo                       // 000000004a44: 02280c80
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[7:8]                  // 000000004a48: 7ca80e24
	v_lshlrev_b64_e32 v[15:16], 2, v[15:16]                    // 000000004a4c: 3e1e1e82
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_4)// 000000004a50: bf870233
	v_mul_lo_u32 v33, s58, v20                                 // 000000004a54: d72c0021 0202283a
	v_add3_u32 v18, v18, v19, v29                              // 000000004a5c: d6550012 04762712
	v_mad_co_u64_u32 v[19:20], null, s58, v31, 0               // 000000004a64: d6fe7c13 02023e3a
	v_add_co_u32 v29, s0, s52, v15                             // 000000004a6c: d700001d 02021e34
	s_wait_alu depctr_va_sdst(0)                               // 000000004a74: bf88f19f
	v_add_co_ci_u32_e64 v30, null, s53, v16, s0                // 000000004a78: d5207c1e 00022035
	s_wait_alu depctr_va_vcc(0)                                // 000000004a80: bf88ff9d
	v_dual_cndmask_b32 v15, 0, v6 :: v_dual_cndmask_b32 v16, 0, v7// 000000004a84: ca520c80 0f100e80
	v_add_co_u32 v31, vcc_lo, s60, v13                         // 000000004a8c: d7006a1f 02021a3c
	s_wait_alu depctr_va_vcc(0)                                // 000000004a94: bf88ff9d
	v_add_co_ci_u32_e64 v32, null, s61, v14, vcc_lo            // 000000004a98: d5207c20 01aa1c3d
	v_lshlrev_b64_e32 v[13:14], 2, v[17:18]                    // 000000004aa0: 3e1a2282
	v_mul_lo_u32 v35, s59, v16                                 // 000000004aa4: d72c0023 0202203b
	v_mul_lo_u32 v36, s58, v15                                 // 000000004aac: d72c0024 02021e3a
	v_mad_co_u64_u32 v[17:18], null, s58, v16, 0               // 000000004ab4: d6fe7c11 0202203a
	v_or_b32_e32 v15, 4, v5                                    // 000000004abc: 381e0a84
	v_mov_b32_e32 v16, s55                                     // 000000004ac0: 7e200237
	v_add3_u32 v20, v20, v33, v34                              // 000000004ac4: d6550014 048a4314
	v_add_co_u32 v33, vcc_lo, s52, v13                         // 000000004acc: d7006a21 02021a34
	s_wait_alu depctr_va_vcc(0)                                // 000000004ad4: bf88ff9d
	v_add_co_ci_u32_e64 v34, null, s53, v14, vcc_lo            // 000000004ad8: d5207c22 01aa1c35
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[15:16]                // 000000004ae0: 7ca81e24
	v_or_b32_e32 v13, 5, v5                                    // 000000004ae4: 381a0a85
	v_mov_b32_e32 v14, s55                                     // 000000004ae8: 7e1c0237
	v_lshlrev_b64_e32 v[19:20], 2, v[19:20]                    // 000000004aec: 3e262682
	v_add3_u32 v18, v18, v36, v35                              // 000000004af0: d6550012 048e4912
	s_wait_alu depctr_va_vcc(0)                                // 000000004af8: bf88ff9d
	v_dual_cndmask_b32 v39, 0, v6 :: v_dual_cndmask_b32 v40, 0, v15// 000000004afc: ca520c80 27281e80
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[13:14]                // 000000004b04: 7ca81a24
	s_delay_alu instid0(valu_dep_4)                            // 000000004b08: bf870004
	v_add_co_u32 v35, s0, s52, v19                             // 000000004b0c: d7000023 02022634
	s_wait_alu depctr_va_sdst(0)                               // 000000004b14: bf88f19f
	v_add_co_ci_u32_e64 v36, null, s53, v20, s0                // 000000004b18: d5207c24 00022835
	v_lshlrev_b64_e32 v[37:38], 2, v[17:18]                    // 000000004b20: 3e4a2282
	s_wait_alu depctr_va_vcc(0)                                // 000000004b24: bf88ff9d
	v_dual_cndmask_b32 v19, 0, v6 :: v_dual_cndmask_b32 v20, 0, v13// 000000004b28: ca520c80 13141a80
	v_or_b32_e32 v17, 6, v5                                    // 000000004b30: 38220a86
	v_mov_b32_e32 v18, s55                                     // 000000004b34: 7e240237
	v_mul_lo_u32 v43, s59, v40                                 // 000000004b38: d72c002b 0202503b
	v_mul_lo_u32 v44, s58, v39                                 // 000000004b40: d72c002c 02024e3a
	v_mad_co_u64_u32 v[39:40], null, s58, v40, 0               // 000000004b48: d6fe7c27 0202503a
	v_mul_lo_u32 v45, s59, v20                                 // 000000004b50: d72c002d 0202283b
	v_mul_lo_u32 v46, s58, v19                                 // 000000004b58: d72c002e 0202263a
	v_mad_co_u64_u32 v[41:42], null, s58, v20, 0               // 000000004b60: d6fe7c29 0202283a
	v_or_b32_e32 v19, 7, v5                                    // 000000004b68: 38260a87
	v_mov_b32_e32 v20, s55                                     // 000000004b6c: 7e280237
	v_cmp_gt_i64_e32 vcc_lo, s[36:37], v[17:18]                // 000000004b70: 7ca82224
	v_add_co_u32 v37, s0, s52, v37                             // 000000004b74: d7000025 02024a34
	s_wait_alu depctr_va_sdst(0)                               // 000000004b7c: bf88f19f
	v_add_co_ci_u32_e64 v38, null, s53, v38, s0                // 000000004b80: d5207c26 00024c35
	v_cmp_gt_i64_e64 s0, s[36:37], v[19:20]                    // 000000004b88: d4540000 02022624
	v_add3_u32 v40, v40, v44, v43                              // 000000004b90: d6550028 04ae5928
	s_wait_alu depctr_va_vcc(0)                                // 000000004b98: bf88ff9d
	v_dual_cndmask_b32 v43, 0, v6 :: v_dual_cndmask_b32 v44, 0, v17// 000000004b9c: ca520c80 2b2c2280
	v_add3_u32 v42, v42, v46, v45                              // 000000004ba4: d655002a 04b65d2a
	s_wait_alu depctr_va_sdst(0)                               // 000000004bac: bf88f19f
	v_cndmask_b32_e64 v45, 0, v6, s0                           // 000000004bb0: d501002d 00020c80
	v_cndmask_b32_e64 v46, 0, v19, s0                          // 000000004bb8: d501002e 00022680
	v_mul_lo_u32 v47, s59, v44                                 // 000000004bc0: d72c002f 0202583b
	v_mul_lo_u32 v48, s58, v43                                 // 000000004bc8: d72c0030 0202563a
	v_mad_co_u64_u32 v[43:44], null, s58, v44, 0               // 000000004bd0: d6fe7c2b 0202583a
	v_mul_lo_u32 v50, s58, v45                                 // 000000004bd8: d72c0032 02025a3a
	v_mul_lo_u32 v49, s59, v46                                 // 000000004be0: d72c0031 02025c3b
	v_mad_co_u64_u32 v[45:46], null, s58, v46, 0               // 000000004be8: d6fe7c2d 02025c3a
	v_lshlrev_b64_e32 v[39:40], 2, v[39:40]                    // 000000004bf0: 3e4e4e82
	v_lshlrev_b64_e32 v[41:42], 2, v[41:42]                    // 000000004bf4: 3e525282
	v_add3_u32 v44, v44, v48, v47                              // 000000004bf8: d655002c 04be612c
	v_add_co_u32 v47, s0, s56, v23                             // 000000004c00: d700002f 02022e38
	s_wait_alu depctr_va_sdst(0)                               // 000000004c08: bf88f19f
	v_add_co_ci_u32_e64 v48, null, s57, 0, s0                  // 000000004c0c: d5207c30 00010039
	v_add_co_u32 v23, s0, s54, v23                             // 000000004c14: d7000017 02022e36
	v_add3_u32 v46, v46, v50, v49                              // 000000004c1c: d655002e 04c6652e
	s_wait_alu depctr_va_sdst(0)                               // 000000004c24: bf88f19f
	v_add_co_ci_u32_e64 v49, null, s55, 0, s0                  // 000000004c28: d5207c31 00010037
	v_lshlrev_b64_e32 v[43:44], 2, v[43:44]                    // 000000004c30: 3e565682
	v_mul_lo_u32 v51, s46, v48                                 // 000000004c34: d72c0033 0202602e
	v_mul_lo_u32 v52, s47, v47                                 // 000000004c3c: d72c0034 02025e2f
	v_mad_co_u64_u32 v[47:48], null, s46, v47, v[21:22]        // 000000004c44: d6fe7c2f 04565e2e
	v_add_co_u32 v39, vcc_lo, s52, v39                         // 000000004c4c: d7006a27 02024e34
	v_lshlrev_b64_e32 v[45:46], 2, v[45:46]                    // 000000004c54: 3e5a5a82
	v_mul_lo_u32 v53, s46, v49                                 // 000000004c58: d72c0035 0202622e
	v_mul_lo_u32 v54, s47, v23                                 // 000000004c60: d72c0036 02022e2f
	v_mad_co_u64_u32 v[49:50], null, s46, v23, v[21:22]        // 000000004c68: d6fe7c31 04562e2e
	s_wait_alu depctr_va_vcc(0)                                // 000000004c70: bf88ff9d
	v_add_co_ci_u32_e64 v40, null, s53, v40, vcc_lo            // 000000004c74: d5207c28 01aa5035
	v_add_co_u32 v41, vcc_lo, s52, v41                         // 000000004c7c: d7006a29 02025234
	s_wait_alu depctr_va_vcc(0)                                // 000000004c84: bf88ff9d
	v_add_co_ci_u32_e64 v42, null, s53, v42, vcc_lo            // 000000004c88: d5207c2a 01aa5435
	v_add_co_u32 v21, vcc_lo, s52, v43                         // 000000004c90: d7006a15 02025634
	s_wait_alu depctr_va_vcc(0)                                // 000000004c98: bf88ff9d
	v_add_co_ci_u32_e64 v22, null, s53, v44, vcc_lo            // 000000004c9c: d5207c16 01aa5835
	v_add_co_u32 v23, vcc_lo, s52, v45                         // 000000004ca4: d7006a17 02025a34
	v_add3_u32 v45, v52, v48, v51                              // 000000004cac: d655002d 04ce6134
	v_add3_u32 v48, v54, v50, v53                              // 000000004cb4: d6550030 04d66536
	s_wait_alu depctr_va_vcc(0)                                // 000000004cbc: bf88ff9d
	v_add_co_ci_u32_e64 v43, null, s53, v46, vcc_lo            // 000000004cc0: d5207c2b 01aa5c35
	v_add_co_u32 v44, vcc_lo, s50, v47                         // 000000004cc8: d7006a2c 02025e32
	s_wait_alu depctr_va_vcc(0)                                // 000000004cd0: bf88ff9d
	v_add_co_ci_u32_e64 v45, null, s51, v45, vcc_lo            // 000000004cd4: d5207c2d 01aa5a33
	v_add_co_u32 v46, vcc_lo, s48, v49                         // 000000004cdc: d7006a2e 02026230
	s_wait_alu depctr_va_vcc(0)                                // 000000004ce4: bf88ff9d
	v_add_co_ci_u32_e64 v47, null, s49, v48, vcc_lo            // 000000004ce8: d5207c2f 01aa6031
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000004cf0: bf870122
	v_add_co_u32 v48, vcc_lo, v46, s44                         // 000000004cf4: d7006a30 0200592e
	s_wait_alu depctr_va_vcc(0)                                // 000000004cfc: bf88ff9d
	v_add_co_ci_u32_e64 v49, null, s45, v47, vcc_lo            // 000000004d00: d5207c31 01aa5e2d
	v_add_co_u32 v50, vcc_lo, v44, s44                         // 000000004d08: d7006a32 0200592c
	s_lshr_b64 s[2:3], s[44:45], 2                             // 000000004d10: 8582822c
	s_wait_alu depctr_va_vcc(0)                                // 000000004d14: bf88ff9d
	v_add_co_ci_u32_e64 v51, null, s45, v45, vcc_lo            // 000000004d18: d5207c33 01aa5a2d
	s_wait_alu depctr_sa_sdst(0)                               // 000000004d20: bf88ff9e
	v_add_co_u32 v52, vcc_lo, v29, s2                          // 000000004d24: d7006a34 0200051d
	s_wait_alu depctr_va_vcc(0)                                // 000000004d2c: bf88ff9d
	v_add_co_ci_u32_e64 v53, null, s3, v30, vcc_lo             // 000000004d30: d5207c35 01aa3c03
	v_add_co_u32 v54, vcc_lo, v33, s2                          // 000000004d38: d7006a36 02000521
	s_wait_alu depctr_va_vcc(0)                                // 000000004d40: bf88ff9d
	v_add_co_ci_u32_e64 v55, null, s3, v34, vcc_lo             // 000000004d44: d5207c37 01aa4403
	v_add_co_u32 v56, vcc_lo, v35, s2                          // 000000004d4c: d7006a38 02000523
	s_wait_alu depctr_va_vcc(0)                                // 000000004d54: bf88ff9d
	v_add_co_ci_u32_e64 v57, null, s3, v36, vcc_lo             // 000000004d58: d5207c39 01aa4803
	v_add_co_u32 v58, vcc_lo, v37, s2                          // 000000004d60: d7006a3a 02000525
	s_wait_alu depctr_va_vcc(0)                                // 000000004d68: bf88ff9d
	v_add_co_ci_u32_e64 v59, null, s3, v38, vcc_lo             // 000000004d6c: d5207c3b 01aa4c03
	v_add_co_u32 v60, vcc_lo, v39, s2                          // 000000004d74: d7006a3c 02000527
	s_lshr_b64 s[0:1], s[44:45], 4                             // 000000004d7c: 8580842c
	s_wait_alu depctr_va_vcc(0)                                // 000000004d80: bf88ff9d
	v_add_co_ci_u32_e64 v61, null, s3, v40, vcc_lo             // 000000004d84: d5207c3d 01aa5003
	v_add_co_u32 v62, vcc_lo, v41, s2                          // 000000004d8c: d7006a3e 02000529
	s_wait_alu depctr_sa_sdst(0)                               // 000000004d94: bf88ff9e
	s_mul_u64 s[0:1], s[0:1], s[38:39]                         // 000000004d98: aa802600
	s_wait_alu depctr_va_vcc(0)                                // 000000004d9c: bf88ff9d
	v_add_co_ci_u32_e64 v63, null, s3, v42, vcc_lo             // 000000004da0: d5207c3f 01aa5403
	v_add_co_u32 v64, vcc_lo, v21, s2                          // 000000004da8: d7006a40 02000515
	s_wait_alu depctr_va_vcc(0)                                // 000000004db0: bf88ff9d
	v_add_co_ci_u32_e64 v65, null, s3, v22, vcc_lo             // 000000004db4: d5207c41 01aa2c03
	v_add_co_u32 v66, vcc_lo, v23, s2                          // 000000004dbc: d7006a42 02000517
	s_wait_alu depctr_sa_sdst(0)                               // 000000004dc4: bf88ff9e
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000004dc8: 84808200
	s_wait_alu depctr_va_vcc(0)                                // 000000004dcc: bf88ff9d
	v_add_co_ci_u32_e64 v67, null, s3, v43, vcc_lo             // 000000004dd0: d5207c43 01aa5603
	global_load_b64 v[68:69], v[48:49], off                    // 000000004dd8: ee05407c 00000044 00000030
	global_load_b64 v[70:71], v[50:51], off                    // 000000004de4: ee05407c 00000046 00000032
	s_wait_alu depctr_sa_sdst(0)                               // 000000004df0: bf88ff9e
	v_add_co_u32 v48, vcc_lo, v31, s0                          // 000000004df4: d7006a30 0200011f
	s_wait_alu depctr_va_vcc(0)                                // 000000004dfc: bf88ff9d
	v_add_co_ci_u32_e64 v49, null, s1, v32, vcc_lo             // 000000004e00: d5207c31 01aa4001
	s_clause 0x7                                               // 000000004e08: bf850007
	global_load_b32 v72, v[52:53], off                         // 000000004e0c: ee05007c 00000048 00000034
	global_load_b32 v73, v[54:55], off                         // 000000004e18: ee05007c 00000049 00000036
	global_load_b32 v56, v[56:57], off                         // 000000004e24: ee05007c 00000038 00000038
	global_load_b32 v57, v[58:59], off                         // 000000004e30: ee05007c 00000039 0000003a
	global_load_b32 v58, v[60:61], off                         // 000000004e3c: ee05007c 0000003a 0000003c
	global_load_b32 v59, v[62:63], off                         // 000000004e48: ee05007c 0000003b 0000003e
	global_load_b32 v60, v[64:65], off                         // 000000004e54: ee05007c 0000003c 00000040
	global_load_b32 v61, v[66:67], off                         // 000000004e60: ee05007c 0000003d 00000042
	global_load_b32 v62, v[48:49], off                         // 000000004e6c: ee05007c 0000003e 00000030
	s_add_nc_u64 s[44:45], s[44:45], 16                        // 000000004e78: a9ac902c
	s_wait_alu depctr_sa_sdst(0)                               // 000000004e7c: bf88ff9e
	v_cmp_lt_i64_e64 s0, s[44:45], s[42:43]                    // 000000004e80: d4510000 0200542c
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000004e88: 8b6a007e
	s_wait_loadcnt 0x9                                         // 000000004e8c: bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[68:69], v[70:71], 0// 000000004e90: cc464030 1a028d44
	s_wait_loadcnt 0x0                                         // 000000004e98: bfc00000
	v_dual_mul_f32 v63, v72, v62 :: v_dual_mul_f32 v64, v62, v73// 000000004e9c: c8c67d48 3f40933e
	v_dual_mul_f32 v56, v62, v56 :: v_dual_mul_f32 v57, v62, v57// 000000004ea4: c8c6713e 3838733e
	v_dual_mul_f32 v58, v62, v58 :: v_dual_mul_f32 v59, v62, v59// 000000004eac: c8c6753e 3a3a773e
	v_dual_mul_f32 v60, v62, v60 :: v_dual_mul_f32 v61, v62, v61// 000000004eb4: c8c6793e 3c3c7b3e
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000004ebc: bf870214
	v_dual_mul_f32 v48, v48, v63 :: v_dual_mul_f32 v49, v49, v64// 000000004ec0: c8c67f30 30308131
	v_dual_mul_f32 v50, v50, v56 :: v_dual_mul_f32 v51, v51, v57// 000000004ec8: c8c67132 32327333
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000004ed0: bf870214
	v_dual_mul_f32 v52, v52, v58 :: v_dual_mul_f32 v53, v53, v59// 000000004ed4: c8c67534 34347735
	v_dual_mul_f32 v54, v54, v60 :: v_dual_mul_f32 v55, v55, v61// 000000004edc: c8c67936 36367b37
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000004ee4: bf870214
	v_dual_add_f32 v1, v1, v48 :: v_dual_add_f32 v28, v28, v49 // 000000004ee8: c9086101 011c631c
	v_dual_add_f32 v27, v27, v50 :: v_dual_add_f32 v26, v26, v51// 000000004ef0: c908651b 1b1a671a
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000004ef8: bf870214
	v_dual_add_f32 v25, v25, v52 :: v_dual_add_f32 v2, v2, v53 // 000000004efc: c9086919 19026b02
	v_add_f32_e32 v0, v0, v54                                  // 000000004f04: 06006d00
	v_add_f32_e32 v24, v24, v55                                // 000000004f08: 06306f18
	s_wait_alu depctr_sa_sdst(0)                               // 000000004f0c: bf88ff9e
	s_cbranch_vccnz 65399                                      // 000000004f10: bfa4ff77 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x31f0>
	v_mul_lo_u32 v21, s39, v5                                  // 000000004f14: d72c0015 02020a27
	v_mul_lo_u32 v22, s38, v6                                  // 000000004f1c: d72c0016 02020c26
	v_mad_co_u64_u32 v[5:6], null, s38, v5, 0                  // 000000004f24: d6fe7c05 02020a26
	v_mul_lo_u32 v23, s39, v11                                 // 000000004f2c: d72c0017 02021627
	v_mul_lo_u32 v29, s38, v12                                 // 000000004f34: d72c001d 02021826
	v_mad_co_u64_u32 v[11:12], null, s38, v11, 0               // 000000004f3c: d6fe7c0b 02021626
	v_bfe_u32 v30, v1, 16, 1                                   // 000000004f44: d610001e 02052101
	v_or_b32_e32 v32, 0x400000, v1                             // 000000004f4c: 384002ff 00400000
	v_bfe_u32 v31, v28, 16, 1                                  // 000000004f54: d610001f 0205211c
	v_mul_lo_u32 v16, s38, v16                                 // 000000004f5c: d72c0010 02022026
	v_add3_u32 v6, v6, v22, v21                                // 000000004f64: d6550006 04562d06
	v_lshlrev_b64_e32 v[21:22], 1, v[3:4]                      // 000000004f6c: 3e2a0681
	v_add3_u32 v30, v30, v1, 0x7fff                            // 000000004f70: d655001e 03fe031e 00007fff
	v_add3_u32 v12, v12, v29, v23                              // 000000004f7c: d655000c 045e3b0c
	v_mul_lo_u32 v29, s39, v9                                  // 000000004f84: d72c001d 02021227
	v_lshlrev_b64_e32 v[5:6], 1, v[5:6]                        // 000000004f8c: 3e0a0a81
	v_add3_u32 v31, v31, v28, 0x7fff                           // 000000004f90: d655001f 03fe391f 00007fff
	v_or_b32_e32 v23, 0x400000, v28                            // 000000004f9c: 382e38ff 00400000
	v_lshlrev_b64_e32 v[11:12], 1, v[11:12]                    // 000000004fa4: 3e161681
	v_mul_lo_u32 v14, s38, v14                                 // 000000004fa8: d72c000e 02021c26
	s_mov_b32 s0, -1                                           // 000000004fb0: be8000c1
	v_add_co_u32 v5, vcc_lo, s40, v5                           // 000000004fb4: d7006a05 02020a28
	s_wait_alu depctr_va_vcc(0)                                // 000000004fbc: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s41, v6, vcc_lo              // 000000004fc0: d5207c06 01aa0c29
	v_cmp_u_f32_e32 vcc_lo, v1, v1                             // 000000004fc8: 7c300301
	s_wait_alu depctr_va_vcc(0)                                // 000000004fcc: bf88ff9d
	v_cndmask_b32_e32 v1, v30, v32, vcc_lo                     // 000000004fd0: 0202411e
	v_add_co_u32 v5, vcc_lo, v5, v21                           // 000000004fd4: d7006a05 02022b05
	v_mul_lo_u32 v30, s38, v10                                 // 000000004fdc: d72c001e 02021426
	v_mad_co_u64_u32 v[9:10], null, s38, v9, 0                 // 000000004fe4: d6fe7c09 02021226
	s_wait_alu depctr_va_vcc(0)                                // 000000004fec: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, v6, v22, vcc_lo              // 000000004ff0: d5207c06 01aa2d06
	v_cmp_u_f32_e32 vcc_lo, v28, v28                           // 000000004ff8: 7c30391c
	v_mul_lo_u32 v28, s38, v8                                  // 000000004ffc: d72c001c 02021026
	global_store_d16_hi_b16 v[5:6], v1, off                    // 000000005004: ee09407c 00800000 00000005
	s_wait_alu depctr_va_vcc(0)                                // 000000005010: bf88ff9d
	v_cndmask_b32_e32 v1, v31, v23, vcc_lo                     // 000000005014: 02022f1f
	v_add_co_u32 v5, vcc_lo, s40, v11                          // 000000005018: d7006a05 02021628
	v_add3_u32 v10, v10, v30, v29                              // 000000005020: d655000a 04763d0a
	s_wait_alu depctr_va_vcc(0)                                // 000000005028: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s41, v12, vcc_lo             // 00000000502c: d5207c06 01aa1829
	v_bfe_u32 v11, v27, 16, 1                                  // 000000005034: d610000b 0205211b
	v_add_co_u32 v5, vcc_lo, v5, v21                           // 00000000503c: d7006a05 02022b05
	v_lshlrev_b64_e32 v[9:10], 1, v[9:10]                      // 000000005044: 3e121281
	v_mul_lo_u32 v23, s39, v7                                  // 000000005048: d72c0017 02020e27
	v_mad_co_u64_u32 v[7:8], null, s38, v7, 0                  // 000000005050: d6fe7c07 02020e26
	s_wait_alu depctr_va_vcc(0)                                // 000000005058: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, v6, v22, vcc_lo              // 00000000505c: d5207c06 01aa2d06
	v_add3_u32 v11, v11, v27, 0x7fff                           // 000000005064: d655000b 03fe370b 00007fff
	v_or_b32_e32 v12, 0x400000, v27                            // 000000005070: 381836ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v27, v27                           // 000000005078: 7c30371b
	global_store_d16_hi_b16 v[5:6], v1, off                    // 00000000507c: ee09407c 00800000 00000005
	v_add3_u32 v8, v8, v28, v23                                // 000000005088: d6550008 045e3908
	v_mul_lo_u32 v23, s39, v15                                 // 000000005090: d72c0017 02021e27
	s_wait_alu depctr_va_vcc(0)                                // 000000005098: bf88ff9d
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                     // 00000000509c: 0202190b
	v_add_co_u32 v5, vcc_lo, s40, v9                           // 0000000050a0: d7006a05 02021228
	v_bfe_u32 v9, v26, 16, 1                                   // 0000000050a8: d6100009 0205211a
	s_wait_alu depctr_va_vcc(0)                                // 0000000050b0: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s41, v10, vcc_lo             // 0000000050b4: d5207c06 01aa1429
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000050bc: bf870193
	v_add_co_u32 v5, vcc_lo, v5, v21                           // 0000000050c0: d7006a05 02022b05
	v_add3_u32 v11, v9, v26, 0x7fff                            // 0000000050c8: d655000b 03fe3509 00007fff
	v_mad_co_u64_u32 v[9:10], null, s38, v15, 0                // 0000000050d4: d6fe7c09 02021e26
	v_lshlrev_b64_e32 v[7:8], 1, v[7:8]                        // 0000000050dc: 3e0e0e81
	s_wait_alu depctr_va_vcc(0)                                // 0000000050e0: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, v6, v22, vcc_lo              // 0000000050e4: d5207c06 01aa2d06
	v_or_b32_e32 v12, 0x400000, v26                            // 0000000050ec: 381834ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v26, v26                           // 0000000050f4: 7c30351a
	v_mul_lo_u32 v15, s39, v13                                 // 0000000050f8: d72c000f 02021a27
	global_store_d16_hi_b16 v[5:6], v1, off                    // 000000005100: ee09407c 00800000 00000005
	v_add3_u32 v10, v10, v16, v23                              // 00000000510c: d655000a 045e210a
	s_wait_alu depctr_va_vcc(0)                                // 000000005114: bf88ff9d
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                     // 000000005118: 0202190b
	v_add_co_u32 v5, vcc_lo, s40, v7                           // 00000000511c: d7006a05 02020e28
	v_bfe_u32 v7, v25, 16, 1                                   // 000000005124: d6100007 02052119
	s_wait_alu depctr_va_vcc(0)                                // 00000000512c: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s41, v8, vcc_lo              // 000000005130: d5207c06 01aa1029
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000005138: bf870193
	v_add_co_u32 v5, vcc_lo, v5, v21                           // 00000000513c: d7006a05 02022b05
	v_add3_u32 v11, v7, v25, 0x7fff                            // 000000005144: d655000b 03fe3307 00007fff
	v_lshlrev_b64_e32 v[7:8], 1, v[9:10]                       // 000000005150: 3e0e1281
	v_mad_co_u64_u32 v[9:10], null, s38, v13, 0                // 000000005154: d6fe7c09 02021a26
	s_wait_alu depctr_va_vcc(0)                                // 00000000515c: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, v6, v22, vcc_lo              // 000000005160: d5207c06 01aa2d06
	v_or_b32_e32 v12, 0x400000, v25                            // 000000005168: 381832ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v25, v25                           // 000000005170: 7c303319
	v_mul_lo_u32 v13, s39, v17                                 // 000000005174: d72c000d 02022227
	global_store_d16_hi_b16 v[5:6], v1, off                    // 00000000517c: ee09407c 00800000 00000005
	v_add3_u32 v10, v10, v14, v15                              // 000000005188: d655000a 043e1d0a
	s_wait_alu depctr_va_vcc(0)                                // 000000005190: bf88ff9d
	v_cndmask_b32_e32 v11, v11, v12, vcc_lo                    // 000000005194: 0216190b
	v_add_co_u32 v1, vcc_lo, s40, v7                           // 000000005198: d7006a01 02020e28
	v_bfe_u32 v7, v2, 16, 1                                    // 0000000051a0: d6100007 02052102
	s_wait_alu depctr_va_vcc(0)                                // 0000000051a8: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s41, v8, vcc_lo              // 0000000051ac: d5207c06 01aa1029
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000051b4: bf870193
	v_add_co_u32 v5, vcc_lo, v1, v21                           // 0000000051b8: d7006a05 02022b01
	v_add3_u32 v1, v7, v2, 0x7fff                              // 0000000051c0: d6550001 03fe0507 00007fff
	v_lshlrev_b64_e32 v[7:8], 1, v[9:10]                       // 0000000051cc: 3e0e1281
	v_mul_lo_u32 v14, s38, v18                                 // 0000000051d0: d72c000e 02022426
	v_mad_co_u64_u32 v[9:10], null, s38, v17, 0                // 0000000051d8: d6fe7c09 02022226
	s_wait_alu depctr_va_vcc(0)                                // 0000000051e0: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, v6, v22, vcc_lo              // 0000000051e4: d5207c06 01aa2d06
	v_or_b32_e32 v12, 0x400000, v2                             // 0000000051ec: 381804ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v2, v2                             // 0000000051f4: 7c300502
	v_mul_lo_u32 v17, s39, v19                                 // 0000000051f8: d72c0011 02022627
	v_mul_lo_u32 v18, s38, v20                                 // 000000005200: d72c0012 02022826
	v_add3_u32 v10, v10, v14, v13                              // 000000005208: d655000a 04361d0a
	s_wait_alu depctr_va_vcc(0)                                // 000000005210: bf88ff9d
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 000000005214: 02181901
	v_bfe_u32 v1, v0, 16, 1                                    // 000000005218: d6100001 02052100
	v_add_co_u32 v15, vcc_lo, s40, v7                          // 000000005220: d7006a0f 02020e28
	s_wait_alu depctr_va_vcc(0)                                // 000000005228: bf88ff9d
	v_add_co_ci_u32_e64 v16, null, s41, v8, vcc_lo             // 00000000522c: d5207c10 01aa1029
	s_delay_alu instid0(valu_dep_3)                            // 000000005234: bf870003
	v_add3_u32 v13, v1, v0, 0x7fff                             // 000000005238: d655000d 03fe0101 00007fff
	v_mad_co_u64_u32 v[1:2], null, s38, v19, 0                 // 000000005244: d6fe7c01 02022626
	v_lshlrev_b64_e32 v[7:8], 1, v[9:10]                       // 00000000524c: 3e0e1281
	v_add_co_u32 v9, vcc_lo, v15, v21                          // 000000005250: d7006a09 02022b0f
	v_or_b32_e32 v14, 0x400000, v0                             // 000000005258: 381c00ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000005260: bf88ff9d
	v_add_co_ci_u32_e64 v10, null, v16, v22, vcc_lo            // 000000005264: d5207c0a 01aa2d10
	v_cmp_u_f32_e32 vcc_lo, v0, v0                             // 00000000526c: 7c300100
	v_add3_u32 v2, v2, v18, v17                                // 000000005270: d6550002 04462502
	s_clause 0x1                                               // 000000005278: bf850001
	global_store_d16_hi_b16 v[5:6], v11, off                   // 00000000527c: ee09407c 05800000 00000005
	global_store_d16_hi_b16 v[9:10], v12, off                  // 000000005288: ee09407c 06000000 00000009
	s_wait_alu depctr_va_vcc(0)                                // 000000005294: bf88ff9d
	v_cndmask_b32_e32 v13, v13, v14, vcc_lo                    // 000000005298: 021a1d0d
	v_add_co_u32 v7, vcc_lo, s40, v7                           // 00000000529c: d7006a07 02020e28
	s_wait_alu depctr_va_vcc(0)                                // 0000000052a4: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s41, v8, vcc_lo              // 0000000052a8: d5207c08 01aa1029
	v_lshlrev_b64_e32 v[0:1], 1, v[1:2]                        // 0000000052b0: 3e000281
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 0000000052b4: bf8701a3
	v_add_co_u32 v7, vcc_lo, v7, v21                           // 0000000052b8: d7006a07 02022b07
	s_wait_alu depctr_va_vcc(0)                                // 0000000052c0: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, v8, v22, vcc_lo              // 0000000052c4: d5207c08 01aa2d08
	s_delay_alu instid0(valu_dep_3)                            // 0000000052cc: bf870003
	v_add_co_u32 v0, vcc_lo, s40, v0                           // 0000000052d0: d7006a00 02020028
	s_wait_alu depctr_va_vcc(0)                                // 0000000052d8: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s41, v1, vcc_lo              // 0000000052dc: d5207c01 01aa0229
	global_store_d16_hi_b16 v[7:8], v13, off                   // 0000000052e4: ee09407c 06800000 00000007
	s_wait_alu depctr_sa_sdst(0)                               // 0000000052f0: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 0000000052f4: be812000
	s_cbranch_execnz 1                                         // 0000000052f8: bfa60001 <tessera_rocm_scaled_matmul_db789d6585c8dc9d+0x3800>
	s_endpgm                                                   // 0000000052fc: bfb00000
	v_bfe_u32 v2, v24, 16, 1                                   // 000000005300: d6100002 02052118
	v_or_b32_e32 v5, 0x400000, v24                             // 000000005308: 380a30ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v24, v24                           // 000000005310: 7c303118
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_2)// 000000005314: bf870133
	v_add3_u32 v6, v2, v24, 0x7fff                             // 000000005318: d6550006 03fe3102 00007fff
	v_lshlrev_b64_e32 v[2:3], 1, v[3:4]                        // 000000005324: 3e040681
	s_wait_alu depctr_va_vcc(0)                                // 000000005328: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v5, vcc_lo                       // 00000000532c: 02080b06
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_3)// 000000005330: bf8701a2
	v_add_co_u32 v0, vcc_lo, v0, v2                            // 000000005334: d7006a00 02020500
	s_wait_alu depctr_va_vcc(0)                                // 00000000533c: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v1, v3, vcc_lo               // 000000005340: d5207c01 01aa0701
	global_store_d16_hi_b16 v[0:1], v4, off                    // 000000005348: ee09407c 02000000 00000000
	s_endpgm                                                   // 000000005354: bfb00000
	s_code_end                                                 // 000000005358: bf9f0000
	s_code_end                                                 // 00000000535c: bf9f0000
	s_code_end                                                 // 000000005360: bf9f0000
	s_code_end                                                 // 000000005364: bf9f0000
	s_code_end                                                 // 000000005368: bf9f0000
	s_code_end                                                 // 00000000536c: bf9f0000
	s_code_end                                                 // 000000005370: bf9f0000
	s_code_end                                                 // 000000005374: bf9f0000
	s_code_end                                                 // 000000005378: bf9f0000
	s_code_end                                                 // 00000000537c: bf9f0000
	s_code_end                                                 // 000000005380: bf9f0000
	s_code_end                                                 // 000000005384: bf9f0000
	s_code_end                                                 // 000000005388: bf9f0000
	s_code_end                                                 // 00000000538c: bf9f0000
	s_code_end                                                 // 000000005390: bf9f0000
	s_code_end                                                 // 000000005394: bf9f0000
	s_code_end                                                 // 000000005398: bf9f0000
	s_code_end                                                 // 00000000539c: bf9f0000
	s_code_end                                                 // 0000000053a0: bf9f0000
	s_code_end                                                 // 0000000053a4: bf9f0000
	s_code_end                                                 // 0000000053a8: bf9f0000
	s_code_end                                                 // 0000000053ac: bf9f0000
	s_code_end                                                 // 0000000053b0: bf9f0000
	s_code_end                                                 // 0000000053b4: bf9f0000
	s_code_end                                                 // 0000000053b8: bf9f0000
	s_code_end                                                 // 0000000053bc: bf9f0000
	s_code_end                                                 // 0000000053c0: bf9f0000
	s_code_end                                                 // 0000000053c4: bf9f0000
	s_code_end                                                 // 0000000053c8: bf9f0000
	s_code_end                                                 // 0000000053cc: bf9f0000
	s_code_end                                                 // 0000000053d0: bf9f0000
	s_code_end                                                 // 0000000053d4: bf9f0000
	s_code_end                                                 // 0000000053d8: bf9f0000
	s_code_end                                                 // 0000000053dc: bf9f0000
	s_code_end                                                 // 0000000053e0: bf9f0000
	s_code_end                                                 // 0000000053e4: bf9f0000
	s_code_end                                                 // 0000000053e8: bf9f0000
	s_code_end                                                 // 0000000053ec: bf9f0000
	s_code_end                                                 // 0000000053f0: bf9f0000
	s_code_end                                                 // 0000000053f4: bf9f0000
	s_code_end                                                 // 0000000053f8: bf9f0000
	s_code_end                                                 // 0000000053fc: bf9f0000
	s_code_end                                                 // 000000005400: bf9f0000
	s_code_end                                                 // 000000005404: bf9f0000
	s_code_end                                                 // 000000005408: bf9f0000
	s_code_end                                                 // 00000000540c: bf9f0000
	s_code_end                                                 // 000000005410: bf9f0000
	s_code_end                                                 // 000000005414: bf9f0000
	s_code_end                                                 // 000000005418: bf9f0000
	s_code_end                                                 // 00000000541c: bf9f0000
	s_code_end                                                 // 000000005420: bf9f0000
	s_code_end                                                 // 000000005424: bf9f0000
	s_code_end                                                 // 000000005428: bf9f0000
	s_code_end                                                 // 00000000542c: bf9f0000
	s_code_end                                                 // 000000005430: bf9f0000
	s_code_end                                                 // 000000005434: bf9f0000
	s_code_end                                                 // 000000005438: bf9f0000
	s_code_end                                                 // 00000000543c: bf9f0000
	s_code_end                                                 // 000000005440: bf9f0000
	s_code_end                                                 // 000000005444: bf9f0000
	s_code_end                                                 // 000000005448: bf9f0000
	s_code_end                                                 // 00000000544c: bf9f0000
	s_code_end                                                 // 000000005450: bf9f0000
	s_code_end                                                 // 000000005454: bf9f0000
	s_code_end                                                 // 000000005458: bf9f0000
	s_code_end                                                 // 00000000545c: bf9f0000
	s_code_end                                                 // 000000005460: bf9f0000
	s_code_end                                                 // 000000005464: bf9f0000
	s_code_end                                                 // 000000005468: bf9f0000
	s_code_end                                                 // 00000000546c: bf9f0000
	s_code_end                                                 // 000000005470: bf9f0000
	s_code_end                                                 // 000000005474: bf9f0000
	s_code_end                                                 // 000000005478: bf9f0000
	s_code_end                                                 // 00000000547c: bf9f0000
	s_code_end                                                 // 000000005480: bf9f0000
	s_code_end                                                 // 000000005484: bf9f0000
	s_code_end                                                 // 000000005488: bf9f0000
	s_code_end                                                 // 00000000548c: bf9f0000
	s_code_end                                                 // 000000005490: bf9f0000
	s_code_end                                                 // 000000005494: bf9f0000
	s_code_end                                                 // 000000005498: bf9f0000
	s_code_end                                                 // 00000000549c: bf9f0000
	s_code_end                                                 // 0000000054a0: bf9f0000
	s_code_end                                                 // 0000000054a4: bf9f0000
	s_code_end                                                 // 0000000054a8: bf9f0000
	s_code_end                                                 // 0000000054ac: bf9f0000
	s_code_end                                                 // 0000000054b0: bf9f0000
	s_code_end                                                 // 0000000054b4: bf9f0000
	s_code_end                                                 // 0000000054b8: bf9f0000
	s_code_end                                                 // 0000000054bc: bf9f0000
	s_code_end                                                 // 0000000054c0: bf9f0000
	s_code_end                                                 // 0000000054c4: bf9f0000
	s_code_end                                                 // 0000000054c8: bf9f0000
	s_code_end                                                 // 0000000054cc: bf9f0000
	s_code_end                                                 // 0000000054d0: bf9f0000
	s_code_end                                                 // 0000000054d4: bf9f0000
	s_code_end                                                 // 0000000054d8: bf9f0000
	s_code_end                                                 // 0000000054dc: bf9f0000
	s_code_end                                                 // 0000000054e0: bf9f0000
	s_code_end                                                 // 0000000054e4: bf9f0000
	s_code_end                                                 // 0000000054e8: bf9f0000
	s_code_end                                                 // 0000000054ec: bf9f0000
	s_code_end                                                 // 0000000054f0: bf9f0000
	s_code_end                                                 // 0000000054f4: bf9f0000
	s_code_end                                                 // 0000000054f8: bf9f0000
	s_code_end                                                 // 0000000054fc: bf9f0000
