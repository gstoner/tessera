
/tmp/tmp16ufyirk.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

disassembly of section .text:

0000000000001b00 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f>:
	s_clause 0x6                                               // 000000001b00: bf850006
	s_load_b128 s[12:15], s[0:1], 0xc8                         // 000000001b04: f4004300 f80000c8
	s_load_b64 s[16:17], s[0:1], 0xa8                          // 000000001b0c: f4002400 f80000a8
	s_load_b64 s[24:25], s[0:1], 0xd8                          // 000000001b14: f4002600 f80000d8
	s_load_b64 s[26:27], s[0:1], 0x8                           // 000000001b1c: f4002680 f8000008
	s_load_b64 s[28:29], s[0:1], 0x30                          // 000000001b24: f4002700 f8000030
	s_load_b64 s[34:35], s[0:1], 0x58                          // 000000001b2c: f4002880 f8000058
	s_load_b64 s[18:19], s[0:1], 0x80                          // 000000001b34: f4002480 f8000080
	s_mov_b32 s2, ttmp9                                        // 000000001b3c: be820075
	s_ashr_i32 s3, ttmp9, 31                                   // 000000001b40: 86039f75
	s_mov_b32 s4, ttmp7                                        // 000000001b44: be840073
	s_ashr_i32 s5, ttmp7, 31                                   // 000000001b48: 86059f73
	s_lshl_b64 s[36:37], s[2:3], 5                             // 000000001b4c: 84a48502
	s_delay_alu instid0(salu_cycle_1) | instskip(skip_3) | instid1(valu_dep_1)// 000000001b50: bf8700c9
	v_dual_mov_b32 v11, s37 :: v_dual_and_b32 v42, 15, v0      // 000000001b54: ca240025 0b2a008f
	s_lshl_b64 s[30:31], s[4:5], 4                             // 000000001b5c: 849e8404
	s_add_nc_u64 s[2:3], s[36:37], 32                          // 000000001b60: a982a024
	s_add_nc_u64 s[0:1], s[30:31], 16                          // 000000001b64: a980901e
	v_or_b32_e32 v8, s36, v42                                  // 000000001b68: 38105424
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v9, s37            // 000000001b6c: ca100080 2c080025
	v_bfe_u32 v43, v0, 4, 1                                    // 000000001b74: d610002b 02050900
	s_delay_alu instid0(valu_dep_3)                            // 000000001b7c: bf870003
	v_or_b32_e32 v10, 16, v8                                   // 000000001b80: 38141090
	s_wait_kmcnt 0x0                                           // 000000001b84: bfc70000
	v_cmp_gt_i64_e64 s0, s[0:1], s[12:13]                      // 000000001b88: d4540000 02001800
	v_cmp_gt_i64_e64 s1, s[2:3], s[14:15]                      // 000000001b90: d4540001 02001c02
	v_cmp_gt_i64_e64 s33, s[24:25], 31                         // 000000001b98: d4540021 02013e18
	s_lshr_b64 s[38:39], s[24:25], 4                           // 000000001ba0: 85a68418
	s_and_b32 s20, s24, -16                                    // 000000001ba4: 8b14d018
	s_mov_b32 s21, s25                                         // 000000001ba8: be950019
	s_and_b32 s22, s24, 0xffffffe0                             // 000000001bac: 8b16ff18 ffffffe0
	s_or_b32 s0, s0, s1                                        // 000000001bb4: 8c000100
	s_mov_b32 s23, s25                                         // 000000001bb8: be970019
	s_wait_alu depctr_sa_sdst(0)                               // 000000001bbc: bf88ff9e
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000001bc0: 8b6a007e
	s_mov_b32 s0, -1                                           // 000000001bc4: be8000c1
	s_cbranch_vccz 3676                                        // 000000001bc8: bfa30e5c <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3a3c>
	v_dual_mov_b32 v15, s31 :: v_dual_mov_b32 v40, 0           // 000000001bcc: ca10001f 0f280080
	v_or_b32_e32 v14, s30, v42                                 // 000000001bd4: 381c541e
	s_and_b32 s0, s33, exec_lo                                 // 000000001bd8: 8b007e21
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v13, 0             // 000000001bdc: ca100080 260c0080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v45, 0             // 000000001be4: ca100080 242c0080
	s_delay_alu instid0(valu_dep_3)                            // 000000001bec: bf870003
	v_cmp_gt_i64_e64 s0, s[12:13], v[14:15]                    // 000000001bf0: d4540000 02021c0c
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v47, 0             // 000000001bf8: ca100080 222e0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v49, 0             // 000000001c00: ca100080 20300080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v51, 0             // 000000001c08: ca100080 1e320080
	v_mov_b32_e32 v46, 0                                       // 000000001c10: 7e5c0280
	v_mov_b32_e32 v48, 0                                       // 000000001c14: 7e600280
	v_mov_b32_e32 v50, 0                                       // 000000001c18: 7e640280
	v_mov_b32_e32 v52, 0                                       // 000000001c1c: 7e680280
	s_cselect_b32 s1, 1, 0                                     // 000000001c20: 98018081
	s_wait_alu depctr_sa_sdst(0)                               // 000000001c24: bf88ff9e
	s_cmp_lg_u32 s1, 1                                         // 000000001c28: bf078101
	s_cbranch_scc1 1888                                        // 000000001c2c: bfa20760 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x1eb0>
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 3, v43    // 000000001c30: ca220080 0d0c5683
	v_mov_b32_e32 v17, s31                                     // 000000001c38: 7e22021f
	v_cmp_gt_i64_e64 s1, s[14:15], v[8:9]                      // 000000001c3c: d4540001 0202100e
	s_lshl_b64 s[40:41], s[14:15], 2                           // 000000001c44: 84a8820e
	v_or_b32_e32 v0, s30, v12                                  // 000000001c48: 3800181e
	v_dual_mov_b32 v1, s31 :: v_dual_mov_b32 v40, v13          // 000000001c4c: ca10001f 0128010d
	v_mov_b32_e32 v44, v13                                     // 000000001c54: 7e58030d
	v_cndmask_b32_e64 v3, 0, v9, s1                            // 000000001c58: d5010003 00061280
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000001c60: bf870214
	v_or_b32_e32 v16, 3, v0                                    // 000000001c64: 38200083
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[0:1]                  // 000000001c68: 7ca8000c
	v_or_b32_e32 v4, 1, v0                                     // 000000001c6c: 38080081
	v_or_b32_e32 v6, 2, v0                                     // 000000001c70: 380c0082
	v_cndmask_b32_e64 v2, 0, v8, s1                            // 000000001c74: d5010002 00061080
	v_mov_b32_e32 v52, v13                                     // 000000001c7c: 7e68030d
	v_mov_b32_e32 v50, v13                                     // 000000001c80: 7e64030d
	v_cndmask_b32_e32 v18, 0, v0, vcc_lo                       // 000000001c84: 02240080
	v_cndmask_b32_e64 v21, 0, s31, vcc_lo                      // 000000001c88: d5010015 01a83e80
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[16:17]                // 000000001c90: 7ca8200c
	v_dual_mov_b32 v5, s31 :: v_dual_mov_b32 v48, v13          // 000000001c94: ca10001f 0530010d
	v_mov_b32_e32 v46, v13                                     // 000000001c9c: 7e5c030d
	s_lshl_b64 s[42:43], s[14:15], 3                           // 000000001ca0: 84aa830e
	s_mov_b64 s[44:45], 0                                      // 000000001ca4: beac0180
	s_wait_alu depctr_va_vcc(0)                                // 000000001ca8: bf88ff9d
	v_cndmask_b32_e32 v24, 0, v16, vcc_lo                      // 000000001cac: 02302080
	v_cmp_gt_i64_e64 s2, s[12:13], v[4:5]                      // 000000001cb0: d4540002 0202080c
	v_cndmask_b32_e64 v25, 0, s31, vcc_lo                      // 000000001cb8: d5010019 01a83e80
	v_or_b32_e32 v16, 6, v0                                    // 000000001cc0: 38200086
	s_mov_b64 s[46:47], s[34:35]                               // 000000001cc4: beae0122
	v_mov_b32_e32 v45, v13                                     // 000000001cc8: 7e5a030d
	v_mov_b32_e32 v51, v13                                     // 000000001ccc: 7e66030d
	s_wait_alu depctr_va_sdst(0)                               // 000000001cd0: bf88f19f
	v_cndmask_b32_e64 v19, 0, v4, s2                           // 000000001cd4: d5010013 000a0880
	v_or_b32_e32 v4, 4, v0                                     // 000000001cdc: 38080084
	v_cndmask_b32_e64 v22, 0, s31, s2                          // 000000001ce0: d5010016 00083e80
	v_mov_b32_e32 v49, v13                                     // 000000001ce8: 7e62030d
	v_mov_b32_e32 v47, v13                                     // 000000001cec: 7e5e030d
	v_mul_lo_u32 v37, v19, s39                                 // 000000001cf0: d72c0025 02004f13
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[4:5]                  // 000000001cf8: 7ca8080c
	v_mov_b32_e32 v7, s31                                      // 000000001cfc: 7e0e021f
	v_mul_lo_u32 v22, v22, s38                                 // 000000001d00: d72c0016 02004d16
	s_wait_alu depctr_va_vcc(0)                                // 000000001d08: bf88ff9d
	v_cndmask_b32_e32 v26, 0, v4, vcc_lo                       // 000000001d0c: 02340880
	s_delay_alu instid0(valu_dep_3) | instskip(skip_3) | instid1(valu_dep_3)// 000000001d10: bf8701c3
	v_cmp_gt_i64_e64 s3, s[12:13], v[6:7]                      // 000000001d14: d4540003 02020c0c
	v_cndmask_b32_e64 v27, 0, s31, vcc_lo                      // 000000001d1c: d501001b 01a83e80
	v_mul_lo_u32 v4, v18, s39                                  // 000000001d24: d72c0004 02004f12
	s_wait_alu depctr_va_sdst(0)                               // 000000001d2c: bf88f19f
	v_cndmask_b32_e64 v20, 0, v6, s3                           // 000000001d30: d5010014 000e0c80
	v_or_b32_e32 v6, 5, v0                                     // 000000001d38: 380c0085
	v_or_b32_e32 v0, 7, v0                                     // 000000001d3c: 38000087
	v_cndmask_b32_e64 v23, 0, s31, s3                          // 000000001d40: d5010017 000c3e80
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000001d48: bf870214
	v_mul_lo_u32 v38, v20, s39                                 // 000000001d4c: d72c0026 02004f14
	v_cmp_gt_i64_e64 s2, s[12:13], v[6:7]                      // 000000001d54: d4540002 02020c0c
	s_delay_alu instid0(valu_dep_4) | instskip(skip_1) | instid1(valu_dep_2)// 000000001d5c: bf870124
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[0:1]                  // 000000001d60: 7ca8000c
	s_wait_alu depctr_va_sdst(0)                               // 000000001d64: bf88f19f
	v_cndmask_b32_e64 v28, 0, v6, s2                           // 000000001d68: d501001c 000a0c80
	s_wait_alu depctr_va_vcc(0)                                // 000000001d70: bf88ff9d
	v_cndmask_b32_e32 v32, 0, v0, vcc_lo                       // 000000001d74: 02400080
	v_cmp_gt_i64_e64 s3, s[12:13], v[16:17]                    // 000000001d78: d4540003 0202200c
	v_mad_co_u64_u32 v[0:1], null, v18, s38, 0                 // 000000001d80: d6fe7c00 02004d12
	v_mul_lo_u32 v6, v21, s38                                  // 000000001d88: d72c0006 02004d15
	v_cndmask_b32_e64 v33, 0, s31, vcc_lo                      // 000000001d90: d5010021 01a83e80
	v_cndmask_b32_e64 v29, 0, s31, s2                          // 000000001d98: d501001d 00083e80
	v_cmp_gt_i64_e64 s2, s[14:15], v[10:11]                    // 000000001da0: d4540002 0202140e
	s_wait_alu depctr_va_sdst(0)                               // 000000001da8: bf88f19f
	v_cndmask_b32_e64 v30, 0, v16, s3                          // 000000001dac: d501001e 000e2080
	v_cndmask_b32_e64 v31, 0, s31, s3                          // 000000001db4: d501001f 000c3e80
	v_add_co_u32 v34, s3, s36, v42                             // 000000001dbc: d7000322 02025424
	s_wait_alu depctr_va_sdst(0)                               // 000000001dc4: bf88f19f
	v_add_co_ci_u32_e64 v35, null, s37, 0, s3                  // 000000001dc8: d5207c23 000d0025
	v_add3_u32 v1, v1, v4, v6                                  // 000000001dd0: d6550001 041a0901
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000001dd8: bf8701a3
	v_add_co_u32 v21, vcc_lo, v34, 16                          // 000000001ddc: d7006a15 02012122
	s_wait_alu depctr_va_vcc(0)                                // 000000001de4: bf88ff9d
	v_add_co_ci_u32_e64 v36, null, 0, v35, vcc_lo              // 000000001de8: d5207c24 01aa4680
	v_mad_co_u64_u32 v[6:7], null, v19, s38, 0                 // 000000001df0: d6fe7c06 02004d13
	v_mad_co_u64_u32 v[18:19], null, v20, s38, 0               // 000000001df8: d6fe7c12 02004d14
	v_mul_lo_u32 v20, v23, s38                                 // 000000001e00: d72c0014 02004d17
	v_lshlrev_b64_e32 v[0:1], 2, v[0:1]                        // 000000001e08: 3e000082
	v_mad_co_u64_u32 v[16:17], null, s24, v21, v[12:13]        // 000000001e0c: d6fe7c10 04322a18
	v_mul_lo_u32 v23, s24, v36                                 // 000000001e14: d72c0017 02024818
	v_mul_lo_u32 v21, s25, v21                                 // 000000001e1c: d72c0015 02022a19
	v_cndmask_b32_e64 v5, 0, v11, s2                           // 000000001e24: d5010005 000a1680
	v_add3_u32 v7, v7, v37, v22                                // 000000001e2c: d6550007 045a4b07
	v_add_co_u32 v53, vcc_lo, v0, 4                            // 000000001e34: d7006a35 02010900
	v_add3_u32 v19, v19, v38, v20                              // 000000001e3c: d6550013 04524d13
	s_wait_alu depctr_va_vcc(0)                                // 000000001e44: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, 0, v1, vcc_lo               // 000000001e48: d5207c36 01aa0280
	v_add3_u32 v17, v21, v17, v23                              // 000000001e50: d6550011 045e2315
	v_lshlrev_b64_e32 v[0:1], 2, v[6:7]                        // 000000001e58: 3e000c82
	v_lshlrev_b64_e32 v[6:7], 2, v[18:19]                      // 000000001e5c: 3e0c2482
	v_mul_lo_u32 v22, v24, s39                                 // 000000001e60: d72c0016 02004f18
	v_mad_co_u64_u32 v[18:19], null, v24, s38, 0               // 000000001e68: d6fe7c12 02004d18
	v_mul_lo_u32 v23, v25, s38                                 // 000000001e70: d72c0017 02004d19
	v_mul_lo_u32 v24, v26, s39                                 // 000000001e78: d72c0018 02004f1a
	v_mad_co_u64_u32 v[20:21], null, v26, s38, 0               // 000000001e80: d6fe7c14 02004d1a
	v_mul_lo_u32 v25, v27, s38                                 // 000000001e88: d72c0019 02004d1b
	v_add_co_u32 v55, vcc_lo, v0, 4                            // 000000001e90: d7006a37 02010900
	s_wait_alu depctr_va_vcc(0)                                // 000000001e98: bf88ff9d
	v_add_co_ci_u32_e64 v56, null, 0, v1, vcc_lo               // 000000001e9c: d5207c38 01aa0280
	v_add3_u32 v19, v19, v22, v23                              // 000000001ea4: d6550013 045e2d13
	v_add_co_u32 v57, vcc_lo, v6, 4                            // 000000001eac: d7006a39 02010906
	s_wait_alu depctr_va_vcc(0)                                // 000000001eb4: bf88ff9d
	v_add_co_ci_u32_e64 v58, null, 0, v7, vcc_lo               // 000000001eb8: d5207c3a 01aa0e80
	s_delay_alu instid0(valu_dep_3)                            // 000000001ec0: bf870003
	v_lshlrev_b64_e32 v[0:1], 2, v[18:19]                      // 000000001ec4: 3e002482
	v_mul_lo_u32 v22, v28, s39                                 // 000000001ec8: d72c0016 02004f1c
	v_mad_co_u64_u32 v[6:7], null, v28, s38, 0                 // 000000001ed0: d6fe7c06 02004d1c
	v_mul_lo_u32 v23, v29, s38                                 // 000000001ed8: d72c0017 02004d1d
	v_add3_u32 v21, v21, v24, v25                              // 000000001ee0: d6550015 04663115
	v_mul_lo_u32 v24, v30, s39                                 // 000000001ee8: d72c0018 02004f1e
	v_mad_co_u64_u32 v[18:19], null, v30, s38, 0               // 000000001ef0: d6fe7c12 02004d1e
	v_mul_lo_u32 v25, v31, s38                                 // 000000001ef8: d72c0019 02004d1f
	v_add_co_u32 v59, vcc_lo, v0, 4                            // 000000001f00: d7006a3b 02010900
	s_wait_alu depctr_va_vcc(0)                                // 000000001f08: bf88ff9d
	v_add_co_ci_u32_e64 v60, null, 0, v1, vcc_lo               // 000000001f0c: d5207c3c 01aa0280
	v_lshlrev_b64_e32 v[0:1], 2, v[20:21]                      // 000000001f14: 3e002882
	v_add3_u32 v7, v7, v22, v23                                // 000000001f18: d6550007 045e2d07
	v_mul_lo_u32 v22, v32, s39                                 // 000000001f20: d72c0016 02004f20
	v_mad_co_u64_u32 v[20:21], null, v32, s38, 0               // 000000001f28: d6fe7c14 02004d20
	v_mul_lo_u32 v23, v33, s38                                 // 000000001f30: d72c0017 02004d21
	v_add3_u32 v19, v19, v24, v25                              // 000000001f38: d6550013 04663113
	v_lshlrev_b64_e32 v[6:7], 2, v[6:7]                        // 000000001f40: 3e0c0c82
	v_add_co_u32 v61, vcc_lo, v0, 4                            // 000000001f44: d7006a3d 02010900
	s_wait_alu depctr_va_vcc(0)                                // 000000001f4c: bf88ff9d
	v_add_co_ci_u32_e64 v62, null, 0, v1, vcc_lo               // 000000001f50: d5207c3e 01aa0280
	v_lshlrev_b64_e32 v[0:1], 2, v[18:19]                      // 000000001f58: 3e002482
	v_add3_u32 v21, v21, v22, v23                              // 000000001f5c: d6550015 045e2d15
	v_cndmask_b32_e64 v4, 0, v10, s2                           // 000000001f64: d5010004 000a1480
	v_add_co_u32 v63, vcc_lo, v6, 4                            // 000000001f6c: d7006a3f 02010906
	s_wait_alu depctr_va_vcc(0)                                // 000000001f74: bf88ff9d
	v_add_co_ci_u32_e64 v64, null, 0, v7, vcc_lo               // 000000001f78: d5207c40 01aa0e80
	v_add_co_u32 v65, vcc_lo, v0, 4                            // 000000001f80: d7006a41 02010900
	v_lshlrev_b64_e32 v[6:7], 2, v[20:21]                      // 000000001f88: 3e0c2882
	s_wait_alu depctr_va_vcc(0)                                // 000000001f8c: bf88ff9d
	v_add_co_ci_u32_e64 v66, null, 0, v1, vcc_lo               // 000000001f90: d5207c42 01aa0280
	v_lshlrev_b64_e32 v[0:1], 2, v[2:3]                        // 000000001f98: 3e000482
	v_lshlrev_b64_e32 v[2:3], 2, v[4:5]                        // 000000001f9c: 3e040882
	v_add_co_u32 v4, s3, s30, v42                              // 000000001fa0: d7000304 0202541e
	s_wait_alu depctr_va_sdst(0)                               // 000000001fa8: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s31, 0, s3                   // 000000001fac: d5207c05 000d001f
	v_add_co_u32 v67, vcc_lo, v6, 4                            // 000000001fb4: d7006a43 02010906
	s_wait_alu depctr_va_vcc(0)                                // 000000001fbc: bf88ff9d
	v_add_co_ci_u32_e64 v68, null, 0, v7, vcc_lo               // 000000001fc0: d5207c44 01aa0e80
	v_mad_co_u64_u32 v[18:19], null, s24, v34, v[12:13]        // 000000001fc8: d6fe7c12 04324418
	v_mul_lo_u32 v6, s24, v35                                  // 000000001fd0: d72c0006 02024618
	v_mul_lo_u32 v7, s25, v34                                  // 000000001fd8: d72c0007 02024419
	v_mad_co_u64_u32 v[20:21], null, s24, v4, v[12:13]         // 000000001fe0: d6fe7c14 04320818
	v_mul_lo_u32 v5, s24, v5                                   // 000000001fe8: d72c0005 02020a18
	v_mul_lo_u32 v4, s25, v4                                   // 000000001ff0: d72c0004 02020819
	v_add_co_u32 v22, vcc_lo, s18, v0                          // 000000001ff8: d7006a16 02020012
	s_wait_alu depctr_va_vcc(0)                                // 000000002000: bf88ff9d
	v_add_co_ci_u32_e64 v23, null, s19, v1, vcc_lo             // 000000002004: d5207c17 01aa0213
	v_add_co_u32 v24, vcc_lo, s18, v2                          // 00000000200c: d7006a18 02020412
	s_wait_alu depctr_va_vcc(0)                                // 000000002014: bf88ff9d
	v_add_co_ci_u32_e64 v25, null, s19, v3, vcc_lo             // 000000002018: d5207c19 01aa0613
	v_add3_u32 v19, v7, v19, v6                                // 000000002020: d6550013 041a2707
	v_add3_u32 v21, v4, v21, v5                                // 000000002028: d6550015 04162b04
	v_mov_b32_e32 v30, v13                                     // 000000002030: 7e3c030d
	v_mov_b32_e32 v32, v13                                     // 000000002034: 7e40030d
	v_mov_b32_e32 v34, v13                                     // 000000002038: 7e44030d
	v_mov_b32_e32 v36, v13                                     // 00000000203c: 7e48030d
	v_mov_b32_e32 v38, v13                                     // 000000002040: 7e4c030d
	v_add_co_u32 v0, s3, v12, s44                              // 000000002044: d7000300 0200590c
	s_wait_alu depctr_va_sdst(0)                               // 00000000204c: bf88f19f
	v_add_co_ci_u32_e64 v1, null, 0, s45, s3                   // 000000002050: d5207c01 000c5a80
	v_add_co_u32 v2, vcc_lo, v20, s44                          // 000000002058: d7006a02 02005914
	s_wait_alu depctr_va_vcc(0)                                // 000000002060: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, s45, v21, vcc_lo             // 000000002064: d5207c03 01aa2a2d
	s_delay_alu instid0(valu_dep_3) | instskip(skip_4) | instid1(valu_dep_2)// 00000000206c: bf870153
	v_cmp_gt_i64_e32 vcc_lo, s[24:25], v[0:1]                  // 000000002070: 7ca80018
	s_and_b32 s3, s0, vcc_lo                                   // 000000002074: 8b036a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002078: bf88ff9e
	v_cndmask_b32_e64 v4, 0, v2, s3                            // 00000000207c: d5010004 000e0480
	v_cndmask_b32_e64 v5, 0, v3, s3                            // 000000002084: d5010005 000e0680
	v_add_co_u32 v4, s4, s26, v4                               // 00000000208c: d7000404 0202081a
	s_wait_alu depctr_va_sdst(0)                               // 000000002094: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002098: bf870002
	v_add_co_ci_u32_e64 v5, null, s27, v5, s4                  // 00000000209c: d5207c05 00120a1b
	global_load_d16_u8 v4, v[4:5], off                         // 0000000020a4: ee07807c 00000004 00000004
	s_wait_loadcnt 0x0                                         // 0000000020b0: bfc00000
	v_cndmask_b16 v4.l, 0, v4.l, s3                            // 0000000020b4: d65d0004 000e0880
	v_add_co_u32 v7, s3, v2, 1                                 // 0000000020bc: d7000307 02010302
	s_wait_alu depctr_va_sdst(0)                               // 0000000020c4: bf88f19f
	v_add_co_ci_u32_e64 v26, null, 0, v3, s3                   // 0000000020c8: d5207c1a 000e0680
	v_add_co_u32 v5, s3, v0, 1                                 // 0000000020d0: d7000305 02010300
	s_wait_alu depctr_va_sdst(0)                               // 0000000020d8: bf88f19f
	v_add_co_ci_u32_e64 v6, null, 0, v1, s3                    // 0000000020dc: d5207c06 000e0280
	v_and_b16 v4.l, 0xff, v4.l                                 // 0000000020e4: d7620004 020208ff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 0000000020f0: bf870152
	v_cmp_gt_i64_e64 s3, s[24:25], v[5:6]                      // 0000000020f4: d4540003 02020a18
	s_and_b32 s4, s0, s3                                       // 0000000020fc: 8b040300
	s_wait_alu depctr_sa_sdst(0)                               // 000000002100: bf88ff9e
	v_cndmask_b32_e64 v5, 0, v7, s4                            // 000000002104: d5010005 00120e80
	v_cndmask_b32_e64 v6, 0, v26, s4                           // 00000000210c: d5010006 00123480
	v_add_co_u32 v5, s5, s26, v5                               // 000000002114: d7000505 02020a1a
	s_wait_alu depctr_va_sdst(0)                               // 00000000211c: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002120: bf870002
	v_add_co_ci_u32_e64 v6, null, s27, v6, s5                  // 000000002124: d5207c06 00160c1b
	global_load_d16_hi_u8 v4, v[5:6], off                      // 00000000212c: ee08407c 00000004 00000005
	s_wait_loadcnt 0x0                                         // 000000002138: bfc00000
	v_cndmask_b16 v4.h, 0, v4.h, s4                            // 00000000213c: d65d5004 00120880
	v_add_co_u32 v7, s4, v2, 2                                 // 000000002144: d7000407 02010502
	s_wait_alu depctr_va_sdst(0)                               // 00000000214c: bf88f19f
	v_add_co_ci_u32_e64 v26, null, 0, v3, s4                   // 000000002150: d5207c1a 00120680
	v_add_co_u32 v5, s4, v0, 2                                 // 000000002158: d7000405 02010500
	s_wait_alu depctr_va_sdst(0)                               // 000000002160: bf88f19f
	v_add_co_ci_u32_e64 v6, null, 0, v1, s4                    // 000000002164: d5207c06 00120280
	v_lshlrev_b16 v4.h, 8, v4.h op_sel:[0,1,1]                 // 00000000216c: d7385004 02020888
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000002174: bf870112
	v_cmp_gt_i64_e64 s4, s[24:25], v[5:6]                      // 000000002178: d4540004 02020a18
	v_or_b16 v85.l, v4.l, v4.h op_sel:[0,1,0]                  // 000000002180: d7631055 02020904
	s_and_b32 s5, s0, s4                                       // 000000002188: 8b050400
	s_wait_alu depctr_sa_sdst(0)                               // 00000000218c: bf88ff9e
	v_cndmask_b32_e64 v5, 0, v7, s5                            // 000000002190: d5010005 00160e80
	v_cndmask_b32_e64 v6, 0, v26, s5                           // 000000002198: d5010006 00163480
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000021a0: bf870122
	v_add_co_u32 v5, s6, s26, v5                               // 0000000021a4: d7000605 02020a1a
	s_wait_alu depctr_va_sdst(0)                               // 0000000021ac: bf88f19f
	v_add_co_ci_u32_e64 v6, null, s27, v6, s6                  // 0000000021b0: d5207c06 001a0c1b
	global_load_d16_u8 v5, v[5:6], off                         // 0000000021b8: ee07807c 00000005 00000005
	s_wait_loadcnt 0x0                                         // 0000000021c4: bfc00000
	v_cndmask_b16 v5.l, 0, v5.l, s5                            // 0000000021c8: d65d0005 00160a80
	v_add_co_u32 v26, s5, v2, 3                                // 0000000021d0: d700051a 02010702
	s_wait_alu depctr_va_sdst(0)                               // 0000000021d8: bf88f19f
	v_add_co_ci_u32_e64 v27, null, 0, v3, s5                   // 0000000021dc: d5207c1b 00160680
	v_add_co_u32 v6, s5, v0, 3                                 // 0000000021e4: d7000506 02010700
	s_wait_alu depctr_va_sdst(0)                               // 0000000021ec: bf88f19f
	v_add_co_ci_u32_e64 v7, null, 0, v1, s5                    // 0000000021f0: d5207c07 00160280
	v_and_b16 v5.l, 0xff, v5.l                                 // 0000000021f8: d7620005 02020aff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000002204: bf870152
	v_cmp_gt_i64_e64 s5, s[24:25], v[6:7]                      // 000000002208: d4540005 02020c18
	s_and_b32 s6, s0, s5                                       // 000000002210: 8b060500
	s_wait_alu depctr_sa_sdst(0)                               // 000000002214: bf88ff9e
	v_cndmask_b32_e64 v6, 0, v26, s6                           // 000000002218: d5010006 001a3480
	v_cndmask_b32_e64 v7, 0, v27, s6                           // 000000002220: d5010007 001a3680
	v_add_co_u32 v6, s7, s26, v6                               // 000000002228: d7000706 02020c1a
	s_wait_alu depctr_va_sdst(0)                               // 000000002230: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002234: bf870002
	v_add_co_ci_u32_e64 v7, null, s27, v7, s7                  // 000000002238: d5207c07 001e0e1b
	global_load_d16_hi_u8 v5, v[6:7], off                      // 000000002240: ee08407c 00000005 00000006
	s_wait_loadcnt 0x0                                         // 00000000224c: bfc00000
	v_cndmask_b16 v5.h, 0, v5.h, s6                            // 000000002250: d65d5005 001a0a80
	v_add_co_u32 v26, s6, v2, 4                                // 000000002258: d700061a 02010902
	s_wait_alu depctr_va_sdst(0)                               // 000000002260: bf88f19f
	v_add_co_ci_u32_e64 v27, null, 0, v3, s6                   // 000000002264: d5207c1b 001a0680
	v_add_co_u32 v6, s6, v0, 4                                 // 00000000226c: d7000606 02010900
	s_wait_alu depctr_va_sdst(0)                               // 000000002274: bf88f19f
	v_add_co_ci_u32_e64 v7, null, 0, v1, s6                    // 000000002278: d5207c07 001a0280
	v_lshlrev_b16 v5.h, 8, v5.h op_sel:[0,1,1]                 // 000000002280: d7385005 02020a88
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000002288: bf870112
	v_cmp_gt_i64_e64 s6, s[24:25], v[6:7]                      // 00000000228c: d4540006 02020c18
	v_or_b16 v85.h, v5.l, v5.h op_sel:[0,1,1]                  // 000000002294: d7635055 02020b05
	s_and_b32 s7, s0, s6                                       // 00000000229c: 8b070600
	s_wait_alu depctr_sa_sdst(0)                               // 0000000022a0: bf88ff9e
	v_cndmask_b32_e64 v6, 0, v26, s7                           // 0000000022a4: d5010006 001e3480
	v_cndmask_b32_e64 v7, 0, v27, s7                           // 0000000022ac: d5010007 001e3680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000022b4: bf870122
	v_add_co_u32 v6, s8, s26, v6                               // 0000000022b8: d7000806 02020c1a
	s_wait_alu depctr_va_sdst(0)                               // 0000000022c0: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s27, v7, s8                  // 0000000022c4: d5207c07 00220e1b
	global_load_d16_u8 v6, v[6:7], off                         // 0000000022cc: ee07807c 00000006 00000006
	s_wait_loadcnt 0x0                                         // 0000000022d8: bfc00000
	v_cndmask_b16 v6.l, 0, v6.l, s7                            // 0000000022dc: d65d0006 001e0c80
	v_add_co_u32 v7, s7, v2, 5                                 // 0000000022e4: d7000707 02010b02
	s_wait_alu depctr_va_sdst(0)                               // 0000000022ec: bf88f19f
	v_add_co_ci_u32_e64 v28, null, 0, v3, s7                   // 0000000022f0: d5207c1c 001e0680
	v_add_co_u32 v26, s7, v0, 5                                // 0000000022f8: d700071a 02010b00
	s_wait_alu depctr_va_sdst(0)                               // 000000002300: bf88f19f
	v_add_co_ci_u32_e64 v27, null, 0, v1, s7                   // 000000002304: d5207c1b 001e0280
	v_and_b16 v6.l, 0xff, v6.l                                 // 00000000230c: d7620006 02020cff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000002318: bf870152
	v_cmp_gt_i64_e64 s7, s[24:25], v[26:27]                    // 00000000231c: d4540007 02023418
	s_and_b32 s8, s0, s7                                       // 000000002324: 8b080700
	s_wait_alu depctr_sa_sdst(0)                               // 000000002328: bf88ff9e
	v_cndmask_b32_e64 v7, 0, v7, s8                            // 00000000232c: d5010007 00220e80
	v_cndmask_b32_e64 v27, 0, v28, s8                          // 000000002334: d501001b 00223880
	v_add_co_u32 v26, s9, s26, v7                              // 00000000233c: d700091a 02020e1a
	s_wait_alu depctr_va_sdst(0)                               // 000000002344: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002348: bf870002
	v_add_co_ci_u32_e64 v27, null, s27, v27, s9                // 00000000234c: d5207c1b 0026361b
	global_load_d16_hi_u8 v6, v[26:27], off                    // 000000002354: ee08407c 00000006 0000001a
	s_wait_loadcnt 0x0                                         // 000000002360: bfc00000
	v_cndmask_b16 v6.h, 0, v6.h, s8                            // 000000002364: d65d5006 00220c80
	v_add_co_u32 v7, s8, v2, 6                                 // 00000000236c: d7000807 02010d02
	s_wait_alu depctr_va_sdst(0)                               // 000000002374: bf88f19f
	v_add_co_ci_u32_e64 v28, null, 0, v3, s8                   // 000000002378: d5207c1c 00220680
	v_add_co_u32 v26, s8, v0, 6                                // 000000002380: d700081a 02010d00
	s_wait_alu depctr_va_sdst(0)                               // 000000002388: bf88f19f
	v_add_co_ci_u32_e64 v27, null, 0, v1, s8                   // 00000000238c: d5207c1b 00220280
	v_lshlrev_b16 v6.h, 8, v6.h op_sel:[0,1,1]                 // 000000002394: d7385006 02020c88
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 00000000239c: bf870112
	v_cmp_gt_i64_e64 s8, s[24:25], v[26:27]                    // 0000000023a0: d4540008 02023418
	v_or_b16 v86.l, v6.l, v6.h op_sel:[0,1,0]                  // 0000000023a8: d7631056 02020d06
	s_and_b32 s9, s0, s8                                       // 0000000023b0: 8b090800
	s_wait_alu depctr_sa_sdst(0)                               // 0000000023b4: bf88ff9e
	v_cndmask_b32_e64 v7, 0, v7, s9                            // 0000000023b8: d5010007 00260e80
	v_cndmask_b32_e64 v27, 0, v28, s9                          // 0000000023c0: d501001b 00263880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000023c8: bf870122
	v_add_co_u32 v26, s10, s26, v7                             // 0000000023cc: d7000a1a 02020e1a
	s_wait_alu depctr_va_sdst(0)                               // 0000000023d4: bf88f19f
	v_add_co_ci_u32_e64 v27, null, s27, v27, s10               // 0000000023d8: d5207c1b 002a361b
	global_load_d16_u8 v7, v[26:27], off                       // 0000000023e0: ee07807c 00000007 0000001a
	s_wait_loadcnt 0x0                                         // 0000000023ec: bfc00000
	v_cndmask_b16 v7.l, 0, v7.l, s9                            // 0000000023f0: d65d0007 00260e80
	v_add_co_u32 v28, s9, v2, 7                                // 0000000023f8: d700091c 02010f02
	s_wait_alu depctr_va_sdst(0)                               // 000000002400: bf88f19f
	v_add_co_ci_u32_e64 v29, null, 0, v3, s9                   // 000000002404: d5207c1d 00260680
	v_add_co_u32 v26, s9, v0, 7                                // 00000000240c: d700091a 02010f00
	s_wait_alu depctr_va_sdst(0)                               // 000000002414: bf88f19f
	v_add_co_ci_u32_e64 v27, null, 0, v1, s9                   // 000000002418: d5207c1b 00260280
	v_and_b16 v7.l, 0xff, v7.l                                 // 000000002420: d7620007 02020eff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 00000000242c: bf870152
	v_cmp_gt_i64_e64 s9, s[24:25], v[26:27]                    // 000000002430: d4540009 02023418
	s_and_b32 s10, s0, s9                                      // 000000002438: 8b0a0900
	s_wait_alu depctr_sa_sdst(0)                               // 00000000243c: bf88ff9e
	v_cndmask_b32_e64 v26, 0, v28, s10                         // 000000002440: d501001a 002a3880
	v_cndmask_b32_e64 v27, 0, v29, s10                         // 000000002448: d501001b 002a3a80
	v_add_co_u32 v26, s11, s26, v26                            // 000000002450: d7000b1a 0202341a
	s_wait_alu depctr_va_sdst(0)                               // 000000002458: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 00000000245c: bf870002
	v_add_co_ci_u32_e64 v27, null, s27, v27, s11               // 000000002460: d5207c1b 002e361b
	global_load_d16_hi_u8 v7, v[26:27], off                    // 000000002468: ee08407c 00000007 0000001a
	s_wait_loadcnt 0x0                                         // 000000002474: bfc00000
	v_cndmask_b16 v7.h, 0, v7.h, s10                           // 000000002478: d65d5007 002a0e80
	v_add_co_u32 v4, s10, v18, s44                             // 000000002480: d7000a04 02005912
	s_wait_alu depctr_va_sdst(0)                               // 000000002488: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s45, v19, s10                // 00000000248c: d5207c05 002a262d
	s_delay_alu instid0(valu_dep_3)                            // 000000002494: bf870003
	v_lshlrev_b16 v7.h, 8, v7.h op_sel:[0,1,1]                 // 000000002498: d7385007 02020e88
	s_and_b32 s10, s1, vcc_lo                                  // 0000000024a0: 8b0a6a01
	s_and_b32 vcc_lo, s2, vcc_lo                               // 0000000024a4: 8b6a6a02
	s_wait_alu depctr_sa_sdst(0)                               // 0000000024a8: bf88ff9e
	v_cndmask_b32_e64 v6, 0, v4, s10                           // 0000000024ac: d5010006 002a0880
	v_or_b16 v86.h, v7.l, v7.h op_sel:[0,1,1]                  // 0000000024b4: d7635056 02020f07
	v_cndmask_b32_e64 v7, 0, v5, s10                           // 0000000024bc: d5010007 002a0a80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_2)// 0000000024c4: bf870123
	v_add_co_u32 v6, s11, s28, v6                              // 0000000024c8: d7000b06 02020c1c
	s_wait_alu depctr_va_sdst(0)                               // 0000000024d0: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s29, v7, s11                 // 0000000024d4: d5207c07 002e0e1d
	global_load_d16_u8 v6, v[6:7], off                         // 0000000024dc: ee07807c 00000006 00000006
	s_wait_loadcnt 0x0                                         // 0000000024e8: bfc00000
	v_cndmask_b16 v6.l, 0, v6.l, s10                           // 0000000024ec: d65d0006 002a0c80
	v_add_co_u32 v7, s10, v4, 1                                // 0000000024f4: d7000a07 02010304
	s_wait_alu depctr_va_sdst(0)                               // 0000000024fc: bf88f19f
	v_add_co_ci_u32_e64 v26, null, 0, v5, s10                  // 000000002500: d5207c1a 002a0a80
	s_and_b32 s10, s1, s3                                      // 000000002508: 8b0a0301
	v_and_b16 v6.l, 0xff, v6.l                                 // 00000000250c: d7620006 02020cff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000002518: bf88ff9e
	v_cndmask_b32_e64 v7, 0, v7, s10                           // 00000000251c: d5010007 002a0e80
	v_cndmask_b32_e64 v27, 0, v26, s10                         // 000000002524: d501001b 002a3480
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 00000000252c: bf870122
	v_add_co_u32 v26, s11, s28, v7                             // 000000002530: d7000b1a 02020e1c
	s_wait_alu depctr_va_sdst(0)                               // 000000002538: bf88f19f
	v_add_co_ci_u32_e64 v27, null, s29, v27, s11               // 00000000253c: d5207c1b 002e361d
	global_load_d16_hi_u8 v6, v[26:27], off                    // 000000002544: ee08407c 00000006 0000001a
	s_wait_loadcnt 0x0                                         // 000000002550: bfc00000
	v_cndmask_b16 v6.h, 0, v6.h, s10                           // 000000002554: d65d5006 002a0c80
	v_add_co_u32 v7, s10, v4, 2                                // 00000000255c: d7000a07 02010504
	s_wait_alu depctr_va_sdst(0)                               // 000000002564: bf88f19f
	v_add_co_ci_u32_e64 v26, null, 0, v5, s10                  // 000000002568: d5207c1a 002a0a80
	s_and_b32 s10, s1, s4                                      // 000000002570: 8b0a0401
	v_lshlrev_b16 v6.h, 8, v6.h op_sel:[0,1,1]                 // 000000002574: d7385006 02020c88
	s_wait_alu depctr_sa_sdst(0)                               // 00000000257c: bf88ff9e
	v_cndmask_b32_e64 v7, 0, v7, s10                           // 000000002580: d5010007 002a0e80
	v_cndmask_b32_e64 v27, 0, v26, s10                         // 000000002588: d501001b 002a3480
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002590: bf870193
	v_or_b16 v77.l, v6.l, v6.h op_sel:[0,1,0]                  // 000000002594: d763104d 02020d06
	v_add_co_u32 v26, s11, s28, v7                             // 00000000259c: d7000b1a 02020e1c
	s_wait_alu depctr_va_sdst(0)                               // 0000000025a4: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 0000000025a8: bf870003
	v_add_co_ci_u32_e64 v27, null, s29, v27, s11               // 0000000025ac: d5207c1b 002e361d
	global_load_d16_u8 v7, v[26:27], off                       // 0000000025b4: ee07807c 00000007 0000001a
	s_wait_loadcnt 0x0                                         // 0000000025c0: bfc00000
	v_cndmask_b16 v7.l, 0, v7.l, s10                           // 0000000025c4: d65d0007 002a0e80
	v_add_co_u32 v26, s10, v4, 3                               // 0000000025cc: d7000a1a 02010704
	s_wait_alu depctr_va_sdst(0)                               // 0000000025d4: bf88f19f
	v_add_co_ci_u32_e64 v27, null, 0, v5, s10                  // 0000000025d8: d5207c1b 002a0a80
	s_and_b32 s10, s1, s5                                      // 0000000025e0: 8b0a0501
	v_and_b16 v7.l, 0xff, v7.l                                 // 0000000025e4: d7620007 02020eff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000025f0: bf88ff9e
	v_cndmask_b32_e64 v26, 0, v26, s10                         // 0000000025f4: d501001a 002a3480
	v_cndmask_b32_e64 v27, 0, v27, s10                         // 0000000025fc: d501001b 002a3680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000002604: bf870122
	v_add_co_u32 v26, s11, s28, v26                            // 000000002608: d7000b1a 0202341c
	s_wait_alu depctr_va_sdst(0)                               // 000000002610: bf88f19f
	v_add_co_ci_u32_e64 v27, null, s29, v27, s11               // 000000002614: d5207c1b 002e361d
	global_load_d16_hi_u8 v7, v[26:27], off                    // 00000000261c: ee08407c 00000007 0000001a
	s_wait_loadcnt 0x0                                         // 000000002628: bfc00000
	v_cndmask_b16 v7.h, 0, v7.h, s10                           // 00000000262c: d65d5007 002a0e80
	v_add_co_u32 v26, s10, v4, 4                               // 000000002634: d7000a1a 02010904
	s_wait_alu depctr_va_sdst(0)                               // 00000000263c: bf88f19f
	v_add_co_ci_u32_e64 v27, null, 0, v5, s10                  // 000000002640: d5207c1b 002a0a80
	s_and_b32 s10, s1, s6                                      // 000000002648: 8b0a0601
	v_lshlrev_b16 v7.h, 8, v7.h op_sel:[0,1,1]                 // 00000000264c: d7385007 02020e88
	s_wait_alu depctr_sa_sdst(0)                               // 000000002654: bf88ff9e
	v_cndmask_b32_e64 v26, 0, v26, s10                         // 000000002658: d501001a 002a3480
	v_cndmask_b32_e64 v27, 0, v27, s10                         // 000000002660: d501001b 002a3680
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002668: bf870193
	v_or_b16 v77.h, v7.l, v7.h op_sel:[0,1,1]                  // 00000000266c: d763504d 02020f07
	v_add_co_u32 v26, s11, s28, v26                            // 000000002674: d7000b1a 0202341c
	s_wait_alu depctr_va_sdst(0)                               // 00000000267c: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000002680: bf870003
	v_add_co_ci_u32_e64 v27, null, s29, v27, s11               // 000000002684: d5207c1b 002e361d
	global_load_d16_u8 v26, v[26:27], off                      // 00000000268c: ee07807c 0000001a 0000001a
	s_wait_loadcnt 0x0                                         // 000000002698: bfc00000
	v_cndmask_b16 v26.l, 0, v26.l, s10                         // 00000000269c: d65d001a 002a3480
	v_add_co_u32 v27, s10, v4, 5                               // 0000000026a4: d7000a1b 02010b04
	s_wait_alu depctr_va_sdst(0)                               // 0000000026ac: bf88f19f
	v_add_co_ci_u32_e64 v28, null, 0, v5, s10                  // 0000000026b0: d5207c1c 002a0a80
	s_and_b32 s10, s1, s7                                      // 0000000026b8: 8b0a0701
	v_and_b16 v26.l, 0xff, v26.l                               // 0000000026bc: d762001a 020234ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000026c8: bf88ff9e
	v_cndmask_b32_e64 v27, 0, v27, s10                         // 0000000026cc: d501001b 002a3680
	v_cndmask_b32_e64 v28, 0, v28, s10                         // 0000000026d4: d501001c 002a3880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000026dc: bf870122
	v_add_co_u32 v27, s11, s28, v27                            // 0000000026e0: d7000b1b 0202361c
	s_wait_alu depctr_va_sdst(0)                               // 0000000026e8: bf88f19f
	v_add_co_ci_u32_e64 v28, null, s29, v28, s11               // 0000000026ec: d5207c1c 002e381d
	global_load_d16_hi_u8 v26, v[27:28], off                   // 0000000026f4: ee08407c 0000001a 0000001b
	s_wait_loadcnt 0x0                                         // 000000002700: bfc00000
	v_cndmask_b16 v26.h, 0, v26.h, s10                         // 000000002704: d65d501a 002a3480
	v_add_co_u32 v27, s10, v4, 6                               // 00000000270c: d7000a1b 02010d04
	s_wait_alu depctr_va_sdst(0)                               // 000000002714: bf88f19f
	v_add_co_ci_u32_e64 v28, null, 0, v5, s10                  // 000000002718: d5207c1c 002a0a80
	s_and_b32 s10, s1, s8                                      // 000000002720: 8b0a0801
	v_lshlrev_b16 v26.h, 8, v26.h op_sel:[0,1,1]               // 000000002724: d738501a 02023488
	s_wait_alu depctr_sa_sdst(0)                               // 00000000272c: bf88ff9e
	v_cndmask_b32_e64 v27, 0, v27, s10                         // 000000002730: d501001b 002a3680
	v_cndmask_b32_e64 v28, 0, v28, s10                         // 000000002738: d501001c 002a3880
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002740: bf870193
	v_or_b16 v78.l, v26.l, v26.h op_sel:[0,1,0]                // 000000002744: d763104e 0202351a
	v_add_co_u32 v27, s11, s28, v27                            // 00000000274c: d7000b1b 0202361c
	s_wait_alu depctr_va_sdst(0)                               // 000000002754: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000002758: bf870003
	v_add_co_ci_u32_e64 v28, null, s29, v28, s11               // 00000000275c: d5207c1c 002e381d
	global_load_d16_u8 v27, v[27:28], off                      // 000000002764: ee07807c 0000001b 0000001b
	s_wait_loadcnt 0x0                                         // 000000002770: bfc00000
	v_cndmask_b16 v27.l, 0, v27.l, s10                         // 000000002774: d65d001b 002a3680
	v_add_co_u32 v28, s10, v4, 7                               // 00000000277c: d7000a1c 02010f04
	s_wait_alu depctr_va_sdst(0)                               // 000000002784: bf88f19f
	v_add_co_ci_u32_e64 v29, null, 0, v5, s10                  // 000000002788: d5207c1d 002a0a80
	s_and_b32 s10, s1, s9                                      // 000000002790: 8b0a0901
	v_and_b16 v27.l, 0xff, v27.l                               // 000000002794: d762001b 020236ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000027a0: bf88ff9e
	v_cndmask_b32_e64 v28, 0, v28, s10                         // 0000000027a4: d501001c 002a3880
	v_cndmask_b32_e64 v29, 0, v29, s10                         // 0000000027ac: d501001d 002a3a80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000027b4: bf870122
	v_add_co_u32 v28, s11, s28, v28                            // 0000000027b8: d7000b1c 0202381c
	s_wait_alu depctr_va_sdst(0)                               // 0000000027c0: bf88f19f
	v_add_co_ci_u32_e64 v29, null, s29, v29, s11               // 0000000027c4: d5207c1d 002e3a1d
	global_load_d16_hi_u8 v27, v[28:29], off                   // 0000000027cc: ee08407c 0000001b 0000001c
	s_wait_loadcnt 0x0                                         // 0000000027d8: bfc00000
	v_cndmask_b16 v27.h, 0, v27.h, s10                         // 0000000027dc: d65d501b 002a3680
	v_add_co_u32 v6, s10, v16, s44                             // 0000000027e4: d7000a06 02005910
	s_wait_alu depctr_va_sdst(0)                               // 0000000027ec: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s45, v17, s10                // 0000000027f0: d5207c07 002a222d
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000027f8: bf870193
	v_lshlrev_b16 v27.h, 8, v27.h op_sel:[0,1,1]               // 0000000027fc: d738501b 02023688
	v_cndmask_b32_e32 v26, 0, v6, vcc_lo                       // 000000002804: 02340c80
	s_add_nc_u64 s[44:45], s[44:45], 32                        // 000000002808: a9aca02c
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_3)// 00000000280c: bf8701a2
	v_or_b16 v78.h, v27.l, v27.h op_sel:[0,1,1]                // 000000002810: d763504e 0202371b
	v_cndmask_b32_e32 v27, 0, v7, vcc_lo                       // 000000002818: 02360e80
	v_add_co_u32 v26, s10, s28, v26                            // 00000000281c: d7000a1a 0202341c
	s_wait_alu depctr_va_sdst(0)                               // 000000002824: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002828: bf870002
	v_add_co_ci_u32_e64 v27, null, s29, v27, s10               // 00000000282c: d5207c1b 002a361d
	global_load_d16_u8 v26, v[26:27], off                      // 000000002834: ee07807c 0000001a 0000001a
	s_wait_loadcnt 0x0                                         // 000000002840: bfc00000
	v_cndmask_b16 v26.l, 0, v26.l, vcc_lo                      // 000000002844: d65d001a 01aa3480
	v_add_co_u32 v27, vcc_lo, v6, 1                            // 00000000284c: d7006a1b 02010306
	s_wait_alu depctr_va_vcc(0)                                // 000000002854: bf88ff9d
	v_add_co_ci_u32_e64 v28, null, 0, v7, vcc_lo               // 000000002858: d5207c1c 01aa0e80
	s_and_b32 vcc_lo, s2, s3                                   // 000000002860: 8b6a0302
	v_and_b16 v26.l, 0xff, v26.l                               // 000000002864: d762001a 020234ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000002870: bf88ff9e
	v_dual_cndmask_b32 v27, 0, v27 :: v_dual_cndmask_b32 v28, 0, v28// 000000002874: ca523680 1b1c3880
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 00000000287c: bf870121
	v_add_co_u32 v27, s3, s28, v27                             // 000000002880: d700031b 0202361c
	s_wait_alu depctr_va_sdst(0)                               // 000000002888: bf88f19f
	v_add_co_ci_u32_e64 v28, null, s29, v28, s3                // 00000000288c: d5207c1c 000e381d
	global_load_d16_hi_u8 v26, v[27:28], off                   // 000000002894: ee08407c 0000001a 0000001b
	s_wait_loadcnt 0x0                                         // 0000000028a0: bfc00000
	v_cndmask_b16 v26.h, 0, v26.h, vcc_lo                      // 0000000028a4: d65d501a 01aa3480
	v_add_co_u32 v27, vcc_lo, v6, 2                            // 0000000028ac: d7006a1b 02010506
	s_wait_alu depctr_va_vcc(0)                                // 0000000028b4: bf88ff9d
	v_add_co_ci_u32_e64 v28, null, 0, v7, vcc_lo               // 0000000028b8: d5207c1c 01aa0e80
	s_and_b32 vcc_lo, s2, s4                                   // 0000000028c0: 8b6a0402
	v_lshlrev_b16 v26.h, 8, v26.h op_sel:[0,1,1]               // 0000000028c4: d738501a 02023488
	s_wait_alu depctr_sa_sdst(0)                               // 0000000028cc: bf88ff9e
	v_dual_cndmask_b32 v27, 0, v27 :: v_dual_cndmask_b32 v28, 0, v28// 0000000028d0: ca523680 1b1c3880
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 0000000028d8: bf870121
	v_add_co_u32 v27, s3, s28, v27                             // 0000000028dc: d700031b 0202361c
	s_wait_alu depctr_va_sdst(0)                               // 0000000028e4: bf88f19f
	v_add_co_ci_u32_e64 v28, null, s29, v28, s3                // 0000000028e8: d5207c1c 000e381d
	global_load_d16_u8 v27, v[27:28], off                      // 0000000028f0: ee07807c 0000001b 0000001b
	s_wait_loadcnt 0x0                                         // 0000000028fc: bfc00000
	v_cndmask_b16 v27.l, 0, v27.l, vcc_lo                      // 000000002900: d65d001b 01aa3680
	v_add_co_u32 v28, vcc_lo, v6, 3                            // 000000002908: d7006a1c 02010706
	s_wait_alu depctr_va_vcc(0)                                // 000000002910: bf88ff9d
	v_add_co_ci_u32_e64 v29, null, 0, v7, vcc_lo               // 000000002914: d5207c1d 01aa0e80
	s_and_b32 vcc_lo, s2, s5                                   // 00000000291c: 8b6a0502
	v_and_b16 v27.l, 0xff, v27.l                               // 000000002920: d762001b 020236ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 00000000292c: bf88ff9e
	v_dual_cndmask_b32 v28, 0, v28 :: v_dual_cndmask_b32 v29, 0, v29// 000000002930: ca523880 1c1c3a80
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000002938: bf870121
	v_add_co_u32 v28, s3, s28, v28                             // 00000000293c: d700031c 0202381c
	s_wait_alu depctr_va_sdst(0)                               // 000000002944: bf88f19f
	v_add_co_ci_u32_e64 v29, null, s29, v29, s3                // 000000002948: d5207c1d 000e3a1d
	global_load_d16_hi_u8 v27, v[28:29], off                   // 000000002950: ee08407c 0000001b 0000001c
	s_wait_loadcnt 0x0                                         // 00000000295c: bfc00000
	v_cndmask_b16 v27.h, 0, v27.h, vcc_lo                      // 000000002960: d65d501b 01aa3680
	v_add_co_u32 v28, vcc_lo, v6, 4                            // 000000002968: d7006a1c 02010906
	s_wait_alu depctr_va_vcc(0)                                // 000000002970: bf88ff9d
	v_add_co_ci_u32_e64 v29, null, 0, v7, vcc_lo               // 000000002974: d5207c1d 01aa0e80
	s_and_b32 vcc_lo, s2, s6                                   // 00000000297c: 8b6a0602
	v_lshlrev_b16 v27.h, 8, v27.h op_sel:[0,1,1]               // 000000002980: d738501b 02023688
	s_wait_alu depctr_sa_sdst(0)                               // 000000002988: bf88ff9e
	v_dual_cndmask_b32 v28, 0, v28 :: v_dual_cndmask_b32 v29, 0, v29// 00000000298c: ca523880 1c1c3a80
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000002994: bf870121
	v_add_co_u32 v28, s3, s28, v28                             // 000000002998: d700031c 0202381c
	s_wait_alu depctr_va_sdst(0)                               // 0000000029a0: bf88f19f
	v_add_co_ci_u32_e64 v29, null, s29, v29, s3                // 0000000029a4: d5207c1d 000e3a1d
	global_load_d16_u8 v28, v[28:29], off                      // 0000000029ac: ee07807c 0000001c 0000001c
	s_wait_loadcnt 0x0                                         // 0000000029b8: bfc00000
	v_cndmask_b16 v28.l, 0, v28.l, vcc_lo                      // 0000000029bc: d65d001c 01aa3880
	v_add_co_u32 v29, vcc_lo, v6, 5                            // 0000000029c4: d7006a1d 02010b06
	s_wait_alu depctr_va_vcc(0)                                // 0000000029cc: bf88ff9d
	v_add_co_ci_u32_e64 v31, null, 0, v7, vcc_lo               // 0000000029d0: d5207c1f 01aa0e80
	s_and_b32 vcc_lo, s2, s7                                   // 0000000029d8: 8b6a0702
	v_and_b16 v28.l, 0xff, v28.l                               // 0000000029dc: d762001c 020238ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000029e8: bf88ff9e
	v_cndmask_b32_e32 v29, 0, v29, vcc_lo                      // 0000000029ec: 023a3a80
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 0000000029f0: 023e3e80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000029f4: bf870122
	v_add_co_u32 v69, s3, s28, v29                             // 0000000029f8: d7000345 02023a1c
	s_wait_alu depctr_va_sdst(0)                               // 000000002a00: bf88f19f
	v_add_co_ci_u32_e64 v70, null, s29, v31, s3                // 000000002a04: d5207c46 000e3e1d
	global_load_d16_hi_u8 v28, v[69:70], off                   // 000000002a0c: ee08407c 0000001c 00000045
	s_wait_loadcnt 0x0                                         // 000000002a18: bfc00000
	v_cndmask_b16 v28.h, 0, v28.h, vcc_lo                      // 000000002a1c: d65d501c 01aa3880
	v_add_co_u32 v29, vcc_lo, v6, 6                            // 000000002a24: d7006a1d 02010d06
	s_wait_alu depctr_va_vcc(0)                                // 000000002a2c: bf88ff9d
	v_add_co_ci_u32_e64 v31, null, 0, v7, vcc_lo               // 000000002a30: d5207c1f 01aa0e80
	s_and_b32 vcc_lo, s2, s8                                   // 000000002a38: 8b6a0802
	v_lshlrev_b16 v28.h, 8, v28.h op_sel:[0,1,1]               // 000000002a3c: d738501c 02023888
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a44: bf88ff9e
	v_cndmask_b32_e32 v29, 0, v29, vcc_lo                      // 000000002a48: 023a3a80
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 000000002a4c: 023e3e80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000002a50: bf870122
	v_add_co_u32 v69, s3, s28, v29                             // 000000002a54: d7000345 02023a1c
	s_wait_alu depctr_va_sdst(0)                               // 000000002a5c: bf88f19f
	v_add_co_ci_u32_e64 v70, null, s29, v31, s3                // 000000002a60: d5207c46 000e3e1d
	global_load_d16_u8 v29, v[69:70], off                      // 000000002a68: ee07807c 0000001d 00000045
	s_wait_loadcnt 0x0                                         // 000000002a74: bfc00000
	v_cndmask_b16 v29.l, 0, v29.l, vcc_lo                      // 000000002a78: d65d001d 01aa3a80
	v_add_co_u32 v31, vcc_lo, v6, 7                            // 000000002a80: d7006a1f 02010f06
	s_wait_alu depctr_va_vcc(0)                                // 000000002a88: bf88ff9d
	v_add_co_ci_u32_e64 v33, null, 0, v7, vcc_lo               // 000000002a8c: d5207c21 01aa0e80
	s_and_b32 vcc_lo, s2, s9                                   // 000000002a94: 8b6a0902
	v_and_b16 v29.l, 0xff, v29.l                               // 000000002a98: d762001d 02023aff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000002aa4: bf88ff9e
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 000000002aa8: 023e3e80
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000002aac: 02424280
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000002ab0: bf870122
	v_add_co_u32 v69, s3, s28, v31                             // 000000002ab4: d7000345 02023e1c
	s_wait_alu depctr_va_sdst(0)                               // 000000002abc: bf88f19f
	v_add_co_ci_u32_e64 v70, null, s29, v33, s3                // 000000002ac0: d5207c46 000e421d
	global_load_d16_hi_u8 v29, v[69:70], off                   // 000000002ac8: ee08407c 0000001d 00000045
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[85:86], v[77:78], 0// 000000002ad4: cc464045 1a029b55
	s_wait_loadcnt 0x0                                         // 000000002adc: bfc00000
	v_cndmask_b16 v29.h, 0, v29.h, vcc_lo                      // 000000002ae0: d65d501d 01aa3a80
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002ae8: bf870091
	v_lshlrev_b16 v29.h, 8, v29.h op_sel:[0,1,1]               // 000000002aec: d738501d 02023a88
	v_or_b16 v29.h, v29.l, v29.h op_sel:[0,1,1]                // 000000002af4: d763501d 02023b1d
	v_or_b16 v29.l, v28.l, v28.h op_sel:[0,1,0]                // 000000002afc: d763101d 0202391c
	v_or_b16 v28.l, v26.l, v26.h op_sel:[0,1,0]                // 000000002b04: d763101c 0202351a
	v_add_co_u32 v26, vcc_lo, s46, v53                         // 000000002b0c: d7006a1a 02026a2e
	v_or_b16 v28.h, v27.l, v27.h op_sel:[0,1,1]                // 000000002b14: d763501c 0202371b
	s_wait_alu depctr_va_vcc(0)                                // 000000002b1c: bf88ff9d
	v_add_co_ci_u32_e64 v27, null, s47, v54, vcc_lo            // 000000002b20: d5207c1b 01aa6c2f
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_1)// 000000002b28: bf8700d2
	v_wmma_f32_16x16x16_fp8_fp8 v[77:84], v[85:86], v[28:29], 0// 000000002b2c: cc46404d 1a023955
	global_load_b64 v[26:27], v[26:27], off offset:-4          // 000000002b34: ee05407c 0000001a fffffc1a
	global_load_b32 v85, v[22:23], off                         // 000000002b40: ee05007c 00000055 00000016
	s_wait_loadcnt 0x0                                         // 000000002b4c: bfc00000
	v_mul_f32_e32 v28, v26, v85                                // 000000002b50: 1038ab1a
	v_mul_f32_e32 v28, v69, v28                                // 000000002b54: 10383945
	s_delay_alu instid0(valu_dep_1)                            // 000000002b58: bf870001
	v_add_f32_e32 v13, v13, v28                                // 000000002b5c: 061a390d
	v_add_co_u32 v28, vcc_lo, s46, v55                         // 000000002b60: d7006a1c 02026e2e
	s_wait_alu depctr_va_vcc(0)                                // 000000002b68: bf88ff9d
	v_add_co_ci_u32_e64 v29, null, s47, v56, vcc_lo            // 000000002b6c: d5207c1d 01aa702f
	global_load_b64 v[28:29], v[28:29], off offset:-4          // 000000002b74: ee05407c 0000001c fffffc1c
	s_wait_loadcnt 0x0                                         // 000000002b80: bfc00000
	v_mul_f32_e32 v31, v85, v28                                // 000000002b84: 103e3955
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002b88: bf870091
	v_mul_f32_e32 v31, v70, v31                                // 000000002b8c: 103e3f46
	v_add_f32_e32 v69, v30, v31                                // 000000002b90: 068a3f1e
	v_add_co_u32 v30, vcc_lo, s46, v57                         // 000000002b94: d7006a1e 0202722e
	s_wait_alu depctr_va_vcc(0)                                // 000000002b9c: bf88ff9d
	v_add_co_ci_u32_e64 v31, null, s47, v58, vcc_lo            // 000000002ba0: d5207c1f 01aa742f
	global_load_b64 v[30:31], v[30:31], off offset:-4          // 000000002ba8: ee05407c 0000001e fffffc1e
	s_wait_loadcnt 0x0                                         // 000000002bb4: bfc00000
	v_mul_f32_e32 v33, v85, v30                                // 000000002bb8: 10423d55
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002bbc: bf870091
	v_mul_f32_e32 v33, v71, v33                                // 000000002bc0: 10424347
	v_add_f32_e32 v70, v32, v33                                // 000000002bc4: 068c4320
	v_add_co_u32 v32, vcc_lo, s46, v59                         // 000000002bc8: d7006a20 0202762e
	s_wait_alu depctr_va_vcc(0)                                // 000000002bd0: bf88ff9d
	v_add_co_ci_u32_e64 v33, null, s47, v60, vcc_lo            // 000000002bd4: d5207c21 01aa782f
	global_load_b64 v[32:33], v[32:33], off offset:-4          // 000000002bdc: ee05407c 00000020 fffffc20
	s_wait_loadcnt 0x0                                         // 000000002be8: bfc00000
	v_mul_f32_e32 v35, v85, v32                                // 000000002bec: 10464155
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002bf0: bf870091
	v_mul_f32_e32 v35, v72, v35                                // 000000002bf4: 10464748
	v_add_f32_e32 v86, v34, v35                                // 000000002bf8: 06ac4722
	v_add_co_u32 v34, vcc_lo, s46, v61                         // 000000002bfc: d7006a22 02027a2e
	s_wait_alu depctr_va_vcc(0)                                // 000000002c04: bf88ff9d
	v_add_co_ci_u32_e64 v35, null, s47, v62, vcc_lo            // 000000002c08: d5207c23 01aa7c2f
	global_load_b64 v[34:35], v[34:35], off offset:-4          // 000000002c10: ee05407c 00000022 fffffc22
	s_wait_loadcnt 0x0                                         // 000000002c1c: bfc00000
	v_mul_f32_e32 v37, v85, v34                                // 000000002c20: 104a4555
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002c24: bf870091
	v_mul_f32_e32 v37, v73, v37                                // 000000002c28: 104a4b49
	v_add_f32_e32 v87, v36, v37                                // 000000002c2c: 06ae4b24
	v_add_co_u32 v36, vcc_lo, s46, v63                         // 000000002c30: d7006a24 02027e2e
	s_wait_alu depctr_va_vcc(0)                                // 000000002c38: bf88ff9d
	v_add_co_ci_u32_e64 v37, null, s47, v64, vcc_lo            // 000000002c3c: d5207c25 01aa802f
	global_load_b64 v[36:37], v[36:37], off offset:-4          // 000000002c44: ee05407c 00000024 fffffc24
	s_wait_loadcnt 0x0                                         // 000000002c50: bfc00000
	v_mul_f32_e32 v39, v85, v36                                // 000000002c54: 104e4955
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002c58: bf870091
	v_mul_f32_e32 v39, v74, v39                                // 000000002c5c: 104e4f4a
	v_add_f32_e32 v88, v38, v39                                // 000000002c60: 06b04f26
	v_add_co_u32 v38, vcc_lo, s46, v65                         // 000000002c64: d7006a26 0202822e
	s_wait_alu depctr_va_vcc(0)                                // 000000002c6c: bf88ff9d
	v_add_co_ci_u32_e64 v39, null, s47, v66, vcc_lo            // 000000002c70: d5207c27 01aa842f
	global_load_b64 v[38:39], v[38:39], off offset:-4          // 000000002c78: ee05407c 00000026 fffffc26
	s_wait_loadcnt 0x0                                         // 000000002c84: bfc00000
	v_mul_f32_e32 v41, v85, v38                                // 000000002c88: 10524d55
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002c8c: bf870091
	v_mul_f32_e32 v41, v75, v41                                // 000000002c90: 1052534b
	v_add_f32_e32 v89, v40, v41                                // 000000002c94: 06b25328
	v_add_co_u32 v40, vcc_lo, s46, v67                         // 000000002c98: d7006a28 0202862e
	s_wait_alu depctr_va_vcc(0)                                // 000000002ca0: bf88ff9d
	v_add_co_ci_u32_e64 v41, null, s47, v68, vcc_lo            // 000000002ca4: d5207c29 01aa882f
	s_add_nc_u64 s[46:47], s[46:47], 8                         // 000000002cac: a9ae882e
	global_load_b64 v[40:41], v[40:41], off offset:-4          // 000000002cb0: ee05407c 00000028 fffffc28
	s_wait_loadcnt 0x0                                         // 000000002cbc: bfc00000
	v_mul_f32_e32 v71, v85, v40                                // 000000002cc0: 108e5155
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002cc4: bf870091
	v_mul_f32_e32 v71, v76, v71                                // 000000002cc8: 108e8f4c
	v_add_f32_e32 v85, v44, v71                                // 000000002ccc: 06aa8f2c
	global_load_b32 v44, v[24:25], off                         // 000000002cd0: ee05007c 0000002c 00000018
	s_wait_loadcnt 0x0                                         // 000000002cdc: bfc00000
	v_mul_f32_e32 v26, v26, v44                                // 000000002ce0: 1034591a
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002ce4: bf870091
	v_mul_f32_e32 v26, v77, v26                                // 000000002ce8: 1034354d
	v_add_f32_e32 v52, v52, v26                                // 000000002cec: 06683534
	v_mul_f32_e32 v26, v28, v44                                // 000000002cf0: 1034591c
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002cf4: bf870091
	v_mul_f32_e32 v26, v78, v26                                // 000000002cf8: 1034354e
	v_dual_add_f32 v51, v51, v26 :: v_dual_mul_f32 v26, v30, v44// 000000002cfc: c9063533 331a591e
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002d04: bf870091
	v_mul_f32_e32 v26, v79, v26                                // 000000002d08: 1034354f
	v_add_f32_e32 v50, v50, v26                                // 000000002d0c: 06643532
	v_mul_f32_e32 v26, v32, v44                                // 000000002d10: 10345920
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002d14: bf870091
	v_mul_f32_e32 v26, v80, v26                                // 000000002d18: 10343550
	v_dual_add_f32 v49, v49, v26 :: v_dual_mul_f32 v26, v34, v44// 000000002d1c: c9063531 311a5922
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002d24: bf870091
	v_mul_f32_e32 v26, v81, v26                                // 000000002d28: 10343551
	v_add_f32_e32 v48, v48, v26                                // 000000002d2c: 06603530
	v_mul_f32_e32 v26, v36, v44                                // 000000002d30: 10345924
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002d34: bf870091
	v_mul_f32_e32 v26, v82, v26                                // 000000002d38: 10343552
	v_dual_add_f32 v47, v47, v26 :: v_dual_mul_f32 v26, v38, v44// 000000002d3c: c906352f 2f1a5926
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000002d44: bf870091
	v_mul_f32_e32 v26, v83, v26                                // 000000002d48: 10343553
	v_add_f32_e32 v28, v46, v26                                // 000000002d4c: 0638352e
	v_mul_f32_e32 v26, v40, v44                                // 000000002d50: 10345928
	v_add_co_u32 v44, vcc_lo, v0, 16                           // 000000002d54: d7006a2c 02012100
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000002d5c: bf870092
	v_mul_f32_e32 v26, v84, v26                                // 000000002d60: 10343554
	v_add_f32_e32 v26, v45, v26                                // 000000002d64: 0634352d
	s_wait_alu depctr_va_vcc(0)                                // 000000002d68: bf88ff9d
	v_add_co_ci_u32_e64 v45, null, 0, v1, vcc_lo               // 000000002d6c: d5207c2d 01aa0280
	v_add_co_u32 v30, vcc_lo, v2, 16                           // 000000002d74: d7006a1e 02012102
	s_wait_alu depctr_va_vcc(0)                                // 000000002d7c: bf88ff9d
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000002d80: d5207c20 01aa0680
	s_delay_alu instid0(valu_dep_3) | instskip(skip_4) | instid1(valu_dep_2)// 000000002d88: bf870153
	v_cmp_gt_i64_e32 vcc_lo, s[24:25], v[44:45]                // 000000002d8c: 7ca85818
	s_and_b32 s3, s0, vcc_lo                                   // 000000002d90: 8b036a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002d94: bf88ff9e
	v_cndmask_b32_e64 v30, 0, v30, s3                          // 000000002d98: d501001e 000e3c80
	v_cndmask_b32_e64 v32, 0, v32, s3                          // 000000002da0: d5010020 000e4080
	v_add_co_u32 v44, s4, s26, v30                             // 000000002da8: d700042c 02023c1a
	s_wait_alu depctr_va_sdst(0)                               // 000000002db0: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002db4: bf870002
	v_add_co_ci_u32_e64 v45, null, s27, v32, s4                // 000000002db8: d5207c2d 0012401b
	global_load_d16_u8 v30, v[44:45], off                      // 000000002dc0: ee07807c 0000001e 0000002c
	s_wait_loadcnt 0x0                                         // 000000002dcc: bfc00000
	v_cndmask_b16 v30.l, 0, v30.l, s3                          // 000000002dd0: d65d001e 000e3c80
	v_add_co_u32 v32, s3, v2, 17                               // 000000002dd8: d7000320 02012302
	s_wait_alu depctr_va_sdst(0)                               // 000000002de0: bf88f19f
	v_add_co_ci_u32_e64 v34, null, 0, v3, s3                   // 000000002de4: d5207c22 000e0680
	v_add_co_u32 v44, s3, v0, 17                               // 000000002dec: d700032c 02012300
	s_wait_alu depctr_va_sdst(0)                               // 000000002df4: bf88f19f
	v_add_co_ci_u32_e64 v45, null, 0, v1, s3                   // 000000002df8: d5207c2d 000e0280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_4) | instid1(valu_dep_2)// 000000002e00: bf870151
	v_cmp_gt_i64_e64 s3, s[24:25], v[44:45]                    // 000000002e04: d4540003 02025818
	s_and_b32 s4, s0, s3                                       // 000000002e0c: 8b040300
	s_wait_alu depctr_sa_sdst(0)                               // 000000002e10: bf88ff9e
	v_cndmask_b32_e64 v32, 0, v32, s4                          // 000000002e14: d5010020 00124080
	v_cndmask_b32_e64 v34, 0, v34, s4                          // 000000002e1c: d5010022 00124480
	v_add_co_u32 v44, s5, s26, v32                             // 000000002e24: d700052c 0202401a
	s_wait_alu depctr_va_sdst(0)                               // 000000002e2c: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002e30: bf870002
	v_add_co_ci_u32_e64 v45, null, s27, v34, s5                // 000000002e34: d5207c2d 0016441b
	global_load_d16_hi_u8 v30, v[44:45], off                   // 000000002e3c: ee08407c 0000001e 0000002c
	s_wait_loadcnt 0x0                                         // 000000002e48: bfc00000
	v_cndmask_b16 v30.h, 0, v30.h, s4                          // 000000002e4c: d65d501e 00123c80
	v_add_co_u32 v32, s4, v2, 18                               // 000000002e54: d7000420 02012502
	s_wait_alu depctr_va_sdst(0)                               // 000000002e5c: bf88f19f
	v_add_co_ci_u32_e64 v34, null, 0, v3, s4                   // 000000002e60: d5207c22 00120680
	v_add_co_u32 v44, s4, v0, 18                               // 000000002e68: d700042c 02012500
	s_wait_alu depctr_va_sdst(0)                               // 000000002e70: bf88f19f
	v_add_co_ci_u32_e64 v45, null, 0, v1, s4                   // 000000002e74: d5207c2d 00120280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_4) | instid1(valu_dep_2)// 000000002e7c: bf870151
	v_cmp_gt_i64_e64 s4, s[24:25], v[44:45]                    // 000000002e80: d4540004 02025818
	s_and_b32 s5, s0, s4                                       // 000000002e88: 8b050400
	s_wait_alu depctr_sa_sdst(0)                               // 000000002e8c: bf88ff9e
	v_cndmask_b32_e64 v32, 0, v32, s5                          // 000000002e90: d5010020 00164080
	v_cndmask_b32_e64 v34, 0, v34, s5                          // 000000002e98: d5010022 00164480
	v_add_co_u32 v44, s6, s26, v32                             // 000000002ea0: d700062c 0202401a
	s_wait_alu depctr_va_sdst(0)                               // 000000002ea8: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002eac: bf870002
	v_add_co_ci_u32_e64 v45, null, s27, v34, s6                // 000000002eb0: d5207c2d 001a441b
	global_load_d16_u8 v32, v[44:45], off                      // 000000002eb8: ee07807c 00000020 0000002c
	s_wait_loadcnt 0x0                                         // 000000002ec4: bfc00000
	v_cndmask_b16 v32.l, 0, v32.l, s5                          // 000000002ec8: d65d0020 00164080
	v_add_co_u32 v34, s5, v2, 19                               // 000000002ed0: d7000522 02012702
	s_wait_alu depctr_va_sdst(0)                               // 000000002ed8: bf88f19f
	v_add_co_ci_u32_e64 v36, null, 0, v3, s5                   // 000000002edc: d5207c24 00160680
	v_add_co_u32 v44, s5, v0, 19                               // 000000002ee4: d700052c 02012700
	s_wait_alu depctr_va_sdst(0)                               // 000000002eec: bf88f19f
	v_add_co_ci_u32_e64 v45, null, 0, v1, s5                   // 000000002ef0: d5207c2d 00160280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_4) | instid1(valu_dep_2)// 000000002ef8: bf870151
	v_cmp_gt_i64_e64 s5, s[24:25], v[44:45]                    // 000000002efc: d4540005 02025818
	s_and_b32 s6, s0, s5                                       // 000000002f04: 8b060500
	s_wait_alu depctr_sa_sdst(0)                               // 000000002f08: bf88ff9e
	v_cndmask_b32_e64 v34, 0, v34, s6                          // 000000002f0c: d5010022 001a4480
	v_cndmask_b32_e64 v36, 0, v36, s6                          // 000000002f14: d5010024 001a4880
	v_add_co_u32 v44, s7, s26, v34                             // 000000002f1c: d700072c 0202441a
	s_wait_alu depctr_va_sdst(0)                               // 000000002f24: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002f28: bf870002
	v_add_co_ci_u32_e64 v45, null, s27, v36, s7                // 000000002f2c: d5207c2d 001e481b
	global_load_d16_hi_u8 v32, v[44:45], off                   // 000000002f34: ee08407c 00000020 0000002c
	s_wait_loadcnt 0x0                                         // 000000002f40: bfc00000
	v_cndmask_b16 v32.h, 0, v32.h, s6                          // 000000002f44: d65d5020 001a4080
	v_add_co_u32 v34, s6, v2, 20                               // 000000002f4c: d7000622 02012902
	s_wait_alu depctr_va_sdst(0)                               // 000000002f54: bf88f19f
	v_add_co_ci_u32_e64 v36, null, 0, v3, s6                   // 000000002f58: d5207c24 001a0680
	v_add_co_u32 v44, s6, v0, 20                               // 000000002f60: d700062c 02012900
	s_wait_alu depctr_va_sdst(0)                               // 000000002f68: bf88f19f
	v_add_co_ci_u32_e64 v45, null, 0, v1, s6                   // 000000002f6c: d5207c2d 001a0280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_4) | instid1(valu_dep_2)// 000000002f74: bf870151
	v_cmp_gt_i64_e64 s6, s[24:25], v[44:45]                    // 000000002f78: d4540006 02025818
	s_and_b32 s7, s0, s6                                       // 000000002f80: 8b070600
	s_wait_alu depctr_sa_sdst(0)                               // 000000002f84: bf88ff9e
	v_cndmask_b32_e64 v34, 0, v34, s7                          // 000000002f88: d5010022 001e4480
	v_cndmask_b32_e64 v36, 0, v36, s7                          // 000000002f90: d5010024 001e4880
	v_add_co_u32 v44, s8, s26, v34                             // 000000002f98: d700082c 0202441a
	s_wait_alu depctr_va_sdst(0)                               // 000000002fa0: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000002fa4: bf870002
	v_add_co_ci_u32_e64 v45, null, s27, v36, s8                // 000000002fa8: d5207c2d 0022481b
	global_load_d16_u8 v34, v[44:45], off                      // 000000002fb0: ee07807c 00000022 0000002c
	s_wait_loadcnt 0x0                                         // 000000002fbc: bfc00000
	v_cndmask_b16 v34.l, 0, v34.l, s7                          // 000000002fc0: d65d0022 001e4480
	v_add_co_u32 v36, s7, v2, 21                               // 000000002fc8: d7000724 02012b02
	s_wait_alu depctr_va_sdst(0)                               // 000000002fd0: bf88f19f
	v_add_co_ci_u32_e64 v38, null, 0, v3, s7                   // 000000002fd4: d5207c26 001e0680
	v_add_co_u32 v44, s7, v0, 21                               // 000000002fdc: d700072c 02012b00
	s_wait_alu depctr_va_sdst(0)                               // 000000002fe4: bf88f19f
	v_add_co_ci_u32_e64 v45, null, 0, v1, s7                   // 000000002fe8: d5207c2d 001e0280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_4) | instid1(valu_dep_2)// 000000002ff0: bf870151
	v_cmp_gt_i64_e64 s7, s[24:25], v[44:45]                    // 000000002ff4: d4540007 02025818
	s_and_b32 s8, s0, s7                                       // 000000002ffc: 8b080700
	s_wait_alu depctr_sa_sdst(0)                               // 000000003000: bf88ff9e
	v_cndmask_b32_e64 v36, 0, v36, s8                          // 000000003004: d5010024 00224880
	v_cndmask_b32_e64 v38, 0, v38, s8                          // 00000000300c: d5010026 00224c80
	v_add_co_u32 v44, s9, s26, v36                             // 000000003014: d700092c 0202481a
	s_wait_alu depctr_va_sdst(0)                               // 00000000301c: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000003020: bf870002
	v_add_co_ci_u32_e64 v45, null, s27, v38, s9                // 000000003024: d5207c2d 00264c1b
	global_load_d16_hi_u8 v34, v[44:45], off                   // 00000000302c: ee08407c 00000022 0000002c
	s_wait_loadcnt 0x0                                         // 000000003038: bfc00000
	v_cndmask_b16 v34.h, 0, v34.h, s8                          // 00000000303c: d65d5022 00224480
	v_add_co_u32 v36, s8, v2, 22                               // 000000003044: d7000824 02012d02
	s_wait_alu depctr_va_sdst(0)                               // 00000000304c: bf88f19f
	v_add_co_ci_u32_e64 v38, null, 0, v3, s8                   // 000000003050: d5207c26 00220680
	v_add_co_u32 v44, s8, v0, 22                               // 000000003058: d700082c 02012d00
	s_wait_alu depctr_va_sdst(0)                               // 000000003060: bf88f19f
	v_add_co_ci_u32_e64 v45, null, 0, v1, s8                   // 000000003064: d5207c2d 00220280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_4) | instid1(valu_dep_2)// 00000000306c: bf870151
	v_cmp_gt_i64_e64 s8, s[24:25], v[44:45]                    // 000000003070: d4540008 02025818
	s_and_b32 s9, s0, s8                                       // 000000003078: 8b090800
	s_wait_alu depctr_sa_sdst(0)                               // 00000000307c: bf88ff9e
	v_cndmask_b32_e64 v36, 0, v36, s9                          // 000000003080: d5010024 00264880
	v_cndmask_b32_e64 v38, 0, v38, s9                          // 000000003088: d5010026 00264c80
	v_add_co_u32 v44, s10, s26, v36                            // 000000003090: d7000a2c 0202481a
	s_wait_alu depctr_va_sdst(0)                               // 000000003098: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 00000000309c: bf870002
	v_add_co_ci_u32_e64 v45, null, s27, v38, s10               // 0000000030a0: d5207c2d 002a4c1b
	global_load_d16_u8 v36, v[44:45], off                      // 0000000030a8: ee07807c 00000024 0000002c
	s_wait_loadcnt 0x0                                         // 0000000030b4: bfc00000
	v_cndmask_b16 v36.l, 0, v36.l, s9                          // 0000000030b8: d65d0024 00264880
	v_add_co_u32 v2, s9, v2, 23                                // 0000000030c0: d7000902 02012f02
	s_wait_alu depctr_va_sdst(0)                               // 0000000030c8: bf88f19f
	v_add_co_ci_u32_e64 v3, null, 0, v3, s9                    // 0000000030cc: d5207c03 00260680
	v_add_co_u32 v0, s9, v0, 23                                // 0000000030d4: d7000900 02012f00
	s_wait_alu depctr_va_sdst(0)                               // 0000000030dc: bf88f19f
	v_add_co_ci_u32_e64 v1, null, 0, v1, s9                    // 0000000030e0: d5207c01 00260280
	s_delay_alu instid0(valu_dep_1) | instskip(skip_4) | instid1(valu_dep_2)// 0000000030e8: bf870151
	v_cmp_gt_i64_e64 s9, s[24:25], v[0:1]                      // 0000000030ec: d4540009 02020018
	s_and_b32 s10, s0, s9                                      // 0000000030f4: 8b0a0900
	s_wait_alu depctr_sa_sdst(0)                               // 0000000030f8: bf88ff9e
	v_cndmask_b32_e64 v0, 0, v2, s10                           // 0000000030fc: d5010000 002a0480
	v_cndmask_b32_e64 v1, 0, v3, s10                           // 000000003104: d5010001 002a0680
	v_add_co_u32 v0, s11, s26, v0                              // 00000000310c: d7000b00 0202001a
	s_wait_alu depctr_va_sdst(0)                               // 000000003114: bf88f19f
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_1)// 000000003118: bf8700d2
	v_add_co_ci_u32_e64 v1, null, s27, v1, s11                 // 00000000311c: d5207c01 002e021b
	global_load_d16_u8 v0, v[0:1], off                         // 000000003124: ee07807c 00000000 00000000
	s_wait_loadcnt 0x0                                         // 000000003130: bfc00000
	v_and_b16 v0.h, 0xff, v36.l op_sel:[0,0,1]                 // 000000003134: d7624000 020248ff 000000ff
	v_cndmask_b16 v0.l, 0, v0.l, s10                           // 000000003140: d65d0000 002a0080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000003148: d7380000 02020088
	s_delay_alu instid0(valu_dep_1) | instskip(skip_2) | instid1(valu_dep_1)// 000000003150: bf8700b1
	v_or_b16 v45.h, v0.h, v0.l op_sel:[1,0,1]                  // 000000003154: d763482d 02020100
	v_lshlrev_b16 v0.l, 8, v34.h op_sel:[0,1,0]                // 00000000315c: d7381000 02024488
	v_and_b16 v0.h, 0xff, v34.l op_sel:[0,0,1]                 // 000000003164: d7624000 020244ff 000000ff
	v_or_b16 v45.l, v0.h, v0.l op_sel:[1,0,0]                  // 000000003170: d763082d 02020100
	v_lshlrev_b16 v0.l, 8, v32.h op_sel:[0,1,0]                // 000000003178: d7381000 02024088
	v_and_b16 v0.h, 0xff, v32.l op_sel:[0,0,1]                 // 000000003180: d7624000 020240ff 000000ff
	s_delay_alu instid0(valu_dep_1) | instskip(skip_2) | instid1(valu_dep_1)// 00000000318c: bf8700b1
	v_or_b16 v44.h, v0.h, v0.l op_sel:[1,0,1]                  // 000000003190: d763482c 02020100
	v_lshlrev_b16 v0.l, 8, v30.h op_sel:[0,1,0]                // 000000003198: d7381000 02023c88
	v_and_b16 v0.h, 0xff, v30.l op_sel:[0,0,1]                 // 0000000031a0: d7624000 02023cff 000000ff
	v_or_b16 v44.l, v0.h, v0.l op_sel:[1,0,0]                  // 0000000031ac: d763082c 02020100
	v_add_co_u32 v0, s10, v4, 16                               // 0000000031b4: d7000a00 02012104
	s_wait_alu depctr_va_sdst(0)                               // 0000000031bc: bf88f19f
	v_add_co_ci_u32_e64 v1, null, 0, v5, s10                   // 0000000031c0: d5207c01 002a0a80
	s_and_b32 s10, s1, vcc_lo                                  // 0000000031c8: 8b0a6a01
	s_and_b32 vcc_lo, s2, vcc_lo                               // 0000000031cc: 8b6a6a02
	s_wait_alu depctr_sa_sdst(0)                               // 0000000031d0: bf88ff9e
	v_cndmask_b32_e64 v0, 0, v0, s10                           // 0000000031d4: d5010000 002a0080
	v_cndmask_b32_e64 v1, 0, v1, s10                           // 0000000031dc: d5010001 002a0280
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000031e4: bf870122
	v_add_co_u32 v0, s11, s28, v0                              // 0000000031e8: d7000b00 0202001c
	s_wait_alu depctr_va_sdst(0)                               // 0000000031f0: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s29, v1, s11                 // 0000000031f4: d5207c01 002e021d
	global_load_d16_u8 v0, v[0:1], off                         // 0000000031fc: ee07807c 00000000 00000000
	s_wait_loadcnt 0x0                                         // 000000003208: bfc00000
	v_cndmask_b16 v0.l, 0, v0.l, s10                           // 00000000320c: d65d0000 002a0080
	v_add_co_u32 v1, s10, v4, 17                               // 000000003214: d7000a01 02012304
	s_wait_alu depctr_va_sdst(0)                               // 00000000321c: bf88f19f
	v_add_co_ci_u32_e64 v2, null, 0, v5, s10                   // 000000003220: d5207c02 002a0a80
	s_and_b32 s10, s1, s3                                      // 000000003228: 8b0a0301
	v_and_b16 v0.l, 0xff, v0.l                                 // 00000000322c: d7620000 020200ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003238: bf88ff9e
	v_cndmask_b32_e64 v1, 0, v1, s10                           // 00000000323c: d5010001 002a0280
	v_cndmask_b32_e64 v2, 0, v2, s10                           // 000000003244: d5010002 002a0480
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 00000000324c: bf870122
	v_add_co_u32 v1, s11, s28, v1                              // 000000003250: d7000b01 0202021c
	s_wait_alu depctr_va_sdst(0)                               // 000000003258: bf88f19f
	v_add_co_ci_u32_e64 v2, null, s29, v2, s11                 // 00000000325c: d5207c02 002e041d
	global_load_d16_hi_u8 v0, v[1:2], off                      // 000000003264: ee08407c 00000000 00000001
	s_wait_loadcnt 0x0                                         // 000000003270: bfc00000
	v_cndmask_b16 v0.h, 0, v0.h, s10                           // 000000003274: d65d5000 002a0080
	v_add_co_u32 v1, s10, v4, 18                               // 00000000327c: d7000a01 02012504
	s_wait_alu depctr_va_sdst(0)                               // 000000003284: bf88f19f
	v_add_co_ci_u32_e64 v2, null, 0, v5, s10                   // 000000003288: d5207c02 002a0a80
	s_and_b32 s10, s1, s4                                      // 000000003290: 8b0a0401
	v_lshlrev_b16 v0.h, 8, v0.h op_sel:[0,1,1]                 // 000000003294: d7385000 02020088
	s_wait_alu depctr_sa_sdst(0)                               // 00000000329c: bf88ff9e
	v_cndmask_b32_e64 v1, 0, v1, s10                           // 0000000032a0: d5010001 002a0280
	v_cndmask_b32_e64 v2, 0, v2, s10                           // 0000000032a8: d5010002 002a0480
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000032b0: bf870122
	v_add_co_u32 v1, s11, s28, v1                              // 0000000032b4: d7000b01 0202021c
	s_wait_alu depctr_va_sdst(0)                               // 0000000032bc: bf88f19f
	v_add_co_ci_u32_e64 v2, null, s29, v2, s11                 // 0000000032c0: d5207c02 002e041d
	global_load_d16_u8 v1, v[1:2], off                         // 0000000032c8: ee07807c 00000001 00000001
	s_wait_loadcnt 0x0                                         // 0000000032d4: bfc00000
	v_cndmask_b16 v1.l, 0, v1.l, s10                           // 0000000032d8: d65d0001 002a0280
	v_add_co_u32 v2, s10, v4, 19                               // 0000000032e0: d7000a02 02012704
	s_wait_alu depctr_va_sdst(0)                               // 0000000032e8: bf88f19f
	v_add_co_ci_u32_e64 v3, null, 0, v5, s10                   // 0000000032ec: d5207c03 002a0a80
	s_and_b32 s10, s1, s5                                      // 0000000032f4: 8b0a0501
	v_and_b16 v1.l, 0xff, v1.l                                 // 0000000032f8: d7620001 020202ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003304: bf88ff9e
	v_cndmask_b32_e64 v2, 0, v2, s10                           // 000000003308: d5010002 002a0480
	v_cndmask_b32_e64 v3, 0, v3, s10                           // 000000003310: d5010003 002a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000003318: bf870122
	v_add_co_u32 v2, s11, s28, v2                              // 00000000331c: d7000b02 0202041c
	s_wait_alu depctr_va_sdst(0)                               // 000000003324: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s29, v3, s11                 // 000000003328: d5207c03 002e061d
	global_load_d16_hi_u8 v1, v[2:3], off                      // 000000003330: ee08407c 00000001 00000002
	s_wait_loadcnt 0x0                                         // 00000000333c: bfc00000
	v_cndmask_b16 v1.h, 0, v1.h, s10                           // 000000003340: d65d5001 002a0280
	v_add_co_u32 v2, s10, v4, 20                               // 000000003348: d7000a02 02012904
	s_wait_alu depctr_va_sdst(0)                               // 000000003350: bf88f19f
	v_add_co_ci_u32_e64 v3, null, 0, v5, s10                   // 000000003354: d5207c03 002a0a80
	s_and_b32 s10, s1, s6                                      // 00000000335c: 8b0a0601
	v_lshlrev_b16 v1.h, 8, v1.h op_sel:[0,1,1]                 // 000000003360: d7385001 02020288
	s_wait_alu depctr_sa_sdst(0)                               // 000000003368: bf88ff9e
	v_cndmask_b32_e64 v2, 0, v2, s10                           // 00000000336c: d5010002 002a0480
	v_cndmask_b32_e64 v3, 0, v3, s10                           // 000000003374: d5010003 002a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 00000000337c: bf870122
	v_add_co_u32 v2, s11, s28, v2                              // 000000003380: d7000b02 0202041c
	s_wait_alu depctr_va_sdst(0)                               // 000000003388: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s29, v3, s11                 // 00000000338c: d5207c03 002e061d
	global_load_d16_u8 v2, v[2:3], off                         // 000000003394: ee07807c 00000002 00000002
	s_wait_loadcnt 0x0                                         // 0000000033a0: bfc00000
	v_cndmask_b16 v2.l, 0, v2.l, s10                           // 0000000033a4: d65d0002 002a0480
	v_add_co_u32 v3, s10, v4, 21                               // 0000000033ac: d7000a03 02012b04
	s_wait_alu depctr_va_sdst(0)                               // 0000000033b4: bf88f19f
	v_add_co_ci_u32_e64 v30, null, 0, v5, s10                  // 0000000033b8: d5207c1e 002a0a80
	s_and_b32 s10, s1, s7                                      // 0000000033c0: 8b0a0701
	v_and_b16 v2.l, 0xff, v2.l                                 // 0000000033c4: d7620002 020204ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000033d0: bf88ff9e
	v_cndmask_b32_e64 v3, 0, v3, s10                           // 0000000033d4: d5010003 002a0680
	v_cndmask_b32_e64 v30, 0, v30, s10                         // 0000000033dc: d501001e 002a3c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000033e4: bf870122
	v_add_co_u32 v71, s11, s28, v3                             // 0000000033e8: d7000b47 0202061c
	s_wait_alu depctr_va_sdst(0)                               // 0000000033f0: bf88f19f
	v_add_co_ci_u32_e64 v72, null, s29, v30, s11               // 0000000033f4: d5207c48 002e3c1d
	global_load_d16_hi_u8 v2, v[71:72], off                    // 0000000033fc: ee08407c 00000002 00000047
	s_wait_loadcnt 0x0                                         // 000000003408: bfc00000
	v_cndmask_b16 v2.h, 0, v2.h, s10                           // 00000000340c: d65d5002 002a0480
	v_add_co_u32 v3, s10, v4, 22                               // 000000003414: d7000a03 02012d04
	s_wait_alu depctr_va_sdst(0)                               // 00000000341c: bf88f19f
	v_add_co_ci_u32_e64 v30, null, 0, v5, s10                  // 000000003420: d5207c1e 002a0a80
	s_and_b32 s10, s1, s8                                      // 000000003428: 8b0a0801
	v_lshlrev_b16 v2.h, 8, v2.h op_sel:[0,1,1]                 // 00000000342c: d7385002 02020488
	s_wait_alu depctr_sa_sdst(0)                               // 000000003434: bf88ff9e
	v_cndmask_b32_e64 v3, 0, v3, s10                           // 000000003438: d5010003 002a0680
	v_cndmask_b32_e64 v30, 0, v30, s10                         // 000000003440: d501001e 002a3c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000003448: bf870122
	v_add_co_u32 v71, s11, s28, v3                             // 00000000344c: d7000b47 0202061c
	s_wait_alu depctr_va_sdst(0)                               // 000000003454: bf88f19f
	v_add_co_ci_u32_e64 v72, null, s29, v30, s11               // 000000003458: d5207c48 002e3c1d
	global_load_d16_u8 v3, v[71:72], off                       // 000000003460: ee07807c 00000003 00000047
	s_wait_loadcnt 0x0                                         // 00000000346c: bfc00000
	v_cndmask_b16 v3.l, 0, v3.l, s10                           // 000000003470: d65d0003 002a0680
	v_add_co_u32 v4, s10, v4, 23                               // 000000003478: d7000a04 02012f04
	s_wait_alu depctr_va_sdst(0)                               // 000000003480: bf88f19f
	v_add_co_ci_u32_e64 v5, null, 0, v5, s10                   // 000000003484: d5207c05 002a0a80
	s_and_b32 s10, s1, s9                                      // 00000000348c: 8b0a0901
	v_and_b16 v3.l, 0xff, v3.l                                 // 000000003490: d7620003 020206ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 00000000349c: bf88ff9e
	v_cndmask_b32_e64 v4, 0, v4, s10                           // 0000000034a0: d5010004 002a0880
	v_cndmask_b32_e64 v5, 0, v5, s10                           // 0000000034a8: d5010005 002a0a80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000034b0: bf870122
	v_add_co_u32 v4, s11, s28, v4                              // 0000000034b4: d7000b04 0202081c
	s_wait_alu depctr_va_sdst(0)                               // 0000000034bc: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s29, v5, s11                 // 0000000034c0: d5207c05 002e0a1d
	global_load_d16_hi_u8 v3, v[4:5], off                      // 0000000034c8: ee08407c 00000003 00000004
	v_or_b16 v4.l, v0.l, v0.h op_sel:[0,1,0]                   // 0000000034d4: d7631004 02020100
	v_or_b16 v4.h, v1.l, v1.h op_sel:[0,1,1]                   // 0000000034dc: d7635004 02020301
	v_or_b16 v5.l, v2.l, v2.h op_sel:[0,1,0]                   // 0000000034e4: d7631005 02020502
	s_wait_loadcnt 0x0                                         // 0000000034ec: bfc00000
	v_cndmask_b16 v3.h, 0, v3.h, s10                           // 0000000034f0: d65d5003 002a0680
	v_add_co_u32 v0, s10, v6, 16                               // 0000000034f8: d7000a00 02012106
	s_wait_alu depctr_va_sdst(0)                               // 000000003500: bf88f19f
	v_add_co_ci_u32_e64 v1, null, 0, v7, s10                   // 000000003504: d5207c01 002a0e80
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_2)// 00000000350c: bf870113
	v_lshlrev_b16 v3.h, 8, v3.h op_sel:[0,1,1]                 // 000000003510: d7385003 02020688
	v_dual_cndmask_b32 v0, 0, v0 :: v_dual_cndmask_b32 v1, 0, v1// 000000003518: ca520080 00000280
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003520: bf870112
	v_or_b16 v5.h, v3.l, v3.h op_sel:[0,1,1]                   // 000000003524: d7635005 02020703
	v_add_co_u32 v0, s10, s28, v0                              // 00000000352c: d7000a00 0202001c
	s_wait_alu depctr_va_sdst(0)                               // 000000003534: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000003538: bf870003
	v_add_co_ci_u32_e64 v1, null, s29, v1, s10                 // 00000000353c: d5207c01 002a021d
	global_load_d16_u8 v0, v[0:1], off                         // 000000003544: ee07807c 00000000 00000000
	s_wait_loadcnt 0x0                                         // 000000003550: bfc00000
	v_cndmask_b16 v0.l, 0, v0.l, vcc_lo                        // 000000003554: d65d0000 01aa0080
	v_add_co_u32 v1, vcc_lo, v6, 17                            // 00000000355c: d7006a01 02012306
	s_wait_alu depctr_va_vcc(0)                                // 000000003564: bf88ff9d
	v_add_co_ci_u32_e64 v2, null, 0, v7, vcc_lo                // 000000003568: d5207c02 01aa0e80
	s_and_b32 vcc_lo, s2, s3                                   // 000000003570: 8b6a0302
	v_and_b16 v0.l, 0xff, v0.l                                 // 000000003574: d7620000 020200ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003580: bf88ff9e
	v_dual_cndmask_b32 v1, 0, v1 :: v_dual_cndmask_b32 v2, 0, v2// 000000003584: ca520280 01020480
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 00000000358c: bf870121
	v_add_co_u32 v1, s3, s28, v1                               // 000000003590: d7000301 0202021c
	s_wait_alu depctr_va_sdst(0)                               // 000000003598: bf88f19f
	v_add_co_ci_u32_e64 v2, null, s29, v2, s3                  // 00000000359c: d5207c02 000e041d
	global_load_d16_hi_u8 v0, v[1:2], off                      // 0000000035a4: ee08407c 00000000 00000001
	s_wait_loadcnt 0x0                                         // 0000000035b0: bfc00000
	v_cndmask_b16 v0.h, 0, v0.h, vcc_lo                        // 0000000035b4: d65d5000 01aa0080
	v_add_co_u32 v1, vcc_lo, v6, 18                            // 0000000035bc: d7006a01 02012506
	s_wait_alu depctr_va_vcc(0)                                // 0000000035c4: bf88ff9d
	v_add_co_ci_u32_e64 v2, null, 0, v7, vcc_lo                // 0000000035c8: d5207c02 01aa0e80
	s_and_b32 vcc_lo, s2, s4                                   // 0000000035d0: 8b6a0402
	v_lshlrev_b16 v0.h, 8, v0.h op_sel:[0,1,1]                 // 0000000035d4: d7385000 02020088
	s_wait_alu depctr_sa_sdst(0)                               // 0000000035dc: bf88ff9e
	v_dual_cndmask_b32 v1, 0, v1 :: v_dual_cndmask_b32 v2, 0, v2// 0000000035e0: ca520280 01020480
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 0000000035e8: bf870112
	v_or_b16 v79.l, v0.l, v0.h op_sel:[0,1,0]                  // 0000000035ec: d763104f 02020100
	v_add_co_u32 v1, s3, s28, v1                               // 0000000035f4: d7000301 0202021c
	s_wait_alu depctr_va_sdst(0)                               // 0000000035fc: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000003600: bf870003
	v_add_co_ci_u32_e64 v2, null, s29, v2, s3                  // 000000003604: d5207c02 000e041d
	global_load_d16_u8 v1, v[1:2], off                         // 00000000360c: ee07807c 00000001 00000001
	s_wait_loadcnt 0x0                                         // 000000003618: bfc00000
	v_cndmask_b16 v1.l, 0, v1.l, vcc_lo                        // 00000000361c: d65d0001 01aa0280
	v_add_co_u32 v2, vcc_lo, v6, 19                            // 000000003624: d7006a02 02012706
	s_wait_alu depctr_va_vcc(0)                                // 00000000362c: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, 0, v7, vcc_lo                // 000000003630: d5207c03 01aa0e80
	s_and_b32 vcc_lo, s2, s5                                   // 000000003638: 8b6a0502
	v_and_b16 v1.l, 0xff, v1.l                                 // 00000000363c: d7620001 020202ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003648: bf88ff9e
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v3, 0, v3// 00000000364c: ca520480 02020680
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000003654: bf870121
	v_add_co_u32 v2, s3, s28, v2                               // 000000003658: d7000302 0202041c
	s_wait_alu depctr_va_sdst(0)                               // 000000003660: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s29, v3, s3                  // 000000003664: d5207c03 000e061d
	global_load_d16_hi_u8 v1, v[2:3], off                      // 00000000366c: ee08407c 00000001 00000002
	s_wait_loadcnt 0x0                                         // 000000003678: bfc00000
	v_cndmask_b16 v1.h, 0, v1.h, vcc_lo                        // 00000000367c: d65d5001 01aa0280
	v_add_co_u32 v2, vcc_lo, v6, 20                            // 000000003684: d7006a02 02012906
	s_wait_alu depctr_va_vcc(0)                                // 00000000368c: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, 0, v7, vcc_lo                // 000000003690: d5207c03 01aa0e80
	s_and_b32 vcc_lo, s2, s6                                   // 000000003698: 8b6a0602
	v_lshlrev_b16 v1.h, 8, v1.h op_sel:[0,1,1]                 // 00000000369c: d7385001 02020288
	s_wait_alu depctr_sa_sdst(0)                               // 0000000036a4: bf88ff9e
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v3, 0, v3// 0000000036a8: ca520480 02020680
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 0000000036b0: bf870112
	v_or_b16 v79.h, v1.l, v1.h op_sel:[0,1,1]                  // 0000000036b4: d763504f 02020301
	v_add_co_u32 v2, s3, s28, v2                               // 0000000036bc: d7000302 0202041c
	s_wait_alu depctr_va_sdst(0)                               // 0000000036c4: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 0000000036c8: bf870003
	v_add_co_ci_u32_e64 v3, null, s29, v3, s3                  // 0000000036cc: d5207c03 000e061d
	global_load_d16_u8 v2, v[2:3], off                         // 0000000036d4: ee07807c 00000002 00000002
	s_wait_loadcnt 0x0                                         // 0000000036e0: bfc00000
	v_cndmask_b16 v2.l, 0, v2.l, vcc_lo                        // 0000000036e4: d65d0002 01aa0480
	v_add_co_u32 v3, vcc_lo, v6, 21                            // 0000000036ec: d7006a03 02012b06
	s_wait_alu depctr_va_vcc(0)                                // 0000000036f4: bf88ff9d
	v_add_co_ci_u32_e64 v30, null, 0, v7, vcc_lo               // 0000000036f8: d5207c1e 01aa0e80
	s_and_b32 vcc_lo, s2, s7                                   // 000000003700: 8b6a0702
	v_and_b16 v2.l, 0xff, v2.l                                 // 000000003704: d7620002 020204ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000003710: bf88ff9e
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_cndmask_b32 v30, 0, v30// 000000003714: ca520680 031e3c80
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 00000000371c: bf870121
	v_add_co_u32 v71, s3, s28, v3                              // 000000003720: d7000347 0202061c
	s_wait_alu depctr_va_sdst(0)                               // 000000003728: bf88f19f
	v_add_co_ci_u32_e64 v72, null, s29, v30, s3                // 00000000372c: d5207c48 000e3c1d
	global_load_d16_hi_u8 v2, v[71:72], off                    // 000000003734: ee08407c 00000002 00000047
	s_wait_loadcnt 0x0                                         // 000000003740: bfc00000
	v_cndmask_b16 v2.h, 0, v2.h, vcc_lo                        // 000000003744: d65d5002 01aa0480
	v_add_co_u32 v3, vcc_lo, v6, 22                            // 00000000374c: d7006a03 02012d06
	s_wait_alu depctr_va_vcc(0)                                // 000000003754: bf88ff9d
	v_add_co_ci_u32_e64 v30, null, 0, v7, vcc_lo               // 000000003758: d5207c1e 01aa0e80
	s_and_b32 vcc_lo, s2, s8                                   // 000000003760: 8b6a0802
	v_lshlrev_b16 v2.h, 8, v2.h op_sel:[0,1,1]                 // 000000003764: d7385002 02020488
	s_wait_alu depctr_sa_sdst(0)                               // 00000000376c: bf88ff9e
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_cndmask_b32 v30, 0, v30// 000000003770: ca520680 031e3c80
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003778: bf870112
	v_or_b16 v80.l, v2.l, v2.h op_sel:[0,1,0]                  // 00000000377c: d7631050 02020502
	v_add_co_u32 v71, s3, s28, v3                              // 000000003784: d7000347 0202061c
	s_wait_alu depctr_va_sdst(0)                               // 00000000378c: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000003790: bf870003
	v_add_co_ci_u32_e64 v72, null, s29, v30, s3                // 000000003794: d5207c48 000e3c1d
	global_load_d16_u8 v3, v[71:72], off                       // 00000000379c: ee07807c 00000003 00000047
	v_wmma_f32_16x16x16_fp8_fp8 v[71:78], v[44:45], v[4:5], 0  // 0000000037a8: cc464047 1a02092c
	s_wait_loadcnt 0x0                                         // 0000000037b0: bfc00000
	v_cndmask_b16 v3.l, 0, v3.l, vcc_lo                        // 0000000037b4: d65d0003 01aa0680
	v_add_co_u32 v6, vcc_lo, v6, 23                            // 0000000037bc: d7006a06 02012f06
	s_wait_alu depctr_va_vcc(0)                                // 0000000037c4: bf88ff9d
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 0000000037c8: d5207c07 01aa0e80
	s_and_b32 vcc_lo, s2, s9                                   // 0000000037d0: 8b6a0902
	v_and_b16 v3.l, 0xff, v3.l                                 // 0000000037d4: d7620003 020206ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000037e0: bf88ff9e
	v_dual_cndmask_b32 v6, 0, v6 :: v_dual_cndmask_b32 v7, 0, v7// 0000000037e4: ca520c80 06060e80
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 0000000037ec: bf870121
	v_add_co_u32 v6, s3, s28, v6                               // 0000000037f0: d7000306 02020c1c
	s_wait_alu depctr_va_sdst(0)                               // 0000000037f8: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s29, v7, s3                  // 0000000037fc: d5207c07 000e0e1d
	v_cmp_ge_i64_e64 s3, s[44:45], s[22:23]                    // 000000003804: d4560003 02002c2c
	global_load_d16_hi_u8 v3, v[6:7], off                      // 00000000380c: ee08407c 00000003 00000006
	s_wait_loadcnt 0x0                                         // 000000003818: bfc00000
	v_cndmask_b16 v3.h, 0, v3.h, vcc_lo                        // 00000000381c: d65d5003 01aa0680
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003824: bf870091
	v_lshlrev_b16 v3.h, 8, v3.h op_sel:[0,1,1]                 // 000000003828: d7385003 02020688
	v_or_b16 v80.h, v3.l, v3.h op_sel:[0,1,1]                  // 000000003830: d7635050 02020703
	s_delay_alu instid0(valu_dep_1)                            // 000000003838: bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[44:45], v[79:80], 0  // 00000000383c: cc464000 1a029f2c
	v_add_co_u32 v44, vcc_lo, v22, s40                         // 000000003844: d7006a2c 02005116
	s_wait_alu depctr_va_vcc(0)                                // 00000000384c: bf88ff9d
	v_add_co_ci_u32_e64 v45, null, s41, v23, vcc_lo            // 000000003850: d5207c2d 01aa2e29
	global_load_b32 v44, v[44:45], off                         // 000000003858: ee05007c 0000002c 0000002c
	v_add_co_u32 v45, vcc_lo, v24, s40                         // 000000003864: d7006a2d 02005118
	s_wait_alu depctr_va_vcc(0)                                // 00000000386c: bf88ff9d
	v_add_co_ci_u32_e64 v46, null, s41, v25, vcc_lo            // 000000003870: d5207c2e 01aa3229
	v_add_co_u32 v22, vcc_lo, v22, s42                         // 000000003878: d7006a16 02005516
	s_wait_alu depctr_va_vcc(0)                                // 000000003880: bf88ff9d
	v_add_co_ci_u32_e64 v23, null, s43, v23, vcc_lo            // 000000003884: d5207c17 01aa2e2b
	global_load_b32 v45, v[45:46], off                         // 00000000388c: ee05007c 0000002d 0000002d
	v_add_co_u32 v24, vcc_lo, v24, s42                         // 000000003898: d7006a18 02005518
	s_wait_alu depctr_va_vcc(0)                                // 0000000038a0: bf88ff9d
	v_add_co_ci_u32_e64 v25, null, s43, v25, vcc_lo            // 0000000038a4: d5207c19 01aa322b
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000000038ac: 8b6a037e
	s_wait_loadcnt 0x1                                         // 0000000038b0: bfc00001
	v_mul_f32_e32 v30, v27, v44                                // 0000000038b4: 103c591b
	v_mul_f32_e32 v34, v44, v33                                // 0000000038b8: 1044432c
	v_mul_f32_e32 v36, v44, v35                                // 0000000038bc: 1048472c
	v_mul_f32_e32 v38, v44, v37                                // 0000000038c0: 104c4b2c
	v_mul_f32_e32 v40, v44, v39                                // 0000000038c4: 10504f2c
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 0000000038c8: bf870214
	v_mul_f32_e32 v34, v74, v34                                // 0000000038cc: 1044454a
	v_mul_f32_e32 v36, v75, v36                                // 0000000038d0: 1048494b
	s_wait_loadcnt 0x0                                         // 0000000038d4: bfc00000
	v_dual_mul_f32 v38, v76, v38 :: v_dual_mul_f32 v27, v27, v45// 0000000038d8: c8c64d4c 261a5b1b
	v_mul_f32_e32 v40, v77, v40                                // 0000000038e0: 1050514d
	v_add_f32_e32 v34, v86, v34                                // 0000000038e4: 06444556
	v_add_f32_e32 v36, v87, v36                                // 0000000038e8: 06484957
	s_delay_alu instid0(valu_dep_4) | instskip(skip_2) | instid1(valu_dep_2)// 0000000038ec: bf870134
	v_add_f32_e32 v38, v88, v38                                // 0000000038f0: 064c4d58
	v_mul_f32_e32 v0, v0, v27                                  // 0000000038f4: 10003700
	v_add_f32_e32 v40, v89, v40                                // 0000000038f8: 06505159
	v_add_f32_e32 v52, v52, v0                                 // 0000000038fc: 06680134
	v_mul_f32_e32 v0, v29, v45                                 // 000000003900: 10005b1d
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003904: bf870091
	v_mul_f32_e32 v0, v1, v0                                   // 000000003908: 10000101
	v_dual_mul_f32 v32, v44, v31 :: v_dual_add_f32 v51, v51, v0// 00000000390c: c8c83f2c 20320133
	v_mul_f32_e32 v0, v31, v45                                 // 000000003914: 10005b1f
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003918: bf870112
	v_mul_f32_e32 v32, v73, v32                                // 00000000391c: 10404149
	v_mul_f32_e32 v0, v2, v0                                   // 000000003920: 10000102
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003924: bf870112
	v_add_f32_e32 v32, v70, v32                                // 000000003928: 06404146
	v_add_f32_e32 v50, v50, v0                                 // 00000000392c: 06640132
	v_mul_f32_e32 v0, v33, v45                                 // 000000003930: 10005b21
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000003934: bf870091
	v_mul_f32_e32 v0, v3, v0                                   // 000000003938: 10000103
	v_dual_mul_f32 v30, v71, v30 :: v_dual_add_f32 v49, v49, v0// 00000000393c: c8c83d47 1e300131
	s_delay_alu instid0(valu_dep_1) | instskip(skip_2) | instid1(valu_dep_3)// 000000003944: bf8701b1
	v_dual_mul_f32 v0, v35, v45 :: v_dual_add_f32 v13, v13, v30// 000000003948: c8c85b23 000c3d0d
	v_mul_f32_e32 v30, v44, v29                                // 000000003950: 103c3b2c
	v_mul_f32_e32 v44, v44, v41                                // 000000003954: 1058532c
	v_mul_f32_e32 v0, v4, v0                                   // 000000003958: 10000104
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 00000000395c: bf870112
	v_mul_f32_e32 v44, v78, v44                                // 000000003960: 1058594e
	v_add_f32_e32 v48, v48, v0                                 // 000000003964: 06600130
	v_mul_f32_e32 v0, v37, v45                                 // 000000003968: 10005b25
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_2)// 00000000396c: bf870113
	v_add_f32_e32 v44, v85, v44                                // 000000003970: 06585955
	v_mul_f32_e32 v0, v5, v0                                   // 000000003974: 10000105
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_1)// 000000003978: bf8700a1
	v_dual_mul_f32 v30, v72, v30 :: v_dual_add_f32 v47, v47, v0// 00000000397c: c8c83d48 1e2e012f
	v_mul_f32_e32 v0, v39, v45                                 // 000000003984: 10005b27
	v_mul_f32_e32 v0, v6, v0                                   // 000000003988: 10000106
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_1)// 00000000398c: bf8700a1
	v_add_f32_e32 v46, v28, v0                                 // 000000003990: 065c011c
	v_mul_f32_e32 v0, v41, v45                                 // 000000003994: 10005b29
	v_mul_f32_e32 v0, v7, v0                                   // 000000003998: 10000107
	s_delay_alu instid0(valu_dep_1)                            // 00000000399c: bf870001
	v_dual_add_f32 v30, v69, v30 :: v_dual_add_f32 v45, v26, v0// 0000000039a0: c9083d45 1e2c011a
	s_wait_alu depctr_sa_sdst(0)                               // 0000000039a8: bf88ff9e
	s_cbranch_vccz 63909                                       // 0000000039ac: bfa3f9a5 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x544>
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v2, 3, v43      // 0000000039b0: ca220080 03025683
	v_cmp_lt_i64_e64 s0, s[22:23], s[20:21]                    // 0000000039b8: d4510000 02002816
	s_delay_alu instid0(valu_dep_2)                            // 0000000039c0: bf870002
	v_or_b32_e32 v0, s30, v2                                   // 0000000039c4: 3800041e
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000000039c8: 8b6a007e
	s_wait_alu depctr_sa_sdst(0)                               // 0000000039cc: bf88ff9e
	s_cbranch_vccnz 3                                          // 0000000039d0: bfa40003 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x1ee0>
	v_mov_b32_e32 v1, s31                                      // 0000000039d4: 7e02021f
	s_mov_b32 s0, 0                                            // 0000000039d8: be800080
	s_branch 1                                                 // 0000000039dc: bfa00001 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x1ee4>
	s_mov_b32 s0, -1                                           // 0000000039e0: be8000c1
	s_wait_alu depctr_sa_sdst(0)                               // 0000000039e4: bf88ff9e
	s_and_b32 s0, s0, exec_lo                                  // 0000000039e8: 8b007e00
	s_cselect_b32 s0, 1, 0                                     // 0000000039ec: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 0000000039f0: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 0000000039f4: bf078100
	s_cbranch_scc1 1087                                        // 0000000039f8: bfa2043f <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x2ff8>
	v_mov_b32_e32 v1, s31                                      // 0000000039fc: 7e02021f
	v_cmp_gt_i64_e64 s0, s[12:13], v[14:15]                    // 000000003a00: d4540000 02021c0c
	v_or_b32_e32 v4, 1, v0                                     // 000000003a08: 38080081
	v_or_b32_e32 v6, 2, v0                                     // 000000003a0c: 380c0082
	v_or_b32_e32 v53, 7, v0                                    // 000000003a10: 386a0087
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[0:1]                  // 000000003a14: 7ca8000c
	v_cmp_gt_i64_e64 s1, s[14:15], v[10:11]                    // 000000003a18: d4540001 0202140e
	v_cmp_gt_i64_e64 s2, s[14:15], v[8:9]                      // 000000003a20: d4540002 0202100e
	s_mov_b64 s[40:41], s[22:23]                               // 000000003a28: bea80116
	v_mov_b32_e32 v54, s31                                     // 000000003a2c: 7e6c021f
	s_wait_alu depctr_va_vcc(0)                                // 000000003a30: bf88ff9d
	v_dual_cndmask_b32 v14, 0, v0 :: v_dual_mov_b32 v5, s31    // 000000003a34: ca500080 0e04001f
	v_cndmask_b32_e32 v12, 0, v1, vcc_lo                       // 000000003a3c: 02180280
	v_cndmask_b32_e64 v17, 0, v9, s2                           // 000000003a40: d5010011 000a1280
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_4)// 000000003a48: bf870213
	v_mul_lo_u32 v16, s39, v14                                 // 000000003a4c: d72c0010 02021c27
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[4:5]                  // 000000003a54: 7ca8080c
	v_mov_b32_e32 v7, s31                                      // 000000003a58: 7e0e021f
	v_mul_lo_u32 v12, s38, v12                                 // 000000003a5c: d72c000c 02021826
	v_mad_co_u64_u32 v[14:15], null, s38, v14, 0               // 000000003a64: d6fe7c0e 02021c26
	s_wait_alu depctr_va_vcc(0)                                // 000000003a6c: bf88ff9d
	v_dual_cndmask_b32 v5, 0, v1 :: v_dual_cndmask_b32 v18, 0, v4// 000000003a70: ca520280 05120880
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[6:7]                  // 000000003a78: 7ca80c0c
	v_or_b32_e32 v4, 3, v0                                     // 000000003a7c: 38080083
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000003a80: bf870214
	v_add3_u32 v15, v15, v12, v16                              // 000000003a84: d655000f 0442190f
	v_mul_lo_u32 v20, s39, v18                                 // 000000003a8c: d72c0014 02022427
	v_mad_co_u64_u32 v[18:19], null, s38, v18, 0               // 000000003a94: d6fe7c12 02022426
	s_wait_alu depctr_va_vcc(0)                                // 000000003a9c: bf88ff9d
	v_cndmask_b32_e32 v12, 0, v1, vcc_lo                       // 000000003aa0: 02180280
	v_mul_lo_u32 v7, s38, v5                                   // 000000003aa4: d72c0007 02020a26
	v_mov_b32_e32 v5, s31                                      // 000000003aac: 7e0a021f
	v_cndmask_b32_e32 v21, 0, v6, vcc_lo                       // 000000003ab0: 022a0c80
	v_cndmask_b32_e64 v16, 0, v8, s2                           // 000000003ab4: d5010010 000a1080
	v_mul_lo_u32 v22, s38, v12                                 // 000000003abc: d72c0016 02021826
	s_delay_alu instid0(valu_dep_4)                            // 000000003ac4: bf870004
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[4:5]                  // 000000003ac8: 7ca8080c
	v_lshlrev_b64_e32 v[5:6], 2, v[14:15]                      // 000000003acc: 3e0a1c82
	v_add3_u32 v19, v19, v7, v20                               // 000000003ad0: d6550013 04520f13
	v_mul_lo_u32 v7, s39, v21                                  // 000000003ad8: d72c0007 02022a27
	v_mad_co_u64_u32 v[14:15], null, s38, v21, 0               // 000000003ae0: d6fe7c0e 02022a26
	v_lshlrev_b64_e32 v[16:17], 2, v[16:17]                    // 000000003ae8: 3e202082
	s_wait_alu depctr_va_vcc(0)                                // 000000003aec: bf88ff9d
	v_cndmask_b32_e32 v21, 0, v1, vcc_lo                       // 000000003af0: 022a0280
	v_cndmask_b32_e32 v23, 0, v4, vcc_lo                       // 000000003af4: 022e0880
	v_add_co_u32 v12, vcc_lo, s34, v5                          // 000000003af8: d7006a0c 02020a22
	v_lshlrev_b64_e32 v[4:5], 2, v[18:19]                      // 000000003b00: 3e082482
	v_or_b32_e32 v18, 4, v0                                    // 000000003b04: 38240084
	v_mov_b32_e32 v19, s31                                     // 000000003b08: 7e26021f
	s_wait_alu depctr_va_vcc(0)                                // 000000003b0c: bf88ff9d
	v_add_co_ci_u32_e64 v20, null, s35, v6, vcc_lo             // 000000003b10: d5207c14 01aa0c23
	v_add3_u32 v15, v15, v22, v7                               // 000000003b18: d655000f 041e2d0f
	v_mul_lo_u32 v25, s38, v21                                 // 000000003b20: d72c0019 02022a26
	v_add_co_u32 v21, vcc_lo, s34, v4                          // 000000003b28: d7006a15 02020822
	s_wait_alu depctr_va_vcc(0)                                // 000000003b30: bf88ff9d
	v_add_co_ci_u32_e64 v22, null, s35, v5, vcc_lo             // 000000003b34: d5207c16 01aa0a23
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[18:19]                // 000000003b3c: 7ca8240c
	v_or_b32_e32 v4, 5, v0                                     // 000000003b40: 38080085
	v_mov_b32_e32 v5, s31                                      // 000000003b44: 7e0a021f
	v_mul_lo_u32 v24, s39, v23                                 // 000000003b48: d72c0018 02022e27
	v_mad_co_u64_u32 v[6:7], null, s38, v23, 0                 // 000000003b50: d6fe7c06 02022e26
	v_lshlrev_b64_e32 v[14:15], 2, v[14:15]                    // 000000003b58: 3e1c1c82
	s_wait_alu depctr_va_vcc(0)                                // 000000003b5c: bf88ff9d
	v_dual_cndmask_b32 v19, 0, v1 :: v_dual_cndmask_b32 v18, 0, v18// 000000003b60: ca520280 13122480
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[4:5]                  // 000000003b68: 7ca8080c
	s_delay_alu instid0(valu_dep_3)                            // 000000003b6c: bf870003
	v_add_co_u32 v23, s3, s34, v14                             // 000000003b70: d7000317 02021c22
	v_add3_u32 v7, v7, v25, v24                                // 000000003b78: d6550007 04623307
	s_wait_alu depctr_va_sdst(0)                               // 000000003b80: bf88f19f
	v_add_co_ci_u32_e64 v24, null, s35, v15, s3                // 000000003b84: d5207c18 000e1e23
	v_or_b32_e32 v14, 6, v0                                    // 000000003b8c: 381c0086
	v_mov_b32_e32 v15, s31                                     // 000000003b90: 7e1e021f
	s_wait_alu depctr_va_vcc(0)                                // 000000003b94: bf88ff9d
	v_dual_cndmask_b32 v25, 0, v1 :: v_dual_cndmask_b32 v4, 0, v4// 000000003b98: ca520280 19040880
	v_lshlrev_b64_e32 v[5:6], 2, v[6:7]                        // 000000003ba0: 3e0a0c82
	v_mul_lo_u32 v7, s39, v18                                  // 000000003ba4: d72c0007 02022427
	v_mul_lo_u32 v29, s38, v19                                 // 000000003bac: d72c001d 02022626
	v_mad_co_u64_u32 v[18:19], null, s38, v18, 0               // 000000003bb4: d6fe7c12 02022426
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[14:15]                // 000000003bbc: 7ca81c0c
	v_mul_lo_u32 v31, s39, v4                                  // 000000003bc0: d72c001f 02020827
	v_mul_lo_u32 v33, s38, v25                                 // 000000003bc8: d72c0021 02023226
	v_mad_co_u64_u32 v[27:28], null, s38, v4, 0                // 000000003bd0: d6fe7c1b 02020826
	v_add_co_u32 v25, s3, s34, v5                              // 000000003bd8: d7000319 02020a22
	s_wait_alu depctr_va_vcc(0)                                // 000000003be0: bf88ff9d
	v_dual_cndmask_b32 v15, 0, v1 :: v_dual_cndmask_b32 v14, 0, v14// 000000003be4: ca520280 0f0e1c80
	v_add3_u32 v19, v19, v29, v7                               // 000000003bec: d6550013 041e3b13
	s_wait_alu depctr_va_sdst(0)                               // 000000003bf4: bf88f19f
	v_add_co_ci_u32_e64 v26, null, s35, v6, s3                 // 000000003bf8: d5207c1a 000e0c23
	v_add3_u32 v28, v28, v33, v31                              // 000000003c00: d655001c 047e431c
	v_cmp_gt_i64_e64 s3, s[12:13], v[53:54]                    // 000000003c08: d4540003 02026a0c
	v_mul_lo_u32 v29, s39, v14                                 // 000000003c10: d72c001d 02021c27
	v_mul_lo_u32 v31, s38, v15                                 // 000000003c18: d72c001f 02021e26
	v_mad_co_u64_u32 v[14:15], null, s38, v14, 0               // 000000003c20: d6fe7c0e 02021c26
	v_lshlrev_b64_e32 v[4:5], 2, v[18:19]                      // 000000003c28: 3e082482
	v_lshlrev_b64_e32 v[6:7], 2, v[27:28]                      // 000000003c2c: 3e0c3682
	s_wait_alu depctr_va_sdst(0)                               // 000000003c30: bf88f19f
	v_cndmask_b32_e64 v18, 0, v1, s3                           // 000000003c34: d5010012 000e0280
	v_cndmask_b32_e64 v19, 0, v53, s3                          // 000000003c3c: d5010013 000e6a80
	v_cndmask_b32_e64 v54, 0, v11, s1                          // 000000003c44: d5010036 00061680
	v_cndmask_b32_e64 v53, 0, v10, s1                          // 000000003c4c: d5010035 00061480
	v_add_co_u32 v27, vcc_lo, s34, v4                          // 000000003c54: d7006a1b 02020822
	v_add3_u32 v15, v15, v31, v29                              // 000000003c5c: d655000f 04763f0f
	s_wait_alu depctr_va_vcc(0)                                // 000000003c64: bf88ff9d
	v_add_co_ci_u32_e64 v28, null, s35, v5, vcc_lo             // 000000003c68: d5207c1c 01aa0a23
	v_add_co_u32 v29, vcc_lo, s34, v6                          // 000000003c70: d7006a1d 02020c22
	v_add_co_u32 v6, s3, s30, v42                              // 000000003c78: d7000306 0202541e
	v_mul_lo_u32 v33, s39, v19                                 // 000000003c80: d72c0021 02022627
	v_mul_lo_u32 v35, s38, v18                                 // 000000003c88: d72c0023 02022426
	v_mad_co_u64_u32 v[18:19], null, s38, v19, 0               // 000000003c90: d6fe7c12 02022626
	s_wait_alu depctr_va_vcc(0)                                // 000000003c98: bf88ff9d
	v_add_co_ci_u32_e64 v31, null, s35, v7, vcc_lo             // 000000003c9c: d5207c1f 01aa0e23
	s_wait_alu depctr_va_sdst(0)                               // 000000003ca4: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s31, 0, s3                   // 000000003ca8: d5207c07 000d001f
	v_lshlrev_b64_e32 v[4:5], 2, v[14:15]                      // 000000003cb0: 3e081c82
	v_mul_lo_u32 v41, s25, v6                                  // 000000003cb4: d72c0029 02020c19
	s_delay_alu instid0(valu_dep_3)                            // 000000003cbc: bf870003
	v_mul_lo_u32 v39, s24, v7                                  // 000000003cc0: d72c0027 02020e18
	v_add_co_u32 v7, s3, s36, v42                              // 000000003cc8: d7000307 02025424
	s_wait_alu depctr_va_sdst(0)                               // 000000003cd0: bf88f19f
	v_add_co_ci_u32_e64 v14, null, s37, 0, s3                  // 000000003cd4: d5207c0e 000d0025
	v_add3_u32 v19, v19, v35, v33                              // 000000003cdc: d6550013 04864713
	v_add_co_u32 v33, vcc_lo, s34, v4                          // 000000003ce4: d7006a21 02020822
	s_wait_alu depctr_va_vcc(0)                                // 000000003cec: bf88ff9d
	v_add_co_ci_u32_e64 v35, null, s35, v5, vcc_lo             // 000000003cf0: d5207c23 01aa0a23
	v_add_co_u32 v15, vcc_lo, v7, 16                           // 000000003cf8: d7006a0f 02012107
	s_wait_alu depctr_va_vcc(0)                                // 000000003d00: bf88ff9d
	v_add_co_ci_u32_e64 v37, null, 0, v14, vcc_lo              // 000000003d04: d5207c25 01aa1c80
	v_lshlrev_b64_e32 v[18:19], 2, v[18:19]                    // 000000003d0c: 3e242482
	v_mad_co_u64_u32 v[4:5], null, s24, v6, v[2:3]             // 000000003d10: d6fe7c04 040a0c18
	v_mul_lo_u32 v55, s24, v14                                 // 000000003d18: d72c0037 02021c18
	v_mul_lo_u32 v56, s25, v7                                  // 000000003d20: d72c0038 02020e19
	v_mad_co_u64_u32 v[6:7], null, s24, v7, v[2:3]             // 000000003d28: d6fe7c06 040a0e18
	v_mul_lo_u32 v57, s24, v37                                 // 000000003d30: d72c0039 02024a18
	v_mul_lo_u32 v58, s25, v15                                 // 000000003d38: d72c003a 02021e19
	v_mad_co_u64_u32 v[14:15], null, s24, v15, v[2:3]          // 000000003d40: d6fe7c0e 040a1e18
	v_add_co_u32 v3, vcc_lo, s34, v18                          // 000000003d48: d7006a03 02022422
	s_wait_alu depctr_va_vcc(0)                                // 000000003d50: bf88ff9d
	v_add_co_ci_u32_e64 v37, null, s35, v19, vcc_lo            // 000000003d54: d5207c25 01aa2623
	v_lshlrev_b64_e32 v[18:19], 2, v[53:54]                    // 000000003d5c: 3e246a82
	v_add3_u32 v5, v41, v5, v39                                // 000000003d60: d6550005 049e0b29
	v_add3_u32 v7, v56, v7, v55                                // 000000003d68: d6550007 04de0f38
	v_add3_u32 v15, v58, v15, v57                              // 000000003d70: d655000f 04e61f3a
	s_wait_alu depctr_sa_sdst(0)                               // 000000003d78: bf88ff9e
	v_add_co_u32 v55, s3, v2, s40                              // 000000003d7c: d7000337 02005102
	s_wait_alu depctr_va_sdst(0)                               // 000000003d84: bf88f19f
	v_add_co_ci_u32_e64 v56, null, 0, s41, s3                  // 000000003d88: d5207c38 000c5280
	v_add_co_u32 v59, vcc_lo, v4, s40                          // 000000003d90: d7006a3b 02005104
	s_wait_alu depctr_va_vcc(0)                                // 000000003d98: bf88ff9d
	v_add_co_ci_u32_e64 v60, null, s41, v5, vcc_lo             // 000000003d9c: d5207c3c 01aa0a29
	s_delay_alu instid0(valu_dep_3) | instskip(skip_4) | instid1(valu_dep_2)// 000000003da4: bf870153
	v_cmp_gt_i64_e32 vcc_lo, s[24:25], v[55:56]                // 000000003da8: 7ca86e18
	s_and_b32 s3, s0, vcc_lo                                   // 000000003dac: 8b036a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000003db0: bf88ff9e
	v_cndmask_b32_e64 v41, 0, v59, s3                          // 000000003db4: d5010029 000e7680
	v_cndmask_b32_e64 v39, 0, v60, s3                          // 000000003dbc: d5010027 000e7880
	v_add_co_u32 v53, s4, s26, v41                             // 000000003dc4: d7000435 0202521a
	s_wait_alu depctr_va_sdst(0)                               // 000000003dcc: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000003dd0: bf870002
	v_add_co_ci_u32_e64 v54, null, s27, v39, s4                // 000000003dd4: d5207c36 00124e1b
	global_load_d16_u8 v39, v[53:54], off                      // 000000003ddc: ee07807c 00000027 00000035
	s_wait_loadcnt 0x0                                         // 000000003de8: bfc00000
	v_cndmask_b16 v39.l, 0, v39.l, s3                          // 000000003dec: d65d0027 000e4e80
	v_add_co_u32 v41, s3, v59, 1                               // 000000003df4: d7000329 0201033b
	s_wait_alu depctr_va_sdst(0)                               // 000000003dfc: bf88f19f
	v_add_co_ci_u32_e64 v57, null, 0, v60, s3                  // 000000003e00: d5207c39 000e7880
	v_add_co_u32 v53, s3, v55, 1                               // 000000003e08: d7000335 02010337
	s_wait_alu depctr_va_sdst(0)                               // 000000003e10: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v56, s3                  // 000000003e14: d5207c36 000e7080
	v_and_b16 v39.l, 0xff, v39.l                               // 000000003e1c: d7620027 02024eff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000003e28: bf870152
	v_cmp_gt_i64_e64 s3, s[24:25], v[53:54]                    // 000000003e2c: d4540003 02026a18
	s_and_b32 s4, s0, s3                                       // 000000003e34: 8b040300
	s_wait_alu depctr_sa_sdst(0)                               // 000000003e38: bf88ff9e
	v_cndmask_b32_e64 v41, 0, v41, s4                          // 000000003e3c: d5010029 00125280
	v_cndmask_b32_e64 v54, 0, v57, s4                          // 000000003e44: d5010036 00127280
	v_add_co_u32 v53, s5, s26, v41                             // 000000003e4c: d7000535 0202521a
	s_wait_alu depctr_va_sdst(0)                               // 000000003e54: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000003e58: bf870002
	v_add_co_ci_u32_e64 v54, null, s27, v54, s5                // 000000003e5c: d5207c36 00166c1b
	global_load_d16_hi_u8 v39, v[53:54], off                   // 000000003e64: ee08407c 00000027 00000035
	s_wait_loadcnt 0x0                                         // 000000003e70: bfc00000
	v_cndmask_b16 v39.h, 0, v39.h, s4                          // 000000003e74: d65d5027 00124e80
	v_add_co_u32 v41, s4, v59, 2                               // 000000003e7c: d7000429 0201053b
	s_wait_alu depctr_va_sdst(0)                               // 000000003e84: bf88f19f
	v_add_co_ci_u32_e64 v57, null, 0, v60, s4                  // 000000003e88: d5207c39 00127880
	v_add_co_u32 v53, s4, v55, 2                               // 000000003e90: d7000435 02010537
	s_wait_alu depctr_va_sdst(0)                               // 000000003e98: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v56, s4                  // 000000003e9c: d5207c36 00127080
	v_lshlrev_b16 v39.h, 8, v39.h op_sel:[0,1,1]               // 000000003ea4: d7385027 02024e88
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003eac: bf870112
	v_cmp_gt_i64_e64 s4, s[24:25], v[53:54]                    // 000000003eb0: d4540004 02026a18
	v_or_b16 v69.l, v39.l, v39.h op_sel:[0,1,0]                // 000000003eb8: d7631045 02024f27
	s_and_b32 s5, s0, s4                                       // 000000003ec0: 8b050400
	s_wait_alu depctr_sa_sdst(0)                               // 000000003ec4: bf88ff9e
	v_cndmask_b32_e64 v41, 0, v41, s5                          // 000000003ec8: d5010029 00165280
	v_cndmask_b32_e64 v54, 0, v57, s5                          // 000000003ed0: d5010036 00167280
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000003ed8: bf870122
	v_add_co_u32 v53, s6, s26, v41                             // 000000003edc: d7000635 0202521a
	s_wait_alu depctr_va_sdst(0)                               // 000000003ee4: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s27, v54, s6                // 000000003ee8: d5207c36 001a6c1b
	global_load_d16_u8 v41, v[53:54], off                      // 000000003ef0: ee07807c 00000029 00000035
	s_wait_loadcnt 0x0                                         // 000000003efc: bfc00000
	v_cndmask_b16 v41.l, 0, v41.l, s5                          // 000000003f00: d65d0029 00165280
	v_add_co_u32 v57, s5, v59, 3                               // 000000003f08: d7000539 0201073b
	s_wait_alu depctr_va_sdst(0)                               // 000000003f10: bf88f19f
	v_add_co_ci_u32_e64 v58, null, 0, v60, s5                  // 000000003f14: d5207c3a 00167880
	v_add_co_u32 v53, s5, v55, 3                               // 000000003f1c: d7000535 02010737
	s_wait_alu depctr_va_sdst(0)                               // 000000003f24: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v56, s5                  // 000000003f28: d5207c36 00167080
	v_and_b16 v41.l, 0xff, v41.l                               // 000000003f30: d7620029 020252ff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000003f3c: bf870152
	v_cmp_gt_i64_e64 s5, s[24:25], v[53:54]                    // 000000003f40: d4540005 02026a18
	s_and_b32 s6, s0, s5                                       // 000000003f48: 8b060500
	s_wait_alu depctr_sa_sdst(0)                               // 000000003f4c: bf88ff9e
	v_cndmask_b32_e64 v53, 0, v57, s6                          // 000000003f50: d5010035 001a7280
	v_cndmask_b32_e64 v54, 0, v58, s6                          // 000000003f58: d5010036 001a7480
	v_add_co_u32 v53, s7, s26, v53                             // 000000003f60: d7000735 02026a1a
	s_wait_alu depctr_va_sdst(0)                               // 000000003f68: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000003f6c: bf870002
	v_add_co_ci_u32_e64 v54, null, s27, v54, s7                // 000000003f70: d5207c36 001e6c1b
	global_load_d16_hi_u8 v41, v[53:54], off                   // 000000003f78: ee08407c 00000029 00000035
	s_wait_loadcnt 0x0                                         // 000000003f84: bfc00000
	v_cndmask_b16 v41.h, 0, v41.h, s6                          // 000000003f88: d65d5029 001a5280
	v_add_co_u32 v57, s6, v59, 4                               // 000000003f90: d7000639 0201093b
	s_wait_alu depctr_va_sdst(0)                               // 000000003f98: bf88f19f
	v_add_co_ci_u32_e64 v58, null, 0, v60, s6                  // 000000003f9c: d5207c3a 001a7880
	v_add_co_u32 v53, s6, v55, 4                               // 000000003fa4: d7000635 02010937
	s_wait_alu depctr_va_sdst(0)                               // 000000003fac: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v56, s6                  // 000000003fb0: d5207c36 001a7080
	v_lshlrev_b16 v41.h, 8, v41.h op_sel:[0,1,1]               // 000000003fb8: d7385029 02025288
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000003fc0: bf870112
	v_cmp_gt_i64_e64 s6, s[24:25], v[53:54]                    // 000000003fc4: d4540006 02026a18
	v_or_b16 v69.h, v41.l, v41.h op_sel:[0,1,1]                // 000000003fcc: d7635045 02025329
	s_and_b32 s7, s0, s6                                       // 000000003fd4: 8b070600
	s_wait_alu depctr_sa_sdst(0)                               // 000000003fd8: bf88ff9e
	v_cndmask_b32_e64 v53, 0, v57, s7                          // 000000003fdc: d5010035 001e7280
	v_cndmask_b32_e64 v54, 0, v58, s7                          // 000000003fe4: d5010036 001e7480
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000003fec: bf870122
	v_add_co_u32 v53, s8, s26, v53                             // 000000003ff0: d7000835 02026a1a
	s_wait_alu depctr_va_sdst(0)                               // 000000003ff8: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s27, v54, s8                // 000000003ffc: d5207c36 00226c1b
	global_load_d16_u8 v53, v[53:54], off                      // 000000004004: ee07807c 00000035 00000035
	s_wait_loadcnt 0x0                                         // 000000004010: bfc00000
	v_cndmask_b16 v53.l, 0, v53.l, s7                          // 000000004014: d65d0035 001e6a80
	v_add_co_u32 v54, s7, v59, 5                               // 00000000401c: d7000736 02010b3b
	s_wait_alu depctr_va_sdst(0)                               // 000000004024: bf88f19f
	v_add_co_ci_u32_e64 v61, null, 0, v60, s7                  // 000000004028: d5207c3d 001e7880
	v_add_co_u32 v57, s7, v55, 5                               // 000000004030: d7000739 02010b37
	s_wait_alu depctr_va_sdst(0)                               // 000000004038: bf88f19f
	v_add_co_ci_u32_e64 v58, null, 0, v56, s7                  // 00000000403c: d5207c3a 001e7080
	v_and_b16 v53.l, 0xff, v53.l                               // 000000004044: d7620035 02026aff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000004050: bf870152
	v_cmp_gt_i64_e64 s7, s[24:25], v[57:58]                    // 000000004054: d4540007 02027218
	s_and_b32 s8, s0, s7                                       // 00000000405c: 8b080700
	s_wait_alu depctr_sa_sdst(0)                               // 000000004060: bf88ff9e
	v_cndmask_b32_e64 v54, 0, v54, s8                          // 000000004064: d5010036 00226c80
	v_cndmask_b32_e64 v58, 0, v61, s8                          // 00000000406c: d501003a 00227a80
	v_add_co_u32 v57, s9, s26, v54                             // 000000004074: d7000939 02026c1a
	s_wait_alu depctr_va_sdst(0)                               // 00000000407c: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000004080: bf870002
	v_add_co_ci_u32_e64 v58, null, s27, v58, s9                // 000000004084: d5207c3a 0026741b
	global_load_d16_hi_u8 v53, v[57:58], off                   // 00000000408c: ee08407c 00000035 00000039
	s_wait_loadcnt 0x0                                         // 000000004098: bfc00000
	v_cndmask_b16 v53.h, 0, v53.h, s8                          // 00000000409c: d65d5035 00226a80
	v_add_co_u32 v54, s8, v59, 6                               // 0000000040a4: d7000836 02010d3b
	s_wait_alu depctr_va_sdst(0)                               // 0000000040ac: bf88f19f
	v_add_co_ci_u32_e64 v61, null, 0, v60, s8                  // 0000000040b0: d5207c3d 00227880
	v_add_co_u32 v57, s8, v55, 6                               // 0000000040b8: d7000839 02010d37
	s_wait_alu depctr_va_sdst(0)                               // 0000000040c0: bf88f19f
	v_add_co_ci_u32_e64 v58, null, 0, v56, s8                  // 0000000040c4: d5207c3a 00227080
	v_lshlrev_b16 v53.h, 8, v53.h op_sel:[0,1,1]               // 0000000040cc: d7385035 02026a88
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 0000000040d4: bf870112
	v_cmp_gt_i64_e64 s8, s[24:25], v[57:58]                    // 0000000040d8: d4540008 02027218
	v_or_b16 v70.l, v53.l, v53.h op_sel:[0,1,0]                // 0000000040e0: d7631046 02026b35
	s_and_b32 s9, s0, s8                                       // 0000000040e8: 8b090800
	s_wait_alu depctr_sa_sdst(0)                               // 0000000040ec: bf88ff9e
	v_cndmask_b32_e64 v54, 0, v54, s9                          // 0000000040f0: d5010036 00266c80
	v_cndmask_b32_e64 v58, 0, v61, s9                          // 0000000040f8: d501003a 00267a80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000004100: bf870122
	v_add_co_u32 v57, s10, s26, v54                            // 000000004104: d7000a39 02026c1a
	s_wait_alu depctr_va_sdst(0)                               // 00000000410c: bf88f19f
	v_add_co_ci_u32_e64 v58, null, s27, v58, s10               // 000000004110: d5207c3a 002a741b
	global_load_d16_u8 v54, v[57:58], off                      // 000000004118: ee07807c 00000036 00000039
	s_wait_loadcnt 0x0                                         // 000000004124: bfc00000
	v_cndmask_b16 v54.l, 0, v54.l, s9                          // 000000004128: d65d0036 00266c80
	v_add_co_u32 v57, s9, v59, 7                               // 000000004130: d7000939 02010f3b
	s_wait_alu depctr_va_sdst(0)                               // 000000004138: bf88f19f
	v_add_co_ci_u32_e64 v58, null, 0, v60, s9                  // 00000000413c: d5207c3a 00267880
	v_add_co_u32 v55, s9, v55, 7                               // 000000004144: d7000937 02010f37
	s_wait_alu depctr_va_sdst(0)                               // 00000000414c: bf88f19f
	v_add_co_ci_u32_e64 v56, null, 0, v56, s9                  // 000000004150: d5207c38 00267080
	v_and_b16 v54.l, 0xff, v54.l                               // 000000004158: d7620036 02026cff 000000ff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_4) | instid1(valu_dep_2)// 000000004164: bf870152
	v_cmp_gt_i64_e64 s9, s[24:25], v[55:56]                    // 000000004168: d4540009 02026e18
	s_and_b32 s10, s0, s9                                      // 000000004170: 8b0a0900
	s_wait_alu depctr_sa_sdst(0)                               // 000000004174: bf88ff9e
	v_cndmask_b32_e64 v55, 0, v57, s10                         // 000000004178: d5010037 002a7280
	v_cndmask_b32_e64 v56, 0, v58, s10                         // 000000004180: d5010038 002a7480
	v_add_co_u32 v55, s11, s26, v55                            // 000000004188: d7000b37 02026e1a
	s_wait_alu depctr_va_sdst(0)                               // 000000004190: bf88f19f
	s_delay_alu instid0(valu_dep_2)                            // 000000004194: bf870002
	v_add_co_ci_u32_e64 v56, null, s27, v56, s11               // 000000004198: d5207c38 002e701b
	global_load_d16_hi_u8 v54, v[55:56], off                   // 0000000041a0: ee08407c 00000036 00000037
	s_wait_loadcnt 0x0                                         // 0000000041ac: bfc00000
	v_cndmask_b16 v54.h, 0, v54.h, s10                         // 0000000041b0: d65d5036 002a6c80
	v_add_co_u32 v56, s10, v6, s40                             // 0000000041b8: d7000a38 02005106
	s_wait_alu depctr_va_sdst(0)                               // 0000000041c0: bf88f19f
	v_add_co_ci_u32_e64 v57, null, s41, v7, s10                // 0000000041c4: d5207c39 002a0e29
	s_and_b32 s10, s2, vcc_lo                                  // 0000000041cc: 8b0a6a02
	v_lshlrev_b16 v54.h, 8, v54.h op_sel:[0,1,1]               // 0000000041d0: d7385036 02026c88
	s_wait_alu depctr_sa_sdst(0)                               // 0000000041d8: bf88ff9e
	v_cndmask_b32_e64 v41, 0, v56, s10                         // 0000000041dc: d5010029 002a7080
	v_cndmask_b32_e64 v39, 0, v57, s10                         // 0000000041e4: d5010027 002a7280
	s_and_b32 vcc_lo, s1, vcc_lo                               // 0000000041ec: 8b6a6a01
	v_or_b16 v70.h, v54.l, v54.h op_sel:[0,1,1]                // 0000000041f0: d7635046 02026d36
	s_delay_alu instid0(valu_dep_3)                            // 0000000041f8: bf870003
	v_add_co_u32 v53, s11, s28, v41                            // 0000000041fc: d7000b35 0202521c
	s_wait_alu depctr_va_sdst(0)                               // 000000004204: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s29, v39, s11               // 000000004208: d5207c36 002e4e1d
	global_load_d16_u8 v39, v[53:54], off                      // 000000004210: ee07807c 00000027 00000035
	s_wait_loadcnt 0x0                                         // 00000000421c: bfc00000
	v_cndmask_b16 v39.l, 0, v39.l, s10                         // 000000004220: d65d0027 002a4e80
	v_add_co_u32 v41, s10, v56, 1                              // 000000004228: d7000a29 02010338
	s_wait_alu depctr_va_sdst(0)                               // 000000004230: bf88f19f
	v_add_co_ci_u32_e64 v53, null, 0, v57, s10                 // 000000004234: d5207c35 002a7280
	s_and_b32 s10, s2, s3                                      // 00000000423c: 8b0a0302
	v_and_b16 v39.l, 0xff, v39.l                               // 000000004240: d7620027 02024eff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 00000000424c: bf88ff9e
	v_cndmask_b32_e64 v41, 0, v41, s10                         // 000000004250: d5010029 002a5280
	v_cndmask_b32_e64 v54, 0, v53, s10                         // 000000004258: d5010036 002a6a80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000004260: bf870122
	v_add_co_u32 v53, s11, s28, v41                            // 000000004264: d7000b35 0202521c
	s_wait_alu depctr_va_sdst(0)                               // 00000000426c: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s29, v54, s11               // 000000004270: d5207c36 002e6c1d
	global_load_d16_hi_u8 v39, v[53:54], off                   // 000000004278: ee08407c 00000027 00000035
	s_wait_loadcnt 0x0                                         // 000000004284: bfc00000
	v_cndmask_b16 v39.h, 0, v39.h, s10                         // 000000004288: d65d5027 002a4e80
	v_add_co_u32 v41, s10, v56, 2                              // 000000004290: d7000a29 02010538
	s_wait_alu depctr_va_sdst(0)                               // 000000004298: bf88f19f
	v_add_co_ci_u32_e64 v53, null, 0, v57, s10                 // 00000000429c: d5207c35 002a7280
	s_and_b32 s10, s2, s4                                      // 0000000042a4: 8b0a0402
	v_lshlrev_b16 v39.h, 8, v39.h op_sel:[0,1,1]               // 0000000042a8: d7385027 02024e88
	s_wait_alu depctr_sa_sdst(0)                               // 0000000042b0: bf88ff9e
	v_cndmask_b32_e64 v41, 0, v41, s10                         // 0000000042b4: d5010029 002a5280
	v_cndmask_b32_e64 v54, 0, v53, s10                         // 0000000042bc: d5010036 002a6a80
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000042c4: bf870193
	v_or_b16 v61.l, v39.l, v39.h op_sel:[0,1,0]                // 0000000042c8: d763103d 02024f27
	v_add_co_u32 v53, s11, s28, v41                            // 0000000042d0: d7000b35 0202521c
	s_wait_alu depctr_va_sdst(0)                               // 0000000042d8: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 0000000042dc: bf870003
	v_add_co_ci_u32_e64 v54, null, s29, v54, s11               // 0000000042e0: d5207c36 002e6c1d
	global_load_d16_u8 v41, v[53:54], off                      // 0000000042e8: ee07807c 00000029 00000035
	s_wait_loadcnt 0x0                                         // 0000000042f4: bfc00000
	v_cndmask_b16 v41.l, 0, v41.l, s10                         // 0000000042f8: d65d0029 002a5280
	v_add_co_u32 v53, s10, v56, 3                              // 000000004300: d7000a35 02010738
	s_wait_alu depctr_va_sdst(0)                               // 000000004308: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v57, s10                 // 00000000430c: d5207c36 002a7280
	s_and_b32 s10, s2, s5                                      // 000000004314: 8b0a0502
	v_and_b16 v41.l, 0xff, v41.l                               // 000000004318: d7620029 020252ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000004324: bf88ff9e
	v_cndmask_b32_e64 v53, 0, v53, s10                         // 000000004328: d5010035 002a6a80
	v_cndmask_b32_e64 v54, 0, v54, s10                         // 000000004330: d5010036 002a6c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000004338: bf870122
	v_add_co_u32 v53, s11, s28, v53                            // 00000000433c: d7000b35 02026a1c
	s_wait_alu depctr_va_sdst(0)                               // 000000004344: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s29, v54, s11               // 000000004348: d5207c36 002e6c1d
	global_load_d16_hi_u8 v41, v[53:54], off                   // 000000004350: ee08407c 00000029 00000035
	s_wait_loadcnt 0x0                                         // 00000000435c: bfc00000
	v_cndmask_b16 v41.h, 0, v41.h, s10                         // 000000004360: d65d5029 002a5280
	v_add_co_u32 v53, s10, v56, 4                              // 000000004368: d7000a35 02010938
	s_wait_alu depctr_va_sdst(0)                               // 000000004370: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v57, s10                 // 000000004374: d5207c36 002a7280
	s_and_b32 s10, s2, s6                                      // 00000000437c: 8b0a0602
	v_lshlrev_b16 v41.h, 8, v41.h op_sel:[0,1,1]               // 000000004380: d7385029 02025288
	s_wait_alu depctr_sa_sdst(0)                               // 000000004388: bf88ff9e
	v_cndmask_b32_e64 v53, 0, v53, s10                         // 00000000438c: d5010035 002a6a80
	v_cndmask_b32_e64 v54, 0, v54, s10                         // 000000004394: d5010036 002a6c80
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 00000000439c: bf870193
	v_or_b16 v61.h, v41.l, v41.h op_sel:[0,1,1]                // 0000000043a0: d763503d 02025329
	v_add_co_u32 v53, s11, s28, v53                            // 0000000043a8: d7000b35 02026a1c
	s_wait_alu depctr_va_sdst(0)                               // 0000000043b0: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 0000000043b4: bf870003
	v_add_co_ci_u32_e64 v54, null, s29, v54, s11               // 0000000043b8: d5207c36 002e6c1d
	global_load_d16_u8 v53, v[53:54], off                      // 0000000043c0: ee07807c 00000035 00000035
	s_wait_loadcnt 0x0                                         // 0000000043cc: bfc00000
	v_cndmask_b16 v53.l, 0, v53.l, s10                         // 0000000043d0: d65d0035 002a6a80
	v_add_co_u32 v54, s10, v56, 5                              // 0000000043d8: d7000a36 02010b38
	s_wait_alu depctr_va_sdst(0)                               // 0000000043e0: bf88f19f
	v_add_co_ci_u32_e64 v55, null, 0, v57, s10                 // 0000000043e4: d5207c37 002a7280
	s_and_b32 s10, s2, s7                                      // 0000000043ec: 8b0a0702
	v_and_b16 v53.l, 0xff, v53.l                               // 0000000043f0: d7620035 02026aff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000043fc: bf88ff9e
	v_cndmask_b32_e64 v54, 0, v54, s10                         // 000000004400: d5010036 002a6c80
	v_cndmask_b32_e64 v55, 0, v55, s10                         // 000000004408: d5010037 002a6e80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000004410: bf870122
	v_add_co_u32 v54, s11, s28, v54                            // 000000004414: d7000b36 02026c1c
	s_wait_alu depctr_va_sdst(0)                               // 00000000441c: bf88f19f
	v_add_co_ci_u32_e64 v55, null, s29, v55, s11               // 000000004420: d5207c37 002e6e1d
	global_load_d16_hi_u8 v53, v[54:55], off                   // 000000004428: ee08407c 00000035 00000036
	s_wait_loadcnt 0x0                                         // 000000004434: bfc00000
	v_cndmask_b16 v53.h, 0, v53.h, s10                         // 000000004438: d65d5035 002a6a80
	v_add_co_u32 v54, s10, v56, 6                              // 000000004440: d7000a36 02010d38
	s_wait_alu depctr_va_sdst(0)                               // 000000004448: bf88f19f
	v_add_co_ci_u32_e64 v55, null, 0, v57, s10                 // 00000000444c: d5207c37 002a7280
	s_and_b32 s10, s2, s8                                      // 000000004454: 8b0a0802
	v_lshlrev_b16 v53.h, 8, v53.h op_sel:[0,1,1]               // 000000004458: d7385035 02026a88
	s_wait_alu depctr_sa_sdst(0)                               // 000000004460: bf88ff9e
	v_cndmask_b32_e64 v54, 0, v54, s10                         // 000000004464: d5010036 002a6c80
	v_cndmask_b32_e64 v55, 0, v55, s10                         // 00000000446c: d5010037 002a6e80
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004474: bf870193
	v_or_b16 v62.l, v53.l, v53.h op_sel:[0,1,0]                // 000000004478: d763103e 02026b35
	v_add_co_u32 v54, s11, s28, v54                            // 000000004480: d7000b36 02026c1c
	s_wait_alu depctr_va_sdst(0)                               // 000000004488: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 00000000448c: bf870003
	v_add_co_ci_u32_e64 v55, null, s29, v55, s11               // 000000004490: d5207c37 002e6e1d
	global_load_d16_u8 v54, v[54:55], off                      // 000000004498: ee07807c 00000036 00000036
	s_wait_loadcnt 0x0                                         // 0000000044a4: bfc00000
	v_cndmask_b16 v54.l, 0, v54.l, s10                         // 0000000044a8: d65d0036 002a6c80
	v_add_co_u32 v55, s10, v56, 7                              // 0000000044b0: d7000a37 02010f38
	s_wait_alu depctr_va_sdst(0)                               // 0000000044b8: bf88f19f
	v_add_co_ci_u32_e64 v56, null, 0, v57, s10                 // 0000000044bc: d5207c38 002a7280
	s_and_b32 s10, s2, s9                                      // 0000000044c4: 8b0a0902
	v_and_b16 v54.l, 0xff, v54.l                               // 0000000044c8: d7620036 02026cff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000044d4: bf88ff9e
	v_cndmask_b32_e64 v55, 0, v55, s10                         // 0000000044d8: d5010037 002a6e80
	v_cndmask_b32_e64 v56, 0, v56, s10                         // 0000000044e0: d5010038 002a7080
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000044e8: bf870122
	v_add_co_u32 v55, s11, s28, v55                            // 0000000044ec: d7000b37 02026e1c
	s_wait_alu depctr_va_sdst(0)                               // 0000000044f4: bf88f19f
	v_add_co_ci_u32_e64 v56, null, s29, v56, s11               // 0000000044f8: d5207c38 002e701d
	global_load_d16_hi_u8 v54, v[55:56], off                   // 000000004500: ee08407c 00000036 00000037
	s_wait_loadcnt 0x0                                         // 00000000450c: bfc00000
	v_cndmask_b16 v54.h, 0, v54.h, s10                         // 000000004510: d65d5036 002a6c80
	v_add_co_u32 v56, s10, v14, s40                            // 000000004518: d7000a38 0200510e
	s_wait_alu depctr_va_sdst(0)                               // 000000004520: bf88f19f
	v_add_co_ci_u32_e64 v57, null, s41, v15, s10               // 000000004524: d5207c39 002a1e29
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 00000000452c: bf870193
	v_lshlrev_b16 v54.h, 8, v54.h op_sel:[0,1,1]               // 000000004530: d7385036 02026c88
	v_cndmask_b32_e32 v41, 0, v56, vcc_lo                      // 000000004538: 02527080
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 00000000453c: bf870193
	v_cndmask_b32_e32 v39, 0, v57, vcc_lo                      // 000000004540: 024e7280
	v_or_b16 v62.h, v54.l, v54.h op_sel:[0,1,1]                // 000000004544: d763503e 02026d36
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 00000000454c: bf8701a3
	v_add_co_u32 v53, s10, s28, v41                            // 000000004550: d7000a35 0202521c
	s_wait_alu depctr_va_sdst(0)                               // 000000004558: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s29, v39, s10               // 00000000455c: d5207c36 002a4e1d
	global_load_d16_u8 v39, v[53:54], off                      // 000000004564: ee07807c 00000027 00000035
	s_wait_loadcnt 0x0                                         // 000000004570: bfc00000
	v_cndmask_b16 v39.l, 0, v39.l, vcc_lo                      // 000000004574: d65d0027 01aa4e80
	v_add_co_u32 v41, vcc_lo, v56, 1                           // 00000000457c: d7006a29 02010338
	s_wait_alu depctr_va_vcc(0)                                // 000000004584: bf88ff9d
	v_add_co_ci_u32_e64 v53, null, 0, v57, vcc_lo              // 000000004588: d5207c35 01aa7280
	s_and_b32 vcc_lo, s1, s3                                   // 000000004590: 8b6a0301
	v_and_b16 v39.l, 0xff, v39.l                               // 000000004594: d7620027 02024eff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 0000000045a0: bf88ff9e
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000045a4: 02525280
	v_cndmask_b32_e32 v54, 0, v53, vcc_lo                      // 0000000045a8: 026c6a80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000045ac: bf870122
	v_add_co_u32 v53, s3, s28, v41                             // 0000000045b0: d7000335 0202521c
	s_wait_alu depctr_va_sdst(0)                               // 0000000045b8: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s29, v54, s3                // 0000000045bc: d5207c36 000e6c1d
	global_load_d16_hi_u8 v39, v[53:54], off                   // 0000000045c4: ee08407c 00000027 00000035
	s_wait_loadcnt 0x0                                         // 0000000045d0: bfc00000
	v_cndmask_b16 v39.h, 0, v39.h, vcc_lo                      // 0000000045d4: d65d5027 01aa4e80
	v_add_co_u32 v41, vcc_lo, v56, 2                           // 0000000045dc: d7006a29 02010538
	s_wait_alu depctr_va_vcc(0)                                // 0000000045e4: bf88ff9d
	v_add_co_ci_u32_e64 v53, null, 0, v57, vcc_lo              // 0000000045e8: d5207c35 01aa7280
	s_and_b32 vcc_lo, s1, s4                                   // 0000000045f0: 8b6a0401
	v_lshlrev_b16 v39.h, 8, v39.h op_sel:[0,1,1]               // 0000000045f4: d7385027 02024e88
	s_wait_alu depctr_sa_sdst(0)                               // 0000000045fc: bf88ff9e
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000004600: 02525280
	v_cndmask_b32_e32 v54, 0, v53, vcc_lo                      // 000000004604: 026c6a80
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004608: bf870193
	v_or_b16 v71.l, v39.l, v39.h op_sel:[0,1,0]                // 00000000460c: d7631047 02024f27
	v_add_co_u32 v53, s3, s28, v41                             // 000000004614: d7000335 0202521c
	s_wait_alu depctr_va_sdst(0)                               // 00000000461c: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000004620: bf870003
	v_add_co_ci_u32_e64 v54, null, s29, v54, s3                // 000000004624: d5207c36 000e6c1d
	global_load_d16_u8 v41, v[53:54], off                      // 00000000462c: ee07807c 00000029 00000035
	s_wait_loadcnt 0x0                                         // 000000004638: bfc00000
	v_cndmask_b16 v41.l, 0, v41.l, vcc_lo                      // 00000000463c: d65d0029 01aa5280
	v_add_co_u32 v53, vcc_lo, v56, 3                           // 000000004644: d7006a35 02010738
	s_wait_alu depctr_va_vcc(0)                                // 00000000464c: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, 0, v57, vcc_lo              // 000000004650: d5207c36 01aa7280
	s_and_b32 vcc_lo, s1, s5                                   // 000000004658: 8b6a0501
	v_and_b16 v41.l, 0xff, v41.l                               // 00000000465c: d7620029 020252ff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 000000004668: bf88ff9e
	v_dual_cndmask_b32 v53, 0, v53 :: v_dual_cndmask_b32 v54, 0, v54// 00000000466c: ca526a80 35366c80
	s_lshr_b64 s[4:5], s[40:41], 4                             // 000000004674: 85848428
	s_wait_alu depctr_sa_sdst(0)                               // 000000004678: bf88ff9e
	s_mul_u64 s[4:5], s[4:5], s[14:15]                         // 00000000467c: aa840e04
	s_delay_alu instid0(valu_dep_1)                            // 000000004680: bf870001
	v_add_co_u32 v53, s3, s28, v53                             // 000000004684: d7000335 02026a1c
	s_wait_alu depctr_va_sdst(0)                               // 00000000468c: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s29, v54, s3                // 000000004690: d5207c36 000e6c1d
	s_wait_alu depctr_sa_sdst(0)                               // 000000004698: bf88ff9e
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000000469c: 84848204
	s_wait_alu depctr_sa_sdst(0)                               // 0000000046a0: bf88ff9e
	s_add_nc_u64 s[4:5], s[18:19], s[4:5]                      // 0000000046a4: a9840412
	global_load_d16_hi_u8 v41, v[53:54], off                   // 0000000046a8: ee08407c 00000029 00000035
	s_wait_loadcnt 0x0                                         // 0000000046b4: bfc00000
	v_cndmask_b16 v41.h, 0, v41.h, vcc_lo                      // 0000000046b8: d65d5029 01aa5280
	v_add_co_u32 v53, vcc_lo, v56, 4                           // 0000000046c0: d7006a35 02010938
	s_wait_alu depctr_va_vcc(0)                                // 0000000046c8: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, 0, v57, vcc_lo              // 0000000046cc: d5207c36 01aa7280
	s_and_b32 vcc_lo, s1, s6                                   // 0000000046d4: 8b6a0601
	v_lshlrev_b16 v41.h, 8, v41.h op_sel:[0,1,1]               // 0000000046d8: d7385029 02025288
	s_wait_alu depctr_sa_sdst(0)                               // 0000000046e0: bf88ff9e
	v_dual_cndmask_b32 v53, 0, v53 :: v_dual_cndmask_b32 v54, 0, v54// 0000000046e4: ca526a80 35366c80
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 0000000046ec: bf870112
	v_or_b16 v71.h, v41.l, v41.h op_sel:[0,1,1]                // 0000000046f0: d7635047 02025329
	v_add_co_u32 v53, s3, s28, v53                             // 0000000046f8: d7000335 02026a1c
	s_wait_alu depctr_va_sdst(0)                               // 000000004700: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 000000004704: bf870003
	v_add_co_ci_u32_e64 v54, null, s29, v54, s3                // 000000004708: d5207c36 000e6c1d
	global_load_d16_u8 v53, v[53:54], off                      // 000000004710: ee07807c 00000035 00000035
	s_wait_loadcnt 0x0                                         // 00000000471c: bfc00000
	v_cndmask_b16 v53.l, 0, v53.l, vcc_lo                      // 000000004720: d65d0035 01aa6a80
	v_add_co_u32 v54, vcc_lo, v56, 5                           // 000000004728: d7006a36 02010b38
	s_wait_alu depctr_va_vcc(0)                                // 000000004730: bf88ff9d
	v_add_co_ci_u32_e64 v55, null, 0, v57, vcc_lo              // 000000004734: d5207c37 01aa7280
	s_and_b32 vcc_lo, s1, s7                                   // 00000000473c: 8b6a0701
	v_and_b16 v53.l, 0xff, v53.l                               // 000000004740: d7620035 02026aff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 00000000474c: bf88ff9e
	v_dual_cndmask_b32 v54, 0, v54 :: v_dual_cndmask_b32 v55, 0, v55// 000000004750: ca526c80 36366e80
	s_lshr_b64 s[6:7], s[40:41], 2                             // 000000004758: 85868228
	s_add_nc_u64 s[40:41], s[40:41], 16                        // 00000000475c: a9a89028
	s_delay_alu instid0(valu_dep_1)                            // 000000004760: bf870001
	v_add_co_u32 v54, s3, s28, v54                             // 000000004764: d7000336 02026c1c
	s_wait_alu depctr_va_sdst(0)                               // 00000000476c: bf88f19f
	v_add_co_ci_u32_e64 v55, null, s29, v55, s3                // 000000004770: d5207c37 000e6e1d
	global_load_d16_hi_u8 v53, v[54:55], off                   // 000000004778: ee08407c 00000035 00000036
	s_wait_loadcnt 0x0                                         // 000000004784: bfc00000
	v_cndmask_b16 v53.h, 0, v53.h, vcc_lo                      // 000000004788: d65d5035 01aa6a80
	v_add_co_u32 v54, vcc_lo, v56, 6                           // 000000004790: d7006a36 02010d38
	s_wait_alu depctr_va_vcc(0)                                // 000000004798: bf88ff9d
	v_add_co_ci_u32_e64 v55, null, 0, v57, vcc_lo              // 00000000479c: d5207c37 01aa7280
	s_and_b32 vcc_lo, s1, s8                                   // 0000000047a4: 8b6a0801
	v_lshlrev_b16 v53.h, 8, v53.h op_sel:[0,1,1]               // 0000000047a8: d7385035 02026a88
	s_wait_alu depctr_sa_sdst(0)                               // 0000000047b0: bf88ff9e
	v_dual_cndmask_b32 v54, 0, v54 :: v_dual_cndmask_b32 v55, 0, v55// 0000000047b4: ca526c80 36366e80
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 0000000047bc: bf870112
	v_or_b16 v72.l, v53.l, v53.h op_sel:[0,1,0]                // 0000000047c0: d7631048 02026b35
	v_add_co_u32 v54, s3, s28, v54                             // 0000000047c8: d7000336 02026c1c
	s_wait_alu depctr_va_sdst(0)                               // 0000000047d0: bf88f19f
	s_delay_alu instid0(valu_dep_3)                            // 0000000047d4: bf870003
	v_add_co_ci_u32_e64 v55, null, s29, v55, s3                // 0000000047d8: d5207c37 000e6e1d
	global_load_d16_u8 v54, v[54:55], off                      // 0000000047e0: ee07807c 00000036 00000036
	s_wait_loadcnt 0x0                                         // 0000000047ec: bfc00000
	v_cndmask_b16 v54.l, 0, v54.l, vcc_lo                      // 0000000047f0: d65d0036 01aa6c80
	v_add_co_u32 v55, vcc_lo, v56, 7                           // 0000000047f8: d7006a37 02010f38
	s_wait_alu depctr_va_vcc(0)                                // 000000004800: bf88ff9d
	v_add_co_ci_u32_e64 v56, null, 0, v57, vcc_lo              // 000000004804: d5207c38 01aa7280
	s_and_b32 vcc_lo, s1, s9                                   // 00000000480c: 8b6a0901
	v_and_b16 v54.l, 0xff, v54.l                               // 000000004810: d7620036 02026cff 000000ff
	s_wait_alu depctr_sa_sdst(0)                               // 00000000481c: bf88ff9e
	v_dual_cndmask_b32 v55, 0, v55 :: v_dual_cndmask_b32 v56, 0, v56// 000000004820: ca526e80 37387080
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000004828: bf870121
	v_add_co_u32 v55, s3, s28, v55                             // 00000000482c: d7000337 02026e1c
	s_wait_alu depctr_va_sdst(0)                               // 000000004834: bf88f19f
	v_add_co_ci_u32_e64 v56, null, s29, v56, s3                // 000000004838: d5207c38 000e701d
	v_cmp_lt_i64_e64 s3, s[40:41], s[20:21]                    // 000000004840: d4510003 02002828
	global_load_d16_hi_u8 v54, v[55:56], off                   // 000000004848: ee08407c 00000036 00000037
	s_wait_loadcnt 0x0                                         // 000000004854: bfc00000
	v_cndmask_b16 v54.h, 0, v54.h, vcc_lo                      // 000000004858: d65d5036 01aa6c80
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004860: bf870091
	v_lshlrev_b16 v54.h, 8, v54.h op_sel:[0,1,1]               // 000000004864: d7385036 02026c88
	v_or_b16 v72.h, v54.l, v54.h op_sel:[0,1,1]                // 00000000486c: d7635048 02026d36
	v_wmma_f32_16x16x16_fp8_fp8 v[53:60], v[69:70], v[61:62], 0// 000000004874: cc464035 1a027b45
	s_delay_alu instid0(valu_dep_2)                            // 00000000487c: bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[61:68], v[69:70], v[71:72], 0// 000000004880: cc46403d 1a028f45
	v_add_co_u32 v69, vcc_lo, v12, s6                          // 000000004888: d7006a45 02000d0c
	s_wait_alu depctr_va_vcc(0)                                // 000000004890: bf88ff9d
	v_add_co_ci_u32_e64 v70, null, s7, v20, vcc_lo             // 000000004894: d5207c46 01aa2807
	global_load_b32 v39, v[69:70], off                         // 00000000489c: ee05007c 00000027 00000045
	v_add_co_u32 v69, vcc_lo, s4, v16                          // 0000000048a8: d7006a45 02022004
	s_wait_alu depctr_va_vcc(0)                                // 0000000048b0: bf88ff9d
	v_add_co_ci_u32_e64 v70, null, s5, v17, vcc_lo             // 0000000048b4: d5207c46 01aa2205
	global_load_b32 v41, v[69:70], off                         // 0000000048bc: ee05007c 00000029 00000045
	s_wait_loadcnt 0x0                                         // 0000000048c8: bfc00000
	v_mul_f32_e32 v69, v39, v41                                // 0000000048cc: 108a5327
	s_delay_alu instid0(valu_dep_1) | instskip(skip_3) | instid1(valu_dep_3)// 0000000048d0: bf8701c1
	v_mul_f32_e32 v53, v53, v69                                // 0000000048d4: 106a8b35
	v_add_co_u32 v69, vcc_lo, v21, s6                          // 0000000048d8: d7006a45 02000d15
	s_wait_alu depctr_va_vcc(0)                                // 0000000048e0: bf88ff9d
	v_add_co_ci_u32_e64 v70, null, s7, v22, vcc_lo             // 0000000048e4: d5207c46 01aa2c07
	v_add_f32_e32 v13, v13, v53                                // 0000000048ec: 061a6b0d
	global_load_b32 v69, v[69:70], off                         // 0000000048f0: ee05007c 00000045 00000045
	s_wait_loadcnt 0x0                                         // 0000000048fc: bfc00000
	v_mul_f32_e32 v53, v41, v69                                // 000000004900: 106a8b29
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004904: bf870091
	v_mul_f32_e32 v53, v54, v53                                // 000000004908: 106a6b36
	v_add_f32_e32 v30, v30, v53                                // 00000000490c: 063c6b1e
	v_add_co_u32 v53, vcc_lo, v23, s6                          // 000000004910: d7006a35 02000d17
	s_wait_alu depctr_va_vcc(0)                                // 000000004918: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s7, v24, vcc_lo             // 00000000491c: d5207c36 01aa3007
	global_load_b32 v70, v[53:54], off                         // 000000004924: ee05007c 00000046 00000035
	s_wait_loadcnt 0x0                                         // 000000004930: bfc00000
	v_mul_f32_e32 v53, v41, v70                                // 000000004934: 106a8d29
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004938: bf870091
	v_mul_f32_e32 v53, v55, v53                                // 00000000493c: 106a6b37
	v_add_f32_e32 v32, v32, v53                                // 000000004940: 06406b20
	v_add_co_u32 v53, vcc_lo, v25, s6                          // 000000004944: d7006a35 02000d19
	s_wait_alu depctr_va_vcc(0)                                // 00000000494c: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s7, v26, vcc_lo             // 000000004950: d5207c36 01aa3407
	global_load_b32 v55, v[53:54], off                         // 000000004958: ee05007c 00000037 00000035
	s_wait_loadcnt 0x0                                         // 000000004964: bfc00000
	v_mul_f32_e32 v53, v41, v55                                // 000000004968: 106a6f29
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 00000000496c: bf870091
	v_mul_f32_e32 v53, v56, v53                                // 000000004970: 106a6b38
	v_add_f32_e32 v34, v34, v53                                // 000000004974: 06446b22
	v_add_co_u32 v53, vcc_lo, v27, s6                          // 000000004978: d7006a35 02000d1b
	s_wait_alu depctr_va_vcc(0)                                // 000000004980: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s7, v28, vcc_lo             // 000000004984: d5207c36 01aa3807
	global_load_b32 v56, v[53:54], off                         // 00000000498c: ee05007c 00000038 00000035
	s_wait_loadcnt 0x0                                         // 000000004998: bfc00000
	v_mul_f32_e32 v53, v41, v56                                // 00000000499c: 106a7129
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 0000000049a0: bf870091
	v_mul_f32_e32 v53, v57, v53                                // 0000000049a4: 106a6b39
	v_add_f32_e32 v36, v36, v53                                // 0000000049a8: 06486b24
	v_add_co_u32 v53, vcc_lo, v29, s6                          // 0000000049ac: d7006a35 02000d1d
	s_wait_alu depctr_va_vcc(0)                                // 0000000049b4: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s7, v31, vcc_lo             // 0000000049b8: d5207c36 01aa3e07
	global_load_b32 v57, v[53:54], off                         // 0000000049c0: ee05007c 00000039 00000035
	s_wait_loadcnt 0x0                                         // 0000000049cc: bfc00000
	v_mul_f32_e32 v53, v41, v57                                // 0000000049d0: 106a7329
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 0000000049d4: bf870091
	v_mul_f32_e32 v53, v58, v53                                // 0000000049d8: 106a6b3a
	v_add_f32_e32 v38, v38, v53                                // 0000000049dc: 064c6b26
	v_add_co_u32 v53, vcc_lo, v33, s6                          // 0000000049e0: d7006a35 02000d21
	s_wait_alu depctr_va_vcc(0)                                // 0000000049e8: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s7, v35, vcc_lo             // 0000000049ec: d5207c36 01aa4607
	global_load_b32 v58, v[53:54], off                         // 0000000049f4: ee05007c 0000003a 00000035
	s_wait_loadcnt 0x0                                         // 000000004a00: bfc00000
	v_mul_f32_e32 v53, v41, v58                                // 000000004a04: 106a7529
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004a08: bf870091
	v_mul_f32_e32 v53, v59, v53                                // 000000004a0c: 106a6b3b
	v_add_f32_e32 v40, v40, v53                                // 000000004a10: 06506b28
	v_add_co_u32 v53, vcc_lo, v3, s6                           // 000000004a14: d7006a35 02000d03
	s_wait_alu depctr_va_vcc(0)                                // 000000004a1c: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s7, v37, vcc_lo             // 000000004a20: d5207c36 01aa4a07
	global_load_b32 v59, v[53:54], off                         // 000000004a28: ee05007c 0000003b 00000035
	v_add_co_u32 v53, vcc_lo, s4, v18                          // 000000004a34: d7006a35 02022404
	s_wait_alu depctr_va_vcc(0)                                // 000000004a3c: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s5, v19, vcc_lo             // 000000004a40: d5207c36 01aa2605
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000004a48: 8b6a037e
	s_wait_loadcnt 0x0                                         // 000000004a4c: bfc00000
	v_mul_f32_e32 v41, v41, v59                                // 000000004a50: 10527729
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004a54: bf870091
	v_mul_f32_e32 v41, v60, v41                                // 000000004a58: 1052533c
	v_add_f32_e32 v44, v44, v41                                // 000000004a5c: 0658532c
	global_load_b32 v41, v[53:54], off                         // 000000004a60: ee05007c 00000029 00000035
	s_wait_loadcnt 0x0                                         // 000000004a6c: bfc00000
	v_mul_f32_e32 v39, v39, v41                                // 000000004a70: 104e5327
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004a74: bf870091
	v_mul_f32_e32 v39, v61, v39                                // 000000004a78: 104e4f3d
	v_dual_add_f32 v52, v52, v39 :: v_dual_mul_f32 v39, v69, v41// 000000004a7c: c9064f34 34265345
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004a84: bf870091
	v_mul_f32_e32 v39, v62, v39                                // 000000004a88: 104e4f3e
	v_add_f32_e32 v51, v51, v39                                // 000000004a8c: 06664f33
	v_mul_f32_e32 v39, v70, v41                                // 000000004a90: 104e5346
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004a94: bf870091
	v_mul_f32_e32 v39, v63, v39                                // 000000004a98: 104e4f3f
	v_dual_add_f32 v50, v50, v39 :: v_dual_mul_f32 v39, v55, v41// 000000004a9c: c9064f32 32265337
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004aa4: bf870091
	v_mul_f32_e32 v39, v64, v39                                // 000000004aa8: 104e4f40
	v_add_f32_e32 v49, v49, v39                                // 000000004aac: 06624f31
	v_mul_f32_e32 v39, v56, v41                                // 000000004ab0: 104e5338
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004ab4: bf870091
	v_mul_f32_e32 v39, v65, v39                                // 000000004ab8: 104e4f41
	v_dual_add_f32 v48, v48, v39 :: v_dual_mul_f32 v39, v57, v41// 000000004abc: c9064f30 30265339
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004ac4: bf870091
	v_mul_f32_e32 v39, v66, v39                                // 000000004ac8: 104e4f42
	v_add_f32_e32 v47, v47, v39                                // 000000004acc: 065e4f2f
	v_mul_f32_e32 v39, v58, v41                                // 000000004ad0: 104e533a
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004ad4: bf870091
	v_mul_f32_e32 v39, v67, v39                                // 000000004ad8: 104e4f43
	v_dual_add_f32 v46, v46, v39 :: v_dual_mul_f32 v39, v59, v41// 000000004adc: c9064f2e 2e26533b
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000004ae4: bf870091
	v_mul_f32_e32 v39, v68, v39                                // 000000004ae8: 104e4f44
	v_add_f32_e32 v45, v45, v39                                // 000000004aec: 065a4f2d
	s_wait_alu depctr_sa_sdst(0)                               // 000000004af0: bf88ff9e
	s_cbranch_vccnz 64672                                      // 000000004af4: bfa4fca0 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x2278>
	v_mul_lo_u32 v6, s15, v0                                   // 000000004af8: d72c0006 0202000f
	v_mul_lo_u32 v7, s14, v1                                   // 000000004b00: d72c0007 0202020e
	v_mad_co_u64_u32 v[4:5], null, s14, v0, 0                  // 000000004b08: d6fe7c04 0202000e
	v_sub_co_u32 v2, vcc_lo, s12, v0                           // 000000004b10: d7016a02 0202000c
	s_wait_alu depctr_va_vcc(0)                                // 000000004b18: bf88ff9d
	v_sub_co_ci_u32_e64 v3, null, s13, v1, vcc_lo              // 000000004b1c: d5217c03 01aa020d
	v_cmp_gt_i64_e64 s7, s[14:15], v[8:9]                      // 000000004b24: d4540007 0202100e
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 000000004b2c: bf870194
	v_add3_u32 v5, v5, v7, v6                                  // 000000004b30: d6550005 041a0f05
	v_cmp_lt_i64_e32 vcc_lo, 0, v[2:3]                         // 000000004b38: 7ca20480
	s_delay_alu instid0(valu_dep_2)                            // 000000004b3c: bf870002
	v_lshlrev_b64_e32 v[0:1], 1, v[4:5]                        // 000000004b40: 3e000881
	s_and_b32 s0, vcc_lo, s7                                   // 000000004b44: 8b00076a
	s_wait_alu depctr_sa_sdst(0)                               // 000000004b48: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000004b4c: be812000
	s_cbranch_execz 28                                         // 000000004b50: bfa5001c <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x30c4>
	v_lshlrev_b64_e32 v[4:5], 1, v[8:9]                        // 000000004b54: 3e081081
	v_add_co_u32 v7, s0, s16, v0                               // 000000004b58: d7000007 02020010
	v_bfe_u32 v6, v13, 16, 1                                   // 000000004b60: d6100006 0205210d
	s_wait_alu depctr_va_sdst(0)                               // 000000004b68: bf88f19f
	v_add_co_ci_u32_e64 v12, null, s17, v1, s0                 // 000000004b6c: d5207c0c 00020211
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004b74: bf870193
	v_add_co_u32 v4, s0, v7, v4                                // 000000004b78: d7000004 02020907
	v_add3_u32 v6, v6, v13, 0x7fff                             // 000000004b80: d6550006 03fe1b06 00007fff
	v_or_b32_e32 v14, 0x400000, v13                            // 000000004b8c: 381c1aff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000004b94: bf88f19f
	v_add_co_ci_u32_e64 v5, null, v12, v5, s0                  // 000000004b98: d5207c05 00020b0c
	v_cmp_u_f32_e64 s0, v13, v13                               // 000000004ba0: d4180000 02021b0d
	s_wait_alu depctr_va_sdst(0)                               // 000000004ba8: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004bac: bf870001
	v_cndmask_b32_e64 v6, v6, v14, s0                          // 000000004bb0: d5010006 00021d06
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000004bb8: ee09407c 03000000 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004bc4: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000004bc8: 8c7e017e
	v_cmp_lt_i64_e64 s0, 1, v[2:3]                             // 000000004bcc: d4510000 02020481
	s_and_b32 s1, s0, s7                                       // 000000004bd4: 8b010700
	s_wait_alu depctr_sa_sdst(0)                               // 000000004bd8: bf88ff9e
	s_and_saveexec_b32 s2, s1                                  // 000000004bdc: be822001
	s_cbranch_execz 35                                         // 000000004be0: bfa50023 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3170>
	v_add_co_u32 v6, s1, s16, v0                               // 000000004be4: d7000106 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000004bec: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s17, v1, s1                  // 000000004bf0: d5207c07 00060211
	s_lshl_b64 s[4:5], s[14:15], 1                             // 000000004bf8: 8484810e
	v_lshlrev_b64_e32 v[4:5], 1, v[8:9]                        // 000000004bfc: 3e081081
	s_wait_alu depctr_sa_sdst(0)                               // 000000004c00: bf88ff9e
	v_add_co_u32 v6, s1, v6, s4                                // 000000004c04: d7000106 02000906
	v_bfe_u32 v12, v30, 16, 1                                  // 000000004c0c: d610000c 0205211e
	s_wait_alu depctr_va_sdst(0)                               // 000000004c14: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s5, v7, s1                   // 000000004c18: d5207c07 00060e05
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004c20: bf870193
	v_add_co_u32 v4, s1, v6, v4                                // 000000004c24: d7000104 02020906
	v_add3_u32 v12, v12, v30, 0x7fff                           // 000000004c2c: d655000c 03fe3d0c 00007fff
	v_or_b32_e32 v13, 0x400000, v30                            // 000000004c38: 381a3cff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000004c40: bf88f19f
	v_add_co_ci_u32_e64 v5, null, v7, v5, s1                   // 000000004c44: d5207c05 00060b07
	v_cmp_u_f32_e64 s1, v30, v30                               // 000000004c4c: d4180001 02023d1e
	s_wait_alu depctr_va_sdst(0)                               // 000000004c54: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004c58: bf870001
	v_cndmask_b32_e64 v6, v12, v13, s1                         // 000000004c5c: d5010006 00061b0c
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000004c64: ee09407c 03000000 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004c70: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s2                              // 000000004c74: 8c7e027e
	v_cmp_lt_i64_e64 s1, 2, v[2:3]                             // 000000004c78: d4510001 02020482
	s_lshl_b64 s[8:9], s[14:15], 1                             // 000000004c80: 8488810e
	s_and_b32 s2, s1, s7                                       // 000000004c84: 8b020701
	s_wait_alu depctr_sa_sdst(0)                               // 000000004c88: bf88ff9e
	s_and_saveexec_b32 s3, s2                                  // 000000004c8c: be832002
	s_cbranch_execz 35                                         // 000000004c90: bfa50023 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3220>
	v_add_co_u32 v6, s2, s16, v0                               // 000000004c94: d7000206 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000004c9c: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s17, v1, s2                  // 000000004ca0: d5207c07 000a0211
	s_lshl_b64 s[4:5], s[8:9], 1                               // 000000004ca8: 84848108
	v_lshlrev_b64_e32 v[4:5], 1, v[8:9]                        // 000000004cac: 3e081081
	s_wait_alu depctr_sa_sdst(0)                               // 000000004cb0: bf88ff9e
	v_add_co_u32 v6, s2, v6, s4                                // 000000004cb4: d7000206 02000906
	v_bfe_u32 v12, v32, 16, 1                                  // 000000004cbc: d610000c 02052120
	s_wait_alu depctr_va_sdst(0)                               // 000000004cc4: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s5, v7, s2                   // 000000004cc8: d5207c07 000a0e05
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004cd0: bf870193
	v_add_co_u32 v4, s2, v6, v4                                // 000000004cd4: d7000204 02020906
	v_add3_u32 v12, v12, v32, 0x7fff                           // 000000004cdc: d655000c 03fe410c 00007fff
	v_or_b32_e32 v13, 0x400000, v32                            // 000000004ce8: 381a40ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000004cf0: bf88f19f
	v_add_co_ci_u32_e64 v5, null, v7, v5, s2                   // 000000004cf4: d5207c05 000a0b07
	v_cmp_u_f32_e64 s2, v32, v32                               // 000000004cfc: d4180002 02024120
	s_wait_alu depctr_va_sdst(0)                               // 000000004d04: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004d08: bf870001
	v_cndmask_b32_e64 v6, v12, v13, s2                         // 000000004d0c: d5010006 000a1b0c
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000004d14: ee09407c 03000000 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004d20: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s3                              // 000000004d24: 8c7e037e
	v_cmp_lt_i64_e64 s2, 3, v[2:3]                             // 000000004d28: d4510002 02020483
	s_mul_u64 s[10:11], s[14:15], 3                            // 000000004d30: aa8a830e
	s_and_b32 s3, s2, s7                                       // 000000004d34: 8b030702
	s_wait_alu depctr_sa_sdst(0)                               // 000000004d38: bf88ff9e
	s_and_saveexec_b32 s4, s3                                  // 000000004d3c: be842003
	s_cbranch_execz 35                                         // 000000004d40: bfa50023 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x32d0>
	v_add_co_u32 v6, s3, s16, v0                               // 000000004d44: d7000306 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000004d4c: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s17, v1, s3                  // 000000004d50: d5207c07 000e0211
	s_lshl_b64 s[40:41], s[10:11], 1                           // 000000004d58: 84a8810a
	v_lshlrev_b64_e32 v[4:5], 1, v[8:9]                        // 000000004d5c: 3e081081
	s_wait_alu depctr_sa_sdst(0)                               // 000000004d60: bf88ff9e
	v_add_co_u32 v6, s3, v6, s40                               // 000000004d64: d7000306 02005106
	v_bfe_u32 v12, v34, 16, 1                                  // 000000004d6c: d610000c 02052122
	s_wait_alu depctr_va_sdst(0)                               // 000000004d74: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s41, v7, s3                  // 000000004d78: d5207c07 000e0e29
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004d80: bf870193
	v_add_co_u32 v4, s3, v6, v4                                // 000000004d84: d7000304 02020906
	v_add3_u32 v12, v12, v34, 0x7fff                           // 000000004d8c: d655000c 03fe450c 00007fff
	v_or_b32_e32 v13, 0x400000, v34                            // 000000004d98: 381a44ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000004da0: bf88f19f
	v_add_co_ci_u32_e64 v5, null, v7, v5, s3                   // 000000004da4: d5207c05 000e0b07
	v_cmp_u_f32_e64 s3, v34, v34                               // 000000004dac: d4180003 02024522
	s_wait_alu depctr_va_sdst(0)                               // 000000004db4: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004db8: bf870001
	v_cndmask_b32_e64 v6, v12, v13, s3                         // 000000004dbc: d5010006 000e1b0c
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000004dc4: ee09407c 03000000 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004dd0: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s4                              // 000000004dd4: 8c7e047e
	v_cmp_lt_i64_e64 s3, 4, v[2:3]                             // 000000004dd8: d4510003 02020484
	s_lshl_b64 s[40:41], s[14:15], 2                           // 000000004de0: 84a8820e
	s_and_b32 s4, s3, s7                                       // 000000004de4: 8b040703
	s_wait_alu depctr_sa_sdst(0)                               // 000000004de8: bf88ff9e
	s_and_saveexec_b32 s5, s4                                  // 000000004dec: be852004
	s_cbranch_execz 35                                         // 000000004df0: bfa50023 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3380>
	v_add_co_u32 v6, s4, s16, v0                               // 000000004df4: d7000406 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000004dfc: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s17, v1, s4                  // 000000004e00: d5207c07 00120211
	s_lshl_b64 s[42:43], s[40:41], 1                           // 000000004e08: 84aa8128
	v_lshlrev_b64_e32 v[4:5], 1, v[8:9]                        // 000000004e0c: 3e081081
	s_wait_alu depctr_sa_sdst(0)                               // 000000004e10: bf88ff9e
	v_add_co_u32 v6, s4, v6, s42                               // 000000004e14: d7000406 02005506
	v_bfe_u32 v12, v36, 16, 1                                  // 000000004e1c: d610000c 02052124
	s_wait_alu depctr_va_sdst(0)                               // 000000004e24: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s43, v7, s4                  // 000000004e28: d5207c07 00120e2b
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004e30: bf870193
	v_add_co_u32 v4, s4, v6, v4                                // 000000004e34: d7000404 02020906
	v_add3_u32 v12, v12, v36, 0x7fff                           // 000000004e3c: d655000c 03fe490c 00007fff
	v_or_b32_e32 v13, 0x400000, v36                            // 000000004e48: 381a48ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000004e50: bf88f19f
	v_add_co_ci_u32_e64 v5, null, v7, v5, s4                   // 000000004e54: d5207c05 00120b07
	v_cmp_u_f32_e64 s4, v36, v36                               // 000000004e5c: d4180004 02024924
	s_wait_alu depctr_va_sdst(0)                               // 000000004e64: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004e68: bf870001
	v_cndmask_b32_e64 v6, v12, v13, s4                         // 000000004e6c: d5010006 00121b0c
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000004e74: ee09407c 03000000 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004e80: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s5                              // 000000004e84: 8c7e057e
	v_cmp_lt_i64_e64 s4, 5, v[2:3]                             // 000000004e88: d4510004 02020485
	s_mul_u64 s[42:43], s[14:15], 5                            // 000000004e90: aaaa850e
	s_and_b32 s5, s4, s7                                       // 000000004e94: 8b050704
	s_wait_alu depctr_sa_sdst(0)                               // 000000004e98: bf88ff9e
	s_and_saveexec_b32 s6, s5                                  // 000000004e9c: be862005
	s_cbranch_execz 35                                         // 000000004ea0: bfa50023 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3430>
	v_add_co_u32 v6, s5, s16, v0                               // 000000004ea4: d7000506 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000004eac: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s17, v1, s5                  // 000000004eb0: d5207c07 00160211
	s_lshl_b64 s[44:45], s[42:43], 1                           // 000000004eb8: 84ac812a
	v_lshlrev_b64_e32 v[4:5], 1, v[8:9]                        // 000000004ebc: 3e081081
	s_wait_alu depctr_sa_sdst(0)                               // 000000004ec0: bf88ff9e
	v_add_co_u32 v6, s5, v6, s44                               // 000000004ec4: d7000506 02005906
	v_bfe_u32 v12, v38, 16, 1                                  // 000000004ecc: d610000c 02052126
	s_wait_alu depctr_va_sdst(0)                               // 000000004ed4: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s45, v7, s5                  // 000000004ed8: d5207c07 00160e2d
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004ee0: bf870193
	v_add_co_u32 v4, s5, v6, v4                                // 000000004ee4: d7000504 02020906
	v_add3_u32 v12, v12, v38, 0x7fff                           // 000000004eec: d655000c 03fe4d0c 00007fff
	v_or_b32_e32 v13, 0x400000, v38                            // 000000004ef8: 381a4cff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000004f00: bf88f19f
	v_add_co_ci_u32_e64 v5, null, v7, v5, s5                   // 000000004f04: d5207c05 00160b07
	v_cmp_u_f32_e64 s5, v38, v38                               // 000000004f0c: d4180005 02024d26
	s_wait_alu depctr_va_sdst(0)                               // 000000004f14: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004f18: bf870001
	v_cndmask_b32_e64 v6, v12, v13, s5                         // 000000004f1c: d5010006 00161b0c
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000004f24: ee09407c 03000000 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004f30: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s6                              // 000000004f34: 8c7e067e
	v_cmp_lt_i64_e64 s5, 6, v[2:3]                             // 000000004f38: d4510005 02020486
	s_mul_u64 s[44:45], s[14:15], 6                            // 000000004f40: aaac860e
	s_and_b32 s6, s5, s7                                       // 000000004f44: 8b060705
	s_wait_alu depctr_sa_sdst(0)                               // 000000004f48: bf88ff9e
	s_and_saveexec_b32 s46, s6                                 // 000000004f4c: beae2006
	s_cbranch_execz 34                                         // 000000004f50: bfa50022 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x34dc>
	v_add_co_u32 v6, s6, s16, v0                               // 000000004f54: d7000606 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000004f5c: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s17, v1, s6                  // 000000004f60: d5207c07 001a0211
	s_lshl_b64 s[48:49], s[44:45], 1                           // 000000004f68: 84b0812c
	v_lshlrev_b64_e32 v[4:5], 1, v[8:9]                        // 000000004f6c: 3e081081
	v_add_co_u32 v6, s6, v6, s48                               // 000000004f70: d7000606 02006106
	v_bfe_u32 v12, v40, 16, 1                                  // 000000004f78: d610000c 02052128
	s_wait_alu depctr_va_sdst(0)                               // 000000004f80: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s49, v7, s6                  // 000000004f84: d5207c07 001a0e31
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000004f8c: bf870193
	v_add_co_u32 v4, s6, v6, v4                                // 000000004f90: d7000604 02020906
	v_add3_u32 v12, v12, v40, 0x7fff                           // 000000004f98: d655000c 03fe510c 00007fff
	v_or_b32_e32 v13, 0x400000, v40                            // 000000004fa4: 381a50ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000004fac: bf88f19f
	v_add_co_ci_u32_e64 v5, null, v7, v5, s6                   // 000000004fb0: d5207c05 001a0b07
	v_cmp_u_f32_e64 s6, v40, v40                               // 000000004fb8: d4180006 02025128
	s_wait_alu depctr_va_sdst(0)                               // 000000004fc0: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000004fc4: bf870001
	v_cndmask_b32_e64 v6, v12, v13, s6                         // 000000004fc8: d5010006 001a1b0c
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000004fd0: ee09407c 03000000 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000004fdc: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s46                             // 000000004fe0: 8c7e2e7e
	v_cmp_lt_i64_e64 s6, 7, v[2:3]                             // 000000004fe4: d4510006 02020487
	s_mul_u64 s[46:47], s[14:15], 7                            // 000000004fec: aaae870e
	s_and_b32 s7, s6, s7                                       // 000000004ff0: 8b070706
	s_wait_alu depctr_sa_sdst(0)                               // 000000004ff4: bf88ff9e
	s_and_saveexec_b32 s48, s7                                 // 000000004ff8: beb02007
	s_cbranch_execz 34                                         // 000000004ffc: bfa50022 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3588>
	v_add_co_u32 v4, s7, s16, v0                               // 000000005000: d7000704 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000005008: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s17, v1, s7                  // 00000000500c: d5207c05 001e0211
	s_lshl_b64 s[50:51], s[46:47], 1                           // 000000005014: 84b2812e
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 000000005018: 3e041081
	v_add_co_u32 v4, s7, v4, s50                               // 00000000501c: d7000704 02006504
	v_bfe_u32 v6, v44, 16, 1                                   // 000000005024: d6100006 0205212c
	s_wait_alu depctr_va_sdst(0)                               // 00000000502c: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s51, v5, s7                  // 000000005030: d5207c05 001e0a33
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000005038: bf870193
	v_add_co_u32 v2, s7, v4, v2                                // 00000000503c: d7000702 02020504
	v_add3_u32 v6, v6, v44, 0x7fff                             // 000000005044: d6550006 03fe5906 00007fff
	v_or_b32_e32 v7, 0x400000, v44                             // 000000005050: 380e58ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000005058: bf88f19f
	v_add_co_ci_u32_e64 v3, null, v5, v3, s7                   // 00000000505c: d5207c03 001e0705
	v_cmp_u_f32_e64 s7, v44, v44                               // 000000005064: d4180007 0202592c
	s_wait_alu depctr_va_sdst(0)                               // 00000000506c: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000005070: bf870001
	v_cndmask_b32_e64 v4, v6, v7, s7                           // 000000005074: d5010004 001e0f06
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000000507c: ee09407c 02000000 00000002
	s_wait_alu depctr_sa_sdst(0)                               // 000000005088: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s48                             // 00000000508c: 8c7e307e
	v_cmp_gt_i64_e64 s7, s[14:15], v[10:11]                    // 000000005090: d4540007 0202140e
	s_and_b32 s49, vcc_lo, s7                                  // 000000005098: 8b31076a
	s_wait_alu depctr_sa_sdst(0)                               // 00000000509c: bf88ff9e
	s_and_saveexec_b32 s48, s49                                // 0000000050a0: beb02031
	s_cbranch_execz 25                                         // 0000000050a4: bfa50019 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x360c>
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 0000000050a8: 3e041081
	v_add_co_u32 v5, vcc_lo, s16, v0                           // 0000000050ac: d7006a05 02020010
	v_bfe_u32 v4, v52, 16, 1                                   // 0000000050b4: d6100004 02052134
	s_wait_alu depctr_va_vcc(0)                                // 0000000050bc: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s17, v1, vcc_lo              // 0000000050c0: d5207c06 01aa0211
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000050c8: bf870193
	v_add_co_u32 v2, vcc_lo, v5, v2                            // 0000000050cc: d7006a02 02020505
	v_add3_u32 v4, v4, v52, 0x7fff                             // 0000000050d4: d6550004 03fe6904 00007fff
	v_or_b32_e32 v7, 0x400000, v52                             // 0000000050e0: 380e68ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000050e8: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v6, v3, vcc_lo               // 0000000050ec: d5207c03 01aa0706
	v_cmp_u_f32_e32 vcc_lo, v52, v52                           // 0000000050f4: 7c306934
	s_wait_alu depctr_va_vcc(0)                                // 0000000050f8: bf88ff9d
	v_cndmask_b32_e32 v4, v4, v7, vcc_lo                       // 0000000050fc: 02080f04
	global_store_d16_hi_b16 v[2:3], v4, off offset:32          // 000000005100: ee09407c 02000000 00002002
	s_wait_alu depctr_sa_sdst(0)                               // 00000000510c: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s48                             // 000000005110: 8c7e307e
	s_and_b32 s48, s0, s7                                      // 000000005114: 8b300700
	s_wait_alu depctr_sa_sdst(0)                               // 000000005118: bf88ff9e
	s_and_saveexec_b32 s0, s48                                 // 00000000511c: be802030
	s_cbranch_execz 31                                         // 000000005120: bfa5001f <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x36a0>
	v_add_co_u32 v4, vcc_lo, s16, v0                           // 000000005124: d7006a04 02020010
	s_wait_alu depctr_va_vcc(0)                                // 00000000512c: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s17, v1, vcc_lo              // 000000005130: d5207c05 01aa0211
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 000000005138: 3e041081
	s_delay_alu instid0(valu_dep_3) | instskip(skip_3) | instid1(valu_dep_3)// 00000000513c: bf8701c3
	v_add_co_u32 v4, vcc_lo, v4, s8                            // 000000005140: d7006a04 02001104
	v_bfe_u32 v6, v51, 16, 1                                   // 000000005148: d6100006 02052133
	s_wait_alu depctr_va_vcc(0)                                // 000000005150: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 000000005154: d5207c05 01aa0a09
	v_add_co_u32 v2, vcc_lo, v4, v2                            // 00000000515c: d7006a02 02020504
	s_delay_alu instid0(valu_dep_3)                            // 000000005164: bf870003
	v_add3_u32 v6, v6, v51, 0x7fff                             // 000000005168: d6550006 03fe6706 00007fff
	v_or_b32_e32 v7, 0x400000, v51                             // 000000005174: 380e66ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 00000000517c: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 000000005180: d5207c03 01aa0705
	v_cmp_u_f32_e32 vcc_lo, v51, v51                           // 000000005188: 7c306733
	s_wait_alu depctr_va_vcc(0)                                // 00000000518c: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v7, vcc_lo                       // 000000005190: 02080f06
	global_store_d16_hi_b16 v[2:3], v4, off offset:32          // 000000005194: ee09407c 02000000 00002002
	s_wait_alu depctr_sa_sdst(0)                               // 0000000051a0: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000051a4: 8c7e007e
	s_and_b32 s1, s1, s7                                       // 0000000051a8: 8b010701
	s_wait_alu depctr_sa_sdst(0)                               // 0000000051ac: bf88ff9e
	s_and_saveexec_b32 s0, s1                                  // 0000000051b0: be802001
	s_cbranch_execz 32                                         // 0000000051b4: bfa50020 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3738>
	v_add_co_u32 v4, vcc_lo, s16, v0                           // 0000000051b8: d7006a04 02020010
	s_wait_alu depctr_va_vcc(0)                                // 0000000051c0: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s17, v1, vcc_lo              // 0000000051c4: d5207c05 01aa0211
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000000051cc: 84888108
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 0000000051d0: 3e041081
	s_wait_alu depctr_sa_sdst(0)                               // 0000000051d4: bf88ff9e
	v_add_co_u32 v4, vcc_lo, v4, s8                            // 0000000051d8: d7006a04 02001104
	v_bfe_u32 v6, v50, 16, 1                                   // 0000000051e0: d6100006 02052132
	s_wait_alu depctr_va_vcc(0)                                // 0000000051e8: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 0000000051ec: d5207c05 01aa0a09
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000051f4: bf870193
	v_add_co_u32 v2, vcc_lo, v4, v2                            // 0000000051f8: d7006a02 02020504
	v_add3_u32 v6, v6, v50, 0x7fff                             // 000000005200: d6550006 03fe6506 00007fff
	v_or_b32_e32 v7, 0x400000, v50                             // 00000000520c: 380e64ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000005214: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 000000005218: d5207c03 01aa0705
	v_cmp_u_f32_e32 vcc_lo, v50, v50                           // 000000005220: 7c306532
	s_wait_alu depctr_va_vcc(0)                                // 000000005224: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v7, vcc_lo                       // 000000005228: 02080f06
	global_store_d16_hi_b16 v[2:3], v4, off offset:32          // 00000000522c: ee09407c 02000000 00002002
	s_wait_alu depctr_sa_sdst(0)                               // 000000005238: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000523c: 8c7e007e
	s_and_b32 s1, s2, s7                                       // 000000005240: 8b010702
	s_wait_alu depctr_sa_sdst(0)                               // 000000005244: bf88ff9e
	s_and_saveexec_b32 s0, s1                                  // 000000005248: be802001
	s_cbranch_execz 32                                         // 00000000524c: bfa50020 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x37d0>
	v_add_co_u32 v4, vcc_lo, s16, v0                           // 000000005250: d7006a04 02020010
	s_wait_alu depctr_va_vcc(0)                                // 000000005258: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s17, v1, vcc_lo              // 00000000525c: d5207c05 01aa0211
	s_lshl_b64 s[8:9], s[10:11], 1                             // 000000005264: 8488810a
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 000000005268: 3e041081
	s_wait_alu depctr_sa_sdst(0)                               // 00000000526c: bf88ff9e
	v_add_co_u32 v4, vcc_lo, v4, s8                            // 000000005270: d7006a04 02001104
	v_bfe_u32 v6, v49, 16, 1                                   // 000000005278: d6100006 02052131
	s_wait_alu depctr_va_vcc(0)                                // 000000005280: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 000000005284: d5207c05 01aa0a09
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 00000000528c: bf870193
	v_add_co_u32 v2, vcc_lo, v4, v2                            // 000000005290: d7006a02 02020504
	v_add3_u32 v6, v6, v49, 0x7fff                             // 000000005298: d6550006 03fe6306 00007fff
	v_or_b32_e32 v7, 0x400000, v49                             // 0000000052a4: 380e62ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000052ac: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 0000000052b0: d5207c03 01aa0705
	v_cmp_u_f32_e32 vcc_lo, v49, v49                           // 0000000052b8: 7c306331
	s_wait_alu depctr_va_vcc(0)                                // 0000000052bc: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v7, vcc_lo                       // 0000000052c0: 02080f06
	global_store_d16_hi_b16 v[2:3], v4, off offset:32          // 0000000052c4: ee09407c 02000000 00002002
	s_wait_alu depctr_sa_sdst(0)                               // 0000000052d0: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000052d4: 8c7e007e
	s_and_b32 s1, s3, s7                                       // 0000000052d8: 8b010703
	s_wait_alu depctr_sa_sdst(0)                               // 0000000052dc: bf88ff9e
	s_and_saveexec_b32 s0, s1                                  // 0000000052e0: be802001
	s_cbranch_execz 32                                         // 0000000052e4: bfa50020 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3868>
	v_add_co_u32 v4, vcc_lo, s16, v0                           // 0000000052e8: d7006a04 02020010
	s_wait_alu depctr_va_vcc(0)                                // 0000000052f0: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s17, v1, vcc_lo              // 0000000052f4: d5207c05 01aa0211
	s_lshl_b64 s[2:3], s[40:41], 1                             // 0000000052fc: 84828128
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 000000005300: 3e041081
	s_wait_alu depctr_sa_sdst(0)                               // 000000005304: bf88ff9e
	v_add_co_u32 v4, vcc_lo, v4, s2                            // 000000005308: d7006a04 02000504
	v_bfe_u32 v6, v48, 16, 1                                   // 000000005310: d6100006 02052130
	s_wait_alu depctr_va_vcc(0)                                // 000000005318: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000000531c: d5207c05 01aa0a03
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000005324: bf870193
	v_add_co_u32 v2, vcc_lo, v4, v2                            // 000000005328: d7006a02 02020504
	v_add3_u32 v6, v6, v48, 0x7fff                             // 000000005330: d6550006 03fe6106 00007fff
	v_or_b32_e32 v7, 0x400000, v48                             // 00000000533c: 380e60ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000005344: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 000000005348: d5207c03 01aa0705
	v_cmp_u_f32_e32 vcc_lo, v48, v48                           // 000000005350: 7c306130
	s_wait_alu depctr_va_vcc(0)                                // 000000005354: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v7, vcc_lo                       // 000000005358: 02080f06
	global_store_d16_hi_b16 v[2:3], v4, off offset:32          // 00000000535c: ee09407c 02000000 00002002
	s_wait_alu depctr_sa_sdst(0)                               // 000000005368: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000536c: 8c7e007e
	s_and_b32 s1, s4, s7                                       // 000000005370: 8b010704
	s_wait_alu depctr_sa_sdst(0)                               // 000000005374: bf88ff9e
	s_and_saveexec_b32 s0, s1                                  // 000000005378: be802001
	s_cbranch_execz 32                                         // 00000000537c: bfa50020 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3900>
	v_add_co_u32 v4, vcc_lo, s16, v0                           // 000000005380: d7006a04 02020010
	s_wait_alu depctr_va_vcc(0)                                // 000000005388: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s17, v1, vcc_lo              // 00000000538c: d5207c05 01aa0211
	s_lshl_b64 s[2:3], s[42:43], 1                             // 000000005394: 8482812a
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 000000005398: 3e041081
	s_wait_alu depctr_sa_sdst(0)                               // 00000000539c: bf88ff9e
	v_add_co_u32 v4, vcc_lo, v4, s2                            // 0000000053a0: d7006a04 02000504
	v_bfe_u32 v6, v47, 16, 1                                   // 0000000053a8: d6100006 0205212f
	s_wait_alu depctr_va_vcc(0)                                // 0000000053b0: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 0000000053b4: d5207c05 01aa0a03
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000053bc: bf870193
	v_add_co_u32 v2, vcc_lo, v4, v2                            // 0000000053c0: d7006a02 02020504
	v_add3_u32 v6, v6, v47, 0x7fff                             // 0000000053c8: d6550006 03fe5f06 00007fff
	v_or_b32_e32 v7, 0x400000, v47                             // 0000000053d4: 380e5eff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000053dc: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 0000000053e0: d5207c03 01aa0705
	v_cmp_u_f32_e32 vcc_lo, v47, v47                           // 0000000053e8: 7c305f2f
	s_wait_alu depctr_va_vcc(0)                                // 0000000053ec: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v7, vcc_lo                       // 0000000053f0: 02080f06
	global_store_d16_hi_b16 v[2:3], v4, off offset:32          // 0000000053f4: ee09407c 02000000 00002002
	s_wait_alu depctr_sa_sdst(0)                               // 000000005400: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005404: 8c7e007e
	s_and_b32 s1, s5, s7                                       // 000000005408: 8b010705
	s_wait_alu depctr_sa_sdst(0)                               // 00000000540c: bf88ff9e
	s_and_saveexec_b32 s0, s1                                  // 000000005410: be802001
	s_cbranch_execz 32                                         // 000000005414: bfa50020 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3998>
	v_add_co_u32 v4, vcc_lo, s16, v0                           // 000000005418: d7006a04 02020010
	s_wait_alu depctr_va_vcc(0)                                // 000000005420: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s17, v1, vcc_lo              // 000000005424: d5207c05 01aa0211
	s_lshl_b64 s[2:3], s[44:45], 1                             // 00000000542c: 8482812c
	v_lshlrev_b64_e32 v[2:3], 1, v[8:9]                        // 000000005430: 3e041081
	s_wait_alu depctr_sa_sdst(0)                               // 000000005434: bf88ff9e
	v_add_co_u32 v4, vcc_lo, v4, s2                            // 000000005438: d7006a04 02000504
	v_bfe_u32 v6, v46, 16, 1                                   // 000000005440: d6100006 0205212e
	s_wait_alu depctr_va_vcc(0)                                // 000000005448: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000000544c: d5207c05 01aa0a03
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000005454: bf870193
	v_add_co_u32 v2, vcc_lo, v4, v2                            // 000000005458: d7006a02 02020504
	v_add3_u32 v6, v6, v46, 0x7fff                             // 000000005460: d6550006 03fe5d06 00007fff
	v_or_b32_e32 v7, 0x400000, v46                             // 00000000546c: 380e5cff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000005474: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 000000005478: d5207c03 01aa0705
	v_cmp_u_f32_e32 vcc_lo, v46, v46                           // 000000005480: 7c305d2e
	s_wait_alu depctr_va_vcc(0)                                // 000000005484: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v7, vcc_lo                       // 000000005488: 02080f06
	global_store_d16_hi_b16 v[2:3], v4, off offset:32          // 00000000548c: ee09407c 02000000 00002002
	s_wait_alu depctr_sa_sdst(0)                               // 000000005498: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s0                              // 00000000549c: 8c7e007e
	s_and_b32 s1, s6, s7                                       // 0000000054a0: 8b010706
	s_wait_alu depctr_sa_sdst(0)                               // 0000000054a4: bf88ff9e
	s_and_saveexec_b32 s0, s1                                  // 0000000054a8: be802001
	s_cbranch_execz 32                                         // 0000000054ac: bfa50020 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3a30>
	v_add_co_u32 v2, vcc_lo, s16, v0                           // 0000000054b0: d7006a02 02020010
	s_wait_alu depctr_va_vcc(0)                                // 0000000054b8: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, s17, v1, vcc_lo              // 0000000054bc: d5207c03 01aa0211
	s_lshl_b64 s[2:3], s[46:47], 1                             // 0000000054c4: 8482812e
	v_lshlrev_b64_e32 v[0:1], 1, v[8:9]                        // 0000000054c8: 3e001081
	s_wait_alu depctr_sa_sdst(0)                               // 0000000054cc: bf88ff9e
	v_add_co_u32 v2, vcc_lo, v2, s2                            // 0000000054d0: d7006a02 02000502
	v_bfe_u32 v4, v45, 16, 1                                   // 0000000054d8: d6100004 0205212d
	s_wait_alu depctr_va_vcc(0)                                // 0000000054e0: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 0000000054e4: d5207c03 01aa0603
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000054ec: bf870193
	v_add_co_u32 v0, vcc_lo, v2, v0                            // 0000000054f0: d7006a00 02020102
	v_add3_u32 v4, v4, v45, 0x7fff                             // 0000000054f8: d6550004 03fe5b04 00007fff
	v_or_b32_e32 v5, 0x400000, v45                             // 000000005504: 380a5aff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 00000000550c: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 000000005510: d5207c01 01aa0303
	v_cmp_u_f32_e32 vcc_lo, v45, v45                           // 000000005518: 7c305b2d
	s_wait_alu depctr_va_vcc(0)                                // 00000000551c: bf88ff9d
	v_cndmask_b32_e32 v2, v4, v5, vcc_lo                       // 000000005520: 02040b04
	global_store_d16_hi_b16 v[0:1], v2, off offset:32          // 000000005524: ee09407c 01000000 00002000
	s_wait_alu depctr_sa_sdst(0)                               // 000000005530: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s0                              // 000000005534: 8c7e007e
	s_mov_b32 s0, 0                                            // 000000005538: be800080
	s_wait_alu depctr_sa_sdst(0)                               // 00000000553c: bf88ff9e
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000005540: 8b6a007e
	s_wait_alu depctr_sa_sdst(0)                               // 000000005544: bf88ff9e
	s_cbranch_vccz 612                                         // 000000005548: bfa30264 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x43dc>
	s_and_b32 s0, s33, exec_lo                                 // 00000000554c: 8b007e21
	v_cmp_gt_i64_e64 s0, s[14:15], v[8:9]                      // 000000005550: d4540000 0202100e
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v34, 0             // 000000005558: ca100080 1b220080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v36, 0             // 000000005560: ca100080 1f240080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v0, 0              // 000000005568: ca100080 21000080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v24, 0             // 000000005570: ca100080 23180080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v26, 0             // 000000005578: ca100080 251a0080
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v28, 0              // 000000005580: ca100080 011c0080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v30, 0             // 000000005588: ca100080 191e0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v32, 0             // 000000005590: ca100080 1d200080
	s_cselect_b32 s1, 1, 0                                     // 000000005598: 98018081
	v_cmp_gt_i64_e32 vcc_lo, s[14:15], v[10:11]                // 00000000559c: 7ca8140e
	s_wait_alu depctr_sa_sdst(0)                               // 0000000055a0: bf88ff9e
	s_cmp_lg_u32 s1, 1                                         // 0000000055a4: bf078101
	s_cbranch_scc1 562                                         // 0000000055a8: bfa20232 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x4374>
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v0, 3, v43      // 0000000055ac: ca220080 01005683
	v_mov_b32_e32 v7, s31                                      // 0000000055b4: 7e0e021f
	v_dual_mov_b32 v3, s31 :: v_dual_mov_b32 v16, s31          // 0000000055b8: ca10001f 0310001f
	s_delay_alu instid0(valu_dep_3)                            // 0000000055c0: bf870003
	v_or_b32_e32 v2, s30, v0                                   // 0000000055c4: 3804001e
	v_mov_b32_e32 v13, s31                                     // 0000000055c8: 7e1a021f
	v_cndmask_b32_e64 v5, 0, v9, s0                            // 0000000055cc: d5010005 00021280
	v_cndmask_b32_e64 v4, 0, v8, s0                            // 0000000055d4: d5010004 00021080
	v_mov_b32_e32 v15, s31                                     // 0000000055dc: 7e1e021f
	v_or_b32_e32 v6, 1, v2                                     // 0000000055e0: 380c0481
	v_or_b32_e32 v12, 2, v2                                    // 0000000055e4: 38180482
	v_cmp_gt_i64_e64 s0, s[12:13], v[2:3]                      // 0000000055e8: d4540000 0202040c
	v_or_b32_e32 v14, 3, v2                                    // 0000000055f0: 381c0483
	s_mov_b64 s[4:5], 0                                        // 0000000055f4: be840180
	v_cmp_gt_i64_e64 s1, s[12:13], v[6:7]                      // 0000000055f8: d4540001 02020c0c
	v_cmp_gt_i64_e64 s2, s[12:13], v[12:13]                    // 000000005600: d4540002 0202180c
	s_mov_b64 s[6:7], s[34:35]                                 // 000000005608: be860122
	v_cndmask_b32_e64 v17, 0, v2, s0                           // 00000000560c: d5010011 00020480
	v_cndmask_b32_e64 v18, 0, s31, s0                          // 000000005614: d5010012 00003e80
	v_cmp_gt_i64_e64 s3, s[12:13], v[14:15]                    // 00000000561c: d4540003 02021c0c
	v_cndmask_b32_e64 v19, 0, v6, s1                           // 000000005624: d5010013 00060c80
	v_or_b32_e32 v6, 4, v2                                     // 00000000562c: 380c0484
	v_cndmask_b32_e64 v25, 0, v12, s2                          // 000000005630: d5010019 000a1880
	v_or_b32_e32 v12, 5, v2                                    // 000000005638: 38180485
	v_or_b32_e32 v15, 6, v2                                    // 00000000563c: 381e0486
	v_cndmask_b32_e64 v21, 0, s31, s1                          // 000000005640: d5010015 00043e80
	v_cmp_gt_i64_e64 s0, s[12:13], v[6:7]                      // 000000005648: d4540000 02020c0c
	v_cndmask_b32_e64 v26, 0, s31, s2                          // 000000005650: d501001a 00083e80
	v_cmp_gt_i64_e64 s1, s[12:13], v[12:13]                    // 000000005658: d4540001 0202180c
	v_cmp_gt_i64_e64 s2, s[12:13], v[15:16]                    // 000000005660: d4540002 02021e0c
	v_or_b32_e32 v2, 7, v2                                     // 000000005668: 38040487
	s_wait_alu depctr_va_sdst(0)                               // 00000000566c: bf88f19f
	v_cndmask_b32_e64 v27, 0, v14, s3                          // 000000005670: d501001b 000e1c80
	v_cndmask_b32_e64 v30, 0, v6, s0                           // 000000005678: d501001e 00020c80
	v_cndmask_b32_e64 v32, 0, s31, s0                          // 000000005680: d5010020 00003e80
	v_add_co_u32 v16, s0, s36, v42                             // 000000005688: d7000010 02025424
	s_wait_alu depctr_va_sdst(0)                               // 000000005690: bf88f19f
	v_add_co_ci_u32_e64 v20, null, s37, 0, s0                  // 000000005694: d5207c14 00010025
	v_cndmask_b32_e64 v29, 0, v12, s1                          // 00000000569c: d501001d 00061880
	v_cndmask_b32_e64 v31, 0, s31, s1                          // 0000000056a4: d501001f 00043e80
	v_add_co_u32 v6, s1, v16, 16                               // 0000000056ac: d7000106 02012110
	v_cmp_gt_i64_e64 s0, s[12:13], v[2:3]                      // 0000000056b4: d4540000 0202040c
	s_wait_alu depctr_va_sdst(0)                               // 0000000056bc: bf88f19f
	v_add_co_ci_u32_e64 v7, null, 0, v20, s1                   // 0000000056c0: d5207c07 00062880
	s_delay_alu instid0(valu_dep_3)                            // 0000000056c8: bf870003
	v_mul_lo_u32 v13, s25, v6                                  // 0000000056cc: d72c000d 02020c19
	v_cndmask_b32_e64 v33, 0, v15, s2                          // 0000000056d4: d5010021 000a1e80
	v_mad_co_u64_u32 v[14:15], null, s24, v16, v[0:1]          // 0000000056dc: d6fe7c0e 04022018
	v_cndmask_b32_e64 v22, 0, v2, s0                           // 0000000056e4: d5010016 00020480
	v_lshlrev_b64_e32 v[2:3], 2, v[4:5]                        // 0000000056ec: 3e040882
	v_mad_co_u64_u32 v[4:5], null, s24, v6, v[0:1]             // 0000000056f0: d6fe7c04 04020c18
	v_mul_lo_u32 v12, s24, v7                                  // 0000000056f8: d72c000c 02020e18
	s_wait_alu depctr_va_vcc(0)                                // 000000005700: bf88ff9d
	v_dual_cndmask_b32 v7, 0, v11 :: v_dual_cndmask_b32 v6, 0, v10// 000000005704: ca521680 07061480
	v_mul_lo_u32 v20, s24, v20                                 // 00000000570c: d72c0014 02022818
	v_mul_lo_u32 v16, s25, v16                                 // 000000005714: d72c0010 02022019
	v_add_co_u32 v2, vcc_lo, s18, v2                           // 00000000571c: d7006a02 02020412
	s_wait_alu depctr_va_vcc(0)                                // 000000005724: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, s19, v3, vcc_lo              // 000000005728: d5207c03 01aa0613
	v_add3_u32 v5, v13, v5, v12                                // 000000005730: d6550005 04320b0d
	v_lshlrev_b64_e32 v[12:13], 2, v[6:7]                      // 000000005738: 3e180c82
	v_add_co_u32 v6, vcc_lo, s28, v4                           // 00000000573c: d7006a06 0202081c
	v_cndmask_b32_e64 v34, 0, s31, s2                          // 000000005744: d5010022 00083e80
	s_wait_alu depctr_va_vcc(0)                                // 00000000574c: bf88ff9d
	v_add_co_ci_u32_e64 v7, null, s29, v5, vcc_lo              // 000000005750: d5207c07 01aa0a1d
	s_delay_alu instid0(valu_dep_4)                            // 000000005758: bf870004
	v_add_co_u32 v4, vcc_lo, s18, v12                          // 00000000575c: d7006a04 02021812
	s_wait_alu depctr_va_vcc(0)                                // 000000005764: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s19, v13, vcc_lo             // 000000005768: d5207c05 01aa1a13
	v_add3_u32 v13, v16, v15, v20                              // 000000005770: d655000d 04521f10
	v_add_co_u32 v20, s2, s30, v42                             // 000000005778: d7000214 0202541e
	v_mul_lo_u32 v35, v17, s39                                 // 000000005780: d72c0023 02004f11
	v_mad_co_u64_u32 v[15:16], null, v17, s38, 0               // 000000005788: d6fe7c0f 02004d11
	v_mul_lo_u32 v36, v18, s38                                 // 000000005790: d72c0024 02004d12
	s_wait_alu depctr_va_sdst(0)                               // 000000005798: bf88f19f
	v_add_co_ci_u32_e64 v24, null, s31, 0, s2                  // 00000000579c: d5207c18 0009001f
	v_cndmask_b32_e64 v23, 0, s31, s0                          // 0000000057a4: d5010017 00003e80
	v_add_co_u32 v12, vcc_lo, s28, v14                         // 0000000057ac: d7006a0c 02021c1c
	v_mad_co_u64_u32 v[17:18], null, s24, v20, v[0:1]          // 0000000057b4: d6fe7c11 04022818
	s_delay_alu instid0(valu_dep_4)                            // 0000000057bc: bf870004
	v_mul_lo_u32 v0, s24, v24                                  // 0000000057c0: d72c0000 02023018
	v_mul_lo_u32 v14, s25, v20                                 // 0000000057c8: d72c000e 02022819
	v_add3_u32 v16, v16, v35, v36                              // 0000000057d0: d6550010 04924710
	v_mul_lo_u32 v35, v19, s39                                 // 0000000057d8: d72c0023 02004f13
	v_mad_co_u64_u32 v[19:20], null, v19, s38, 0               // 0000000057e0: d6fe7c13 02004d13
	v_mul_lo_u32 v36, v21, s38                                 // 0000000057e8: d72c0024 02004d15
	v_mul_lo_u32 v37, v22, s39                                 // 0000000057f0: d72c0025 02004f16
	v_mad_co_u64_u32 v[21:22], null, v22, s38, 0               // 0000000057f8: d6fe7c15 02004d16
	v_mul_lo_u32 v38, v23, s38                                 // 000000005800: d72c0026 02004d17
	v_lshlrev_b64_e32 v[23:24], 2, v[15:16]                    // 000000005808: 3e2e1e82
	v_add3_u32 v0, v14, v18, v0                                // 00000000580c: d6550000 0402250e
	s_wait_alu depctr_va_vcc(0)                                // 000000005814: bf88ff9d
	v_add_co_ci_u32_e64 v13, null, s29, v13, vcc_lo            // 000000005818: d5207c0d 01aa1a1d
	v_add3_u32 v20, v20, v35, v36                              // 000000005820: d6550014 04924714
	v_add_co_u32 v14, vcc_lo, s26, v17                         // 000000005828: d7006a0e 0202221a
	v_add3_u32 v22, v22, v37, v38                              // 000000005830: d6550016 049a4b16
	s_wait_alu depctr_va_vcc(0)                                // 000000005838: bf88ff9d
	v_add_co_ci_u32_e64 v15, null, s27, v0, vcc_lo             // 00000000583c: d5207c0f 01aa001b
	v_add_co_u32 v16, vcc_lo, v23, 4                           // 000000005844: d7006a10 02010917
	s_wait_alu depctr_va_vcc(0)                                // 00000000584c: bf88ff9d
	v_add_co_ci_u32_e64 v17, null, 0, v24, vcc_lo              // 000000005850: d5207c11 01aa3080
	v_lshlrev_b64_e32 v[18:19], 2, v[19:20]                    // 000000005858: 3e242682
	v_lshlrev_b64_e32 v[20:21], 2, v[21:22]                    // 00000000585c: 3e282a82
	v_mul_lo_u32 v0, v25, s39                                  // 000000005860: d72c0000 02004f19
	v_mad_co_u64_u32 v[22:23], null, v25, s38, 0               // 000000005868: d6fe7c16 02004d19
	v_mul_lo_u32 v26, v26, s38                                 // 000000005870: d72c001a 02004d1a
	v_mul_lo_u32 v35, v33, s39                                 // 000000005878: d72c0023 02004f21
	v_mad_co_u64_u32 v[24:25], null, v33, s38, 0               // 000000005880: d6fe7c18 02004d21
	v_mul_lo_u32 v33, v34, s38                                 // 000000005888: d72c0021 02004d22
	v_cndmask_b32_e64 v28, 0, s31, s3                          // 000000005890: d501001c 000c3e80
	v_mul_lo_u32 v34, v29, s39                                 // 000000005898: d72c0022 02004f1d
	v_mul_lo_u32 v32, v32, s38                                 // 0000000058a0: d72c0020 02004d20
	v_add_co_u32 v18, vcc_lo, v18, 4                           // 0000000058a8: d7006a12 02010912
	v_add3_u32 v23, v23, v0, v26                               // 0000000058b0: d6550017 046a0117
	v_mul_lo_u32 v0, v27, s39                                  // 0000000058b8: d72c0000 02004f1b
	v_add3_u32 v25, v25, v35, v33                              // 0000000058c0: d6550019 04864719
	v_mad_co_u64_u32 v[26:27], null, v27, s38, 0               // 0000000058c8: d6fe7c1a 02004d1b
	v_mul_lo_u32 v33, v28, s38                                 // 0000000058d0: d72c0021 02004d1c
	v_mad_co_u64_u32 v[28:29], null, v29, s38, 0               // 0000000058d8: d6fe7c1c 02004d1d
	v_mul_lo_u32 v35, v31, s38                                 // 0000000058e0: d72c0023 02004d1f
	v_lshlrev_b64_e32 v[22:23], 2, v[22:23]                    // 0000000058e8: 3e2c2c82
	v_lshlrev_b64_e32 v[24:25], 2, v[24:25]                    // 0000000058ec: 3e303082
	s_wait_alu depctr_va_vcc(0)                                // 0000000058f0: bf88ff9d
	v_add_co_ci_u32_e64 v19, null, 0, v19, vcc_lo              // 0000000058f4: d5207c13 01aa2680
	v_add_co_u32 v20, vcc_lo, v20, 4                           // 0000000058fc: d7006a14 02010914
	v_add3_u32 v27, v27, v0, v33                               // 000000005904: d655001b 0486011b
	v_mul_lo_u32 v0, v30, s39                                  // 00000000590c: d72c0000 02004f1e
	v_mad_co_u64_u32 v[30:31], null, v30, s38, 0               // 000000005914: d6fe7c1e 02004d1e
	v_add3_u32 v29, v29, v34, v35                              // 00000000591c: d655001d 048e451d
	s_wait_alu depctr_va_vcc(0)                                // 000000005924: bf88ff9d
	v_add_co_ci_u32_e64 v21, null, 0, v21, vcc_lo              // 000000005928: d5207c15 01aa2a80
	v_lshlrev_b64_e32 v[26:27], 2, v[26:27]                    // 000000005930: 3e343482
	v_add_co_u32 v22, vcc_lo, v22, 4                           // 000000005934: d7006a16 02010916
	s_wait_alu depctr_va_vcc(0)                                // 00000000593c: bf88ff9d
	v_add_co_ci_u32_e64 v23, null, 0, v23, vcc_lo              // 000000005940: d5207c17 01aa2e80
	v_add3_u32 v31, v31, v0, v32                               // 000000005948: d655001f 0482011f
	v_add_co_u32 v38, vcc_lo, v24, 4                           // 000000005950: d7006a26 02010918
	s_wait_alu depctr_va_vcc(0)                                // 000000005958: bf88ff9d
	v_add_co_ci_u32_e64 v39, null, 0, v25, vcc_lo              // 00000000595c: d5207c27 01aa3280
	v_lshlrev_b64_e32 v[24:25], 2, v[28:29]                    // 000000005964: 3e303882
	v_add_co_u32 v40, vcc_lo, v26, 4                           // 000000005968: d7006a28 0201091a
	s_wait_alu depctr_va_vcc(0)                                // 000000005970: bf88ff9d
	v_add_co_ci_u32_e64 v41, null, 0, v27, vcc_lo              // 000000005974: d5207c29 01aa3680
	v_lshlrev_b64_e32 v[26:27], 2, v[30:31]                    // 00000000597c: 3e343c82
	s_delay_alu instid0(valu_dep_4) | instskip(skip_3) | instid1(valu_dep_4)// 000000005980: bf870244
	v_add_co_u32 v44, vcc_lo, v24, 4                           // 000000005984: d7006a2c 02010918
	s_wait_alu depctr_va_vcc(0)                                // 00000000598c: bf88ff9d
	v_add_co_ci_u32_e64 v45, null, 0, v25, vcc_lo              // 000000005990: d5207c2d 01aa3280
	v_dual_mov_b32 v37, v1 :: v_dual_mov_b32 v30, v1           // 000000005998: ca100101 251e0101
	v_add_co_u32 v46, vcc_lo, v26, 4                           // 0000000059a0: d7006a2e 0201091a
	s_wait_alu depctr_va_vcc(0)                                // 0000000059a8: bf88ff9d
	v_add_co_ci_u32_e64 v47, null, 0, v27, vcc_lo              // 0000000059ac: d5207c2f 01aa3680
	v_dual_mov_b32 v36, v1 :: v_dual_mov_b32 v35, v1           // 0000000059b4: ca100101 24220101
	v_mov_b32_e32 v28, v1                                      // 0000000059bc: 7e380301
	v_dual_mov_b32 v34, v1 :: v_dual_mov_b32 v33, v1           // 0000000059c0: ca100101 22200101
	v_dual_mov_b32 v26, v1 :: v_dual_mov_b32 v31, v1           // 0000000059c8: ca100101 1a1e0101
	v_dual_mov_b32 v24, v1 :: v_dual_mov_b32 v27, v1           // 0000000059d0: ca100101 181a0101
	v_mov_b32_e32 v0, v1                                       // 0000000059d8: 7e000301
	v_dual_mov_b32 v32, v1 :: v_dual_mov_b32 v29, v1           // 0000000059dc: ca100101 201c0101
	v_mov_b32_e32 v25, v1                                      // 0000000059e4: 7e320301
	s_lshl_b64 s[0:1], s[14:15], 2                             // 0000000059e8: 8480820e
	s_lshl_b64 s[2:3], s[14:15], 3                             // 0000000059ec: 8482830e
	s_wait_alu depctr_sa_sdst(0)                               // 0000000059f0: bf88ff9e
	v_add_co_u32 v64, vcc_lo, v14, s4                          // 0000000059f4: d7006a40 0200090e
	s_wait_alu depctr_va_vcc(0)                                // 0000000059fc: bf88ff9d
	v_add_co_ci_u32_e64 v65, null, s5, v15, vcc_lo             // 000000005a00: d5207c41 01aa1e05
	v_add_co_u32 v68, vcc_lo, v12, s4                          // 000000005a08: d7006a44 0200090c
	s_wait_alu depctr_va_vcc(0)                                // 000000005a10: bf88ff9d
	v_add_co_ci_u32_e64 v69, null, s5, v13, vcc_lo             // 000000005a14: d5207c45 01aa1a05
	v_add_co_u32 v70, vcc_lo, v6, s4                           // 000000005a1c: d7006a46 02000906
	s_wait_alu depctr_va_vcc(0)                                // 000000005a24: bf88ff9d
	v_add_co_ci_u32_e64 v71, null, s5, v7, vcc_lo              // 000000005a28: d5207c47 01aa0e05
	global_load_b64 v[66:67], v[64:65], off                    // 000000005a30: ee05407c 00000042 00000040
	global_load_b64 v[56:57], v[68:69], off                    // 000000005a3c: ee05407c 00000038 00000044
	s_add_nc_u64 s[4:5], s[4:5], 32                            // 000000005a48: a984a004
	global_load_b64 v[72:73], v[70:71], off                    // 000000005a4c: ee05407c 00000048 00000046
	s_wait_alu depctr_sa_sdst(0)                               // 000000005a58: bf88ff9e
	v_cmp_ge_i64_e64 s8, s[4:5], s[22:23]                      // 000000005a5c: d4560008 02002c04
	s_wait_loadcnt 0x1                                         // 000000005a64: bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[56:57], 0// 000000005a68: cc464030 1a027142
	s_wait_loadcnt 0x0                                         // 000000005a70: bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[66:67], v[72:73], 0// 000000005a74: cc464038 1a029142
	v_add_co_u32 v66, vcc_lo, s6, v16                          // 000000005a7c: d7006a42 02022006
	s_wait_alu depctr_va_vcc(0)                                // 000000005a84: bf88ff9d
	v_add_co_ci_u32_e64 v67, null, s7, v17, vcc_lo             // 000000005a88: d5207c43 01aa2207
	global_load_b64 v[66:67], v[66:67], off offset:-4          // 000000005a90: ee05407c 00000042 fffffc42
	global_load_b32 v86, v[2:3], off                           // 000000005a9c: ee05007c 00000056 00000002
	s_wait_loadcnt 0x0                                         // 000000005aa8: bfc00000
	v_mul_f32_e32 v72, v66, v86                                // 000000005aac: 1090ad42
	s_delay_alu instid0(valu_dep_1) | instskip(skip_3) | instid1(valu_dep_3)// 000000005ab0: bf8701c1
	v_mul_f32_e32 v48, v48, v72                                // 000000005ab4: 10609130
	v_add_co_u32 v72, vcc_lo, s6, v18                          // 000000005ab8: d7006a48 02022406
	s_wait_alu depctr_va_vcc(0)                                // 000000005ac0: bf88ff9d
	v_add_co_ci_u32_e64 v73, null, s7, v19, vcc_lo             // 000000005ac4: d5207c49 01aa2607
	v_add_f32_e32 v87, v1, v48                                 // 000000005acc: 06ae6101
	v_add_co_u32 v48, vcc_lo, s6, v22                          // 000000005ad0: d7006a30 02022c06
	global_load_b64 v[72:73], v[72:73], off offset:-4          // 000000005ad8: ee05407c 00000048 fffffc48
	s_wait_loadcnt 0x0                                         // 000000005ae4: bfc00000
	v_mul_f32_e32 v1, v86, v72                                 // 000000005ae8: 10029156
	s_delay_alu instid0(valu_dep_1)                            // 000000005aec: bf870001
	v_mul_f32_e32 v1, v49, v1                                  // 000000005af0: 10020331
	s_wait_alu depctr_va_vcc(0)                                // 000000005af4: bf88ff9d
	v_add_co_ci_u32_e64 v49, null, s7, v23, vcc_lo             // 000000005af8: d5207c31 01aa2e07
	global_load_b64 v[74:75], v[48:49], off offset:-4          // 000000005b00: ee05407c 0000004a fffffc30
	s_wait_loadcnt 0x0                                         // 000000005b0c: bfc00000
	v_dual_add_f32 v88, v37, v1 :: v_dual_mul_f32 v1, v86, v74 // 000000005b10: c9060325 58009556
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005b18: bf870091
	v_mul_f32_e32 v1, v50, v1                                  // 000000005b1c: 10020332
	v_add_f32_e32 v89, v36, v1                                 // 000000005b20: 06b20324
	v_add_co_u32 v36, vcc_lo, s6, v40                          // 000000005b24: d7006a24 02025006
	s_wait_alu depctr_va_vcc(0)                                // 000000005b2c: bf88ff9d
	v_add_co_ci_u32_e64 v37, null, s7, v41, vcc_lo             // 000000005b30: d5207c25 01aa5207
	global_load_b64 v[76:77], v[36:37], off offset:-4          // 000000005b38: ee05407c 0000004c fffffc24
	s_wait_loadcnt 0x0                                         // 000000005b44: bfc00000
	v_mul_f32_e32 v1, v86, v76                                 // 000000005b48: 10029956
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005b4c: bf870091
	v_mul_f32_e32 v1, v51, v1                                  // 000000005b50: 10020333
	v_add_f32_e32 v90, v35, v1                                 // 000000005b54: 06b40323
	v_add_co_u32 v35, vcc_lo, s6, v46                          // 000000005b58: d7006a23 02025c06
	s_wait_alu depctr_va_vcc(0)                                // 000000005b60: bf88ff9d
	v_add_co_ci_u32_e64 v36, null, s7, v47, vcc_lo             // 000000005b64: d5207c24 01aa5e07
	global_load_b64 v[78:79], v[35:36], off offset:-4          // 000000005b6c: ee05407c 0000004e fffffc23
	s_wait_loadcnt 0x0                                         // 000000005b78: bfc00000
	v_mul_f32_e32 v1, v86, v78                                 // 000000005b7c: 10029d56
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005b80: bf870091
	v_mul_f32_e32 v1, v52, v1                                  // 000000005b84: 10020334
	v_add_f32_e32 v91, v34, v1                                 // 000000005b88: 06b60322
	v_add_co_u32 v34, vcc_lo, s6, v44                          // 000000005b8c: d7006a22 02025806
	s_wait_alu depctr_va_vcc(0)                                // 000000005b94: bf88ff9d
	v_add_co_ci_u32_e64 v35, null, s7, v45, vcc_lo             // 000000005b98: d5207c23 01aa5a07
	global_load_b64 v[80:81], v[34:35], off offset:-4          // 000000005ba0: ee05407c 00000050 fffffc22
	s_wait_loadcnt 0x0                                         // 000000005bac: bfc00000
	v_mul_f32_e32 v1, v86, v80                                 // 000000005bb0: 1002a156
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005bb4: bf870091
	v_mul_f32_e32 v1, v53, v1                                  // 000000005bb8: 10020335
	v_add_f32_e32 v92, v33, v1                                 // 000000005bbc: 06b80321
	v_add_co_u32 v33, vcc_lo, s6, v38                          // 000000005bc0: d7006a21 02024c06
	s_wait_alu depctr_va_vcc(0)                                // 000000005bc8: bf88ff9d
	v_add_co_ci_u32_e64 v34, null, s7, v39, vcc_lo             // 000000005bcc: d5207c22 01aa4e07
	global_load_b64 v[82:83], v[33:34], off offset:-4          // 000000005bd4: ee05407c 00000052 fffffc21
	v_add_co_u32 v33, vcc_lo, s6, v20                          // 000000005be0: d7006a21 02022806
	s_wait_alu depctr_va_vcc(0)                                // 000000005be8: bf88ff9d
	v_add_co_ci_u32_e64 v34, null, s7, v21, vcc_lo             // 000000005bec: d5207c22 01aa2a07
	s_add_nc_u64 s[6:7], s[6:7], 8                             // 000000005bf4: a9868806
	global_load_b64 v[84:85], v[33:34], off offset:-4          // 000000005bf8: ee05407c 00000054 fffffc21
	s_wait_loadcnt 0x1                                         // 000000005c04: bfc00001
	v_mul_f32_e32 v1, v86, v82                                 // 000000005c08: 1002a556
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c0c: bf870091
	v_mul_f32_e32 v1, v54, v1                                  // 000000005c10: 10020336
	v_add_f32_e32 v93, v31, v1                                 // 000000005c14: 06ba031f
	s_wait_loadcnt 0x0                                         // 000000005c18: bfc00000
	v_mul_f32_e32 v1, v86, v84                                 // 000000005c1c: 1002a956
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c20: bf870091
	v_mul_f32_e32 v1, v55, v1                                  // 000000005c24: 10020337
	v_add_f32_e32 v86, v27, v1                                 // 000000005c28: 06ac031b
	global_load_b32 v1, v[4:5], off                            // 000000005c2c: ee05007c 00000001 00000004
	s_wait_loadcnt 0x0                                         // 000000005c38: bfc00000
	v_mul_f32_e32 v27, v66, v1                                 // 000000005c3c: 10360342
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c40: bf870091
	v_mul_f32_e32 v27, v56, v27                                // 000000005c44: 10363738
	v_add_f32_e32 v56, v32, v27                                // 000000005c48: 06703720
	v_mul_f32_e32 v27, v72, v1                                 // 000000005c4c: 10360348
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c50: bf870091
	v_mul_f32_e32 v27, v57, v27                                // 000000005c54: 10363739
	v_add_f32_e32 v57, v30, v27                                // 000000005c58: 0672371e
	v_mul_f32_e32 v27, v74, v1                                 // 000000005c5c: 1036034a
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c60: bf870091
	v_mul_f32_e32 v27, v58, v27                                // 000000005c64: 1036373a
	v_dual_add_f32 v58, v29, v27 :: v_dual_mul_f32 v27, v76, v1// 000000005c68: c906371d 3a1a034c
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c70: bf870091
	v_mul_f32_e32 v27, v59, v27                                // 000000005c74: 1036373b
	v_add_f32_e32 v59, v28, v27                                // 000000005c78: 0676371c
	v_mul_f32_e32 v27, v78, v1                                 // 000000005c7c: 1036034e
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c80: bf870091
	v_mul_f32_e32 v27, v60, v27                                // 000000005c84: 1036373c
	v_add_f32_e32 v60, v26, v27                                // 000000005c88: 0678371a
	v_mul_f32_e32 v26, v80, v1                                 // 000000005c8c: 10340350
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005c90: bf870091
	v_mul_f32_e32 v26, v61, v26                                // 000000005c94: 1034353d
	v_add_f32_e32 v61, v25, v26                                // 000000005c98: 067a3519
	v_mul_f32_e32 v25, v82, v1                                 // 000000005c9c: 10320352
	v_mul_f32_e32 v1, v84, v1                                  // 000000005ca0: 10020354
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000005ca4: bf870112
	v_mul_f32_e32 v25, v62, v25                                // 000000005ca8: 1032333e
	v_mul_f32_e32 v1, v63, v1                                  // 000000005cac: 1002033f
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000005cb0: bf870112
	v_add_f32_e32 v62, v24, v25                                // 000000005cb4: 067c3318
	v_add_f32_e32 v63, v0, v1                                  // 000000005cb8: 067e0300
	global_load_b64 v[0:1], v[64:65], off offset:16            // 000000005cbc: ee05407c 00000000 00001040
	s_clause 0x1                                               // 000000005cc8: bf850001
	global_load_b64 v[33:34], v[68:69], off offset:16          // 000000005ccc: ee05407c 00000021 00001044
	global_load_b64 v[35:36], v[70:71], off offset:16          // 000000005cd8: ee05407c 00000023 00001046
	s_wait_loadcnt 0x1                                         // 000000005ce4: bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[25:32], v[0:1], v[33:34], 0  // 000000005ce8: cc464019 1a024300
	s_wait_loadcnt 0x0                                         // 000000005cf0: bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[0:1], v[35:36], 0  // 000000005cf4: cc464030 1a024700
	v_add_co_u32 v0, vcc_lo, v2, s0                            // 000000005cfc: d7006a00 02000102
	s_wait_alu depctr_va_vcc(0)                                // 000000005d04: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s1, v3, vcc_lo               // 000000005d08: d5207c01 01aa0601
	global_load_b32 v0, v[0:1], off                            // 000000005d10: ee05007c 00000000 00000000
	s_wait_loadcnt 0x0                                         // 000000005d1c: bfc00000
	v_dual_mul_f32 v24, v0, v73 :: v_dual_mul_f32 v1, v67, v0  // 000000005d20: c8c69300 18000143
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005d28: bf870091
	v_dual_mul_f32 v24, v26, v24 :: v_dual_mul_f32 v1, v25, v1 // 000000005d2c: c8c6311a 18000319
	v_add_f32_e32 v37, v88, v24                                // 000000005d34: 064a3158
	v_mul_f32_e32 v24, v0, v75                                 // 000000005d38: 10309700
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005d3c: bf870091
	v_mul_f32_e32 v24, v27, v24                                // 000000005d40: 1030311b
	v_add_f32_e32 v36, v89, v24                                // 000000005d44: 06483159
	v_mul_f32_e32 v24, v0, v77                                 // 000000005d48: 10309b00
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005d4c: bf870091
	v_mul_f32_e32 v24, v28, v24                                // 000000005d50: 1030311c
	v_dual_add_f32 v35, v90, v24 :: v_dual_mul_f32 v24, v0, v79// 000000005d54: c906315a 23189f00
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005d5c: bf870091
	v_mul_f32_e32 v24, v29, v24                                // 000000005d60: 1030311d
	v_add_f32_e32 v34, v91, v24                                // 000000005d64: 0644315b
	v_mul_f32_e32 v24, v0, v81                                 // 000000005d68: 1030a300
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005d6c: bf870091
	v_mul_f32_e32 v24, v30, v24                                // 000000005d70: 1030311e
	v_add_f32_e32 v33, v92, v24                                // 000000005d74: 0642315c
	v_mul_f32_e32 v24, v0, v83                                 // 000000005d78: 1030a700
	v_mul_f32_e32 v0, v0, v85                                  // 000000005d7c: 1000ab00
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000005d80: bf870112
	v_mul_f32_e32 v24, v31, v24                                // 000000005d84: 1030311f
	v_mul_f32_e32 v0, v32, v0                                  // 000000005d88: 10000120
	s_delay_alu instid0(valu_dep_2)                            // 000000005d8c: bf870002
	v_add_f32_e32 v31, v93, v24                                // 000000005d90: 063e315d
	v_add_co_u32 v24, vcc_lo, v4, s0                           // 000000005d94: d7006a18 02000104
	s_wait_alu depctr_va_vcc(0)                                // 000000005d9c: bf88ff9d
	v_add_co_ci_u32_e64 v25, null, s1, v5, vcc_lo              // 000000005da0: d5207c19 01aa0a01
	v_add_f32_e32 v27, v86, v0                                 // 000000005da8: 06360156
	v_add_co_u32 v2, vcc_lo, v2, s2                            // 000000005dac: d7006a02 02000502
	global_load_b32 v0, v[24:25], off                          // 000000005db4: ee05007c 00000000 00000018
	s_wait_alu depctr_va_vcc(0)                                // 000000005dc0: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 000000005dc4: d5207c03 01aa0603
	v_add_co_u32 v4, vcc_lo, v4, s2                            // 000000005dcc: d7006a04 02000504
	s_wait_alu depctr_va_vcc(0)                                // 000000005dd4: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 000000005dd8: d5207c05 01aa0a03
	s_and_b32 vcc_lo, exec_lo, s8                              // 000000005de0: 8b6a087e
	s_wait_loadcnt 0x0                                         // 000000005de4: bfc00000
	v_mul_f32_e32 v24, v67, v0                                 // 000000005de8: 10300143
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005dec: bf870091
	v_mul_f32_e32 v24, v48, v24                                // 000000005df0: 10303130
	v_add_f32_e32 v32, v56, v24                                // 000000005df4: 06403138
	v_mul_f32_e32 v24, v73, v0                                 // 000000005df8: 10300149
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005dfc: bf870091
	v_mul_f32_e32 v24, v49, v24                                // 000000005e00: 10303131
	v_add_f32_e32 v30, v57, v24                                // 000000005e04: 063c3139
	v_mul_f32_e32 v24, v75, v0                                 // 000000005e08: 1030014b
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005e0c: bf870091
	v_mul_f32_e32 v24, v50, v24                                // 000000005e10: 10303132
	v_add_f32_e32 v29, v58, v24                                // 000000005e14: 063a313a
	v_mul_f32_e32 v24, v77, v0                                 // 000000005e18: 1030014d
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005e1c: bf870091
	v_mul_f32_e32 v24, v51, v24                                // 000000005e20: 10303133
	v_add_f32_e32 v28, v59, v24                                // 000000005e24: 0638313b
	v_mul_f32_e32 v24, v79, v0                                 // 000000005e28: 1030014f
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005e2c: bf870091
	v_dual_add_f32 v1, v87, v1 :: v_dual_mul_f32 v24, v52, v24 // 000000005e30: c9060357 01183134
	v_add_f32_e32 v26, v60, v24                                // 000000005e38: 0634313c
	v_mul_f32_e32 v24, v81, v0                                 // 000000005e3c: 10300151
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000005e40: bf870091
	v_mul_f32_e32 v24, v53, v24                                // 000000005e44: 10303135
	v_add_f32_e32 v25, v61, v24                                // 000000005e48: 0632313d
	v_mul_f32_e32 v24, v83, v0                                 // 000000005e4c: 10300153
	v_mul_f32_e32 v0, v85, v0                                  // 000000005e50: 10000155
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000005e54: bf870112
	v_mul_f32_e32 v24, v54, v24                                // 000000005e58: 10303136
	v_mul_f32_e32 v0, v55, v0                                  // 000000005e5c: 10000137
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000005e60: bf870112
	v_add_f32_e32 v24, v62, v24                                // 000000005e64: 0630313e
	v_add_f32_e32 v0, v63, v0                                  // 000000005e68: 0600013f
	s_wait_alu depctr_sa_sdst(0)                               // 000000005e6c: bf88ff9e
	s_cbranch_vccz 65247                                       // 000000005e70: bfa3fedf <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x3ef0>
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v22, 3, v43    // 000000005e74: ca220080 17165683
	v_cmp_lt_i64_e64 s0, s[22:23], s[20:21]                    // 000000005e7c: d4510000 02002816
	s_delay_alu instid0(valu_dep_2)                            // 000000005e84: bf870002
	v_or_b32_e32 v4, s30, v22                                  // 000000005e88: 38082c1e
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000005e8c: 8b6a007e
	s_wait_alu depctr_sa_sdst(0)                               // 000000005e90: bf88ff9e
	s_cbranch_vccnz 18                                         // 000000005e94: bfa40012 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x43e0>
	v_mov_b32_e32 v5, s31                                      // 000000005e98: 7e0a021f
	v_or_b32_e32 v14, 1, v4                                    // 000000005e9c: 381c0881
	v_or_b32_e32 v6, 2, v4                                     // 000000005ea0: 380c0882
	v_or_b32_e32 v2, 3, v4                                     // 000000005ea4: 38040883
	v_mov_b32_e32 v15, s31                                     // 000000005ea8: 7e1e021f
	v_mov_b32_e32 v7, s31                                      // 000000005eac: 7e0e021f
	v_mov_b32_e32 v3, s31                                      // 000000005eb0: 7e06021f
	v_or_b32_e32 v18, 4, v4                                    // 000000005eb4: 38240884
	v_mov_b32_e32 v19, s31                                     // 000000005eb8: 7e26021f
	v_or_b32_e32 v12, 5, v4                                    // 000000005ebc: 38180885
	v_mov_b32_e32 v13, s31                                     // 000000005ec0: 7e1a021f
	v_or_b32_e32 v16, 6, v4                                    // 000000005ec4: 38200886
	v_mov_b32_e32 v17, s31                                     // 000000005ec8: 7e22021f
	v_or_b32_e32 v20, 7, v4                                    // 000000005ecc: 38280887
	v_mov_b32_e32 v21, s31                                     // 000000005ed0: 7e2a021f
	s_mov_b32 s0, 0                                            // 000000005ed4: be800080
	s_branch 2                                                 // 000000005ed8: bfa00002 <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x43e4>
	s_endpgm                                                   // 000000005edc: bfb00000
	s_mov_b32 s0, -1                                           // 000000005ee0: be8000c1
	s_wait_alu depctr_sa_sdst(0)                               // 000000005ee4: bf88ff9e
	s_and_b32 s0, s0, exec_lo                                  // 000000005ee8: 8b007e00
	s_cselect_b32 s0, 1, 0                                     // 000000005eec: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 000000005ef0: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000005ef4: bf078100
	s_cbranch_scc1 427                                         // 000000005ef8: bfa201ab <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x4aa8>
	v_cmp_gt_i64_e32 vcc_lo, s[14:15], v[8:9]                  // 000000005efc: 7ca8100e
	v_mov_b32_e32 v5, s31                                      // 000000005f00: 7e0a021f
	v_or_b32_e32 v2, 3, v4                                     // 000000005f04: 38040883
	v_or_b32_e32 v14, 1, v4                                    // 000000005f08: 381c0881
	v_or_b32_e32 v6, 2, v4                                     // 000000005f0c: 380c0882
	s_wait_alu depctr_va_vcc(0)                                // 000000005f10: bf88ff9d
	v_cndmask_b32_e32 v58, 0, v8, vcc_lo                       // 000000005f14: 02741080
	v_cmp_gt_i64_e64 s0, s[12:13], v[4:5]                      // 000000005f18: d4540000 0202080c
	v_cndmask_b32_e32 v59, 0, v9, vcc_lo                       // 000000005f20: 02761280
	v_mov_b32_e32 v7, s31                                      // 000000005f24: 7e0e021f
	s_wait_alu depctr_va_sdst(0)                               // 000000005f28: bf88f19f
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_2)// 000000005f2c: bf870123
	v_cndmask_b32_e64 v3, 0, v5, s0                            // 000000005f30: d5010003 00020a80
	v_cndmask_b32_e64 v12, 0, v4, s0                           // 000000005f38: d501000c 00020880
	v_mul_lo_u32 v18, s38, v3                                  // 000000005f40: d72c0012 02020626
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_1)// 000000005f48: bf8700a2
	v_mul_lo_u32 v19, s39, v12                                 // 000000005f4c: d72c0013 02021827
	v_mad_co_u64_u32 v[12:13], null, s38, v12, 0               // 000000005f54: d6fe7c0c 02021826
	v_add3_u32 v13, v13, v18, v19                              // 000000005f5c: d655000d 044e250d
	v_or_b32_e32 v18, 4, v4                                    // 000000005f64: 38240884
	v_mov_b32_e32 v3, s31                                      // 000000005f68: 7e06021f
	v_mov_b32_e32 v19, s31                                     // 000000005f6c: 7e26021f
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 000000005f70: bf870194
	v_lshlrev_b64_e32 v[12:13], 2, v[12:13]                    // 000000005f74: 3e181882
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[2:3]                  // 000000005f78: 7ca8040c
	s_wait_alu depctr_va_vcc(0)                                // 000000005f7c: bf88ff9d
	v_dual_mov_b32 v15, s31 :: v_dual_cndmask_b32 v44, 0, v2   // 000000005f80: ca12001f 0f2c0480
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_3)// 000000005f88: bf8701a1
	v_cmp_gt_i64_e64 s0, s[12:13], v[14:15]                    // 000000005f8c: d4540000 02021c0c
	v_cndmask_b32_e32 v43, 0, v5, vcc_lo                       // 000000005f94: 02560a80
	v_mul_lo_u32 v47, s39, v44                                 // 000000005f98: d72c002f 02025827
	v_mad_co_u64_u32 v[45:46], null, s38, v44, 0               // 000000005fa0: d6fe7c2d 02025826
	s_wait_alu depctr_va_sdst(0)                               // 000000005fa8: bf88f19f
	s_delay_alu instid0(valu_dep_4) | instskip(skip_2) | instid1(valu_dep_3)// 000000005fac: bf8701b4
	v_cndmask_b32_e64 v16, 0, v5, s0                           // 000000005fb0: d5010010 00020a80
	v_cndmask_b32_e64 v17, 0, v14, s0                          // 000000005fb8: d5010011 00021c80
	v_cmp_gt_i64_e64 s0, s[12:13], v[6:7]                      // 000000005fc0: d4540000 02020c0c
	v_mul_lo_u32 v21, s38, v16                                 // 000000005fc8: d72c0015 02022026
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_4)// 000000005fd0: bf870233
	v_mul_lo_u32 v38, s39, v17                                 // 000000005fd4: d72c0026 02022227
	v_mad_co_u64_u32 v[16:17], null, s38, v17, 0               // 000000005fdc: d6fe7c10 02022226
	s_wait_alu depctr_va_sdst(0)                               // 000000005fe4: bf88f19f
	v_cndmask_b32_e64 v20, 0, v5, s0                           // 000000005fe8: d5010014 00020a80
	v_cndmask_b32_e64 v39, 0, v6, s0                           // 000000005ff0: d5010027 00020c80
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000005ff8: bf870112
	v_mul_lo_u32 v41, s38, v20                                 // 000000005ffc: d72c0029 02022826
	v_mul_lo_u32 v40, s39, v39                                 // 000000006004: d72c0028 02024e27
	v_add3_u32 v17, v17, v21, v38                              // 00000000600c: d6550011 049a2b11
	v_mad_co_u64_u32 v[20:21], null, s38, v39, 0               // 000000006014: d6fe7c14 02024e26
	v_add_co_u32 v38, vcc_lo, s34, v12                         // 00000000601c: d7006a26 02021822
	s_wait_alu depctr_va_vcc(0)                                // 000000006024: bf88ff9d
	v_add_co_ci_u32_e64 v39, null, s35, v13, vcc_lo            // 000000006028: d5207c27 01aa1a23
	v_lshlrev_b64_e32 v[16:17], 2, v[16:17]                    // 000000006030: 3e202082
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[18:19]                // 000000006034: 7ca8240c
	v_or_b32_e32 v12, 5, v4                                    // 000000006038: 38180885
	v_mov_b32_e32 v13, s31                                     // 00000000603c: 7e1a021f
	v_add3_u32 v21, v21, v41, v40                              // 000000006040: d6550015 04a25315
	s_wait_alu depctr_va_vcc(0)                                // 000000006048: bf88ff9d
	v_cndmask_b32_e32 v44, 0, v5, vcc_lo                       // 00000000604c: 02580a80
	v_cndmask_b32_e32 v48, 0, v18, vcc_lo                      // 000000006050: 02602480
	v_add_co_u32 v40, vcc_lo, s34, v16                         // 000000006054: d7006a28 02022022
	s_wait_alu depctr_va_vcc(0)                                // 00000000605c: bf88ff9d
	v_add_co_ci_u32_e64 v41, null, s35, v17, vcc_lo            // 000000006060: d5207c29 01aa2223
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[12:13]                // 000000006068: 7ca8180c
	v_or_b32_e32 v16, 6, v4                                    // 00000000606c: 38200886
	v_mov_b32_e32 v17, s31                                     // 000000006070: 7e22021f
	v_lshlrev_b64_e32 v[20:21], 2, v[20:21]                    // 000000006074: 3e282882
	v_mul_lo_u32 v49, s39, v48                                 // 000000006078: d72c0031 02026027
	v_mul_lo_u32 v50, s38, v44                                 // 000000006080: d72c0032 02025826
	s_wait_alu depctr_va_vcc(0)                                // 000000006088: bf88ff9d
	v_dual_cndmask_b32 v51, 0, v5 :: v_dual_cndmask_b32 v52, 0, v12// 00000000608c: ca520a80 33341880
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[16:17]                // 000000006094: 7ca8200c
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_3)// 000000006098: bf870192
	v_mul_lo_u32 v56, s38, v51                                 // 00000000609c: d72c0038 02026626
	v_mul_lo_u32 v53, s39, v52                                 // 0000000060a4: d72c0035 02026827
	s_wait_alu depctr_va_vcc(0)                                // 0000000060ac: bf88ff9d
	v_cndmask_b32_e32 v54, 0, v5, vcc_lo                       // 0000000060b0: 026c0a80
	v_mul_lo_u32 v43, s38, v43                                 // 0000000060b4: d72c002b 02025626
	v_cndmask_b32_e32 v55, 0, v16, vcc_lo                      // 0000000060bc: 026e2080
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_2)// 0000000060c0: bf870113
	v_mul_lo_u32 v54, s38, v54                                 // 0000000060c4: d72c0036 02026c26
	v_mul_lo_u32 v57, s39, v55                                 // 0000000060cc: d72c0039 02026e27
	s_delay_alu instid0(valu_dep_4)                            // 0000000060d4: bf870004
	v_add3_u32 v46, v46, v43, v47                              // 0000000060d8: d655002e 04be572e
	v_mad_co_u64_u32 v[47:48], null, s38, v48, 0               // 0000000060e0: d6fe7c2f 02026026
	v_add_co_u32 v43, s0, s34, v20                             // 0000000060e8: d700002b 02022822
	s_wait_alu depctr_va_sdst(0)                               // 0000000060f0: bf88f19f
	v_add_co_ci_u32_e64 v44, null, s35, v21, s0                // 0000000060f4: d5207c2c 00022a23
	v_or_b32_e32 v20, 7, v4                                    // 0000000060fc: 38280887
	v_mov_b32_e32 v21, s31                                     // 000000006100: 7e2a021f
	v_lshlrev_b64_e32 v[45:46], 2, v[45:46]                    // 000000006104: 3e5a5a82
	v_add3_u32 v48, v48, v50, v49                              // 000000006108: d6550030 04c66530
	v_mad_co_u64_u32 v[49:50], null, s38, v52, 0               // 000000006110: d6fe7c31 02026826
	v_mad_co_u64_u32 v[51:52], null, s38, v55, 0               // 000000006118: d6fe7c33 02026e26
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[20:21]                // 000000006120: 7ca8280c
	s_delay_alu instid0(valu_dep_4)                            // 000000006124: bf870004
	v_lshlrev_b64_e32 v[47:48], 2, v[47:48]                    // 000000006128: 3e5e5e82
	v_add_co_u32 v45, s0, s34, v45                             // 00000000612c: d700002d 02025a22
	s_wait_alu depctr_va_sdst(0)                               // 000000006134: bf88f19f
	v_add_co_ci_u32_e64 v46, null, s35, v46, s0                // 000000006138: d5207c2e 00025c23
	v_add3_u32 v50, v50, v56, v53                              // 000000006140: d6550032 04d67132
	v_add3_u32 v52, v52, v54, v57                              // 000000006148: d6550034 04e66d34
	s_wait_alu depctr_va_vcc(0)                                // 000000006150: bf88ff9d
	v_dual_cndmask_b32 v53, 0, v5 :: v_dual_cndmask_b32 v54, 0, v20// 000000006154: ca520a80 35362880
	v_add_co_u32 v47, vcc_lo, s34, v47                         // 00000000615c: d7006a2f 02025e22
	v_lshlrev_b64_e32 v[49:50], 2, v[49:50]                    // 000000006164: 3e626282
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_4)// 000000006168: bf870213
	v_mul_lo_u32 v56, s38, v53                                 // 00000000616c: d72c0038 02026a26
	v_mul_lo_u32 v55, s39, v54                                 // 000000006174: d72c0037 02026c27
	v_mad_co_u64_u32 v[53:54], null, s38, v54, 0               // 00000000617c: d6fe7c35 02026c26
	v_lshlrev_b64_e32 v[51:52], 2, v[51:52]                    // 000000006184: 3e666682
	v_add_co_u32 v57, s0, s36, v42                             // 000000006188: d7000039 02025424
	s_wait_alu depctr_va_vcc(0)                                // 000000006190: bf88ff9d
	v_add_co_ci_u32_e64 v48, null, s35, v48, vcc_lo            // 000000006194: d5207c30 01aa6023
	v_add_co_u32 v49, vcc_lo, s34, v49                         // 00000000619c: d7006a31 02026222
	v_add3_u32 v54, v54, v56, v55                              // 0000000061a4: d6550036 04de7136
	s_wait_alu depctr_va_sdst(0)                               // 0000000061ac: bf88f19f
	v_add_co_ci_u32_e64 v60, null, s37, 0, s0                  // 0000000061b0: d5207c3c 00010025
	s_wait_alu depctr_va_vcc(0)                                // 0000000061b8: bf88ff9d
	v_add_co_ci_u32_e64 v50, null, s35, v50, vcc_lo            // 0000000061bc: d5207c32 01aa6423
	v_add_co_u32 v51, vcc_lo, s34, v51                         // 0000000061c4: d7006a33 02026622
	s_wait_alu depctr_va_vcc(0)                                // 0000000061cc: bf88ff9d
	v_add_co_ci_u32_e64 v52, null, s35, v52, vcc_lo            // 0000000061d0: d5207c34 01aa6823
	v_add_co_u32 v55, vcc_lo, v57, 16                          // 0000000061d8: d7006a37 02012139
	v_lshlrev_b64_e32 v[53:54], 2, v[53:54]                    // 0000000061e0: 3e6a6a82
	s_wait_alu depctr_va_vcc(0)                                // 0000000061e4: bf88ff9d
	v_add_co_ci_u32_e64 v56, null, 0, v60, vcc_lo              // 0000000061e8: d5207c38 01aa7880
	s_delay_alu instid0(valu_dep_3)                            // 0000000061f0: bf870003
	v_mul_lo_u32 v65, s25, v55                                 // 0000000061f4: d72c0041 02026e19
	v_mul_lo_u32 v66, s24, v60                                 // 0000000061fc: d72c0042 02027818
	v_mul_lo_u32 v67, s25, v57                                 // 000000006204: d72c0043 02027219
	v_add_co_u32 v53, vcc_lo, s34, v53                         // 00000000620c: d7006a35 02026a22
	v_mul_lo_u32 v64, s24, v56                                 // 000000006214: d72c0040 02027018
	v_mad_co_u64_u32 v[55:56], null, s24, v55, v[22:23]        // 00000000621c: d6fe7c37 045a6e18
	v_mad_co_u64_u32 v[60:61], null, s24, v57, v[22:23]        // 000000006224: d6fe7c3c 045a7218
	v_add_co_u32 v42, s0, s30, v42                             // 00000000622c: d700002a 0202541e
	s_wait_alu depctr_va_vcc(0)                                // 000000006234: bf88ff9d
	v_add_co_ci_u32_e64 v54, null, s35, v54, vcc_lo            // 000000006238: d5207c36 01aa6c23
	v_cmp_gt_i64_e32 vcc_lo, s[14:15], v[10:11]                // 000000006240: 7ca8140e
	s_wait_alu depctr_va_sdst(0)                               // 000000006244: bf88f19f
	v_add_co_ci_u32_e64 v57, null, s31, 0, s0                  // 000000006248: d5207c39 0001001f
	s_wait_alu depctr_va_vcc(0)                                // 000000006250: bf88ff9d
	v_dual_cndmask_b32 v63, 0, v11 :: v_dual_cndmask_b32 v62, 0, v10// 000000006254: ca521680 3f3e1480
	v_add3_u32 v10, v65, v56, v64                              // 00000000625c: d655000a 05027141
	v_add3_u32 v11, v67, v61, v66                              // 000000006264: d655000b 050a7b43
	v_mul_lo_u32 v61, s24, v57                                 // 00000000626c: d72c003d 02027218
	v_mul_lo_u32 v66, s25, v42                                 // 000000006274: d72c0042 02025419
	v_mad_co_u64_u32 v[64:65], null, s24, v42, v[22:23]        // 00000000627c: d6fe7c40 045a5418
	v_add_co_u32 v42, vcc_lo, s28, v55                         // 000000006284: d7006a2a 02026e1c
	s_wait_alu depctr_va_vcc(0)                                // 00000000628c: bf88ff9d
	v_add_co_ci_u32_e64 v55, null, s29, v10, vcc_lo            // 000000006290: d5207c37 01aa141d
	v_add_co_u32 v56, vcc_lo, s28, v60                         // 000000006298: d7006a38 0202781c
	s_wait_alu depctr_va_vcc(0)                                // 0000000062a0: bf88ff9d
	v_add_co_ci_u32_e64 v57, null, s29, v11, vcc_lo            // 0000000062a4: d5207c39 01aa161d
	v_add3_u32 v60, v66, v65, v61                              // 0000000062ac: d655003c 04f68342
	v_lshlrev_b64_e32 v[10:11], 2, v[58:59]                    // 0000000062b4: 3e147482
	v_add_co_u32 v58, vcc_lo, s26, v64                         // 0000000062b8: d7006a3a 0202801a
	v_lshlrev_b64_e32 v[22:23], 2, v[62:63]                    // 0000000062c0: 3e2c7c82
	s_wait_alu depctr_va_vcc(0)                                // 0000000062c4: bf88ff9d
	v_add_co_ci_u32_e64 v59, null, s27, v60, vcc_lo            // 0000000062c8: d5207c3b 01aa781b
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_2)// 0000000062d0: bf870123
	v_add_co_u32 v60, vcc_lo, v58, s22                         // 0000000062d4: d7006a3c 02002d3a
	s_wait_alu depctr_va_vcc(0)                                // 0000000062dc: bf88ff9d
	v_add_co_ci_u32_e64 v61, null, s23, v59, vcc_lo            // 0000000062e0: d5207c3d 01aa7617
	v_add_co_u32 v62, vcc_lo, v56, s22                         // 0000000062e8: d7006a3e 02002d38
	s_wait_alu depctr_va_vcc(0)                                // 0000000062f0: bf88ff9d
	v_add_co_ci_u32_e64 v63, null, s23, v57, vcc_lo            // 0000000062f4: d5207c3f 01aa7217
	v_add_co_u32 v64, vcc_lo, v42, s22                         // 0000000062fc: d7006a40 02002d2a
	s_lshr_b64 s[2:3], s[22:23], 2                             // 000000006304: 85828216
	s_wait_alu depctr_va_vcc(0)                                // 000000006308: bf88ff9d
	v_add_co_ci_u32_e64 v65, null, s23, v55, vcc_lo            // 00000000630c: d5207c41 01aa6e17
	s_wait_alu depctr_sa_sdst(0)                               // 000000006314: bf88ff9e
	v_add_co_u32 v66, vcc_lo, v38, s2                          // 000000006318: d7006a42 02000526
	s_wait_alu depctr_va_vcc(0)                                // 000000006320: bf88ff9d
	v_add_co_ci_u32_e64 v67, null, s3, v39, vcc_lo             // 000000006324: d5207c43 01aa4e03
	v_add_co_u32 v68, vcc_lo, v40, s2                          // 00000000632c: d7006a44 02000528
	s_wait_alu depctr_va_vcc(0)                                // 000000006334: bf88ff9d
	v_add_co_ci_u32_e64 v69, null, s3, v41, vcc_lo             // 000000006338: d5207c45 01aa5203
	v_add_co_u32 v70, vcc_lo, v43, s2                          // 000000006340: d7006a46 0200052b
	s_wait_alu depctr_va_vcc(0)                                // 000000006348: bf88ff9d
	v_add_co_ci_u32_e64 v71, null, s3, v44, vcc_lo             // 00000000634c: d5207c47 01aa5803
	v_add_co_u32 v72, vcc_lo, v45, s2                          // 000000006354: d7006a48 0200052d
	s_lshr_b64 s[0:1], s[22:23], 4                             // 00000000635c: 85808416
	s_wait_alu depctr_va_vcc(0)                                // 000000006360: bf88ff9d
	v_add_co_ci_u32_e64 v73, null, s3, v46, vcc_lo             // 000000006364: d5207c49 01aa5c03
	v_add_co_u32 v74, vcc_lo, v47, s2                          // 00000000636c: d7006a4a 0200052f
	s_wait_alu depctr_sa_sdst(0)                               // 000000006374: bf88ff9e
	s_mul_u64 s[0:1], s[0:1], s[14:15]                         // 000000006378: aa800e00
	s_wait_alu depctr_va_vcc(0)                                // 00000000637c: bf88ff9d
	v_add_co_ci_u32_e64 v75, null, s3, v48, vcc_lo             // 000000006380: d5207c4b 01aa6003
	v_add_co_u32 v76, vcc_lo, v49, s2                          // 000000006388: d7006a4c 02000531
	s_wait_alu depctr_va_vcc(0)                                // 000000006390: bf88ff9d
	v_add_co_ci_u32_e64 v77, null, s3, v50, vcc_lo             // 000000006394: d5207c4d 01aa6403
	v_add_co_u32 v78, vcc_lo, v51, s2                          // 00000000639c: d7006a4e 02000533
	s_wait_alu depctr_sa_sdst(0)                               // 0000000063a4: bf88ff9e
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000063a8: 84808200
	s_wait_alu depctr_va_vcc(0)                                // 0000000063ac: bf88ff9d
	v_add_co_ci_u32_e64 v79, null, s3, v52, vcc_lo             // 0000000063b0: d5207c4f 01aa6803
	v_add_co_u32 v80, vcc_lo, v53, s2                          // 0000000063b8: d7006a50 02000535
	s_wait_alu depctr_sa_sdst(0)                               // 0000000063c0: bf88ff9e
	s_add_nc_u64 s[0:1], s[18:19], s[0:1]                      // 0000000063c4: a9800012
	s_wait_alu depctr_va_vcc(0)                                // 0000000063c8: bf88ff9d
	v_add_co_ci_u32_e64 v81, null, s3, v54, vcc_lo             // 0000000063cc: d5207c51 01aa6c03
	global_load_b64 v[82:83], v[60:61], off                    // 0000000063d4: ee05407c 00000052 0000003c
	s_clause 0x1                                               // 0000000063e0: bf850001
	global_load_b64 v[84:85], v[62:63], off                    // 0000000063e4: ee05407c 00000054 0000003e
	global_load_b64 v[86:87], v[64:65], off                    // 0000000063f0: ee05407c 00000056 00000040
	s_wait_alu depctr_sa_sdst(0)                               // 0000000063fc: bf88ff9e
	v_add_co_u32 v60, vcc_lo, s0, v10                          // 000000006400: d7006a3c 02021400
	s_wait_alu depctr_va_vcc(0)                                // 000000006408: bf88ff9d
	v_add_co_ci_u32_e64 v61, null, s1, v11, vcc_lo             // 00000000640c: d5207c3d 01aa1601
	v_add_co_u32 v62, vcc_lo, s0, v22                          // 000000006414: d7006a3e 02022c00
	s_wait_alu depctr_va_vcc(0)                                // 00000000641c: bf88ff9d
	v_add_co_ci_u32_e64 v63, null, s1, v23, vcc_lo             // 000000006420: d5207c3f 01aa2e01
	s_clause 0x7                                               // 000000006428: bf850007
	global_load_b32 v88, v[66:67], off                         // 00000000642c: ee05007c 00000058 00000042
	global_load_b32 v89, v[68:69], off                         // 000000006438: ee05007c 00000059 00000044
	global_load_b32 v90, v[70:71], off                         // 000000006444: ee05007c 0000005a 00000046
	global_load_b32 v91, v[72:73], off                         // 000000006450: ee05007c 0000005b 00000048
	global_load_b32 v92, v[74:75], off                         // 00000000645c: ee05007c 0000005c 0000004a
	global_load_b32 v76, v[76:77], off                         // 000000006468: ee05007c 0000004c 0000004c
	global_load_b32 v77, v[78:79], off                         // 000000006474: ee05007c 0000004d 0000004e
	global_load_b32 v78, v[80:81], off                         // 000000006480: ee05007c 0000004e 00000050
	s_clause 0x1                                               // 00000000648c: bf850001
	global_load_b32 v79, v[60:61], off                         // 000000006490: ee05007c 0000004f 0000003c
	global_load_b32 v80, v[62:63], off                         // 00000000649c: ee05007c 00000050 0000003e
	s_add_nc_u64 s[22:23], s[22:23], 16                        // 0000000064a8: a9969016
	s_wait_alu depctr_sa_sdst(0)                               // 0000000064ac: bf88ff9e
	v_cmp_lt_i64_e64 s0, s[22:23], s[20:21]                    // 0000000064b0: d4510000 02002816
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000000064b8: 8b6a007e
	s_wait_loadcnt 0xb                                         // 0000000064bc: bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[82:83], v[84:85], 0// 0000000064c0: cc46403c 1a02a952
	s_wait_loadcnt 0xa                                         // 0000000064c8: bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[68:75], v[82:83], v[86:87], 0// 0000000064cc: cc464044 1a02ad52
	s_wait_loadcnt 0x1                                         // 0000000064d4: bfc00001
	v_dual_mul_f32 v81, v88, v79 :: v_dual_mul_f32 v82, v79, v89// 0000000064d8: c8c69f58 5152b34f
	v_dual_mul_f32 v83, v79, v90 :: v_dual_mul_f32 v84, v79, v91// 0000000064e0: c8c6b54f 5354b74f
	s_delay_alu instid0(valu_dep_2)                            // 0000000064e8: bf870002
	v_dual_mul_f32 v85, v79, v92 :: v_dual_mul_f32 v60, v60, v81// 0000000064ec: c8c6b94f 553ca33c
	v_dual_mul_f32 v86, v79, v76 :: v_dual_mul_f32 v87, v79, v77// 0000000064f4: c8c6994f 56569b4f
	s_wait_loadcnt 0x0                                         // 0000000064fc: bfc00000
	v_dual_mul_f32 v79, v79, v78 :: v_dual_mul_f32 v88, v88, v80// 000000006500: c8c69d4f 4f58a158
	v_dual_mul_f32 v89, v89, v80 :: v_dual_mul_f32 v90, v90, v80// 000000006508: c8c6a159 595aa15a
	v_dual_mul_f32 v91, v91, v80 :: v_dual_mul_f32 v92, v92, v80// 000000006510: c8c6a15b 5b5ca15c
	v_dual_mul_f32 v76, v76, v80 :: v_dual_mul_f32 v77, v77, v80// 000000006518: c8c6a14c 4c4ca14d
	v_dual_mul_f32 v78, v78, v80 :: v_dual_mul_f32 v61, v61, v82// 000000006520: c8c6a14e 4e3ca53d
	v_dual_mul_f32 v62, v62, v83 :: v_dual_mul_f32 v63, v63, v84// 000000006528: c8c6a73e 3e3ea93f
	v_dual_mul_f32 v64, v64, v85 :: v_dual_mul_f32 v65, v65, v86// 000000006530: c8c6ab40 4040ad41
	v_dual_mul_f32 v66, v66, v87 :: v_dual_mul_f32 v69, v69, v89// 000000006538: c8c6af42 4244b345
	v_dual_mul_f32 v67, v67, v79 :: v_dual_mul_f32 v68, v68, v88// 000000006540: c8c69f43 4344b144
	v_dual_mul_f32 v70, v70, v90 :: v_dual_mul_f32 v71, v71, v91// 000000006548: c8c6b546 4646b747
	v_dual_mul_f32 v72, v72, v92 :: v_dual_mul_f32 v75, v75, v78// 000000006550: c8c6b948 484a9d4b
	v_dual_mul_f32 v73, v73, v76 :: v_dual_mul_f32 v74, v74, v77// 000000006558: c8c69949 494a9b4a
	v_dual_add_f32 v1, v1, v60 :: v_dual_add_f32 v36, v36, v62 // 000000006560: c9087901 01247d24
	v_dual_add_f32 v37, v37, v61 :: v_dual_add_f32 v34, v34, v64// 000000006568: c9087b25 25228122
	v_dual_add_f32 v35, v35, v63 :: v_dual_add_f32 v32, v32, v68// 000000006570: c9087f23 23208920
	v_dual_add_f32 v33, v33, v65 :: v_dual_add_f32 v28, v28, v71// 000000006578: c9088321 211c8f1c
	v_dual_add_f32 v31, v31, v66 :: v_dual_add_f32 v30, v30, v69// 000000006580: c908851f 1f1e8b1e
	v_dual_add_f32 v27, v27, v67 :: v_dual_add_f32 v26, v26, v72// 000000006588: c908871b 1b1a911a
	v_dual_add_f32 v29, v29, v70 :: v_dual_add_f32 v0, v0, v75 // 000000006590: c9088d1d 1d009700
	v_dual_add_f32 v25, v25, v73 :: v_dual_add_f32 v24, v24, v74// 000000006598: c9089319 19189518
	s_wait_alu depctr_sa_sdst(0)                               // 0000000065a0: bf88ff9e
	s_cbranch_vccnz 65354                                      // 0000000065a4: bfa4ff4a <tessera_rocm_scaled_matmul_79c17ce3b2268c6f+0x47d0>
	v_mul_lo_u32 v10, s15, v4                                  // 0000000065a8: d72c000a 0202080f
	v_mul_lo_u32 v11, s14, v5                                  // 0000000065b0: d72c000b 02020a0e
	v_mad_co_u64_u32 v[4:5], null, s14, v4, 0                  // 0000000065b8: d6fe7c04 0202080e
	v_mul_lo_u32 v22, s15, v14                                 // 0000000065c0: d72c0016 02021c0f
	v_mul_lo_u32 v15, s14, v15                                 // 0000000065c8: d72c000f 02021e0e
	v_or_b32_e32 v23, 0x400000, v1                             // 0000000065d0: 382e02ff 00400000
	v_bfe_u32 v38, v37, 16, 1                                  // 0000000065d8: d6100026 02052125
	v_lshlrev_b64_e32 v[8:9], 1, v[8:9]                        // 0000000065e0: 3e101081
	v_mul_lo_u32 v39, s15, v6                                  // 0000000065e4: d72c0027 02020c0f
	v_mul_lo_u32 v3, s14, v3                                   // 0000000065ec: d72c0003 0202060e
	v_add3_u32 v5, v5, v11, v10                                // 0000000065f4: d6550005 042a1705
	v_mad_co_u64_u32 v[10:11], null, s14, v14, 0               // 0000000065fc: d6fe7c0a 02021c0e
	v_bfe_u32 v14, v1, 16, 1                                   // 000000006604: d610000e 02052101
	v_mul_lo_u32 v19, s14, v19                                 // 00000000660c: d72c0013 0202260e
	v_mul_lo_u32 v21, s14, v21                                 // 000000006614: d72c0015 02022a0e
	v_lshlrev_b64_e32 v[4:5], 1, v[4:5]                        // 00000000661c: 3e080881
	s_delay_alu instid0(valu_dep_4) | instskip(skip_2) | instid1(valu_dep_4)// 000000006620: bf870234
	v_add3_u32 v14, v14, v1, 0x7fff                            // 000000006624: d655000e 03fe030e 00007fff
	v_add3_u32 v11, v11, v15, v22                              // 000000006630: d655000b 045a1f0b
	v_add3_u32 v15, v38, v37, 0x7fff                           // 000000006638: d655000f 03fe4b26 00007fff
	v_add_co_u32 v4, vcc_lo, s16, v4                           // 000000006644: d7006a04 02020810
	s_wait_alu depctr_va_vcc(0)                                // 00000000664c: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, s17, v5, vcc_lo              // 000000006650: d5207c05 01aa0a11
	v_cmp_u_f32_e32 vcc_lo, v1, v1                             // 000000006658: 7c300301
	v_or_b32_e32 v22, 0x400000, v37                            // 00000000665c: 382c4aff 00400000
	v_lshlrev_b64_e32 v[10:11], 1, v[10:11]                    // 000000006664: 3e141481
	s_wait_alu depctr_va_vcc(0)                                // 000000006668: bf88ff9d
	v_cndmask_b32_e32 v1, v14, v23, vcc_lo                     // 00000000666c: 02022f0e
	v_mul_lo_u32 v14, s14, v7                                  // 000000006670: d72c000e 02020e0e
	v_mad_co_u64_u32 v[6:7], null, s14, v6, 0                  // 000000006678: d6fe7c06 02020c0e
	v_add_co_u32 v4, vcc_lo, v4, v8                            // 000000006680: d7006a04 02021104
	s_wait_alu depctr_va_vcc(0)                                // 000000006688: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, v5, v9, vcc_lo               // 00000000668c: d5207c05 01aa1305
	v_cmp_u_f32_e32 vcc_lo, v37, v37                           // 000000006694: 7c304b25
	v_mul_lo_u32 v23, s15, v2                                  // 000000006698: d72c0017 0202040f
	v_bfe_u32 v37, v35, 16, 1                                  // 0000000066a0: d6100025 02052123
	v_add3_u32 v7, v7, v14, v39                                // 0000000066a8: d6550007 049e1d07
	v_bfe_u32 v14, v36, 16, 1                                  // 0000000066b0: d610000e 02052124
	s_wait_alu depctr_va_vcc(0)                                // 0000000066b8: bf88ff9d
	v_cndmask_b32_e32 v22, v15, v22, vcc_lo                    // 0000000066bc: 022c2d0f
	global_store_d16_hi_b16 v[4:5], v1, off                    // 0000000066c0: ee09407c 00800000 00000004
	v_add_co_u32 v1, vcc_lo, s16, v10                          // 0000000066cc: d7006a01 02021410
	v_lshlrev_b64_e32 v[6:7], 1, v[6:7]                        // 0000000066d4: 3e0c0c81
	s_wait_alu depctr_va_vcc(0)                                // 0000000066d8: bf88ff9d
	v_add_co_ci_u32_e64 v11, null, s17, v11, vcc_lo            // 0000000066dc: d5207c0b 01aa1611
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_3)// 0000000066e4: bf8701b3
	v_add_co_u32 v10, vcc_lo, v1, v8                           // 0000000066e8: d7006a0a 02021101
	v_mad_co_u64_u32 v[1:2], null, s14, v2, 0                  // 0000000066f0: d6fe7c01 0202040e
	s_wait_alu depctr_va_vcc(0)                                // 0000000066f8: bf88ff9d
	v_add_co_ci_u32_e64 v11, null, v11, v9, vcc_lo             // 0000000066fc: d5207c0b 01aa130b
	v_add_co_u32 v6, vcc_lo, s16, v6                           // 000000006704: d7006a06 02020c10
	v_add3_u32 v14, v14, v36, 0x7fff                           // 00000000670c: d655000e 03fe490e 00007fff
	v_or_b32_e32 v15, 0x400000, v36                            // 000000006718: 381e48ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000006720: bf88ff9d
	v_add_co_ci_u32_e64 v7, null, s17, v7, vcc_lo              // 000000006724: d5207c07 01aa0e11
	v_cmp_u_f32_e32 vcc_lo, v36, v36                           // 00000000672c: 7c304924
	v_add3_u32 v2, v2, v3, v23                                 // 000000006730: d6550002 045e0702
	v_mul_lo_u32 v3, s15, v18                                  // 000000006738: d72c0003 0202240f
	v_or_b32_e32 v23, 0x400000, v35                            // 000000006740: 382e46ff 00400000
	global_store_d16_hi_b16 v[10:11], v22, off                 // 000000006748: ee09407c 0b000000 0000000a
	s_wait_alu depctr_va_vcc(0)                                // 000000006754: bf88ff9d
	v_cndmask_b32_e32 v36, v14, v15, vcc_lo                    // 000000006758: 02481f0e
	v_mad_co_u64_u32 v[14:15], null, s14, v18, 0               // 00000000675c: d6fe7c0e 0202240e
	v_add_co_u32 v6, vcc_lo, v6, v8                            // 000000006764: d7006a06 02021106
	v_lshlrev_b64_e32 v[1:2], 1, v[1:2]                        // 00000000676c: 3e020281
	s_wait_alu depctr_va_vcc(0)                                // 000000006770: bf88ff9d
	v_add_co_ci_u32_e64 v7, null, v7, v9, vcc_lo               // 000000006774: d5207c07 01aa1307
	v_add3_u32 v18, v37, v35, 0x7fff                           // 00000000677c: d6550012 03fe4725 00007fff
	v_cmp_u_f32_e32 vcc_lo, v35, v35                           // 000000006788: 7c304723
	v_add3_u32 v15, v15, v19, v3                               // 00000000678c: d655000f 040e270f
	v_bfe_u32 v22, v34, 16, 1                                  // 000000006794: d6100016 02052122
	global_store_d16_hi_b16 v[6:7], v36, off                   // 00000000679c: ee09407c 12000000 00000006
	v_mul_lo_u32 v35, s15, v12                                 // 0000000067a8: d72c0023 0202180f
	s_wait_alu depctr_va_vcc(0)                                // 0000000067b0: bf88ff9d
	v_cndmask_b32_e32 v18, v18, v23, vcc_lo                    // 0000000067b4: 02242f12
	v_add_co_u32 v3, vcc_lo, s16, v1                           // 0000000067b8: d7006a03 02020210
	s_wait_alu depctr_va_vcc(0)                                // 0000000067c0: bf88ff9d
	v_add_co_ci_u32_e64 v19, null, s17, v2, vcc_lo             // 0000000067c4: d5207c13 01aa0411
	v_lshlrev_b64_e32 v[1:2], 1, v[14:15]                      // 0000000067cc: 3e021c81
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 0000000067d0: bf8701a3
	v_add_co_u32 v14, vcc_lo, v3, v8                           // 0000000067d4: d7006a0e 02021103
	s_wait_alu depctr_va_vcc(0)                                // 0000000067dc: bf88ff9d
	v_add_co_ci_u32_e64 v15, null, v19, v9, vcc_lo             // 0000000067e0: d5207c0f 01aa1313
	v_add3_u32 v3, v22, v34, 0x7fff                            // 0000000067e8: d6550003 03fe4516 00007fff
	s_delay_alu instid0(valu_dep_4)                            // 0000000067f4: bf870004
	v_add_co_u32 v22, vcc_lo, s16, v1                          // 0000000067f8: d7006a16 02020210
	s_wait_alu depctr_va_vcc(0)                                // 000000006800: bf88ff9d
	v_add_co_ci_u32_e64 v23, null, s17, v2, vcc_lo             // 000000006804: d5207c17 01aa0411
	v_mul_lo_u32 v36, s14, v13                                 // 00000000680c: d72c0024 02021a0e
	v_mad_co_u64_u32 v[1:2], null, s14, v12, 0                 // 000000006814: d6fe7c01 0202180e
	v_or_b32_e32 v19, 0x400000, v34                            // 00000000681c: 382644ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v34, v34                           // 000000006824: 7c304522
	v_or_b32_e32 v34, 0x400000, v33                            // 000000006828: 384442ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000006830: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000006834: bf870003
	v_cndmask_b32_e32 v3, v3, v19, vcc_lo                      // 000000006838: 02062703
	v_add3_u32 v2, v2, v36, v35                                // 00000000683c: d6550002 048e4902
	v_add_co_u32 v12, vcc_lo, v22, v8                          // 000000006844: d7006a0c 02021116
	v_bfe_u32 v19, v33, 16, 1                                  // 00000000684c: d6100013 02052121
	s_wait_alu depctr_va_vcc(0)                                // 000000006854: bf88ff9d
	v_add_co_ci_u32_e64 v13, null, v23, v9, vcc_lo             // 000000006858: d5207c0d 01aa1317
	v_mul_lo_u32 v22, s15, v16                                 // 000000006860: d72c0016 0202200f
	v_mul_lo_u32 v23, s14, v17                                 // 000000006868: d72c0017 0202220e
	v_mad_co_u64_u32 v[16:17], null, s14, v16, 0               // 000000006870: d6fe7c10 0202200e
	v_lshlrev_b64_e32 v[1:2], 1, v[1:2]                        // 000000006878: 3e020281
	v_add3_u32 v19, v19, v33, 0x7fff                           // 00000000687c: d6550013 03fe4313 00007fff
	v_cmp_u_f32_e32 vcc_lo, v33, v33                           // 000000006888: 7c304321
	s_clause 0x1                                               // 00000000688c: bf850001
	global_store_d16_hi_b16 v[14:15], v18, off                 // 000000006890: ee09407c 09000000 0000000e
	global_store_d16_hi_b16 v[12:13], v3, off                  // 00000000689c: ee09407c 01800000 0000000c
	v_bfe_u32 v18, v31, 16, 1                                  // 0000000068a8: d6100012 0205211f
	v_or_b32_e32 v33, 0x400000, v31                            // 0000000068b0: 38423eff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000068b8: bf88ff9d
	v_cndmask_b32_e32 v3, v19, v34, vcc_lo                     // 0000000068bc: 02064513
	v_add3_u32 v17, v17, v23, v22                              // 0000000068c0: d6550011 045a2f11
	v_add_co_u32 v19, vcc_lo, s16, v1                          // 0000000068c8: d7006a13 02020210
	s_wait_alu depctr_va_vcc(0)                                // 0000000068d0: bf88ff9d
	v_add_co_ci_u32_e64 v22, null, s17, v2, vcc_lo             // 0000000068d4: d5207c16 01aa0411
	v_add3_u32 v23, v18, v31, 0x7fff                           // 0000000068dc: d6550017 03fe3f12 00007fff
	v_lshlrev_b64_e32 v[1:2], 1, v[16:17]                      // 0000000068e8: 3e022081
	v_mul_lo_u32 v34, s15, v20                                 // 0000000068ec: d72c0022 0202280f
	v_mad_co_u64_u32 v[16:17], null, s14, v20, 0               // 0000000068f4: d6fe7c10 0202280e
	v_add_co_u32 v18, vcc_lo, v19, v8                          // 0000000068fc: d7006a12 02021113
	s_wait_alu depctr_va_vcc(0)                                // 000000006904: bf88ff9d
	v_add_co_ci_u32_e64 v19, null, v22, v9, vcc_lo             // 000000006908: d5207c13 01aa1316
	v_cmp_u_f32_e32 vcc_lo, v31, v31                           // 000000006910: 7c303f1f
	v_or_b32_e32 v22, 0x400000, v27                            // 000000006914: 382c36ff 00400000
	v_add3_u32 v17, v17, v21, v34                              // 00000000691c: d6550011 048a2b11
	v_bfe_u32 v21, v27, 16, 1                                  // 000000006924: d6100015 0205211b
	s_wait_alu depctr_va_vcc(0)                                // 00000000692c: bf88ff9d
	v_cndmask_b32_e32 v20, v23, v33, vcc_lo                    // 000000006930: 02284317
	v_add_co_u32 v1, vcc_lo, s16, v1                           // 000000006934: d7006a01 02020210
	s_wait_alu depctr_va_vcc(0)                                // 00000000693c: bf88ff9d
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000006940: d5207c02 01aa0411
	v_lshlrev_b64_e32 v[16:17], 1, v[16:17]                    // 000000006948: 3e202081
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 00000000694c: bf8701a3
	v_add_co_u32 v1, vcc_lo, v1, v8                            // 000000006950: d7006a01 02021101
	s_wait_alu depctr_va_vcc(0)                                // 000000006958: bf88ff9d
	v_add_co_ci_u32_e64 v2, null, v2, v9, vcc_lo               // 00000000695c: d5207c02 01aa1302
	v_add3_u32 v21, v21, v27, 0x7fff                           // 000000006964: d6550015 03fe3715 00007fff
	v_cmp_u_f32_e32 vcc_lo, v27, v27                           // 000000006970: 7c30371b
	s_clause 0x1                                               // 000000006974: bf850001
	global_store_d16_hi_b16 v[18:19], v3, off                  // 000000006978: ee09407c 01800000 00000012
	global_store_d16_hi_b16 v[1:2], v20, off                   // 000000006984: ee09407c 0a000000 00000001
	v_bfe_u32 v20, v32, 16, 1                                  // 000000006990: d6100014 02052120
	s_wait_alu depctr_va_vcc(0)                                // 000000006998: bf88ff9d
	v_cndmask_b32_e32 v3, v21, v22, vcc_lo                     // 00000000699c: 02062d15
	v_add_co_u32 v16, vcc_lo, s16, v16                         // 0000000069a0: d7006a10 02022010
	s_wait_alu depctr_va_vcc(0)                                // 0000000069a8: bf88ff9d
	v_add_co_ci_u32_e64 v17, null, s17, v17, vcc_lo            // 0000000069ac: d5207c11 01aa2211
	v_add3_u32 v20, v20, v32, 0x7fff                           // 0000000069b4: d6550014 03fe4114 00007fff
	s_delay_alu instid0(valu_dep_3)                            // 0000000069c0: bf870003
	v_add_co_u32 v8, vcc_lo, v16, v8                           // 0000000069c4: d7006a08 02021110
	v_or_b32_e32 v21, 0x400000, v32                            // 0000000069cc: 382a40ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000069d4: bf88ff9d
	v_add_co_ci_u32_e64 v9, null, v17, v9, vcc_lo              // 0000000069d8: d5207c09 01aa1311
	v_bfe_u32 v16, v30, 16, 1                                  // 0000000069e0: d6100010 0205211e
	v_cmp_u_f32_e32 vcc_lo, v32, v32                           // 0000000069e8: 7c304120
	global_store_d16_hi_b16 v[8:9], v3, off                    // 0000000069ec: ee09407c 01800000 00000008
	v_add3_u32 v3, v16, v30, 0x7fff                            // 0000000069f8: d6550003 03fe3d10 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000006a04: bf88ff9d
	v_cndmask_b32_e32 v17, v20, v21, vcc_lo                    // 000000006a08: 02222b14
	v_bfe_u32 v20, v29, 16, 1                                  // 000000006a0c: d6100014 0205211d
	v_or_b32_e32 v16, 0x400000, v30                            // 000000006a14: 38203cff 00400000
	v_cmp_u_f32_e32 vcc_lo, v30, v30                           // 000000006a1c: 7c303d1e
	global_store_d16_hi_b16 v[4:5], v17, off offset:32         // 000000006a20: ee09407c 08800000 00002004
	v_add3_u32 v4, v20, v29, 0x7fff                            // 000000006a2c: d6550004 03fe3b14 00007fff
	v_or_b32_e32 v5, 0x400000, v29                             // 000000006a38: 380a3aff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000006a40: bf88ff9d
	v_cndmask_b32_e32 v3, v3, v16, vcc_lo                      // 000000006a44: 02062103
	v_bfe_u32 v16, v28, 16, 1                                  // 000000006a48: d6100010 0205211c
	v_cmp_u_f32_e32 vcc_lo, v29, v29                           // 000000006a50: 7c303b1d
	global_store_d16_hi_b16 v[10:11], v3, off offset:32        // 000000006a54: ee09407c 01800000 0000200a
	v_add3_u32 v3, v16, v28, 0x7fff                            // 000000006a60: d6550003 03fe3910 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000006a6c: bf88ff9d
	v_cndmask_b32_e32 v4, v4, v5, vcc_lo                       // 000000006a70: 02080b04
	v_bfe_u32 v5, v26, 16, 1                                   // 000000006a74: d6100005 0205211a
	v_or_b32_e32 v10, 0x400000, v28                            // 000000006a7c: 381438ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v28, v28                           // 000000006a84: 7c30391c
	v_or_b32_e32 v16, 0x400000, v0                             // 000000006a88: 382000ff 00400000
	global_store_d16_hi_b16 v[6:7], v4, off offset:32          // 000000006a90: ee09407c 02000000 00002006
	v_add3_u32 v4, v5, v26, 0x7fff                             // 000000006a9c: d6550004 03fe3505 00007fff
	v_or_b32_e32 v5, 0x400000, v26                             // 000000006aa8: 380a34ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000006ab0: bf88ff9d
	v_cndmask_b32_e32 v3, v3, v10, vcc_lo                      // 000000006ab4: 02061503
	v_bfe_u32 v6, v25, 16, 1                                   // 000000006ab8: d6100006 02052119
	v_cmp_u_f32_e32 vcc_lo, v26, v26                           // 000000006ac0: 7c30351a
	v_bfe_u32 v7, v24, 16, 1                                   // 000000006ac4: d6100007 02052118
	v_or_b32_e32 v10, 0x400000, v25                            // 000000006acc: 381432ff 00400000
	v_or_b32_e32 v11, 0x400000, v24                            // 000000006ad4: 381630ff 00400000
	v_add3_u32 v6, v6, v25, 0x7fff                             // 000000006adc: d6550006 03fe3306 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000006ae8: bf88ff9d
	v_cndmask_b32_e32 v4, v4, v5, vcc_lo                       // 000000006aec: 02080b04
	v_cmp_u_f32_e32 vcc_lo, v25, v25                           // 000000006af0: 7c303319
	v_bfe_u32 v5, v0, 16, 1                                    // 000000006af4: d6100005 02052100
	v_add3_u32 v7, v7, v24, 0x7fff                             // 000000006afc: d6550007 03fe3107 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000006b08: bf88ff9d
	v_cndmask_b32_e32 v6, v6, v10, vcc_lo                      // 000000006b0c: 020c1506
	v_cmp_u_f32_e32 vcc_lo, v24, v24                           // 000000006b10: 7c303118
	v_add3_u32 v5, v5, v0, 0x7fff                              // 000000006b14: d6550005 03fe0105 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000006b20: bf88ff9d
	v_cndmask_b32_e32 v7, v7, v11, vcc_lo                      // 000000006b24: 020e1707
	v_cmp_u_f32_e32 vcc_lo, v0, v0                             // 000000006b28: 7c300100
	s_wait_alu depctr_va_vcc(0)                                // 000000006b2c: bf88ff9d
	v_cndmask_b32_e32 v0, v5, v16, vcc_lo                      // 000000006b30: 02002105
	s_clause 0x4                                               // 000000006b34: bf850004
	global_store_d16_hi_b16 v[14:15], v3, off offset:32        // 000000006b38: ee09407c 01800000 0000200e
	global_store_d16_hi_b16 v[12:13], v4, off offset:32        // 000000006b44: ee09407c 02000000 0000200c
	global_store_d16_hi_b16 v[18:19], v6, off offset:32        // 000000006b50: ee09407c 03000000 00002012
	global_store_d16_hi_b16 v[1:2], v7, off offset:32          // 000000006b5c: ee09407c 03800000 00002001
	global_store_d16_hi_b16 v[8:9], v0, off offset:32          // 000000006b68: ee09407c 00000000 00002008
	s_endpgm                                                   // 000000006b74: bfb00000
	s_code_end                                                 // 000000006b78: bf9f0000
	s_code_end                                                 // 000000006b7c: bf9f0000
	s_code_end                                                 // 000000006b80: bf9f0000
	s_code_end                                                 // 000000006b84: bf9f0000
	s_code_end                                                 // 000000006b88: bf9f0000
	s_code_end                                                 // 000000006b8c: bf9f0000
	s_code_end                                                 // 000000006b90: bf9f0000
	s_code_end                                                 // 000000006b94: bf9f0000
	s_code_end                                                 // 000000006b98: bf9f0000
	s_code_end                                                 // 000000006b9c: bf9f0000
	s_code_end                                                 // 000000006ba0: bf9f0000
	s_code_end                                                 // 000000006ba4: bf9f0000
	s_code_end                                                 // 000000006ba8: bf9f0000
	s_code_end                                                 // 000000006bac: bf9f0000
	s_code_end                                                 // 000000006bb0: bf9f0000
	s_code_end                                                 // 000000006bb4: bf9f0000
	s_code_end                                                 // 000000006bb8: bf9f0000
	s_code_end                                                 // 000000006bbc: bf9f0000
	s_code_end                                                 // 000000006bc0: bf9f0000
	s_code_end                                                 // 000000006bc4: bf9f0000
	s_code_end                                                 // 000000006bc8: bf9f0000
	s_code_end                                                 // 000000006bcc: bf9f0000
	s_code_end                                                 // 000000006bd0: bf9f0000
	s_code_end                                                 // 000000006bd4: bf9f0000
	s_code_end                                                 // 000000006bd8: bf9f0000
	s_code_end                                                 // 000000006bdc: bf9f0000
	s_code_end                                                 // 000000006be0: bf9f0000
	s_code_end                                                 // 000000006be4: bf9f0000
	s_code_end                                                 // 000000006be8: bf9f0000
	s_code_end                                                 // 000000006bec: bf9f0000
	s_code_end                                                 // 000000006bf0: bf9f0000
	s_code_end                                                 // 000000006bf4: bf9f0000
	s_code_end                                                 // 000000006bf8: bf9f0000
	s_code_end                                                 // 000000006bfc: bf9f0000
	s_code_end                                                 // 000000006c00: bf9f0000
	s_code_end                                                 // 000000006c04: bf9f0000
	s_code_end                                                 // 000000006c08: bf9f0000
	s_code_end                                                 // 000000006c0c: bf9f0000
	s_code_end                                                 // 000000006c10: bf9f0000
	s_code_end                                                 // 000000006c14: bf9f0000
	s_code_end                                                 // 000000006c18: bf9f0000
	s_code_end                                                 // 000000006c1c: bf9f0000
	s_code_end                                                 // 000000006c20: bf9f0000
	s_code_end                                                 // 000000006c24: bf9f0000
	s_code_end                                                 // 000000006c28: bf9f0000
	s_code_end                                                 // 000000006c2c: bf9f0000
	s_code_end                                                 // 000000006c30: bf9f0000
	s_code_end                                                 // 000000006c34: bf9f0000
	s_code_end                                                 // 000000006c38: bf9f0000
	s_code_end                                                 // 000000006c3c: bf9f0000
	s_code_end                                                 // 000000006c40: bf9f0000
	s_code_end                                                 // 000000006c44: bf9f0000
	s_code_end                                                 // 000000006c48: bf9f0000
	s_code_end                                                 // 000000006c4c: bf9f0000
	s_code_end                                                 // 000000006c50: bf9f0000
	s_code_end                                                 // 000000006c54: bf9f0000
	s_code_end                                                 // 000000006c58: bf9f0000
	s_code_end                                                 // 000000006c5c: bf9f0000
	s_code_end                                                 // 000000006c60: bf9f0000
	s_code_end                                                 // 000000006c64: bf9f0000
	s_code_end                                                 // 000000006c68: bf9f0000
	s_code_end                                                 // 000000006c6c: bf9f0000
	s_code_end                                                 // 000000006c70: bf9f0000
	s_code_end                                                 // 000000006c74: bf9f0000
	s_code_end                                                 // 000000006c78: bf9f0000
	s_code_end                                                 // 000000006c7c: bf9f0000
	s_code_end                                                 // 000000006c80: bf9f0000
	s_code_end                                                 // 000000006c84: bf9f0000
	s_code_end                                                 // 000000006c88: bf9f0000
	s_code_end                                                 // 000000006c8c: bf9f0000
	s_code_end                                                 // 000000006c90: bf9f0000
	s_code_end                                                 // 000000006c94: bf9f0000
	s_code_end                                                 // 000000006c98: bf9f0000
	s_code_end                                                 // 000000006c9c: bf9f0000
	s_code_end                                                 // 000000006ca0: bf9f0000
	s_code_end                                                 // 000000006ca4: bf9f0000
	s_code_end                                                 // 000000006ca8: bf9f0000
	s_code_end                                                 // 000000006cac: bf9f0000
	s_code_end                                                 // 000000006cb0: bf9f0000
	s_code_end                                                 // 000000006cb4: bf9f0000
	s_code_end                                                 // 000000006cb8: bf9f0000
	s_code_end                                                 // 000000006cbc: bf9f0000
	s_code_end                                                 // 000000006cc0: bf9f0000
	s_code_end                                                 // 000000006cc4: bf9f0000
	s_code_end                                                 // 000000006cc8: bf9f0000
	s_code_end                                                 // 000000006ccc: bf9f0000
	s_code_end                                                 // 000000006cd0: bf9f0000
	s_code_end                                                 // 000000006cd4: bf9f0000
	s_code_end                                                 // 000000006cd8: bf9f0000
	s_code_end                                                 // 000000006cdc: bf9f0000
	s_code_end                                                 // 000000006ce0: bf9f0000
	s_code_end                                                 // 000000006ce4: bf9f0000
	s_code_end                                                 // 000000006ce8: bf9f0000
	s_code_end                                                 // 000000006cec: bf9f0000
	s_code_end                                                 // 000000006cf0: bf9f0000
	s_code_end                                                 // 000000006cf4: bf9f0000
	s_code_end                                                 // 000000006cf8: bf9f0000
	s_code_end                                                 // 000000006cfc: bf9f0000
