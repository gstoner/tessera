
/tmp/tmpavd2iict.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

disassembly of section .text:

0000000000001b00 <tessera_rocm_scaled_matmul_3f5949f02e72ba89>:
	s_clause 0x2                                               // 000000001b00: bf850002
	s_load_b64 s[34:35], s[0:1], 0xd8                          // 000000001b04: f4002880 f80000d8
	s_load_b128 s[20:23], s[0:1], 0xc8                         // 000000001b0c: f4004500 f80000c8
	s_load_b64 s[18:19], s[0:1], 0xa8                          // 000000001b14: f4002480 f80000a8
	s_mov_b32 s2, ttmp9                                        // 000000001b1c: be820075
	s_ashr_i32 s3, ttmp9, 31                                   // 000000001b20: 86039f75
	s_mov_b32 s4, ttmp7                                        // 000000001b24: be840073
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000001b28: 84828402
	s_delay_alu instid0(salu_cycle_1)                          // 000000001b2c: bf870009
	v_dual_mov_b32 v4, s3 :: v_dual_and_b32 v1, 15, v0         // 000000001b30: ca240003 0400008f
	s_ashr_i32 s5, ttmp7, 31                                   // 000000001b38: 86059f73
	s_clause 0x3                                               // 000000001b3c: bf850003
	s_load_b64 s[36:37], s[0:1], 0x8                           // 000000001b40: f4002900 f8000008
	s_load_b64 s[38:39], s[0:1], 0x30                          // 000000001b48: f4002980 f8000030
	s_load_b64 s[26:27], s[0:1], 0x58                          // 000000001b50: f4002680 f8000058
	s_load_b64 s[30:31], s[0:1], 0x80                          // 000000001b58: f4002780 f8000080
	s_lshl_b64 s[28:29], s[4:5], 4                             // 000000001b60: 849c8404
	s_add_nc_u64 s[4:5], s[2:3], 16                            // 000000001b64: a9849002
	v_or_b32_e32 v10, s28, v1                                  // 000000001b68: 3814021c
	s_add_nc_u64 s[0:1], s[28:29], 16                          // 000000001b6c: a980901c
	v_or_b32_e32 v3, s2, v1                                    // 000000001b70: 38060202
	v_bfe_u32 v22, v0, 4, 1                                    // 000000001b74: d6100016 02050900
	s_wait_kmcnt 0x0                                           // 000000001b7c: bfc70000
	v_mul_lo_u32 v2, s35, v10                                  // 000000001b80: d72c0002 02021423
	v_mad_co_u64_u32 v[5:6], null, s34, v10, 0                 // 000000001b88: d6fe7c05 02021422
	v_cmp_gt_i64_e64 s0, s[0:1], s[20:21]                      // 000000001b90: d4540000 02002800
	v_cmp_gt_i64_e64 s1, s[4:5], s[22:23]                      // 000000001b98: d4540001 02002c04
	s_mul_i32 s2, s34, s29                                     // 000000001ba0: 96021d22
	v_cmp_lt_i64_e64 s33, s[34:35], 16                         // 000000001ba4: d4510021 02012022
	s_and_b32 s24, s34, -16                                    // 000000001bac: 8b18d022
	s_mov_b32 s25, s35                                         // 000000001bb0: be990023
	s_wait_alu depctr_sa_sdst(0)                               // 000000001bb4: bf88ff9e
	v_add3_u32 v21, v6, s2, v2                                 // 000000001bb8: d6550015 04080506
	s_or_b32 s0, s0, s1                                        // 000000001bc0: 8c000100
	s_wait_alu depctr_sa_sdst(0)                               // 000000001bc4: bf88ff9e
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000001bc8: 8b6a007e
	s_cbranch_vccz 10                                          // 000000001bcc: bfa3000a <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0xf8>
	s_and_b32 s0, s33, exec_lo                                 // 000000001bd0: 8b007e21
	s_cselect_b32 s0, 1, 0                                     // 000000001bd4: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 000000001bd8: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000001bdc: bf078100
	s_cbranch_scc1 8                                           // 000000001be0: bfa20008 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x104>
	v_lshl_or_b32 v6, v22, 3, s28                              // 000000001be4: d6560006 00710716
	v_mov_b32_e32 v7, s29                                      // 000000001bec: 7e0e021d
	s_mov_b32 s0, 0                                            // 000000001bf0: be800080
	s_branch 4                                                 // 000000001bf4: bfa00004 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x108>
	s_mov_b32 s0, 0                                            // 000000001bf8: be800080
	s_cbranch_execnz 1104                                      // 000000001bfc: bfa60450 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x1240>
	s_branch 1751                                              // 000000001c00: bfa006d7 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x1c60>
	s_mov_b32 s0, -1                                           // 000000001c04: be8000c1
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v11, 0             // 000000001c08: ca100080 140a0080
	s_wait_alu depctr_sa_sdst(0)                               // 000000001c10: bf88ff9e
	s_and_b32 s0, s0, exec_lo                                  // 000000001c14: 8b007e00
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v13, 0              // 000000001c18: ca100080 020c0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v17, 0             // 000000001c20: ca100080 0c100080
	v_mov_b32_e32 v23, 0                                       // 000000001c28: 7e2e0280
	v_mov_b32_e32 v1, 0                                        // 000000001c2c: 7e020280
	s_cselect_b32 s0, 1, 0                                     // 000000001c30: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 000000001c34: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000001c38: bf078100
	s_cbranch_scc1 759                                         // 000000001c3c: bfa202f7 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0xd1c>
	v_dual_mov_b32 v11, s29 :: v_dual_lshlrev_b32 v0, 3, v22   // 000000001c40: ca22001d 0b002c83
	s_lshr_b64 s[4:5], s[34:35], 4                             // 000000001c48: 85848422
	s_lshr_b32 s3, s35, 4                                      // 000000001c4c: 85038423
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v18, s29            // 000000001c50: ca100080 0112001d
	s_delay_alu instid0(valu_dep_2)                            // 000000001c58: bf870002
	v_or_b32_e32 v6, s28, v0                                   // 000000001c5c: 380c001c
	v_mov_b32_e32 v7, s29                                      // 000000001c60: 7e0e021d
	v_mul_lo_u32 v2, s34, v4                                   // 000000001c64: d72c0002 02020822
	v_mul_lo_u32 v13, s35, v3                                  // 000000001c6c: d72c000d 02020623
	v_mad_co_u64_u32 v[8:9], null, s34, v3, v[0:1]             // 000000001c74: d6fe7c08 04020622
	v_or_b32_e32 v16, 1, v6                                    // 000000001c7c: 38200c81
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[6:7]                  // 000000001c80: 7ca80c14
	v_mov_b32_e32 v17, s29                                     // 000000001c84: 7e22021d
	v_cmp_gt_i64_e64 s0, s[22:23], v[3:4]                      // 000000001c88: d4540000 02020616
	v_cmp_gt_i64_e64 s1, s[20:21], v[10:11]                    // 000000001c90: d4540001 02021414
	v_or_b32_e32 v30, 5, v6                                    // 000000001c98: 383c0c85
	v_dual_mov_b32 v31, s29 :: v_dual_cndmask_b32 v14, 0, v6   // 000000001c9c: ca12001d 1f0e0c80
	v_cndmask_b32_e64 v15, 0, s29, vcc_lo                      // 000000001ca4: d501000f 01a83a80
	v_add3_u32 v9, v13, v9, v2                                 // 000000001cac: d6550009 040a130d
	s_wait_alu depctr_va_sdst(0)                               // 000000001cb4: bf88f19f
	v_cndmask_b32_e64 v12, 0, v4, s0                           // 000000001cb8: d501000c 00020880
	v_cndmask_b32_e64 v11, 0, v3, s0                           // 000000001cc0: d501000b 00020680
	s_wait_alu depctr_sa_sdst(0)                               // 000000001cc8: bf88ff9e
	v_mul_lo_u32 v23, s3, v14                                  // 000000001ccc: d72c0017 02021c03
	v_mad_co_u64_u32 v[19:20], null, s4, v14, 0                // 000000001cd4: d6fe7c13 02021c04
	v_mul_lo_u32 v24, s4, v15                                  // 000000001cdc: d72c0018 02021e04
	v_add_co_u32 v14, vcc_lo, v5, v0                           // 000000001ce4: d7006a0e 02020105
	s_wait_alu depctr_va_vcc(0)                                // 000000001cec: bf88ff9d
	v_add_co_ci_u32_e64 v15, null, 0, v21, vcc_lo              // 000000001cf0: d5207c0f 01aa2a80
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[16:17]                // 000000001cf8: 7ca82014
	v_or_b32_e32 v17, 2, v6                                    // 000000001cfc: 38220c82
	v_lshlrev_b64_e32 v[11:12], 2, v[11:12]                    // 000000001d00: 3e161682
	v_add3_u32 v20, v20, v24, v23                              // 000000001d04: d6550014 045e3114
	v_or_b32_e32 v34, 6, v6                                    // 000000001d0c: 38440c86
	s_wait_alu depctr_va_vcc(0)                                // 000000001d10: bf88ff9d
	v_dual_mov_b32 v35, s29 :: v_dual_cndmask_b32 v10, 0, v16  // 000000001d14: ca12001d 230a2080
	v_cndmask_b32_e64 v2, 0, s29, vcc_lo                       // 000000001d1c: d5010002 01a83a80
	v_lshlrev_b64_e32 v[19:20], 2, v[19:20]                    // 000000001d24: 3e262682
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[17:18]                // 000000001d28: 7ca82214
	s_mov_b64 s[40:41], 0                                      // 000000001d2c: bea80180
	v_mul_lo_u32 v13, s3, v10                                  // 000000001d30: d72c000d 02021403
	v_mad_co_u64_u32 v[23:24], null, s4, v10, 0                // 000000001d38: d6fe7c17 02021404
	v_mul_lo_u32 v2, s4, v2                                    // 000000001d40: d72c0002 02020404
	v_add_co_u32 v10, s2, s26, v19                             // 000000001d48: d700020a 0202261a
	s_wait_alu depctr_va_vcc(0)                                // 000000001d50: bf88ff9d
	v_cndmask_b32_e32 v19, 0, v17, vcc_lo                      // 000000001d54: 02262280
	v_or_b32_e32 v17, 3, v6                                    // 000000001d58: 38220c83
	s_wait_alu depctr_va_sdst(0)                               // 000000001d5c: bf88f19f
	v_add_co_ci_u32_e64 v16, null, s27, v20, s2                // 000000001d60: d5207c10 000a281b
	v_cndmask_b32_e64 v20, 0, s29, vcc_lo                      // 000000001d68: d5010014 01a83a80
	v_add3_u32 v24, v24, v2, v13                               // 000000001d70: d6550018 04360518
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[17:18]                // 000000001d78: 7ca82214
	v_mul_lo_u32 v2, s3, v19                                   // 000000001d7c: d72c0002 02022603
	v_mad_co_u64_u32 v[26:27], null, s4, v19, 0                // 000000001d84: d6fe7c1a 02022604
	v_mul_lo_u32 v13, s4, v20                                  // 000000001d8c: d72c000d 02022804
	v_add_co_u32 v18, s2, s30, v11                             // 000000001d94: d7000212 0202161e
	s_wait_alu depctr_va_vcc(0)                                // 000000001d9c: bf88ff9d
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000001da0: 02222280
	v_cndmask_b32_e64 v20, 0, s29, vcc_lo                      // 000000001da4: d5010014 01a83a80
	s_wait_alu depctr_va_sdst(0)                               // 000000001dac: bf88f19f
	v_add_co_ci_u32_e64 v19, null, s31, v12, s2                // 000000001db0: d5207c13 000a181f
	v_lshlrev_b64_e32 v[11:12], 2, v[23:24]                    // 000000001db8: 3e162e82
	v_or_b32_e32 v23, 4, v6                                    // 000000001dbc: 382e0c84
	v_mov_b32_e32 v24, s29                                     // 000000001dc0: 7e30021d
	v_add3_u32 v27, v27, v13, v2                               // 000000001dc4: d655001b 040a1b1b
	v_mul_lo_u32 v2, s3, v17                                   // 000000001dcc: d72c0002 02022203
	v_mul_lo_u32 v13, s4, v20                                  // 000000001dd4: d72c000d 02022804
	v_mad_co_u64_u32 v[28:29], null, s4, v17, 0                // 000000001ddc: d6fe7c1c 02022204
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[23:24]                // 000000001de4: 7ca82e14
	v_add_co_u32 v24, s2, s26, v11                             // 000000001de8: d7000218 0202161a
	s_wait_alu depctr_va_sdst(0)                               // 000000001df0: bf88f19f
	v_add_co_ci_u32_e64 v25, null, s27, v12, s2                // 000000001df4: d5207c19 000a181b
	v_lshlrev_b64_e32 v[11:12], 2, v[26:27]                    // 000000001dfc: 3e163482
	s_wait_alu depctr_va_vcc(0)                                // 000000001e00: bf88ff9d
	v_cndmask_b32_e64 v20, 0, s29, vcc_lo                      // 000000001e04: d5010014 01a83a80
	v_add3_u32 v29, v29, v13, v2                               // 000000001e0c: d655001d 040a1b1d
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_3)// 000000001e14: bf8701b3
	v_add_co_u32 v26, s2, s26, v11                             // 000000001e18: d700021a 0202161a
	s_wait_alu depctr_va_sdst(0)                               // 000000001e20: bf88f19f
	v_add_co_ci_u32_e64 v27, null, s27, v12, s2                // 000000001e24: d5207c1b 000a181b
	v_lshlrev_b64_e32 v[11:12], 2, v[28:29]                    // 000000001e2c: 3e163882
	v_or_b32_e32 v28, 7, v6                                    // 000000001e30: 38380c87
	v_cndmask_b32_e32 v17, 0, v23, vcc_lo                      // 000000001e34: 02222e80
	v_mul_lo_u32 v13, s4, v20                                  // 000000001e38: d72c000d 02022804
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[30:31]                // 000000001e40: 7ca83c14
	v_cmp_gt_i64_e64 s2, s[20:21], v[34:35]                    // 000000001e44: d4540002 02024414
	v_mov_b32_e32 v29, s29                                     // 000000001e4c: 7e3a021d
	v_mul_lo_u32 v2, s3, v17                                   // 000000001e50: d72c0002 02022203
	v_mad_co_u64_u32 v[32:33], null, s4, v17, 0                // 000000001e58: d6fe7c20 02022204
	s_wait_alu depctr_va_sdst(0)                               // 000000001e60: bf88f19f
	s_delay_alu instid0(valu_dep_4) | instskip(skip_1) | instid1(valu_dep_3)// 000000001e64: bf8701a4
	v_cndmask_b32_e64 v20, 0, v34, s2                          // 000000001e68: d5010014 000a4480
	v_cndmask_b32_e64 v23, 0, s29, s2                          // 000000001e70: d5010017 00083a80
	v_add3_u32 v33, v33, v13, v2                               // 000000001e78: d6550021 040a1b21
	s_wait_alu depctr_va_vcc(0)                                // 000000001e80: bf88ff9d
	v_cndmask_b32_e32 v2, 0, v30, vcc_lo                       // 000000001e84: 02043c80
	v_cndmask_b32_e64 v13, 0, s29, vcc_lo                      // 000000001e88: d501000d 01a83a80
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[28:29]                // 000000001e90: 7ca83814
	v_mad_co_u64_u32 v[34:35], null, s4, v20, 0                // 000000001e94: d6fe7c22 02022804
	v_mul_lo_u32 v23, s4, v23                                  // 000000001e9c: d72c0017 02022e04
	v_mul_lo_u32 v17, s3, v2                                   // 000000001ea4: d72c0011 02020403
	v_mul_lo_u32 v13, s4, v13                                  // 000000001eac: d72c000d 02021a04
	v_mad_co_u64_u32 v[30:31], null, s4, v2, 0                 // 000000001eb4: d6fe7c1e 02020404
	v_mul_lo_u32 v2, s3, v20                                   // 000000001ebc: d72c0002 02022803
	s_wait_alu depctr_va_vcc(0)                                // 000000001ec4: bf88ff9d
	v_cndmask_b32_e32 v20, 0, v28, vcc_lo                      // 000000001ec8: 02283880
	v_cndmask_b32_e64 v36, 0, s29, vcc_lo                      // 000000001ecc: d5010024 01a83a80
	v_add_co_u32 v28, vcc_lo, s26, v11                         // 000000001ed4: d7006a1c 0202161a
	s_wait_alu depctr_va_vcc(0)                                // 000000001edc: bf88ff9d
	v_add_co_ci_u32_e64 v29, null, s27, v12, vcc_lo            // 000000001ee0: d5207c1d 01aa181b
	v_add3_u32 v31, v31, v13, v17                              // 000000001ee8: d655001f 04461b1f
	v_mul_lo_u32 v13, s3, v20                                  // 000000001ef0: d72c000d 02022803
	v_mul_lo_u32 v17, s4, v36                                  // 000000001ef8: d72c0011 02024804
	v_mad_co_u64_u32 v[36:37], null, s4, v20, 0                // 000000001f00: d6fe7c24 02022804
	v_lshlrev_b64_e32 v[11:12], 2, v[32:33]                    // 000000001f08: 3e164082
	v_add3_u32 v35, v35, v23, v2                               // 000000001f0c: d6550023 040a2f23
	v_lshlrev_b64_e32 v[32:33], 2, v[30:31]                    // 000000001f14: 3e403c82
	v_dual_mov_b32 v23, v1 :: v_dual_mov_b32 v2, v1            // 000000001f18: ca100101 17020101
	v_mov_b32_e32 v20, v1                                      // 000000001f20: 7e280301
	v_add_co_u32 v30, vcc_lo, s26, v11                         // 000000001f24: d7006a1e 0202161a
	v_add3_u32 v37, v37, v17, v13                              // 000000001f2c: d6550025 04362325
	s_wait_alu depctr_va_vcc(0)                                // 000000001f34: bf88ff9d
	v_add_co_ci_u32_e64 v31, null, s27, v12, vcc_lo            // 000000001f38: d5207c1f 01aa181b
	v_lshlrev_b64_e32 v[11:12], 2, v[34:35]                    // 000000001f40: 3e164482
	v_add_co_u32 v32, vcc_lo, s26, v32                         // 000000001f44: d7006a20 0202401a
	v_lshlrev_b64_e32 v[36:37], 2, v[36:37]                    // 000000001f4c: 3e484882
	s_wait_alu depctr_va_vcc(0)                                // 000000001f50: bf88ff9d
	v_add_co_ci_u32_e64 v33, null, s27, v33, vcc_lo            // 000000001f54: d5207c21 01aa421b
	s_delay_alu instid0(valu_dep_4)                            // 000000001f5c: bf870004
	v_add_co_u32 v34, vcc_lo, s26, v11                         // 000000001f60: d7006a22 0202161a
	s_wait_alu depctr_va_vcc(0)                                // 000000001f68: bf88ff9d
	v_add_co_ci_u32_e64 v35, null, s27, v12, vcc_lo            // 000000001f6c: d5207c23 01aa181b
	v_add_co_u32 v36, vcc_lo, s26, v36                         // 000000001f74: d7006a24 0202481a
	s_wait_alu depctr_va_vcc(0)                                // 000000001f7c: bf88ff9d
	v_add_co_ci_u32_e64 v37, null, s27, v37, vcc_lo            // 000000001f80: d5207c25 01aa4a1b
	v_mov_b32_e32 v17, v1                                      // 000000001f88: 7e220301
	v_dual_mov_b32 v13, v1 :: v_dual_mov_b32 v12, v1           // 000000001f8c: ca100101 0d0c0101
	v_mov_b32_e32 v11, v1                                      // 000000001f94: 7e160301
	v_or_b32_e32 v38, s40, v0                                  // 000000001f98: 384c0028
	v_add_co_u32 v52, vcc_lo, v14, s40                         // 000000001f9c: d7006a34 0200510e
	v_mov_b32_e32 v39, s41                                     // 000000001fa4: 7e4e0229
	v_mov_b32_e32 v41, s41                                     // 000000001fa8: 7e520229
	s_delay_alu instid0(valu_dep_4)                            // 000000001fac: bf870004
	v_or_b32_e32 v40, 1, v38                                   // 000000001fb0: 38504c81
	s_wait_alu depctr_va_vcc(0)                                // 000000001fb4: bf88ff9d
	v_add_co_ci_u32_e64 v53, null, s41, v15, vcc_lo            // 000000001fb8: d5207c35 01aa1e29
	v_cmp_gt_i64_e64 s9, s[34:35], v[38:39]                    // 000000001fc0: d4540009 02024c22
	v_add_co_u32 v42, s2, v52, 1                               // 000000001fc8: d700022a 02010334
	v_cmp_gt_i64_e64 s10, s[34:35], v[40:41]                   // 000000001fd0: d454000a 02025022
	s_wait_alu depctr_va_sdst(0)                               // 000000001fd8: bf88f19f
	v_add_co_ci_u32_e64 v43, null, 0, v53, s2                  // 000000001fdc: d5207c2b 000a6a80
	s_and_b32 vcc_lo, s1, s9                                   // 000000001fe4: 8b6a0901
	v_add_co_u32 v46, s3, v52, 2                               // 000000001fe8: d700032e 02010534
	s_wait_alu depctr_sa_sdst(0)                               // 000000001ff0: bf88ff9e
	v_dual_cndmask_b32 v40, 0, v52 :: v_dual_cndmask_b32 v41, 0, v53// 000000001ff4: ca526880 28286a80
	s_wait_alu depctr_va_sdst(0)                               // 000000001ffc: bf88f19f
	v_add_co_ci_u32_e64 v47, null, 0, v53, s3                  // 000000002000: d5207c2f 000e6a80
	v_add_co_u32 v48, s4, v52, 3                               // 000000002008: d7000430 02010734
	s_delay_alu instid0(valu_dep_3)                            // 000000002010: bf870003
	v_add_co_u32 v40, s2, s36, v40                             // 000000002014: d7000228 02025024
	s_wait_alu depctr_va_sdst(0)                               // 00000000201c: bf88f19f
	v_add_co_ci_u32_e64 v41, null, s37, v41, s2                // 000000002020: d5207c29 000a5225
	s_and_b32 s2, s1, s10                                      // 000000002028: 8b020a01
	v_add_co_ci_u32_e64 v49, null, 0, v53, s4                  // 00000000202c: d5207c31 00126a80
	s_wait_alu depctr_sa_sdst(0)                               // 000000002034: bf88ff9e
	v_cndmask_b32_e64 v45, 0, v43, s2                          // 000000002038: d501002d 000a5680
	v_cndmask_b32_e64 v44, 0, v42, s2                          // 000000002040: d501002c 000a5480
	v_or_b32_e32 v42, 2, v38                                   // 000000002048: 38544c82
	v_mov_b32_e32 v43, s41                                     // 00000000204c: 7e560229
	v_add_co_u32 v50, s5, v52, 4                               // 000000002050: d7000532 02010934
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 000000002058: bf870194
	v_add_co_u32 v44, s3, s36, v44                             // 00000000205c: d700032c 02025824
	v_cmp_gt_i64_e64 s11, s[34:35], v[42:43]                   // 000000002064: d454000b 02025422
	v_or_b32_e32 v42, 3, v38                                   // 00000000206c: 38544c83
	s_wait_alu depctr_va_sdst(0)                               // 000000002070: bf88f19f
	v_add_co_ci_u32_e64 v45, null, s37, v45, s3                // 000000002074: d5207c2d 000e5a25
	v_add_co_ci_u32_e64 v51, null, 0, v53, s5                  // 00000000207c: d5207c33 00166a80
	s_and_b32 s3, s1, s11                                      // 000000002084: 8b030b01
	v_cmp_gt_i64_e64 s12, s[34:35], v[42:43]                   // 000000002088: d454000c 02025422
	s_wait_alu depctr_sa_sdst(0)                               // 000000002090: bf88ff9e
	v_cndmask_b32_e64 v46, 0, v46, s3                          // 000000002094: d501002e 000e5c80
	v_cndmask_b32_e64 v47, 0, v47, s3                          // 00000000209c: d501002f 000e5e80
	v_add_co_u32 v54, s6, v52, 5                               // 0000000020a4: d7000636 02010b34
	s_wait_alu depctr_va_sdst(0)                               // 0000000020ac: bf88f19f
	v_add_co_ci_u32_e64 v55, null, 0, v53, s6                  // 0000000020b0: d5207c37 001a6a80
	v_add_co_u32 v42, s4, s36, v46                             // 0000000020b8: d700042a 02025c24
	s_wait_alu depctr_va_sdst(0)                               // 0000000020c0: bf88f19f
	v_add_co_ci_u32_e64 v43, null, s37, v47, s4                // 0000000020c4: d5207c2b 00125e25
	v_or_b32_e32 v46, 4, v38                                   // 0000000020cc: 385c4c84
	v_mov_b32_e32 v47, s41                                     // 0000000020d0: 7e5e0229
	s_and_b32 s4, s1, s12                                      // 0000000020d4: 8b040c01
	v_add_co_u32 v56, s7, v52, 6                               // 0000000020d8: d7000738 02010d34
	s_wait_alu depctr_sa_sdst(0)                               // 0000000020e0: bf88ff9e
	v_cndmask_b32_e64 v48, 0, v48, s4                          // 0000000020e4: d5010030 00126080
	v_cmp_gt_i64_e64 s13, s[34:35], v[46:47]                   // 0000000020ec: d454000d 02025c22
	v_cndmask_b32_e64 v49, 0, v49, s4                          // 0000000020f4: d5010031 00126280
	v_or_b32_e32 v46, 5, v38                                   // 0000000020fc: 385c4c85
	s_wait_alu depctr_va_sdst(0)                               // 000000002100: bf88f19f
	v_add_co_ci_u32_e64 v57, null, 0, v53, s7                  // 000000002104: d5207c39 001e6a80
	v_add_co_u32 v48, s5, s36, v48                             // 00000000210c: d7000530 02026024
	s_wait_alu depctr_va_sdst(0)                               // 000000002114: bf88f19f
	v_add_co_ci_u32_e64 v49, null, s37, v49, s5                // 000000002118: d5207c31 00166225
	s_and_b32 s5, s1, s13                                      // 000000002120: 8b050d01
	v_cmp_gt_i64_e64 s14, s[34:35], v[46:47]                   // 000000002124: d454000e 02025c22
	s_wait_alu depctr_sa_sdst(0)                               // 00000000212c: bf88ff9e
	v_cndmask_b32_e64 v50, 0, v50, s5                          // 000000002130: d5010032 00166480
	v_cndmask_b32_e64 v51, 0, v51, s5                          // 000000002138: d5010033 00166680
	v_add_co_u32 v58, s17, v8, s40                             // 000000002140: d700113a 02005108
	s_wait_alu depctr_va_sdst(0)                               // 000000002148: bf88f19f
	v_add_co_ci_u32_e64 v59, null, s41, v9, s17                // 00000000214c: d5207c3b 00461229
	v_add_co_u32 v46, s6, s36, v50                             // 000000002154: d700062e 02026424
	s_wait_alu depctr_va_sdst(0)                               // 00000000215c: bf88f19f
	v_add_co_ci_u32_e64 v47, null, s37, v51, s6                // 000000002160: d5207c2f 001a6625
	v_or_b32_e32 v50, 6, v38                                   // 000000002168: 38644c86
	v_mov_b32_e32 v51, s41                                     // 00000000216c: 7e660229
	s_and_b32 s6, s1, s14                                      // 000000002170: 8b060e01
	v_or_b32_e32 v38, 7, v38                                   // 000000002174: 384c4c87
	s_wait_alu depctr_sa_sdst(0)                               // 000000002178: bf88ff9e
	v_cndmask_b32_e64 v54, 0, v54, s6                          // 00000000217c: d5010036 001a6c80
	v_cndmask_b32_e64 v55, 0, v55, s6                          // 000000002184: d5010037 001a6e80
	v_cmp_gt_i64_e64 s15, s[34:35], v[50:51]                   // 00000000218c: d454000f 02026422
	s_and_b32 s9, s0, s9                                       // 000000002194: 8b090900
	v_cmp_gt_i64_e64 s16, s[34:35], v[38:39]                   // 000000002198: d4540010 02024c22
	v_add_co_u32 v50, s7, s36, v54                             // 0000000021a0: d7000732 02026c24
	s_wait_alu depctr_va_sdst(0)                               // 0000000021a8: bf88f19f
	v_add_co_ci_u32_e64 v51, null, s37, v55, s7                // 0000000021ac: d5207c33 001e6e25
	s_and_b32 s7, s1, s15                                      // 0000000021b4: 8b070f01
	v_add_co_u32 v38, s8, v52, 7                               // 0000000021b8: d7000826 02010f34
	s_wait_alu depctr_sa_sdst(0)                               // 0000000021c0: bf88ff9e
	v_cndmask_b32_e64 v55, 0, v56, s7                          // 0000000021c4: d5010037 001e7080
	v_cndmask_b32_e64 v54, 0, v57, s7                          // 0000000021cc: d5010036 001e7280
	s_wait_alu depctr_va_sdst(0)                               // 0000000021d4: bf88f19f
	v_add_co_ci_u32_e64 v39, null, 0, v53, s8                  // 0000000021d8: d5207c27 00226a80
	s_and_b32 s10, s0, s10                                     // 0000000021e0: 8b0a0a00
	v_add_co_u32 v52, s8, s36, v55                             // 0000000021e4: d7000834 02026e24
	s_wait_alu depctr_va_sdst(0)                               // 0000000021ec: bf88f19f
	v_add_co_ci_u32_e64 v53, null, s37, v54, s8                // 0000000021f0: d5207c35 00226c25
	s_and_b32 s8, s1, s16                                      // 0000000021f8: 8b081001
	s_and_b32 s11, s0, s11                                     // 0000000021fc: 8b0b0b00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002200: bf88ff9e
	v_cndmask_b32_e64 v38, 0, v38, s8                          // 000000002204: d5010026 00224c80
	v_cndmask_b32_e64 v39, 0, v39, s8                          // 00000000220c: d5010027 00224e80
	s_and_b32 s12, s0, s12                                     // 000000002214: 8b0c0c00
	s_and_b32 s13, s0, s13                                     // 000000002218: 8b0d0d00
	s_and_b32 s14, s0, s14                                     // 00000000221c: 8b0e0e00
	v_add_co_u32 v54, s17, s36, v38                            // 000000002220: d7001136 02024c24
	s_wait_alu depctr_va_sdst(0)                               // 000000002228: bf88f19f
	v_add_co_ci_u32_e64 v55, null, s37, v39, s17               // 00000000222c: d5207c37 00464e25
	v_add_co_u32 v60, s17, v58, 1                              // 000000002234: d700113c 0201033a
	s_wait_alu depctr_va_sdst(0)                               // 00000000223c: bf88f19f
	v_add_co_ci_u32_e64 v61, null, 0, v59, s17                 // 000000002240: d5207c3d 00467680
	v_cndmask_b32_e64 v39, 0, v58, s9                          // 000000002248: d5010027 00267480
	v_cndmask_b32_e64 v38, 0, v59, s9                          // 000000002250: d5010026 00267680
	v_cndmask_b32_e64 v60, 0, v60, s10                         // 000000002258: d501003c 002a7880
	s_delay_alu instid0(valu_dep_4)                            // 000000002260: bf870004
	v_cndmask_b32_e64 v61, 0, v61, s10                         // 000000002264: d501003d 002a7a80
	s_lshr_b64 s[42:43], s[40:41], 4                           // 00000000226c: 85aa8428
	v_add_co_u32 v56, s17, s38, v39                            // 000000002270: d7001138 02024e26
	s_wait_alu depctr_va_sdst(0)                               // 000000002278: bf88f19f
	v_add_co_ci_u32_e64 v57, null, s39, v38, s17               // 00000000227c: d5207c39 00464c27
	s_clause 0x7                                               // 000000002284: bf850007
	global_load_d16_u8 v38, v[40:41], off                      // 000000002288: ee07807c 00000026 00000028
	global_load_d16_hi_u8 v38, v[44:45], off                   // 000000002294: ee08407c 00000026 0000002c
	global_load_d16_u8 v39, v[42:43], off                      // 0000000022a0: ee07807c 00000027 0000002a
	global_load_d16_hi_u8 v39, v[48:49], off                   // 0000000022ac: ee08407c 00000027 00000030
	global_load_d16_u8 v40, v[46:47], off                      // 0000000022b8: ee07807c 00000028 0000002e
	global_load_d16_hi_u8 v40, v[50:51], off                   // 0000000022c4: ee08407c 00000028 00000032
	global_load_d16_u8 v41, v[52:53], off                      // 0000000022d0: ee07807c 00000029 00000034
	global_load_d16_hi_u8 v41, v[54:55], off                   // 0000000022dc: ee08407c 00000029 00000036
	global_load_d16_u8 v42, v[56:57], off                      // 0000000022e8: ee07807c 0000002a 00000038
	v_add_co_u32 v43, s17, s38, v60                            // 0000000022f4: d700112b 02027826
	s_wait_alu depctr_va_sdst(0)                               // 0000000022fc: bf88f19f
	v_add_co_ci_u32_e64 v44, null, s39, v61, s17               // 000000002300: d5207c2c 00467a27
	v_add_co_u32 v45, s17, v58, 2                              // 000000002308: d700112d 0201053a
	s_wait_alu depctr_va_sdst(0)                               // 000000002310: bf88f19f
	v_add_co_ci_u32_e64 v46, null, 0, v59, s17                 // 000000002314: d5207c2e 00467680
	v_add_co_u32 v47, s17, v58, 3                              // 00000000231c: d700112f 0201073a
	s_wait_alu depctr_va_sdst(0)                               // 000000002324: bf88f19f
	v_add_co_ci_u32_e64 v48, null, 0, v59, s17                 // 000000002328: d5207c30 00467680
	v_cndmask_b32_e64 v45, 0, v45, s11                         // 000000002330: d501002d 002e5a80
	v_cndmask_b32_e64 v46, 0, v46, s11                         // 000000002338: d501002e 002e5c80
	s_wait_alu depctr_sa_sdst(0)                               // 000000002340: bf88ff9e
	v_cndmask_b32_e64 v47, 0, v47, s12                         // 000000002344: d501002f 00325e80
	v_cndmask_b32_e64 v48, 0, v48, s12                         // 00000000234c: d5010030 00326080
	s_and_b32 s15, s0, s15                                     // 000000002354: 8b0f0f00
	v_add_co_u32 v45, s17, s38, v45                            // 000000002358: d700112d 02025a26
	s_wait_alu depctr_va_sdst(0)                               // 000000002360: bf88f19f
	v_add_co_ci_u32_e64 v46, null, s39, v46, s17               // 000000002364: d5207c2e 00465c27
	v_add_co_u32 v47, s17, s38, v47                            // 00000000236c: d700112f 02025e26
	s_wait_alu depctr_va_sdst(0)                               // 000000002374: bf88f19f
	v_add_co_ci_u32_e64 v48, null, s39, v48, s17               // 000000002378: d5207c30 00466027
	v_add_co_u32 v49, s17, v58, 4                              // 000000002380: d7001131 0201093a
	s_wait_alu depctr_va_sdst(0)                               // 000000002388: bf88f19f
	v_add_co_ci_u32_e64 v50, null, 0, v59, s17                 // 00000000238c: d5207c32 00467680
	v_add_co_u32 v51, s17, v58, 5                              // 000000002394: d7001133 02010b3a
	s_wait_alu depctr_va_sdst(0)                               // 00000000239c: bf88f19f
	v_add_co_ci_u32_e64 v52, null, 0, v59, s17                 // 0000000023a0: d5207c34 00467680
	v_cndmask_b32_e64 v49, 0, v49, s13                         // 0000000023a8: d5010031 00366280
	v_cndmask_b32_e64 v50, 0, v50, s13                         // 0000000023b0: d5010032 00366480
	v_cndmask_b32_e64 v51, 0, v51, s14                         // 0000000023b8: d5010033 003a6680
	s_delay_alu instid0(valu_dep_4)                            // 0000000023c0: bf870004
	v_cndmask_b32_e64 v52, 0, v52, s14                         // 0000000023c4: d5010034 003a6880
	s_mul_u64 s[42:43], s[42:43], s[22:23]                     // 0000000023cc: aaaa162a
	v_add_co_u32 v49, s17, s38, v49                            // 0000000023d0: d7001131 02026226
	s_wait_alu depctr_va_sdst(0)                               // 0000000023d8: bf88f19f
	v_add_co_ci_u32_e64 v50, null, s39, v50, s17               // 0000000023dc: d5207c32 00466427
	v_add_co_u32 v51, s17, s38, v51                            // 0000000023e4: d7001133 02026626
	s_wait_alu depctr_va_sdst(0)                               // 0000000023ec: bf88f19f
	v_add_co_ci_u32_e64 v52, null, s39, v52, s17               // 0000000023f0: d5207c34 00466827
	v_add_co_u32 v53, s17, v58, 6                              // 0000000023f8: d7001135 02010d3a
	s_wait_alu depctr_va_sdst(0)                               // 000000002400: bf88f19f
	v_add_co_ci_u32_e64 v54, null, 0, v59, s17                 // 000000002404: d5207c36 00467680
	v_add_co_u32 v55, s17, v58, 7                              // 00000000240c: d7001137 02010f3a
	s_lshr_b64 s[44:45], s[40:41], 2                           // 000000002414: 85ac8228
	v_add_co_ci_u32_e64 v56, null, 0, v59, s17                 // 000000002418: d5207c38 00467680
	s_wait_alu depctr_sa_sdst(0)                               // 000000002420: bf88ff9e
	v_cndmask_b32_e64 v57, 0, v53, s15                         // 000000002424: d5010039 003e6a80
	s_and_b32 s16, s0, s16                                     // 00000000242c: 8b101000
	v_add_co_u32 v53, s17, v10, s44                            // 000000002430: d7001135 0200590a
	s_lshl_b64 s[42:43], s[42:43], 2                           // 000000002438: 84aa822a
	v_cndmask_b32_e64 v58, 0, v54, s15                         // 00000000243c: d501003a 003e6c80
	s_wait_alu depctr_sa_sdst(0)                               // 000000002444: bf88ff9e
	v_cndmask_b32_e64 v60, 0, v55, s16                         // 000000002448: d501003c 00426e80
	v_add_co_ci_u32_e64 v54, null, s45, v16, s17               // 000000002450: d5207c36 0046202d
	v_add_co_u32 v55, s17, v18, s42                            // 000000002458: d7001137 02005512
	v_cndmask_b32_e64 v59, 0, v56, s16                         // 000000002460: d501003b 00427080
	s_wait_alu depctr_va_sdst(0)                               // 000000002468: bf88f19f
	v_add_co_ci_u32_e64 v56, null, s43, v19, s17               // 00000000246c: d5207c38 0046262b
	v_add_co_u32 v57, s17, s38, v57                            // 000000002474: d7001139 02027226
	s_wait_alu depctr_va_sdst(0)                               // 00000000247c: bf88f19f
	v_add_co_ci_u32_e64 v58, null, s39, v58, s17               // 000000002480: d5207c3a 00467427
	global_load_b32 v61, v[53:54], off                         // 000000002488: ee05007c 0000003d 00000035
	global_load_b32 v55, v[55:56], off                         // 000000002494: ee05007c 00000037 00000037
	v_add_co_u32 v53, s17, s38, v60                            // 0000000024a0: d7001135 02027826
	s_wait_alu depctr_va_sdst(0)                               // 0000000024a8: bf88f19f
	v_add_co_ci_u32_e64 v54, null, s39, v59, s17               // 0000000024ac: d5207c36 00467627
	s_clause 0x6                                               // 0000000024b4: bf850006
	global_load_d16_hi_u8 v42, v[43:44], off                   // 0000000024b8: ee08407c 0000002a 0000002b
	global_load_d16_u8 v43, v[45:46], off                      // 0000000024c4: ee07807c 0000002b 0000002d
	global_load_d16_hi_u8 v43, v[47:48], off                   // 0000000024d0: ee08407c 0000002b 0000002f
	global_load_d16_u8 v44, v[49:50], off                      // 0000000024dc: ee07807c 0000002c 00000031
	global_load_d16_hi_u8 v44, v[51:52], off                   // 0000000024e8: ee08407c 0000002c 00000033
	global_load_d16_u8 v45, v[57:58], off                      // 0000000024f4: ee07807c 0000002d 00000039
	global_load_d16_hi_u8 v45, v[53:54], off                   // 000000002500: ee08407c 0000002d 00000035
	v_add_co_u32 v46, s17, v24, s44                            // 00000000250c: d700112e 02005918
	s_wait_alu depctr_va_sdst(0)                               // 000000002514: bf88f19f
	v_add_co_ci_u32_e64 v47, null, s45, v25, s17               // 000000002518: d5207c2f 0046322d
	v_add_co_u32 v48, s17, v26, s44                            // 000000002520: d7001130 0200591a
	s_wait_alu depctr_va_sdst(0)                               // 000000002528: bf88f19f
	v_add_co_ci_u32_e64 v49, null, s45, v27, s17               // 00000000252c: d5207c31 0046362d
	v_add_co_u32 v50, s17, v28, s44                            // 000000002534: d7001132 0200591c
	s_wait_alu depctr_va_sdst(0)                               // 00000000253c: bf88f19f
	v_add_co_ci_u32_e64 v51, null, s45, v29, s17               // 000000002540: d5207c33 00463a2d
	s_clause 0x2                                               // 000000002548: bf850002
	global_load_b32 v54, v[46:47], off                         // 00000000254c: ee05007c 00000036 0000002e
	global_load_b32 v56, v[48:49], off                         // 000000002558: ee05007c 00000038 00000030
	global_load_b32 v57, v[50:51], off                         // 000000002564: ee05007c 00000039 00000032
	v_add_co_u32 v46, s17, v30, s44                            // 000000002570: d700112e 0200591e
	s_wait_alu depctr_va_sdst(0)                               // 000000002578: bf88f19f
	v_add_co_ci_u32_e64 v47, null, s45, v31, s17               // 00000000257c: d5207c2f 00463e2d
	v_add_co_u32 v48, s17, v32, s44                            // 000000002584: d7001130 02005920
	s_wait_alu depctr_va_sdst(0)                               // 00000000258c: bf88f19f
	v_add_co_ci_u32_e64 v49, null, s45, v33, s17               // 000000002590: d5207c31 0046422d
	v_add_co_u32 v50, s17, v34, s44                            // 000000002598: d7001132 02005922
	s_wait_alu depctr_va_sdst(0)                               // 0000000025a0: bf88f19f
	v_add_co_ci_u32_e64 v51, null, s45, v35, s17               // 0000000025a4: d5207c33 0046462d
	v_add_co_u32 v52, s17, v36, s44                            // 0000000025ac: d7001134 02005924
	s_wait_alu depctr_va_sdst(0)                               // 0000000025b4: bf88f19f
	v_add_co_ci_u32_e64 v53, null, s45, v37, s17               // 0000000025b8: d5207c35 00464a2d
	s_clause 0x3                                               // 0000000025c0: bf850003
	global_load_b32 v58, v[46:47], off                         // 0000000025c4: ee05007c 0000003a 0000002e
	global_load_b32 v59, v[48:49], off                         // 0000000025d0: ee05007c 0000003b 00000030
	global_load_b32 v50, v[50:51], off                         // 0000000025dc: ee05007c 00000032 00000032
	global_load_b32 v51, v[52:53], off                         // 0000000025e8: ee05007c 00000033 00000034
	s_add_nc_u64 s[40:41], s[40:41], 16                        // 0000000025f4: a9a89028
	s_wait_alu depctr_sa_sdst(0)                               // 0000000025f8: bf88ff9e
	v_cmp_lt_i64_e64 s17, s[40:41], s[24:25]                   // 0000000025fc: d4510011 02003028
	s_wait_loadcnt 0x17                                        // 000000002604: bfc00017
	v_cndmask_b16 v38.l, 0, v38.l, vcc_lo                      // 000000002608: d65d0026 01aa4c80
	v_cndmask_b16 v38.h, 0, v38.h, s2                          // 000000002610: d65d5026 000a4c80
	s_wait_loadcnt 0x15                                        // 000000002618: bfc00015
	v_cndmask_b16 v39.l, 0, v39.l, s3                          // 00000000261c: d65d0027 000e4e80
	v_cndmask_b16 v39.h, 0, v39.h, s4                          // 000000002624: d65d5027 00124e80
	s_wait_loadcnt 0x13                                        // 00000000262c: bfc00013
	v_cndmask_b16 v40.l, 0, v40.l, s5                          // 000000002630: d65d0028 00165080
	v_cndmask_b16 v40.h, 0, v40.h, s6                          // 000000002638: d65d5028 001a5080
	s_wait_loadcnt 0x11                                        // 000000002640: bfc00011
	v_cndmask_b16 v41.l, 0, v41.l, s7                          // 000000002644: d65d0029 001e5280
	v_cndmask_b16 v41.h, 0, v41.h, s8                          // 00000000264c: d65d5029 00225280
	s_wait_loadcnt 0xd                                         // 000000002654: bfc0000d
	v_cndmask_b16 v42.l, 0, v42.l, s9                          // 000000002658: d65d002a 00265480
	v_and_b16 v38.l, 0xff, v38.l                               // 000000002660: d7620026 02024cff 000000ff
	v_lshlrev_b16 v40.h, 8, v40.h op_sel:[0,1,1]               // 00000000266c: d7385028 02025088
	v_and_b16 v41.l, 0xff, v41.l                               // 000000002674: d7620029 020252ff 000000ff
	v_lshlrev_b16 v41.h, 8, v41.h op_sel:[0,1,1]               // 000000002680: d7385029 02025288
	v_and_b16 v42.l, 0xff, v42.l                               // 000000002688: d762002a 020254ff 000000ff
	v_and_b16 v40.l, 0xff, v40.l                               // 000000002694: d7620028 020250ff 000000ff
	v_lshlrev_b16 v39.h, 8, v39.h op_sel:[0,1,1]               // 0000000026a0: d7385027 02024e88
	v_and_b16 v39.l, 0xff, v39.l                               // 0000000026a8: d7620027 02024eff 000000ff
	v_lshlrev_b16 v38.h, 8, v38.h op_sel:[0,1,1]               // 0000000026b4: d7385026 02024c88
	v_or_b16 v47.h, v41.l, v41.h op_sel:[0,1,1]                // 0000000026bc: d763502f 02025329
	v_or_b16 v47.l, v40.l, v40.h op_sel:[0,1,0]                // 0000000026c4: d763102f 02025128
	s_and_b32 vcc_lo, exec_lo, s17                             // 0000000026cc: 8b6a117e
	v_or_b16 v46.h, v39.l, v39.h op_sel:[0,1,1]                // 0000000026d0: d763502e 02024f27
	v_or_b16 v46.l, v38.l, v38.h op_sel:[0,1,0]                // 0000000026d8: d763102e 02024d26
	v_cndmask_b16 v42.h, 0, v42.h, s10                         // 0000000026e0: d65d502a 002a5480
	s_wait_loadcnt 0xb                                         // 0000000026e8: bfc0000b
	v_cndmask_b16 v43.l, 0, v43.l, s11                         // 0000000026ec: d65d002b 002e5680
	v_cndmask_b16 v43.h, 0, v43.h, s12                         // 0000000026f4: d65d502b 00325680
	s_wait_loadcnt 0x9                                         // 0000000026fc: bfc00009
	v_cndmask_b16 v44.l, 0, v44.l, s13                         // 000000002700: d65d002c 00365880
	v_cndmask_b16 v44.h, 0, v44.h, s14                         // 000000002708: d65d502c 003a5880
	s_wait_loadcnt 0x7                                         // 000000002710: bfc00007
	v_cndmask_b16 v45.l, 0, v45.l, s15                         // 000000002714: d65d002d 003e5a80
	v_cndmask_b16 v45.h, 0, v45.h, s16                         // 00000000271c: d65d502d 00425a80
	v_lshlrev_b16 v43.h, 8, v43.h op_sel:[0,1,1]               // 000000002724: d738502b 02025688
	v_and_b16 v44.l, 0xff, v44.l                               // 00000000272c: d762002c 020258ff 000000ff
	v_lshlrev_b16 v44.h, 8, v44.h op_sel:[0,1,1]               // 000000002738: d738502c 02025888
	v_and_b16 v45.l, 0xff, v45.l                               // 000000002740: d762002d 02025aff 000000ff
	v_lshlrev_b16 v45.h, 8, v45.h op_sel:[0,1,1]               // 00000000274c: d738502d 02025a88
	v_and_b16 v43.l, 0xff, v43.l                               // 000000002754: d762002b 020256ff 000000ff
	v_lshlrev_b16 v42.h, 8, v42.h op_sel:[0,1,1]               // 000000002760: d738502a 02025488
	v_or_b16 v49.l, v44.l, v44.h op_sel:[0,1,0]                // 000000002768: d7631031 0202592c
	v_mul_f32_e32 v52, v61, v55                                // 000000002770: 10686f3d
	v_or_b16 v49.h, v45.l, v45.h op_sel:[0,1,1]                // 000000002774: d7635031 02025b2d
	v_or_b16 v48.h, v43.l, v43.h op_sel:[0,1,1]                // 00000000277c: d7635030 0202572b
	v_or_b16 v48.l, v42.l, v42.h op_sel:[0,1,0]                // 000000002784: d7631030 0202552a
	s_wait_loadcnt 0x5                                         // 00000000278c: bfc00005
	v_dual_mul_f32 v53, v55, v54 :: v_dual_mul_f32 v54, v55, v56// 000000002790: c8c66d37 35367137
	s_wait_loadcnt 0x4                                         // 000000002798: bfc00004
	v_mul_f32_e32 v56, v55, v57                                // 00000000279c: 10707337
	v_wmma_f32_16x16x16_fp8_fp8 v[38:45], v[46:47], v[48:49], 0// 0000000027a0: cc464026 1a02612e
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 0000000027a8: bf870091
	v_dual_mul_f32 v38, v38, v52 :: v_dual_mul_f32 v39, v39, v53// 0000000027ac: c8c66926 26266b27
	v_add_f32_e32 v1, v1, v38                                  // 0000000027b4: 06024d01
	s_delay_alu instid0(valu_dep_2)                            // 0000000027b8: bf870002
	v_add_f32_e32 v23, v23, v39                                // 0000000027bc: 062e4f17
	s_wait_loadcnt 0x2                                         // 0000000027c0: bfc00002
	v_dual_mul_f32 v47, v55, v59 :: v_dual_mul_f32 v40, v40, v54// 0000000027c4: c8c67737 2f286d28
	s_wait_loadcnt 0x0                                         // 0000000027cc: bfc00000
	v_dual_mul_f32 v49, v55, v51 :: v_dual_mul_f32 v46, v55, v58// 0000000027d0: c8c66737 312e7537
	v_dual_mul_f32 v41, v41, v56 :: v_dual_mul_f32 v48, v55, v50// 0000000027d8: c8c67129 29306537
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 0000000027e0: bf870193
	v_mul_f32_e32 v43, v43, v47                                // 0000000027e4: 10565f2b
	v_dual_mul_f32 v45, v45, v49 :: v_dual_mul_f32 v42, v42, v46// 0000000027e8: c8c6632d 2d2a5d2a
	v_add_f32_e32 v17, v17, v40                                // 0000000027f0: 06225111
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 0000000027f4: bf870194
	v_dual_mul_f32 v44, v44, v48 :: v_dual_add_f32 v13, v13, v41// 0000000027f8: c8c8612c 2c0c530d
	v_dual_add_f32 v11, v11, v43 :: v_dual_add_f32 v20, v20, v45// 000000002800: c908570b 0b145b14
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 000000002808: bf870194
	v_add_f32_e32 v12, v12, v42                                // 00000000280c: 0618550c
	v_add_f32_e32 v2, v2, v44                                  // 000000002810: 06045902
	s_wait_alu depctr_sa_sdst(0)                               // 000000002814: bf88ff9e
	s_cbranch_vccnz 64991                                      // 000000002818: bfa4fddf <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x498>
	v_mul_lo_u32 v0, s23, v6                                   // 00000000281c: d72c0000 02020c17
	v_mul_lo_u32 v10, s22, v7                                  // 000000002824: d72c000a 02020e16
	v_mad_co_u64_u32 v[14:15], null, s22, v6, 0                // 00000000282c: d6fe7c0e 02020c16
	v_sub_co_u32 v8, vcc_lo, s20, v6                           // 000000002834: d7016a08 02020c14
	s_wait_alu depctr_va_vcc(0)                                // 00000000283c: bf88ff9d
	v_sub_co_ci_u32_e64 v9, null, s21, v7, vcc_lo              // 000000002840: d5217c09 01aa0e15
	v_cmp_gt_i64_e32 vcc_lo, s[22:23], v[3:4]                  // 000000002848: 7ca80616
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_3)// 00000000284c: bf870194
	v_add3_u32 v15, v15, v10, v0                               // 000000002850: d655000f 0402150f
	v_cmp_lt_i64_e64 s0, 0, v[8:9]                             // 000000002858: d4510000 02021080
	s_delay_alu instid0(valu_dep_2)                            // 000000002860: bf870002
	v_lshlrev_b64_e32 v[6:7], 1, v[14:15]                      // 000000002864: 3e0c1c81
	s_and_b32 s0, s0, vcc_lo                                   // 000000002868: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 00000000286c: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000002870: be812000
	s_cbranch_execz 28                                         // 000000002874: bfa5001c <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0xde8>
	v_lshlrev_b64_e32 v[14:15], 1, v[3:4]                      // 000000002878: 3e1c0681
	v_add_co_u32 v10, s0, s18, v6                              // 00000000287c: d700000a 02020c12
	v_bfe_u32 v0, v1, 16, 1                                    // 000000002884: d6100000 02052101
	s_wait_alu depctr_va_sdst(0)                               // 00000000288c: bf88f19f
	v_add_co_ci_u32_e64 v16, null, s19, v7, s0                 // 000000002890: d5207c10 00020e13
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002898: bf870193
	v_add_co_u32 v14, s0, v10, v14                             // 00000000289c: d700000e 02021d0a
	v_add3_u32 v0, v0, v1, 0x7fff                              // 0000000028a4: d6550000 03fe0300 00007fff
	v_or_b32_e32 v18, 0x400000, v1                             // 0000000028b0: 382402ff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 0000000028b8: bf88f19f
	v_add_co_ci_u32_e64 v15, null, v16, v15, s0                // 0000000028bc: d5207c0f 00021f10
	v_cmp_u_f32_e64 s0, v1, v1                                 // 0000000028c4: d4180000 02020301
	s_wait_alu depctr_va_sdst(0)                               // 0000000028cc: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 0000000028d0: bf870001
	v_cndmask_b32_e64 v0, v0, v18, s0                          // 0000000028d4: d5010000 00022500
	global_store_d16_hi_b16 v[14:15], v0, off                  // 0000000028dc: ee09407c 00000000 0000000e
	s_wait_alu depctr_sa_sdst(0)                               // 0000000028e8: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000028ec: 8c7e017e
	v_cmp_lt_i64_e64 s0, 1, v[8:9]                             // 0000000028f0: d4510000 02021081
	s_and_b32 s0, s0, vcc_lo                                   // 0000000028f8: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 0000000028fc: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000002900: be812000
	s_cbranch_execz 35                                         // 000000002904: bfa50023 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0xe94>
	v_add_co_u32 v10, s0, s18, v6                              // 000000002908: d700000a 02020c12
	s_wait_alu depctr_va_sdst(0)                               // 000000002910: bf88f19f
	v_add_co_ci_u32_e64 v14, null, s19, v7, s0                 // 000000002914: d5207c0e 00020e13
	s_lshl_b64 s[2:3], s[22:23], 1                             // 00000000291c: 84828116
	v_lshlrev_b64_e32 v[0:1], 1, v[3:4]                        // 000000002920: 3e000681
	s_wait_alu depctr_sa_sdst(0)                               // 000000002924: bf88ff9e
	v_add_co_u32 v10, s0, v10, s2                              // 000000002928: d700000a 0200050a
	v_bfe_u32 v15, v23, 16, 1                                  // 000000002930: d610000f 02052117
	s_wait_alu depctr_va_sdst(0)                               // 000000002938: bf88f19f
	v_add_co_ci_u32_e64 v14, null, s3, v14, s0                 // 00000000293c: d5207c0e 00021c03
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002944: bf870193
	v_add_co_u32 v0, s0, v10, v0                               // 000000002948: d7000000 0202010a
	v_add3_u32 v15, v15, v23, 0x7fff                           // 000000002950: d655000f 03fe2f0f 00007fff
	v_or_b32_e32 v16, 0x400000, v23                            // 00000000295c: 38202eff 00400000
	s_wait_alu depctr_va_sdst(0)                               // 000000002964: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v14, v1, s0                  // 000000002968: d5207c01 0002030e
	v_cmp_u_f32_e64 s0, v23, v23                               // 000000002970: d4180000 02022f17
	s_wait_alu depctr_va_sdst(0)                               // 000000002978: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 00000000297c: bf870001
	v_cndmask_b32_e64 v10, v15, v16, s0                        // 000000002980: d501000a 0002210f
	global_store_d16_hi_b16 v[0:1], v10, off                   // 000000002988: ee09407c 05000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002994: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000002998: 8c7e017e
	v_cmp_lt_i64_e64 s0, 2, v[8:9]                             // 00000000299c: d4510000 02021082
	s_and_b32 s0, s0, vcc_lo                                   // 0000000029a4: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 0000000029a8: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 0000000029ac: be812000
	s_cbranch_execz 34                                         // 0000000029b0: bfa50022 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0xf3c>
	v_add_co_u32 v15, s0, s18, v6                              // 0000000029b4: d700000f 02020c12
	v_bfe_u32 v0, v17, 16, 1                                   // 0000000029bc: d6100000 02052111
	s_wait_alu depctr_va_sdst(0)                               // 0000000029c4: bf88f19f
	v_add_co_ci_u32_e64 v16, null, s19, v7, s0                 // 0000000029c8: d5207c10 00020e13
	s_lshl_b64 s[2:3], s[22:23], 2                             // 0000000029d0: 84828216
	v_or_b32_e32 v10, 0x400000, v17                            // 0000000029d4: 381422ff 00400000
	s_wait_alu depctr_sa_sdst(0)                               // 0000000029dc: bf88ff9e
	v_add_co_u32 v15, s0, v15, s2                              // 0000000029e0: d700000f 0200050f
	v_add3_u32 v14, v0, v17, 0x7fff                            // 0000000029e8: d655000e 03fe2300 00007fff
	v_lshlrev_b64_e32 v[0:1], 1, v[3:4]                        // 0000000029f4: 3e000681
	s_wait_alu depctr_va_sdst(0)                               // 0000000029f8: bf88f19f
	v_add_co_ci_u32_e64 v16, null, s3, v16, s0                 // 0000000029fc: d5207c10 00022003
	v_cmp_u_f32_e64 s0, v17, v17                               // 000000002a04: d4180000 02022311
	s_wait_alu depctr_va_sdst(0)                               // 000000002a0c: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000002a10: bf870001
	v_cndmask_b32_e64 v10, v14, v10, s0                        // 000000002a14: d501000a 0002150e
	v_add_co_u32 v0, s0, v15, v0                               // 000000002a1c: d7000000 0202010f
	s_wait_alu depctr_va_sdst(0)                               // 000000002a24: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v16, v1, s0                  // 000000002a28: d5207c01 00020310
	global_store_d16_hi_b16 v[0:1], v10, off                   // 000000002a30: ee09407c 05000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a3c: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000002a40: 8c7e017e
	v_cmp_lt_i64_e64 s0, 3, v[8:9]                             // 000000002a44: d4510000 02021083
	s_and_b32 s0, s0, vcc_lo                                   // 000000002a4c: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a50: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000002a54: be812000
	s_cbranch_execz 33                                         // 000000002a58: bfa50021 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0xfe0>
	v_add_co_u32 v0, s0, s18, v6                               // 000000002a5c: d7000000 02020c12
	s_wait_alu depctr_va_sdst(0)                               // 000000002a64: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s19, v7, s0                  // 000000002a68: d5207c01 00020e13
	v_bfe_u32 v10, v13, 16, 1                                  // 000000002a70: d610000a 0205210d
	v_or_b32_e32 v17, 0x400000, v13                            // 000000002a78: 38221aff 00400000
	v_cmp_u_f32_e64 s0, v13, v13                               // 000000002a80: d4180000 02021b0d
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000002a88: bf870214
	v_mad_co_u64_u32 v[0:1], null, s22, 6, v[0:1]              // 000000002a8c: d6fe7c00 04010c16
	v_add3_u32 v10, v10, v13, 0x7fff                           // 000000002a94: d655000a 03fe1b0a 00007fff
	s_wait_alu depctr_va_sdst(0)                               // 000000002aa0: bf88f19f
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_3)// 000000002aa4: bf870191
	v_cndmask_b32_e64 v10, v10, v17, s0                        // 000000002aa8: d501000a 0002230a
	v_mad_co_u64_u32 v[14:15], null, s23, 6, v[1:2]            // 000000002ab0: d6fe7c0e 04050c17
	v_lshlrev_b64_e32 v[15:16], 1, v[3:4]                      // 000000002ab8: 3e1e0681
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000002abc: bf870121
	v_add_co_u32 v0, s0, v0, v15                               // 000000002ac0: d7000000 02021f00
	s_wait_alu depctr_va_sdst(0)                               // 000000002ac8: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v14, v16, s0                 // 000000002acc: d5207c01 0002210e
	global_store_d16_hi_b16 v[0:1], v10, off                   // 000000002ad4: ee09407c 05000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002ae0: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000002ae4: 8c7e017e
	v_cmp_lt_i64_e64 s0, 4, v[8:9]                             // 000000002ae8: d4510000 02021084
	s_and_b32 s0, s0, vcc_lo                                   // 000000002af0: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002af4: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000002af8: be812000
	s_cbranch_execz 34                                         // 000000002afc: bfa50022 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x1088>
	v_add_co_u32 v14, s0, s18, v6                              // 000000002b00: d700000e 02020c12
	v_bfe_u32 v0, v12, 16, 1                                   // 000000002b08: d6100000 0205210c
	s_wait_alu depctr_va_sdst(0)                               // 000000002b10: bf88f19f
	v_add_co_ci_u32_e64 v15, null, s19, v7, s0                 // 000000002b14: d5207c0f 00020e13
	s_lshl_b64 s[2:3], s[22:23], 3                             // 000000002b1c: 84828316
	v_or_b32_e32 v10, 0x400000, v12                            // 000000002b20: 381418ff 00400000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002b28: bf88ff9e
	v_add_co_u32 v14, s0, v14, s2                              // 000000002b2c: d700000e 0200050e
	v_add3_u32 v13, v0, v12, 0x7fff                            // 000000002b34: d655000d 03fe1900 00007fff
	v_lshlrev_b64_e32 v[0:1], 1, v[3:4]                        // 000000002b40: 3e000681
	s_wait_alu depctr_va_sdst(0)                               // 000000002b44: bf88f19f
	v_add_co_ci_u32_e64 v15, null, s3, v15, s0                 // 000000002b48: d5207c0f 00021e03
	v_cmp_u_f32_e64 s0, v12, v12                               // 000000002b50: d4180000 0202190c
	s_wait_alu depctr_va_sdst(0)                               // 000000002b58: bf88f19f
	s_delay_alu instid0(valu_dep_1)                            // 000000002b5c: bf870001
	v_cndmask_b32_e64 v10, v13, v10, s0                        // 000000002b60: d501000a 0002150d
	v_add_co_u32 v0, s0, v14, v0                               // 000000002b68: d7000000 0202010e
	s_wait_alu depctr_va_sdst(0)                               // 000000002b70: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v15, v1, s0                  // 000000002b74: d5207c01 0002030f
	global_store_d16_hi_b16 v[0:1], v10, off                   // 000000002b7c: ee09407c 05000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002b88: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000002b8c: 8c7e017e
	v_cmp_lt_i64_e64 s0, 5, v[8:9]                             // 000000002b90: d4510000 02021085
	s_and_b32 s0, s0, vcc_lo                                   // 000000002b98: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002b9c: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000002ba0: be812000
	s_cbranch_execz 33                                         // 000000002ba4: bfa50021 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x112c>
	v_add_co_u32 v0, s0, s18, v6                               // 000000002ba8: d7000000 02020c12
	s_wait_alu depctr_va_sdst(0)                               // 000000002bb0: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s19, v7, s0                  // 000000002bb4: d5207c01 00020e13
	v_bfe_u32 v10, v11, 16, 1                                  // 000000002bbc: d610000a 0205210b
	v_or_b32_e32 v15, 0x400000, v11                            // 000000002bc4: 381e16ff 00400000
	v_cmp_u_f32_e64 s0, v11, v11                               // 000000002bcc: d4180000 0202170b
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000002bd4: bf870214
	v_mad_co_u64_u32 v[0:1], null, s22, 10, v[0:1]             // 000000002bd8: d6fe7c00 04011416
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000002be0: d655000a 03fe170a 00007fff
	s_wait_alu depctr_va_sdst(0)                               // 000000002bec: bf88f19f
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_3)// 000000002bf0: bf870191
	v_cndmask_b32_e64 v10, v10, v15, s0                        // 000000002bf4: d501000a 00021f0a
	v_mad_co_u64_u32 v[12:13], null, s23, 10, v[1:2]           // 000000002bfc: d6fe7c0c 04051417
	v_lshlrev_b64_e32 v[13:14], 1, v[3:4]                      // 000000002c04: 3e1a0681
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000002c08: bf870121
	v_add_co_u32 v0, s0, v0, v13                               // 000000002c0c: d7000000 02021b00
	s_wait_alu depctr_va_sdst(0)                               // 000000002c14: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v12, v14, s0                 // 000000002c18: d5207c01 00021d0c
	global_store_d16_hi_b16 v[0:1], v10, off                   // 000000002c20: ee09407c 05000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002c2c: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000002c30: 8c7e017e
	v_cmp_lt_i64_e64 s0, 6, v[8:9]                             // 000000002c34: d4510000 02021086
	s_and_b32 s0, s0, vcc_lo                                   // 000000002c3c: 8b006a00
	s_wait_alu depctr_sa_sdst(0)                               // 000000002c40: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000002c44: be812000
	s_cbranch_execz 33                                         // 000000002c48: bfa50021 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x11d0>
	v_add_co_u32 v0, s0, s18, v6                               // 000000002c4c: d7000000 02020c12
	s_wait_alu depctr_va_sdst(0)                               // 000000002c54: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s19, v7, s0                  // 000000002c58: d5207c01 00020e13
	v_bfe_u32 v10, v2, 16, 1                                   // 000000002c60: d610000a 02052102
	v_or_b32_e32 v13, 0x400000, v2                             // 000000002c68: 381a04ff 00400000
	v_cmp_u_f32_e64 s0, v2, v2                                 // 000000002c70: d4180000 02020502
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000002c78: bf870214
	v_mad_co_u64_u32 v[0:1], null, s22, 12, v[0:1]             // 000000002c7c: d6fe7c00 04011816
	v_add3_u32 v14, v10, v2, 0x7fff                            // 000000002c84: d655000e 03fe050a 00007fff
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_3)// 000000002c90: bf8701b2
	v_mad_co_u64_u32 v[10:11], null, s23, 12, v[1:2]           // 000000002c94: d6fe7c0a 04051817
	v_lshlrev_b64_e32 v[11:12], 1, v[3:4]                      // 000000002c9c: 3e160681
	s_wait_alu depctr_va_sdst(0)                               // 000000002ca0: bf88f19f
	v_cndmask_b32_e64 v2, v14, v13, s0                         // 000000002ca4: d5010002 00021b0e
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_3)// 000000002cac: bf8701a2
	v_add_co_u32 v0, s0, v0, v11                               // 000000002cb0: d7000000 02021700
	s_wait_alu depctr_va_sdst(0)                               // 000000002cb8: bf88f19f
	v_add_co_ci_u32_e64 v1, null, v10, v12, s0                 // 000000002cbc: d5207c01 0002190a
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000002cc4: ee09407c 01000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002cd0: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s1                              // 000000002cd4: 8c7e017e
	v_cmp_lt_i64_e64 s0, 7, v[8:9]                             // 000000002cd8: d4510000 02021087
	s_mov_b32 s1, 0                                            // 000000002ce0: be810080
	s_and_b32 s2, s0, vcc_lo                                   // 000000002ce4: 8b026a00
	s_mov_b32 s0, 0                                            // 000000002ce8: be800080
	s_wait_alu depctr_sa_sdst(0)                               // 000000002cec: bf88ff9e
	s_and_saveexec_b32 s3, s2                                  // 000000002cf0: be832002
	s_wait_alu depctr_sa_sdst(0)                               // 000000002cf4: bf88ff9e
	s_xor_b32 s2, exec_lo, s3                                  // 000000002cf8: 8d02037e
	v_add_co_u32 v0, vcc_lo, s18, v6                           // 000000002cfc: d7006a00 02020c12
	s_wait_alu depctr_va_vcc(0)                                // 000000002d04: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s19, v7, vcc_lo              // 000000002d08: d5207c01 01aa0e13
	s_mov_b32 s0, exec_lo                                      // 000000002d10: be80007e
	v_mad_co_u64_u32 v[0:1], null, s22, 14, v[0:1]             // 000000002d14: d6fe7c00 04011c16
	s_delay_alu instid0(valu_dep_1)                            // 000000002d1c: bf870001
	v_mad_co_u64_u32 v[1:2], null, s23, 14, v[1:2]             // 000000002d20: d6fe7c01 04051c17
	s_wait_alu depctr_sa_sdst(0)                               // 000000002d28: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s2                              // 000000002d2c: 8c7e027e
	s_delay_alu instid0(salu_cycle_1)                          // 000000002d30: bf870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000002d34: 8b6a017e
	s_wait_alu depctr_sa_sdst(0)                               // 000000002d38: bf88ff9e
	s_cbranch_vccz 648                                         // 000000002d3c: bfa30288 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x1c60>
	s_and_b32 s0, s33, exec_lo                                 // 000000002d40: 8b007e21
	s_cselect_b32 s0, 1, 0                                     // 000000002d44: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 000000002d48: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000002d4c: bf078100
	s_cbranch_scc1 19                                          // 000000002d50: bfa20013 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x12a0>
	v_lshl_or_b32 v0, v22, 3, s28                              // 000000002d54: d6560000 00710716
	v_mov_b32_e32 v1, s29                                      // 000000002d5c: 7e02021d
	v_mov_b32_e32 v9, s29                                      // 000000002d60: 7e12021d
	v_mov_b32_e32 v7, s29                                      // 000000002d64: 7e0e021d
	v_mov_b32_e32 v11, s29                                     // 000000002d68: 7e16021d
	v_or_b32_e32 v8, 1, v0                                     // 000000002d6c: 38100081
	v_or_b32_e32 v6, 2, v0                                     // 000000002d70: 380c0082
	v_or_b32_e32 v10, 3, v0                                    // 000000002d74: 38140083
	v_or_b32_e32 v12, 4, v0                                    // 000000002d78: 38180084
	v_mov_b32_e32 v13, s29                                     // 000000002d7c: 7e1a021d
	v_or_b32_e32 v16, 5, v0                                    // 000000002d80: 38200085
	v_mov_b32_e32 v17, s29                                     // 000000002d84: 7e22021d
	v_or_b32_e32 v14, 6, v0                                    // 000000002d88: 381c0086
	v_mov_b32_e32 v15, s29                                     // 000000002d8c: 7e1e021d
	v_or_b32_e32 v18, 7, v0                                    // 000000002d90: 38240087
	v_mov_b32_e32 v19, s29                                     // 000000002d94: 7e26021d
	s_mov_b32 s0, 0                                            // 000000002d98: be800080
	s_branch 1                                                 // 000000002d9c: bfa00001 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x12a4>
	s_mov_b32 s0, -1                                           // 000000002da0: be8000c1
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v23, 0             // 000000002da4: ca100080 14160080
	s_wait_alu depctr_sa_sdst(0)                               // 000000002dac: bf88ff9e
	s_and_b32 s0, s0, exec_lo                                  // 000000002db0: 8b007e00
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000002db4: ca100080 18180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v30, 0             // 000000002dbc: ca100080 1b1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v2, 0              // 000000002dc4: ca100080 21020080
	s_cselect_b32 s0, 1, 0                                     // 000000002dcc: 98008081
	s_wait_alu depctr_sa_sdst(0)                               // 000000002dd0: bf88ff9e
	s_cmp_lg_u32 s0, 1                                         // 000000002dd4: bf078100
	s_cbranch_scc1 361                                         // 000000002dd8: bfa20169 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x1880>
	v_dual_mov_b32 v1, s29 :: v_dual_lshlrev_b32 v12, 3, v22   // 000000002ddc: ca22001d 010c2c83
	v_mad_co_u64_u32 v[6:7], null, s34, v3, s[38:39]           // 000000002de4: d6fe7c06 009a0622
	v_mul_lo_u32 v8, s34, v4                                   // 000000002dec: d72c0008 02020822
	v_mul_lo_u32 v9, s35, v3                                   // 000000002df4: d72c0009 02020623
	s_delay_alu instid0(valu_dep_4) | instskip(skip_3) | instid1(valu_dep_3)// 000000002dfc: bf8701c4
	v_or_b32_e32 v0, s28, v12                                  // 000000002e00: 3800181c
	v_add_co_u32 v5, vcc_lo, s36, v5                           // 000000002e04: d7006a05 02020a24
	s_wait_alu depctr_va_vcc(0)                                // 000000002e0c: bf88ff9d
	v_add_co_ci_u32_e64 v10, null, s37, v21, vcc_lo            // 000000002e10: d5207c0a 01aa2a25
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[0:1]                  // 000000002e18: 7ca80014
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002e1c: bf8701a3
	v_add_co_u32 v5, s0, v5, v12                               // 000000002e20: d7000005 02021905
	s_wait_alu depctr_va_sdst(0)                               // 000000002e28: bf88f19f
	v_add_co_ci_u32_e64 v21, null, 0, v10, s0                  // 000000002e2c: d5207c15 00021480
	v_add3_u32 v7, v9, v7, v8                                  // 000000002e34: d6550007 04220f09
	s_wait_alu depctr_va_vcc(0)                                // 000000002e3c: bf88ff9d
	v_cndmask_b32_e32 v10, 0, v0, vcc_lo                       // 000000002e40: 02140080
	v_cndmask_b32_e64 v11, 0, s29, vcc_lo                      // 000000002e44: d501000b 01a83a80
	s_lshr_b64 s[2:3], s[34:35], 4                             // 000000002e4c: 85828422
	s_lshr_b32 s3, s35, 4                                      // 000000002e50: 85038423
	v_add_co_u32 v22, s1, v6, v12                              // 000000002e54: d7000116 02021906
	s_wait_alu depctr_sa_sdst(0)                               // 000000002e5c: bf88ff9e
	v_mul_lo_u32 v15, s2, v11                                  // 000000002e60: d72c000f 02021602
	s_wait_alu depctr_va_sdst(0)                               // 000000002e68: bf88f19f
	v_add_co_ci_u32_e64 v26, null, 0, v7, s1                   // 000000002e6c: d5207c1a 00060e80
	v_mov_b32_e32 v7, s29                                      // 000000002e74: 7e0e021d
	v_mul_lo_u32 v14, s3, v10                                  // 000000002e78: d72c000e 02021403
	v_mad_co_u64_u32 v[10:11], null, s2, v10, 0                // 000000002e80: d6fe7c0a 02021402
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v9, s29             // 000000002e88: ca100080 0208001d
	v_or_b32_e32 v8, 1, v0                                     // 000000002e90: 38100081
	v_cmp_gt_i64_e32 vcc_lo, s[22:23], v[3:4]                  // 000000002e94: 7ca80616
	v_or_b32_e32 v6, 2, v0                                     // 000000002e98: 380c0082
	v_add3_u32 v11, v11, v15, v14                              // 000000002e9c: d655000b 043a1f0b
	s_delay_alu instid0(valu_dep_4)                            // 000000002ea4: bf870004
	v_cmp_gt_i64_e64 s0, s[20:21], v[8:9]                      // 000000002ea8: d4540000 02021014
	s_wait_alu depctr_va_vcc(0)                                // 000000002eb0: bf88ff9d
	v_dual_cndmask_b32 v13, 0, v4 :: v_dual_cndmask_b32 v12, 0, v3// 000000002eb4: ca520880 0d0c0680
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[6:7]                  // 000000002ebc: 7ca80c14
	v_lshlrev_b64_e32 v[10:11], 2, v[10:11]                    // 000000002ec0: 3e141482
	s_wait_alu depctr_va_sdst(0)                               // 000000002ec4: bf88f19f
	v_cndmask_b32_e64 v14, 0, v8, s0                           // 000000002ec8: d501000e 00021080
	v_cndmask_b32_e64 v15, 0, s29, s0                          // 000000002ed0: d501000f 00003a80
	v_lshlrev_b64_e32 v[12:13], 2, v[12:13]                    // 000000002ed8: 3e181882
	s_wait_alu depctr_va_vcc(0)                                // 000000002edc: bf88ff9d
	v_cndmask_b32_e32 v18, 0, v6, vcc_lo                       // 000000002ee0: 02240c80
	v_add_co_u32 v28, s0, s26, v10                             // 000000002ee4: d700001c 0202141a
	s_wait_alu depctr_va_sdst(0)                               // 000000002eec: bf88f19f
	v_add_co_ci_u32_e64 v29, null, s27, v11, s0                // 000000002ef0: d5207c1d 0002161b
	v_or_b32_e32 v10, 3, v0                                    // 000000002ef8: 38140083
	v_mov_b32_e32 v11, s29                                     // 000000002efc: 7e16021d
	v_mul_lo_u32 v16, s3, v14                                  // 000000002f00: d72c0010 02021c03
	v_mul_lo_u32 v17, s2, v15                                  // 000000002f08: d72c0011 02021e02
	v_mad_co_u64_u32 v[14:15], null, s2, v14, 0                // 000000002f10: d6fe7c0e 02021c02
	v_cndmask_b32_e64 v19, 0, s29, vcc_lo                      // 000000002f18: d5010013 01a83a80
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[10:11]                // 000000002f20: 7ca81414
	v_add_co_u32 v31, s0, s30, v12                             // 000000002f24: d700001f 0202181e
	v_mul_lo_u32 v20, s3, v18                                  // 000000002f2c: d72c0014 02022403
	s_delay_alu instid0(valu_dep_4)                            // 000000002f34: bf870004
	v_mul_lo_u32 v19, s2, v19                                  // 000000002f38: d72c0013 02022602
	s_wait_alu depctr_va_sdst(0)                               // 000000002f40: bf88f19f
	v_add_co_ci_u32_e64 v32, null, s31, v13, s0                // 000000002f44: d5207c20 00021a1f
	v_add3_u32 v15, v15, v17, v16                              // 000000002f4c: d655000f 0442230f
	v_mad_co_u64_u32 v[16:17], null, s2, v18, 0                // 000000002f54: d6fe7c10 02022402
	s_wait_alu depctr_va_vcc(0)                                // 000000002f5c: bf88ff9d
	v_dual_cndmask_b32 v18, 0, v10 :: v_dual_mov_b32 v13, s29  // 000000002f60: ca501480 120c001d
	v_or_b32_e32 v12, 4, v0                                    // 000000002f68: 38180084
	v_lshlrev_b64_e32 v[14:15], 2, v[14:15]                    // 000000002f6c: 3e1c1c82
	v_cndmask_b32_e64 v23, 0, s29, vcc_lo                      // 000000002f70: d5010017 01a83a80
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_4)// 000000002f78: bf870233
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[12:13]                // 000000002f7c: 7ca81814
	v_add3_u32 v17, v17, v19, v20                              // 000000002f80: d6550011 04522711
	v_mul_lo_u32 v20, s3, v18                                  // 000000002f88: d72c0014 02022403
	v_mul_lo_u32 v25, s2, v23                                  // 000000002f90: d72c0019 02022e02
	v_mad_co_u64_u32 v[18:19], null, s2, v18, 0                // 000000002f98: d6fe7c12 02022402
	v_add_co_u32 v34, s0, s26, v14                             // 000000002fa0: d7000022 02021c1a
	s_wait_alu depctr_va_sdst(0)                               // 000000002fa8: bf88f19f
	v_add_co_ci_u32_e64 v35, null, s27, v15, s0                // 000000002fac: d5207c23 00021e1b
	s_wait_alu depctr_va_vcc(0)                                // 000000002fb4: bf88ff9d
	v_cndmask_b32_e32 v14, 0, v12, vcc_lo                      // 000000002fb8: 021c1880
	v_cndmask_b32_e64 v15, 0, s29, vcc_lo                      // 000000002fbc: d501000f 01a83a80
	v_lshlrev_b64_e32 v[23:24], 2, v[16:17]                    // 000000002fc4: 3e2e2082
	v_or_b32_e32 v16, 5, v0                                    // 000000002fc8: 38200085
	v_mov_b32_e32 v17, s29                                     // 000000002fcc: 7e22021d
	v_add3_u32 v19, v19, v25, v20                              // 000000002fd0: d6550013 04523313
	v_mul_lo_u32 v20, s3, v14                                  // 000000002fd8: d72c0014 02021c03
	v_mul_lo_u32 v25, s2, v15                                  // 000000002fe0: d72c0019 02021e02
	v_mad_co_u64_u32 v[40:41], null, s2, v14, 0                // 000000002fe8: d6fe7c28 02021c02
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[16:17]                // 000000002ff0: 7ca82014
	v_or_b32_e32 v14, 6, v0                                    // 000000002ff4: 381c0086
	v_mov_b32_e32 v15, s29                                     // 000000002ff8: 7e1e021d
	v_add_co_u32 v36, s0, s26, v23                             // 000000002ffc: d7000024 02022e1a
	s_wait_alu depctr_va_sdst(0)                               // 000000003004: bf88f19f
	v_add_co_ci_u32_e64 v37, null, s27, v24, s0                // 000000003008: d5207c25 0002301b
	v_lshlrev_b64_e32 v[23:24], 2, v[18:19]                    // 000000003010: 3e2e2482
	v_add3_u32 v41, v41, v25, v20                              // 000000003014: d6550029 04523329
	s_wait_alu depctr_va_vcc(0)                                // 00000000301c: bf88ff9d
	v_cndmask_b32_e32 v20, 0, v16, vcc_lo                      // 000000003020: 02282080
	v_cmp_gt_i64_e64 s0, s[20:21], v[14:15]                    // 000000003024: d4540000 02021c14
	v_or_b32_e32 v18, 7, v0                                    // 00000000302c: 38240087
	v_mov_b32_e32 v19, s29                                     // 000000003030: 7e26021d
	v_cndmask_b32_e64 v25, 0, s29, vcc_lo                      // 000000003034: d5010019 01a83a80
	v_mul_lo_u32 v27, s3, v20                                  // 00000000303c: d72c001b 02022803
	v_mad_co_u64_u32 v[42:43], null, s2, v20, 0                // 000000003044: d6fe7c2a 02022802
	s_wait_alu depctr_va_sdst(0)                               // 00000000304c: bf88f19f
	v_cndmask_b32_e64 v30, 0, v14, s0                          // 000000003050: d501001e 00021c80
	v_cmp_gt_i64_e32 vcc_lo, s[20:21], v[18:19]                // 000000003058: 7ca82414
	v_mul_lo_u32 v25, s2, v25                                  // 00000000305c: d72c0019 02023202
	v_cndmask_b32_e64 v33, 0, s29, s0                          // 000000003064: d5010021 00003a80
	s_mov_b64 s[0:1], 0                                        // 00000000306c: be800180
	v_mul_lo_u32 v20, s3, v30                                  // 000000003070: d72c0014 02023c03
	v_mad_co_u64_u32 v[44:45], null, s2, v30, 0                // 000000003078: d6fe7c2c 02023c02
	s_wait_alu depctr_va_vcc(0)                                // 000000003080: bf88ff9d
	v_cndmask_b32_e32 v30, 0, v18, vcc_lo                      // 000000003084: 023c2480
	v_cndmask_b32_e64 v46, 0, s29, vcc_lo                      // 000000003088: d501002e 01a83a80
	v_mul_lo_u32 v33, s2, v33                                  // 000000003090: d72c0021 02024202
	v_add3_u32 v43, v43, v25, v27                              // 000000003098: d655002b 046e332b
	v_add_co_u32 v38, vcc_lo, s26, v23                         // 0000000030a0: d7006a26 02022e1a
	v_mul_lo_u32 v25, s3, v30                                  // 0000000030a8: d72c0019 02023c03
	v_mul_lo_u32 v27, s2, v46                                  // 0000000030b0: d72c001b 02025c02
	v_mad_co_u64_u32 v[46:47], null, s2, v30, 0                // 0000000030b8: d6fe7c2e 02023c02
	s_wait_alu depctr_va_vcc(0)                                // 0000000030c0: bf88ff9d
	v_add_co_ci_u32_e64 v39, null, s27, v24, vcc_lo            // 0000000030c4: d5207c27 01aa301b
	v_lshlrev_b64_e32 v[23:24], 2, v[40:41]                    // 0000000030cc: 3e2e5082
	v_add3_u32 v45, v45, v33, v20                              // 0000000030d0: d655002d 0452432d
	v_lshlrev_b64_e32 v[42:43], 2, v[42:43]                    // 0000000030d8: 3e545482
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v30, 0             // 0000000030dc: ca100080 211e0080
	v_add3_u32 v47, v47, v27, v25                              // 0000000030e4: d655002f 0466372f
	v_add_co_u32 v40, vcc_lo, s26, v23                         // 0000000030ec: d7006a28 02022e1a
	s_wait_alu depctr_va_vcc(0)                                // 0000000030f4: bf88ff9d
	v_add_co_ci_u32_e64 v41, null, s27, v24, vcc_lo            // 0000000030f8: d5207c29 01aa301b
	v_lshlrev_b64_e32 v[23:24], 2, v[44:45]                    // 000000003100: 3e2e5882
	v_lshlrev_b64_e32 v[46:47], 2, v[46:47]                    // 000000003104: 3e5c5c82
	v_add_co_u32 v42, vcc_lo, s26, v42                         // 000000003108: d7006a2a 0202541a
	s_wait_alu depctr_va_vcc(0)                                // 000000003110: bf88ff9d
	v_add_co_ci_u32_e64 v43, null, s27, v43, vcc_lo            // 000000003114: d5207c2b 01aa561b
	s_delay_alu instid0(valu_dep_4)                            // 00000000311c: bf870004
	v_add_co_u32 v44, vcc_lo, s26, v23                         // 000000003120: d7006a2c 02022e1a
	s_wait_alu depctr_va_vcc(0)                                // 000000003128: bf88ff9d
	v_add_co_ci_u32_e64 v45, null, s27, v24, vcc_lo            // 00000000312c: d5207c2d 01aa301b
	v_add_co_u32 v46, vcc_lo, s26, v46                         // 000000003134: d7006a2e 02025c1a
	s_wait_alu depctr_va_vcc(0)                                // 00000000313c: bf88ff9d
	v_add_co_ci_u32_e64 v47, null, s27, v47, vcc_lo            // 000000003140: d5207c2f 01aa5e1b
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v24, 0             // 000000003148: ca100080 1b180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v20, 0             // 000000003150: ca100080 19140080
	v_mov_b32_e32 v23, 0                                       // 000000003158: 7e2e0280
	s_wait_alu depctr_sa_sdst(0)                               // 00000000315c: bf88ff9e
	v_add_co_u32 v48, vcc_lo, v5, s0                           // 000000003160: d7006a30 02000105
	s_wait_alu depctr_va_vcc(0)                                // 000000003168: bf88ff9d
	v_add_co_ci_u32_e64 v49, null, s1, v21, vcc_lo             // 00000000316c: d5207c31 01aa2a01
	v_add_co_u32 v50, vcc_lo, v22, s0                          // 000000003174: d7006a32 02000116
	s_lshr_b64 s[4:5], s[0:1], 2                               // 00000000317c: 85848200
	s_wait_alu depctr_va_vcc(0)                                // 000000003180: bf88ff9d
	v_add_co_ci_u32_e64 v51, null, s1, v26, vcc_lo             // 000000003184: d5207c33 01aa3401
	s_wait_alu depctr_sa_sdst(0)                               // 00000000318c: bf88ff9e
	v_add_co_u32 v52, vcc_lo, v28, s4                          // 000000003190: d7006a34 0200091c
	s_wait_alu depctr_va_vcc(0)                                // 000000003198: bf88ff9d
	v_add_co_ci_u32_e64 v53, null, s5, v29, vcc_lo             // 00000000319c: d5207c35 01aa3a05
	v_add_co_u32 v54, vcc_lo, v34, s4                          // 0000000031a4: d7006a36 02000922
	s_wait_alu depctr_va_vcc(0)                                // 0000000031ac: bf88ff9d
	v_add_co_ci_u32_e64 v55, null, s5, v35, vcc_lo             // 0000000031b0: d5207c37 01aa4605
	v_add_co_u32 v56, vcc_lo, v36, s4                          // 0000000031b8: d7006a38 02000924
	s_wait_alu depctr_va_vcc(0)                                // 0000000031c0: bf88ff9d
	v_add_co_ci_u32_e64 v57, null, s5, v37, vcc_lo             // 0000000031c4: d5207c39 01aa4a05
	v_add_co_u32 v58, vcc_lo, v38, s4                          // 0000000031cc: d7006a3a 02000926
	s_wait_alu depctr_va_vcc(0)                                // 0000000031d4: bf88ff9d
	v_add_co_ci_u32_e64 v59, null, s5, v39, vcc_lo             // 0000000031d8: d5207c3b 01aa4e05
	v_add_co_u32 v60, vcc_lo, v40, s4                          // 0000000031e0: d7006a3c 02000928
	s_lshr_b64 s[2:3], s[0:1], 4                               // 0000000031e8: 85828400
	s_wait_alu depctr_va_vcc(0)                                // 0000000031ec: bf88ff9d
	v_add_co_ci_u32_e64 v61, null, s5, v41, vcc_lo             // 0000000031f0: d5207c3d 01aa5205
	v_add_co_u32 v62, vcc_lo, v42, s4                          // 0000000031f8: d7006a3e 0200092a
	s_wait_alu depctr_sa_sdst(0)                               // 000000003200: bf88ff9e
	s_mul_u64 s[2:3], s[2:3], s[22:23]                         // 000000003204: aa821602
	s_wait_alu depctr_va_vcc(0)                                // 000000003208: bf88ff9d
	v_add_co_ci_u32_e64 v63, null, s5, v43, vcc_lo             // 00000000320c: d5207c3f 01aa5605
	v_add_co_u32 v64, vcc_lo, v44, s4                          // 000000003214: d7006a40 0200092c
	s_wait_alu depctr_va_vcc(0)                                // 00000000321c: bf88ff9d
	v_add_co_ci_u32_e64 v65, null, s5, v45, vcc_lo             // 000000003220: d5207c41 01aa5a05
	v_add_co_u32 v66, vcc_lo, v46, s4                          // 000000003228: d7006a42 0200092e
	s_wait_alu depctr_sa_sdst(0)                               // 000000003230: bf88ff9e
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000003234: 84828202
	s_wait_alu depctr_va_vcc(0)                                // 000000003238: bf88ff9d
	v_add_co_ci_u32_e64 v67, null, s5, v47, vcc_lo             // 00000000323c: d5207c43 01aa5e05
	global_load_b64 v[68:69], v[48:49], off                    // 000000003244: ee05407c 00000044 00000030
	global_load_b64 v[70:71], v[50:51], off                    // 000000003250: ee05407c 00000046 00000032
	s_wait_alu depctr_sa_sdst(0)                               // 00000000325c: bf88ff9e
	v_add_co_u32 v48, vcc_lo, v31, s2                          // 000000003260: d7006a30 0200051f
	s_wait_alu depctr_va_vcc(0)                                // 000000003268: bf88ff9d
	v_add_co_ci_u32_e64 v49, null, s3, v32, vcc_lo             // 00000000326c: d5207c31 01aa4003
	s_clause 0x7                                               // 000000003274: bf850007
	global_load_b32 v72, v[52:53], off                         // 000000003278: ee05007c 00000048 00000034
	global_load_b32 v73, v[54:55], off                         // 000000003284: ee05007c 00000049 00000036
	global_load_b32 v56, v[56:57], off                         // 000000003290: ee05007c 00000038 00000038
	global_load_b32 v57, v[58:59], off                         // 00000000329c: ee05007c 00000039 0000003a
	global_load_b32 v58, v[60:61], off                         // 0000000032a8: ee05007c 0000003a 0000003c
	global_load_b32 v59, v[62:63], off                         // 0000000032b4: ee05007c 0000003b 0000003e
	global_load_b32 v60, v[64:65], off                         // 0000000032c0: ee05007c 0000003c 00000040
	global_load_b32 v61, v[66:67], off                         // 0000000032cc: ee05007c 0000003d 00000042
	global_load_b32 v62, v[48:49], off                         // 0000000032d8: ee05007c 0000003e 00000030
	s_add_nc_u64 s[0:1], s[0:1], 16                            // 0000000032e4: a9809000
	s_wait_alu depctr_sa_sdst(0)                               // 0000000032e8: bf88ff9e
	v_cmp_lt_i64_e64 s2, s[0:1], s[24:25]                      // 0000000032ec: d4510002 02003000
	s_and_b32 vcc_lo, exec_lo, s2                              // 0000000032f4: 8b6a027e
	s_wait_loadcnt 0x9                                         // 0000000032f8: bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[68:69], v[70:71], 0// 0000000032fc: cc464030 1a028d44
	s_wait_loadcnt 0x0                                         // 000000003304: bfc00000
	v_dual_mul_f32 v63, v72, v62 :: v_dual_mul_f32 v64, v62, v73// 000000003308: c8c67d48 3f40933e
	v_dual_mul_f32 v56, v62, v56 :: v_dual_mul_f32 v57, v62, v57// 000000003310: c8c6713e 3838733e
	v_dual_mul_f32 v58, v62, v58 :: v_dual_mul_f32 v59, v62, v59// 000000003318: c8c6753e 3a3a773e
	v_dual_mul_f32 v60, v62, v60 :: v_dual_mul_f32 v61, v62, v61// 000000003320: c8c6793e 3c3c7b3e
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000003328: bf870214
	v_dual_mul_f32 v48, v48, v63 :: v_dual_mul_f32 v49, v49, v64// 00000000332c: c8c67f30 30308131
	v_dual_mul_f32 v50, v50, v56 :: v_dual_mul_f32 v51, v51, v57// 000000003334: c8c67132 32327333
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 00000000333c: bf870214
	v_dual_mul_f32 v52, v52, v58 :: v_dual_mul_f32 v53, v53, v59// 000000003340: c8c67534 34347735
	v_dual_mul_f32 v54, v54, v60 :: v_dual_mul_f32 v55, v55, v61// 000000003348: c8c67936 36367b37
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000003350: bf870214
	v_dual_add_f32 v2, v2, v48 :: v_dual_add_f32 v33, v33, v49 // 000000003354: c9086102 02206321
	v_dual_add_f32 v30, v30, v50 :: v_dual_add_f32 v27, v27, v51// 00000000335c: c908651e 1e1a671b
	s_delay_alu instid0(valu_dep_4) | instskip(next) | instid1(valu_dep_4)// 000000003364: bf870214
	v_dual_add_f32 v25, v25, v52 :: v_dual_add_f32 v24, v24, v53// 000000003368: c9086919 19186b18
	v_dual_add_f32 v23, v23, v54 :: v_dual_add_f32 v20, v20, v55// 000000003370: c9086d17 17146f14
	s_wait_alu depctr_sa_sdst(0)                               // 000000003378: bf88ff9e
	s_cbranch_vccnz 65399                                      // 00000000337c: bfa4ff77 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x165c>
	v_mul_lo_u32 v5, s23, v0                                   // 000000003380: d72c0005 02020017
	v_mul_lo_u32 v21, s22, v1                                  // 000000003388: d72c0015 02020216
	v_mad_co_u64_u32 v[0:1], null, s22, v0, 0                  // 000000003390: d6fe7c00 02020016
	v_mul_lo_u32 v26, s23, v8                                  // 000000003398: d72c001a 02021017
	v_mul_lo_u32 v28, s22, v9                                  // 0000000033a0: d72c001c 02021216
	v_mad_co_u64_u32 v[8:9], null, s22, v8, 0                  // 0000000033a8: d6fe7c08 02021016
	v_or_b32_e32 v31, 0x400000, v2                             // 0000000033b0: 383e04ff 00400000
	v_bfe_u32 v29, v33, 16, 1                                  // 0000000033b8: d610001d 02052121
	v_mul_lo_u32 v7, s22, v7                                   // 0000000033c0: d72c0007 02020e16
	v_mul_lo_u32 v11, s22, v11                                 // 0000000033c8: d72c000b 02021616
	v_add3_u32 v1, v1, v21, v5                                 // 0000000033d0: d6550001 04162b01
	v_bfe_u32 v5, v2, 16, 1                                    // 0000000033d8: d6100005 02052102
	v_lshlrev_b64_e32 v[21:22], 1, v[3:4]                      // 0000000033e0: 3e2a0681
	v_add3_u32 v9, v9, v28, v26                                // 0000000033e4: d6550009 046a3909
	v_mul_lo_u32 v28, s23, v6                                  // 0000000033ec: d72c001c 02020c17
	v_lshlrev_b64_e32 v[0:1], 1, v[0:1]                        // 0000000033f4: 3e000081
	v_add3_u32 v5, v5, v2, 0x7fff                              // 0000000033f8: d6550005 03fe0505 00007fff
	v_add3_u32 v29, v29, v33, 0x7fff                           // 000000003404: d655001d 03fe431d 00007fff
	v_lshlrev_b64_e32 v[8:9], 1, v[8:9]                        // 000000003410: 3e101081
	v_or_b32_e32 v26, 0x400000, v33                            // 000000003414: 383442ff 00400000
	v_mul_lo_u32 v13, s22, v13                                 // 00000000341c: d72c000d 02021a16
	v_add_co_u32 v0, vcc_lo, s18, v0                           // 000000003424: d7006a00 02020012
	s_wait_alu depctr_va_vcc(0)                                // 00000000342c: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s19, v1, vcc_lo              // 000000003430: d5207c01 01aa0213
	v_cmp_u_f32_e32 vcc_lo, v2, v2                             // 000000003438: 7c300502
	s_mov_b32 s0, -1                                           // 00000000343c: be8000c1
	s_wait_alu depctr_va_vcc(0)                                // 000000003440: bf88ff9d
	v_cndmask_b32_e32 v2, v5, v31, vcc_lo                      // 000000003444: 02043f05
	v_mad_co_u64_u32 v[5:6], null, s22, v6, 0                  // 000000003448: d6fe7c05 02020c16
	v_add_co_u32 v0, vcc_lo, v0, v21                           // 000000003450: d7006a00 02022b00
	s_wait_alu depctr_va_vcc(0)                                // 000000003458: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v1, v22, vcc_lo              // 00000000345c: d5207c01 01aa2d01
	v_cmp_u_f32_e32 vcc_lo, v33, v33                           // 000000003464: 7c304321
	s_delay_alu instid0(valu_dep_4)                            // 000000003468: bf870004
	v_add3_u32 v6, v6, v7, v28                                 // 00000000346c: d6550006 04720f06
	v_bfe_u32 v7, v30, 16, 1                                   // 000000003474: d6100007 0205211e
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000000347c: ee09407c 01000000 00000000
	s_wait_alu depctr_va_vcc(0)                                // 000000003488: bf88ff9d
	v_cndmask_b32_e32 v2, v29, v26, vcc_lo                     // 00000000348c: 0204351d
	v_add_co_u32 v0, vcc_lo, s18, v8                           // 000000003490: d7006a00 02021012
	s_wait_alu depctr_va_vcc(0)                                // 000000003498: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s19, v9, vcc_lo              // 00000000349c: d5207c01 01aa1213
	v_add3_u32 v9, v7, v30, 0x7fff                             // 0000000034a4: d6550009 03fe3d07 00007fff
	v_mul_lo_u32 v28, s23, v10                                 // 0000000034b0: d72c001c 02021417
	v_mad_co_u64_u32 v[7:8], null, s22, v10, 0                 // 0000000034b8: d6fe7c07 02021416
	v_add_co_u32 v0, vcc_lo, v0, v21                           // 0000000034c0: d7006a00 02022b00
	v_lshlrev_b64_e32 v[5:6], 1, v[5:6]                        // 0000000034c8: 3e0a0a81
	s_wait_alu depctr_va_vcc(0)                                // 0000000034cc: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v1, v22, vcc_lo              // 0000000034d0: d5207c01 01aa2d01
	v_or_b32_e32 v26, 0x400000, v30                            // 0000000034d8: 38343cff 00400000
	v_cmp_u_f32_e32 vcc_lo, v30, v30                           // 0000000034e0: 7c303d1e
	v_add3_u32 v8, v8, v11, v28                                // 0000000034e4: d6550008 04721708
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000000034ec: ee09407c 01000000 00000000
	v_mul_lo_u32 v11, s23, v12                                 // 0000000034f8: d72c000b 02021817
	v_or_b32_e32 v10, 0x400000, v27                            // 000000003500: 381436ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003508: bf88ff9d
	v_cndmask_b32_e32 v2, v9, v26, vcc_lo                      // 00000000350c: 02043509
	v_add_co_u32 v0, vcc_lo, s18, v5                           // 000000003510: d7006a00 02020a12
	v_bfe_u32 v5, v27, 16, 1                                   // 000000003518: d6100005 0205211b
	s_wait_alu depctr_va_vcc(0)                                // 000000003520: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s19, v6, vcc_lo              // 000000003524: d5207c01 01aa0c13
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 00000000352c: bf870193
	v_add_co_u32 v0, vcc_lo, v0, v21                           // 000000003530: d7006a00 02022b00
	v_add3_u32 v9, v5, v27, 0x7fff                             // 000000003538: d6550009 03fe3705 00007fff
	v_lshlrev_b64_e32 v[5:6], 1, v[7:8]                        // 000000003544: 3e0a0e81
	v_mad_co_u64_u32 v[7:8], null, s22, v12, 0                 // 000000003548: d6fe7c07 02021816
	s_wait_alu depctr_va_vcc(0)                                // 000000003550: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v1, v22, vcc_lo              // 000000003554: d5207c01 01aa2d01
	v_cmp_u_f32_e32 vcc_lo, v27, v27                           // 00000000355c: 7c30371b
	v_mul_lo_u32 v12, s22, v17                                 // 000000003560: d72c000c 02022216
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000003568: ee09407c 01000000 00000000
	s_wait_alu depctr_va_vcc(0)                                // 000000003574: bf88ff9d
	v_cndmask_b32_e32 v2, v9, v10, vcc_lo                      // 000000003578: 02041509
	v_add_co_u32 v0, vcc_lo, s18, v5                           // 00000000357c: d7006a00 02020a12
	v_add3_u32 v8, v8, v13, v11                                // 000000003584: d6550008 042e1b08
	v_bfe_u32 v5, v25, 16, 1                                   // 00000000358c: d6100005 02052119
	s_wait_alu depctr_va_vcc(0)                                // 000000003594: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s19, v6, vcc_lo              // 000000003598: d5207c01 01aa0c13
	v_add_co_u32 v0, vcc_lo, v0, v21                           // 0000000035a0: d7006a00 02022b00
	s_delay_alu instid0(valu_dep_3)                            // 0000000035a8: bf870003
	v_add3_u32 v9, v5, v25, 0x7fff                             // 0000000035ac: d6550009 03fe3305 00007fff
	v_lshlrev_b64_e32 v[5:6], 1, v[7:8]                        // 0000000035b8: 3e0a0e81
	v_mul_lo_u32 v11, s23, v16                                 // 0000000035bc: d72c000b 02022017
	v_mad_co_u64_u32 v[7:8], null, s22, v16, 0                 // 0000000035c4: d6fe7c07 02022016
	s_wait_alu depctr_va_vcc(0)                                // 0000000035cc: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v1, v22, vcc_lo              // 0000000035d0: d5207c01 01aa2d01
	v_or_b32_e32 v10, 0x400000, v25                            // 0000000035d8: 381432ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v25, v25                           // 0000000035e0: 7c303319
	v_mul_lo_u32 v16, s22, v19                                 // 0000000035e4: d72c0010 02022616
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000000035ec: ee09407c 01000000 00000000
	v_add3_u32 v8, v8, v12, v11                                // 0000000035f8: d6550008 042e1908
	s_wait_alu depctr_va_vcc(0)                                // 000000003600: bf88ff9d
	v_cndmask_b32_e32 v2, v9, v10, vcc_lo                      // 000000003604: 02041509
	v_add_co_u32 v0, vcc_lo, s18, v5                           // 000000003608: d7006a00 02020a12
	s_wait_alu depctr_va_vcc(0)                                // 000000003610: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s19, v6, vcc_lo              // 000000003614: d5207c01 01aa0c13
	v_bfe_u32 v9, v24, 16, 1                                   // 00000000361c: d6100009 02052118
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000003624: bf8701a3
	v_add_co_u32 v5, vcc_lo, v0, v21                           // 000000003628: d7006a05 02022b00
	s_wait_alu depctr_va_vcc(0)                                // 000000003630: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, v1, v22, vcc_lo              // 000000003634: d5207c06 01aa2d01
	v_lshlrev_b64_e32 v[0:1], 1, v[7:8]                        // 00000000363c: 3e000e81
	v_mul_lo_u32 v11, s23, v14                                 // 000000003640: d72c000b 02021c17
	v_mul_lo_u32 v12, s22, v15                                 // 000000003648: d72c000c 02021e16
	v_mad_co_u64_u32 v[7:8], null, s22, v14, 0                 // 000000003650: d6fe7c07 02021c16
	v_add3_u32 v9, v9, v24, 0x7fff                             // 000000003658: d6550009 03fe3109 00007fff
	v_or_b32_e32 v10, 0x400000, v24                            // 000000003664: 381430ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v24, v24                           // 00000000366c: 7c303118
	v_mul_lo_u32 v15, s23, v18                                 // 000000003670: d72c000f 02022417
	s_wait_alu depctr_va_vcc(0)                                // 000000003678: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 00000000367c: bf870003
	v_cndmask_b32_e32 v13, v9, v10, vcc_lo                     // 000000003680: 021a1509
	v_bfe_u32 v9, v23, 16, 1                                   // 000000003684: d6100009 02052117
	v_add_co_u32 v10, vcc_lo, s18, v0                          // 00000000368c: d7006a0a 02020012
	v_add3_u32 v8, v8, v12, v11                                // 000000003694: d6550008 042e1908
	s_wait_alu depctr_va_vcc(0)                                // 00000000369c: bf88ff9d
	v_add_co_ci_u32_e64 v14, null, s19, v1, vcc_lo             // 0000000036a0: d5207c0e 01aa0213
	v_mad_co_u64_u32 v[0:1], null, s22, v18, 0                 // 0000000036a8: d6fe7c00 02022416
	v_add3_u32 v11, v9, v23, 0x7fff                            // 0000000036b0: d655000b 03fe2f09 00007fff
	v_add_co_u32 v9, vcc_lo, v10, v21                          // 0000000036bc: d7006a09 02022b0a
	v_lshlrev_b64_e32 v[7:8], 1, v[7:8]                        // 0000000036c4: 3e0e0e81
	v_or_b32_e32 v12, 0x400000, v23                            // 0000000036c8: 38182eff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000036d0: bf88ff9d
	v_add_co_ci_u32_e64 v10, null, v14, v22, vcc_lo            // 0000000036d4: d5207c0a 01aa2d0e
	v_cmp_u_f32_e32 vcc_lo, v23, v23                           // 0000000036dc: 7c302f17
	v_add3_u32 v1, v1, v16, v15                                // 0000000036e0: d6550001 043e2101
	s_clause 0x1                                               // 0000000036e8: bf850001
	global_store_d16_hi_b16 v[5:6], v2, off                    // 0000000036ec: ee09407c 01000000 00000005
	global_store_d16_hi_b16 v[9:10], v13, off                  // 0000000036f8: ee09407c 06800000 00000009
	s_wait_alu depctr_va_vcc(0)                                // 000000003704: bf88ff9d
	v_cndmask_b32_e32 v11, v11, v12, vcc_lo                    // 000000003708: 0216190b
	v_add_co_u32 v7, vcc_lo, s18, v7                           // 00000000370c: d7006a07 02020e12
	s_wait_alu depctr_va_vcc(0)                                // 000000003714: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s19, v8, vcc_lo              // 000000003718: d5207c08 01aa1013
	v_lshlrev_b64_e32 v[0:1], 1, v[0:1]                        // 000000003720: 3e000081
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000003724: bf8701a3
	v_add_co_u32 v7, vcc_lo, v7, v21                           // 000000003728: d7006a07 02022b07
	s_wait_alu depctr_va_vcc(0)                                // 000000003730: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, v8, v22, vcc_lo              // 000000003734: d5207c08 01aa2d08
	s_delay_alu instid0(valu_dep_3)                            // 00000000373c: bf870003
	v_add_co_u32 v0, vcc_lo, s18, v0                           // 000000003740: d7006a00 02020012
	s_wait_alu depctr_va_vcc(0)                                // 000000003748: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s19, v1, vcc_lo              // 00000000374c: d5207c01 01aa0213
	global_store_d16_hi_b16 v[7:8], v11, off                   // 000000003754: ee09407c 05800000 00000007
	s_wait_alu depctr_sa_sdst(0)                               // 000000003760: bf88ff9e
	s_and_saveexec_b32 s1, s0                                  // 000000003764: be812000
	s_cbranch_execnz 1                                         // 000000003768: bfa60001 <tessera_rocm_scaled_matmul_3f5949f02e72ba89+0x1c70>
	s_endpgm                                                   // 00000000376c: bfb00000
	v_bfe_u32 v2, v20, 16, 1                                   // 000000003770: d6100002 02052114
	v_or_b32_e32 v5, 0x400000, v20                             // 000000003778: 380a28ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v20, v20                           // 000000003780: 7c302914
	s_delay_alu instid0(valu_dep_3) | instskip(skip_2) | instid1(valu_dep_2)// 000000003784: bf870133
	v_add3_u32 v6, v2, v20, 0x7fff                             // 000000003788: d6550006 03fe2902 00007fff
	v_lshlrev_b64_e32 v[2:3], 1, v[3:4]                        // 000000003794: 3e040681
	s_wait_alu depctr_va_vcc(0)                                // 000000003798: bf88ff9d
	v_cndmask_b32_e32 v4, v6, v5, vcc_lo                       // 00000000379c: 02080b06
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_3)// 0000000037a0: bf8701a2
	v_add_co_u32 v0, vcc_lo, v0, v2                            // 0000000037a4: d7006a00 02020500
	s_wait_alu depctr_va_vcc(0)                                // 0000000037ac: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v1, v3, vcc_lo               // 0000000037b0: d5207c01 01aa0701
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000000037b8: ee09407c 02000000 00000000
	s_endpgm                                                   // 0000000037c4: bfb00000
	s_code_end                                                 // 0000000037c8: bf9f0000
	s_code_end                                                 // 0000000037cc: bf9f0000
	s_code_end                                                 // 0000000037d0: bf9f0000
	s_code_end                                                 // 0000000037d4: bf9f0000
	s_code_end                                                 // 0000000037d8: bf9f0000
	s_code_end                                                 // 0000000037dc: bf9f0000
	s_code_end                                                 // 0000000037e0: bf9f0000
	s_code_end                                                 // 0000000037e4: bf9f0000
	s_code_end                                                 // 0000000037e8: bf9f0000
	s_code_end                                                 // 0000000037ec: bf9f0000
	s_code_end                                                 // 0000000037f0: bf9f0000
	s_code_end                                                 // 0000000037f4: bf9f0000
	s_code_end                                                 // 0000000037f8: bf9f0000
	s_code_end                                                 // 0000000037fc: bf9f0000
	s_code_end                                                 // 000000003800: bf9f0000
	s_code_end                                                 // 000000003804: bf9f0000
	s_code_end                                                 // 000000003808: bf9f0000
	s_code_end                                                 // 00000000380c: bf9f0000
	s_code_end                                                 // 000000003810: bf9f0000
	s_code_end                                                 // 000000003814: bf9f0000
	s_code_end                                                 // 000000003818: bf9f0000
	s_code_end                                                 // 00000000381c: bf9f0000
	s_code_end                                                 // 000000003820: bf9f0000
	s_code_end                                                 // 000000003824: bf9f0000
	s_code_end                                                 // 000000003828: bf9f0000
	s_code_end                                                 // 00000000382c: bf9f0000
	s_code_end                                                 // 000000003830: bf9f0000
	s_code_end                                                 // 000000003834: bf9f0000
	s_code_end                                                 // 000000003838: bf9f0000
	s_code_end                                                 // 00000000383c: bf9f0000
	s_code_end                                                 // 000000003840: bf9f0000
	s_code_end                                                 // 000000003844: bf9f0000
	s_code_end                                                 // 000000003848: bf9f0000
	s_code_end                                                 // 00000000384c: bf9f0000
	s_code_end                                                 // 000000003850: bf9f0000
	s_code_end                                                 // 000000003854: bf9f0000
	s_code_end                                                 // 000000003858: bf9f0000
	s_code_end                                                 // 00000000385c: bf9f0000
	s_code_end                                                 // 000000003860: bf9f0000
	s_code_end                                                 // 000000003864: bf9f0000
	s_code_end                                                 // 000000003868: bf9f0000
	s_code_end                                                 // 00000000386c: bf9f0000
	s_code_end                                                 // 000000003870: bf9f0000
	s_code_end                                                 // 000000003874: bf9f0000
	s_code_end                                                 // 000000003878: bf9f0000
	s_code_end                                                 // 00000000387c: bf9f0000
	s_code_end                                                 // 000000003880: bf9f0000
	s_code_end                                                 // 000000003884: bf9f0000
	s_code_end                                                 // 000000003888: bf9f0000
	s_code_end                                                 // 00000000388c: bf9f0000
	s_code_end                                                 // 000000003890: bf9f0000
	s_code_end                                                 // 000000003894: bf9f0000
	s_code_end                                                 // 000000003898: bf9f0000
	s_code_end                                                 // 00000000389c: bf9f0000
	s_code_end                                                 // 0000000038a0: bf9f0000
	s_code_end                                                 // 0000000038a4: bf9f0000
	s_code_end                                                 // 0000000038a8: bf9f0000
	s_code_end                                                 // 0000000038ac: bf9f0000
	s_code_end                                                 // 0000000038b0: bf9f0000
	s_code_end                                                 // 0000000038b4: bf9f0000
	s_code_end                                                 // 0000000038b8: bf9f0000
	s_code_end                                                 // 0000000038bc: bf9f0000
	s_code_end                                                 // 0000000038c0: bf9f0000
	s_code_end                                                 // 0000000038c4: bf9f0000
	s_code_end                                                 // 0000000038c8: bf9f0000
	s_code_end                                                 // 0000000038cc: bf9f0000
	s_code_end                                                 // 0000000038d0: bf9f0000
	s_code_end                                                 // 0000000038d4: bf9f0000
	s_code_end                                                 // 0000000038d8: bf9f0000
	s_code_end                                                 // 0000000038dc: bf9f0000
	s_code_end                                                 // 0000000038e0: bf9f0000
	s_code_end                                                 // 0000000038e4: bf9f0000
	s_code_end                                                 // 0000000038e8: bf9f0000
	s_code_end                                                 // 0000000038ec: bf9f0000
	s_code_end                                                 // 0000000038f0: bf9f0000
	s_code_end                                                 // 0000000038f4: bf9f0000
	s_code_end                                                 // 0000000038f8: bf9f0000
	s_code_end                                                 // 0000000038fc: bf9f0000
	s_code_end                                                 // 000000003900: bf9f0000
	s_code_end                                                 // 000000003904: bf9f0000
	s_code_end                                                 // 000000003908: bf9f0000
	s_code_end                                                 // 00000000390c: bf9f0000
	s_code_end                                                 // 000000003910: bf9f0000
	s_code_end                                                 // 000000003914: bf9f0000
	s_code_end                                                 // 000000003918: bf9f0000
	s_code_end                                                 // 00000000391c: bf9f0000
	s_code_end                                                 // 000000003920: bf9f0000
	s_code_end                                                 // 000000003924: bf9f0000
	s_code_end                                                 // 000000003928: bf9f0000
	s_code_end                                                 // 00000000392c: bf9f0000
	s_code_end                                                 // 000000003930: bf9f0000
	s_code_end                                                 // 000000003934: bf9f0000
	s_code_end                                                 // 000000003938: bf9f0000
	s_code_end                                                 // 00000000393c: bf9f0000
	s_code_end                                                 // 000000003940: bf9f0000
	s_code_end                                                 // 000000003944: bf9f0000
	s_code_end                                                 // 000000003948: bf9f0000
	s_code_end                                                 // 00000000394c: bf9f0000
	s_code_end                                                 // 000000003950: bf9f0000
	s_code_end                                                 // 000000003954: bf9f0000
	s_code_end                                                 // 000000003958: bf9f0000
	s_code_end                                                 // 00000000395c: bf9f0000
	s_code_end                                                 // 000000003960: bf9f0000
	s_code_end                                                 // 000000003964: bf9f0000
	s_code_end                                                 // 000000003968: bf9f0000
	s_code_end                                                 // 00000000396c: bf9f0000
	s_code_end                                                 // 000000003970: bf9f0000
	s_code_end                                                 // 000000003974: bf9f0000
	s_code_end                                                 // 000000003978: bf9f0000
	s_code_end                                                 // 00000000397c: bf9f0000
