from pathlib import Path
import ctypes as C, hashlib, json, os, re, types
from tessera import runtime as rt
from tessera.compiler.rocm_fp8_blockscale import BlockScaleShape, lower_blockscale, package_blockscale, blockscale_reference
from tests.device.rocm.test_fp8_blockscale_w8a8 import _with_schedule, _inputs, _launch
from tests._support import rocm_isa
from benchmarks.rocm.record_gfx1201_interleaved_compiler_formats import loaded_resources
import numpy as np
r=Path("/home/angstorms/scratch/jvp-schema-reconcile-20261011")
w=Path("/home/angstorms/scratch/rocm-main-refresh-20261017/kn-native-candidate")
assert rt._rocm_live_arch()=="gfx1201"
hip=rt._load_hip_for_launch()
def check(status):
 if status:raise RuntimeError(f"HIP {status}")
check(hip.hipSetDevice(0))
rows=[]
for nmacro in (64,):
 shape=BlockScaleShape(200,8192,1024,128,128,"kn")
 program=_with_schedule(lower_blockscale(shape),staging="lds",warps=8,macro=(128,nmacro))
 operands=_inputs(shape,exact=True,seed=412)
 want=blockscale_reference(*operands,scale_k=128,scale_n=128)
 row={"shape":[200,8192,1024],"macro":[128,nmacro],"arms":{}}
 for name,tool in (("control",w/"tessera-opt-control"),("quad",r/".build-schema-make/tools/tessera-opt/tessera-opt")):
  os.environ["TESSERA_OPT"]=str(tool)
  package=package_blockscale(program,blockscale_stage_k=128,blockscale_prefetch=0,blockscale_lds_pad_bytes=16)
  got=_launch(package,*operands,shape)
  np.testing.assert_array_equal(got,want)
  isa=rocm_isa.disassemble(package.image.payload,chip="gfx1201")
  (w/f"production-isa-{nmacro}-{name}.txt").write_text(isa)
  (w/f"production-image-{nmacro}-{name}.hsaco").write_bytes(package.image.payload)
  counts=rocm_isa.mnemonics(isa,r"[a-z_0-9]+")
  module,function=C.c_void_p(),C.c_void_p()
  blob=C.create_string_buffer(package.image.payload)
  check(hip.hipModuleLoadData(C.byref(module),blob))
  try:
   check(hip.hipModuleGetFunction(C.byref(function),module,package.descriptor.entry_symbol.encode()))
   resources=loaded_resources(hip,types.SimpleNamespace(function=function,block=(256,1,1)))
  finally:check(hip.hipModuleUnload(module))
  selected={key:counts[key] for key in ("ds_store_b8","ds_store_b32","ds_store_2addr_b32","ds_store_b128","ds_load_b8","ds_load_b64","ds_load_2addr_b64","ds_bpermute_b32","v_mov_b32_dpp","v_perm_b32","s_barrier_signal","s_barrier_wait","v_wmma_f32_16x16x16_fp8_fp8")}
  row["arms"][name]={"image_sha256":hashlib.sha256(package.image.payload).hexdigest(),"counts":selected,"resources":resources}
 rows.append(row)
 print(json.dumps(row),flush=True)
receipt={"architecture":rt._rocm_live_arch(),"control_source_sha256":json.loads((w/"source.json").read_text())["control_sha256"],"candidate_source_sha256":hashlib.sha256((r/"src/compiler/codegen/Tessera_ROCM_Backend/lib/Conversion/GenerateWMMAGemmKernel.cpp").read_bytes()).hexdigest(),"rows":rows,"scope":"one matched production-geometry GEMM pair with static instruction/live module resource attribution; no timings"}
(w/"production-isa-resources.json").write_text(json.dumps(receipt,indent=2)+"\n")
