
/tmp/tmp1tqun4nm.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

disassembly of section .text:

0000000000001a00 <tessera_nvfp4_expand_5bf64beae1fbaf3b>:
	s_mov_b32 s2, ttmp9                                        // 000000001a00: be820075
	s_ashr_i32 s3, ttmp9, 31                                   // 000000001a04: 86039f75
	s_delay_alu instid0(salu_cycle_1) | instskip(next) | instid1(salu_cycle_1)// 000000001a08: bf870499
	s_lshl_b64 s[4:5], s[2:3], 8                               // 000000001a0c: 84848802
	v_cmp_lt_u64_e64 s6, 0x7fff, s[4:5]                        // 000000001a10: d4590006 020008ff 00007fff
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000001a1c: 8b6a067e
	s_cbranch_vccnz 454                                        // 000000001a20: bfa401c6 <tessera_nvfp4_expand_5bf64beae1fbaf3b+0x73c>
	s_load_b64 s[6:7], s[0:1], 0x30                            // 000000001a24: f4002180 f8000030
	v_or_b32_e32 v1, s4, v0                                    // 000000001a2c: 38020004
	v_mov_b32_e32 v2, s5                                       // 000000001a30: 7e040205
	s_clause 0x1                                               // 000000001a34: bf850001
	s_load_b64 s[4:5], s[0:1], 0x58                            // 000000001a38: f4002100 f8000058
	s_load_b64 s[8:9], s[0:1], 0x80                            // 000000001a40: f4002200 f8000080
	s_and_b32 s3, s3, 0xffffff                                 // 000000001a48: 8b03ff03 00ffffff
	v_lshlrev_b32_e32 v0, 9, v0                                // 000000001a50: 30000089
	s_wait_kmcnt 0x0                                           // 000000001a54: bfc70000
	v_add_co_u32 v3, vcc_lo, s6, v1                            // 000000001a58: d7006a03 02020206
	s_delay_alu instid0(valu_dep_1)                            // 000000001a60: bf870001
	v_add_co_ci_u32_e64 v4, null, s7, v2, vcc_lo               // 000000001a64: d5207c04 01aa0407
	v_cmp_gt_u64_e64 s6, s[2:3], 63                            // 000000001a6c: d45c0006 02017e02
	global_load_d16_i8 v9, v[3:4], off                         // 000000001a74: ee07c07c 00000009 00000003
	s_and_b32 s6, s6, exec_lo                                  // 000000001a80: 8b067e06
	s_cselect_b32 s6, 1, 0                                     // 000000001a84: 98068081
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000001a88: 84828202
	s_wait_alu depctr_sa_sdst(0)                               // 000000001a8c: bf88ff9e
	s_lshl_b32 s6, s6, 3                                       // 000000001a90: 84068306
	s_load_b64 s[4:5], s[4:5], s6 offset:0x0                   // 000000001a94: f4002102 0c000000
	s_wait_loadcnt 0x0                                         // 000000001a9c: bfc00000
	v_lshrrev_b32_e32 v7, 3, v9                                // 000000001aa0: 320e1283
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000001aa4: bf870091
	v_dual_mov_b32 v7, 0 :: v_dual_and_b32 v10, 15, v7         // 000000001aa8: ca240080 070a0e8f
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000001ab0: 7c941480
	v_and_b32_e32 v3, 7, v9                                    // 000000001ab4: 36061287
	v_lshl_add_u32 v8, v10, 20, 0x3f500000                     // 000000001ab8: d6460008 03fd290a 3f500000
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000001ac4: bf870122
	v_or_b32_e32 v5, 8, v3                                     // 000000001ac8: 380a0688
	v_cvt_f64_u32_e32 v[3:4], v3                               // 000000001acc: 7e062d03
	v_cvt_f64_u32_e32 v[5:6], v5                               // 000000001ad0: 7e0a2d05
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000001ad4: bf870112
	v_ldexp_f64 v[3:4], v[3:4], -9                             // 000000001ad8: d72b0003 02019303
	v_mul_f64_e32 v[5:6], v[5:6], v[7:8]                       // 000000001ae0: 0c0a0f05
	s_wait_alu depctr_va_vcc(0)                                // 000000001ae4: bf88ff9d
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000001ae8: bf870121
	v_dual_cndmask_b32 v4, v6, v4 :: v_dual_cndmask_b32 v3, v5, v3// 000000001aec: ca520906 04020705
	v_cmp_gt_i16_e32 vcc_lo, 0, v9.l                           // 000000001af4: 7c681280
	v_xor_b32_e32 v5, 0x80000000, v4                           // 000000001af8: 3a0a08ff 80000000
	s_wait_alu depctr_va_vcc(0)                                // 000000001b00: bf88ff9d
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_1)// 000000001b04: bf8700a1
	v_cndmask_b32_e32 v4, v4, v5, vcc_lo                       // 000000001b08: 02080b04
	s_wait_kmcnt 0x0                                           // 000000001b0c: bfc70000
	v_mul_f64_e32 v[3:4], s[4:5], v[3:4]                       // 000000001b10: 0c060604
	s_clause 0x1                                               // 000000001b14: bf850001
	s_load_b64 s[4:5], s[0:1], 0xa8                            // 000000001b18: f4002100 f80000a8
	s_load_b64 s[0:1], s[0:1], 0x8                             // 000000001b20: f4002000 f8000008
	s_wait_kmcnt 0x0                                           // 000000001b28: bfc70000
	v_add_co_u32 v0, s4, s4, v0                                // 000000001b2c: d7000400 02020004
	s_wait_alu depctr_va_sdst(0)                               // 000000001b34: bf88f19f
	v_add_co_ci_u32_e64 v6, null, s5, 0, s4                    // 000000001b38: d5207c06 00110005
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000001b40: bf870122
	v_add_co_u32 v5, vcc_lo, v0, s2                            // 000000001b44: d7006a05 02000500
	s_wait_alu depctr_va_vcc(0)                                // 000000001b4c: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 000000001b50: d5207c06 01aa0c03
	v_cvt_f32_f64_e32 v7, v[3:4]                               // 000000001b58: 7e0e1f03
	v_lshlrev_b64_e32 v[3:4], 3, v[1:2]                        // 000000001b5c: 3e060283
	v_lshlrev_b64_e32 v[1:2], 4, v[1:2]                        // 000000001b60: 3e020284
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_3)// 000000001b64: bf8701a2
	v_add_co_u32 v3, vcc_lo, s0, v3                            // 000000001b68: d7006a03 02020600
	s_wait_alu depctr_va_vcc(0)                                // 000000001b70: bf88ff9d
	v_add_co_ci_u32_e64 v4, null, s1, v4, vcc_lo               // 000000001b74: d5207c04 01aa0801
	global_store_b32 v[5:6], v7, off                           // 000000001b7c: ee06807c 03800000 00000005
	global_load_u8 v0, v[3:4], off                             // 000000001b88: ee04007c 00000000 00000003
	s_wait_loadcnt 0x0                                         // 000000001b94: bfc00000
	v_bfe_u32 v5, v0, 4, 3                                     // 000000001b98: d6100005 020d0900
	v_and_b32_e32 v6, 7, v0                                    // 000000001ba0: 360c0087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001ba4: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001ba8: bf870223
	v_lshl_add_u32 v7, v5, 2, 48                               // 000000001bac: d6460007 02c10505
	v_cmp_ne_u32_e32 vcc_lo, 1, v5                             // 000000001bb4: 7c9a0a81
	v_lshl_add_u32 v8, v6, 2, 48                               // 000000001bb8: d6460008 02c10506
	s_wait_alu depctr_va_vcc(0)                                // 000000001bc0: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001bc4: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001bc8: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v6                             // 000000001bcc: 7c9a0c81
	s_wait_alu depctr_va_vcc(0)                                // 000000001bd0: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001bd4: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v5                             // 000000001bd8: 7c9a0a80
	s_wait_alu depctr_va_vcc(0)                                // 000000001bdc: bf88ff9d
	v_cndmask_b32_e32 v5, 0, v7, vcc_lo                        // 000000001be0: 020a0e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 000000001be4: 7c9a0c80
	s_delay_alu instid0(valu_dep_2)                            // 000000001be8: bf870002
	v_and_or_b32 v0, 0x80, v0, v5                              // 000000001bec: d6570000 041600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001bf8: bf88ff9d
	v_cndmask_b32_e32 v6, 0, v8, vcc_lo                        // 000000001bfc: 020c1080
	v_add_co_u32 v1, vcc_lo, s8, v1                            // 000000001c00: d7006a01 02020208
	s_wait_alu depctr_va_vcc(0)                                // 000000001c08: bf88ff9d
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 000000001c0c: d5207c02 01aa0409
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_2)// 000000001c14: bf870123
	v_and_or_b32 v5, 0x80, v9, v6                              // 000000001c18: d6570005 041a12ff 00000080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001c24: d7380000 02020088
	v_and_b16 v0.h, 0xfc, v5.l op_sel:[0,0,1]                  // 000000001c2c: d7624000 02020aff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001c38: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001c3c: d7630800 02020100
	global_store_b16 v[1:2], v0, off                           // 000000001c44: ee06407c 00000000 00000001
	global_load_u8 v0, v[3:4], off offset:1                    // 000000001c50: ee04007c 00000000 00000103
	s_wait_loadcnt 0x0                                         // 000000001c5c: bfc00000
	v_bfe_u32 v5, v0, 4, 3                                     // 000000001c60: d6100005 020d0900
	v_and_b32_e32 v6, 7, v0                                    // 000000001c68: 360c0087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001c6c: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001c70: bf870223
	v_lshl_add_u32 v7, v5, 2, 48                               // 000000001c74: d6460007 02c10505
	v_cmp_ne_u32_e32 vcc_lo, 1, v5                             // 000000001c7c: 7c9a0a81
	v_lshl_add_u32 v8, v6, 2, 48                               // 000000001c80: d6460008 02c10506
	s_wait_alu depctr_va_vcc(0)                                // 000000001c88: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001c8c: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001c90: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v6                             // 000000001c94: 7c9a0c81
	s_wait_alu depctr_va_vcc(0)                                // 000000001c98: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001c9c: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v5                             // 000000001ca0: 7c9a0a80
	s_wait_alu depctr_va_vcc(0)                                // 000000001ca4: bf88ff9d
	v_cndmask_b32_e32 v5, 0, v7, vcc_lo                        // 000000001ca8: 020a0e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 000000001cac: 7c9a0c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001cb0: bf870132
	v_and_or_b32 v0, 0x80, v0, v5                              // 000000001cb4: d6570000 041600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001cc0: bf88ff9d
	v_cndmask_b32_e32 v6, 0, v8, vcc_lo                        // 000000001cc4: 020c1080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001cc8: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001cd0: bf870092
	v_and_or_b32 v5, 0x80, v9, v6                              // 000000001cd4: d6570005 041a12ff 00000080
	v_and_b16 v0.h, 0xfc, v5.l op_sel:[0,0,1]                  // 000000001ce0: d7624000 02020aff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001cec: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001cf0: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:2                  // 000000001cf8: ee06407c 00000000 00000201
	global_load_u8 v0, v[3:4], off offset:2                    // 000000001d04: ee04007c 00000000 00000203
	s_wait_loadcnt 0x0                                         // 000000001d10: bfc00000
	v_bfe_u32 v5, v0, 4, 3                                     // 000000001d14: d6100005 020d0900
	v_and_b32_e32 v6, 7, v0                                    // 000000001d1c: 360c0087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001d20: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001d24: bf870223
	v_lshl_add_u32 v7, v5, 2, 48                               // 000000001d28: d6460007 02c10505
	v_cmp_ne_u32_e32 vcc_lo, 1, v5                             // 000000001d30: 7c9a0a81
	v_lshl_add_u32 v8, v6, 2, 48                               // 000000001d34: d6460008 02c10506
	s_wait_alu depctr_va_vcc(0)                                // 000000001d3c: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001d40: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001d44: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v6                             // 000000001d48: 7c9a0c81
	s_wait_alu depctr_va_vcc(0)                                // 000000001d4c: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001d50: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v5                             // 000000001d54: 7c9a0a80
	s_wait_alu depctr_va_vcc(0)                                // 000000001d58: bf88ff9d
	v_cndmask_b32_e32 v5, 0, v7, vcc_lo                        // 000000001d5c: 020a0e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 000000001d60: 7c9a0c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001d64: bf870132
	v_and_or_b32 v0, 0x80, v0, v5                              // 000000001d68: d6570000 041600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001d74: bf88ff9d
	v_cndmask_b32_e32 v6, 0, v8, vcc_lo                        // 000000001d78: 020c1080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001d7c: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001d84: bf870092
	v_and_or_b32 v5, 0x80, v9, v6                              // 000000001d88: d6570005 041a12ff 00000080
	v_and_b16 v0.h, 0xfc, v5.l op_sel:[0,0,1]                  // 000000001d94: d7624000 02020aff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001da0: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001da4: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:4                  // 000000001dac: ee06407c 00000000 00000401
	global_load_u8 v0, v[3:4], off offset:3                    // 000000001db8: ee04007c 00000000 00000303
	s_wait_loadcnt 0x0                                         // 000000001dc4: bfc00000
	v_bfe_u32 v5, v0, 4, 3                                     // 000000001dc8: d6100005 020d0900
	v_and_b32_e32 v6, 7, v0                                    // 000000001dd0: 360c0087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001dd4: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001dd8: bf870223
	v_lshl_add_u32 v7, v5, 2, 48                               // 000000001ddc: d6460007 02c10505
	v_cmp_ne_u32_e32 vcc_lo, 1, v5                             // 000000001de4: 7c9a0a81
	v_lshl_add_u32 v8, v6, 2, 48                               // 000000001de8: d6460008 02c10506
	s_wait_alu depctr_va_vcc(0)                                // 000000001df0: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001df4: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001df8: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v6                             // 000000001dfc: 7c9a0c81
	s_wait_alu depctr_va_vcc(0)                                // 000000001e00: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001e04: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v5                             // 000000001e08: 7c9a0a80
	s_wait_alu depctr_va_vcc(0)                                // 000000001e0c: bf88ff9d
	v_cndmask_b32_e32 v5, 0, v7, vcc_lo                        // 000000001e10: 020a0e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 000000001e14: 7c9a0c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001e18: bf870132
	v_and_or_b32 v0, 0x80, v0, v5                              // 000000001e1c: d6570000 041600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001e28: bf88ff9d
	v_cndmask_b32_e32 v6, 0, v8, vcc_lo                        // 000000001e2c: 020c1080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001e30: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001e38: bf870092
	v_and_or_b32 v5, 0x80, v9, v6                              // 000000001e3c: d6570005 041a12ff 00000080
	v_and_b16 v0.h, 0xfc, v5.l op_sel:[0,0,1]                  // 000000001e48: d7624000 02020aff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001e54: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001e58: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:6                  // 000000001e60: ee06407c 00000000 00000601
	global_load_u8 v0, v[3:4], off offset:4                    // 000000001e6c: ee04007c 00000000 00000403
	s_wait_loadcnt 0x0                                         // 000000001e78: bfc00000
	v_bfe_u32 v5, v0, 4, 3                                     // 000000001e7c: d6100005 020d0900
	v_and_b32_e32 v6, 7, v0                                    // 000000001e84: 360c0087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001e88: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001e8c: bf870223
	v_lshl_add_u32 v7, v5, 2, 48                               // 000000001e90: d6460007 02c10505
	v_cmp_ne_u32_e32 vcc_lo, 1, v5                             // 000000001e98: 7c9a0a81
	v_lshl_add_u32 v8, v6, 2, 48                               // 000000001e9c: d6460008 02c10506
	s_wait_alu depctr_va_vcc(0)                                // 000000001ea4: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001ea8: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001eac: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v6                             // 000000001eb0: 7c9a0c81
	s_wait_alu depctr_va_vcc(0)                                // 000000001eb4: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001eb8: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v5                             // 000000001ebc: 7c9a0a80
	s_wait_alu depctr_va_vcc(0)                                // 000000001ec0: bf88ff9d
	v_cndmask_b32_e32 v5, 0, v7, vcc_lo                        // 000000001ec4: 020a0e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 000000001ec8: 7c9a0c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001ecc: bf870132
	v_and_or_b32 v0, 0x80, v0, v5                              // 000000001ed0: d6570000 041600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001edc: bf88ff9d
	v_cndmask_b32_e32 v6, 0, v8, vcc_lo                        // 000000001ee0: 020c1080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001ee4: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001eec: bf870092
	v_and_or_b32 v5, 0x80, v9, v6                              // 000000001ef0: d6570005 041a12ff 00000080
	v_and_b16 v0.h, 0xfc, v5.l op_sel:[0,0,1]                  // 000000001efc: d7624000 02020aff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001f08: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001f0c: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:8                  // 000000001f14: ee06407c 00000000 00000801
	global_load_u8 v0, v[3:4], off offset:5                    // 000000001f20: ee04007c 00000000 00000503
	s_wait_loadcnt 0x0                                         // 000000001f2c: bfc00000
	v_bfe_u32 v5, v0, 4, 3                                     // 000000001f30: d6100005 020d0900
	v_and_b32_e32 v6, 7, v0                                    // 000000001f38: 360c0087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001f3c: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001f40: bf870223
	v_lshl_add_u32 v7, v5, 2, 48                               // 000000001f44: d6460007 02c10505
	v_cmp_ne_u32_e32 vcc_lo, 1, v5                             // 000000001f4c: 7c9a0a81
	v_lshl_add_u32 v8, v6, 2, 48                               // 000000001f50: d6460008 02c10506
	s_wait_alu depctr_va_vcc(0)                                // 000000001f58: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001f5c: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001f60: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v6                             // 000000001f64: 7c9a0c81
	s_wait_alu depctr_va_vcc(0)                                // 000000001f68: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001f6c: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v5                             // 000000001f70: 7c9a0a80
	s_wait_alu depctr_va_vcc(0)                                // 000000001f74: bf88ff9d
	v_cndmask_b32_e32 v5, 0, v7, vcc_lo                        // 000000001f78: 020a0e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 000000001f7c: 7c9a0c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001f80: bf870132
	v_and_or_b32 v0, 0x80, v0, v5                              // 000000001f84: d6570000 041600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001f90: bf88ff9d
	v_cndmask_b32_e32 v6, 0, v8, vcc_lo                        // 000000001f94: 020c1080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001f98: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001fa0: bf870092
	v_and_or_b32 v5, 0x80, v9, v6                              // 000000001fa4: d6570005 041a12ff 00000080
	v_and_b16 v0.h, 0xfc, v5.l op_sel:[0,0,1]                  // 000000001fb0: d7624000 02020aff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001fbc: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001fc0: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:10                 // 000000001fc8: ee06407c 00000000 00000a01
	global_load_u8 v0, v[3:4], off offset:6                    // 000000001fd4: ee04007c 00000000 00000603
	s_wait_loadcnt 0x0                                         // 000000001fe0: bfc00000
	v_bfe_u32 v5, v0, 4, 3                                     // 000000001fe4: d6100005 020d0900
	v_and_b32_e32 v6, 7, v0                                    // 000000001fec: 360c0087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001ff0: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001ff4: bf870223
	v_lshl_add_u32 v7, v5, 2, 48                               // 000000001ff8: d6460007 02c10505
	v_cmp_ne_u32_e32 vcc_lo, 1, v5                             // 000000002000: 7c9a0a81
	v_lshl_add_u32 v8, v6, 2, 48                               // 000000002004: d6460008 02c10506
	s_wait_alu depctr_va_vcc(0)                                // 00000000200c: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000002010: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000002014: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v6                             // 000000002018: 7c9a0c81
	s_wait_alu depctr_va_vcc(0)                                // 00000000201c: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000002020: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v5                             // 000000002024: 7c9a0a80
	s_wait_alu depctr_va_vcc(0)                                // 000000002028: bf88ff9d
	v_cndmask_b32_e32 v5, 0, v7, vcc_lo                        // 00000000202c: 020a0e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 000000002030: 7c9a0c80
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000002034: bf870132
	v_and_or_b32 v0, 0x80, v0, v5                              // 000000002038: d6570000 041600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000002044: bf88ff9d
	v_cndmask_b32_e32 v6, 0, v8, vcc_lo                        // 000000002048: 020c1080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 00000000204c: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000002054: bf870092
	v_and_or_b32 v5, 0x80, v9, v6                              // 000000002058: d6570005 041a12ff 00000080
	v_and_b16 v0.h, 0xfc, v5.l op_sel:[0,0,1]                  // 000000002064: d7624000 02020aff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000002070: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000002074: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:12                 // 00000000207c: ee06407c 00000000 00000c01
	global_load_u8 v0, v[3:4], off offset:7                    // 000000002088: ee04007c 00000000 00000703
	s_wait_loadcnt 0x0                                         // 000000002094: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000002098: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 0000000020a0: 36080087
	v_lshlrev_b32_e32 v7, 4, v0                                // 0000000020a4: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 0000000020a8: bf870223
	v_lshl_add_u32 v5, v3, 2, 48                               // 0000000020ac: d6460005 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 0000000020b4: 7c9a0681
	v_lshl_add_u32 v6, v4, 2, 48                               // 0000000020b8: d6460006 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 0000000020c0: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 0000000020c4: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 0000000020c8: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 0000000020cc: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 0000000020d0: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 0000000020d4: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 0000000020d8: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 0000000020dc: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v5, vcc_lo                        // 0000000020e0: 02060a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 0000000020e4: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 0000000020e8: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 0000000020ec: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 0000000020f8: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v6, vcc_lo                        // 0000000020fc: 02080c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000002100: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000002108: bf870092
	v_and_or_b32 v3, 0x80, v7, v4                              // 00000000210c: d6570003 04120eff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000002118: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000002124: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000002128: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:14                 // 000000002130: ee06407c 00000000 00000e01
	s_endpgm                                                   // 00000000213c: bfb00000
	s_code_end                                                 // 000000002140: bf9f0000
	s_code_end                                                 // 000000002144: bf9f0000
	s_code_end                                                 // 000000002148: bf9f0000
	s_code_end                                                 // 00000000214c: bf9f0000
	s_code_end                                                 // 000000002150: bf9f0000
	s_code_end                                                 // 000000002154: bf9f0000
	s_code_end                                                 // 000000002158: bf9f0000
	s_code_end                                                 // 00000000215c: bf9f0000
	s_code_end                                                 // 000000002160: bf9f0000
	s_code_end                                                 // 000000002164: bf9f0000
	s_code_end                                                 // 000000002168: bf9f0000
	s_code_end                                                 // 00000000216c: bf9f0000
	s_code_end                                                 // 000000002170: bf9f0000
	s_code_end                                                 // 000000002174: bf9f0000
	s_code_end                                                 // 000000002178: bf9f0000
	s_code_end                                                 // 00000000217c: bf9f0000
	s_code_end                                                 // 000000002180: bf9f0000
	s_code_end                                                 // 000000002184: bf9f0000
	s_code_end                                                 // 000000002188: bf9f0000
	s_code_end                                                 // 00000000218c: bf9f0000
	s_code_end                                                 // 000000002190: bf9f0000
	s_code_end                                                 // 000000002194: bf9f0000
	s_code_end                                                 // 000000002198: bf9f0000
	s_code_end                                                 // 00000000219c: bf9f0000
	s_code_end                                                 // 0000000021a0: bf9f0000
	s_code_end                                                 // 0000000021a4: bf9f0000
	s_code_end                                                 // 0000000021a8: bf9f0000
	s_code_end                                                 // 0000000021ac: bf9f0000
	s_code_end                                                 // 0000000021b0: bf9f0000
	s_code_end                                                 // 0000000021b4: bf9f0000
	s_code_end                                                 // 0000000021b8: bf9f0000
	s_code_end                                                 // 0000000021bc: bf9f0000
	s_code_end                                                 // 0000000021c0: bf9f0000
	s_code_end                                                 // 0000000021c4: bf9f0000
	s_code_end                                                 // 0000000021c8: bf9f0000
	s_code_end                                                 // 0000000021cc: bf9f0000
	s_code_end                                                 // 0000000021d0: bf9f0000
	s_code_end                                                 // 0000000021d4: bf9f0000
	s_code_end                                                 // 0000000021d8: bf9f0000
	s_code_end                                                 // 0000000021dc: bf9f0000
	s_code_end                                                 // 0000000021e0: bf9f0000
	s_code_end                                                 // 0000000021e4: bf9f0000
	s_code_end                                                 // 0000000021e8: bf9f0000
	s_code_end                                                 // 0000000021ec: bf9f0000
	s_code_end                                                 // 0000000021f0: bf9f0000
	s_code_end                                                 // 0000000021f4: bf9f0000
	s_code_end                                                 // 0000000021f8: bf9f0000
	s_code_end                                                 // 0000000021fc: bf9f0000
	s_code_end                                                 // 000000002200: bf9f0000
	s_code_end                                                 // 000000002204: bf9f0000
	s_code_end                                                 // 000000002208: bf9f0000
	s_code_end                                                 // 00000000220c: bf9f0000
	s_code_end                                                 // 000000002210: bf9f0000
	s_code_end                                                 // 000000002214: bf9f0000
	s_code_end                                                 // 000000002218: bf9f0000
	s_code_end                                                 // 00000000221c: bf9f0000
	s_code_end                                                 // 000000002220: bf9f0000
	s_code_end                                                 // 000000002224: bf9f0000
	s_code_end                                                 // 000000002228: bf9f0000
	s_code_end                                                 // 00000000222c: bf9f0000
	s_code_end                                                 // 000000002230: bf9f0000
	s_code_end                                                 // 000000002234: bf9f0000
	s_code_end                                                 // 000000002238: bf9f0000
	s_code_end                                                 // 00000000223c: bf9f0000
	s_code_end                                                 // 000000002240: bf9f0000
	s_code_end                                                 // 000000002244: bf9f0000
	s_code_end                                                 // 000000002248: bf9f0000
	s_code_end                                                 // 00000000224c: bf9f0000
	s_code_end                                                 // 000000002250: bf9f0000
	s_code_end                                                 // 000000002254: bf9f0000
	s_code_end                                                 // 000000002258: bf9f0000
	s_code_end                                                 // 00000000225c: bf9f0000
	s_code_end                                                 // 000000002260: bf9f0000
	s_code_end                                                 // 000000002264: bf9f0000
	s_code_end                                                 // 000000002268: bf9f0000
	s_code_end                                                 // 00000000226c: bf9f0000
	s_code_end                                                 // 000000002270: bf9f0000
	s_code_end                                                 // 000000002274: bf9f0000
	s_code_end                                                 // 000000002278: bf9f0000
	s_code_end                                                 // 00000000227c: bf9f0000
	s_code_end                                                 // 000000002280: bf9f0000
	s_code_end                                                 // 000000002284: bf9f0000
	s_code_end                                                 // 000000002288: bf9f0000
	s_code_end                                                 // 00000000228c: bf9f0000
	s_code_end                                                 // 000000002290: bf9f0000
	s_code_end                                                 // 000000002294: bf9f0000
	s_code_end                                                 // 000000002298: bf9f0000
	s_code_end                                                 // 00000000229c: bf9f0000
	s_code_end                                                 // 0000000022a0: bf9f0000
	s_code_end                                                 // 0000000022a4: bf9f0000
	s_code_end                                                 // 0000000022a8: bf9f0000
	s_code_end                                                 // 0000000022ac: bf9f0000
	s_code_end                                                 // 0000000022b0: bf9f0000
	s_code_end                                                 // 0000000022b4: bf9f0000
	s_code_end                                                 // 0000000022b8: bf9f0000
	s_code_end                                                 // 0000000022bc: bf9f0000
	s_code_end                                                 // 0000000022c0: bf9f0000
	s_code_end                                                 // 0000000022c4: bf9f0000
	s_code_end                                                 // 0000000022c8: bf9f0000
	s_code_end                                                 // 0000000022cc: bf9f0000
	s_code_end                                                 // 0000000022d0: bf9f0000
	s_code_end                                                 // 0000000022d4: bf9f0000
	s_code_end                                                 // 0000000022d8: bf9f0000
	s_code_end                                                 // 0000000022dc: bf9f0000
	s_code_end                                                 // 0000000022e0: bf9f0000
	s_code_end                                                 // 0000000022e4: bf9f0000
	s_code_end                                                 // 0000000022e8: bf9f0000
	s_code_end                                                 // 0000000022ec: bf9f0000
	s_code_end                                                 // 0000000022f0: bf9f0000
	s_code_end                                                 // 0000000022f4: bf9f0000
	s_code_end                                                 // 0000000022f8: bf9f0000
	s_code_end                                                 // 0000000022fc: bf9f0000
