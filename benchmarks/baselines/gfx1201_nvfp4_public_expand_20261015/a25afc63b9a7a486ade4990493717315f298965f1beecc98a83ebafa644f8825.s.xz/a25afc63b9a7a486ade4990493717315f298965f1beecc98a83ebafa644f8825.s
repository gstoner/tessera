
/tmp/tmp028x780h.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

disassembly of section .text:

0000000000001a00 <tessera_nvfp4_expand_578410a9f98231fc>:
	s_mov_b32 s2, ttmp9                                        // 000000001a00: be820075
	s_ashr_i32 s3, ttmp9, 31                                   // 000000001a04: 86039f75
	s_delay_alu instid0(salu_cycle_1) | instskip(next) | instid1(salu_cycle_1)// 000000001a08: bf870499
	s_lshl_b64 s[4:5], s[2:3], 8                               // 000000001a0c: 84848802
	v_cmp_lt_u64_e64 s6, 0x5fffff, s[4:5]                      // 000000001a10: d4590006 020008ff 005fffff
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000001a1c: 8b6a067e
	s_cbranch_vccnz 452                                        // 000000001a20: bfa401c4 <tessera_nvfp4_expand_578410a9f98231fc+0x734>
	s_load_b64 s[6:7], s[0:1], 0x30                            // 000000001a24: f4002180 f8000030
	v_or_b32_e32 v1, s4, v0                                    // 000000001a2c: 38020004
	v_mov_b32_e32 v2, s5                                       // 000000001a30: 7e040205
	s_clause 0x1                                               // 000000001a34: bf850001
	s_load_b64 s[4:5], s[0:1], 0x58                            // 000000001a38: f4002100 f8000058
	s_load_b64 s[8:9], s[0:1], 0x80                            // 000000001a40: f4002200 f8000080
	s_and_b32 s3, s3, 0xffffff                                 // 000000001a48: 8b03ff03 00ffffff
	s_wait_kmcnt 0x0                                           // 000000001a50: bfc70000
	v_add_co_u32 v3, vcc_lo, s6, v1                            // 000000001a54: d7006a03 02020206
	s_delay_alu instid0(valu_dep_1)                            // 000000001a5c: bf870001
	v_add_co_ci_u32_e64 v4, null, s7, v2, vcc_lo               // 000000001a60: d5207c04 01aa0407
	v_cmp_lt_u64_e64 s6, 0x2fff, s[2:3]                        // 000000001a68: d4590006 020004ff 00002fff
	global_load_d16_i8 v9, v[3:4], off                         // 000000001a74: ee07c07c 00000009 00000003
	s_and_b32 s6, s6, exec_lo                                  // 000000001a80: 8b067e06
	s_cselect_b32 s6, 1, 0                                     // 000000001a84: 98068081
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000001a88: 84828202
	s_wait_alu depctr_sa_sdst(0)                               // 000000001a8c: bf88ff9e
	s_lshl_b32 s6, s6, 3                                       // 000000001a90: 84068306
	s_load_b64 s[4:5], s[4:5], s6 offset:0x0                   // 000000001a94: f4002102 0c000000
	s_wait_loadcnt 0x0                                         // 000000001a9c: bfc00000
	v_lshrrev_b32_e32 v7, 3, v9                                // 000000001aa0: 320e1283
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000001aa4: bf870091
	v_dual_mov_b32 v7, 0 :: v_dual_and_b32 v10, 15, v7         // 000000001aa8: ca240080 070a0e8f
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000001ab0: 7c941480
	v_and_b32_e32 v3, 7, v9                                    // 000000001ab4: 36061287
	v_lshl_add_u32 v8, v10, 20, 0x3f500000                     // 000000001ab8: d6460008 03fd290a 3f500000
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000001ac4: bf870122
	v_or_b32_e32 v5, 8, v3                                     // 000000001ac8: 380a0688
	v_cvt_f64_u32_e32 v[3:4], v3                               // 000000001acc: 7e062d03
	v_cvt_f64_u32_e32 v[5:6], v5                               // 000000001ad0: 7e0a2d05
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000001ad4: bf870112
	v_ldexp_f64 v[3:4], v[3:4], -9                             // 000000001ad8: d72b0003 02019303
	v_mul_f64_e32 v[5:6], v[5:6], v[7:8]                       // 000000001ae0: 0c0a0f05
	s_wait_alu depctr_va_vcc(0)                                // 000000001ae4: bf88ff9d
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000001ae8: bf870121
	v_dual_cndmask_b32 v4, v6, v4 :: v_dual_cndmask_b32 v3, v5, v3// 000000001aec: ca520906 04020705
	v_cmp_gt_i16_e32 vcc_lo, 0, v9.l                           // 000000001af4: 7c681280
	v_xor_b32_e32 v5, 0x80000000, v4                           // 000000001af8: 3a0a08ff 80000000
	s_wait_alu depctr_va_vcc(0)                                // 000000001b00: bf88ff9d
	s_delay_alu instid0(valu_dep_1) | instskip(skip_3) | instid1(valu_dep_3)// 000000001b04: bf8701c1
	v_cndmask_b32_e32 v4, v4, v5, vcc_lo                       // 000000001b08: 02080b04
	v_lshlrev_b64_e32 v[5:6], 3, v[1:2]                        // 000000001b0c: 3e0a0283
	v_lshlrev_b64_e32 v[1:2], 4, v[1:2]                        // 000000001b10: 3e020284
	s_wait_kmcnt 0x0                                           // 000000001b14: bfc70000
	v_mul_f64_e32 v[3:4], s[4:5], v[3:4]                       // 000000001b18: 0c060604
	s_clause 0x1                                               // 000000001b1c: bf850001
	s_load_b64 s[4:5], s[0:1], 0xa8                            // 000000001b20: f4002100 f80000a8
	s_load_b64 s[0:1], s[0:1], 0x8                             // 000000001b28: f4002000 f8000008
	s_delay_alu instid0(valu_dep_1) | instskip(skip_2) | instid1(valu_dep_1)// 000000001b30: bf8700b1
	v_cvt_f32_f64_e32 v7, v[3:4]                               // 000000001b34: 7e0e1f03
	s_wait_kmcnt 0x0                                           // 000000001b38: bfc70000
	v_mad_co_u64_u32 v[3:4], null, 0x18000, v0, s[4:5]         // 000000001b3c: d6fe7c03 001200ff 00018000
	v_add_co_u32 v3, vcc_lo, v3, s2                            // 000000001b48: d7006a03 02000503
	s_wait_alu depctr_va_vcc(0)                                // 000000001b50: bf88ff9d
	s_delay_alu instid0(valu_dep_2)                            // 000000001b54: bf870002
	v_add_co_ci_u32_e64 v4, null, s3, v4, vcc_lo               // 000000001b58: d5207c04 01aa0803
	v_add_co_u32 v5, vcc_lo, s0, v5                            // 000000001b60: d7006a05 02020a00
	s_wait_alu depctr_va_vcc(0)                                // 000000001b68: bf88ff9d
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000001b6c: d5207c06 01aa0c01
	global_store_b32 v[3:4], v7, off                           // 000000001b74: ee06807c 03800000 00000003
	global_load_u8 v0, v[5:6], off                             // 000000001b80: ee04007c 00000000 00000005
	s_wait_loadcnt 0x0                                         // 000000001b8c: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000001b90: d6100003 020d0900
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001b98: 30120084
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001b9c: bf870132
	v_lshl_add_u32 v7, v3, 2, 48                               // 000000001ba0: d6460007 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001ba8: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000001bac: bf88ff9d
	v_dual_cndmask_b32 v7, 48, v7 :: v_dual_and_b32 v4, 7, v0  // 000000001bb0: ca640eb0 07040087
	s_delay_alu instid0(valu_dep_1) | instskip(skip_2) | instid1(valu_dep_2)// 000000001bb8: bf870131
	v_lshl_add_u32 v8, v4, 2, 48                               // 000000001bbc: d6460008 02c10504
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 000000001bc4: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 000000001bc8: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001bcc: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001bd0: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000001bd4: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v7, vcc_lo                        // 000000001bd8: 02060e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 000000001bdc: 7c9a0880
	s_delay_alu instid0(valu_dep_2)                            // 000000001be0: bf870002
	v_and_or_b32 v0, 0x80, v0, v3                              // 000000001be4: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001bf0: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v8, vcc_lo                        // 000000001bf4: 02081080
	v_add_co_u32 v1, vcc_lo, s8, v1                            // 000000001bf8: d7006a01 02020208
	s_wait_alu depctr_va_vcc(0)                                // 000000001c00: bf88ff9d
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 000000001c04: d5207c02 01aa0409
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_2)// 000000001c0c: bf870123
	v_and_or_b32 v3, 0x80, v9, v4                              // 000000001c10: d6570003 041212ff 00000080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001c1c: d7380000 02020088
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000001c24: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001c30: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001c34: d7630800 02020100
	global_store_b16 v[1:2], v0, off                           // 000000001c3c: ee06407c 00000000 00000001
	global_load_u8 v0, v[5:6], off offset:1                    // 000000001c48: ee04007c 00000000 00000105
	s_wait_loadcnt 0x0                                         // 000000001c54: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000001c58: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 000000001c60: 36080087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001c64: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001c68: bf870223
	v_lshl_add_u32 v7, v3, 2, 48                               // 000000001c6c: d6460007 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001c74: 7c9a0681
	v_lshl_add_u32 v8, v4, 2, 48                               // 000000001c78: d6460008 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 000000001c80: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001c84: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001c88: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 000000001c8c: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 000000001c90: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001c94: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001c98: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000001c9c: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v7, vcc_lo                        // 000000001ca0: 02060e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 000000001ca4: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001ca8: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 000000001cac: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001cb8: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v8, vcc_lo                        // 000000001cbc: 02081080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001cc0: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001cc8: bf870092
	v_and_or_b32 v3, 0x80, v9, v4                              // 000000001ccc: d6570003 041212ff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000001cd8: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001ce4: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001ce8: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:2                  // 000000001cf0: ee06407c 00000000 00000201
	global_load_u8 v0, v[5:6], off offset:2                    // 000000001cfc: ee04007c 00000000 00000205
	s_wait_loadcnt 0x0                                         // 000000001d08: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000001d0c: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 000000001d14: 36080087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001d18: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001d1c: bf870223
	v_lshl_add_u32 v7, v3, 2, 48                               // 000000001d20: d6460007 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001d28: 7c9a0681
	v_lshl_add_u32 v8, v4, 2, 48                               // 000000001d2c: d6460008 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 000000001d34: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001d38: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001d3c: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 000000001d40: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 000000001d44: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001d48: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001d4c: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000001d50: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v7, vcc_lo                        // 000000001d54: 02060e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 000000001d58: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001d5c: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 000000001d60: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001d6c: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v8, vcc_lo                        // 000000001d70: 02081080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001d74: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001d7c: bf870092
	v_and_or_b32 v3, 0x80, v9, v4                              // 000000001d80: d6570003 041212ff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000001d8c: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001d98: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001d9c: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:4                  // 000000001da4: ee06407c 00000000 00000401
	global_load_u8 v0, v[5:6], off offset:3                    // 000000001db0: ee04007c 00000000 00000305
	s_wait_loadcnt 0x0                                         // 000000001dbc: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000001dc0: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 000000001dc8: 36080087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001dcc: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001dd0: bf870223
	v_lshl_add_u32 v7, v3, 2, 48                               // 000000001dd4: d6460007 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001ddc: 7c9a0681
	v_lshl_add_u32 v8, v4, 2, 48                               // 000000001de0: d6460008 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 000000001de8: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001dec: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001df0: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 000000001df4: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 000000001df8: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001dfc: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001e00: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000001e04: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v7, vcc_lo                        // 000000001e08: 02060e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 000000001e0c: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001e10: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 000000001e14: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001e20: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v8, vcc_lo                        // 000000001e24: 02081080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001e28: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001e30: bf870092
	v_and_or_b32 v3, 0x80, v9, v4                              // 000000001e34: d6570003 041212ff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000001e40: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001e4c: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001e50: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:6                  // 000000001e58: ee06407c 00000000 00000601
	global_load_u8 v0, v[5:6], off offset:4                    // 000000001e64: ee04007c 00000000 00000405
	s_wait_loadcnt 0x0                                         // 000000001e70: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000001e74: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 000000001e7c: 36080087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001e80: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001e84: bf870223
	v_lshl_add_u32 v7, v3, 2, 48                               // 000000001e88: d6460007 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001e90: 7c9a0681
	v_lshl_add_u32 v8, v4, 2, 48                               // 000000001e94: d6460008 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 000000001e9c: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001ea0: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001ea4: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 000000001ea8: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 000000001eac: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001eb0: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001eb4: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000001eb8: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v7, vcc_lo                        // 000000001ebc: 02060e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 000000001ec0: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001ec4: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 000000001ec8: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001ed4: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v8, vcc_lo                        // 000000001ed8: 02081080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001edc: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001ee4: bf870092
	v_and_or_b32 v3, 0x80, v9, v4                              // 000000001ee8: d6570003 041212ff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000001ef4: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001f00: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001f04: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:8                  // 000000001f0c: ee06407c 00000000 00000801
	global_load_u8 v0, v[5:6], off offset:5                    // 000000001f18: ee04007c 00000000 00000505
	s_wait_loadcnt 0x0                                         // 000000001f24: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000001f28: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 000000001f30: 36080087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001f34: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001f38: bf870223
	v_lshl_add_u32 v7, v3, 2, 48                               // 000000001f3c: d6460007 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001f44: 7c9a0681
	v_lshl_add_u32 v8, v4, 2, 48                               // 000000001f48: d6460008 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 000000001f50: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001f54: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 000000001f58: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 000000001f5c: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 000000001f60: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000001f64: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001f68: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000001f6c: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v7, vcc_lo                        // 000000001f70: 02060e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 000000001f74: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001f78: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 000000001f7c: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001f88: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v8, vcc_lo                        // 000000001f8c: 02081080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001f90: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001f98: bf870092
	v_and_or_b32 v3, 0x80, v9, v4                              // 000000001f9c: d6570003 041212ff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000001fa8: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001fb4: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001fb8: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:10                 // 000000001fc0: ee06407c 00000000 00000a01
	global_load_u8 v0, v[5:6], off offset:6                    // 000000001fcc: ee04007c 00000000 00000605
	s_wait_loadcnt 0x0                                         // 000000001fd8: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000001fdc: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 000000001fe4: 36080087
	v_lshlrev_b32_e32 v9, 4, v0                                // 000000001fe8: 30120084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001fec: bf870223
	v_lshl_add_u32 v7, v3, 2, 48                               // 000000001ff0: d6460007 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001ff8: 7c9a0681
	v_lshl_add_u32 v8, v4, 2, 48                               // 000000001ffc: d6460008 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 000000002004: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000002008: bf870003
	v_cndmask_b32_e32 v7, 48, v7, vcc_lo                       // 00000000200c: 020e0eb0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 000000002010: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 000000002014: bf88ff9d
	v_cndmask_b32_e32 v8, 48, v8, vcc_lo                       // 000000002018: 021010b0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 00000000201c: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000002020: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v7, vcc_lo                        // 000000002024: 02060e80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 000000002028: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 00000000202c: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 000000002030: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 00000000203c: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v8, vcc_lo                        // 000000002040: 02081080
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000002044: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 00000000204c: bf870092
	v_and_or_b32 v3, 0x80, v9, v4                              // 000000002050: d6570003 041212ff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 00000000205c: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000002068: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 00000000206c: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:12                 // 000000002074: ee06407c 00000000 00000c01
	global_load_u8 v0, v[5:6], off offset:7                    // 000000002080: ee04007c 00000000 00000705
	s_wait_loadcnt 0x0                                         // 00000000208c: bfc00000
	v_bfe_u32 v3, v0, 4, 3                                     // 000000002090: d6100003 020d0900
	v_and_b32_e32 v4, 7, v0                                    // 000000002098: 36080087
	v_lshlrev_b32_e32 v7, 4, v0                                // 00000000209c: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 0000000020a0: bf870223
	v_lshl_add_u32 v5, v3, 2, 48                               // 0000000020a4: d6460005 02c10503
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 0000000020ac: 7c9a0681
	v_lshl_add_u32 v6, v4, 2, 48                               // 0000000020b0: d6460006 02c10504
	s_wait_alu depctr_va_vcc(0)                                // 0000000020b8: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 0000000020bc: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 0000000020c0: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v4                             // 0000000020c4: 7c9a0881
	s_wait_alu depctr_va_vcc(0)                                // 0000000020c8: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 0000000020cc: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 0000000020d0: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 0000000020d4: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v5, vcc_lo                        // 0000000020d8: 02060a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v4                             // 0000000020dc: 7c9a0880
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 0000000020e0: bf870132
	v_and_or_b32 v0, 0x80, v0, v3                              // 0000000020e4: d6570000 040e00ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 0000000020f0: bf88ff9d
	v_cndmask_b32_e32 v4, 0, v6, vcc_lo                        // 0000000020f4: 02080c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 0000000020f8: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000002100: bf870092
	v_and_or_b32 v3, 0x80, v7, v4                              // 000000002104: d6570003 04120eff 00000080
	v_and_b16 v0.h, 0xfc, v3.l op_sel:[0,0,1]                  // 000000002110: d7624000 020206ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 00000000211c: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000002120: d7630800 02020100
	global_store_b16 v[1:2], v0, off offset:14                 // 000000002128: ee06407c 00000000 00000e01
	s_endpgm                                                   // 000000002134: bfb00000
	s_code_end                                                 // 000000002138: bf9f0000
	s_code_end                                                 // 00000000213c: bf9f0000
	s_code_end                                                 // 000000002140: bf9f0000
	s_code_end                                                 // 000000002144: bf9f0000
	s_code_end                                                 // 000000002148: bf9f0000
	s_code_end                                                 // 00000000214c: bf9f0000
	s_code_end                                                 // 000000002150: bf9f0000
	s_code_end                                                 // 000000002154: bf9f0000
	s_code_end                                                 // 000000002158: bf9f0000
	s_code_end                                                 // 00000000215c: bf9f0000
	s_code_end                                                 // 000000002160: bf9f0000
	s_code_end                                                 // 000000002164: bf9f0000
	s_code_end                                                 // 000000002168: bf9f0000
	s_code_end                                                 // 00000000216c: bf9f0000
	s_code_end                                                 // 000000002170: bf9f0000
	s_code_end                                                 // 000000002174: bf9f0000
	s_code_end                                                 // 000000002178: bf9f0000
	s_code_end                                                 // 00000000217c: bf9f0000
	s_code_end                                                 // 000000002180: bf9f0000
	s_code_end                                                 // 000000002184: bf9f0000
	s_code_end                                                 // 000000002188: bf9f0000
	s_code_end                                                 // 00000000218c: bf9f0000
	s_code_end                                                 // 000000002190: bf9f0000
	s_code_end                                                 // 000000002194: bf9f0000
	s_code_end                                                 // 000000002198: bf9f0000
	s_code_end                                                 // 00000000219c: bf9f0000
	s_code_end                                                 // 0000000021a0: bf9f0000
	s_code_end                                                 // 0000000021a4: bf9f0000
	s_code_end                                                 // 0000000021a8: bf9f0000
	s_code_end                                                 // 0000000021ac: bf9f0000
	s_code_end                                                 // 0000000021b0: bf9f0000
	s_code_end                                                 // 0000000021b4: bf9f0000
	s_code_end                                                 // 0000000021b8: bf9f0000
	s_code_end                                                 // 0000000021bc: bf9f0000
	s_code_end                                                 // 0000000021c0: bf9f0000
	s_code_end                                                 // 0000000021c4: bf9f0000
	s_code_end                                                 // 0000000021c8: bf9f0000
	s_code_end                                                 // 0000000021cc: bf9f0000
	s_code_end                                                 // 0000000021d0: bf9f0000
	s_code_end                                                 // 0000000021d4: bf9f0000
	s_code_end                                                 // 0000000021d8: bf9f0000
	s_code_end                                                 // 0000000021dc: bf9f0000
	s_code_end                                                 // 0000000021e0: bf9f0000
	s_code_end                                                 // 0000000021e4: bf9f0000
	s_code_end                                                 // 0000000021e8: bf9f0000
	s_code_end                                                 // 0000000021ec: bf9f0000
	s_code_end                                                 // 0000000021f0: bf9f0000
	s_code_end                                                 // 0000000021f4: bf9f0000
	s_code_end                                                 // 0000000021f8: bf9f0000
	s_code_end                                                 // 0000000021fc: bf9f0000
	s_code_end                                                 // 000000002200: bf9f0000
	s_code_end                                                 // 000000002204: bf9f0000
	s_code_end                                                 // 000000002208: bf9f0000
	s_code_end                                                 // 00000000220c: bf9f0000
	s_code_end                                                 // 000000002210: bf9f0000
	s_code_end                                                 // 000000002214: bf9f0000
	s_code_end                                                 // 000000002218: bf9f0000
	s_code_end                                                 // 00000000221c: bf9f0000
	s_code_end                                                 // 000000002220: bf9f0000
	s_code_end                                                 // 000000002224: bf9f0000
	s_code_end                                                 // 000000002228: bf9f0000
	s_code_end                                                 // 00000000222c: bf9f0000
	s_code_end                                                 // 000000002230: bf9f0000
	s_code_end                                                 // 000000002234: bf9f0000
	s_code_end                                                 // 000000002238: bf9f0000
	s_code_end                                                 // 00000000223c: bf9f0000
	s_code_end                                                 // 000000002240: bf9f0000
	s_code_end                                                 // 000000002244: bf9f0000
	s_code_end                                                 // 000000002248: bf9f0000
	s_code_end                                                 // 00000000224c: bf9f0000
	s_code_end                                                 // 000000002250: bf9f0000
	s_code_end                                                 // 000000002254: bf9f0000
	s_code_end                                                 // 000000002258: bf9f0000
	s_code_end                                                 // 00000000225c: bf9f0000
	s_code_end                                                 // 000000002260: bf9f0000
	s_code_end                                                 // 000000002264: bf9f0000
	s_code_end                                                 // 000000002268: bf9f0000
	s_code_end                                                 // 00000000226c: bf9f0000
	s_code_end                                                 // 000000002270: bf9f0000
	s_code_end                                                 // 000000002274: bf9f0000
	s_code_end                                                 // 000000002278: bf9f0000
	s_code_end                                                 // 00000000227c: bf9f0000
	s_code_end                                                 // 000000002280: bf9f0000
	s_code_end                                                 // 000000002284: bf9f0000
	s_code_end                                                 // 000000002288: bf9f0000
	s_code_end                                                 // 00000000228c: bf9f0000
	s_code_end                                                 // 000000002290: bf9f0000
	s_code_end                                                 // 000000002294: bf9f0000
	s_code_end                                                 // 000000002298: bf9f0000
	s_code_end                                                 // 00000000229c: bf9f0000
	s_code_end                                                 // 0000000022a0: bf9f0000
	s_code_end                                                 // 0000000022a4: bf9f0000
	s_code_end                                                 // 0000000022a8: bf9f0000
	s_code_end                                                 // 0000000022ac: bf9f0000
	s_code_end                                                 // 0000000022b0: bf9f0000
	s_code_end                                                 // 0000000022b4: bf9f0000
	s_code_end                                                 // 0000000022b8: bf9f0000
	s_code_end                                                 // 0000000022bc: bf9f0000
	s_code_end                                                 // 0000000022c0: bf9f0000
	s_code_end                                                 // 0000000022c4: bf9f0000
	s_code_end                                                 // 0000000022c8: bf9f0000
	s_code_end                                                 // 0000000022cc: bf9f0000
	s_code_end                                                 // 0000000022d0: bf9f0000
	s_code_end                                                 // 0000000022d4: bf9f0000
	s_code_end                                                 // 0000000022d8: bf9f0000
	s_code_end                                                 // 0000000022dc: bf9f0000
	s_code_end                                                 // 0000000022e0: bf9f0000
	s_code_end                                                 // 0000000022e4: bf9f0000
	s_code_end                                                 // 0000000022e8: bf9f0000
	s_code_end                                                 // 0000000022ec: bf9f0000
	s_code_end                                                 // 0000000022f0: bf9f0000
	s_code_end                                                 // 0000000022f4: bf9f0000
	s_code_end                                                 // 0000000022f8: bf9f0000
	s_code_end                                                 // 0000000022fc: bf9f0000
