
/tmp/tmp5_nkw0z4.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

disassembly of section .text:

0000000000001a00 <tessera_nvfp4_expand_30ece241b64aa312>:
	s_mov_b32 s2, ttmp9                                        // 000000001a00: be820075
	s_ashr_i32 s3, ttmp9, 31                                   // 000000001a04: 86039f75
	s_delay_alu instid0(salu_cycle_1) | instskip(next) | instid1(salu_cycle_1)// 000000001a08: bf870499
	s_lshl_b64 s[2:3], s[2:3], 8                               // 000000001a0c: 84828802
	v_or_b32_e32 v1, s2, v0                                    // 000000001a10: 38020002
	v_mov_b32_e32 v2, s3                                       // 000000001a14: 7e040203
	s_mov_b32 s2, exec_lo                                      // 000000001a18: be82007e
	s_delay_alu instid0(valu_dep_1)                            // 000000001a1c: bf870001
	v_cmpx_gt_u64_e32 21, v[1:2]                               // 000000001a20: 7db80295
	s_cbranch_execz 454                                        // 000000001a24: bfa501c6 <tessera_nvfp4_expand_30ece241b64aa312+0x740>
	s_clause 0x2                                               // 000000001a28: bf850002
	s_load_b64 s[4:5], s[0:1], 0x30                            // 000000001a2c: f4002100 f8000030
	s_load_b64 s[6:7], s[0:1], 0x58                            // 000000001a34: f4002180 f8000058
	s_load_b64 s[2:3], s[0:1], 0x80                            // 000000001a3c: f4002080 f8000080
	s_wait_kmcnt 0x0                                           // 000000001a44: bfc70000
	v_add_co_u32 v1, vcc_lo, s4, v1                            // 000000001a48: d7006a01 02020204
	s_delay_alu instid0(valu_dep_1)                            // 000000001a50: bf870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000001a54: d5207c02 01aa0405
	v_cmp_lt_u32_e32 vcc_lo, 8, v0                             // 000000001a5c: 7c920088
	s_clause 0x1                                               // 000000001a60: bf850001
	s_load_b64 s[4:5], s[0:1], 0xa8                            // 000000001a64: f4002100 f80000a8
	s_load_b64 s[0:1], s[0:1], 0x8                             // 000000001a6c: f4002000 f8000008
	global_load_d16_i8 v9, v[1:2], off                         // 000000001a74: ee07c07c 00000009 00000001
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000001a80: d5010001 01a90280
	s_wait_loadcnt 0x0                                         // 000000001a88: bfc00000
	v_and_b32_e32 v3, 7, v9                                    // 000000001a8c: 36061287
	v_lshrrev_b32_e32 v7, 3, v9                                // 000000001a90: 320e1283
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_3)// 000000001a94: bf8701a2
	v_or_b32_e32 v5, 8, v3                                     // 000000001a98: 380a0688
	v_cvt_f64_u32_e32 v[3:4], v3                               // 000000001a9c: 7e062d03
	v_dual_mov_b32 v7, 0 :: v_dual_and_b32 v10, 15, v7         // 000000001aa0: ca240080 070a0e8f
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_2)// 000000001aa8: bf870113
	v_cvt_f64_u32_e32 v[5:6], v5                               // 000000001aac: 7e0a2d05
	v_lshl_add_u32 v8, v10, 20, 0x3f500000                     // 000000001ab0: d6460008 03fd290a 3f500000
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000001abc: 7c941480
	v_ldexp_f64 v[3:4], v[3:4], -9                             // 000000001ac0: d72b0003 02019303
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_1)// 000000001ac8: bf8700a3
	v_mul_f64_e32 v[5:6], v[5:6], v[7:8]                       // 000000001acc: 0c0a0f05
	s_wait_alu depctr_va_vcc(0)                                // 000000001ad0: bf88ff9d
	v_dual_cndmask_b32 v4, v6, v4 :: v_dual_lshlrev_b32 v1, 3, v1// 000000001ad4: ca620906 04000283
	global_load_b64 v[1:2], v1, s[6:7]                         // 000000001adc: ee054006 00000001 00000001
	v_cndmask_b32_e32 v3, v5, v3, vcc_lo                       // 000000001ae8: 02060705
	v_cmp_gt_i16_e32 vcc_lo, 0, v9.l                           // 000000001aec: 7c681280
	v_xor_b32_e32 v5, 0x80000000, v4                           // 000000001af0: 3a0a08ff 80000000
	s_wait_alu depctr_va_vcc(0)                                // 000000001af8: bf88ff9d
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_1)// 000000001afc: bf8700a1
	v_cndmask_b32_e32 v4, v4, v5, vcc_lo                       // 000000001b00: 02080b04
	s_wait_loadcnt 0x0                                         // 000000001b04: bfc00000
	v_mul_f64_e32 v[2:3], v[1:2], v[3:4]                       // 000000001b08: 0c040701
	v_mul_lo_u16 v1.l, 0xab, v0.l                              // 000000001b0c: d7050001 020200ff 000000ab
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_1)// 000000001b18: bf870091
	v_lshrrev_b16 v1.l, 9, v1.l                                // 000000001b1c: d7390001 02020289
	v_mul_lo_u16 v1.h, v1.l, 3 op_sel:[0,0,1]                  // 000000001b24: d7054001 02010701
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 000000001b2c: bf870121
	v_sub_nc_u16 v1.h, v0.l, v1.h op_sel:[0,1,1]               // 000000001b30: d7045001 02020300
	v_cvt_f32_f64_e32 v3, v[2:3]                               // 000000001b38: 7e061f02
	v_mul_lo_u16 v2.l, v1.h, 28 op_sel:[1,0,0]                 // 000000001b3c: d7050802 02013901
	v_cvt_u32_u16_e32 v1, v1.l                                 // 000000001b44: 7e02d701
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000001b48: bf870112
	v_and_b32_e32 v2, 0xfc, v2                                 // 000000001b4c: 360404ff 000000fc
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000001b54: 30020282
	s_wait_kmcnt 0x0                                           // 000000001b58: bfc70000
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001b5c: bf870132
	v_add_co_u32 v2, s4, s4, v2                                // 000000001b60: d7000402 02020404
	s_wait_alu depctr_va_sdst(0)                               // 000000001b68: bf88f19f
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 000000001b6c: d5207c04 00110005
	v_add_co_u32 v1, vcc_lo, v2, v1                            // 000000001b74: d7006a01 02020302
	s_wait_alu depctr_va_vcc(0)                                // 000000001b7c: bf88ff9d
	s_delay_alu instid0(valu_dep_2)                            // 000000001b80: bf870002
	v_add_co_ci_u32_e64 v2, null, 0, v4, vcc_lo                // 000000001b84: d5207c02 01aa0880
	v_lshlrev_b32_e32 v4, 3, v0                                // 000000001b8c: 30080083
	global_store_b32 v[1:2], v3, off                           // 000000001b90: ee06807c 01800000 00000001
	global_load_u8 v1, v4, s[0:1]                              // 000000001b9c: ee040000 00000001 00000004
	s_wait_loadcnt 0x0                                         // 000000001ba8: bfc00000
	v_bfe_u32 v2, v1, 4, 3                                     // 000000001bac: d6100002 020d0901
	v_and_b32_e32 v3, 7, v1                                    // 000000001bb4: 36060287
	v_lshlrev_b32_e32 v7, 4, v1                                // 000000001bb8: 300e0284
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001bbc: bf870223
	v_lshl_add_u32 v5, v2, 2, 48                               // 000000001bc0: d6460005 02c10502
	v_cmp_ne_u32_e32 vcc_lo, 1, v2                             // 000000001bc8: 7c9a0481
	v_lshl_add_u32 v6, v3, 2, 48                               // 000000001bcc: d6460006 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 000000001bd4: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001bd8: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 000000001bdc: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001be0: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000001be4: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 000000001be8: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v2                             // 000000001bec: 7c9a0480
	s_wait_alu depctr_va_vcc(0)                                // 000000001bf0: bf88ff9d
	v_cndmask_b32_e32 v2, 0, v5, vcc_lo                        // 000000001bf4: 02040a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001bf8: 7c9a0680
	s_wait_alu depctr_va_vcc(0)                                // 000000001bfc: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v6, vcc_lo                        // 000000001c00: 02060c80
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_2)// 000000001c04: bf870113
	v_and_or_b32 v1, 0x80, v1, v2                              // 000000001c08: d6570001 040a02ff 00000080
	v_and_or_b32 v2, 0x80, v7, v3                              // 000000001c14: d6570002 040e0eff 00000080
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_2)// 000000001c20: bf870112
	v_lshlrev_b16 v1.l, 8, v1.l                                // 000000001c24: d7380001 02020288
	v_and_b16 v1.h, 0xfc, v2.l op_sel:[0,0,1]                  // 000000001c2c: d7624001 020204ff 000000fc
	v_lshlrev_b32_e32 v2, 4, v0                                // 000000001c38: 30040084
	s_delay_alu instid0(valu_dep_2)                            // 000000001c3c: bf870002
	v_or_b16 v0.l, v1.h, v1.l op_sel:[1,0,0]                   // 000000001c40: d7630800 02020301
	global_store_b16 v2, v0, s[2:3]                            // 000000001c48: ee064002 00000000 00000002
	global_load_u8 v0, v4, s[0:1] offset:1                     // 000000001c54: ee040000 00000000 00000104
	s_wait_loadcnt 0x0                                         // 000000001c60: bfc00000
	v_bfe_u32 v1, v0, 4, 3                                     // 000000001c64: d6100001 020d0900
	v_and_b32_e32 v3, 7, v0                                    // 000000001c6c: 36060087
	v_lshlrev_b32_e32 v7, 4, v0                                // 000000001c70: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001c74: bf870223
	v_lshl_add_u32 v5, v1, 2, 48                               // 000000001c78: d6460005 02c10501
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 000000001c80: 7c9a0281
	v_lshl_add_u32 v6, v3, 2, 48                               // 000000001c84: d6460006 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 000000001c8c: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001c90: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 000000001c94: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001c98: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000001c9c: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 000000001ca0: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000001ca4: 7c9a0280
	s_wait_alu depctr_va_vcc(0)                                // 000000001ca8: bf88ff9d
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000001cac: 02020a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001cb0: 7c9a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001cb4: bf870132
	v_and_or_b32 v0, 0x80, v0, v1                              // 000000001cb8: d6570000 040600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001cc4: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v6, vcc_lo                        // 000000001cc8: 02060c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001ccc: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001cd4: bf870092
	v_and_or_b32 v1, 0x80, v7, v3                              // 000000001cd8: d6570001 040e0eff 00000080
	v_and_b16 v0.h, 0xfc, v1.l op_sel:[0,0,1]                  // 000000001ce4: d7624000 020202ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001cf0: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001cf4: d7630800 02020100
	global_store_b16 v2, v0, s[2:3] offset:2                   // 000000001cfc: ee064002 00000000 00000202
	global_load_u8 v0, v4, s[0:1] offset:2                     // 000000001d08: ee040000 00000000 00000204
	s_wait_loadcnt 0x0                                         // 000000001d14: bfc00000
	v_bfe_u32 v1, v0, 4, 3                                     // 000000001d18: d6100001 020d0900
	v_and_b32_e32 v3, 7, v0                                    // 000000001d20: 36060087
	v_lshlrev_b32_e32 v7, 4, v0                                // 000000001d24: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001d28: bf870223
	v_lshl_add_u32 v5, v1, 2, 48                               // 000000001d2c: d6460005 02c10501
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 000000001d34: 7c9a0281
	v_lshl_add_u32 v6, v3, 2, 48                               // 000000001d38: d6460006 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 000000001d40: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001d44: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 000000001d48: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001d4c: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000001d50: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 000000001d54: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000001d58: 7c9a0280
	s_wait_alu depctr_va_vcc(0)                                // 000000001d5c: bf88ff9d
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000001d60: 02020a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001d64: 7c9a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001d68: bf870132
	v_and_or_b32 v0, 0x80, v0, v1                              // 000000001d6c: d6570000 040600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001d78: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v6, vcc_lo                        // 000000001d7c: 02060c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001d80: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001d88: bf870092
	v_and_or_b32 v1, 0x80, v7, v3                              // 000000001d8c: d6570001 040e0eff 00000080
	v_and_b16 v0.h, 0xfc, v1.l op_sel:[0,0,1]                  // 000000001d98: d7624000 020202ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001da4: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001da8: d7630800 02020100
	global_store_b16 v2, v0, s[2:3] offset:4                   // 000000001db0: ee064002 00000000 00000402
	global_load_u8 v0, v4, s[0:1] offset:3                     // 000000001dbc: ee040000 00000000 00000304
	s_wait_loadcnt 0x0                                         // 000000001dc8: bfc00000
	v_bfe_u32 v1, v0, 4, 3                                     // 000000001dcc: d6100001 020d0900
	v_and_b32_e32 v3, 7, v0                                    // 000000001dd4: 36060087
	v_lshlrev_b32_e32 v7, 4, v0                                // 000000001dd8: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001ddc: bf870223
	v_lshl_add_u32 v5, v1, 2, 48                               // 000000001de0: d6460005 02c10501
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 000000001de8: 7c9a0281
	v_lshl_add_u32 v6, v3, 2, 48                               // 000000001dec: d6460006 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 000000001df4: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001df8: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 000000001dfc: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001e00: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000001e04: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 000000001e08: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000001e0c: 7c9a0280
	s_wait_alu depctr_va_vcc(0)                                // 000000001e10: bf88ff9d
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000001e14: 02020a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001e18: 7c9a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001e1c: bf870132
	v_and_or_b32 v0, 0x80, v0, v1                              // 000000001e20: d6570000 040600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001e2c: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v6, vcc_lo                        // 000000001e30: 02060c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001e34: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001e3c: bf870092
	v_and_or_b32 v1, 0x80, v7, v3                              // 000000001e40: d6570001 040e0eff 00000080
	v_and_b16 v0.h, 0xfc, v1.l op_sel:[0,0,1]                  // 000000001e4c: d7624000 020202ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001e58: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001e5c: d7630800 02020100
	global_store_b16 v2, v0, s[2:3] offset:6                   // 000000001e64: ee064002 00000000 00000602
	global_load_u8 v0, v4, s[0:1] offset:4                     // 000000001e70: ee040000 00000000 00000404
	s_wait_loadcnt 0x0                                         // 000000001e7c: bfc00000
	v_bfe_u32 v1, v0, 4, 3                                     // 000000001e80: d6100001 020d0900
	v_and_b32_e32 v3, 7, v0                                    // 000000001e88: 36060087
	v_lshlrev_b32_e32 v7, 4, v0                                // 000000001e8c: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001e90: bf870223
	v_lshl_add_u32 v5, v1, 2, 48                               // 000000001e94: d6460005 02c10501
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 000000001e9c: 7c9a0281
	v_lshl_add_u32 v6, v3, 2, 48                               // 000000001ea0: d6460006 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 000000001ea8: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001eac: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 000000001eb0: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001eb4: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000001eb8: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 000000001ebc: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000001ec0: 7c9a0280
	s_wait_alu depctr_va_vcc(0)                                // 000000001ec4: bf88ff9d
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000001ec8: 02020a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001ecc: 7c9a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001ed0: bf870132
	v_and_or_b32 v0, 0x80, v0, v1                              // 000000001ed4: d6570000 040600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001ee0: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v6, vcc_lo                        // 000000001ee4: 02060c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001ee8: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001ef0: bf870092
	v_and_or_b32 v1, 0x80, v7, v3                              // 000000001ef4: d6570001 040e0eff 00000080
	v_and_b16 v0.h, 0xfc, v1.l op_sel:[0,0,1]                  // 000000001f00: d7624000 020202ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001f0c: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001f10: d7630800 02020100
	global_store_b16 v2, v0, s[2:3] offset:8                   // 000000001f18: ee064002 00000000 00000802
	global_load_u8 v0, v4, s[0:1] offset:5                     // 000000001f24: ee040000 00000000 00000504
	s_wait_loadcnt 0x0                                         // 000000001f30: bfc00000
	v_bfe_u32 v1, v0, 4, 3                                     // 000000001f34: d6100001 020d0900
	v_and_b32_e32 v3, 7, v0                                    // 000000001f3c: 36060087
	v_lshlrev_b32_e32 v7, 4, v0                                // 000000001f40: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001f44: bf870223
	v_lshl_add_u32 v5, v1, 2, 48                               // 000000001f48: d6460005 02c10501
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 000000001f50: 7c9a0281
	v_lshl_add_u32 v6, v3, 2, 48                               // 000000001f54: d6460006 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 000000001f5c: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000001f60: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 000000001f64: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 000000001f68: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000001f6c: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 000000001f70: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000001f74: 7c9a0280
	s_wait_alu depctr_va_vcc(0)                                // 000000001f78: bf88ff9d
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000001f7c: 02020a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000001f80: 7c9a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000001f84: bf870132
	v_and_or_b32 v0, 0x80, v0, v1                              // 000000001f88: d6570000 040600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000001f94: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v6, vcc_lo                        // 000000001f98: 02060c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000001f9c: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000001fa4: bf870092
	v_and_or_b32 v1, 0x80, v7, v3                              // 000000001fa8: d6570001 040e0eff 00000080
	v_and_b16 v0.h, 0xfc, v1.l op_sel:[0,0,1]                  // 000000001fb4: d7624000 020202ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000001fc0: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000001fc4: d7630800 02020100
	global_store_b16 v2, v0, s[2:3] offset:10                  // 000000001fcc: ee064002 00000000 00000a02
	global_load_u8 v0, v4, s[0:1] offset:6                     // 000000001fd8: ee040000 00000000 00000604
	s_wait_loadcnt 0x0                                         // 000000001fe4: bfc00000
	v_bfe_u32 v1, v0, 4, 3                                     // 000000001fe8: d6100001 020d0900
	v_and_b32_e32 v3, 7, v0                                    // 000000001ff0: 36060087
	v_lshlrev_b32_e32 v7, 4, v0                                // 000000001ff4: 300e0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 000000001ff8: bf870223
	v_lshl_add_u32 v5, v1, 2, 48                               // 000000001ffc: d6460005 02c10501
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 000000002004: 7c9a0281
	v_lshl_add_u32 v6, v3, 2, 48                               // 000000002008: d6460006 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 000000002010: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000002014: bf870003
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 000000002018: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 00000000201c: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 000000002020: bf88ff9d
	v_cndmask_b32_e32 v6, 48, v6, vcc_lo                       // 000000002024: 020c0cb0
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000002028: 7c9a0280
	s_wait_alu depctr_va_vcc(0)                                // 00000000202c: bf88ff9d
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000002030: 02020a80
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 000000002034: 7c9a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 000000002038: bf870132
	v_and_or_b32 v0, 0x80, v0, v1                              // 00000000203c: d6570000 040600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 000000002048: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v6, vcc_lo                        // 00000000204c: 02060c80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000002050: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000002058: bf870092
	v_and_or_b32 v1, 0x80, v7, v3                              // 00000000205c: d6570001 040e0eff 00000080
	v_and_b16 v0.h, 0xfc, v1.l op_sel:[0,0,1]                  // 000000002068: d7624000 020202ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000002074: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 000000002078: d7630800 02020100
	global_store_b16 v2, v0, s[2:3] offset:12                  // 000000002080: ee064002 00000000 00000c02
	global_load_u8 v0, v4, s[0:1] offset:7                     // 00000000208c: ee040000 00000000 00000704
	s_wait_loadcnt 0x0                                         // 000000002098: bfc00000
	v_bfe_u32 v1, v0, 4, 3                                     // 00000000209c: d6100001 020d0900
	v_and_b32_e32 v3, 7, v0                                    // 0000000020a4: 36060087
	v_lshlrev_b32_e32 v6, 4, v0                                // 0000000020a8: 300c0084
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_4)// 0000000020ac: bf870223
	v_lshl_add_u32 v4, v1, 2, 48                               // 0000000020b0: d6460004 02c10501
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 0000000020b8: 7c9a0281
	v_lshl_add_u32 v5, v3, 2, 48                               // 0000000020bc: d6460005 02c10503
	s_wait_alu depctr_va_vcc(0)                                // 0000000020c4: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 0000000020c8: bf870003
	v_cndmask_b32_e32 v4, 48, v4, vcc_lo                       // 0000000020cc: 020808b0
	v_cmp_ne_u32_e32 vcc_lo, 1, v3                             // 0000000020d0: 7c9a0681
	s_wait_alu depctr_va_vcc(0)                                // 0000000020d4: bf88ff9d
	v_cndmask_b32_e32 v5, 48, v5, vcc_lo                       // 0000000020d8: 020a0ab0
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 0000000020dc: 7c9a0280
	s_wait_alu depctr_va_vcc(0)                                // 0000000020e0: bf88ff9d
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000000020e4: 02020880
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 0000000020e8: 7c9a0680
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_2)// 0000000020ec: bf870132
	v_and_or_b32 v0, 0x80, v0, v1                              // 0000000020f0: d6570000 040600ff 00000080
	s_wait_alu depctr_va_vcc(0)                                // 0000000020fc: bf88ff9d
	v_cndmask_b32_e32 v3, 0, v5, vcc_lo                        // 000000002100: 02060a80
	v_lshlrev_b16 v0.l, 8, v0.l                                // 000000002104: d7380000 02020088
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 00000000210c: bf870092
	v_and_or_b32 v1, 0x80, v6, v3                              // 000000002110: d6570001 040e0cff 00000080
	v_and_b16 v0.h, 0xfc, v1.l op_sel:[0,0,1]                  // 00000000211c: d7624000 020202ff 000000fc
	s_delay_alu instid0(valu_dep_1)                            // 000000002128: bf870001
	v_or_b16 v0.l, v0.h, v0.l op_sel:[1,0,0]                   // 00000000212c: d7630800 02020100
	global_store_b16 v2, v0, s[2:3] offset:14                  // 000000002134: ee064002 00000000 00000e02
	s_endpgm                                                   // 000000002140: bfb00000
	s_code_end                                                 // 000000002144: bf9f0000
	s_code_end                                                 // 000000002148: bf9f0000
	s_code_end                                                 // 00000000214c: bf9f0000
	s_code_end                                                 // 000000002150: bf9f0000
	s_code_end                                                 // 000000002154: bf9f0000
	s_code_end                                                 // 000000002158: bf9f0000
	s_code_end                                                 // 00000000215c: bf9f0000
	s_code_end                                                 // 000000002160: bf9f0000
	s_code_end                                                 // 000000002164: bf9f0000
	s_code_end                                                 // 000000002168: bf9f0000
	s_code_end                                                 // 00000000216c: bf9f0000
	s_code_end                                                 // 000000002170: bf9f0000
	s_code_end                                                 // 000000002174: bf9f0000
	s_code_end                                                 // 000000002178: bf9f0000
	s_code_end                                                 // 00000000217c: bf9f0000
	s_code_end                                                 // 000000002180: bf9f0000
	s_code_end                                                 // 000000002184: bf9f0000
	s_code_end                                                 // 000000002188: bf9f0000
	s_code_end                                                 // 00000000218c: bf9f0000
	s_code_end                                                 // 000000002190: bf9f0000
	s_code_end                                                 // 000000002194: bf9f0000
	s_code_end                                                 // 000000002198: bf9f0000
	s_code_end                                                 // 00000000219c: bf9f0000
	s_code_end                                                 // 0000000021a0: bf9f0000
	s_code_end                                                 // 0000000021a4: bf9f0000
	s_code_end                                                 // 0000000021a8: bf9f0000
	s_code_end                                                 // 0000000021ac: bf9f0000
	s_code_end                                                 // 0000000021b0: bf9f0000
	s_code_end                                                 // 0000000021b4: bf9f0000
	s_code_end                                                 // 0000000021b8: bf9f0000
	s_code_end                                                 // 0000000021bc: bf9f0000
	s_code_end                                                 // 0000000021c0: bf9f0000
	s_code_end                                                 // 0000000021c4: bf9f0000
	s_code_end                                                 // 0000000021c8: bf9f0000
	s_code_end                                                 // 0000000021cc: bf9f0000
	s_code_end                                                 // 0000000021d0: bf9f0000
	s_code_end                                                 // 0000000021d4: bf9f0000
	s_code_end                                                 // 0000000021d8: bf9f0000
	s_code_end                                                 // 0000000021dc: bf9f0000
	s_code_end                                                 // 0000000021e0: bf9f0000
	s_code_end                                                 // 0000000021e4: bf9f0000
	s_code_end                                                 // 0000000021e8: bf9f0000
	s_code_end                                                 // 0000000021ec: bf9f0000
	s_code_end                                                 // 0000000021f0: bf9f0000
	s_code_end                                                 // 0000000021f4: bf9f0000
	s_code_end                                                 // 0000000021f8: bf9f0000
	s_code_end                                                 // 0000000021fc: bf9f0000
	s_code_end                                                 // 000000002200: bf9f0000
	s_code_end                                                 // 000000002204: bf9f0000
	s_code_end                                                 // 000000002208: bf9f0000
	s_code_end                                                 // 00000000220c: bf9f0000
	s_code_end                                                 // 000000002210: bf9f0000
	s_code_end                                                 // 000000002214: bf9f0000
	s_code_end                                                 // 000000002218: bf9f0000
	s_code_end                                                 // 00000000221c: bf9f0000
	s_code_end                                                 // 000000002220: bf9f0000
	s_code_end                                                 // 000000002224: bf9f0000
	s_code_end                                                 // 000000002228: bf9f0000
	s_code_end                                                 // 00000000222c: bf9f0000
	s_code_end                                                 // 000000002230: bf9f0000
	s_code_end                                                 // 000000002234: bf9f0000
	s_code_end                                                 // 000000002238: bf9f0000
	s_code_end                                                 // 00000000223c: bf9f0000
	s_code_end                                                 // 000000002240: bf9f0000
	s_code_end                                                 // 000000002244: bf9f0000
	s_code_end                                                 // 000000002248: bf9f0000
	s_code_end                                                 // 00000000224c: bf9f0000
	s_code_end                                                 // 000000002250: bf9f0000
	s_code_end                                                 // 000000002254: bf9f0000
	s_code_end                                                 // 000000002258: bf9f0000
	s_code_end                                                 // 00000000225c: bf9f0000
	s_code_end                                                 // 000000002260: bf9f0000
	s_code_end                                                 // 000000002264: bf9f0000
	s_code_end                                                 // 000000002268: bf9f0000
	s_code_end                                                 // 00000000226c: bf9f0000
	s_code_end                                                 // 000000002270: bf9f0000
	s_code_end                                                 // 000000002274: bf9f0000
	s_code_end                                                 // 000000002278: bf9f0000
	s_code_end                                                 // 00000000227c: bf9f0000
	s_code_end                                                 // 000000002280: bf9f0000
	s_code_end                                                 // 000000002284: bf9f0000
	s_code_end                                                 // 000000002288: bf9f0000
	s_code_end                                                 // 00000000228c: bf9f0000
	s_code_end                                                 // 000000002290: bf9f0000
	s_code_end                                                 // 000000002294: bf9f0000
	s_code_end                                                 // 000000002298: bf9f0000
	s_code_end                                                 // 00000000229c: bf9f0000
	s_code_end                                                 // 0000000022a0: bf9f0000
	s_code_end                                                 // 0000000022a4: bf9f0000
	s_code_end                                                 // 0000000022a8: bf9f0000
	s_code_end                                                 // 0000000022ac: bf9f0000
	s_code_end                                                 // 0000000022b0: bf9f0000
	s_code_end                                                 // 0000000022b4: bf9f0000
	s_code_end                                                 // 0000000022b8: bf9f0000
	s_code_end                                                 // 0000000022bc: bf9f0000
	s_code_end                                                 // 0000000022c0: bf9f0000
	s_code_end                                                 // 0000000022c4: bf9f0000
	s_code_end                                                 // 0000000022c8: bf9f0000
	s_code_end                                                 // 0000000022cc: bf9f0000
	s_code_end                                                 // 0000000022d0: bf9f0000
	s_code_end                                                 // 0000000022d4: bf9f0000
	s_code_end                                                 // 0000000022d8: bf9f0000
	s_code_end                                                 // 0000000022dc: bf9f0000
	s_code_end                                                 // 0000000022e0: bf9f0000
	s_code_end                                                 // 0000000022e4: bf9f0000
	s_code_end                                                 // 0000000022e8: bf9f0000
	s_code_end                                                 // 0000000022ec: bf9f0000
	s_code_end                                                 // 0000000022f0: bf9f0000
	s_code_end                                                 // 0000000022f4: bf9f0000
	s_code_end                                                 // 0000000022f8: bf9f0000
	s_code_end                                                 // 0000000022fc: bf9f0000
