import hashlib,json,os,re
from pathlib import Path
from tests.unit.test_sm120_bounded_norm_schedule import source
from tests.unit.test_sm120_reverse_row_schedule import invoke
candidate=Path(os.environ["TESSERA_OPT"])
control=Path("/home/angstorms/scratch/rocm-closure-baseline-20261018/bounded-row-prereq-opt")
rows=[]
for storage in ("f16","bf16","f32"):
    for kind in ("rmsnorm","layer_norm"):
        for capacity in ((2,3,7,35),(1,2,17,257)):
            text=source(storage,capacity)
            text=re.sub(r' attributes \{\s*tessera.native.query_sequence_bound = \d+ : i64\}',"",text)
            assert "query_sequence_bound" not in text
            text=text.replace("x?x",f"x{capacity[2]}x").replace("tessera.rmsnorm","tessera."+kind)
            receipts=[]
            for tool in (control,candidate):
                stage=text; hashes=[]
                for flag in ("--tessera-graph-to-schedule","--tessera-schedule-to-tile",
                             "--lower-tile-to-nvidia=sm=120","--lower-tessera-nvidia-to-nvvm"):
                    result=invoke(tool,stage,flag)
                    assert result.returncode==0,(storage,kind,capacity,flag,result.stderr)
                    stage=result.stdout;hashes.append(hashlib.sha256(stage.encode()).hexdigest())
                receipts.append(hashes)
            assert receipts[0]==receipts[1],(storage,kind,capacity,receipts)
            rows.append({"storage":storage,"kind":kind,"shape":list(capacity),"stage_sha256":receipts[0],"identical":True})
record={"control_compiler_sha256":hashlib.sha256(control.read_bytes()).hexdigest(),
        "candidate_compiler_sha256":hashlib.sha256(candidate.read_bytes()).hexdigest(),
        "scope":"static RMSNorm/LayerNorm Schedule/Tile/Target/native identity, not a new device certificate",
        "rows":rows}
Path("/home/angstorms/scratch/rocm-closure-baseline-20261018/bounded-norm-static-parity.json").write_text(json.dumps(record,indent=2)+"\n")
print(len(rows),"legacy norm profiles byte-identical across four stages")
