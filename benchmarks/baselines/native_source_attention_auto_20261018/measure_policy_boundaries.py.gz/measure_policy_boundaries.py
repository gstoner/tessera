from pathlib import Path
import hashlib,json,os,subprocess
from benchmarks.nvidia.benchmark_source_attention_rows import run_case
p=Path("/home/angstorms/scratch/source-attention-rows-20261018")
profiles={"row_boundary":(1,2,1,16,5,35,7),"d_boundary":(1,2,1,16,5,32,7),
          "key_boundary":(1,2,1,16,4,35,7),"value_boundary":(1,2,1,16,5,35,4)}
result={"scope":"pre-selection native policy boundary A/B; explicit inline and row compiler programs",
        "compiler_sha256":hashlib.sha256(Path(os.environ["TESSERA_OPT"]).read_bytes()).hexdigest(),
        "provider_sha256":hashlib.sha256(Path(os.environ["TESSERA_NVIDIA_PTX_LAUNCH_LIB"]).read_bytes()).hexdigest(),
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "gpu":subprocess.check_output(["/usr/lib/wsl/lib/nvidia-smi","--query-gpu=name,uuid,compute_cap,driver_version","--format=csv,noheader"],text=True).strip(),"orders":[]}
assert "RTX 5070" in result["gpu"] and result["gpu"].split(",")[2].strip()=="12.0"
for order in (0,1):
 out=p/f"boundary-ab-order{order}";out.mkdir(exist_ok=False)
 rows=[]
 for storage in ("f16","bf16"):
  for name,dims in profiles.items():
   row=run_case(name,dims,storage,out,21,8,order)
   rows.append(row)
   print(order,storage,name,row["medians"],flush=True)
   (out/"packet.json").write_text(json.dumps({"order":order,"profiles":rows},indent=2)+"\n")
 result["orders"].append({"order":order,"profiles":rows})
 (p/"boundary-ab.json").write_text(json.dumps(result,indent=2)+"\n")

