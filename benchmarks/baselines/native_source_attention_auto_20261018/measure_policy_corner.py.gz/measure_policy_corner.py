from pathlib import Path
import hashlib,json,os
from benchmarks.nvidia.benchmark_source_attention_rows import run_case
p=Path("/home/angstorms/scratch/source-attention-rows-20261018")
result={"scope":"combined lower-bound corner before automatic policy promotion",
"compiler_sha256":hashlib.sha256(Path(os.environ["TESSERA_OPT"]).read_bytes()).hexdigest(),
"provider_sha256":hashlib.sha256(Path(os.environ["TESSERA_NVIDIA_PTX_LAUNCH_LIB"]).read_bytes()).hexdigest(),"orders":[]}
for order in (0,1):
 out=p/f"corner-ab-order{order}";out.mkdir(exist_ok=False);rows=[]
 for storage in ("f16","bf16"):
  row=run_case("combined_corner",(1,2,1,16,4,32,4),storage,out,21,8,order)
  rows.append(row);print(order,storage,row["medians"],flush=True)
 result["orders"].append({"order":order,"profiles":rows})
 (p/"corner-ab.json").write_text(json.dumps(result,indent=2)+"\n")

