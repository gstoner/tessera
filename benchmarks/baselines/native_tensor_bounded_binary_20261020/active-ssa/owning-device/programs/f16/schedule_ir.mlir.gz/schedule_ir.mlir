module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program = 2 : i64, tessera.native.tensor_program_row_bound = 256 : i64, tessera.native.tensor_program_row_buffers = array<i64: 1, 1, 0, 1, 1>, tessera.native.tensor_program_row_root = 0 : i64, tessera.native.tensor_program_source = "module attributes {tessera.arch = \22sm_120\22, tessera.frontend.authority = \22tracer\22, tessera.ir.version = \221.0\22, tessera.native.tensor_program_row_bound_request = 256 : i64, tessera.target = \22nvidia_sm120\22} {\0A  func.func @lhs_add(%arg0: tensor<17x4096xf16>, %arg1: tensor<17x4096xf16>, %arg2: tensor<4096x256xf16>) -> tensor<17x256xf32> attributes {tessera.frontend.authority = \22tracer\22, tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = \220900f4bdf92ef1a013aff09c5067a47d259e5648534c208628af1a08482139b7\22, tessera.structured_cfg.schema = \22tessera.structured_cfg.v1\22} {\0A    %0 = tessera.add %arg0, %arg1 {tessera.effect_kind = \22pure\22} : (tensor<17x4096xf16>, tensor<17x4096xf16>) -> tensor<17x4096xf16>\0A    %1 = tessera.matmul %0, %arg2 {output_dtype = \22fp32\22, tessera.effect_kind = \22pure\22} : (tensor<17x4096xf16>, tensor<4096x256xf16>) -> tensor<17x256xf32>\0A    return %1 : tensor<17x256xf32>\0A  }\0A}", tessera.native.tensor_program_source_sha256 = "d51cdb00840e2ae45c8636a17c6ae102bb33418fde3a826bf64b17b06f68013f", tessera.target = "nvidia_sm120"} {
  func.func @lhs_add(%arg0: memref<?x4096xf16>, %arg1: memref<?x4096xf16>, %arg2: memref<4096x256xf16>) -> memref<?x256xf32> attributes {tessera.frontend.authority = "tracer", tessera.native.tensor_program = 2 : i64, tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "0900f4bdf92ef1a013aff09c5067a47d259e5648534c208628af1a08482139b7", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %c0 = arith.constant 0 : index
    %dim = memref.dim %arg0, %c0 : memref<?x4096xf16>
    %alloc = memref.alloc() : memref<256x4096xf16>
    %subview = memref.subview %alloc[0, 0] [%dim, 4096] [1, 1] : memref<256x4096xf16> to memref<?x4096xf16>
    tile.program_invoke %arg0, %arg1, %subview {callee = @tensor_stage_0::@source, input_count = 2 : i64, source_attributes = {tessera.effect_kind = "pure"}} : memref<?x4096xf16>, memref<?x4096xf16>, memref<?x4096xf16>
    %alloc_0 = memref.alloc() : memref<256x256xf32>
    %subview_1 = memref.subview %alloc_0[0, 0] [%dim, 256] [1, 1] : memref<256x256xf32> to memref<?x256xf32>
    tile.program_invoke %subview, %arg2, %subview_1 {callee = @tensor_stage_1::@source, input_count = 2 : i64, source_attributes = {output_dtype = "fp32", shape_bounds = [256, 256, 4096], tessera.effect_kind = "pure", transposeA = false, transposeB = false}} : memref<?x4096xf16>, memref<4096x256xf16>, memref<?x256xf32>
    memref.dealloc %alloc : memref<256x4096xf16>
    return %subview_1 : memref<?x256xf32>
  }
  module @tensor_stage_0 attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program_member, tessera.native.tensor_program_row_bound = 256 : i64, tessera.target = "nvidia_sm120"} {
    func.func @source(%arg0: tensor<?x4096xf16>, %arg1: tensor<?x4096xf16>) -> tensor<?x4096xf16> attributes {tessera.native.tensor_row_bound = 256 : i64} {
      %0 = tessera.add %arg0, %arg1 {schedule.artifact_hash = "0e37445a241c79f202616ec18d5310cdc4ef8d51826fe1614d58705bdbf0b3ff", tessera.effect_kind = "pure"} : (tensor<?x4096xf16>, tensor<?x4096xf16>) -> tensor<?x4096xf16>
      %1 = schedule.binary_kernel %0 {accum = "f32", arch = "sm_120", artifact_hash = "0e37445a241c79f202616ec18d5310cdc4ef8d51826fe1614d58705bdbf0b3ff", axis = -1 : i64, kind = "add", nan_mode = "propagate", output_storage = "f16", row_bound = 256 : i64, schedule = "flat_128", storage = "f16", workgroup_size = 128 : i64} : tensor<?x4096xf16> -> tensor<?x4096xf16>
      schedule.artifact {arch = "sm_120", hash = "0e37445a241c79f202616ec18d5310cdc4ef8d51826fe1614d58705bdbf0b3ff", numeric_policy = "f16->f32", shape_key = "family=binary;storage=f16;axis=-1", tile = {workgroup_size = 128 : i64}}
      return %1 : tensor<?x4096xf16>
    }
  }
  module @tensor_stage_1 attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program_member, tessera.native.tensor_program_row_bound = 256 : i64, tessera.target = "nvidia_sm120"} {
    func.func @source(%arg0: tensor<?x4096xf16>, %arg1: tensor<4096x256xf16>) -> tensor<?x256xf32> {
      %0 = tessera.matmul %arg0, %arg1 {output_dtype = "fp32", rhs_storage_order = "row_major", schedule.artifact_binding = "matmul-0", schedule.artifact_hash = "e76e5c558c6908beddddcbaf5fe7a58a259961d0f6ab603e4ebba934222d91cb", shape_bounds = [256, 256, 4096], tessera.effect_kind = "pure"} : (tensor<?x4096xf16>, tensor<4096x256xf16>) -> tensor<?x256xf32>
      %1 = schedule.matmul %0 {a_layout = "row_major", accum = "f32", activation = "none", arch = "sm_120", artifact_binding = "matmul-0", artifact_hash = "e76e5c558c6908beddddcbaf5fe7a58a259961d0f6ab603e4ebba934222d91cb", b_layout = "row_major", bias = false, macro_tile_m = 128 : i64, macro_tile_n = 128 : i64, output = "f32", pipeline_depth = 1 : i64, raster_group = 1 : i64, raster_order = "row_major", residual = false, storage = "f16", tile_k = 16 : i64, tile_m = 16 : i64, tile_n = 8 : i64, warps = 1 : i64} : tensor<?x256xf32> -> tensor<?x256xf32>
      schedule.artifact {arch = "sm_120", binding = "matmul-0", hash = "e76e5c558c6908beddddcbaf5fe7a58a259961d0f6ab603e4ebba934222d91cb", numeric_policy = "f16->f32", shape_key = "M=256;N=256;K=4096;dtype=f16", tile = {k = 16 : i64, m = 16 : i64, macro_m = 128 : i64, macro_n = 128 : i64, n = 8 : i64, pipeline_depth = 1 : i64, warps = 1 : i64}}
      return %1 : tensor<?x256xf32>
    }
  }
}

