module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program_frame_json = "eyJhcmNoaXRlY3R1cmUiOiJzbV8xMjAiLCJidWZmZXJzIjpbeyJieXRlcyI6MjA5NzE1MiwiaWQiOjAsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbMjU2LDQwOTZdLCJzdG9yYWdlIjoiYmYxNiJ9LHsiYnl0ZXMiOjIwOTcxNTIsImlkIjoxLCJyb2xlIjoiaW5wdXQiLCJzaGFwZSI6WzI1Niw0MDk2XSwic3RvcmFnZSI6ImJmMTYifSx7ImJ5dGVzIjoyMDk3MTUyLCJpZCI6Miwicm9sZSI6ImlucHV0Iiwic2hhcGUiOls0MDk2LDI1Nl0sInN0b3JhZ2UiOiJiZjE2In0seyJieXRlcyI6MjA5NzE1MiwiaWQiOjMsInJvbGUiOiJwcml2YXRlIiwic2hhcGUiOlsyNTYsNDA5Nl0sInN0b3JhZ2UiOiJiZjE2In0seyJieXRlcyI6MjYyMTQ0LCJpZCI6NCwicm9sZSI6Im91dHB1dCIsInNoYXBlIjpbMjU2LDI1Nl0sInN0b3JhZ2UiOiJmMzIifV0sImZ1bmN0aW9uIjoibGhzX2FkZCIsIm91dHB1dCI6NCwicm9vdHMiOlswLDEsMl0sInJvd19ib3VuZCI6MjU2LCJyb3dfYnVmZmVycyI6WzEsMSwwLDEsMV0sInJvd19yb290IjowLCJzY2hlbWEiOiJ0ZXNzZXJhLm5hdGl2ZS50ZW5zb3JfcHJvZ3JhbV9mcmFtZS52MiIsInN0YWdlcyI6W3siZW50cnkiOiJ0ZXNzZXJhX3RpbGVfYmluYXJ5X2FkZF9iZjE2XzQ1YjYwN2UwNjIiLCJnZW9tZXRyeSI6WzgxOTIsMSwxLDEyOCwxLDFdLCJncmlkX3Jvd19kaXZpc29ycyI6WzEyOCwxLDFdLCJncmlkX3Jvd19tdWx0aXBsaWVycyI6WzQwOTYsMCwwXSwiaW5wdXRzIjpbMCwxXSwibWVtYmVyIjoidGVuc29yX3N0YWdlXzAiLCJvdXRwdXQiOjMsInNjYWxhcl9yb3dfbXVsdGlwbGllcnMiOls0MDk2XSwic2NhbGFycyI6WzEwNDg1NzZdfSx7ImVudHJ5Ijoic291cmNlX3Jvd19yaHNfa2VybmVsIiwiZ2VvbWV0cnkiOlszMiwxNiwxLDMyLDEsMV0sImdyaWRfcm93X2Rpdmlzb3JzIjpbMSwxNiwxXSwiZ3JpZF9yb3dfbXVsdGlwbGllcnMiOlswLDEsMF0sImlucHV0cyI6WzMsMl0sIm1lbWJlciI6InRlbnNvcl9zdGFnZV8xIiwib3V0cHV0Ijo0LCJzY2FsYXJfcm93X211bHRpcGxpZXJzIjpbMSwwLDAsMCwwLDBdLCJzY2FsYXJzIjpbMjU2LDI1Niw0MDk2LDQwOTYsMjU2LDI1Nl19XSwidGFyZ2V0IjoibnZpZGlhX3NtMTIwIn0=", tessera.native.tensor_program_member, tessera.native.tensor_program_member_index = 0 : i64, tessera.native.tensor_program_row_bound = 256 : i64, tessera.target = "nvidia_sm120"} {
  llvm.func @tessera_tile_binary_add_bf16_45b607e062(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr, %arg3: i64) attributes {nvvm.kernel, nvvm.reqntid = array<i32: 128, 1, 1>, tessera.native.elementwise_contract = {accum = "f32", elements = 1048576 : i64, kind = "add", output_storage = "bf16", storage = "bf16"}, tessera.native.program_active_buffer_types = [memref<?x4096xbf16>, memref<?x4096xbf16>, memref<?x4096xbf16>], tessera.native.program_buffer_types = [memref<256x4096xbf16>, memref<256x4096xbf16>, memref<256x4096xbf16>], tessera.native.program_geometry = array<i64: 8192, 1, 1, 128, 1, 1>, tessera.native.program_grid_row_divisors = array<i64: 128, 1, 1>, tessera.native.program_grid_row_multipliers = array<i64: 4096, 0, 0>, tessera.native.program_scalar_row_multipliers = array<i64: 4096>, tessera.native.program_scalars = array<i64: 1048576>} {
    %0 = nvvm.read.ptx.sreg.ctaid.x : i32
    %1 = arith.extui %0 : i32 to i64
    %2 = nvvm.read.ptx.sreg.tid.x : i32
    %3 = arith.extui %2 : i32 to i64
    %c128_i64 = arith.constant 128 : i64
    %4 = arith.muli %1, %c128_i64 : i64
    %5 = arith.addi %4, %3 : i64
    %6 = arith.cmpi ult, %5, %arg3 : i64
    scf.if %6 {
      %7 = llvm.getelementptr %arg0[%5] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
      %8 = llvm.load %7 {alignment = 2 : i64} : !llvm.ptr -> bf16
      %9 = llvm.fpext %8 : bf16 to f32
      %10 = llvm.getelementptr %arg1[%5] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
      %11 = llvm.load %10 {alignment = 2 : i64} : !llvm.ptr -> bf16
      %12 = llvm.fpext %11 : bf16 to f32
      %13 = arith.addf %9, %12 : f32
      %14 = llvm.fptrunc %13 : f32 to bf16
      %15 = llvm.getelementptr %arg2[%5] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
      llvm.store %14, %15 {alignment = 2 : i64} : bf16, !llvm.ptr
    }
    llvm.return
  }
}

