module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program_frame_json = "eyJhcmNoaXRlY3R1cmUiOiJzbV8xMjAiLCJidWZmZXJzIjpbeyJieXRlcyI6MjA5NzE1MiwiaWQiOjAsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbMjU2LDQwOTZdLCJzdG9yYWdlIjoiZjE2In0seyJieXRlcyI6MjA5NzE1MiwiaWQiOjEsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbMjU2LDQwOTZdLCJzdG9yYWdlIjoiZjE2In0seyJieXRlcyI6MjA5NzE1MiwiaWQiOjIsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbNDA5NiwyNTZdLCJzdG9yYWdlIjoiZjE2In0seyJieXRlcyI6MjA5NzE1MiwiaWQiOjMsInJvbGUiOiJwcml2YXRlIiwic2hhcGUiOlsyNTYsNDA5Nl0sInN0b3JhZ2UiOiJmMTYifSx7ImJ5dGVzIjoyNjIxNDQsImlkIjo0LCJyb2xlIjoib3V0cHV0Iiwic2hhcGUiOlsyNTYsMjU2XSwic3RvcmFnZSI6ImYzMiJ9XSwiZnVuY3Rpb24iOiJsaHNfYWRkIiwib3V0cHV0Ijo0LCJyb290cyI6WzAsMSwyXSwicm93X2JvdW5kIjoyNTYsInJvd19idWZmZXJzIjpbMSwxLDAsMSwxXSwicm93X3Jvb3QiOjAsInNjaGVtYSI6InRlc3NlcmEubmF0aXZlLnRlbnNvcl9wcm9ncmFtX2ZyYW1lLnYyIiwic3RhZ2VzIjpbeyJlbnRyeSI6InRlc3NlcmFfdGlsZV9iaW5hcnlfYWRkX2YxNl8wZTM3NDQ1YTI0IiwiZ2VvbWV0cnkiOls4MTkyLDEsMSwxMjgsMSwxXSwiZ3JpZF9yb3dfZGl2aXNvcnMiOlsxMjgsMSwxXSwiZ3JpZF9yb3dfbXVsdGlwbGllcnMiOls0MDk2LDAsMF0sImlucHV0cyI6WzAsMV0sIm1lbWJlciI6InRlbnNvcl9zdGFnZV8wIiwib3V0cHV0IjozLCJzY2FsYXJfcm93X211bHRpcGxpZXJzIjpbNDA5Nl0sInNjYWxhcnMiOlsxMDQ4NTc2XX0seyJlbnRyeSI6InNvdXJjZV9yb3dfcmhzX2tlcm5lbCIsImdlb21ldHJ5IjpbMzIsMTYsMSwzMiwxLDFdLCJncmlkX3Jvd19kaXZpc29ycyI6WzEsMTYsMV0sImdyaWRfcm93X211bHRpcGxpZXJzIjpbMCwxLDBdLCJpbnB1dHMiOlszLDJdLCJtZW1iZXIiOiJ0ZW5zb3Jfc3RhZ2VfMSIsIm91dHB1dCI6NCwic2NhbGFyX3Jvd19tdWx0aXBsaWVycyI6WzEsMCwwLDAsMCwwXSwic2NhbGFycyI6WzI1NiwyNTYsNDA5Niw0MDk2LDI1NiwyNTZdfV0sInRhcmdldCI6Im52aWRpYV9zbTEyMCJ9", tessera.native.tensor_program_member, tessera.native.tensor_program_member_index = 0 : i64, tessera.native.tensor_program_row_bound = 256 : i64, tessera.target = "nvidia_sm120"} {
  llvm.func @tessera_tile_binary_add_f16_0e37445a24(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr, %arg3: i64) attributes {nvvm.kernel, nvvm.reqntid = array<i32: 128, 1, 1>, tessera.native.elementwise_contract = {accum = "f32", elements = 1048576 : i64, kind = "add", output_storage = "f16", storage = "f16"}, tessera.native.program_active_buffer_types = [memref<?x4096xf16>, memref<?x4096xf16>, memref<?x4096xf16>], tessera.native.program_buffer_types = [memref<256x4096xf16>, memref<256x4096xf16>, memref<256x4096xf16>], tessera.native.program_geometry = array<i64: 8192, 1, 1, 128, 1, 1>, tessera.native.program_grid_row_divisors = array<i64: 128, 1, 1>, tessera.native.program_grid_row_multipliers = array<i64: 4096, 0, 0>, tessera.native.program_scalar_row_multipliers = array<i64: 4096>, tessera.native.program_scalars = array<i64: 1048576>} {
    %0 = nvvm.read.ptx.sreg.ctaid.x : i32
    %1 = arith.extui %0 : i32 to i64
    %2 = nvvm.read.ptx.sreg.tid.x : i32
    %3 = arith.extui %2 : i32 to i64
    %c128_i64 = arith.constant 128 : i64
    %4 = arith.muli %1, %c128_i64 : i64
    %5 = arith.addi %4, %3 : i64
    %6 = arith.cmpi ult, %5, %arg3 : i64
    scf.if %6 {
      %7 = llvm.getelementptr %arg0[%5] : (!llvm.ptr, i64) -> !llvm.ptr, f16
      %8 = llvm.load %7 {alignment = 2 : i64} : !llvm.ptr -> f16
      %9 = llvm.fpext %8 : f16 to f32
      %10 = llvm.getelementptr %arg1[%5] : (!llvm.ptr, i64) -> !llvm.ptr, f16
      %11 = llvm.load %10 {alignment = 2 : i64} : !llvm.ptr -> f16
      %12 = llvm.fpext %11 : f16 to f32
      %13 = arith.addf %9, %12 : f32
      %14 = llvm.fptrunc %13 : f32 to f16
      %15 = llvm.getelementptr %arg2[%5] : (!llvm.ptr, i64) -> !llvm.ptr, f16
      llvm.store %14, %15 {alignment = 2 : i64} : f16, !llvm.ptr
    }
    llvm.return
  }
}

