module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program_row_bound_request = 256 : i64, tessera.target = "nvidia_sm120"} {
  func.func @lhs_add(%arg0: tensor<17x4096xf16>, %arg1: tensor<17x4096xf16>, %arg2: tensor<4096x256xf16>) -> tensor<17x256xf32> attributes {tessera.frontend.authority = "tracer", tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "0900f4bdf92ef1a013aff09c5067a47d259e5648534c208628af1a08482139b7", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %0 = tessera.add %arg0, %arg1 {tessera.effect_kind = "pure"} : (tensor<17x4096xf16>, tensor<17x4096xf16>) -> tensor<17x4096xf16>
    %1 = tessera.matmul %0, %arg2 {output_dtype = "fp32", tessera.effect_kind = "pure"} : (tensor<17x4096xf16>, tensor<4096x256xf16>) -> tensor<17x256xf32>
    return %1 : tensor<17x256xf32>
  }
}

