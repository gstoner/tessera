module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program = 2 : i64, tessera.native.tensor_program_frame_json = "eyJhcmNoaXRlY3R1cmUiOiJzbV8xMjAiLCJidWZmZXJzIjpbeyJieXRlcyI6MjA5NzE1MiwiaWQiOjAsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbMjU2LDQwOTZdLCJzdG9yYWdlIjoiZjE2In0seyJieXRlcyI6MjA5NzE1MiwiaWQiOjEsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbMjU2LDQwOTZdLCJzdG9yYWdlIjoiZjE2In0seyJieXRlcyI6MjA5NzE1MiwiaWQiOjIsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbNDA5NiwyNTZdLCJzdG9yYWdlIjoiZjE2In0seyJieXRlcyI6MjA5NzE1MiwiaWQiOjMsInJvbGUiOiJwcml2YXRlIiwic2hhcGUiOlsyNTYsNDA5Nl0sInN0b3JhZ2UiOiJmMTYifSx7ImJ5dGVzIjoyNjIxNDQsImlkIjo0LCJyb2xlIjoib3V0cHV0Iiwic2hhcGUiOlsyNTYsMjU2XSwic3RvcmFnZSI6ImYzMiJ9XSwiZnVuY3Rpb24iOiJsaHNfYWRkIiwib3V0cHV0Ijo0LCJyb290cyI6WzAsMSwyXSwicm93X2JvdW5kIjoyNTYsInJvd19idWZmZXJzIjpbMSwxLDAsMSwxXSwicm93X3Jvb3QiOjAsInNjaGVtYSI6InRlc3NlcmEubmF0aXZlLnRlbnNvcl9wcm9ncmFtX2ZyYW1lLnYyIiwic3RhZ2VzIjpbeyJlbnRyeSI6InRlc3NlcmFfdGlsZV9iaW5hcnlfYWRkX2YxNl8wZTM3NDQ1YTI0IiwiZ2VvbWV0cnkiOls4MTkyLDEsMSwxMjgsMSwxXSwiZ3JpZF9yb3dfZGl2aXNvcnMiOlsxMjgsMSwxXSwiZ3JpZF9yb3dfbXVsdGlwbGllcnMiOls0MDk2LDAsMF0sImlucHV0cyI6WzAsMV0sIm1lbWJlciI6InRlbnNvcl9zdGFnZV8wIiwib3V0cHV0IjozLCJzY2FsYXJfcm93X211bHRpcGxpZXJzIjpbNDA5Nl0sInNjYWxhcnMiOlsxMDQ4NTc2XX0seyJlbnRyeSI6InNvdXJjZV9yb3dfcmhzX2tlcm5lbCIsImdlb21ldHJ5IjpbMzIsMTYsMSwzMiwxLDFdLCJncmlkX3Jvd19kaXZpc29ycyI6WzEsMTYsMV0sImdyaWRfcm93X211bHRpcGxpZXJzIjpbMCwxLDBdLCJpbnB1dHMiOlszLDJdLCJtZW1iZXIiOiJ0ZW5zb3Jfc3RhZ2VfMSIsIm91dHB1dCI6NCwic2NhbGFyX3Jvd19tdWx0aXBsaWVycyI6WzEsMCwwLDAsMCwwXSwic2NhbGFycyI6WzI1NiwyNTYsNDA5Niw0MDk2LDI1NiwyNTZdfV0sInRhcmdldCI6Im52aWRpYV9zbTEyMCJ9", tessera.native.tensor_program_row_bound = 256 : i64, tessera.native.tensor_program_row_buffers = array<i64: 1, 1, 0, 1, 1>, tessera.native.tensor_program_row_root = 0 : i64, tessera.native.tensor_program_source = "module attributes {tessera.arch = \22sm_120\22, tessera.frontend.authority = \22tracer\22, tessera.ir.version = \221.0\22, tessera.native.tensor_program_row_bound_request = 256 : i64, tessera.target = \22nvidia_sm120\22} {\0A  func.func @lhs_add(%arg0: tensor<17x4096xf16>, %arg1: tensor<17x4096xf16>, %arg2: tensor<4096x256xf16>) -> tensor<17x256xf32> attributes {tessera.frontend.authority = \22tracer\22, tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = \220900f4bdf92ef1a013aff09c5067a47d259e5648534c208628af1a08482139b7\22, tessera.structured_cfg.schema = \22tessera.structured_cfg.v1\22} {\0A    %0 = tessera.add %arg0, %arg1 {tessera.effect_kind = \22pure\22} : (tensor<17x4096xf16>, tensor<17x4096xf16>) -> tensor<17x4096xf16>\0A    %1 = tessera.matmul %0, %arg2 {output_dtype = \22fp32\22, tessera.effect_kind = \22pure\22} : (tensor<17x4096xf16>, tensor<4096x256xf16>) -> tensor<17x256xf32>\0A    return %1 : tensor<17x256xf32>\0A  }\0A}", tessera.native.tensor_program_source_sha256 = "d51cdb00840e2ae45c8636a17c6ae102bb33418fde3a826bf64b17b06f68013f", tessera.native.tensor_program_target = "nvidia_sm120", tessera.nvidia.arch = "sm_120", tessera.target = "nvidia_sm120"} {
  func.func @lhs_add(%arg0: memref<256x4096xf16>, %arg1: memref<256x4096xf16>, %arg2: memref<4096x256xf16>) -> memref<256x256xf32> attributes {tessera.frontend.authority = "tracer", tessera.native.tensor_program = 2 : i64, tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "0900f4bdf92ef1a013aff09c5067a47d259e5648534c208628af1a08482139b7", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %alloc = memref.alloc() : memref<256x4096xf16>
    tessera_nvidia.program_invoke %arg0, %arg1, %alloc {arch = "sm_120", callee = @tensor_stage_0::@tessera_tile_binary_add_f16_0e37445a24, geometry = array<i64: 8192, 1, 1, 128, 1, 1>, grid_row_divisors = array<i64: 128, 1, 1>, grid_row_multipliers = array<i64: 4096, 0, 0>, input_count = 2 : i64, scalar_row_multipliers = array<i64: 4096>, scalars = array<i64: 1048576>, source_attributes = {tessera.effect_kind = "pure"}} : memref<256x4096xf16>, memref<256x4096xf16>, memref<256x4096xf16>
    %alloc_0 = memref.alloc() : memref<256x256xf32>
    tessera_nvidia.program_invoke %alloc, %arg2, %alloc_0 {arch = "sm_120", callee = @tensor_stage_1::@source_row_rhs_kernel, geometry = array<i64: 32, 16, 1, 32, 1, 1>, grid_row_divisors = array<i64: 1, 16, 1>, grid_row_multipliers = array<i64: 0, 1, 0>, input_count = 2 : i64, scalar_row_multipliers = array<i64: 1, 0, 0, 0, 0, 0>, scalars = array<i64: 256, 256, 4096, 4096, 256, 256>, source_attributes = {output_dtype = "fp32", shape_bounds = [256, 256, 4096], tessera.effect_kind = "pure", transposeA = false, transposeB = false}} : memref<256x4096xf16>, memref<4096x256xf16>, memref<256x256xf32>
    memref.dealloc %alloc : memref<256x4096xf16>
    return %alloc_0 : memref<256x256xf32>
  }
  module @tensor_stage_0 attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.native.tensor_program_member, tessera.native.tensor_program_row_bound = 256 : i64, tessera.target = "nvidia_sm120"} {
    llvm.func @tessera_tile_binary_add_f16_0e37445a24(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr, %arg3: i64) attributes {nvvm.kernel, nvvm.reqntid = array<i32: 128, 1, 1>, tessera.native.elementwise_contract = {accum = "f32", elements = 1048576 : i64, kind = "add", output_storage = "f16", storage = "f16"}, tessera.native.program_active_buffer_types = [memref<?x4096xf16>, memref<?x4096xf16>, memref<?x4096xf16>], tessera.native.program_buffer_types = [memref<256x4096xf16>, memref<256x4096xf16>, memref<256x4096xf16>], tessera.native.program_geometry = array<i64: 8192, 1, 1, 128, 1, 1>, tessera.native.program_grid_row_divisors = array<i64: 128, 1, 1>, tessera.native.program_grid_row_multipliers = array<i64: 4096, 0, 0>, tessera.native.program_scalar_row_multipliers = array<i64: 4096>, tessera.native.program_scalars = array<i64: 1048576>} {
      %0 = nvvm.read.ptx.sreg.ctaid.x : i32
      %1 = arith.extui %0 : i32 to i64
      %2 = nvvm.read.ptx.sreg.tid.x : i32
      %3 = arith.extui %2 : i32 to i64
      %c128_i64 = arith.constant 128 : i64
      %4 = arith.muli %1, %c128_i64 : i64
      %5 = arith.addi %4, %3 : i64
      %6 = arith.cmpi ult, %5, %arg3 : i64
      scf.if %6 {
        %7 = llvm.getelementptr %arg0[%5] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %8 = llvm.load %7 {alignment = 2 : i64} : !llvm.ptr -> f16
        %9 = llvm.fpext %8 : f16 to f32
        %10 = llvm.getelementptr %arg1[%5] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %11 = llvm.load %10 {alignment = 2 : i64} : !llvm.ptr -> f16
        %12 = llvm.fpext %11 : f16 to f32
        %13 = arith.addf %9, %12 : f32
        %14 = llvm.fptrunc %13 : f32 to f16
        %15 = llvm.getelementptr %arg2[%5] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        llvm.store %14, %15 {alignment = 2 : i64} : f16, !llvm.ptr
      }
      llvm.return
    }
  }
  module @tensor_stage_1 attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.lowering.dropped = {layout = "consumed_by_pass"}, tessera.native.tensor_program_member, tessera.native.tensor_program_row_bound = 256 : i64, tessera.target = "nvidia_sm120"} {
    llvm.func @source_row_rhs_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64) attributes {nvvm.kernel, tessera.native.program_active_buffer_types = [memref<?x4096xf16>, memref<4096x256xf16>, memref<?x256xf32>], tessera.native.program_buffer_types = [memref<256x4096xf16>, memref<4096x256xf16>, memref<256x256xf32>], tessera.native.program_geometry = array<i64: 32, 16, 1, 32, 1, 1>, tessera.native.program_grid_row_divisors = array<i64: 1, 16, 1>, tessera.native.program_grid_row_multipliers = array<i64: 0, 1, 0>, tessera.native.program_scalar_row_multipliers = array<i64: 1, 0, 0, 0, 0, 0>, tessera.native.program_scalars = array<i64: 256, 256, 4096, 4096, 256, 256>} {
      %c0_i64 = arith.constant 0 : i64
      %0 = nvvm.read.ptx.sreg.ctaid.x : i32
      %1 = arith.extui %0 : i32 to i64
      %2 = nvvm.read.ptx.sreg.ctaid.y : i32
      %3 = arith.extui %2 : i32 to i64
      %c16_i64 = arith.constant 16 : i64
      %4 = arith.muli %3, %c16_i64 : i64
      %c8_i64 = arith.constant 8 : i64
      %5 = arith.muli %1, %c8_i64 : i64
      %cst = arith.constant 0.000000e+00 : f32
      %cst_0 = arith.constant 0.000000e+00 : f32
      %cst_1 = arith.constant 0.000000e+00 : f32
      %cst_2 = arith.constant 0.000000e+00 : f32
      %6 = llvm.mlir.undef : !llvm.struct<(f32, f32, f32, f32)>
      %7 = llvm.insertvalue %cst, %6[0] : !llvm.struct<(f32, f32, f32, f32)> 
      %8 = llvm.insertvalue %cst_0, %7[1] : !llvm.struct<(f32, f32, f32, f32)> 
      %9 = llvm.insertvalue %cst_1, %8[2] : !llvm.struct<(f32, f32, f32, f32)> 
      %10 = llvm.insertvalue %cst_2, %9[3] : !llvm.struct<(f32, f32, f32, f32)> 
      %c16_i64_3 = arith.constant 16 : i64
      %11 = scf.for %arg9 = %c0_i64 to %arg5 step %c16_i64_3 iter_args(%arg10 = %10) -> (!llvm.struct<(f32, f32, f32, f32)>)  : i64 {
        %c0_i64_6 = arith.constant 0 : i64
        %c0_i64_7 = arith.constant 0 : i64
        %c1_i64_8 = arith.constant 1 : i64
        %59 = arith.muli %4, %c1_i64_8 : i64
        %60 = arith.addi %c0_i64_7, %59 : i64
        %61 = arith.muli %60, %arg6 : i64
        %62 = arith.addi %c0_i64_6, %61 : i64
        %c1_i64_9 = arith.constant 1 : i64
        %c0_i64_10 = arith.constant 0 : i64
        %c1_i64_11 = arith.constant 1 : i64
        %63 = arith.muli %arg9, %c1_i64_11 : i64
        %64 = arith.addi %c0_i64_10, %63 : i64
        %65 = arith.muli %64, %c1_i64_9 : i64
        %66 = arith.addi %62, %65 : i64
        %c0_i64_12 = arith.constant 0 : i64
        %c0_i64_13 = arith.constant 0 : i64
        %c1_i64_14 = arith.constant 1 : i64
        %67 = arith.muli %arg9, %c1_i64_14 : i64
        %68 = arith.addi %c0_i64_13, %67 : i64
        %69 = arith.muli %68, %arg7 : i64
        %70 = arith.addi %c0_i64_12, %69 : i64
        %c1_i64_15 = arith.constant 1 : i64
        %c0_i64_16 = arith.constant 0 : i64
        %c1_i64_17 = arith.constant 1 : i64
        %71 = arith.muli %5, %c1_i64_17 : i64
        %72 = arith.addi %c0_i64_16, %71 : i64
        %73 = arith.muli %72, %c1_i64_15 : i64
        %74 = arith.addi %70, %73 : i64
        %75 = nvvm.read.ptx.sreg.tid.x : i32
        %c31_i32_18 = arith.constant 31 : i32
        %76 = arith.andi %75, %c31_i32_18 : i32
        %c2_i32_19 = arith.constant 2 : i32
        %77 = arith.shrui %76, %c2_i32_19 : i32
        %c3_i32_20 = arith.constant 3 : i32
        %78 = arith.andi %76, %c3_i32_20 : i32
        %79 = arith.extui %77 : i32 to i64
        %80 = arith.extui %78 : i32 to i64
        %c8_i64_21 = arith.constant 8 : i64
        %c2_i64 = arith.constant 2 : i64
        %81 = arith.muli %80, %c2_i64 : i64
        %c8_i64_22 = arith.constant 8 : i64
        %82 = arith.addi %79, %c8_i64_21 : i64
        %83 = arith.addi %81, %c8_i64_22 : i64
        %84 = arith.addi %79, %c8_i64_21 : i64
        %85 = arith.addi %81, %c8_i64_22 : i64
        %86 = arith.addi %4, %79 : i64
        %87 = arith.addi %arg9, %81 : i64
        %88 = arith.muli %79, %arg6 : i64
        %89 = arith.addi %88, %81 : i64
        %90 = arith.addi %66, %89 : i64
        %cst_23 = arith.constant dense<0.000000e+00> : vector<2xf16>
        %c0_i64_24 = arith.constant 0 : i64
        %91 = arith.addi %87, %c0_i64_24 : i64
        %92 = arith.cmpi ult, %91, %arg5 : i64
        %93 = arith.cmpi ult, %86, %arg3 : i64
        %94 = arith.andi %93, %92 : i1
        %95 = arith.addi %81, %c0_i64_24 : i64
        %96 = arith.muli %79, %arg6 : i64
        %97 = arith.addi %96, %95 : i64
        %98 = arith.addi %66, %97 : i64
        %c0_i64_25 = arith.constant 0 : i64
        %99 = arith.select %94, %98, %c0_i64_25 : i64
        %100 = llvm.getelementptr %arg0[%99] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %101 = llvm.load %100 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_26 = arith.constant 0.000000e+00 : f16
        %102 = arith.select %94, %101, %cst_26 : f16
        %c0_i64_27 = arith.constant 0 : i64
        %103 = llvm.insertelement %102, %cst_23[%c0_i64_27 : i64] : vector<2xf16>
        %c1_i64_28 = arith.constant 1 : i64
        %104 = arith.addi %87, %c1_i64_28 : i64
        %105 = arith.cmpi ult, %104, %arg5 : i64
        %106 = arith.cmpi ult, %86, %arg3 : i64
        %107 = arith.andi %106, %105 : i1
        %108 = arith.addi %81, %c1_i64_28 : i64
        %109 = arith.muli %79, %arg6 : i64
        %110 = arith.addi %109, %108 : i64
        %111 = arith.addi %66, %110 : i64
        %c0_i64_29 = arith.constant 0 : i64
        %112 = arith.select %107, %111, %c0_i64_29 : i64
        %113 = llvm.getelementptr %arg0[%112] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %114 = llvm.load %113 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_30 = arith.constant 0.000000e+00 : f16
        %115 = arith.select %107, %114, %cst_30 : f16
        %c1_i64_31 = arith.constant 1 : i64
        %116 = llvm.insertelement %115, %103[%c1_i64_31 : i64] : vector<2xf16>
        %117 = arith.addi %4, %82 : i64
        %118 = arith.addi %arg9, %81 : i64
        %119 = arith.muli %82, %arg6 : i64
        %120 = arith.addi %119, %81 : i64
        %121 = arith.addi %66, %120 : i64
        %cst_32 = arith.constant dense<0.000000e+00> : vector<2xf16>
        %c0_i64_33 = arith.constant 0 : i64
        %122 = arith.addi %118, %c0_i64_33 : i64
        %123 = arith.cmpi ult, %122, %arg5 : i64
        %124 = arith.cmpi ult, %117, %arg3 : i64
        %125 = arith.andi %124, %123 : i1
        %126 = arith.addi %81, %c0_i64_33 : i64
        %127 = arith.muli %82, %arg6 : i64
        %128 = arith.addi %127, %126 : i64
        %129 = arith.addi %66, %128 : i64
        %c0_i64_34 = arith.constant 0 : i64
        %130 = arith.select %125, %129, %c0_i64_34 : i64
        %131 = llvm.getelementptr %arg0[%130] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %132 = llvm.load %131 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_35 = arith.constant 0.000000e+00 : f16
        %133 = arith.select %125, %132, %cst_35 : f16
        %c0_i64_36 = arith.constant 0 : i64
        %134 = llvm.insertelement %133, %cst_32[%c0_i64_36 : i64] : vector<2xf16>
        %c1_i64_37 = arith.constant 1 : i64
        %135 = arith.addi %118, %c1_i64_37 : i64
        %136 = arith.cmpi ult, %135, %arg5 : i64
        %137 = arith.cmpi ult, %117, %arg3 : i64
        %138 = arith.andi %137, %136 : i1
        %139 = arith.addi %81, %c1_i64_37 : i64
        %140 = arith.muli %82, %arg6 : i64
        %141 = arith.addi %140, %139 : i64
        %142 = arith.addi %66, %141 : i64
        %c0_i64_38 = arith.constant 0 : i64
        %143 = arith.select %138, %142, %c0_i64_38 : i64
        %144 = llvm.getelementptr %arg0[%143] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %145 = llvm.load %144 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_39 = arith.constant 0.000000e+00 : f16
        %146 = arith.select %138, %145, %cst_39 : f16
        %c1_i64_40 = arith.constant 1 : i64
        %147 = llvm.insertelement %146, %134[%c1_i64_40 : i64] : vector<2xf16>
        %148 = arith.addi %4, %79 : i64
        %149 = arith.addi %arg9, %83 : i64
        %150 = arith.muli %79, %arg6 : i64
        %151 = arith.addi %150, %83 : i64
        %152 = arith.addi %66, %151 : i64
        %cst_41 = arith.constant dense<0.000000e+00> : vector<2xf16>
        %c0_i64_42 = arith.constant 0 : i64
        %153 = arith.addi %149, %c0_i64_42 : i64
        %154 = arith.cmpi ult, %153, %arg5 : i64
        %155 = arith.cmpi ult, %148, %arg3 : i64
        %156 = arith.andi %155, %154 : i1
        %157 = arith.addi %83, %c0_i64_42 : i64
        %158 = arith.muli %79, %arg6 : i64
        %159 = arith.addi %158, %157 : i64
        %160 = arith.addi %66, %159 : i64
        %c0_i64_43 = arith.constant 0 : i64
        %161 = arith.select %156, %160, %c0_i64_43 : i64
        %162 = llvm.getelementptr %arg0[%161] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %163 = llvm.load %162 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_44 = arith.constant 0.000000e+00 : f16
        %164 = arith.select %156, %163, %cst_44 : f16
        %c0_i64_45 = arith.constant 0 : i64
        %165 = llvm.insertelement %164, %cst_41[%c0_i64_45 : i64] : vector<2xf16>
        %c1_i64_46 = arith.constant 1 : i64
        %166 = arith.addi %149, %c1_i64_46 : i64
        %167 = arith.cmpi ult, %166, %arg5 : i64
        %168 = arith.cmpi ult, %148, %arg3 : i64
        %169 = arith.andi %168, %167 : i1
        %170 = arith.addi %83, %c1_i64_46 : i64
        %171 = arith.muli %79, %arg6 : i64
        %172 = arith.addi %171, %170 : i64
        %173 = arith.addi %66, %172 : i64
        %c0_i64_47 = arith.constant 0 : i64
        %174 = arith.select %169, %173, %c0_i64_47 : i64
        %175 = llvm.getelementptr %arg0[%174] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %176 = llvm.load %175 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_48 = arith.constant 0.000000e+00 : f16
        %177 = arith.select %169, %176, %cst_48 : f16
        %c1_i64_49 = arith.constant 1 : i64
        %178 = llvm.insertelement %177, %165[%c1_i64_49 : i64] : vector<2xf16>
        %179 = arith.addi %4, %84 : i64
        %180 = arith.addi %arg9, %85 : i64
        %181 = arith.muli %84, %arg6 : i64
        %182 = arith.addi %181, %85 : i64
        %183 = arith.addi %66, %182 : i64
        %cst_50 = arith.constant dense<0.000000e+00> : vector<2xf16>
        %c0_i64_51 = arith.constant 0 : i64
        %184 = arith.addi %180, %c0_i64_51 : i64
        %185 = arith.cmpi ult, %184, %arg5 : i64
        %186 = arith.cmpi ult, %179, %arg3 : i64
        %187 = arith.andi %186, %185 : i1
        %188 = arith.addi %85, %c0_i64_51 : i64
        %189 = arith.muli %84, %arg6 : i64
        %190 = arith.addi %189, %188 : i64
        %191 = arith.addi %66, %190 : i64
        %c0_i64_52 = arith.constant 0 : i64
        %192 = arith.select %187, %191, %c0_i64_52 : i64
        %193 = llvm.getelementptr %arg0[%192] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %194 = llvm.load %193 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_53 = arith.constant 0.000000e+00 : f16
        %195 = arith.select %187, %194, %cst_53 : f16
        %c0_i64_54 = arith.constant 0 : i64
        %196 = llvm.insertelement %195, %cst_50[%c0_i64_54 : i64] : vector<2xf16>
        %c1_i64_55 = arith.constant 1 : i64
        %197 = arith.addi %180, %c1_i64_55 : i64
        %198 = arith.cmpi ult, %197, %arg5 : i64
        %199 = arith.cmpi ult, %179, %arg3 : i64
        %200 = arith.andi %199, %198 : i1
        %201 = arith.addi %85, %c1_i64_55 : i64
        %202 = arith.muli %84, %arg6 : i64
        %203 = arith.addi %202, %201 : i64
        %204 = arith.addi %66, %203 : i64
        %c0_i64_56 = arith.constant 0 : i64
        %205 = arith.select %200, %204, %c0_i64_56 : i64
        %206 = llvm.getelementptr %arg0[%205] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %207 = llvm.load %206 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_57 = arith.constant 0.000000e+00 : f16
        %208 = arith.select %200, %207, %cst_57 : f16
        %c1_i64_58 = arith.constant 1 : i64
        %209 = llvm.insertelement %208, %196[%c1_i64_58 : i64] : vector<2xf16>
        %210 = llvm.mlir.undef : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)>
        %211 = llvm.insertvalue %116, %210[0] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %212 = llvm.insertvalue %147, %211[1] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %213 = llvm.insertvalue %178, %212[2] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %214 = llvm.insertvalue %209, %213[3] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %215 = nvvm.read.ptx.sreg.tid.x : i32
        %c31_i32_59 = arith.constant 31 : i32
        %216 = arith.andi %215, %c31_i32_59 : i32
        %c2_i32_60 = arith.constant 2 : i32
        %217 = arith.shrui %216, %c2_i32_60 : i32
        %c3_i32_61 = arith.constant 3 : i32
        %218 = arith.andi %216, %c3_i32_61 : i32
        %219 = arith.extui %217 : i32 to i64
        %220 = arith.extui %218 : i32 to i64
        %c8_i64_62 = arith.constant 8 : i64
        %c2_i64_63 = arith.constant 2 : i64
        %221 = arith.muli %220, %c2_i64_63 : i64
        %c8_i64_64 = arith.constant 8 : i64
        %222 = arith.addi %221, %c8_i64_64 : i64
        %223 = arith.addi %arg9, %221 : i64
        %224 = arith.addi %5, %219 : i64
        %225 = arith.muli %221, %arg7 : i64
        %226 = arith.addi %225, %219 : i64
        %227 = arith.addi %74, %226 : i64
        %cst_65 = arith.constant dense<0.000000e+00> : vector<2xf16>
        %c0_i64_66 = arith.constant 0 : i64
        %228 = arith.addi %223, %c0_i64_66 : i64
        %229 = arith.cmpi ult, %224, %arg4 : i64
        %230 = arith.cmpi ult, %228, %arg5 : i64
        %231 = arith.andi %230, %229 : i1
        %232 = arith.addi %221, %c0_i64_66 : i64
        %233 = arith.muli %232, %arg7 : i64
        %234 = arith.addi %233, %219 : i64
        %235 = arith.addi %74, %234 : i64
        %c0_i64_67 = arith.constant 0 : i64
        %236 = arith.select %231, %235, %c0_i64_67 : i64
        %237 = llvm.getelementptr %arg1[%236] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %238 = llvm.load %237 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_68 = arith.constant 0.000000e+00 : f16
        %239 = arith.select %231, %238, %cst_68 : f16
        %c0_i64_69 = arith.constant 0 : i64
        %240 = llvm.insertelement %239, %cst_65[%c0_i64_69 : i64] : vector<2xf16>
        %c1_i64_70 = arith.constant 1 : i64
        %241 = arith.addi %223, %c1_i64_70 : i64
        %242 = arith.cmpi ult, %224, %arg4 : i64
        %243 = arith.cmpi ult, %241, %arg5 : i64
        %244 = arith.andi %243, %242 : i1
        %245 = arith.addi %221, %c1_i64_70 : i64
        %246 = arith.muli %245, %arg7 : i64
        %247 = arith.addi %246, %219 : i64
        %248 = arith.addi %74, %247 : i64
        %c0_i64_71 = arith.constant 0 : i64
        %249 = arith.select %244, %248, %c0_i64_71 : i64
        %250 = llvm.getelementptr %arg1[%249] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %251 = llvm.load %250 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_72 = arith.constant 0.000000e+00 : f16
        %252 = arith.select %244, %251, %cst_72 : f16
        %c1_i64_73 = arith.constant 1 : i64
        %253 = llvm.insertelement %252, %240[%c1_i64_73 : i64] : vector<2xf16>
        %254 = arith.addi %arg9, %222 : i64
        %255 = arith.addi %5, %219 : i64
        %256 = arith.muli %222, %arg7 : i64
        %257 = arith.addi %256, %219 : i64
        %258 = arith.addi %74, %257 : i64
        %cst_74 = arith.constant dense<0.000000e+00> : vector<2xf16>
        %c0_i64_75 = arith.constant 0 : i64
        %259 = arith.addi %254, %c0_i64_75 : i64
        %260 = arith.cmpi ult, %255, %arg4 : i64
        %261 = arith.cmpi ult, %259, %arg5 : i64
        %262 = arith.andi %261, %260 : i1
        %263 = arith.addi %222, %c0_i64_75 : i64
        %264 = arith.muli %263, %arg7 : i64
        %265 = arith.addi %264, %219 : i64
        %266 = arith.addi %74, %265 : i64
        %c0_i64_76 = arith.constant 0 : i64
        %267 = arith.select %262, %266, %c0_i64_76 : i64
        %268 = llvm.getelementptr %arg1[%267] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %269 = llvm.load %268 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_77 = arith.constant 0.000000e+00 : f16
        %270 = arith.select %262, %269, %cst_77 : f16
        %c0_i64_78 = arith.constant 0 : i64
        %271 = llvm.insertelement %270, %cst_74[%c0_i64_78 : i64] : vector<2xf16>
        %c1_i64_79 = arith.constant 1 : i64
        %272 = arith.addi %254, %c1_i64_79 : i64
        %273 = arith.cmpi ult, %255, %arg4 : i64
        %274 = arith.cmpi ult, %272, %arg5 : i64
        %275 = arith.andi %274, %273 : i1
        %276 = arith.addi %222, %c1_i64_79 : i64
        %277 = arith.muli %276, %arg7 : i64
        %278 = arith.addi %277, %219 : i64
        %279 = arith.addi %74, %278 : i64
        %c0_i64_80 = arith.constant 0 : i64
        %280 = arith.select %275, %279, %c0_i64_80 : i64
        %281 = llvm.getelementptr %arg1[%280] : (!llvm.ptr, i64) -> !llvm.ptr, f16
        %282 = llvm.load %281 {alignment = 2 : i64} : !llvm.ptr -> f16
        %cst_81 = arith.constant 0.000000e+00 : f16
        %283 = arith.select %275, %282, %cst_81 : f16
        %c1_i64_82 = arith.constant 1 : i64
        %284 = llvm.insertelement %283, %271[%c1_i64_82 : i64] : vector<2xf16>
        %285 = llvm.mlir.undef : !llvm.struct<(vector<2xf16>, vector<2xf16>)>
        %286 = llvm.insertvalue %253, %285[0] : !llvm.struct<(vector<2xf16>, vector<2xf16>)> 
        %287 = llvm.insertvalue %284, %286[1] : !llvm.struct<(vector<2xf16>, vector<2xf16>)> 
        %288 = llvm.extractvalue %214[0] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %289 = llvm.extractvalue %214[1] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %290 = llvm.extractvalue %214[2] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %291 = llvm.extractvalue %214[3] : !llvm.struct<(vector<2xf16>, vector<2xf16>, vector<2xf16>, vector<2xf16>)> 
        %292 = llvm.extractvalue %287[0] : !llvm.struct<(vector<2xf16>, vector<2xf16>)> 
        %293 = llvm.extractvalue %287[1] : !llvm.struct<(vector<2xf16>, vector<2xf16>)> 
        %294 = llvm.extractvalue %arg10[0] : !llvm.struct<(f32, f32, f32, f32)> 
        %295 = llvm.extractvalue %arg10[1] : !llvm.struct<(f32, f32, f32, f32)> 
        %296 = llvm.extractvalue %arg10[2] : !llvm.struct<(f32, f32, f32, f32)> 
        %297 = llvm.extractvalue %arg10[3] : !llvm.struct<(f32, f32, f32, f32)> 
        %298 = nvvm.mma.sync A[%288, %289, %290, %291]  B[%292, %293]  C[%294, %295, %296, %297]  {layoutA = #nvvm.mma_layout<row>, layoutB = #nvvm.mma_layout<col>, shape = #nvvm.shape<m = 16, n = 8, k = 16>} : (vector<2xf16>, vector<2xf16>, f32) -> !llvm.struct<(f32, f32, f32, f32)>
        scf.yield %298 : !llvm.struct<(f32, f32, f32, f32)>
      }
      %12 = nvvm.read.ptx.sreg.tid.x : i32
      %c31_i32 = arith.constant 31 : i32
      %13 = arith.andi %12, %c31_i32 : i32
      %c2_i32 = arith.constant 2 : i32
      %14 = arith.shrui %13, %c2_i32 : i32
      %c3_i32 = arith.constant 3 : i32
      %15 = arith.andi %13, %c3_i32 : i32
      %c2_i32_4 = arith.constant 2 : i32
      %16 = arith.muli %15, %c2_i32_4 : i32
      %17 = arith.extui %14 : i32 to i64
      %18 = arith.extui %16 : i32 to i64
      %c1_i64 = arith.constant 1 : i64
      %c8_i64_5 = arith.constant 8 : i64
      %19 = arith.addi %18, %c1_i64 : i64
      %20 = arith.addi %17, %c8_i64_5 : i64
      %21 = arith.addi %17, %c8_i64_5 : i64
      %22 = arith.addi %18, %c1_i64 : i64
      %23 = arith.addi %4, %17 : i64
      %24 = arith.addi %5, %18 : i64
      %25 = arith.muli %23, %arg8 : i64
      %26 = arith.addi %25, %24 : i64
      %27 = llvm.getelementptr %arg2[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %28 = llvm.extractvalue %11[0] : !llvm.struct<(f32, f32, f32, f32)> 
      %29 = arith.cmpi ult, %24, %arg4 : i64
      %30 = arith.cmpi ult, %23, %arg3 : i64
      %31 = arith.andi %30, %29 : i1
      scf.if %31 {
        llvm.store %28, %27 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      %32 = arith.addi %4, %17 : i64
      %33 = arith.addi %5, %19 : i64
      %34 = arith.muli %32, %arg8 : i64
      %35 = arith.addi %34, %33 : i64
      %36 = llvm.getelementptr %arg2[%35] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %37 = llvm.extractvalue %11[1] : !llvm.struct<(f32, f32, f32, f32)> 
      %38 = arith.cmpi ult, %33, %arg4 : i64
      %39 = arith.cmpi ult, %32, %arg3 : i64
      %40 = arith.andi %39, %38 : i1
      scf.if %40 {
        llvm.store %37, %36 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      %41 = arith.addi %4, %20 : i64
      %42 = arith.addi %5, %18 : i64
      %43 = arith.muli %41, %arg8 : i64
      %44 = arith.addi %43, %42 : i64
      %45 = llvm.getelementptr %arg2[%44] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %46 = llvm.extractvalue %11[2] : !llvm.struct<(f32, f32, f32, f32)> 
      %47 = arith.cmpi ult, %42, %arg4 : i64
      %48 = arith.cmpi ult, %41, %arg3 : i64
      %49 = arith.andi %48, %47 : i1
      scf.if %49 {
        llvm.store %46, %45 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      %50 = arith.addi %4, %21 : i64
      %51 = arith.addi %5, %22 : i64
      %52 = arith.muli %50, %arg8 : i64
      %53 = arith.addi %52, %51 : i64
      %54 = llvm.getelementptr %arg2[%53] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %55 = llvm.extractvalue %11[3] : !llvm.struct<(f32, f32, f32, f32)> 
      %56 = arith.cmpi ult, %51, %arg4 : i64
      %57 = arith.cmpi ult, %50, %arg3 : i64
      %58 = arith.andi %57, %56 : i1
      scf.if %58 {
        llvm.store %55, %54 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      llvm.return
    }
  }
}

