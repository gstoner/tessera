module attributes {tessera.arch = "sm_120", tessera.target = "nvidia_sm120",
tessera.native.tensor_program = 1 : i64, tessera.native.tensor_program_target = "nvidia_sm120"} {
func.func private @host() -> memref<1x1xf32> attributes {tessera.native.tensor_program = 1 : i64}
}
