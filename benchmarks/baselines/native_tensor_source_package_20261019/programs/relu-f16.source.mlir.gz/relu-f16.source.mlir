module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.target = "nvidia_sm120"} {
  func.func @relu(%arg0: tensor<17x32xf16>, %arg1: tensor<32x11xf16>) -> tensor<17x11xf32> attributes {tessera.frontend.authority = "tracer", tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "4e57e8782eae35b87f773dc3e829612ba6b24d538cc5d82be6b72fe3f2368023", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %0 = tessera.relu %arg0 {tessera.effect_kind = "pure"} : (tensor<17x32xf16>) -> tensor<17x32xf16>
    %1 = tessera.matmul %0, %arg1 {output_dtype = "fp32", tessera.effect_kind = "pure"} : (tensor<17x32xf16>, tensor<32x11xf16>) -> tensor<17x11xf32>
    return %1 : tensor<17x11xf32>
  }
}

