module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.target = "nvidia_sm120"} {
  func.func @reverse(%arg0: tensor<32x11xf16>, %arg1: tensor<17x32xf16>) -> tensor<17x11xf32> attributes {tessera.frontend.authority = "tracer", tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "6bc07e93e6de19df5ac6bd18cec89d9a54942b97ee6fd788cdede1ae4037cb9e", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %0 = tessera.relu %arg1 {tessera.effect_kind = "pure"} : (tensor<17x32xf16>) -> tensor<17x32xf16>
    %1 = tessera.matmul %0, %arg0 {output_dtype = "fp32", tessera.effect_kind = "pure"} : (tensor<17x32xf16>, tensor<32x11xf16>) -> tensor<17x11xf32>
    return %1 : tensor<17x11xf32>
  }
}

