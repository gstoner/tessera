module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.target = "nvidia_sm120"} {
  func.func @two_sided(%arg0: tensor<17x32xbf16>, %arg1: tensor<32x11xbf16>) -> tensor<17x11xf32> attributes {tessera.frontend.authority = "tracer", tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "a47321b348d47a3c29b13e5b2e20bb5beceb73825169b4291ff54f51abfa5dd2", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %0 = tessera.relu %arg0 {tessera.effect_kind = "pure"} : (tensor<17x32xbf16>) -> tensor<17x32xbf16>
    %1 = tessera.softmax %arg1 {axis = -1 : i64, tessera.effect_kind = "pure"} : (tensor<32x11xbf16>) -> tensor<32x11xbf16>
    %2 = tessera.matmul %0, %1 {output_dtype = "fp32", tessera.effect_kind = "pure"} : (tensor<17x32xbf16>, tensor<32x11xbf16>) -> tensor<17x11xf32>
    return %2 : tensor<17x11xf32>
  }
}

