module attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.metadata_snapshot = {"<module>" = {target = ["\22nvidia_sm120\22", 1]}, two_sided = {layout = ["\22row_major\22", 1]}}, tessera.native.tensor_program = 1 : i64, tessera.native.tensor_program_frame_json = "eyJhcmNoaXRlY3R1cmUiOiJzbV8xMjAiLCJidWZmZXJzIjpbeyJieXRlcyI6MTA4OCwiaWQiOjAsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbMTcsMzJdLCJzdG9yYWdlIjoiYmYxNiJ9LHsiYnl0ZXMiOjcwNCwiaWQiOjEsInJvbGUiOiJpbnB1dCIsInNoYXBlIjpbMzIsMTFdLCJzdG9yYWdlIjoiYmYxNiJ9LHsiYnl0ZXMiOjEwODgsImlkIjoyLCJyb2xlIjoicHJpdmF0ZSIsInNoYXBlIjpbMTcsMzJdLCJzdG9yYWdlIjoiYmYxNiJ9LHsiYnl0ZXMiOjcwNCwiaWQiOjMsInJvbGUiOiJwcml2YXRlIiwic2hhcGUiOlszMiwxMV0sInN0b3JhZ2UiOiJiZjE2In0seyJieXRlcyI6NzQ4LCJpZCI6NCwicm9sZSI6Im91dHB1dCIsInNoYXBlIjpbMTcsMTFdLCJzdG9yYWdlIjoiZjMyIn1dLCJmdW5jdGlvbiI6InR3b19zaWRlZCIsIm91dHB1dCI6NCwicm9vdHMiOlswLDFdLCJzY2hlbWEiOiJ0ZXNzZXJhLm5hdGl2ZS50ZW5zb3JfcHJvZ3JhbV9mcmFtZS52MSIsInN0YWdlcyI6W3siZW50cnkiOiJ0ZXNzZXJhX3RpbGVfYWN0aXZhdGlvbl9yZWx1X2JmMTZfZTA4ZWQ1MmE2NSIsImdlb21ldHJ5IjpbMSwxLDEsMTI4LDEsMV0sImlucHV0cyI6WzBdLCJtZW1iZXIiOiJ0ZW5zb3Jfc3RhZ2VfMCIsIm91dHB1dCI6Miwic2NhbGFycyI6WzE3LDMyXX0seyJlbnRyeSI6InRlc3NlcmFfdGlsZV9zb2Z0bWF4X2JmMTYiLCJnZW9tZXRyeSI6WzEsMSwxLDEyOCwxLDFdLCJpbnB1dHMiOlsxXSwibWVtYmVyIjoidGVuc29yX3N0YWdlXzEiLCJvdXRwdXQiOjMsInNjYWxhcnMiOlszMiwxMV19LHsiZW50cnkiOiJzb3VyY2Vfa2VybmVsIiwiZ2VvbWV0cnkiOlsyLDIsMSwzMiwxLDFdLCJpbnB1dHMiOlsyLDNdLCJtZW1iZXIiOiJ0ZW5zb3Jfc3RhZ2VfMiIsIm91dHB1dCI6NCwic2NhbGFycyI6WzE3LDExLDMyXX1dLCJ0YXJnZXQiOiJudmlkaWFfc20xMjAifQ==", tessera.native.tensor_program_source = "module attributes {tessera.arch = \22sm_120\22, tessera.frontend.authority = \22tracer\22, tessera.ir.version = \221.0\22, tessera.metadata_snapshot = {\22<module>\22 = {target = [\22\\22nvidia_sm120\\22\22, 1]}, two_sided = {layout = [\22\\22row_major\\22\22, 1]}}, tessera.target = \22nvidia_sm120\22} {\0A  func.func @two_sided(%arg0: tensor<17x32xbf16>, %arg1: tensor<32x11xbf16>) -> tensor<17x11xf32> attributes {tessera.effect = \22pure\22, tessera.frontend.authority = \22tracer\22, tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = \22a47321b348d47a3c29b13e5b2e20bb5beceb73825169b4291ff54f51abfa5dd2\22, tessera.structured_cfg.schema = \22tessera.structured_cfg.v1\22} {\0A    %0 = tessera.relu %arg0 {tessera.effect_kind = \22pure\22} : (tensor<17x32xbf16>) -> tensor<17x32xbf16>\0A    %1 = tessera.softmax %arg1 {axis = -1 : i64, tessera.effect_kind = \22pure\22} : (tensor<32x11xbf16>) -> tensor<32x11xbf16>\0A    %2 = tessera.matmul %0, %1 {output_dtype = \22fp32\22, tessera.effect_kind = \22pure\22, tessera.layout = \22row_major\22} : (tensor<17x32xbf16>, tensor<32x11xbf16>) -> tensor<17x11xf32>\0A    return %2 : tensor<17x11xf32>\0A  }\0A}\0A", tessera.native.tensor_program_target = "nvidia_sm120", tessera.nvidia.arch = "sm_120", tessera.target = "nvidia_sm120"} {
  func.func @two_sided(%arg0: memref<17x32xbf16>, %arg1: memref<32x11xbf16>) -> memref<17x11xf32> attributes {tessera.effect = "pure", tessera.frontend.authority = "tracer", tessera.native.tensor_program = 1 : i64, tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "a47321b348d47a3c29b13e5b2e20bb5beceb73825169b4291ff54f51abfa5dd2", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %alloc = memref.alloc() : memref<17x32xbf16>
    tessera_nvidia.program_invoke %arg0, %alloc {arch = "sm_120", callee = @tensor_stage_0::@tessera_tile_activation_relu_bf16_e08ed52a65, geometry = array<i64: 1, 1, 1, 128, 1, 1>, input_count = 1 : i64, scalars = array<i64: 17, 32>, source_attributes = {tessera.effect_kind = "pure"}} : memref<17x32xbf16>, memref<17x32xbf16>
    %alloc_0 = memref.alloc() : memref<32x11xbf16>
    tessera_nvidia.program_invoke %arg1, %alloc_0 {arch = "sm_120", callee = @tensor_stage_1::@tessera_tile_softmax_bf16, geometry = array<i64: 1, 1, 1, 128, 1, 1>, input_count = 1 : i64, scalars = array<i64: 32, 11>, source_attributes = {axis = -1 : i64, tessera.effect_kind = "pure"}} : memref<32x11xbf16>, memref<32x11xbf16>
    %alloc_1 = memref.alloc() : memref<17x11xf32>
    tessera_nvidia.program_invoke %alloc, %alloc_0, %alloc_1 {arch = "sm_120", callee = @tensor_stage_2::@source_kernel, geometry = array<i64: 2, 2, 1, 32, 1, 1>, input_count = 2 : i64, scalars = array<i64: 17, 11, 32>, source_attributes = {output_dtype = "fp32", tessera.effect_kind = "pure", tessera.layout = "row_major", transposeA = false, transposeB = false}, tessera.layout = "row_major"} : memref<17x32xbf16>, memref<32x11xbf16>, memref<17x11xf32>
    memref.dealloc %alloc : memref<17x32xbf16>
    memref.dealloc %alloc_0 : memref<32x11xbf16>
    return %alloc_1 : memref<17x11xf32>
  }
  module @tensor_stage_0 attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.metadata_snapshot = {"<module>" = {target = ["\22nvidia_sm120\22", 1]}, two_sided = {layout = ["\22row_major\22", 1]}}, tessera.native.tensor_program_member, tessera.target = "nvidia_sm120"} {
    llvm.func @tessera_tile_activation_relu_bf16_e08ed52a65(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64) attributes {nvvm.kernel, tessera.native.program_buffer_types = [memref<17x32xbf16>, memref<17x32xbf16>], tessera.native.program_geometry = array<i64: 1, 1, 1, 128, 1, 1>, tessera.native.program_scalars = array<i64: 17, 32>} {
      %0 = nvvm.read.ptx.sreg.ctaid.x : i32
      %1 = arith.extui %0 : i32 to i64
      %2 = nvvm.read.ptx.sreg.tid.x : i32
      %3 = arith.extui %2 : i32 to i64
      %c128_i64 = arith.constant 128 : i64
      %4 = arith.muli %1, %c128_i64 : i64
      %5 = arith.addi %4, %3 : i64
      %6 = arith.cmpi ult, %5, %arg2 : i64
      scf.if %6 {
        %c0_i64 = arith.constant 0 : i64
        %c1_i64 = arith.constant 1 : i64
        scf.for %arg4 = %c0_i64 to %arg3 step %c1_i64  : i64 {
          %7 = arith.muli %5, %arg3 : i64
          %8 = arith.addi %7, %arg4 : i64
          %9 = llvm.getelementptr %arg0[%8] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
          %10 = llvm.getelementptr %arg1[%8] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
          %11 = llvm.load %9 {alignment = 2 : i64} : !llvm.ptr -> bf16
          %12 = llvm.fpext %11 : bf16 to f32
          %cst = arith.constant 0.000000e+00 : f32
          %13 = arith.cmpf olt, %12, %cst : f32
          %14 = llvm.fptrunc %cst : f32 to bf16
          %15 = arith.select %13, %14, %11 : bf16
          llvm.store %15, %10 {alignment = 2 : i64} : bf16, !llvm.ptr
        }
      }
      llvm.return
    }
  }
  module @tensor_stage_1 attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.metadata_snapshot = {"<module>" = {target = ["\22nvidia_sm120\22", 1]}, two_sided = {layout = ["\22row_major\22", 1]}}, tessera.native.tensor_program_member, tessera.target = "nvidia_sm120"} {
    llvm.func @tessera_tile_softmax_bf16(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64) attributes {nvvm.kernel, tessera.native.program_buffer_types = [memref<32x11xbf16>, memref<32x11xbf16>], tessera.native.program_geometry = array<i64: 1, 1, 1, 128, 1, 1>, tessera.native.program_scalars = array<i64: 32, 11>} {
      %0 = nvvm.read.ptx.sreg.ctaid.x : i32
      %1 = arith.extui %0 : i32 to i64
      %2 = nvvm.read.ptx.sreg.tid.x : i32
      %3 = arith.extui %2 : i32 to i64
      %c128_i64 = arith.constant 128 : i64
      %4 = arith.muli %1, %c128_i64 : i64
      %5 = arith.addi %4, %3 : i64
      %6 = arith.cmpi ult, %5, %arg2 : i64
      scf.if %6 {
        %c0_i64 = arith.constant 0 : i64
        %c1_i64 = arith.constant 1 : i64
        %7 = arith.muli %5, %arg3 : i64
        %cst = arith.constant 0xFF800000 : f32
        %8 = scf.for %arg4 = %c0_i64 to %arg3 step %c1_i64 iter_args(%arg5 = %cst) -> (f32)  : i64 {
          %10 = arith.addi %7, %arg4 : i64
          %11 = llvm.getelementptr %arg0[%10] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
          %12 = llvm.load %11 {alignment = 2 : i64} : !llvm.ptr -> bf16
          %13 = llvm.fpext %12 : bf16 to f32
          %14 = arith.maximumf %arg5, %13 : f32
          scf.yield %14 : f32
        }
        %cst_0 = arith.constant 0.000000e+00 : f32
        %9 = scf.for %arg4 = %c0_i64 to %arg3 step %c1_i64 iter_args(%arg5 = %cst_0) -> (f32)  : i64 {
          %10 = arith.addi %7, %arg4 : i64
          %11 = llvm.getelementptr %arg0[%10] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
          %12 = llvm.load %11 {alignment = 2 : i64} : !llvm.ptr -> bf16
          %13 = llvm.fpext %12 : bf16 to f32
          %14 = arith.subf %13, %8 : f32
          %cst_1 = arith.constant 1.44269502 : f32
          %15 = arith.mulf %14, %cst_1 : f32
          %16 = nvvm.ex2 %15 : f32
          %17 = arith.addf %arg5, %16 : f32
          scf.yield %17 : f32
        }
        scf.for %arg4 = %c0_i64 to %arg3 step %c1_i64  : i64 {
          %10 = arith.addi %7, %arg4 : i64
          %11 = llvm.getelementptr %arg0[%10] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
          %12 = llvm.load %11 {alignment = 2 : i64} : !llvm.ptr -> bf16
          %13 = llvm.fpext %12 : bf16 to f32
          %14 = arith.subf %13, %8 : f32
          %cst_1 = arith.constant 1.44269502 : f32
          %15 = arith.mulf %14, %cst_1 : f32
          %16 = nvvm.ex2 %15 : f32
          %17 = arith.divf %16, %9 : f32
          %18 = llvm.fptrunc %17 : f32 to bf16
          %19 = llvm.getelementptr %arg1[%10] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
          llvm.store %18, %19 {alignment = 2 : i64} : bf16, !llvm.ptr
        }
      }
      llvm.return
    }
  }
  module @tensor_stage_2 attributes {tessera.arch = "sm_120", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.lowering.dropped = {layout = "consumed_by_pass"}, tessera.metadata_snapshot = {"<module>" = {target = ["\22nvidia_sm120\22", 1]}, two_sided = {layout = ["\22row_major\22", 1]}}, tessera.native.tensor_program_member, tessera.target = "nvidia_sm120"} {
    llvm.func @source_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr, %arg3: i64, %arg4: i64, %arg5: i64) attributes {nvvm.kernel, tessera.native.program_buffer_types = [memref<17x32xbf16>, memref<32x11xbf16>, memref<17x11xf32>], tessera.native.program_geometry = array<i64: 2, 2, 1, 32, 1, 1>, tessera.native.program_scalars = array<i64: 17, 11, 32>} {
      %c16_i64 = arith.constant 16 : i64
      %c32_i64 = arith.constant 32 : i64
      %c0_i64 = arith.constant 0 : i64
      %0 = nvvm.read.ptx.sreg.ctaid.x : i32
      %1 = arith.extui %0 : i32 to i64
      %2 = nvvm.read.ptx.sreg.ctaid.y : i32
      %3 = arith.extui %2 : i32 to i64
      %c16_i64_0 = arith.constant 16 : i64
      %4 = arith.muli %3, %c16_i64_0 : i64
      %c8_i64 = arith.constant 8 : i64
      %5 = arith.muli %1, %c8_i64 : i64
      %cst = arith.constant 0.000000e+00 : f32
      %cst_1 = arith.constant 0.000000e+00 : f32
      %cst_2 = arith.constant 0.000000e+00 : f32
      %cst_3 = arith.constant 0.000000e+00 : f32
      %6 = llvm.mlir.undef : !llvm.struct<(f32, f32, f32, f32)>
      %7 = llvm.insertvalue %cst, %6[0] : !llvm.struct<(f32, f32, f32, f32)> 
      %8 = llvm.insertvalue %cst_1, %7[1] : !llvm.struct<(f32, f32, f32, f32)> 
      %9 = llvm.insertvalue %cst_2, %8[2] : !llvm.struct<(f32, f32, f32, f32)> 
      %10 = llvm.insertvalue %cst_3, %9[3] : !llvm.struct<(f32, f32, f32, f32)> 
      %11 = scf.for %arg6 = %c0_i64 to %c32_i64 step %c16_i64 iter_args(%arg7 = %10) -> (!llvm.struct<(f32, f32, f32, f32)>)  : i64 {
        %c0_i64_6 = arith.constant 0 : i64
        %c32_i64_7 = arith.constant 32 : i64
        %c0_i64_8 = arith.constant 0 : i64
        %c17_i64 = arith.constant 17 : i64
        %c1_i64_9 = arith.constant 1 : i64
        %59 = arith.muli %4, %c1_i64_9 : i64
        %60 = arith.addi %c0_i64_8, %59 : i64
        %61 = arith.muli %60, %c32_i64_7 : i64
        %62 = arith.addi %c0_i64_6, %61 : i64
        %c1_i64_10 = arith.constant 1 : i64
        %c0_i64_11 = arith.constant 0 : i64
        %c32_i64_12 = arith.constant 32 : i64
        %c1_i64_13 = arith.constant 1 : i64
        %63 = arith.muli %arg6, %c1_i64_13 : i64
        %64 = arith.addi %c0_i64_11, %63 : i64
        %65 = arith.muli %64, %c1_i64_10 : i64
        %66 = arith.addi %62, %65 : i64
        %c0_i64_14 = arith.constant 0 : i64
        %c11_i64_15 = arith.constant 11 : i64
        %c0_i64_16 = arith.constant 0 : i64
        %c32_i64_17 = arith.constant 32 : i64
        %c1_i64_18 = arith.constant 1 : i64
        %67 = arith.muli %arg6, %c1_i64_18 : i64
        %68 = arith.addi %c0_i64_16, %67 : i64
        %69 = arith.muli %68, %c11_i64_15 : i64
        %70 = arith.addi %c0_i64_14, %69 : i64
        %c1_i64_19 = arith.constant 1 : i64
        %c0_i64_20 = arith.constant 0 : i64
        %c11_i64_21 = arith.constant 11 : i64
        %c1_i64_22 = arith.constant 1 : i64
        %71 = arith.muli %5, %c1_i64_22 : i64
        %72 = arith.addi %c0_i64_20, %71 : i64
        %73 = arith.muli %72, %c1_i64_19 : i64
        %74 = arith.addi %70, %73 : i64
        %75 = nvvm.read.ptx.sreg.tid.x : i32
        %c31_i32_23 = arith.constant 31 : i32
        %76 = arith.andi %75, %c31_i32_23 : i32
        %c2_i32_24 = arith.constant 2 : i32
        %77 = arith.shrui %76, %c2_i32_24 : i32
        %c3_i32_25 = arith.constant 3 : i32
        %78 = arith.andi %76, %c3_i32_25 : i32
        %79 = arith.extui %77 : i32 to i64
        %80 = arith.extui %78 : i32 to i64
        %c32_i64_26 = arith.constant 32 : i64
        %c8_i64_27 = arith.constant 8 : i64
        %c2_i64 = arith.constant 2 : i64
        %81 = arith.muli %80, %c2_i64 : i64
        %c8_i64_28 = arith.constant 8 : i64
        %82 = arith.addi %79, %c8_i64_27 : i64
        %83 = arith.addi %81, %c8_i64_28 : i64
        %84 = arith.addi %79, %c8_i64_27 : i64
        %85 = arith.addi %81, %c8_i64_28 : i64
        %86 = arith.addi %4, %79 : i64
        %87 = arith.addi %arg6, %81 : i64
        %88 = arith.muli %79, %c32_i64_26 : i64
        %89 = arith.addi %88, %81 : i64
        %90 = arith.addi %66, %89 : i64
        %cst_29 = arith.constant dense<0.000000e+00> : vector<2xbf16>
        %c0_i64_30 = arith.constant 0 : i64
        %91 = arith.addi %87, %c0_i64_30 : i64
        %92 = arith.cmpi ult, %91, %arg5 : i64
        %93 = arith.cmpi ult, %86, %arg3 : i64
        %94 = arith.andi %93, %92 : i1
        %95 = arith.addi %81, %c0_i64_30 : i64
        %96 = arith.muli %79, %c32_i64_26 : i64
        %97 = arith.addi %96, %95 : i64
        %98 = arith.addi %66, %97 : i64
        %c0_i64_31 = arith.constant 0 : i64
        %99 = arith.select %94, %98, %c0_i64_31 : i64
        %100 = llvm.getelementptr %arg0[%99] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %101 = llvm.load %100 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_32 = arith.constant 0.000000e+00 : bf16
        %102 = arith.select %94, %101, %cst_32 : bf16
        %c0_i64_33 = arith.constant 0 : i64
        %103 = llvm.insertelement %102, %cst_29[%c0_i64_33 : i64] : vector<2xbf16>
        %c1_i64_34 = arith.constant 1 : i64
        %104 = arith.addi %87, %c1_i64_34 : i64
        %105 = arith.cmpi ult, %104, %arg5 : i64
        %106 = arith.cmpi ult, %86, %arg3 : i64
        %107 = arith.andi %106, %105 : i1
        %108 = arith.addi %81, %c1_i64_34 : i64
        %109 = arith.muli %79, %c32_i64_26 : i64
        %110 = arith.addi %109, %108 : i64
        %111 = arith.addi %66, %110 : i64
        %c0_i64_35 = arith.constant 0 : i64
        %112 = arith.select %107, %111, %c0_i64_35 : i64
        %113 = llvm.getelementptr %arg0[%112] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %114 = llvm.load %113 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_36 = arith.constant 0.000000e+00 : bf16
        %115 = arith.select %107, %114, %cst_36 : bf16
        %c1_i64_37 = arith.constant 1 : i64
        %116 = llvm.insertelement %115, %103[%c1_i64_37 : i64] : vector<2xbf16>
        %117 = llvm.bitcast %116 : vector<2xbf16> to i32
        %118 = arith.addi %4, %82 : i64
        %119 = arith.addi %arg6, %81 : i64
        %120 = arith.muli %82, %c32_i64_26 : i64
        %121 = arith.addi %120, %81 : i64
        %122 = arith.addi %66, %121 : i64
        %cst_38 = arith.constant dense<0.000000e+00> : vector<2xbf16>
        %c0_i64_39 = arith.constant 0 : i64
        %123 = arith.addi %119, %c0_i64_39 : i64
        %124 = arith.cmpi ult, %123, %arg5 : i64
        %125 = arith.cmpi ult, %118, %arg3 : i64
        %126 = arith.andi %125, %124 : i1
        %127 = arith.addi %81, %c0_i64_39 : i64
        %128 = arith.muli %82, %c32_i64_26 : i64
        %129 = arith.addi %128, %127 : i64
        %130 = arith.addi %66, %129 : i64
        %c0_i64_40 = arith.constant 0 : i64
        %131 = arith.select %126, %130, %c0_i64_40 : i64
        %132 = llvm.getelementptr %arg0[%131] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %133 = llvm.load %132 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_41 = arith.constant 0.000000e+00 : bf16
        %134 = arith.select %126, %133, %cst_41 : bf16
        %c0_i64_42 = arith.constant 0 : i64
        %135 = llvm.insertelement %134, %cst_38[%c0_i64_42 : i64] : vector<2xbf16>
        %c1_i64_43 = arith.constant 1 : i64
        %136 = arith.addi %119, %c1_i64_43 : i64
        %137 = arith.cmpi ult, %136, %arg5 : i64
        %138 = arith.cmpi ult, %118, %arg3 : i64
        %139 = arith.andi %138, %137 : i1
        %140 = arith.addi %81, %c1_i64_43 : i64
        %141 = arith.muli %82, %c32_i64_26 : i64
        %142 = arith.addi %141, %140 : i64
        %143 = arith.addi %66, %142 : i64
        %c0_i64_44 = arith.constant 0 : i64
        %144 = arith.select %139, %143, %c0_i64_44 : i64
        %145 = llvm.getelementptr %arg0[%144] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %146 = llvm.load %145 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_45 = arith.constant 0.000000e+00 : bf16
        %147 = arith.select %139, %146, %cst_45 : bf16
        %c1_i64_46 = arith.constant 1 : i64
        %148 = llvm.insertelement %147, %135[%c1_i64_46 : i64] : vector<2xbf16>
        %149 = llvm.bitcast %148 : vector<2xbf16> to i32
        %150 = arith.addi %4, %79 : i64
        %151 = arith.addi %arg6, %83 : i64
        %152 = arith.muli %79, %c32_i64_26 : i64
        %153 = arith.addi %152, %83 : i64
        %154 = arith.addi %66, %153 : i64
        %cst_47 = arith.constant dense<0.000000e+00> : vector<2xbf16>
        %c0_i64_48 = arith.constant 0 : i64
        %155 = arith.addi %151, %c0_i64_48 : i64
        %156 = arith.cmpi ult, %155, %arg5 : i64
        %157 = arith.cmpi ult, %150, %arg3 : i64
        %158 = arith.andi %157, %156 : i1
        %159 = arith.addi %83, %c0_i64_48 : i64
        %160 = arith.muli %79, %c32_i64_26 : i64
        %161 = arith.addi %160, %159 : i64
        %162 = arith.addi %66, %161 : i64
        %c0_i64_49 = arith.constant 0 : i64
        %163 = arith.select %158, %162, %c0_i64_49 : i64
        %164 = llvm.getelementptr %arg0[%163] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %165 = llvm.load %164 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_50 = arith.constant 0.000000e+00 : bf16
        %166 = arith.select %158, %165, %cst_50 : bf16
        %c0_i64_51 = arith.constant 0 : i64
        %167 = llvm.insertelement %166, %cst_47[%c0_i64_51 : i64] : vector<2xbf16>
        %c1_i64_52 = arith.constant 1 : i64
        %168 = arith.addi %151, %c1_i64_52 : i64
        %169 = arith.cmpi ult, %168, %arg5 : i64
        %170 = arith.cmpi ult, %150, %arg3 : i64
        %171 = arith.andi %170, %169 : i1
        %172 = arith.addi %83, %c1_i64_52 : i64
        %173 = arith.muli %79, %c32_i64_26 : i64
        %174 = arith.addi %173, %172 : i64
        %175 = arith.addi %66, %174 : i64
        %c0_i64_53 = arith.constant 0 : i64
        %176 = arith.select %171, %175, %c0_i64_53 : i64
        %177 = llvm.getelementptr %arg0[%176] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %178 = llvm.load %177 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_54 = arith.constant 0.000000e+00 : bf16
        %179 = arith.select %171, %178, %cst_54 : bf16
        %c1_i64_55 = arith.constant 1 : i64
        %180 = llvm.insertelement %179, %167[%c1_i64_55 : i64] : vector<2xbf16>
        %181 = llvm.bitcast %180 : vector<2xbf16> to i32
        %182 = arith.addi %4, %84 : i64
        %183 = arith.addi %arg6, %85 : i64
        %184 = arith.muli %84, %c32_i64_26 : i64
        %185 = arith.addi %184, %85 : i64
        %186 = arith.addi %66, %185 : i64
        %cst_56 = arith.constant dense<0.000000e+00> : vector<2xbf16>
        %c0_i64_57 = arith.constant 0 : i64
        %187 = arith.addi %183, %c0_i64_57 : i64
        %188 = arith.cmpi ult, %187, %arg5 : i64
        %189 = arith.cmpi ult, %182, %arg3 : i64
        %190 = arith.andi %189, %188 : i1
        %191 = arith.addi %85, %c0_i64_57 : i64
        %192 = arith.muli %84, %c32_i64_26 : i64
        %193 = arith.addi %192, %191 : i64
        %194 = arith.addi %66, %193 : i64
        %c0_i64_58 = arith.constant 0 : i64
        %195 = arith.select %190, %194, %c0_i64_58 : i64
        %196 = llvm.getelementptr %arg0[%195] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %197 = llvm.load %196 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_59 = arith.constant 0.000000e+00 : bf16
        %198 = arith.select %190, %197, %cst_59 : bf16
        %c0_i64_60 = arith.constant 0 : i64
        %199 = llvm.insertelement %198, %cst_56[%c0_i64_60 : i64] : vector<2xbf16>
        %c1_i64_61 = arith.constant 1 : i64
        %200 = arith.addi %183, %c1_i64_61 : i64
        %201 = arith.cmpi ult, %200, %arg5 : i64
        %202 = arith.cmpi ult, %182, %arg3 : i64
        %203 = arith.andi %202, %201 : i1
        %204 = arith.addi %85, %c1_i64_61 : i64
        %205 = arith.muli %84, %c32_i64_26 : i64
        %206 = arith.addi %205, %204 : i64
        %207 = arith.addi %66, %206 : i64
        %c0_i64_62 = arith.constant 0 : i64
        %208 = arith.select %203, %207, %c0_i64_62 : i64
        %209 = llvm.getelementptr %arg0[%208] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %210 = llvm.load %209 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_63 = arith.constant 0.000000e+00 : bf16
        %211 = arith.select %203, %210, %cst_63 : bf16
        %c1_i64_64 = arith.constant 1 : i64
        %212 = llvm.insertelement %211, %199[%c1_i64_64 : i64] : vector<2xbf16>
        %213 = llvm.bitcast %212 : vector<2xbf16> to i32
        %214 = llvm.mlir.undef : !llvm.struct<(i32, i32, i32, i32)>
        %215 = llvm.insertvalue %117, %214[0] : !llvm.struct<(i32, i32, i32, i32)> 
        %216 = llvm.insertvalue %149, %215[1] : !llvm.struct<(i32, i32, i32, i32)> 
        %217 = llvm.insertvalue %181, %216[2] : !llvm.struct<(i32, i32, i32, i32)> 
        %218 = llvm.insertvalue %213, %217[3] : !llvm.struct<(i32, i32, i32, i32)> 
        %219 = nvvm.read.ptx.sreg.tid.x : i32
        %c31_i32_65 = arith.constant 31 : i32
        %220 = arith.andi %219, %c31_i32_65 : i32
        %c2_i32_66 = arith.constant 2 : i32
        %221 = arith.shrui %220, %c2_i32_66 : i32
        %c3_i32_67 = arith.constant 3 : i32
        %222 = arith.andi %220, %c3_i32_67 : i32
        %223 = arith.extui %221 : i32 to i64
        %224 = arith.extui %222 : i32 to i64
        %c11_i64_68 = arith.constant 11 : i64
        %c8_i64_69 = arith.constant 8 : i64
        %c2_i64_70 = arith.constant 2 : i64
        %225 = arith.muli %224, %c2_i64_70 : i64
        %c8_i64_71 = arith.constant 8 : i64
        %226 = arith.addi %225, %c8_i64_71 : i64
        %227 = arith.addi %arg6, %225 : i64
        %228 = arith.addi %5, %223 : i64
        %229 = arith.muli %225, %c11_i64_68 : i64
        %230 = arith.addi %229, %223 : i64
        %231 = arith.addi %74, %230 : i64
        %cst_72 = arith.constant dense<0.000000e+00> : vector<2xbf16>
        %c0_i64_73 = arith.constant 0 : i64
        %232 = arith.addi %227, %c0_i64_73 : i64
        %233 = arith.cmpi ult, %228, %arg4 : i64
        %234 = arith.cmpi ult, %232, %arg5 : i64
        %235 = arith.andi %234, %233 : i1
        %236 = arith.addi %225, %c0_i64_73 : i64
        %237 = arith.muli %236, %c11_i64_68 : i64
        %238 = arith.addi %237, %223 : i64
        %239 = arith.addi %74, %238 : i64
        %c0_i64_74 = arith.constant 0 : i64
        %240 = arith.select %235, %239, %c0_i64_74 : i64
        %241 = llvm.getelementptr %arg1[%240] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %242 = llvm.load %241 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_75 = arith.constant 0.000000e+00 : bf16
        %243 = arith.select %235, %242, %cst_75 : bf16
        %c0_i64_76 = arith.constant 0 : i64
        %244 = llvm.insertelement %243, %cst_72[%c0_i64_76 : i64] : vector<2xbf16>
        %c1_i64_77 = arith.constant 1 : i64
        %245 = arith.addi %227, %c1_i64_77 : i64
        %246 = arith.cmpi ult, %228, %arg4 : i64
        %247 = arith.cmpi ult, %245, %arg5 : i64
        %248 = arith.andi %247, %246 : i1
        %249 = arith.addi %225, %c1_i64_77 : i64
        %250 = arith.muli %249, %c11_i64_68 : i64
        %251 = arith.addi %250, %223 : i64
        %252 = arith.addi %74, %251 : i64
        %c0_i64_78 = arith.constant 0 : i64
        %253 = arith.select %248, %252, %c0_i64_78 : i64
        %254 = llvm.getelementptr %arg1[%253] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %255 = llvm.load %254 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_79 = arith.constant 0.000000e+00 : bf16
        %256 = arith.select %248, %255, %cst_79 : bf16
        %c1_i64_80 = arith.constant 1 : i64
        %257 = llvm.insertelement %256, %244[%c1_i64_80 : i64] : vector<2xbf16>
        %258 = llvm.bitcast %257 : vector<2xbf16> to i32
        %259 = arith.addi %arg6, %226 : i64
        %260 = arith.addi %5, %223 : i64
        %261 = arith.muli %226, %c11_i64_68 : i64
        %262 = arith.addi %261, %223 : i64
        %263 = arith.addi %74, %262 : i64
        %cst_81 = arith.constant dense<0.000000e+00> : vector<2xbf16>
        %c0_i64_82 = arith.constant 0 : i64
        %264 = arith.addi %259, %c0_i64_82 : i64
        %265 = arith.cmpi ult, %260, %arg4 : i64
        %266 = arith.cmpi ult, %264, %arg5 : i64
        %267 = arith.andi %266, %265 : i1
        %268 = arith.addi %226, %c0_i64_82 : i64
        %269 = arith.muli %268, %c11_i64_68 : i64
        %270 = arith.addi %269, %223 : i64
        %271 = arith.addi %74, %270 : i64
        %c0_i64_83 = arith.constant 0 : i64
        %272 = arith.select %267, %271, %c0_i64_83 : i64
        %273 = llvm.getelementptr %arg1[%272] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %274 = llvm.load %273 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_84 = arith.constant 0.000000e+00 : bf16
        %275 = arith.select %267, %274, %cst_84 : bf16
        %c0_i64_85 = arith.constant 0 : i64
        %276 = llvm.insertelement %275, %cst_81[%c0_i64_85 : i64] : vector<2xbf16>
        %c1_i64_86 = arith.constant 1 : i64
        %277 = arith.addi %259, %c1_i64_86 : i64
        %278 = arith.cmpi ult, %260, %arg4 : i64
        %279 = arith.cmpi ult, %277, %arg5 : i64
        %280 = arith.andi %279, %278 : i1
        %281 = arith.addi %226, %c1_i64_86 : i64
        %282 = arith.muli %281, %c11_i64_68 : i64
        %283 = arith.addi %282, %223 : i64
        %284 = arith.addi %74, %283 : i64
        %c0_i64_87 = arith.constant 0 : i64
        %285 = arith.select %280, %284, %c0_i64_87 : i64
        %286 = llvm.getelementptr %arg1[%285] : (!llvm.ptr, i64) -> !llvm.ptr, bf16
        %287 = llvm.load %286 {alignment = 2 : i64} : !llvm.ptr -> bf16
        %cst_88 = arith.constant 0.000000e+00 : bf16
        %288 = arith.select %280, %287, %cst_88 : bf16
        %c1_i64_89 = arith.constant 1 : i64
        %289 = llvm.insertelement %288, %276[%c1_i64_89 : i64] : vector<2xbf16>
        %290 = llvm.bitcast %289 : vector<2xbf16> to i32
        %291 = llvm.mlir.undef : !llvm.struct<(i32, i32)>
        %292 = llvm.insertvalue %258, %291[0] : !llvm.struct<(i32, i32)> 
        %293 = llvm.insertvalue %290, %292[1] : !llvm.struct<(i32, i32)> 
        %294 = llvm.extractvalue %218[0] : !llvm.struct<(i32, i32, i32, i32)> 
        %295 = llvm.extractvalue %218[1] : !llvm.struct<(i32, i32, i32, i32)> 
        %296 = llvm.extractvalue %218[2] : !llvm.struct<(i32, i32, i32, i32)> 
        %297 = llvm.extractvalue %218[3] : !llvm.struct<(i32, i32, i32, i32)> 
        %298 = llvm.extractvalue %293[0] : !llvm.struct<(i32, i32)> 
        %299 = llvm.extractvalue %293[1] : !llvm.struct<(i32, i32)> 
        %300 = llvm.extractvalue %arg7[0] : !llvm.struct<(f32, f32, f32, f32)> 
        %301 = llvm.extractvalue %arg7[1] : !llvm.struct<(f32, f32, f32, f32)> 
        %302 = llvm.extractvalue %arg7[2] : !llvm.struct<(f32, f32, f32, f32)> 
        %303 = llvm.extractvalue %arg7[3] : !llvm.struct<(f32, f32, f32, f32)> 
        %304 = nvvm.mma.sync A[%294, %295, %296, %297]  B[%298, %299]  C[%300, %301, %302, %303]  {layoutA = #nvvm.mma_layout<row>, layoutB = #nvvm.mma_layout<col>, multiplicandAPtxType = #nvvm.mma_type<bf16>, multiplicandBPtxType = #nvvm.mma_type<bf16>, shape = #nvvm.shape<m = 16, n = 8, k = 16>} : (i32, i32, f32) -> !llvm.struct<(f32, f32, f32, f32)>
        scf.yield %304 : !llvm.struct<(f32, f32, f32, f32)>
      }
      %12 = nvvm.read.ptx.sreg.tid.x : i32
      %c31_i32 = arith.constant 31 : i32
      %13 = arith.andi %12, %c31_i32 : i32
      %c2_i32 = arith.constant 2 : i32
      %14 = arith.shrui %13, %c2_i32 : i32
      %c3_i32 = arith.constant 3 : i32
      %15 = arith.andi %13, %c3_i32 : i32
      %c2_i32_4 = arith.constant 2 : i32
      %16 = arith.muli %15, %c2_i32_4 : i32
      %17 = arith.extui %14 : i32 to i64
      %18 = arith.extui %16 : i32 to i64
      %c1_i64 = arith.constant 1 : i64
      %c8_i64_5 = arith.constant 8 : i64
      %19 = arith.addi %18, %c1_i64 : i64
      %20 = arith.addi %17, %c8_i64_5 : i64
      %21 = arith.addi %17, %c8_i64_5 : i64
      %22 = arith.addi %18, %c1_i64 : i64
      %c11_i64 = arith.constant 11 : i64
      %23 = arith.addi %4, %17 : i64
      %24 = arith.addi %5, %18 : i64
      %25 = arith.muli %23, %c11_i64 : i64
      %26 = arith.addi %25, %24 : i64
      %27 = llvm.getelementptr %arg2[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %28 = llvm.extractvalue %11[0] : !llvm.struct<(f32, f32, f32, f32)> 
      %29 = arith.cmpi ult, %24, %arg4 : i64
      %30 = arith.cmpi ult, %23, %arg3 : i64
      %31 = arith.andi %30, %29 : i1
      scf.if %31 {
        llvm.store %28, %27 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      %32 = arith.addi %4, %17 : i64
      %33 = arith.addi %5, %19 : i64
      %34 = arith.muli %32, %c11_i64 : i64
      %35 = arith.addi %34, %33 : i64
      %36 = llvm.getelementptr %arg2[%35] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %37 = llvm.extractvalue %11[1] : !llvm.struct<(f32, f32, f32, f32)> 
      %38 = arith.cmpi ult, %33, %arg4 : i64
      %39 = arith.cmpi ult, %32, %arg3 : i64
      %40 = arith.andi %39, %38 : i1
      scf.if %40 {
        llvm.store %37, %36 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      %41 = arith.addi %4, %20 : i64
      %42 = arith.addi %5, %18 : i64
      %43 = arith.muli %41, %c11_i64 : i64
      %44 = arith.addi %43, %42 : i64
      %45 = llvm.getelementptr %arg2[%44] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %46 = llvm.extractvalue %11[2] : !llvm.struct<(f32, f32, f32, f32)> 
      %47 = arith.cmpi ult, %42, %arg4 : i64
      %48 = arith.cmpi ult, %41, %arg3 : i64
      %49 = arith.andi %48, %47 : i1
      scf.if %49 {
        llvm.store %46, %45 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      %50 = arith.addi %4, %21 : i64
      %51 = arith.addi %5, %22 : i64
      %52 = arith.muli %50, %c11_i64 : i64
      %53 = arith.addi %52, %51 : i64
      %54 = llvm.getelementptr %arg2[%53] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %55 = llvm.extractvalue %11[3] : !llvm.struct<(f32, f32, f32, f32)> 
      %56 = arith.cmpi ult, %51, %arg4 : i64
      %57 = arith.cmpi ult, %50, %arg3 : i64
      %58 = arith.andi %57, %56 : i1
      scf.if %58 {
        llvm.store %55, %54 {alignment = 4 : i64} : f32, !llvm.ptr
      }
      llvm.return
    }
  }
}

