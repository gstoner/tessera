
/tmp/tmpqbdzsmxp.hsaco:	file format elf64-amdgpu
	.amdgcn_target "amdgpu-amd-amdhsa-unknown-gfx1201"

disassembly of section .text:

0000000000001b00 <tessera_rocm_scaled_matmul_lds_434e421f100676d4>:
	v_lshrrev_b32_e32 v1, 1, v0                                // 000000001b00: 32020081
	s_load_b64 s[2:3], s[0:1], 0xd8                            // 000000001b04: f4002080 f80000d8
	v_mov_b32_e32 v43, 0                                       // 000000001b0c: 7e560280
	s_clause 0x4                                               // 000000001b10: bf850004
	s_load_b64 s[18:19], s[0:1], 0x8                           // 000000001b14: f4002480 f8000008
	s_load_b64 s[20:21], s[0:1], 0x30                          // 000000001b1c: f4002500 f8000030
	s_load_b64 s[12:13], s[0:1], 0x58                          // 000000001b24: f4002300 f8000058
	s_load_b64 s[8:9], s[0:1], 0x80                            // 000000001b2c: f4002200 f8000080
	s_load_b128 s[4:7], s[0:1], 0xc8                           // 000000001b34: f4004100 f80000c8
	s_mov_b32 s14, ttmp7                                       // 000000001b3c: be8e0073
	v_and_b32_e32 v2, 0x60, v1                                 // 000000001b40: 360402ff 00000060
	s_ashr_i32 s15, ttmp7, 31                                  // 000000001b48: 860f9f73
	s_mov_b32 s10, ttmp9                                       // 000000001b4c: be8a0075
	s_ashr_i32 s11, ttmp9, 31                                  // 000000001b50: 860b9f75
	s_lshl_b64 s[14:15], s[14:15], 7                           // 000000001b54: 848e870e
	v_or_b32_e32 v3, 16, v2                                    // 000000001b58: 38060490
	s_lshl_b64 s[16:17], s[10:11], 7                           // 000000001b5c: 8490870a
	v_or_b32_e32 v18, s14, v2                                  // 000000001b60: 3824040e
	v_and_b32_e32 v20, 8, v1                                   // 000000001b64: 36280288
	v_dual_mov_b32 v11, s15 :: v_dual_lshlrev_b32 v4, 1, v0    // 000000001b68: ca22000f 0b040081
	v_or_b32_e32 v28, s14, v3                                  // 000000001b70: 3838060e
	v_add_co_u32 v5, s14, s14, v0                              // 000000001b74: d7000e05 0202000e
	s_wait_alu depctr_va_sdst(0)                               // 000000001b7c: bf88f19f
	v_add_co_ci_u32_e64 v6, null, s15, 0, s14                  // 000000001b80: d5207c06 0039000f
	v_add_co_u32 v7, s14, s16, v0                              // 000000001b88: d7000e07 02020010
	s_wait_alu depctr_va_sdst(0)                               // 000000001b90: bf88f19f
	v_add_co_ci_u32_e64 v10, null, s17, 0, s14                 // 000000001b94: d5207c0a 00390011
	s_wait_kmcnt 0x0                                           // 000000001b9c: bfc70000
	v_mul_lo_u32 v15, s3, v5                                   // 000000001ba0: d72c000f 02020a03
	v_mad_co_u64_u32 v[8:9], null, s2, v5, s[18:19]            // 000000001ba8: d6fe7c08 004a0a02
	v_mad_co_u64_u32 v[12:13], null, s2, v7, s[20:21]          // 000000001bb0: d6fe7c0c 00520e02
	v_mul_lo_u32 v5, s2, v10                                   // 000000001bb8: d72c0005 02021402
	v_mul_lo_u32 v10, s3, v7                                   // 000000001bc0: d72c000a 02020e03
	v_and_b32_e32 v14, 15, v0                                  // 000000001bc8: 361c008f
	s_lshr_b64 s[10:11], s[2:3], 4                             // 000000001bcc: 858a8402
	v_mul_lo_u32 v6, s2, v6                                    // 000000001bd0: d72c0006 02020c02
	v_cmp_gt_u32_e32 vcc_lo, 0x80, v0                          // 000000001bd8: 7c9800ff 00000080
	v_lshlrev_b32_e32 v56, 5, v0                               // 000000001be0: 30700085
	v_or_b32_e32 v1, v3, v14                                   // 000000001be4: 38021d03
	s_lshr_b32 s14, s3, 4                                      // 000000001be8: 850e8403
	v_add3_u32 v13, v10, v13, v5                               // 000000001bec: d655000d 04161b0a
	v_or_b32_e32 v10, v18, v20                                 // 000000001bf4: 38142912
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v40, 0            // 000000001bf8: ca100080 75280080
	v_lshl_or_b32 v59, v1, 5, v20                              // 000000001c00: d656003b 04510b01
	v_mov_b32_e32 v1, s15                                      // 000000001c08: 7e02020f
	s_delay_alu instid0(valu_dep_4)                            // 000000001c0c: bf870004
	v_cmp_gt_i64_e64 s2, s[4:5], v[10:11]                      // 000000001c10: d4540002 02021404
	v_or_b32_e32 v0, v2, v14                                   // 000000001c18: 38001d02
	v_and_or_b32 v2, v4, 64, v14                               // 000000001c1c: d6570002 04398104
	v_add3_u32 v9, v15, v9, v6                                 // 000000001c24: d6550009 041a130f
	v_mov_b32_e32 v15, s17                                     // 000000001c2c: 7e1e0211
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v38, 0            // 000000001c30: ca100080 71260080
	s_wait_alu depctr_va_sdst(0)                               // 000000001c38: bf88f19f
	v_cndmask_b32_e64 v3, 0, v11, s2                           // 000000001c3c: d5010003 000a1680
	v_cndmask_b32_e64 v4, 0, v10, s2                           // 000000001c44: d5010004 000a1480
	v_or_b32_e32 v21, 16, v2                                   // 000000001c4c: 382a0490
	v_lshl_or_b32 v61, v2, 5, v20                              // 000000001c50: d656003d 04510b02
	v_or_b32_e32 v22, 32, v2                                   // 000000001c58: 382c04a0
	v_or_b32_e32 v23, 48, v2                                   // 000000001c5c: 382e04b0
	v_or_b32_e32 v14, s16, v2                                  // 000000001c60: 381c0410
	s_wait_alu depctr_sa_sdst(0)                               // 000000001c64: bf88ff9e
	v_mul_lo_u32 v16, s14, v4                                  // 000000001c68: d72c0010 0202080e
	v_mul_lo_u32 v17, s10, v3                                  // 000000001c70: d72c0011 0202060a
	v_mad_co_u64_u32 v[2:3], null, s10, v4, 0                  // 000000001c78: d6fe7c02 0202080a
	v_mov_b32_e32 v111, 0                                      // 000000001c80: 7ede0280
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v106, 0           // 000000001c84: ca100080 6d6a0080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0           // 000000001c8c: ca100080 69680080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v102, 0            // 000000001c94: ca100080 55660080
	v_add3_u32 v3, v3, v17, v16                                // 000000001c9c: d6550003 04422303
	v_mov_b32_e32 v17, s15                                     // 000000001ca4: 7e22020f
	v_or_b32_e32 v24, 1, v20                                   // 000000001ca8: 38302881
	v_lshl_or_b32 v58, v0, 5, v20                              // 000000001cac: d656003a 04510b00
	v_or_b32_e32 v25, 2, v20                                   // 000000001cb4: 38322882
	v_or_b32_e32 v27, 3, v20                                   // 000000001cb8: 38362883
	v_or_b32_e32 v32, 7, v20                                   // 000000001cbc: 38402887
	v_or_b32_e32 v0, v24, v18                                  // 000000001cc0: 38002518
	v_lshl_or_b32 v62, v21, 5, v20                             // 000000001cc4: d656003e 04510b15
	v_lshl_or_b32 v64, v22, 5, v20                             // 000000001ccc: d6560040 04510b16
	v_or_b32_e32 v16, v27, v18                                 // 000000001cd4: 3820251b
	v_lshl_or_b32 v65, v23, 5, v20                             // 000000001cd8: d6560041 04510b17
	v_cmp_gt_i64_e64 s2, s[4:5], v[0:1]                        // 000000001ce0: d4540002 02020004
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v98, 0             // 000000001ce8: ca100080 53620080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v92, 0             // 000000001cf0: ca100080 4f5c0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v76, 0             // 000000001cf8: ca100080 4b4c0080
	s_wait_alu depctr_va_sdst(0)                               // 000000001d00: bf88f19f
	s_delay_alu instid0(valu_dep_4) | instskip(skip_4) | instid1(valu_dep_4)// 000000001d04: bf870254
	v_cndmask_b32_e64 v4, 0, v1, s2                            // 000000001d08: d5010004 000a0280
	v_cndmask_b32_e64 v6, 0, v0, s2                            // 000000001d10: d5010006 000a0080
	v_or_b32_e32 v0, v25, v18                                  // 000000001d18: 38002519
	v_cmp_gt_i64_e64 s2, s[6:7], v[14:15]                      // 000000001d1c: d4540002 02021c06
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v72, 0             // 000000001d24: ca100080 47480080
	v_mul_lo_u32 v19, s14, v6                                  // 000000001d2c: d72c0013 02020c0e
	v_mul_lo_u32 v26, s10, v4                                  // 000000001d34: d72c001a 0202080a
	v_mad_co_u64_u32 v[6:7], null, s10, v6, 0                  // 000000001d3c: d6fe7c06 02020c0a
	v_cmp_gt_i64_e64 s3, s[4:5], v[0:1]                        // 000000001d44: d4540003 02020004
	s_wait_alu depctr_va_sdst(0)                               // 000000001d4c: bf88f19f
	v_cndmask_b32_e64 v5, 0, v15, s2                           // 000000001d50: d5010005 000a1e80
	v_cndmask_b32_e64 v4, 0, v14, s2                           // 000000001d58: d5010004 000a1c80
	v_cmp_gt_i64_e64 s2, s[4:5], v[16:17]                      // 000000001d60: d4540002 02022004
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v70, 0             // 000000001d68: ca100080 3f460080
	v_cndmask_b32_e64 v29, 0, v1, s3                           // 000000001d70: d501001d 000e0280
	v_cndmask_b32_e64 v30, 0, v0, s3                           // 000000001d78: d501001e 000e0080
	v_add3_u32 v7, v7, v26, v19                                // 000000001d80: d6550007 044e3507
	v_or_b32_e32 v26, 4, v20                                   // 000000001d88: 38342884
	v_lshlrev_b64_e32 v[0:1], 2, v[2:3]                        // 000000001d8c: 3e000482
	v_mul_lo_u32 v29, s10, v29                                 // 000000001d90: d72c001d 02023a0a
	v_mul_lo_u32 v19, s14, v30                                 // 000000001d98: d72c0013 02023c0e
	v_mad_co_u64_u32 v[2:3], null, s10, v30, 0                 // 000000001da0: d6fe7c02 02023c0a
	s_wait_alu depctr_va_sdst(0)                               // 000000001da8: bf88f19f
	v_cndmask_b32_e64 v31, 0, v16, s2                          // 000000001dac: d501001f 000a2080
	v_or_b32_e32 v16, v26, v18                                 // 000000001db4: 3820251a
	v_cndmask_b32_e64 v30, 0, v17, s2                          // 000000001db8: d501001e 000a2280
	v_add_co_u32 v77, s2, s12, v0                              // 000000001dc0: d700024d 0202000c
	s_wait_alu depctr_va_sdst(0)                               // 000000001dc8: bf88f19f
	v_add_co_ci_u32_e64 v78, null, s13, v1, s2                 // 000000001dcc: d5207c4e 000a020d
	v_lshlrev_b64_e32 v[0:1], 2, v[6:7]                        // 000000001dd4: 3e000c82
	v_cmp_gt_i64_e64 s2, s[4:5], v[16:17]                      // 000000001dd8: d4540002 02022004
	v_add3_u32 v3, v3, v29, v19                                // 000000001de0: d6550003 044e3b03
	v_mul_lo_u32 v19, s14, v31                                 // 000000001de8: d72c0013 02023e0e
	v_mul_lo_u32 v29, s10, v30                                 // 000000001df0: d72c001d 02023c0a
	v_mad_co_u64_u32 v[6:7], null, s10, v31, 0                 // 000000001df8: d6fe7c06 02023e0a
	v_or_b32_e32 v30, 5, v20                                   // 000000001e00: 383c2885
	s_wait_alu depctr_va_sdst(0)                               // 000000001e04: bf88f19f
	v_cndmask_b32_e64 v17, 0, v17, s2                          // 000000001e08: d5010011 000a2280
	v_cndmask_b32_e64 v16, 0, v16, s2                          // 000000001e10: d5010010 000a2080
	v_add_co_u32 v80, s2, s12, v0                              // 000000001e18: d7000250 0202000c
	s_wait_alu depctr_va_sdst(0)                               // 000000001e20: bf88f19f
	v_add_co_ci_u32_e64 v81, null, s13, v1, s2                 // 000000001e24: d5207c51 000a020d
	v_lshlrev_b64_e32 v[0:1], 2, v[2:3]                        // 000000001e2c: 3e000482
	v_add3_u32 v7, v7, v29, v19                                // 000000001e30: d6550007 044e3b07
	v_mul_lo_u32 v19, s14, v16                                 // 000000001e38: d72c0013 0202200e
	v_mul_lo_u32 v29, s10, v17                                 // 000000001e40: d72c001d 0202220a
	v_mad_co_u64_u32 v[2:3], null, s10, v16, 0                 // 000000001e48: d6fe7c02 0202200a
	v_or_b32_e32 v16, v30, v18                                 // 000000001e50: 3820251e
	v_dual_mov_b32 v17, s15 :: v_dual_mov_b32 v118, 0          // 000000001e54: ca10000f 11760080
	v_or_b32_e32 v31, 6, v20                                   // 000000001e5c: 383e2886
	v_add_co_u32 v86, s2, s12, v0                              // 000000001e60: d7000256 0202000c
	s_wait_alu depctr_va_sdst(0)                               // 000000001e68: bf88f19f
	v_add_co_ci_u32_e64 v87, null, s13, v1, s2                 // 000000001e6c: d5207c57 000a020d
	v_cmp_gt_i64_e64 s2, s[4:5], v[16:17]                      // 000000001e74: d4540002 02022004
	v_or_b32_e32 v0, v31, v18                                  // 000000001e7c: 3800251f
	v_dual_mov_b32 v1, s15 :: v_dual_mov_b32 v114, 0           // 000000001e80: ca10000f 01720080
	v_add3_u32 v3, v3, v29, v19                                // 000000001e88: d6550003 044e3b03
	v_lshlrev_b64_e32 v[6:7], 2, v[6:7]                        // 000000001e90: 3e0c0c82
	s_wait_alu depctr_va_sdst(0)                               // 000000001e94: bf88f19f
	v_cndmask_b32_e64 v29, 0, v16, s2                          // 000000001e98: d501001d 000a2080
	v_or_b32_e32 v16, v32, v18                                 // 000000001ea0: 38202520
	v_cmp_gt_i64_e64 s3, s[4:5], v[0:1]                        // 000000001ea4: d4540003 02020004
	v_cndmask_b32_e64 v19, 0, v17, s2                          // 000000001eac: d5010013 000a2280
	v_lshlrev_b64_e32 v[2:3], 2, v[2:3]                        // 000000001eb4: 3e040482
	v_mul_lo_u32 v34, s14, v29                                 // 000000001eb8: d72c0022 02023a0e
	v_cmp_gt_i64_e64 s2, s[4:5], v[16:17]                      // 000000001ec0: d4540002 02022004
	v_mov_b32_e32 v84, 0                                       // 000000001ec8: 7ea80280
	s_wait_alu depctr_va_sdst(0)                               // 000000001ecc: bf88f19f
	v_cndmask_b32_e64 v18, 0, v1, s3                           // 000000001ed0: d5010012 000e0280
	v_cndmask_b32_e64 v33, 0, v0, s3                           // 000000001ed8: d5010021 000e0080
	v_mul_lo_u32 v35, s10, v19                                 // 000000001ee0: d72c0023 0202260a
	v_mad_co_u64_u32 v[0:1], null, s10, v29, 0                 // 000000001ee8: d6fe7c00 02023a0a
	v_cndmask_b32_e64 v17, 0, v17, s2                          // 000000001ef0: d5010011 000a2280
	v_cndmask_b32_e64 v16, 0, v16, s2                          // 000000001ef8: d5010010 000a2080
	v_mul_lo_u32 v29, s14, v33                                 // 000000001f00: d72c001d 0202420e
	v_mul_lo_u32 v36, s10, v18                                 // 000000001f08: d72c0024 0202240a
	v_mad_co_u64_u32 v[18:19], null, s10, v33, 0               // 000000001f10: d6fe7c12 0202420a
	v_add_co_u32 v88, s2, s12, v6                              // 000000001f18: d7000258 02020c0c
	s_wait_alu depctr_va_sdst(0)                               // 000000001f20: bf88f19f
	v_add_co_ci_u32_e64 v89, null, s13, v7, s2                 // 000000001f24: d5207c59 000a0e0d
	v_add3_u32 v1, v1, v35, v34                                // 000000001f2c: d6550001 048a4701
	v_mul_lo_u32 v33, s14, v16                                 // 000000001f34: d72c0021 0202200e
	v_mul_lo_u32 v17, s10, v17                                 // 000000001f3c: d72c0011 0202220a
	v_mad_co_u64_u32 v[6:7], null, s10, v16, 0                 // 000000001f44: d6fe7c06 0202200a
	v_add3_u32 v19, v19, v36, v29                              // 000000001f4c: d6550013 04764913
	v_lshlrev_b64_e32 v[0:1], 2, v[0:1]                        // 000000001f54: 3e000082
	v_add_co_u32 v90, s2, s12, v2                              // 000000001f58: d700025a 0202040c
	s_wait_alu depctr_va_sdst(0)                               // 000000001f60: bf88f19f
	v_add_co_ci_u32_e64 v91, null, s13, v3, s2                 // 000000001f64: d5207c5b 000a060d
	v_lshlrev_b64_e32 v[2:3], 2, v[18:19]                      // 000000001f6c: 3e042482
	v_add3_u32 v7, v7, v17, v33                                // 000000001f70: d6550007 04862307
	v_add_co_u32 v93, s2, s12, v0                              // 000000001f78: d700025d 0202000c
	s_wait_alu depctr_va_sdst(0)                               // 000000001f80: bf88f19f
	v_add_co_ci_u32_e64 v94, null, s13, v1, s2                 // 000000001f84: d5207c5e 000a020d
	s_delay_alu instid0(valu_dep_3)                            // 000000001f8c: bf870003
	v_lshlrev_b64_e32 v[0:1], 2, v[6:7]                        // 000000001f90: 3e000c82
	v_mov_b32_e32 v7, s17                                      // 000000001f94: 7e0e0211
	v_or_b32_e32 v6, s16, v21                                  // 000000001f98: 380c2a10
	v_add_co_u32 v95, s2, s12, v2                              // 000000001f9c: d700025f 0202040c
	s_wait_alu depctr_va_sdst(0)                               // 000000001fa4: bf88f19f
	v_add_co_ci_u32_e64 v96, null, s13, v3, s2                 // 000000001fa8: d5207c60 000a060d
	s_delay_alu instid0(valu_dep_3)                            // 000000001fb0: bf870003
	v_cmp_gt_i64_e64 s2, s[6:7], v[6:7]                        // 000000001fb4: d4540002 02020c06
	v_dual_mov_b32 v17, s15 :: v_dual_mov_b32 v82, 0           // 000000001fbc: ca10000f 11520080
	v_or_b32_e32 v16, v28, v20                                 // 000000001fc4: 3820291c
	v_add_co_u32 v99, s3, s12, v0                              // 000000001fc8: d7000363 0202000c
	s_wait_alu depctr_va_sdst(0)                               // 000000001fd0: bf88f19f
	v_add_co_ci_u32_e64 v100, null, s13, v1, s3                // 000000001fd4: d5207c64 000e020d
	v_cndmask_b32_e64 v1, 0, v7, s2                            // 000000001fdc: d5010001 000a0e80
	v_cndmask_b32_e64 v0, 0, v6, s2                            // 000000001fe4: d5010000 000a0c80
	v_cmp_gt_i64_e64 s2, s[4:5], v[16:17]                      // 000000001fec: d4540002 02022004
	v_dual_mov_b32 v3, s17 :: v_dual_mov_b32 v74, 0            // 000000001ff4: ca100011 034a0080
	v_or_b32_e32 v2, s16, v22                                  // 000000001ffc: 38042c10
	v_dual_mov_b32 v7, s15 :: v_dual_mov_b32 v60, 0            // 000000002000: ca10000f 073c0080
	s_wait_alu depctr_va_sdst(0)                               // 000000002008: bf88f19f
	s_delay_alu instid0(valu_dep_4)                            // 00000000200c: bf870004
	v_cndmask_b32_e64 v18, 0, v17, s2                          // 000000002010: d5010012 000a2280
	v_or_b32_e32 v6, v28, v24                                  // 000000002018: 380c311c
	v_cndmask_b32_e64 v20, 0, v16, s2                          // 00000000201c: d5010014 000a2080
	v_cmp_gt_i64_e64 s2, s[6:7], v[2:3]                        // 000000002024: d4540002 02020406
	v_dual_mov_b32 v19, s17 :: v_dual_mov_b32 v54, 0           // 00000000202c: ca100011 13360080
	v_mul_lo_u32 v24, s10, v18                                 // 000000002034: d72c0018 0202240a
	v_or_b32_e32 v18, s16, v23                                 // 00000000203c: 38242e10
	v_cmp_gt_i64_e64 s3, s[4:5], v[6:7]                        // 000000002040: d4540003 02020c04
	v_mul_lo_u32 v22, s14, v20                                 // 000000002048: d72c0016 0202280e
	v_mad_co_u64_u32 v[20:21], null, s10, v20, 0               // 000000002050: d6fe7c14 0202280a
	s_wait_alu depctr_va_sdst(0)                               // 000000002058: bf88f19f
	v_cndmask_b32_e64 v3, 0, v3, s2                            // 00000000205c: d5010003 000a0680
	v_cndmask_b32_e64 v2, 0, v2, s2                            // 000000002064: d5010002 000a0480
	v_cmp_gt_i64_e64 s2, s[6:7], v[18:19]                      // 00000000206c: d4540002 02022406
	v_cndmask_b32_e64 v29, 0, v6, s3                           // 000000002074: d501001d 000e0c80
	v_or_b32_e32 v6, v28, v25                                  // 00000000207c: 380c331c
	v_cndmask_b32_e64 v23, 0, v7, s3                           // 000000002080: d5010017 000e0e80
	v_mov_b32_e32 v52, 0                                       // 000000002088: 7e680280
	v_add3_u32 v21, v21, v24, v22                              // 00000000208c: d6550015 045a3115
	s_wait_alu depctr_va_sdst(0)                               // 000000002094: bf88f19f
	v_cndmask_b32_e64 v25, 0, v19, s2                          // 000000002098: d5010019 000a2680
	v_cndmask_b32_e64 v24, 0, v18, s2                          // 0000000020a0: d5010018 000a2480
	v_mov_b32_e32 v19, s15                                     // 0000000020a8: 7e26020f
	v_or_b32_e32 v18, v28, v27                                 // 0000000020ac: 3824371c
	v_cmp_gt_i64_e64 s3, s[4:5], v[6:7]                        // 0000000020b0: d4540003 02020c04
	v_mul_lo_u32 v33, s14, v29                                 // 0000000020b8: d72c0021 02023a0e
	v_mul_lo_u32 v34, s10, v23                                 // 0000000020c0: d72c0022 02022e0a
	v_mad_co_u64_u32 v[22:23], null, s10, v29, 0               // 0000000020c8: d6fe7c16 02023a0a
	v_cmp_gt_i64_e64 s2, s[4:5], v[18:19]                      // 0000000020d0: d4540002 02022404
	v_mov_b32_e32 v48, 0                                       // 0000000020d8: 7e600280
	s_wait_alu depctr_va_sdst(0)                               // 0000000020dc: bf88f19f
	v_cndmask_b32_e64 v29, 0, v7, s3                           // 0000000020e0: d501001d 000e0e80
	v_cndmask_b32_e64 v35, 0, v6, s3                           // 0000000020e8: d5010023 000e0c80
	v_lshlrev_b64_e32 v[6:7], 2, v[20:21]                      // 0000000020f0: 3e0c2882
	v_lshlrev_b64_e32 v[24:25], 2, v[24:25]                    // 0000000020f4: 3e303082
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v68, 0             // 0000000020f8: ca100080 39440080
	v_add3_u32 v23, v23, v34, v33                              // 000000002100: d6550017 04864517
	v_cndmask_b32_e64 v34, 0, v18, s2                          // 000000002108: d5010022 000a2480
	v_or_b32_e32 v18, v28, v26                                 // 000000002110: 3824351c
	v_mul_lo_u32 v27, s14, v35                                 // 000000002114: d72c001b 0202460e
	v_mul_lo_u32 v29, s10, v29                                 // 00000000211c: d72c001d 02023a0a
	v_mad_co_u64_u32 v[20:21], null, s10, v35, 0               // 000000002124: d6fe7c14 0202460a
	v_add_co_u32 v107, s3, s12, v6                             // 00000000212c: d700036b 02020c0c
	v_cndmask_b32_e64 v33, 0, v19, s2                          // 000000002134: d5010021 000a2680
	v_cmp_gt_i64_e64 s2, s[4:5], v[18:19]                      // 00000000213c: d4540002 02022404
	s_wait_alu depctr_va_sdst(0)                               // 000000002144: bf88f19f
	v_add_co_ci_u32_e64 v108, null, s13, v7, s3                // 000000002148: d5207c6c 000e0e0d
	v_lshlrev_b64_e32 v[6:7], 2, v[22:23]                      // 000000002150: 3e0c2c82
	v_add3_u32 v21, v21, v29, v27                              // 000000002154: d6550015 046e3b15
	v_mul_lo_u32 v26, s14, v34                                 // 00000000215c: d72c001a 0202440e
	v_mul_lo_u32 v27, s10, v33                                 // 000000002164: d72c001b 0202420a
	v_mad_co_u64_u32 v[22:23], null, s10, v34, 0               // 00000000216c: d6fe7c16 0202440a
	v_cndmask_b32_e64 v33, 0, v18, s2                          // 000000002174: d5010021 000a2480
	v_or_b32_e32 v18, v28, v30                                 // 00000000217c: 38243d1c
	v_add_co_u32 v110, s3, s12, v6                             // 000000002180: d700036e 02020c0c
	s_wait_alu depctr_va_sdst(0)                               // 000000002188: bf88f19f
	v_add_co_ci_u32_e64 v112, null, s13, v7, s3                // 00000000218c: d5207c70 000e0e0d
	v_lshlrev_b64_e32 v[6:7], 2, v[20:21]                      // 000000002194: 3e0c2882
	v_cndmask_b32_e64 v29, 0, v19, s2                          // 000000002198: d501001d 000a2680
	v_cmp_gt_i64_e64 s2, s[4:5], v[18:19]                      // 0000000021a0: d4540002 02022404
	v_add3_u32 v23, v23, v27, v26                              // 0000000021a8: d6550017 046a3717
	v_mov_b32_e32 v27, s15                                     // 0000000021b0: 7e36020f
	v_or_b32_e32 v26, v28, v31                                 // 0000000021b4: 38343f1c
	v_add_co_u32 v115, s3, s12, v6                             // 0000000021b8: d7000373 02020c0c
	v_mul_lo_u32 v30, s14, v33                                 // 0000000021c0: d72c001e 0202420e
	v_mul_lo_u32 v29, s10, v29                                 // 0000000021c8: d72c001d 02023a0a
	v_mad_co_u64_u32 v[20:21], null, s10, v33, 0               // 0000000021d0: d6fe7c14 0202420a
	s_wait_alu depctr_va_sdst(0)                               // 0000000021d8: bf88f19f
	v_add_co_ci_u32_e64 v116, null, s13, v7, s3                // 0000000021dc: d5207c74 000e0e0d
	v_lshlrev_b64_e32 v[6:7], 2, v[22:23]                      // 0000000021e4: 3e0c2c82
	v_cndmask_b32_e64 v23, 0, v18, s2                          // 0000000021e8: d5010017 000a2480
	v_or_b32_e32 v18, v28, v32                                 // 0000000021f0: 3824411c
	v_cmp_gt_i64_e64 s3, s[4:5], v[26:27]                      // 0000000021f4: d4540003 02023404
	v_cndmask_b32_e64 v22, 0, v19, s2                          // 0000000021fc: d5010016 000a2680
	v_add3_u32 v21, v21, v29, v30                              // 000000002204: d6550015 047a3b15
	v_mul_lo_u32 v28, s14, v23                                 // 00000000220c: d72c001c 02022e0e
	v_cmp_gt_i64_e64 s2, s[4:5], v[18:19]                      // 000000002214: d4540002 02022404
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v66, 0             // 00000000221c: ca100080 37420080
	v_mul_lo_u32 v29, s10, v22                                 // 000000002224: d72c001d 02022c0a
	v_mad_co_u64_u32 v[22:23], null, s10, v23, 0               // 00000000222c: d6fe7c16 02022e0a
	s_wait_alu depctr_va_sdst(0)                               // 000000002234: bf88f19f
	v_cndmask_b32_e64 v27, 0, v27, s3                          // 000000002238: d501001b 000e3680
	v_cndmask_b32_e64 v26, 0, v26, s3                          // 000000002240: d501001a 000e3480
	v_cndmask_b32_e64 v19, 0, v19, s2                          // 000000002248: d5010013 000a2680
	v_cndmask_b32_e64 v18, 0, v18, s2                          // 000000002250: d5010012 000a2480
	v_add_co_u32 v119, s2, s12, v6                             // 000000002258: d7000277 02020c0c
	s_delay_alu instid0(valu_dep_4)                            // 000000002260: bf870004
	v_mul_lo_u32 v30, s14, v26                                 // 000000002264: d72c001e 0202340e
	v_mul_lo_u32 v31, s10, v27                                 // 00000000226c: d72c001f 0202360a
	v_mad_co_u64_u32 v[26:27], null, s10, v26, 0               // 000000002274: d6fe7c1a 0202340a
	v_add3_u32 v23, v23, v29, v28                              // 00000000227c: d6550017 04723b17
	v_mul_lo_u32 v28, s14, v18                                 // 000000002284: d72c001c 0202240e
	v_mul_lo_u32 v29, s10, v19                                 // 00000000228c: d72c001d 0202260a
	v_mad_co_u64_u32 v[18:19], null, s10, v18, 0               // 000000002294: d6fe7c12 0202240a
	s_wait_alu depctr_va_sdst(0)                               // 00000000229c: bf88f19f
	v_add_co_ci_u32_e64 v120, null, s13, v7, s2                // 0000000022a0: d5207c78 000a0e0d
	v_lshlrev_b64_e32 v[6:7], 2, v[20:21]                      // 0000000022a8: 3e0c2882
	v_add3_u32 v27, v27, v31, v30                              // 0000000022ac: d655001b 047a3f1b
	v_lshlrev_b64_e32 v[20:21], 2, v[22:23]                    // 0000000022b4: 3e282c82
	v_lshlrev_b64_e32 v[22:23], 2, v[2:3]                      // 0000000022b8: 3e2c0482
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0             // 0000000022bc: ca100080 33320080
	v_add3_u32 v19, v19, v29, v28                              // 0000000022c4: d6550013 04723b13
	v_add_co_u32 v121, s2, s12, v6                             // 0000000022cc: d7000279 02020c0c
	s_wait_alu depctr_va_sdst(0)                               // 0000000022d4: bf88f19f
	v_add_co_ci_u32_e64 v122, null, s13, v7, s2                // 0000000022d8: d5207c7a 000a0e0d
	v_lshlrev_b64_e32 v[6:7], 2, v[26:27]                      // 0000000022e0: 3e0c3482
	v_lshlrev_b64_e32 v[18:19], 2, v[18:19]                    // 0000000022e4: 3e242482
	v_add_co_u32 v123, s2, s12, v20                            // 0000000022e8: d700027b 0202280c
	s_wait_alu depctr_va_sdst(0)                               // 0000000022f0: bf88f19f
	v_add_co_ci_u32_e64 v124, null, s13, v21, s2               // 0000000022f4: d5207c7c 000a2a0d
	s_delay_alu instid0(valu_dep_4)                            // 0000000022fc: bf870004
	v_add_co_u32 v125, s2, s12, v6                             // 000000002300: d700027d 02020c0c
	s_wait_alu depctr_va_sdst(0)                               // 000000002308: bf88f19f
	v_add_co_ci_u32_e64 v126, null, s13, v7, s2                // 00000000230c: d5207c7e 000a0e0d
	v_add_co_u32 v127, s2, s12, v18                            // 000000002314: d700027f 0202240c
	s_wait_alu depctr_va_sdst(0)                               // 00000000231c: bf88f19f
	v_add_co_ci_u32_e64 v128, null, s13, v19, s2               // 000000002320: d5207c80 000a260d
	v_lshlrev_b64_e32 v[18:19], 2, v[4:5]                      // 000000002328: 3e240882
	v_lshlrev_b64_e32 v[20:21], 2, v[0:1]                      // 00000000232c: 3e280082
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v46, 0             // 000000002330: ca100080 292e0080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v44, 0             // 000000002338: ca100080 272c0080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v42, 0             // 000000002340: ca100080 252a0080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000002348: ca100080 23240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v31, 0             // 000000002350: ca100080 221e0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v103, 0            // 000000002358: ca100080 20660080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v101, 0            // 000000002360: ca100080 1e640080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v97, 0             // 000000002368: ca100080 1c600080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v73, 0             // 000000002370: ca100080 1a480080
	v_mov_b32_e32 v69, 0                                       // 000000002378: 7e8a0280
	v_mov_b32_e32 v67, 0                                       // 00000000237c: 7e860280
	v_mov_b32_e32 v53, 0                                       // 000000002380: 7e6a0280
	v_mov_b32_e32 v49, 0                                       // 000000002384: 7e620280
	v_mov_b32_e32 v47, 0                                       // 000000002388: 7e5e0280
	v_mov_b32_e32 v45, 0                                       // 00000000238c: 7e5a0280
	v_mov_b32_e32 v33, 0                                       // 000000002390: 7e420280
	v_mov_b32_e32 v29, 0                                       // 000000002394: 7e3a0280
	v_mov_b32_e32 v27, 0                                       // 000000002398: 7e360280
	s_mov_b64 s[4:5], 0                                        // 00000000239c: be840180
	s_branch 421                                               // 0000000023a0: bfa001a5 <tessera_rocm_scaled_matmul_lds_434e421f100676d4+0xf38>
	s_wait_alu depctr_sa_sdst(0)                               // 0000000023a4: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000023a8: 8c7e027e
	s_mul_u64 s[14:15], s[4:5], s[6:7]                         // 0000000023ac: aa8e0604
	s_lshl_b64 s[12:13], s[4:5], 2                             // 0000000023b0: 848c8204
	s_wait_alu depctr_sa_sdst(0)                               // 0000000023b4: bf88ff9e
	s_lshl_b64 s[14:15], s[14:15], 2                           // 0000000023b8: 848e820e
	s_wait_loadcnt 0x0                                         // 0000000023bc: bfc00000
	v_add_co_u32 v0, s2, v77, s12                              // 0000000023c0: d7000200 0200194d
	s_wait_alu depctr_sa_sdst(0)                               // 0000000023c8: bf88ff9e
	s_add_nc_u64 s[14:15], s[8:9], s[14:15]                    // 0000000023cc: a98e0e08
	v_add_co_ci_u32_e64 v1, null, s13, v78, s2                 // 0000000023d0: d5207c01 000a9c0d
	s_wait_alu depctr_sa_sdst(0)                               // 0000000023d8: bf88ff9e
	v_add_co_u32 v2, s2, s14, v18                              // 0000000023dc: d7000202 0202240e
	s_wait_alu depctr_va_sdst(0)                               // 0000000023e4: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s15, v19, s2                 // 0000000023e8: d5207c03 000a260f
	v_add_co_u32 v4, s2, v80, s12                              // 0000000023f0: d7000204 02001950
	s_wait_alu depctr_va_sdst(0)                               // 0000000023f8: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s13, v81, s2                 // 0000000023fc: d5207c05 000aa20d
	v_add_co_u32 v6, s2, v86, s12                              // 000000002404: d7000206 02001956
	s_wait_dscnt 0x0                                           // 00000000240c: bfc60000
	s_barrier_signal -1                                        // 000000002410: be804ec1
	s_barrier_wait 0xffff                                      // 000000002414: bf94ffff
	s_wait_alu depctr_va_sdst(0)                               // 000000002418: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s13, v87, s2                 // 00000000241c: d5207c07 000aae0d
	global_load_b32 v189, v[0:1], off                          // 000000002424: ee05007c 000000bd 00000000
	v_add_co_u32 v0, s2, v88, s12                              // 000000002430: d7000200 02001958
	s_wait_alu depctr_va_sdst(0)                               // 000000002438: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s13, v89, s2                 // 00000000243c: d5207c01 000ab20d
	global_load_b32 v190, v[2:3], off                          // 000000002444: ee05007c 000000be 00000002
	v_add_co_u32 v2, s2, v90, s12                              // 000000002450: d7000202 0200195a
	s_wait_alu depctr_va_sdst(0)                               // 000000002458: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s13, v91, s2                 // 00000000245c: d5207c03 000ab60d
	global_load_b32 v193, v[0:1], off                          // 000000002464: ee05007c 000000c1 00000000
	v_add_co_u32 v0, s2, v93, s12                              // 000000002470: d7000200 0200195d
	global_load_b32 v191, v[4:5], off                          // 000000002478: ee05007c 000000bf 00000004
	s_wait_alu depctr_va_sdst(0)                               // 000000002484: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s13, v94, s2                 // 000000002488: d5207c01 000abc0d
	v_add_co_u32 v4, s2, v95, s12                              // 000000002490: d7000204 0200195f
	global_load_b32 v192, v[6:7], off                          // 000000002498: ee05007c 000000c0 00000006
	s_wait_alu depctr_va_sdst(0)                               // 0000000024a4: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s13, v96, s2                 // 0000000024a8: d5207c05 000ac00d
	v_add_co_u32 v6, s2, v99, s12                              // 0000000024b0: d7000206 02001963
	s_wait_alu depctr_va_sdst(0)                               // 0000000024b8: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s13, v100, s2                // 0000000024bc: d5207c07 000ac80d
	v_add_co_u32 v129, s2, s14, v20                            // 0000000024c4: d7000281 0202280e
	s_wait_alu depctr_va_sdst(0)                               // 0000000024cc: bf88f19f
	v_add_co_ci_u32_e64 v130, null, s15, v21, s2               // 0000000024d0: d5207c82 000a2a0f
	global_load_b32 v194, v[2:3], off                          // 0000000024d8: ee05007c 000000c2 00000002
	v_add_co_u32 v2, s2, s14, v22                              // 0000000024e4: d7000202 02022c0e
	s_wait_alu depctr_va_sdst(0)                               // 0000000024ec: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s15, v23, s2                 // 0000000024f0: d5207c03 000a2e0f
	global_load_b32 v195, v[0:1], off                          // 0000000024f8: ee05007c 000000c3 00000000
	v_add_co_u32 v0, s2, s14, v24                              // 000000002504: d7000200 0202300e
	global_load_b32 v199, v[2:3], off                          // 00000000250c: ee05007c 000000c7 00000002
	s_wait_alu depctr_va_sdst(0)                               // 000000002518: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s15, v25, s2                 // 00000000251c: d5207c01 000a320f
	v_add_co_u32 v2, s2, v107, s12                             // 000000002524: d7000202 0200196b
	global_load_b32 v196, v[4:5], off                          // 00000000252c: ee05007c 000000c4 00000004
	s_wait_alu depctr_va_sdst(0)                               // 000000002538: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s13, v108, s2                // 00000000253c: d5207c03 000ad80d
	v_add_co_u32 v4, s2, v110, s12                             // 000000002544: d7000204 0200196e
	global_load_b32 v197, v[6:7], off                          // 00000000254c: ee05007c 000000c5 00000006
	s_wait_alu depctr_va_sdst(0)                               // 000000002558: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s13, v112, s2                // 00000000255c: d5207c05 000ae00d
	v_add_co_u32 v6, s2, v115, s12                             // 000000002564: d7000206 02001973
	s_wait_alu depctr_va_sdst(0)                               // 00000000256c: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s13, v116, s2                // 000000002570: d5207c07 000ae80d
	global_load_b32 v200, v[0:1], off                          // 000000002578: ee05007c 000000c8 00000000
	v_add_co_u32 v0, s2, v119, s12                             // 000000002584: d7000200 02001977
	global_load_b32 v201, v[2:3], off                          // 00000000258c: ee05007c 000000c9 00000002
	s_wait_alu depctr_va_sdst(0)                               // 000000002598: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s13, v120, s2                // 00000000259c: d5207c01 000af00d
	v_add_co_u32 v2, s2, v121, s12                             // 0000000025a4: d7000202 02001979
	global_load_b32 v202, v[4:5], off                          // 0000000025ac: ee05007c 000000ca 00000004
	s_wait_alu depctr_va_sdst(0)                               // 0000000025b8: bf88f19f
	v_add_co_ci_u32_e64 v3, null, s13, v122, s2                // 0000000025bc: d5207c03 000af40d
	v_add_co_u32 v4, s2, v123, s12                             // 0000000025c4: d7000204 0200197b
	global_load_b32 v203, v[6:7], off                          // 0000000025cc: ee05007c 000000cb 00000006
	s_wait_alu depctr_va_sdst(0)                               // 0000000025d8: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s13, v124, s2                // 0000000025dc: d5207c05 000af80d
	v_add_co_u32 v6, s2, v125, s12                             // 0000000025e4: d7000206 0200197d
	global_load_b32 v198, v[129:130], off                      // 0000000025ec: ee05007c 000000c6 00000081
	s_wait_alu depctr_va_sdst(0)                               // 0000000025f8: bf88f19f
	v_add_co_ci_u32_e64 v7, null, s13, v126, s2                // 0000000025fc: d5207c07 000afc0d
	v_add_co_u32 v129, s2, v127, s12                           // 000000002604: d7000281 0200197f
	s_wait_alu depctr_va_sdst(0)                               // 00000000260c: bf88f19f
	v_add_co_ci_u32_e64 v130, null, s13, v128, s2              // 000000002610: d5207c82 000b000d
	s_clause 0x4                                               // 000000002618: bf850004
	global_load_b32 v204, v[0:1], off                          // 00000000261c: ee05007c 000000cc 00000000
	global_load_b32 v205, v[2:3], off                          // 000000002628: ee05007c 000000cd 00000002
	global_load_b32 v206, v[4:5], off                          // 000000002634: ee05007c 000000ce 00000004
	global_load_b32 v207, v[6:7], off                          // 000000002640: ee05007c 000000cf 00000006
	global_load_b32 v208, v[129:130], off                      // 00000000264c: ee05007c 000000d0 00000081
	ds_load_b64 v[153:154], v58                                // 000000002658: d9d80000 9900003a
	ds_load_b64 v[161:162], v61 offset:4096                    // 000000002660: d9d81000 a100003d
	ds_load_b64 v[169:170], v62 offset:4096                    // 000000002668: d9d81000 a900003e
	ds_load_b64 v[177:178], v64 offset:4096                    // 000000002670: d9d81000 b1000040
	ds_load_b64 v[185:186], v65 offset:4096                    // 000000002678: d9d81000 b9000041
	ds_load_b64 v[187:188], v59                                // 000000002680: d9d80000 bb00003b
	s_add_nc_u64 s[4:5], s[4:5], 1                             // 000000002688: a9848104
	s_wait_alu depctr_sa_sdst(0)                               // 00000000268c: bf88ff9e
	s_cmp_lg_u64 s[4:5], s[10:11]                              // 000000002690: bf110a04
	s_wait_dscnt 0x4                                           // 000000002694: bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[153:154], v[161:162], 0// 000000002698: cc464000 1a034399
	s_wait_dscnt 0x3                                           // 0000000026a0: bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[129:136], v[153:154], v[169:170], 0// 0000000026a4: cc464081 1a035399
	s_wait_dscnt 0x2                                           // 0000000026ac: bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[137:144], v[153:154], v[177:178], 0// 0000000026b0: cc464089 1a036399
	s_wait_dscnt 0x1                                           // 0000000026b8: bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[145:152], v[153:154], v[185:186], 0// 0000000026bc: cc464091 1a037399
	s_wait_dscnt 0x0                                           // 0000000026c4: bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[153:160], v[187:188], v[161:162], 0// 0000000026c8: cc464099 1a0343bb
	v_wmma_f32_16x16x16_fp8_fp8 v[161:168], v[187:188], v[169:170], 0// 0000000026d0: cc4640a1 1a0353bb
	v_wmma_f32_16x16x16_fp8_fp8 v[169:176], v[187:188], v[177:178], 0// 0000000026d8: cc4640a9 1a0363bb
	v_wmma_f32_16x16x16_fp8_fp8 v[177:184], v[187:188], v[185:186], 0// 0000000026e0: cc4640b1 1a0373bb
	s_wait_loadcnt 0x11                                        // 0000000026e8: bfc00011
	v_dual_mul_f32 v185, v189, v190 :: v_dual_mul_f32 v188, v190, v193// 0000000026ec: c8c77dbd b9bd83be
	s_delay_alu instid0(valu_dep_1) | instskip(skip_1) | instid1(valu_dep_2)// 0000000026f4: bf870121
	v_mul_f32_e32 v0, v0, v185                                 // 0000000026f8: 10017300
	s_wait_loadcnt 0x10                                        // 0000000026fc: bfc00010
	v_dual_mul_f32 v186, v190, v191 :: v_dual_mul_f32 v3, v3, v188// 000000002700: c8c77fbe ba037903
	s_delay_alu instid0(valu_dep_2) | instskip(skip_2) | instid1(valu_dep_3)// 000000002708: bf8701b2
	v_add_f32_e32 v43, v43, v0                                 // 00000000270c: 0656012b
	s_wait_loadcnt 0xf                                         // 000000002710: bfc0000f
	v_mul_f32_e32 v187, v190, v192                             // 000000002714: 117781be
	v_dual_mul_f32 v1, v1, v186 :: v_dual_add_f32 v114, v114, v3// 000000002718: c8c97501 01720772
	s_delay_alu instid0(valu_dep_2) | instskip(next) | instid1(valu_dep_1)// 000000002720: bf870092
	v_mul_f32_e32 v2, v2, v187                                 // 000000002724: 10057702
	v_dual_add_f32 v118, v118, v1 :: v_dual_add_f32 v117, v117, v2// 000000002728: c9080376 76740575
	s_wait_loadcnt 0xd                                         // 000000002730: bfc0000d
	v_dual_mul_f32 v209, v190, v194 :: v_dual_mul_f32 v210, v190, v195// 000000002734: c8c785be d1d387be
	s_wait_loadcnt 0xc                                         // 00000000273c: bfc0000c
	s_delay_alu instid0(valu_dep_1) | instskip(next) | instid1(valu_dep_2)// 000000002740: bf870111
	v_dual_mul_f32 v4, v4, v209 :: v_dual_mul_f32 v221, v189, v199// 000000002744: c8c7a304 04dd8fbd
	v_dual_mul_f32 v222, v191, v199 :: v_dual_mul_f32 v5, v5, v210// 00000000274c: c8c78fbf de05a505
	v_dual_mul_f32 v185, v192, v199 :: v_dual_mul_f32 v186, v193, v199// 000000002754: c8c78fc0 b9bb8fc1
	s_wait_loadcnt 0xb                                         // 00000000275c: bfc0000b
	v_mul_f32_e32 v211, v190, v196                             // 000000002760: 11a789be
	v_dual_mul_f32 v187, v194, v199 :: v_dual_mul_f32 v188, v195, v199// 000000002764: c8c78fc2 bbbd8fc3
	v_mul_f32_e32 v209, v196, v199                             // 00000000276c: 11a38fc4
	v_mul_f32_e32 v137, v137, v221                             // 000000002770: 1113bb89
	s_wait_loadcnt 0xa                                         // 000000002774: bfc0000a
	v_mul_f32_e32 v212, v190, v197                             // 000000002778: 11a98bbe
	v_mul_f32_e32 v210, v197, v199                             // 00000000277c: 11a58fc5
	v_mul_f32_e32 v6, v6, v211                                 // 000000002780: 100da706
	v_dual_mul_f32 v138, v138, v222 :: v_dual_mul_f32 v139, v139, v185// 000000002784: c8c7bd8a 8a8b738b
	s_delay_alu instid0(valu_dep_4)                            // 00000000278c: bf870004
	v_dual_mul_f32 v7, v7, v212 :: v_dual_mul_f32 v140, v140, v186// 000000002790: c8c7a907 078d758c
	v_dual_mul_f32 v141, v141, v187 :: v_dual_mul_f32 v142, v142, v188// 000000002798: c8c7778d 8d8f798e
	v_mul_f32_e32 v143, v143, v209                             // 0000000027a0: 111fa38f
	s_wait_loadcnt 0x8                                         // 0000000027a4: bfc00008
	v_dual_mul_f32 v211, v190, v201 :: v_dual_mul_f32 v144, v144, v210// 0000000027a8: c8c793be d391a590
	v_mul_f32_e32 v209, v199, v201                             // 0000000027b0: 11a393c7
	v_add_f32_e32 v113, v113, v4                               // 0000000027b4: 06e20971
	s_wait_loadcnt 0x7                                         // 0000000027b8: bfc00007
	v_dual_add_f32 v111, v111, v5 :: v_dual_mul_f32 v212, v190, v202// 0000000027bc: c9060b6f 6fd595be
	v_dual_mul_f32 v210, v199, v202 :: v_dual_mul_f32 v153, v153, v211// 0000000027c4: c8c795c7 d299a799
	v_mul_f32_e32 v169, v169, v209                             // 0000000027cc: 1153a3a9
	v_add_f32_e32 v109, v109, v6                               // 0000000027d0: 06da0d6d
	s_wait_loadcnt 0x6                                         // 0000000027d4: bfc00006
	v_dual_mul_f32 v221, v199, v203 :: v_dual_mul_f32 v154, v154, v212// 0000000027d8: c8c797c7 dd9ba99a
	v_dual_mul_f32 v170, v170, v210 :: v_dual_add_f32 v105, v105, v7// 0000000027e0: c8c9a5aa aa680f69
	v_add_f32_e32 v63, v63, v137                               // 0000000027e8: 067f133f
	s_wait_loadcnt 0x5                                         // 0000000027ec: bfc00005
	v_dual_mul_f32 v213, v189, v198 :: v_dual_mul_f32 v214, v191, v198// 0000000027f0: c8c78dbd d5d78dbf
	v_dual_mul_f32 v215, v192, v198 :: v_dual_mul_f32 v216, v193, v198// 0000000027f8: c8c78dc0 d7d98dc1
	v_dual_mul_f32 v217, v194, v198 :: v_dual_mul_f32 v218, v195, v198// 000000002800: c8c78dc2 d9db8dc3
	v_dual_mul_f32 v219, v196, v198 :: v_dual_mul_f32 v220, v197, v198// 000000002808: c8c78dc4 dbdd8dc5
	v_mul_f32_e32 v189, v189, v200                             // 000000002810: 117b91bd
	v_dual_mul_f32 v191, v191, v200 :: v_dual_mul_f32 v192, v192, v200// 000000002814: c8c791bf bfc191c0
	v_dual_mul_f32 v193, v193, v200 :: v_dual_mul_f32 v194, v194, v200// 00000000281c: c8c791c1 c1c391c2
	v_dual_mul_f32 v195, v195, v200 :: v_dual_mul_f32 v196, v196, v200// 000000002824: c8c791c3 c3c591c4
	v_mul_f32_e32 v197, v197, v200                             // 00000000282c: 118b91c5
	v_dual_mul_f32 v129, v129, v213 :: v_dual_mul_f32 v130, v130, v214// 000000002830: c8c7ab81 8183ad82
	v_dual_mul_f32 v131, v131, v215 :: v_dual_mul_f32 v132, v132, v216// 000000002838: c8c7af83 8385b184
	v_dual_mul_f32 v133, v133, v217 :: v_dual_mul_f32 v134, v134, v218// 000000002840: c8c7b385 8587b586
	v_dual_mul_f32 v135, v135, v219 :: v_dual_mul_f32 v136, v136, v220// 000000002848: c8c7b787 8789b988
	s_wait_loadcnt 0x4                                         // 000000002850: bfc00004
	v_dual_mul_f32 v213, v190, v203 :: v_dual_mul_f32 v214, v190, v204// 000000002854: c8c797be d5d799be
	s_wait_loadcnt 0x2                                         // 00000000285c: bfc00002
	v_dual_mul_f32 v215, v190, v205 :: v_dual_mul_f32 v216, v190, v206// 000000002860: c8c79bbe d7d99dbe
	s_wait_loadcnt 0x0                                         // 000000002868: bfc00000
	v_dual_mul_f32 v217, v190, v207 :: v_dual_mul_f32 v190, v190, v208// 00000000286c: c8c79fbe d9bfa1be
	v_dual_mul_f32 v218, v198, v201 :: v_dual_mul_f32 v219, v198, v202// 000000002874: c8c793c6 dadb95c6
	v_dual_mul_f32 v220, v198, v203 :: v_dual_mul_f32 v185, v198, v204// 00000000287c: c8c797c6 dcb999c6
	v_dual_mul_f32 v186, v198, v205 :: v_dual_mul_f32 v187, v198, v206// 000000002884: c8c79bc6 babb9dc6
	v_mul_f32_e32 v188, v198, v207                             // 00000000288c: 11799fc6
	v_mul_f32_e32 v198, v198, v208                             // 000000002890: 118da1c6
	v_dual_mul_f32 v222, v199, v204 :: v_dual_mul_f32 v145, v145, v189// 000000002894: c8c799c7 de917b91
	v_dual_mul_f32 v146, v146, v191 :: v_dual_mul_f32 v147, v147, v192// 00000000289c: c8c77f92 92938193
	v_dual_mul_f32 v148, v148, v193 :: v_dual_mul_f32 v149, v149, v194// 0000000028a4: c8c78394 94958595
	v_dual_mul_f32 v150, v150, v195 :: v_dual_mul_f32 v151, v151, v196// 0000000028ac: c8c78796 96978997
	v_mul_f32_e32 v152, v152, v197                             // 0000000028b4: 11318b98
	v_mul_f32_e32 v189, v199, v205                             // 0000000028b8: 117b9bc7
	v_dual_mul_f32 v191, v199, v206 :: v_dual_mul_f32 v192, v199, v207// 0000000028bc: c8c79dc7 bfc19fc7
	v_dual_mul_f32 v193, v199, v208 :: v_dual_mul_f32 v194, v200, v201// 0000000028c4: c8c7a1c7 c1c393c8
	v_dual_mul_f32 v195, v200, v202 :: v_dual_mul_f32 v196, v200, v203// 0000000028cc: c8c795c8 c3c597c8
	v_mul_f32_e32 v197, v200, v204                             // 0000000028d4: 118b99c8
	v_mul_f32_e32 v199, v200, v205                             // 0000000028d8: 118f9bc8
	v_dual_mul_f32 v201, v200, v206 :: v_dual_mul_f32 v202, v200, v207// 0000000028dc: c8c79dc8 c9cb9fc8
	v_dual_mul_f32 v200, v200, v208 :: v_dual_mul_f32 v155, v155, v213// 0000000028e4: c8c7a1c8 c89bab9b
	v_dual_mul_f32 v156, v156, v214 :: v_dual_mul_f32 v157, v157, v215// 0000000028ec: c8c7ad9c 9c9daf9d
	v_dual_mul_f32 v158, v158, v216 :: v_dual_mul_f32 v159, v159, v217// 0000000028f4: c8c7b19e 9e9fb39f
	v_mul_f32_e32 v160, v160, v190                             // 0000000028fc: 11417da0
	v_dual_mul_f32 v161, v161, v218 :: v_dual_mul_f32 v162, v162, v219// 000000002900: c8c7b5a1 a1a3b7a2
	v_dual_mul_f32 v163, v163, v220 :: v_dual_mul_f32 v164, v164, v185// 000000002908: c8c7b9a3 a3a573a4
	v_dual_mul_f32 v165, v165, v186 :: v_dual_mul_f32 v166, v166, v187// 000000002910: c8c775a5 a5a777a6
	v_dual_mul_f32 v167, v167, v188 :: v_dual_mul_f32 v168, v168, v198// 000000002918: c8c779a7 a7a98da8
	v_dual_mul_f32 v171, v171, v221 :: v_dual_mul_f32 v172, v172, v222// 000000002920: c8c7bbab abadbdac
	v_dual_mul_f32 v173, v173, v189 :: v_dual_mul_f32 v174, v174, v191// 000000002928: c8c77bad adaf7fae
	v_dual_mul_f32 v175, v175, v192 :: v_dual_mul_f32 v176, v176, v193// 000000002930: c8c781af afb183b0
	v_dual_mul_f32 v177, v177, v194 :: v_dual_mul_f32 v178, v178, v195// 000000002938: c8c785b1 b1b387b2
	v_dual_mul_f32 v179, v179, v196 :: v_dual_mul_f32 v180, v180, v197// 000000002940: c8c789b3 b3b58bb4
	v_dual_mul_f32 v181, v181, v199 :: v_dual_mul_f32 v182, v182, v201// 000000002948: c8c78fb5 b5b793b6
	v_dual_mul_f32 v183, v183, v202 :: v_dual_mul_f32 v184, v184, v200// 000000002950: c8c795b7 b7b991b8
	v_dual_add_f32 v85, v85, v129 :: v_dual_add_f32 v84, v84, v130// 000000002958: c9090355 55550554
	v_dual_add_f32 v83, v83, v131 :: v_dual_add_f32 v82, v82, v132// 000000002960: c9090753 53530952
	v_add_f32_e32 v79, v79, v133                               // 000000002968: 069f0b4f
	v_dual_add_f32 v75, v75, v134 :: v_dual_add_f32 v74, v74, v135// 00000000296c: c9090d4b 4b4b0f4a
	v_dual_add_f32 v71, v71, v136 :: v_dual_add_f32 v60, v60, v138// 000000002974: c9091147 473d153c
	v_add_f32_e32 v57, v57, v139                               // 00000000297c: 06731739
	v_dual_add_f32 v55, v55, v140 :: v_dual_add_f32 v54, v54, v141// 000000002980: c9091937 37371b36
	v_dual_add_f32 v52, v52, v142 :: v_dual_add_f32 v51, v51, v143// 000000002988: c9091d34 34331f33
	v_dual_add_f32 v48, v48, v144 :: v_dual_add_f32 v41, v41, v145// 000000002990: c9092130 30292329
	v_dual_add_f32 v40, v40, v146 :: v_dual_add_f32 v39, v39, v147// 000000002998: c9092528 28272727
	v_dual_add_f32 v38, v38, v148 :: v_dual_add_f32 v37, v37, v149// 0000000029a0: c9092926 26252b25
	v_dual_add_f32 v35, v35, v150 :: v_dual_add_f32 v34, v34, v151// 0000000029a8: c9092d23 23232f22
	v_dual_add_f32 v31, v31, v152 :: v_dual_add_f32 v106, v106, v153// 0000000029b0: c909311f 1f6b336a
	v_dual_add_f32 v104, v104, v154 :: v_dual_add_f32 v103, v103, v155// 0000000029b8: c9093568 68673767
	v_dual_add_f32 v102, v102, v156 :: v_dual_add_f32 v101, v101, v157// 0000000029c0: c9093966 66653b65
	v_dual_add_f32 v98, v98, v158 :: v_dual_add_f32 v97, v97, v159// 0000000029c8: c9093d62 62613f61
	v_add_f32_e32 v92, v92, v160                               // 0000000029d0: 06b9415c
	v_dual_add_f32 v76, v76, v161 :: v_dual_add_f32 v73, v73, v162// 0000000029d4: c909434c 4c494549
	v_add_f32_e32 v72, v72, v163                               // 0000000029dc: 06914748
	v_dual_add_f32 v70, v70, v164 :: v_dual_add_f32 v69, v69, v165// 0000000029e0: c9094946 46454b45
	v_dual_add_f32 v68, v68, v166 :: v_dual_add_f32 v67, v67, v167// 0000000029e8: c9094d44 44434f43
	v_dual_add_f32 v66, v66, v168 :: v_dual_add_f32 v53, v53, v169// 0000000029f0: c9095142 42355335
	v_dual_add_f32 v50, v50, v170 :: v_dual_add_f32 v49, v49, v171// 0000000029f8: c9095532 32315731
	v_dual_add_f32 v47, v47, v172 :: v_dual_add_f32 v46, v46, v173// 000000002a00: c909592f 2f2f5b2e
	v_dual_add_f32 v45, v45, v174 :: v_dual_add_f32 v44, v44, v175// 000000002a08: c9095d2d 2d2d5f2c
	v_add_f32_e32 v42, v42, v176                               // 000000002a10: 0655612a
	v_dual_add_f32 v36, v36, v177 :: v_dual_add_f32 v33, v33, v178// 000000002a14: c9096324 24216521
	v_add_f32_e32 v32, v32, v179                               // 000000002a1c: 06416720
	v_dual_add_f32 v30, v30, v180 :: v_dual_add_f32 v29, v29, v181// 000000002a20: c909691e 1e1d6b1d
	v_dual_add_f32 v28, v28, v182 :: v_dual_add_f32 v27, v27, v183// 000000002a28: c9096d1c 1c1b6f1b
	v_add_f32_e32 v26, v26, v184                               // 000000002a30: 0635711a
	s_cbranch_scc0 45                                          // 000000002a34: bfa1002d <tessera_rocm_scaled_matmul_lds_434e421f100676d4+0xfec>
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, 0               // 000000002a38: ca100080 00000080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 000000002a40: ca100080 02020080
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a48: bf88ff9e
	s_lshl_b64 s[12:13], s[4:5], 4                             // 000000002a4c: 848c8404
	s_and_saveexec_b32 s3, vcc_lo                              // 000000002a50: be83206a
	s_cbranch_execz 9                                          // 000000002a54: bfa50009 <tessera_rocm_scaled_matmul_lds_434e421f100676d4+0xf7c>
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a58: bf88ff9e
	v_add_co_u32 v0, s2, v8, s12                               // 000000002a5c: d7000200 02001908
	s_wait_alu depctr_va_sdst(0)                               // 000000002a64: bf88f19f
	v_add_co_ci_u32_e64 v1, null, s13, v9, s2                  // 000000002a68: d5207c01 000a120d
	global_load_b128 v[0:3], v[0:1], off                       // 000000002a70: ee05c07c 00000000 00000000
	s_wait_alu depctr_sa_sdst(0)                               // 000000002a7c: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s3                              // 000000002a80: 8c7e037e
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000002a84: ca100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0               // 000000002a8c: ca100080 06060080
	s_and_saveexec_b32 s3, vcc_lo                              // 000000002a94: be83206a
	s_cbranch_execz 8                                          // 000000002a98: bfa50008 <tessera_rocm_scaled_matmul_lds_434e421f100676d4+0xfbc>
	v_add_co_u32 v4, s2, v12, s12                              // 000000002a9c: d7000204 0200190c
	s_wait_alu depctr_va_sdst(0)                               // 000000002aa4: bf88f19f
	v_add_co_ci_u32_e64 v5, null, s13, v13, s2                 // 000000002aa8: d5207c05 000a1a0d
	global_load_b128 v[4:7], v[4:5], off                       // 000000002ab0: ee05c07c 00000004 00000004
	s_wait_alu depctr_sa_sdst(0)                               // 000000002abc: bf88ff9e
	s_or_b32 exec_lo, exec_lo, s3                              // 000000002ac0: 8c7e037e
	s_barrier_signal -1                                        // 000000002ac4: be804ec1
	s_barrier_wait 0xffff                                      // 000000002ac8: bf94ffff
	s_and_saveexec_b32 s2, vcc_lo                              // 000000002acc: be82206a
	s_cbranch_execz 65076                                      // 000000002ad0: bfa5fe34 <tessera_rocm_scaled_matmul_lds_434e421f100676d4+0x8a4>
	s_wait_loadcnt 0x0                                         // 000000002ad4: bfc00000
	ds_store_b128 v56, v[0:3]                                  // 000000002ad8: db7c0000 00000038
	ds_store_b128 v56, v[4:7] offset:4096                      // 000000002ae0: db7c1000 00000438
	s_branch 65070                                             // 000000002ae8: bfa0fe2e <tessera_rocm_scaled_matmul_lds_434e421f100676d4+0x8a4>
	s_load_b64 s[2:3], s[0:1], 0xa8                            // 000000002aec: f4002080 f80000a8
	v_mul_lo_u32 v2, s7, v10                                   // 000000002af4: d72c0002 02021407
	v_mul_lo_u32 v3, s6, v11                                   // 000000002afc: d72c0003 02021606
	v_mad_co_u64_u32 v[0:1], null, s6, v10, 0                  // 000000002b04: d6fe7c00 02021406
	v_bfe_u32 v4, v43, 16, 1                                   // 000000002b0c: d6100004 0205212b
	v_or_b32_e32 v5, 0x400000, v43                             // 000000002b14: 380a56ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v43, v43                           // 000000002b1c: 7c30572b
	v_lshlrev_b64_e32 v[58:59], 1, v[14:15]                    // 000000002b20: 3e741c81
	s_lshl_b64 s[0:1], s[6:7], 1                               // 000000002b24: 84808106
	v_add3_u32 v4, v4, v43, 0x7fff                             // 000000002b28: d6550004 03fe5704 00007fff
	v_or_b32_e32 v9, 0x400000, v117                            // 000000002b34: 3812eaff 00400000
	v_add3_u32 v1, v1, v3, v2                                  // 000000002b3c: d6550001 040a0701
	v_bfe_u32 v2, v118, 16, 1                                  // 000000002b44: d6100002 02052176
	v_or_b32_e32 v3, 0x400000, v118                            // 000000002b4c: 3806ecff 00400000
	v_cndmask_b32_e32 v6, v4, v5, vcc_lo                       // 000000002b54: 020c0b04
	v_bfe_u32 v4, v117, 16, 1                                  // 000000002b58: d6100004 02052175
	v_lshlrev_b64_e32 v[0:1], 1, v[0:1]                        // 000000002b60: 3e000081
	v_add3_u32 v2, v2, v118, 0x7fff                            // 000000002b64: d6550002 03feed02 00007fff
	v_bfe_u32 v11, v114, 16, 1                                 // 000000002b70: d610000b 02052172
	v_or_b32_e32 v12, 0x400000, v114                           // 000000002b78: 3818e4ff 00400000
	v_add3_u32 v4, v4, v117, 0x7fff                            // 000000002b80: d6550004 03feeb04 00007fff
	v_or_b32_e32 v15, 0x400000, v111                           // 000000002b8c: 381edeff 00400000
	s_wait_kmcnt 0x0                                           // 000000002b94: bfc70000
	v_add_co_u32 v0, vcc_lo, s2, v0                            // 000000002b98: d7006a00 02020002
	s_wait_alu depctr_va_vcc(0)                                // 000000002ba0: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 000000002ba4: d5207c01 01aa0203
	v_cmp_u_f32_e32 vcc_lo, v118, v118                         // 000000002bac: 7c30ed76
	v_add3_u32 v11, v11, v114, 0x7fff                          // 000000002bb0: d655000b 03fee50b 00007fff
	v_bfe_u32 v19, v109, 16, 1                                 // 000000002bbc: d6100013 0205216d
	v_or_b32_e32 v20, 0x400000, v109                           // 000000002bc4: 3828daff 00400000
	v_mul_lo_u32 v22, s7, v16                                  // 000000002bcc: d72c0016 02022007
	s_wait_alu depctr_va_vcc(0)                                // 000000002bd4: bf88ff9d
	v_cndmask_b32_e32 v7, v2, v3, vcc_lo                       // 000000002bd8: 020e0702
	v_add_co_u32 v2, vcc_lo, v0, v58                           // 000000002bdc: d7006a02 02027500
	s_wait_alu depctr_va_vcc(0)                                // 000000002be4: bf88ff9d
	v_add_co_ci_u32_e64 v3, null, v1, v59, vcc_lo              // 000000002be8: d5207c03 01aa7701
	v_add_co_u32 v5, vcc_lo, v0, s0                            // 000000002bf0: d7006a05 02000100
	s_wait_alu depctr_va_vcc(0)                                // 000000002bf8: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s1, v1, vcc_lo               // 000000002bfc: d5207c08 01aa0201
	v_add3_u32 v19, v19, v109, 0x7fff                          // 000000002c04: d6550013 03fedb13 00007fff
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002c10: bf8701a3
	v_add_co_u32 v0, vcc_lo, v5, v58                           // 000000002c14: d7006a00 02027505
	s_wait_alu depctr_va_vcc(0)                                // 000000002c1c: bf88ff9d
	v_add_co_ci_u32_e64 v1, null, v8, v59, vcc_lo              // 000000002c20: d5207c01 01aa7708
	v_cmp_u_f32_e32 vcc_lo, v117, v117                         // 000000002c28: 7c30eb75
	v_mul_lo_u32 v17, s6, v17                                  // 000000002c2c: d72c0011 02022206
	v_or_b32_e32 v23, 0x400000, v106                           // 000000002c34: 382ed4ff 00400000
	v_or_b32_e32 v24, 0x400000, v104                           // 000000002c3c: 3830d0ff 00400000
	v_or_b32_e32 v56, 0x400000, v102                           // 000000002c44: 3870ccff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000002c4c: bf88ff9d
	v_cndmask_b32_e32 v9, v4, v9, vcc_lo                       // 000000002c50: 02121304
	v_add_co_u32 v10, vcc_lo, v5, s0                           // 000000002c54: d7006a0a 02000105
	s_wait_alu depctr_va_vcc(0)                                // 000000002c5c: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s1, v8, vcc_lo               // 000000002c60: d5207c08 01aa1001
	v_bfe_u32 v62, v101, 16, 1                                 // 000000002c68: d610003e 02052165
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002c70: bf8701a3
	v_add_co_u32 v4, vcc_lo, v10, v58                          // 000000002c74: d7006a04 0202750a
	s_wait_alu depctr_va_vcc(0)                                // 000000002c7c: bf88ff9d
	v_add_co_ci_u32_e64 v5, null, v8, v59, vcc_lo              // 000000002c80: d5207c05 01aa7708
	v_cmp_u_f32_e32 vcc_lo, v114, v114                         // 000000002c88: 7c30e572
	s_clause 0x2                                               // 000000002c8c: bf850002
	global_store_d16_hi_b16 v[2:3], v6, off                    // 000000002c90: ee09407c 03000000 00000002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 000000002c9c: ee09407c 03800000 00000000
	global_store_d16_hi_b16 v[4:5], v9, off                    // 000000002ca8: ee09407c 04800000 00000004
	v_bfe_u32 v6, v113, 16, 1                                  // 000000002cb4: d6100006 02052171
	v_add3_u32 v62, v62, v101, 0x7fff                          // 000000002cbc: d655003e 03fecb3e 00007fff
	v_or_b32_e32 v64, 0x400000, v101                           // 000000002cc8: 3880caff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000002cd0: bf88ff9d
	v_cndmask_b32_e32 v12, v11, v12, vcc_lo                    // 000000002cd4: 0218190b
	v_add_co_u32 v9, vcc_lo, v10, s0                           // 000000002cd8: d7006a09 0200010a
	s_wait_alu depctr_va_vcc(0)                                // 000000002ce0: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s1, v8, vcc_lo               // 000000002ce4: d5207c08 01aa1001
	v_add3_u32 v10, v6, v113, 0x7fff                           // 000000002cec: d655000a 03fee306 00007fff
	s_delay_alu instid0(valu_dep_3)                            // 000000002cf8: bf870003
	v_add_co_u32 v6, vcc_lo, v9, v58                           // 000000002cfc: d7006a06 02027509
	v_or_b32_e32 v11, 0x400000, v113                           // 000000002d04: 3816e2ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000002d0c: bf88ff9d
	v_add_co_ci_u32_e64 v7, null, v8, v59, vcc_lo              // 000000002d10: d5207c07 01aa7708
	v_cmp_u_f32_e32 vcc_lo, v113, v113                         // 000000002d18: 7c30e371
	v_or_b32_e32 v78, 0x400000, v97                            // 000000002d1c: 389cc2ff 00400000
	v_bfe_u32 v81, v92, 16, 1                                  // 000000002d24: d6100051 0205215c
	v_or_b32_e32 v86, 0x400000, v92                            // 000000002d2c: 38acb8ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000002d34: bf88ff9d
	v_cndmask_b32_e32 v13, v10, v11, vcc_lo                    // 000000002d38: 021a170a
	v_bfe_u32 v10, v111, 16, 1                                 // 000000002d3c: d610000a 0205216f
	v_add_co_u32 v9, vcc_lo, v9, s0                            // 000000002d44: d7006a09 02000109
	s_wait_alu depctr_va_vcc(0)                                // 000000002d4c: bf88ff9d
	v_add_co_ci_u32_e64 v8, null, s1, v8, vcc_lo               // 000000002d50: d5207c08 01aa1001
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002d58: bf870193
	v_add3_u32 v14, v10, v111, 0x7fff                          // 000000002d5c: d655000e 03fedf0a 00007fff
	v_add_co_u32 v10, vcc_lo, v9, v58                          // 000000002d68: d7006a0a 02027509
	s_wait_alu depctr_va_vcc(0)                                // 000000002d70: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000002d74: bf870003
	v_add_co_ci_u32_e64 v11, null, v8, v59, vcc_lo             // 000000002d78: d5207c0b 01aa7708
	v_cmp_u_f32_e32 vcc_lo, v111, v111                         // 000000002d80: 7c30df6f
	v_add3_u32 v81, v81, v92, 0x7fff                           // 000000002d84: d6550051 03feb951 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000002d90: bf88ff9d
	v_cndmask_b32_e32 v14, v14, v15, vcc_lo                    // 000000002d94: 021c1f0e
	v_add_co_u32 v15, vcc_lo, v9, s0                           // 000000002d98: d7006a0f 02000109
	s_wait_alu depctr_va_vcc(0)                                // 000000002da0: bf88ff9d
	v_add_co_ci_u32_e64 v18, null, s1, v8, vcc_lo              // 000000002da4: d5207c12 01aa1001
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000002dac: bf870122
	v_add_co_u32 v8, vcc_lo, v15, v58                          // 000000002db0: d7006a08 0202750f
	s_wait_alu depctr_va_vcc(0)                                // 000000002db8: bf88ff9d
	v_add_co_ci_u32_e64 v9, null, v18, v59, vcc_lo             // 000000002dbc: d5207c09 01aa7712
	v_cmp_u_f32_e32 vcc_lo, v109, v109                         // 000000002dc4: 7c30db6d
	s_clause 0x2                                               // 000000002dc8: bf850002
	global_store_d16_hi_b16 v[6:7], v12, off                   // 000000002dcc: ee09407c 06000000 00000006
	global_store_d16_hi_b16 v[10:11], v13, off                 // 000000002dd8: ee09407c 06800000 0000000a
	global_store_d16_hi_b16 v[8:9], v14, off                   // 000000002de4: ee09407c 07000000 00000008
	v_bfe_u32 v12, v105, 16, 1                                 // 000000002df0: d610000c 02052169
	s_wait_alu depctr_va_vcc(0)                                // 000000002df8: bf88ff9d
	v_cndmask_b32_e32 v20, v19, v20, vcc_lo                    // 000000002dfc: 02282913
	v_add_co_u32 v19, vcc_lo, v15, s0                          // 000000002e00: d7006a13 0200010f
	s_wait_alu depctr_va_vcc(0)                                // 000000002e08: bf88ff9d
	v_add_co_ci_u32_e64 v18, null, s1, v18, vcc_lo             // 000000002e0c: d5207c12 01aa2401
	v_add3_u32 v21, v12, v105, 0x7fff                          // 000000002e14: d6550015 03fed30c 00007fff
	v_mad_co_u64_u32 v[12:13], null, s6, v16, 0                // 000000002e20: d6fe7c0c 02022006
	v_add_co_u32 v14, vcc_lo, v19, v58                         // 000000002e28: d7006a0e 02027513
	v_or_b32_e32 v16, 0x400000, v105                           // 000000002e30: 3820d2ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000002e38: bf88ff9d
	v_add_co_ci_u32_e64 v15, null, v18, v59, vcc_lo            // 000000002e3c: d5207c0f 01aa7712
	v_cmp_u_f32_e32 vcc_lo, v105, v105                         // 000000002e44: 7c30d369
	v_add3_u32 v13, v13, v17, v22                              // 000000002e48: d655000d 045a230d
	s_wait_alu depctr_va_vcc(0)                                // 000000002e50: bf88ff9d
	v_cndmask_b32_e32 v21, v21, v16, vcc_lo                    // 000000002e54: 022a2115
	v_bfe_u32 v16, v106, 16, 1                                 // 000000002e58: d6100010 0205216a
	v_add_co_u32 v19, vcc_lo, v19, s0                          // 000000002e60: d7006a13 02000113
	s_wait_alu depctr_va_vcc(0)                                // 000000002e68: bf88ff9d
	v_add_co_ci_u32_e64 v18, null, s1, v18, vcc_lo             // 000000002e6c: d5207c12 01aa2401
	s_delay_alu instid0(valu_dep_3)                            // 000000002e74: bf870003
	v_add3_u32 v22, v16, v106, 0x7fff                          // 000000002e78: d6550016 03fed510 00007fff
	v_lshlrev_b64_e32 v[16:17], 1, v[12:13]                    // 000000002e84: 3e201881
	v_add_co_u32 v12, vcc_lo, v19, v58                         // 000000002e88: d7006a0c 02027513
	s_wait_alu depctr_va_vcc(0)                                // 000000002e90: bf88ff9d
	v_add_co_ci_u32_e64 v13, null, v18, v59, vcc_lo            // 000000002e94: d5207c0d 01aa7712
	v_cmp_u_f32_e32 vcc_lo, v106, v106                         // 000000002e9c: 7c30d56a
	s_wait_alu depctr_va_vcc(0)                                // 000000002ea0: bf88ff9d
	v_cndmask_b32_e32 v22, v22, v23, vcc_lo                    // 000000002ea4: 022c2f16
	v_add_co_u32 v16, vcc_lo, s2, v16                          // 000000002ea8: d7006a10 02022002
	s_wait_alu depctr_va_vcc(0)                                // 000000002eb0: bf88ff9d
	v_add_co_ci_u32_e64 v17, null, s3, v17, vcc_lo             // 000000002eb4: d5207c11 01aa2203
	v_bfe_u32 v23, v104, 16, 1                                 // 000000002ebc: d6100017 02052168
	s_delay_alu instid0(valu_dep_3) | instskip(skip_1) | instid1(valu_dep_3)// 000000002ec4: bf8701a3
	v_add_co_u32 v18, vcc_lo, v16, v58                         // 000000002ec8: d7006a12 02027510
	s_wait_alu depctr_va_vcc(0)                                // 000000002ed0: bf88ff9d
	v_add_co_ci_u32_e64 v19, null, v17, v59, vcc_lo            // 000000002ed4: d5207c13 01aa7711
	s_delay_alu instid0(valu_dep_3)                            // 000000002edc: bf870003
	v_add3_u32 v23, v23, v104, 0x7fff                          // 000000002ee0: d6550017 03fed117 00007fff
	v_cmp_u_f32_e32 vcc_lo, v104, v104                         // 000000002eec: 7c30d168
	s_clause 0x2                                               // 000000002ef0: bf850002
	global_store_d16_hi_b16 v[14:15], v20, off                 // 000000002ef4: ee09407c 0a000000 0000000e
	global_store_d16_hi_b16 v[12:13], v21, off                 // 000000002f00: ee09407c 0a800000 0000000c
	global_store_d16_hi_b16 v[18:19], v22, off                 // 000000002f0c: ee09407c 0b000000 00000012
	v_bfe_u32 v20, v103, 16, 1                                 // 000000002f18: d6100014 02052167
	s_wait_alu depctr_va_vcc(0)                                // 000000002f20: bf88ff9d
	v_cndmask_b32_e32 v22, v23, v24, vcc_lo                    // 000000002f24: 022c3117
	v_add_co_u32 v16, vcc_lo, v16, s0                          // 000000002f28: d7006a10 02000110
	s_wait_alu depctr_va_vcc(0)                                // 000000002f30: bf88ff9d
	v_add_co_ci_u32_e64 v17, null, s1, v17, vcc_lo             // 000000002f34: d5207c11 01aa2201
	v_add3_u32 v23, v20, v103, 0x7fff                          // 000000002f3c: d6550017 03fecf14 00007fff
	s_delay_alu instid0(valu_dep_3)                            // 000000002f48: bf870003
	v_add_co_u32 v20, vcc_lo, v16, v58                         // 000000002f4c: d7006a14 02027510
	v_or_b32_e32 v24, 0x400000, v103                           // 000000002f54: 3830ceff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000002f5c: bf88ff9d
	v_add_co_ci_u32_e64 v21, null, v17, v59, vcc_lo            // 000000002f60: d5207c15 01aa7711
	v_cmp_u_f32_e32 vcc_lo, v103, v103                         // 000000002f68: 7c30cf67
	s_wait_alu depctr_va_vcc(0)                                // 000000002f6c: bf88ff9d
	v_cndmask_b32_e32 v23, v23, v24, vcc_lo                    // 000000002f70: 022e3117
	v_bfe_u32 v24, v102, 16, 1                                 // 000000002f74: d6100018 02052166
	v_add_co_u32 v16, vcc_lo, v16, s0                          // 000000002f7c: d7006a10 02000110
	s_wait_alu depctr_va_vcc(0)                                // 000000002f84: bf88ff9d
	v_add_co_ci_u32_e64 v17, null, s1, v17, vcc_lo             // 000000002f88: d5207c11 01aa2201
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000002f90: bf870193
	v_add3_u32 v43, v24, v102, 0x7fff                          // 000000002f94: d655002b 03fecd18 00007fff
	v_add_co_u32 v24, vcc_lo, v16, v58                         // 000000002fa0: d7006a18 02027510
	s_wait_alu depctr_va_vcc(0)                                // 000000002fa8: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 000000002fac: bf870003
	v_add_co_ci_u32_e64 v25, null, v17, v59, vcc_lo            // 000000002fb0: d5207c19 01aa7711
	v_cmp_u_f32_e32 vcc_lo, v102, v102                         // 000000002fb8: 7c30cd66
	s_wait_alu depctr_va_vcc(0)                                // 000000002fbc: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 000000002fc0: 0256712b
	v_add_co_u32 v56, vcc_lo, v16, s0                          // 000000002fc4: d7006a38 02000110
	s_wait_alu depctr_va_vcc(0)                                // 000000002fcc: bf88ff9d
	v_add_co_ci_u32_e64 v61, null, s1, v17, vcc_lo             // 000000002fd0: d5207c3d 01aa2201
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 000000002fd8: bf870122
	v_add_co_u32 v16, vcc_lo, v56, v58                         // 000000002fdc: d7006a10 02027538
	s_wait_alu depctr_va_vcc(0)                                // 000000002fe4: bf88ff9d
	v_add_co_ci_u32_e64 v17, null, v61, v59, vcc_lo            // 000000002fe8: d5207c11 01aa773d
	v_cmp_u_f32_e32 vcc_lo, v101, v101                         // 000000002ff0: 7c30cb65
	s_clause 0x2                                               // 000000002ff4: bf850002
	global_store_d16_hi_b16 v[20:21], v22, off                 // 000000002ff8: ee09407c 0b000000 00000014
	global_store_d16_hi_b16 v[24:25], v23, off                 // 000000003004: ee09407c 0b800000 00000018
	global_store_d16_hi_b16 v[16:17], v43, off                 // 000000003010: ee09407c 15800000 00000010
	v_bfe_u32 v22, v98, 16, 1                                  // 00000000301c: d6100016 02052162
	s_wait_alu depctr_va_vcc(0)                                // 000000003024: bf88ff9d
	v_cndmask_b32_e32 v43, v62, v64, vcc_lo                    // 000000003028: 0256813e
	v_add_co_u32 v56, vcc_lo, v56, s0                          // 00000000302c: d7006a38 02000138
	s_wait_alu depctr_va_vcc(0)                                // 000000003034: bf88ff9d
	v_add_co_ci_u32_e64 v61, null, s1, v61, vcc_lo             // 000000003038: d5207c3d 01aa7a01
	v_add3_u32 v62, v22, v98, 0x7fff                           // 000000003040: d655003e 03fec516 00007fff
	s_delay_alu instid0(valu_dep_3)                            // 00000000304c: bf870003
	v_add_co_u32 v22, vcc_lo, v56, v58                         // 000000003050: d7006a16 02027538
	v_or_b32_e32 v64, 0x400000, v98                            // 000000003058: 3880c4ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003060: bf88ff9d
	v_add_co_ci_u32_e64 v23, null, v61, v59, vcc_lo            // 000000003064: d5207c17 01aa773d
	v_cmp_u_f32_e32 vcc_lo, v98, v98                           // 00000000306c: 7c30c562
	s_wait_alu depctr_va_vcc(0)                                // 000000003070: bf88ff9d
	v_cndmask_b32_e32 v77, v62, v64, vcc_lo                    // 000000003074: 029a813e
	v_add_co_u32 v56, vcc_lo, v56, s0                          // 000000003078: d7006a38 02000138
	v_bfe_u32 v62, v97, 16, 1                                  // 000000003080: d610003e 02052161
	s_wait_alu depctr_va_vcc(0)                                // 000000003088: bf88ff9d
	v_add_co_ci_u32_e64 v64, null, s1, v61, vcc_lo             // 00000000308c: d5207c40 01aa7a01
	s_delay_alu instid0(valu_dep_3) | instskip(next) | instid1(valu_dep_3)// 000000003094: bf870193
	v_add_co_u32 v61, vcc_lo, v56, v58                         // 000000003098: d7006a3d 02027538
	v_add3_u32 v65, v62, v97, 0x7fff                           // 0000000030a0: d6550041 03fec33e 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000030ac: bf88ff9d
	s_delay_alu instid0(valu_dep_3)                            // 0000000030b0: bf870003
	v_add_co_ci_u32_e64 v62, null, v64, v59, vcc_lo            // 0000000030b4: d5207c3e 01aa7740
	v_cmp_u_f32_e32 vcc_lo, v97, v97                           // 0000000030bc: 7c30c361
	s_wait_alu depctr_va_vcc(0)                                // 0000000030c0: bf88ff9d
	v_cndmask_b32_e32 v78, v65, v78, vcc_lo                    // 0000000030c4: 029c9d41
	v_add_co_u32 v56, vcc_lo, v56, s0                          // 0000000030c8: d7006a38 02000138
	s_wait_alu depctr_va_vcc(0)                                // 0000000030d0: bf88ff9d
	v_add_co_ci_u32_e64 v80, null, s1, v64, vcc_lo             // 0000000030d4: d5207c50 01aa8001
	s_delay_alu instid0(valu_dep_2) | instskip(skip_1) | instid1(valu_dep_2)// 0000000030dc: bf870122
	v_add_co_u32 v64, vcc_lo, v56, v58                         // 0000000030e0: d7006a40 02027538
	s_wait_alu depctr_va_vcc(0)                                // 0000000030e8: bf88ff9d
	v_add_co_ci_u32_e64 v65, null, v80, v59, vcc_lo            // 0000000030ec: d5207c41 01aa7750
	v_cmp_u_f32_e32 vcc_lo, v92, v92                           // 0000000030f4: 7c30b95c
	s_clause 0x2                                               // 0000000030f8: bf850002
	global_store_d16_hi_b16 v[22:23], v43, off                 // 0000000030fc: ee09407c 15800000 00000016
	global_store_d16_hi_b16 v[61:62], v77, off                 // 000000003108: ee09407c 26800000 0000003d
	global_store_d16_hi_b16 v[64:65], v78, off                 // 000000003114: ee09407c 27000000 00000040
	v_bfe_u32 v77, v85, 16, 1                                  // 000000003120: d610004d 02052155
	s_wait_alu depctr_va_vcc(0)                                // 000000003128: bf88ff9d
	v_cndmask_b32_e32 v43, v81, v86, vcc_lo                    // 00000000312c: 0256ad51
	v_add_co_u32 v56, vcc_lo, v56, s0                          // 000000003130: d7006a38 02000138
	s_wait_alu depctr_va_vcc(0)                                // 000000003138: bf88ff9d
	v_add_co_ci_u32_e64 v78, null, s1, v80, vcc_lo             // 00000000313c: d5207c4e 01aaa001
	v_add3_u32 v77, v77, v85, 0x7fff                           // 000000003144: d655004d 03feab4d 00007fff
	s_delay_alu instid0(valu_dep_3)                            // 000000003150: bf870003
	v_add_co_u32 v58, vcc_lo, v56, v58                         // 000000003154: d7006a3a 02027538
	v_or_b32_e32 v80, 0x400000, v85                            // 00000000315c: 38a0aaff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003164: bf88ff9d
	v_add_co_ci_u32_e64 v59, null, v78, v59, vcc_lo            // 000000003168: d5207c3b 01aa774e
	v_bfe_u32 v56, v84, 16, 1                                  // 000000003170: d6100038 02052154
	v_cmp_u_f32_e32 vcc_lo, v85, v85                           // 000000003178: 7c30ab55
	v_bfe_u32 v78, v83, 16, 1                                  // 00000000317c: d610004e 02052153
	global_store_d16_hi_b16 v[58:59], v43, off                 // 000000003184: ee09407c 15800000 0000003a
	v_add3_u32 v43, v56, v84, 0x7fff                           // 000000003190: d655002b 03fea938 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 00000000319c: bf88ff9d
	v_cndmask_b32_e32 v77, v77, v80, vcc_lo                    // 0000000031a0: 029aa14d
	v_or_b32_e32 v56, 0x400000, v84                            // 0000000031a4: 3870a8ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v84, v84                           // 0000000031ac: 7c30a954
	global_store_d16_hi_b16 v[2:3], v77, off offset:32         // 0000000031b0: ee09407c 26800000 00002002
	v_add3_u32 v77, v78, v83, 0x7fff                           // 0000000031bc: d655004d 03fea74e 00007fff
	v_or_b32_e32 v78, 0x400000, v83                            // 0000000031c8: 389ca6ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000031d0: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 0000000031d4: 0256712b
	v_bfe_u32 v56, v82, 16, 1                                  // 0000000031d8: d6100038 02052152
	v_cmp_u_f32_e32 vcc_lo, v83, v83                           // 0000000031e0: 7c30a753
	global_store_d16_hi_b16 v[0:1], v43, off offset:32         // 0000000031e4: ee09407c 15800000 00002000
	v_add3_u32 v43, v56, v82, 0x7fff                           // 0000000031f0: d655002b 03fea538 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000031fc: bf88ff9d
	v_cndmask_b32_e32 v77, v77, v78, vcc_lo                    // 000000003200: 029a9d4d
	v_bfe_u32 v78, v79, 16, 1                                  // 000000003204: d610004e 0205214f
	v_or_b32_e32 v56, 0x400000, v82                            // 00000000320c: 3870a4ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v82, v82                           // 000000003214: 7c30a552
	global_store_d16_hi_b16 v[4:5], v77, off offset:32         // 000000003218: ee09407c 26800000 00002004
	v_add3_u32 v77, v78, v79, 0x7fff                           // 000000003224: d655004d 03fe9f4e 00007fff
	v_or_b32_e32 v78, 0x400000, v79                            // 000000003230: 389c9eff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003238: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 00000000323c: 0256712b
	v_bfe_u32 v56, v75, 16, 1                                  // 000000003240: d6100038 0205214b
	v_cmp_u_f32_e32 vcc_lo, v79, v79                           // 000000003248: 7c309f4f
	global_store_d16_hi_b16 v[6:7], v43, off offset:32         // 00000000324c: ee09407c 15800000 00002006
	v_add3_u32 v43, v56, v75, 0x7fff                           // 000000003258: d655002b 03fe9738 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003264: bf88ff9d
	v_cndmask_b32_e32 v77, v77, v78, vcc_lo                    // 000000003268: 029a9d4d
	v_bfe_u32 v78, v74, 16, 1                                  // 00000000326c: d610004e 0205214a
	v_or_b32_e32 v56, 0x400000, v75                            // 000000003274: 387096ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v75, v75                           // 00000000327c: 7c30974b
	v_bfe_u32 v75, v76, 16, 1                                  // 000000003280: d610004b 0205214c
	global_store_d16_hi_b16 v[10:11], v77, off offset:32       // 000000003288: ee09407c 26800000 0000200a
	v_add3_u32 v77, v78, v74, 0x7fff                           // 000000003294: d655004d 03fe954e 00007fff
	v_or_b32_e32 v78, 0x400000, v74                            // 0000000032a0: 389c94ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000032a8: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 0000000032ac: 0256712b
	v_bfe_u32 v56, v71, 16, 1                                  // 0000000032b0: d6100038 02052147
	v_cmp_u_f32_e32 vcc_lo, v74, v74                           // 0000000032b8: 7c30954a
	global_store_d16_hi_b16 v[8:9], v43, off offset:32         // 0000000032bc: ee09407c 15800000 00002008
	v_add3_u32 v43, v56, v71, 0x7fff                           // 0000000032c8: d655002b 03fe8f38 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000032d4: bf88ff9d
	v_cndmask_b32_e32 v74, v77, v78, vcc_lo                    // 0000000032d8: 02949d4d
	v_or_b32_e32 v56, 0x400000, v71                            // 0000000032dc: 38708eff 00400000
	v_cmp_u_f32_e32 vcc_lo, v71, v71                           // 0000000032e4: 7c308f47
	global_store_d16_hi_b16 v[14:15], v74, off offset:32       // 0000000032e8: ee09407c 25000000 0000200e
	v_add3_u32 v74, v75, v76, 0x7fff                           // 0000000032f4: d655004a 03fe994b 00007fff
	v_or_b32_e32 v75, 0x400000, v76                            // 000000003300: 389698ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003308: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 00000000330c: 0256712b
	v_bfe_u32 v56, v73, 16, 1                                  // 000000003310: d6100038 02052149
	v_cmp_u_f32_e32 vcc_lo, v76, v76                           // 000000003318: 7c30994c
	global_store_d16_hi_b16 v[12:13], v43, off offset:32       // 00000000331c: ee09407c 15800000 0000200c
	v_add3_u32 v43, v56, v73, 0x7fff                           // 000000003328: d655002b 03fe9338 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003334: bf88ff9d
	v_cndmask_b32_e32 v71, v74, v75, vcc_lo                    // 000000003338: 028e974a
	v_bfe_u32 v74, v72, 16, 1                                  // 00000000333c: d610004a 02052148
	v_or_b32_e32 v56, 0x400000, v73                            // 000000003344: 387092ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v73, v73                           // 00000000334c: 7c309349
	global_store_d16_hi_b16 v[18:19], v71, off offset:32       // 000000003350: ee09407c 23800000 00002012
	v_add3_u32 v71, v74, v72, 0x7fff                           // 00000000335c: d6550047 03fe914a 00007fff
	v_or_b32_e32 v74, 0x400000, v72                            // 000000003368: 389490ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003370: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 000000003374: 0256712b
	v_bfe_u32 v56, v70, 16, 1                                  // 000000003378: d6100038 02052146
	v_cmp_u_f32_e32 vcc_lo, v72, v72                           // 000000003380: 7c309148
	v_bfe_u32 v72, v69, 16, 1                                  // 000000003384: d6100048 02052145
	global_store_d16_hi_b16 v[20:21], v43, off offset:32       // 00000000338c: ee09407c 15800000 00002014
	v_add3_u32 v43, v56, v70, 0x7fff                           // 000000003398: d655002b 03fe8d38 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000033a4: bf88ff9d
	v_cndmask_b32_e32 v71, v71, v74, vcc_lo                    // 0000000033a8: 028e9547
	v_or_b32_e32 v56, 0x400000, v70                            // 0000000033ac: 38708cff 00400000
	v_cmp_u_f32_e32 vcc_lo, v70, v70                           // 0000000033b4: 7c308d46
	v_bfe_u32 v70, v67, 16, 1                                  // 0000000033b8: d6100046 02052143
	global_store_d16_hi_b16 v[24:25], v71, off offset:32       // 0000000033c0: ee09407c 23800000 00002018
	v_add3_u32 v71, v72, v69, 0x7fff                           // 0000000033cc: d6550047 03fe8b48 00007fff
	v_or_b32_e32 v72, 0x400000, v69                            // 0000000033d8: 38908aff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000033e0: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 0000000033e4: 0256712b
	v_bfe_u32 v56, v68, 16, 1                                  // 0000000033e8: d6100038 02052144
	v_cmp_u_f32_e32 vcc_lo, v69, v69                           // 0000000033f0: 7c308b45
	global_store_d16_hi_b16 v[16:17], v43, off offset:32       // 0000000033f4: ee09407c 15800000 00002010
	v_add3_u32 v43, v56, v68, 0x7fff                           // 000000003400: d655002b 03fe8938 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 00000000340c: bf88ff9d
	v_cndmask_b32_e32 v69, v71, v72, vcc_lo                    // 000000003410: 028a9147
	v_or_b32_e32 v56, 0x400000, v68                            // 000000003414: 387088ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v68, v68                           // 00000000341c: 7c308944
	v_bfe_u32 v68, v63, 16, 1                                  // 000000003420: d6100044 0205213f
	global_store_d16_hi_b16 v[22:23], v69, off offset:32       // 000000003428: ee09407c 22800000 00002016
	v_add3_u32 v69, v70, v67, 0x7fff                           // 000000003434: d6550045 03fe8746 00007fff
	v_or_b32_e32 v70, 0x400000, v67                            // 000000003440: 388c86ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003448: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 00000000344c: 0256712b
	v_bfe_u32 v56, v66, 16, 1                                  // 000000003450: d6100038 02052142
	v_cmp_u_f32_e32 vcc_lo, v67, v67                           // 000000003458: 7c308743
	global_store_d16_hi_b16 v[61:62], v43, off offset:32       // 00000000345c: ee09407c 15800000 0000203d
	v_add3_u32 v43, v56, v66, 0x7fff                           // 000000003468: d655002b 03fe8538 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003474: bf88ff9d
	v_cndmask_b32_e32 v67, v69, v70, vcc_lo                    // 000000003478: 02868d45
	v_or_b32_e32 v56, 0x400000, v66                            // 00000000347c: 387084ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v66, v66                           // 000000003484: 7c308542
	v_bfe_u32 v66, v57, 16, 1                                  // 000000003488: d6100042 02052139
	global_store_d16_hi_b16 v[64:65], v67, off offset:32       // 000000003490: ee09407c 21800000 00002040
	v_add3_u32 v67, v68, v63, 0x7fff                           // 00000000349c: d6550043 03fe7f44 00007fff
	v_or_b32_e32 v68, 0x400000, v63                            // 0000000034a8: 38887eff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000034b0: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 0000000034b4: 0256712b
	v_bfe_u32 v56, v60, 16, 1                                  // 0000000034b8: d6100038 0205213c
	v_cmp_u_f32_e32 vcc_lo, v63, v63                           // 0000000034c0: 7c307f3f
	global_store_d16_hi_b16 v[58:59], v43, off offset:32       // 0000000034c4: ee09407c 15800000 0000203a
	v_add3_u32 v43, v56, v60, 0x7fff                           // 0000000034d0: d655002b 03fe7938 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000034dc: bf88ff9d
	v_cndmask_b32_e32 v63, v67, v68, vcc_lo                    // 0000000034e0: 027e8943
	v_or_b32_e32 v56, 0x400000, v60                            // 0000000034e4: 387078ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v60, v60                           // 0000000034ec: 7c30793c
	v_bfe_u32 v60, v54, 16, 1                                  // 0000000034f0: d610003c 02052136
	global_store_d16_hi_b16 v[2:3], v63, off offset:64         // 0000000034f8: ee09407c 1f800000 00004002
	v_add3_u32 v63, v66, v57, 0x7fff                           // 000000003504: d655003f 03fe7342 00007fff
	v_or_b32_e32 v66, 0x400000, v57                            // 000000003510: 388472ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003518: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 00000000351c: 0256712b
	v_bfe_u32 v56, v55, 16, 1                                  // 000000003520: d6100038 02052137
	v_cmp_u_f32_e32 vcc_lo, v57, v57                           // 000000003528: 7c307339
	global_store_d16_hi_b16 v[0:1], v43, off offset:64         // 00000000352c: ee09407c 15800000 00004000
	v_add3_u32 v43, v56, v55, 0x7fff                           // 000000003538: d655002b 03fe6f38 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003544: bf88ff9d
	v_cndmask_b32_e32 v57, v63, v66, vcc_lo                    // 000000003548: 0272853f
	v_or_b32_e32 v56, 0x400000, v55                            // 00000000354c: 38706eff 00400000
	v_cmp_u_f32_e32 vcc_lo, v55, v55                           // 000000003554: 7c306f37
	v_bfe_u32 v55, v52, 16, 1                                  // 000000003558: d6100037 02052134
	global_store_d16_hi_b16 v[4:5], v57, off offset:64         // 000000003560: ee09407c 1c800000 00004004
	v_add3_u32 v57, v60, v54, 0x7fff                           // 00000000356c: d6550039 03fe6d3c 00007fff
	v_or_b32_e32 v60, 0x400000, v54                            // 000000003578: 38786cff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003580: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v56, vcc_lo                    // 000000003584: 0256712b
	v_cmp_u_f32_e32 vcc_lo, v54, v54                           // 000000003588: 7c306d36
	v_bfe_u32 v56, v51, 16, 1                                  // 00000000358c: d6100038 02052133
	global_store_d16_hi_b16 v[6:7], v43, off offset:64         // 000000003594: ee09407c 15800000 00004006
	s_wait_alu depctr_va_vcc(0)                                // 0000000035a0: bf88ff9d
	v_cndmask_b32_e32 v54, v57, v60, vcc_lo                    // 0000000035a4: 026c7939
	v_add3_u32 v43, v55, v52, 0x7fff                           // 0000000035a8: d655002b 03fe6937 00007fff
	v_or_b32_e32 v55, 0x400000, v52                            // 0000000035b4: 386e68ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v52, v52                           // 0000000035bc: 7c306934
	v_bfe_u32 v52, v48, 16, 1                                  // 0000000035c0: d6100034 02052130
	global_store_d16_hi_b16 v[10:11], v54, off offset:64       // 0000000035c8: ee09407c 1b000000 0000400a
	v_add3_u32 v54, v56, v51, 0x7fff                           // 0000000035d4: d6550036 03fe6738 00007fff
	v_or_b32_e32 v56, 0x400000, v51                            // 0000000035e0: 387066ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000035e8: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v55, vcc_lo                    // 0000000035ec: 02566f2b
	v_cmp_u_f32_e32 vcc_lo, v51, v51                           // 0000000035f0: 7c306733
	global_store_d16_hi_b16 v[8:9], v43, off offset:64         // 0000000035f4: ee09407c 15800000 00004008
	s_wait_alu depctr_va_vcc(0)                                // 000000003600: bf88ff9d
	v_cndmask_b32_e32 v51, v54, v56, vcc_lo                    // 000000003604: 02667136
	v_bfe_u32 v54, v53, 16, 1                                  // 000000003608: d6100036 02052135
	v_add3_u32 v43, v52, v48, 0x7fff                           // 000000003610: d655002b 03fe6134 00007fff
	v_or_b32_e32 v52, 0x400000, v48                            // 00000000361c: 386860ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v48, v48                           // 000000003624: 7c306130
	global_store_d16_hi_b16 v[14:15], v51, off offset:64       // 000000003628: ee09407c 19800000 0000400e
	v_add3_u32 v51, v54, v53, 0x7fff                           // 000000003634: d6550033 03fe6b36 00007fff
	v_or_b32_e32 v54, 0x400000, v53                            // 000000003640: 386c6aff 00400000
	v_bfe_u32 v48, v50, 16, 1                                  // 000000003648: d6100030 02052132
	s_wait_alu depctr_va_vcc(0)                                // 000000003650: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v52, vcc_lo                    // 000000003654: 0256692b
	v_cmp_u_f32_e32 vcc_lo, v53, v53                           // 000000003658: 7c306b35
	v_bfe_u32 v52, v49, 16, 1                                  // 00000000365c: d6100034 02052131
	global_store_d16_hi_b16 v[12:13], v43, off offset:64       // 000000003664: ee09407c 15800000 0000400c
	s_wait_alu depctr_va_vcc(0)                                // 000000003670: bf88ff9d
	v_cndmask_b32_e32 v51, v51, v54, vcc_lo                    // 000000003674: 02666d33
	v_add3_u32 v43, v48, v50, 0x7fff                           // 000000003678: d655002b 03fe6530 00007fff
	v_or_b32_e32 v48, 0x400000, v50                            // 000000003684: 386064ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v50, v50                           // 00000000368c: 7c306532
	v_bfe_u32 v50, v46, 16, 1                                  // 000000003690: d6100032 0205212e
	global_store_d16_hi_b16 v[18:19], v51, off offset:64       // 000000003698: ee09407c 19800000 00004012
	v_add3_u32 v51, v52, v49, 0x7fff                           // 0000000036a4: d6550033 03fe6334 00007fff
	v_or_b32_e32 v52, 0x400000, v49                            // 0000000036b0: 386862ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000036b8: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v48, vcc_lo                    // 0000000036bc: 0256612b
	v_bfe_u32 v48, v47, 16, 1                                  // 0000000036c0: d6100030 0205212f
	v_cmp_u_f32_e32 vcc_lo, v49, v49                           // 0000000036c8: 7c306331
	global_store_d16_hi_b16 v[20:21], v43, off offset:64       // 0000000036cc: ee09407c 15800000 00004014
	v_add3_u32 v43, v48, v47, 0x7fff                           // 0000000036d8: d655002b 03fe5f30 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000036e4: bf88ff9d
	v_cndmask_b32_e32 v49, v51, v52, vcc_lo                    // 0000000036e8: 02626933
	v_or_b32_e32 v48, 0x400000, v47                            // 0000000036ec: 38605eff 00400000
	v_cmp_u_f32_e32 vcc_lo, v47, v47                           // 0000000036f4: 7c305f2f
	v_bfe_u32 v47, v45, 16, 1                                  // 0000000036f8: d610002f 0205212d
	global_store_d16_hi_b16 v[24:25], v49, off offset:64       // 000000003700: ee09407c 18800000 00004018
	v_add3_u32 v49, v50, v46, 0x7fff                           // 00000000370c: d6550031 03fe5d32 00007fff
	v_or_b32_e32 v50, 0x400000, v46                            // 000000003718: 38645cff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003720: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v48, vcc_lo                    // 000000003724: 0256612b
	v_cmp_u_f32_e32 vcc_lo, v46, v46                           // 000000003728: 7c305d2e
	v_bfe_u32 v48, v44, 16, 1                                  // 00000000372c: d6100030 0205212c
	global_store_d16_hi_b16 v[16:17], v43, off offset:64       // 000000003734: ee09407c 15800000 00004010
	s_wait_alu depctr_va_vcc(0)                                // 000000003740: bf88ff9d
	v_cndmask_b32_e32 v46, v49, v50, vcc_lo                    // 000000003744: 025c6531
	v_add3_u32 v43, v47, v45, 0x7fff                           // 000000003748: d655002b 03fe5b2f 00007fff
	v_or_b32_e32 v47, 0x400000, v45                            // 000000003754: 385e5aff 00400000
	v_cmp_u_f32_e32 vcc_lo, v45, v45                           // 00000000375c: 7c305b2d
	v_bfe_u32 v45, v42, 16, 1                                  // 000000003760: d610002d 0205212a
	global_store_d16_hi_b16 v[22:23], v46, off offset:64       // 000000003768: ee09407c 17000000 00004016
	v_add3_u32 v46, v48, v44, 0x7fff                           // 000000003774: d655002e 03fe5930 00007fff
	v_or_b32_e32 v48, 0x400000, v44                            // 000000003780: 386058ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003788: bf88ff9d
	v_cndmask_b32_e32 v43, v43, v47, vcc_lo                    // 00000000378c: 02565f2b
	v_cmp_u_f32_e32 vcc_lo, v44, v44                           // 000000003790: 7c30592c
	global_store_d16_hi_b16 v[61:62], v43, off offset:64       // 000000003794: ee09407c 15800000 0000403d
	s_wait_alu depctr_va_vcc(0)                                // 0000000037a0: bf88ff9d
	v_cndmask_b32_e32 v44, v46, v48, vcc_lo                    // 0000000037a4: 0258612e
	v_bfe_u32 v46, v41, 16, 1                                  // 0000000037a8: d610002e 02052129
	v_add3_u32 v43, v45, v42, 0x7fff                           // 0000000037b0: d655002b 03fe552d 00007fff
	v_or_b32_e32 v45, 0x400000, v42                            // 0000000037bc: 385a54ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v42, v42                           // 0000000037c4: 7c30552a
	global_store_d16_hi_b16 v[64:65], v44, off offset:64       // 0000000037c8: ee09407c 16000000 00004040
	v_add3_u32 v44, v46, v41, 0x7fff                           // 0000000037d4: d655002c 03fe532e 00007fff
	v_or_b32_e32 v46, 0x400000, v41                            // 0000000037e0: 385c52ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000037e8: bf88ff9d
	v_cndmask_b32_e32 v42, v43, v45, vcc_lo                    // 0000000037ec: 02545b2b
	v_bfe_u32 v43, v40, 16, 1                                  // 0000000037f0: d610002b 02052128
	v_cmp_u_f32_e32 vcc_lo, v41, v41                           // 0000000037f8: 7c305329
	global_store_d16_hi_b16 v[58:59], v42, off offset:64       // 0000000037fc: ee09407c 15000000 0000403a
	v_add3_u32 v42, v43, v40, 0x7fff                           // 000000003808: d655002a 03fe512b 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003814: bf88ff9d
	v_cndmask_b32_e32 v41, v44, v46, vcc_lo                    // 000000003818: 02525d2c
	v_bfe_u32 v44, v39, 16, 1                                  // 00000000381c: d610002c 02052127
	v_or_b32_e32 v43, 0x400000, v40                            // 000000003824: 385650ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v40, v40                           // 00000000382c: 7c305128
	global_store_d16_hi_b16 v[2:3], v41, off offset:96         // 000000003830: ee09407c 14800000 00006002
	v_add3_u32 v2, v44, v39, 0x7fff                            // 00000000383c: d6550002 03fe4f2c 00007fff
	v_or_b32_e32 v3, 0x400000, v39                             // 000000003848: 38064eff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003850: bf88ff9d
	v_cndmask_b32_e32 v40, v42, v43, vcc_lo                    // 000000003854: 0250572a
	v_bfe_u32 v41, v38, 16, 1                                  // 000000003858: d6100029 02052126
	v_cmp_u_f32_e32 vcc_lo, v39, v39                           // 000000003860: 7c304f27
	global_store_d16_hi_b16 v[0:1], v40, off offset:96         // 000000003864: ee09407c 14000000 00006000
	v_add3_u32 v0, v41, v38, 0x7fff                            // 000000003870: d6550000 03fe4d29 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 00000000387c: bf88ff9d
	v_cndmask_b32_e32 v2, v2, v3, vcc_lo                       // 000000003880: 02040702
	v_bfe_u32 v3, v37, 16, 1                                   // 000000003884: d6100003 02052125
	v_or_b32_e32 v1, 0x400000, v38                             // 00000000388c: 38024cff 00400000
	v_cmp_u_f32_e32 vcc_lo, v38, v38                           // 000000003894: 7c304d26
	global_store_d16_hi_b16 v[4:5], v2, off offset:96          // 000000003898: ee09407c 01000000 00006004
	v_add3_u32 v2, v3, v37, 0x7fff                             // 0000000038a4: d6550002 03fe4b03 00007fff
	v_or_b32_e32 v3, 0x400000, v37                             // 0000000038b0: 38064aff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000038b8: bf88ff9d
	v_cndmask_b32_e32 v0, v0, v1, vcc_lo                       // 0000000038bc: 02000300
	v_bfe_u32 v1, v35, 16, 1                                   // 0000000038c0: d6100001 02052123
	v_cmp_u_f32_e32 vcc_lo, v37, v37                           // 0000000038c8: 7c304b25
	v_bfe_u32 v4, v27, 16, 1                                   // 0000000038cc: d6100004 0205211b
	v_or_b32_e32 v5, 0x400000, v28                             // 0000000038d4: 380a38ff 00400000
	global_store_d16_hi_b16 v[6:7], v0, off offset:96          // 0000000038dc: ee09407c 00000000 00006006
	v_add3_u32 v0, v1, v35, 0x7fff                             // 0000000038e8: d6550000 03fe4701 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000038f4: bf88ff9d
	v_cndmask_b32_e32 v2, v2, v3, vcc_lo                       // 0000000038f8: 02040702
	v_bfe_u32 v3, v34, 16, 1                                   // 0000000038fc: d6100003 02052122
	v_or_b32_e32 v1, 0x400000, v35                             // 000000003904: 380246ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v35, v35                           // 00000000390c: 7c304723
	v_add3_u32 v4, v4, v27, 0x7fff                             // 000000003910: d6550004 03fe3704 00007fff
	global_store_d16_hi_b16 v[10:11], v2, off offset:96        // 00000000391c: ee09407c 01000000 0000600a
	v_add3_u32 v2, v3, v34, 0x7fff                             // 000000003928: d6550002 03fe4503 00007fff
	v_or_b32_e32 v3, 0x400000, v34                             // 000000003934: 380644ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 00000000393c: bf88ff9d
	v_cndmask_b32_e32 v0, v0, v1, vcc_lo                       // 000000003940: 02000300
	v_bfe_u32 v1, v31, 16, 1                                   // 000000003944: d6100001 0205211f
	v_cmp_u_f32_e32 vcc_lo, v34, v34                           // 00000000394c: 7c304522
	v_or_b32_e32 v6, 0x400000, v27                             // 000000003950: 380c36ff 00400000
	v_or_b32_e32 v7, 0x400000, v26                             // 000000003958: 380e34ff 00400000
	global_store_d16_hi_b16 v[8:9], v0, off offset:96          // 000000003960: ee09407c 00000000 00006008
	v_add3_u32 v0, v1, v31, 0x7fff                             // 00000000396c: d6550000 03fe3f01 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003978: bf88ff9d
	v_cndmask_b32_e32 v2, v2, v3, vcc_lo                       // 00000000397c: 02040702
	v_bfe_u32 v3, v36, 16, 1                                   // 000000003980: d6100003 02052124
	v_or_b32_e32 v1, 0x400000, v31                             // 000000003988: 38023eff 00400000
	v_cmp_u_f32_e32 vcc_lo, v31, v31                           // 000000003990: 7c303f1f
	global_store_d16_hi_b16 v[14:15], v2, off offset:96        // 000000003994: ee09407c 01000000 0000600e
	v_add3_u32 v2, v3, v36, 0x7fff                             // 0000000039a0: d6550002 03fe4903 00007fff
	v_or_b32_e32 v3, 0x400000, v36                             // 0000000039ac: 380648ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 0000000039b4: bf88ff9d
	v_cndmask_b32_e32 v0, v0, v1, vcc_lo                       // 0000000039b8: 02000300
	v_bfe_u32 v1, v33, 16, 1                                   // 0000000039bc: d6100001 02052121
	v_cmp_u_f32_e32 vcc_lo, v36, v36                           // 0000000039c4: 7c304924
	global_store_d16_hi_b16 v[12:13], v0, off offset:96        // 0000000039c8: ee09407c 00000000 0000600c
	v_add3_u32 v0, v1, v33, 0x7fff                             // 0000000039d4: d6550000 03fe4301 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 0000000039e0: bf88ff9d
	v_cndmask_b32_e32 v2, v2, v3, vcc_lo                       // 0000000039e4: 02040702
	v_bfe_u32 v3, v32, 16, 1                                   // 0000000039e8: d6100003 02052120
	v_or_b32_e32 v1, 0x400000, v33                             // 0000000039f0: 380242ff 00400000
	v_cmp_u_f32_e32 vcc_lo, v33, v33                           // 0000000039f8: 7c304321
	global_store_d16_hi_b16 v[18:19], v2, off offset:96        // 0000000039fc: ee09407c 01000000 00006012
	v_add3_u32 v2, v3, v32, 0x7fff                             // 000000003a08: d6550002 03fe4103 00007fff
	v_or_b32_e32 v3, 0x400000, v32                             // 000000003a14: 380640ff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003a1c: bf88ff9d
	v_cndmask_b32_e32 v0, v0, v1, vcc_lo                       // 000000003a20: 02000300
	v_bfe_u32 v1, v30, 16, 1                                   // 000000003a24: d6100001 0205211e
	v_cmp_u_f32_e32 vcc_lo, v32, v32                           // 000000003a2c: 7c304120
	global_store_d16_hi_b16 v[20:21], v0, off offset:96        // 000000003a30: ee09407c 00000000 00006014
	v_add3_u32 v0, v1, v30, 0x7fff                             // 000000003a3c: d6550000 03fe3d01 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003a48: bf88ff9d
	v_cndmask_b32_e32 v2, v2, v3, vcc_lo                       // 000000003a4c: 02040702
	v_bfe_u32 v3, v29, 16, 1                                   // 000000003a50: d6100003 0205211d
	v_or_b32_e32 v1, 0x400000, v30                             // 000000003a58: 38023cff 00400000
	v_cmp_u_f32_e32 vcc_lo, v30, v30                           // 000000003a60: 7c303d1e
	global_store_d16_hi_b16 v[24:25], v2, off offset:96        // 000000003a64: ee09407c 01000000 00006018
	v_add3_u32 v2, v3, v29, 0x7fff                             // 000000003a70: d6550002 03fe3b03 00007fff
	v_or_b32_e32 v3, 0x400000, v29                             // 000000003a7c: 38063aff 00400000
	s_wait_alu depctr_va_vcc(0)                                // 000000003a84: bf88ff9d
	v_cndmask_b32_e32 v0, v0, v1, vcc_lo                       // 000000003a88: 02000300
	v_bfe_u32 v1, v28, 16, 1                                   // 000000003a8c: d6100001 0205211c
	v_cmp_u_f32_e32 vcc_lo, v29, v29                           // 000000003a94: 7c303b1d
	s_delay_alu instid0(valu_dep_2)                            // 000000003a98: bf870002
	v_add3_u32 v1, v1, v28, 0x7fff                             // 000000003a9c: d6550001 03fe3901 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003aa8: bf88ff9d
	v_cndmask_b32_e32 v2, v2, v3, vcc_lo                       // 000000003aac: 02040702
	v_cmp_u_f32_e32 vcc_lo, v28, v28                           // 000000003ab0: 7c30391c
	v_bfe_u32 v3, v26, 16, 1                                   // 000000003ab4: d6100003 0205211a
	s_wait_alu depctr_va_vcc(0)                                // 000000003abc: bf88ff9d
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 000000003ac0: 02020b01
	v_cmp_u_f32_e32 vcc_lo, v27, v27                           // 000000003ac4: 7c30371b
	s_delay_alu instid0(valu_dep_3)                            // 000000003ac8: bf870003
	v_add3_u32 v3, v3, v26, 0x7fff                             // 000000003acc: d6550003 03fe3503 00007fff
	s_wait_alu depctr_va_vcc(0)                                // 000000003ad8: bf88ff9d
	v_cndmask_b32_e32 v4, v4, v6, vcc_lo                       // 000000003adc: 02080d04
	v_cmp_u_f32_e32 vcc_lo, v26, v26                           // 000000003ae0: 7c30351a
	s_wait_alu depctr_va_vcc(0)                                // 000000003ae4: bf88ff9d
	v_cndmask_b32_e32 v3, v3, v7, vcc_lo                       // 000000003ae8: 02060f03
	s_clause 0x3                                               // 000000003aec: bf850003
	global_store_d16_hi_b16 v[16:17], v0, off offset:96        // 000000003af0: ee09407c 00000000 00006010
	global_store_d16_hi_b16 v[22:23], v2, off offset:96        // 000000003afc: ee09407c 01000000 00006016
	global_store_d16_hi_b16 v[61:62], v1, off offset:96        // 000000003b08: ee09407c 00800000 0000603d
	global_store_d16_hi_b16 v[64:65], v4, off offset:96        // 000000003b14: ee09407c 02000000 00006040
	global_store_d16_hi_b16 v[58:59], v3, off offset:96        // 000000003b20: ee09407c 01800000 0000603a
	s_nop 0                                                    // 000000003b2c: bf800000
	s_sendmsg sendmsg(msg_dealloc_vgprs)                       // 000000003b30: bfb60003
	s_endpgm                                                   // 000000003b34: bfb00000
	s_code_end                                                 // 000000003b38: bf9f0000
	s_code_end                                                 // 000000003b3c: bf9f0000
	s_code_end                                                 // 000000003b40: bf9f0000
	s_code_end                                                 // 000000003b44: bf9f0000
	s_code_end                                                 // 000000003b48: bf9f0000
	s_code_end                                                 // 000000003b4c: bf9f0000
	s_code_end                                                 // 000000003b50: bf9f0000
	s_code_end                                                 // 000000003b54: bf9f0000
	s_code_end                                                 // 000000003b58: bf9f0000
	s_code_end                                                 // 000000003b5c: bf9f0000
	s_code_end                                                 // 000000003b60: bf9f0000
	s_code_end                                                 // 000000003b64: bf9f0000
	s_code_end                                                 // 000000003b68: bf9f0000
	s_code_end                                                 // 000000003b6c: bf9f0000
	s_code_end                                                 // 000000003b70: bf9f0000
	s_code_end                                                 // 000000003b74: bf9f0000
	s_code_end                                                 // 000000003b78: bf9f0000
	s_code_end                                                 // 000000003b7c: bf9f0000
	s_code_end                                                 // 000000003b80: bf9f0000
	s_code_end                                                 // 000000003b84: bf9f0000
	s_code_end                                                 // 000000003b88: bf9f0000
	s_code_end                                                 // 000000003b8c: bf9f0000
	s_code_end                                                 // 000000003b90: bf9f0000
	s_code_end                                                 // 000000003b94: bf9f0000
	s_code_end                                                 // 000000003b98: bf9f0000
	s_code_end                                                 // 000000003b9c: bf9f0000
	s_code_end                                                 // 000000003ba0: bf9f0000
	s_code_end                                                 // 000000003ba4: bf9f0000
	s_code_end                                                 // 000000003ba8: bf9f0000
	s_code_end                                                 // 000000003bac: bf9f0000
	s_code_end                                                 // 000000003bb0: bf9f0000
	s_code_end                                                 // 000000003bb4: bf9f0000
	s_code_end                                                 // 000000003bb8: bf9f0000
	s_code_end                                                 // 000000003bbc: bf9f0000
	s_code_end                                                 // 000000003bc0: bf9f0000
	s_code_end                                                 // 000000003bc4: bf9f0000
	s_code_end                                                 // 000000003bc8: bf9f0000
	s_code_end                                                 // 000000003bcc: bf9f0000
	s_code_end                                                 // 000000003bd0: bf9f0000
	s_code_end                                                 // 000000003bd4: bf9f0000
	s_code_end                                                 // 000000003bd8: bf9f0000
	s_code_end                                                 // 000000003bdc: bf9f0000
	s_code_end                                                 // 000000003be0: bf9f0000
	s_code_end                                                 // 000000003be4: bf9f0000
	s_code_end                                                 // 000000003be8: bf9f0000
	s_code_end                                                 // 000000003bec: bf9f0000
	s_code_end                                                 // 000000003bf0: bf9f0000
	s_code_end                                                 // 000000003bf4: bf9f0000
	s_code_end                                                 // 000000003bf8: bf9f0000
	s_code_end                                                 // 000000003bfc: bf9f0000
	s_code_end                                                 // 000000003c00: bf9f0000
	s_code_end                                                 // 000000003c04: bf9f0000
	s_code_end                                                 // 000000003c08: bf9f0000
	s_code_end                                                 // 000000003c0c: bf9f0000
	s_code_end                                                 // 000000003c10: bf9f0000
	s_code_end                                                 // 000000003c14: bf9f0000
	s_code_end                                                 // 000000003c18: bf9f0000
	s_code_end                                                 // 000000003c1c: bf9f0000
	s_code_end                                                 // 000000003c20: bf9f0000
	s_code_end                                                 // 000000003c24: bf9f0000
	s_code_end                                                 // 000000003c28: bf9f0000
	s_code_end                                                 // 000000003c2c: bf9f0000
	s_code_end                                                 // 000000003c30: bf9f0000
	s_code_end                                                 // 000000003c34: bf9f0000
	s_code_end                                                 // 000000003c38: bf9f0000
	s_code_end                                                 // 000000003c3c: bf9f0000
	s_code_end                                                 // 000000003c40: bf9f0000
	s_code_end                                                 // 000000003c44: bf9f0000
	s_code_end                                                 // 000000003c48: bf9f0000
	s_code_end                                                 // 000000003c4c: bf9f0000
	s_code_end                                                 // 000000003c50: bf9f0000
	s_code_end                                                 // 000000003c54: bf9f0000
	s_code_end                                                 // 000000003c58: bf9f0000
	s_code_end                                                 // 000000003c5c: bf9f0000
	s_code_end                                                 // 000000003c60: bf9f0000
	s_code_end                                                 // 000000003c64: bf9f0000
	s_code_end                                                 // 000000003c68: bf9f0000
	s_code_end                                                 // 000000003c6c: bf9f0000
	s_code_end                                                 // 000000003c70: bf9f0000
	s_code_end                                                 // 000000003c74: bf9f0000
	s_code_end                                                 // 000000003c78: bf9f0000
	s_code_end                                                 // 000000003c7c: bf9f0000
	s_code_end                                                 // 000000003c80: bf9f0000
	s_code_end                                                 // 000000003c84: bf9f0000
	s_code_end                                                 // 000000003c88: bf9f0000
	s_code_end                                                 // 000000003c8c: bf9f0000
	s_code_end                                                 // 000000003c90: bf9f0000
	s_code_end                                                 // 000000003c94: bf9f0000
	s_code_end                                                 // 000000003c98: bf9f0000
	s_code_end                                                 // 000000003c9c: bf9f0000
	s_code_end                                                 // 000000003ca0: bf9f0000
	s_code_end                                                 // 000000003ca4: bf9f0000
	s_code_end                                                 // 000000003ca8: bf9f0000
	s_code_end                                                 // 000000003cac: bf9f0000
	s_code_end                                                 // 000000003cb0: bf9f0000
	s_code_end                                                 // 000000003cb4: bf9f0000
	s_code_end                                                 // 000000003cb8: bf9f0000
	s_code_end                                                 // 000000003cbc: bf9f0000
	s_code_end                                                 // 000000003cc0: bf9f0000
	s_code_end                                                 // 000000003cc4: bf9f0000
	s_code_end                                                 // 000000003cc8: bf9f0000
	s_code_end                                                 // 000000003ccc: bf9f0000
	s_code_end                                                 // 000000003cd0: bf9f0000
	s_code_end                                                 // 000000003cd4: bf9f0000
	s_code_end                                                 // 000000003cd8: bf9f0000
	s_code_end                                                 // 000000003cdc: bf9f0000
	s_code_end                                                 // 000000003ce0: bf9f0000
	s_code_end                                                 // 000000003ce4: bf9f0000
	s_code_end                                                 // 000000003ce8: bf9f0000
	s_code_end                                                 // 000000003cec: bf9f0000
	s_code_end                                                 // 000000003cf0: bf9f0000
	s_code_end                                                 // 000000003cf4: bf9f0000
	s_code_end                                                 // 000000003cf8: bf9f0000
	s_code_end                                                 // 000000003cfc: bf9f0000
