; ModuleID = 'benchmarks/baselines/rocm_folded_bf16_lds_20261003/bf16-pressure/kernel.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"
target triple = "amdgcn-amd-amdhsa"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal unnamed_addr addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal unnamed_addr addrspace(3) global [5120 x i8] undef

; Function Attrs: norecurse nounwind
define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr nofree readnone captures(none) %0, ptr nofree readonly captures(none) %1, i64 %2, i64 %3, i64 %4, ptr nofree readnone captures(none) %5, ptr nofree readonly captures(none) %6, i64 %7, i64 %8, i64 %9, ptr nofree readnone captures(none) %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr nofree readnone captures(none) %15, ptr nofree readonly captures(none) %16, i64 %17, i64 %18, i64 %19, ptr nofree readnone captures(none) %20, ptr nofree writeonly %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) local_unnamed_addr #0 !reqd_work_group_size !1 {
.lr.ph:
  %28 = addrspacecast ptr %21 to ptr addrspace(1)
  %29 = addrspacecast ptr %16 to ptr addrspace(1)
  %30 = addrspacecast ptr %11 to ptr addrspace(1)
  %31 = addrspacecast ptr %6 to ptr addrspace(1)
  %32 = addrspacecast ptr %1 to ptr addrspace(1)
  %33 = tail call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %34 = zext nneg i32 %33 to i64
  %35 = and i64 %34, 15
  %36 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %37 = sext i32 %36 to i64
  %38 = add i64 %25, 255
  %39 = lshr i64 %38, 8
  %40 = add i64 %26, 63
  %41 = lshr i64 %40, 4
  %42 = and i64 %41, 1152921504606846972
  %.frozen = freeze i64 %42
  %43 = udiv i64 %37, %.frozen
  %44 = shl i64 %43, 2
  %45 = sub i64 %39, %44
  %46 = tail call i64 @llvm.umin.i64(i64 %45, i64 4)
  %47 = mul i64 %43, %.frozen
  %.decomposed = sub i64 %37, %47
  %.frozen59 = freeze i64 %46
  %48 = udiv i64 %.decomposed, %.frozen59
  %49 = mul i64 %48, %.frozen59
  %.decomposed60 = sub i64 %.decomposed, %49
  %50 = add nuw i64 %.decomposed60, %44
  %51 = shl i64 %50, 8
  %52 = shl i64 %48, 6
  %53 = and i64 %34, 192
  %54 = and i64 %34, 32
  %55 = or disjoint i64 %51, %53
  %56 = or disjoint i64 %53, 16
  %57 = or disjoint i64 %51, %56
  %58 = or disjoint i64 %53, 32
  %59 = or disjoint i64 %51, %58
  %60 = or disjoint i64 %53, 48
  %61 = or disjoint i64 %51, %60
  %62 = or disjoint i64 %52, %54
  %63 = or disjoint i64 %54, 16
  %64 = lshr i64 %34, 2
  %65 = shl nuw nsw i64 %34, 4
  %66 = and i64 %65, 48
  %67 = or disjoint i64 %51, %64
  %68 = mul i64 %67, %27
  %69 = mul nuw nsw i64 %64, 80
  %70 = add nuw nsw i64 %69, %66
  %71 = or disjoint i64 %64, 64
  %72 = or disjoint i64 %51, %71
  %73 = mul i64 %72, %27
  %74 = mul nuw nsw i64 %71, 80
  %75 = add nuw nsw i64 %74, %66
  %76 = or disjoint i64 %64, 128
  %77 = or disjoint i64 %51, %76
  %78 = mul i64 %77, %27
  %79 = mul nuw nsw i64 %76, 80
  %80 = add nuw nsw i64 %79, %66
  %81 = or disjoint i64 %64, 192
  %82 = or disjoint i64 %51, %81
  %83 = mul i64 %82, %27
  %84 = mul nuw nsw i64 %81, 80
  %85 = add nuw nsw i64 %84, %66
  %86 = or disjoint i64 %52, %64
  %87 = mul i64 %86, %27
  %88 = icmp ugt i64 %27, 63
  tail call void @llvm.assume(i1 %88)
  %89 = lshr i64 %27, 6
  %90 = add i64 %27, -64
  %91 = getelementptr i8, ptr addrspace(1) %32, i64 %68
  %92 = getelementptr i8, ptr addrspace(1) %91, i64 %66
  %93 = load <16 x i8>, ptr addrspace(1) %92, align 16
  %94 = getelementptr i8, ptr addrspace(1) %32, i64 %73
  %95 = getelementptr i8, ptr addrspace(1) %94, i64 %66
  %96 = load <16 x i8>, ptr addrspace(1) %95, align 16
  %97 = getelementptr i8, ptr addrspace(1) %32, i64 %78
  %98 = getelementptr i8, ptr addrspace(1) %97, i64 %66
  %99 = load <16 x i8>, ptr addrspace(1) %98, align 16
  %100 = getelementptr i8, ptr addrspace(1) %32, i64 %83
  %101 = getelementptr i8, ptr addrspace(1) %100, i64 %66
  %102 = load <16 x i8>, ptr addrspace(1) %101, align 16
  %103 = trunc nuw nsw i64 %70 to i32
  %104 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %103
  store <16 x i8> %93, ptr addrspace(3) %104, align 16
  %105 = trunc nuw nsw i64 %75 to i32
  %106 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %105
  store <16 x i8> %96, ptr addrspace(3) %106, align 16
  %107 = trunc nuw nsw i64 %80 to i32
  %108 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %107
  store <16 x i8> %99, ptr addrspace(3) %108, align 16
  %109 = trunc nuw nsw i64 %85 to i32
  %110 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %109
  store <16 x i8> %102, ptr addrspace(3) %110, align 16
  %111 = getelementptr i8, ptr addrspace(1) %31, i64 %87
  %112 = getelementptr i8, ptr addrspace(1) %111, i64 %66
  %113 = load <16 x i8>, ptr addrspace(1) %112, align 16
  %114 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %103
  store <16 x i8> %113, ptr addrspace(3) %114, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %115 = lshr i64 %34, 1
  %116 = and i64 %115, 8
  %117 = and i64 %34, 207
  %118 = mul nuw nsw i64 %117, 80
  %119 = or disjoint i64 %116, %118
  %120 = trunc nuw nsw i64 %119 to i32
  %121 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %120
  %122 = or disjoint i64 %56, %35
  %123 = mul nuw nsw i64 %122, 80
  %124 = or disjoint i64 %123, %116
  %125 = trunc nuw nsw i64 %124 to i32
  %126 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %125
  %127 = or disjoint i64 %58, %35
  %128 = mul nuw nsw i64 %127, 80
  %129 = or disjoint i64 %128, %116
  %130 = trunc nuw nsw i64 %129 to i32
  %131 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %130
  %132 = or disjoint i64 %60, %35
  %133 = mul nuw nsw i64 %132, 80
  %134 = or disjoint i64 %133, %116
  %135 = trunc nuw nsw i64 %134 to i32
  %136 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %135
  %137 = and i64 %34, 47
  %138 = mul nuw nsw i64 %137, 80
  %139 = or disjoint i64 %116, %138
  %140 = trunc nuw nsw i64 %139 to i32
  %141 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %140
  %142 = or disjoint i64 %63, %35
  %143 = mul nuw nsw i64 %142, 80
  %144 = or disjoint i64 %143, %116
  %145 = trunc nuw nsw i64 %144 to i32
  %146 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %145
  %147 = or disjoint i64 %116, 16
  %148 = add nuw nsw i64 %147, %118
  %149 = trunc nuw nsw i64 %148 to i32
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %149
  %151 = add nuw nsw i64 %123, %147
  %152 = trunc nuw nsw i64 %151 to i32
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %152
  %154 = add nuw nsw i64 %128, %147
  %155 = trunc nuw nsw i64 %154 to i32
  %156 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %155
  %157 = add nuw nsw i64 %133, %147
  %158 = trunc nuw nsw i64 %157 to i32
  %159 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %158
  %160 = add nuw nsw i64 %147, %138
  %161 = trunc nuw nsw i64 %160 to i32
  %162 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %161
  %163 = add nuw nsw i64 %143, %147
  %164 = trunc nuw nsw i64 %163 to i32
  %165 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %164
  %166 = or disjoint i64 %116, 32
  %167 = add nuw nsw i64 %166, %118
  %168 = trunc nuw nsw i64 %167 to i32
  %169 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %168
  %170 = add nuw nsw i64 %123, %166
  %171 = trunc nuw nsw i64 %170 to i32
  %172 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %171
  %173 = add nuw nsw i64 %128, %166
  %174 = trunc nuw nsw i64 %173 to i32
  %175 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %174
  %176 = add nuw nsw i64 %133, %166
  %177 = trunc nuw nsw i64 %176 to i32
  %178 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %177
  %179 = add nuw nsw i64 %166, %138
  %180 = trunc nuw nsw i64 %179 to i32
  %181 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %180
  %182 = add nuw nsw i64 %143, %166
  %183 = trunc nuw nsw i64 %182 to i32
  %184 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %183
  %185 = or disjoint i64 %116, 48
  %186 = add nuw nsw i64 %185, %118
  %187 = trunc nuw nsw i64 %186 to i32
  %188 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %187
  %189 = add nuw nsw i64 %123, %185
  %190 = trunc nuw nsw i64 %189 to i32
  %191 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %190
  %192 = add nuw nsw i64 %128, %185
  %193 = trunc nuw nsw i64 %192 to i32
  %194 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %193
  %195 = add nuw nsw i64 %133, %185
  %196 = trunc nuw nsw i64 %195 to i32
  %197 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %196
  %198 = add nuw nsw i64 %185, %138
  %199 = trunc nuw nsw i64 %198 to i32
  %200 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %199
  %201 = add nuw nsw i64 %143, %185
  %202 = trunc nuw nsw i64 %201 to i32
  %203 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %202
  br label %204

204:                                              ; preds = %.lr.ph, %204
  %205 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %282, %204 ]
  %206 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %281, %204 ]
  %207 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %280, %204 ]
  %208 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %279, %204 ]
  %209 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %278, %204 ]
  %210 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %277, %204 ]
  %211 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %276, %204 ]
  %212 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %275, %204 ]
  %213 = phi i64 [ 0, %.lr.ph ], [ %283, %204 ]
  %214 = shl i64 %213, 6
  %215 = add nuw i64 %214, 64
  %216 = tail call i64 @llvm.umin.i64(i64 %215, i64 %90)
  %217 = getelementptr i8, ptr addrspace(1) %92, i64 %216
  %218 = load <16 x i8>, ptr addrspace(1) %217, align 16
  %219 = getelementptr i8, ptr addrspace(1) %95, i64 %216
  %220 = load <16 x i8>, ptr addrspace(1) %219, align 16
  %221 = getelementptr i8, ptr addrspace(1) %98, i64 %216
  %222 = load <16 x i8>, ptr addrspace(1) %221, align 16
  %223 = getelementptr i8, ptr addrspace(1) %101, i64 %216
  %224 = load <16 x i8>, ptr addrspace(1) %223, align 16
  %225 = getelementptr i8, ptr addrspace(1) %112, i64 %216
  %226 = load <16 x i8>, ptr addrspace(1) %225, align 16
  %227 = load <2 x i32>, ptr addrspace(3) %121, align 8
  %228 = load <2 x i32>, ptr addrspace(3) %126, align 8
  %229 = load <2 x i32>, ptr addrspace(3) %131, align 8
  %230 = load <2 x i32>, ptr addrspace(3) %136, align 8
  %231 = load <2 x i32>, ptr addrspace(3) %141, align 8
  %232 = load <2 x i32>, ptr addrspace(3) %146, align 8
  %233 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %231, <8 x float> %212)
  %234 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %232, <8 x float> %211)
  %235 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %231, <8 x float> %210)
  %236 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %232, <8 x float> %209)
  %237 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %231, <8 x float> %208)
  %238 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %232, <8 x float> %207)
  %239 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %230, <2 x i32> %231, <8 x float> %206)
  %240 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %230, <2 x i32> %232, <8 x float> %205)
  %241 = load <2 x i32>, ptr addrspace(3) %150, align 8
  %242 = load <2 x i32>, ptr addrspace(3) %153, align 8
  %243 = load <2 x i32>, ptr addrspace(3) %156, align 8
  %244 = load <2 x i32>, ptr addrspace(3) %159, align 8
  %245 = load <2 x i32>, ptr addrspace(3) %162, align 8
  %246 = load <2 x i32>, ptr addrspace(3) %165, align 8
  %247 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %245, <8 x float> %233)
  %248 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %246, <8 x float> %234)
  %249 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %245, <8 x float> %235)
  %250 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %246, <8 x float> %236)
  %251 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %245, <8 x float> %237)
  %252 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %246, <8 x float> %238)
  %253 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %244, <2 x i32> %245, <8 x float> %239)
  %254 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %244, <2 x i32> %246, <8 x float> %240)
  %255 = load <2 x i32>, ptr addrspace(3) %169, align 8
  %256 = load <2 x i32>, ptr addrspace(3) %172, align 8
  %257 = load <2 x i32>, ptr addrspace(3) %175, align 8
  %258 = load <2 x i32>, ptr addrspace(3) %178, align 8
  %259 = load <2 x i32>, ptr addrspace(3) %181, align 8
  %260 = load <2 x i32>, ptr addrspace(3) %184, align 8
  %261 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %259, <8 x float> %247)
  %262 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %260, <8 x float> %248)
  %263 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %259, <8 x float> %249)
  %264 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %260, <8 x float> %250)
  %265 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %259, <8 x float> %251)
  %266 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %260, <8 x float> %252)
  %267 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %259, <8 x float> %253)
  %268 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %260, <8 x float> %254)
  %269 = load <2 x i32>, ptr addrspace(3) %188, align 8
  %270 = load <2 x i32>, ptr addrspace(3) %191, align 8
  %271 = load <2 x i32>, ptr addrspace(3) %194, align 8
  %272 = load <2 x i32>, ptr addrspace(3) %197, align 8
  %273 = load <2 x i32>, ptr addrspace(3) %200, align 8
  %274 = load <2 x i32>, ptr addrspace(3) %203, align 8
  %275 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %273, <8 x float> %261)
  %276 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %274, <8 x float> %262)
  %277 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %273, <8 x float> %263)
  %278 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %274, <8 x float> %264)
  %279 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %273, <8 x float> %265)
  %280 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %274, <8 x float> %266)
  %281 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %272, <2 x i32> %273, <8 x float> %267)
  %282 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %272, <2 x i32> %274, <8 x float> %268)
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  store <16 x i8> %218, ptr addrspace(3) %104, align 16
  store <16 x i8> %220, ptr addrspace(3) %106, align 16
  store <16 x i8> %222, ptr addrspace(3) %108, align 16
  store <16 x i8> %224, ptr addrspace(3) %110, align 16
  store <16 x i8> %226, ptr addrspace(3) %114, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %283 = add nuw nsw i64 %213, 1
  %exitcond.not = icmp eq i64 %283, %89
  br i1 %exitcond.not, label %._crit_edge, label %204

._crit_edge:                                      ; preds = %204
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %284 = or disjoint i64 %55, %116
  %285 = or disjoint i64 %62, %35
  %286 = or disjoint i64 %284, 7
  %287 = icmp ult i64 %285, %26
  %288 = icmp ult i64 %286, %25
  %289 = and i1 %287, %288
  %290 = ptrtoint ptr %11 to i64
  %291 = and i64 %290, 15
  %292 = icmp eq i64 %291, 0
  %293 = and i1 %292, %289
  br i1 %293, label %294, label %300

294:                                              ; preds = %._crit_edge
  %295 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %284
  %296 = load <4 x float>, ptr addrspace(1) %295, align 16
  %297 = getelementptr i8, ptr addrspace(1) %295, i64 16
  %298 = load <4 x float>, ptr addrspace(1) %297, align 16
  %299 = shufflevector <4 x float> %296, <4 x float> %298, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %347

300:                                              ; preds = %._crit_edge
  %301 = icmp slt i64 %284, %25
  %302 = select i1 %301, i64 %284, i64 0
  %303 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %302
  %304 = load float, ptr addrspace(1) %303, align 4, !amdgpu.noclobber !3
  %305 = insertelement <8 x float> poison, float %304, i64 0
  %306 = or disjoint i64 %284, 1
  %307 = icmp slt i64 %306, %25
  %308 = select i1 %307, i64 %306, i64 0
  %309 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %308
  %310 = load float, ptr addrspace(1) %309, align 4, !amdgpu.noclobber !3
  %311 = insertelement <8 x float> %305, float %310, i64 1
  %312 = or disjoint i64 %284, 2
  %313 = icmp slt i64 %312, %25
  %314 = select i1 %313, i64 %312, i64 0
  %315 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %314
  %316 = load float, ptr addrspace(1) %315, align 4, !amdgpu.noclobber !3
  %317 = insertelement <8 x float> %311, float %316, i64 2
  %318 = or disjoint i64 %284, 3
  %319 = icmp slt i64 %318, %25
  %320 = select i1 %319, i64 %318, i64 0
  %321 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %320
  %322 = load float, ptr addrspace(1) %321, align 4, !amdgpu.noclobber !3
  %323 = insertelement <8 x float> %317, float %322, i64 3
  %324 = or disjoint i64 %284, 4
  %325 = icmp slt i64 %324, %25
  %326 = select i1 %325, i64 %324, i64 0
  %327 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %326
  %328 = load float, ptr addrspace(1) %327, align 4, !amdgpu.noclobber !3
  %329 = insertelement <8 x float> %323, float %328, i64 4
  %330 = or disjoint i64 %284, 5
  %331 = icmp slt i64 %330, %25
  %332 = select i1 %331, i64 %330, i64 0
  %333 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %332
  %334 = load float, ptr addrspace(1) %333, align 4, !amdgpu.noclobber !3
  %335 = insertelement <8 x float> %329, float %334, i64 5
  %336 = or disjoint i64 %284, 6
  %337 = icmp slt i64 %336, %25
  %338 = select i1 %337, i64 %336, i64 0
  %339 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %338
  %340 = load float, ptr addrspace(1) %339, align 4, !amdgpu.noclobber !3
  %341 = insertelement <8 x float> %335, float %340, i64 6
  %342 = icmp slt i64 %286, %25
  %343 = select i1 %342, i64 %286, i64 0
  %344 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %343
  %345 = load float, ptr addrspace(1) %344, align 4, !amdgpu.noclobber !3
  %346 = insertelement <8 x float> %341, float %345, i64 7
  br label %347

347:                                              ; preds = %294, %300
  %348 = phi <8 x float> [ %346, %300 ], [ %299, %294 ]
  %349 = icmp slt i64 %285, %26
  %350 = select i1 %349, i64 %285, i64 0
  %351 = extractelement <8 x float> %348, i64 0
  %352 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %350
  %353 = load i8, ptr addrspace(1) %352, align 1
  %354 = zext i8 %353 to i32
  %355 = shl nuw nsw i32 %354, 23
  %356 = bitcast i32 %355 to float
  %357 = fmul float %351, %356
  %358 = extractelement <8 x float> %275, i64 0
  %359 = fmul float %358, %357
  %360 = tail call i1 @llvm.is.fpclass.f32(float %357, /* (sub norm) */ i32 408)
  br i1 %360, label %373, label %361, !prof !4

361:                                              ; preds = %347
  %362 = fpext float %358 to double
  %363 = fpext nnan float %356 to double
  %364 = fpext float %351 to double
  %365 = fmul double %362, %363
  %366 = fmul double %365, %364
  %367 = fptrunc double %366 to float
  %368 = fcmp oeq float %358, 0.000000e+00
  %369 = tail call float @llvm.fabs.f32(float %351)
  %370 = fcmp one float %369, +inf
  %371 = and i1 %368, %370
  %372 = select i1 %371, float 0.000000e+00, float %367
  br label %373

373:                                              ; preds = %361, %347
  %374 = phi float [ %372, %361 ], [ %359, %347 ]
  %375 = extractelement <8 x float> %348, i64 1
  %376 = fmul float %375, %356
  %377 = extractelement <8 x float> %275, i64 1
  %378 = fmul float %377, %376
  %379 = tail call i1 @llvm.is.fpclass.f32(float %376, /* (sub norm) */ i32 408)
  br i1 %379, label %392, label %380, !prof !4

380:                                              ; preds = %373
  %381 = fpext float %377 to double
  %382 = fpext nnan float %356 to double
  %383 = fpext float %375 to double
  %384 = fmul double %381, %382
  %385 = fmul double %384, %383
  %386 = fptrunc double %385 to float
  %387 = fcmp oeq float %377, 0.000000e+00
  %388 = tail call float @llvm.fabs.f32(float %375)
  %389 = fcmp one float %388, +inf
  %390 = and i1 %387, %389
  %391 = select i1 %390, float 0.000000e+00, float %386
  br label %392

392:                                              ; preds = %380, %373
  %393 = phi float [ %391, %380 ], [ %378, %373 ]
  %394 = extractelement <8 x float> %348, i64 2
  %395 = fmul float %394, %356
  %396 = extractelement <8 x float> %275, i64 2
  %397 = fmul float %396, %395
  %398 = tail call i1 @llvm.is.fpclass.f32(float %395, /* (sub norm) */ i32 408)
  br i1 %398, label %411, label %399, !prof !4

399:                                              ; preds = %392
  %400 = fpext float %396 to double
  %401 = fpext nnan float %356 to double
  %402 = fpext float %394 to double
  %403 = fmul double %400, %401
  %404 = fmul double %403, %402
  %405 = fptrunc double %404 to float
  %406 = fcmp oeq float %396, 0.000000e+00
  %407 = tail call float @llvm.fabs.f32(float %394)
  %408 = fcmp one float %407, +inf
  %409 = and i1 %406, %408
  %410 = select i1 %409, float 0.000000e+00, float %405
  br label %411

411:                                              ; preds = %399, %392
  %412 = phi float [ %410, %399 ], [ %397, %392 ]
  %413 = extractelement <8 x float> %348, i64 3
  %414 = fmul float %413, %356
  %415 = extractelement <8 x float> %275, i64 3
  %416 = fmul float %415, %414
  %417 = tail call i1 @llvm.is.fpclass.f32(float %414, /* (sub norm) */ i32 408)
  br i1 %417, label %430, label %418, !prof !4

418:                                              ; preds = %411
  %419 = fpext float %415 to double
  %420 = fpext nnan float %356 to double
  %421 = fpext float %413 to double
  %422 = fmul double %419, %420
  %423 = fmul double %422, %421
  %424 = fptrunc double %423 to float
  %425 = fcmp oeq float %415, 0.000000e+00
  %426 = tail call float @llvm.fabs.f32(float %413)
  %427 = fcmp one float %426, +inf
  %428 = and i1 %425, %427
  %429 = select i1 %428, float 0.000000e+00, float %424
  br label %430

430:                                              ; preds = %418, %411
  %431 = phi float [ %429, %418 ], [ %416, %411 ]
  %432 = extractelement <8 x float> %348, i64 4
  %433 = fmul float %432, %356
  %434 = extractelement <8 x float> %275, i64 4
  %435 = fmul float %434, %433
  %436 = tail call i1 @llvm.is.fpclass.f32(float %433, /* (sub norm) */ i32 408)
  br i1 %436, label %449, label %437, !prof !4

437:                                              ; preds = %430
  %438 = fpext float %434 to double
  %439 = fpext nnan float %356 to double
  %440 = fpext float %432 to double
  %441 = fmul double %438, %439
  %442 = fmul double %441, %440
  %443 = fptrunc double %442 to float
  %444 = fcmp oeq float %434, 0.000000e+00
  %445 = tail call float @llvm.fabs.f32(float %432)
  %446 = fcmp one float %445, +inf
  %447 = and i1 %444, %446
  %448 = select i1 %447, float 0.000000e+00, float %443
  br label %449

449:                                              ; preds = %437, %430
  %450 = phi float [ %448, %437 ], [ %435, %430 ]
  %451 = extractelement <8 x float> %348, i64 5
  %452 = fmul float %451, %356
  %453 = extractelement <8 x float> %275, i64 5
  %454 = fmul float %453, %452
  %455 = tail call i1 @llvm.is.fpclass.f32(float %452, /* (sub norm) */ i32 408)
  br i1 %455, label %468, label %456, !prof !4

456:                                              ; preds = %449
  %457 = fpext float %453 to double
  %458 = fpext nnan float %356 to double
  %459 = fpext float %451 to double
  %460 = fmul double %457, %458
  %461 = fmul double %460, %459
  %462 = fptrunc double %461 to float
  %463 = fcmp oeq float %453, 0.000000e+00
  %464 = tail call float @llvm.fabs.f32(float %451)
  %465 = fcmp one float %464, +inf
  %466 = and i1 %463, %465
  %467 = select i1 %466, float 0.000000e+00, float %462
  br label %468

468:                                              ; preds = %456, %449
  %469 = phi float [ %467, %456 ], [ %454, %449 ]
  %470 = extractelement <8 x float> %348, i64 6
  %471 = fmul float %470, %356
  %472 = extractelement <8 x float> %275, i64 6
  %473 = fmul float %472, %471
  %474 = tail call i1 @llvm.is.fpclass.f32(float %471, /* (sub norm) */ i32 408)
  br i1 %474, label %487, label %475, !prof !4

475:                                              ; preds = %468
  %476 = fpext float %472 to double
  %477 = fpext nnan float %356 to double
  %478 = fpext float %470 to double
  %479 = fmul double %476, %477
  %480 = fmul double %479, %478
  %481 = fptrunc double %480 to float
  %482 = fcmp oeq float %472, 0.000000e+00
  %483 = tail call float @llvm.fabs.f32(float %470)
  %484 = fcmp one float %483, +inf
  %485 = and i1 %482, %484
  %486 = select i1 %485, float 0.000000e+00, float %481
  br label %487

487:                                              ; preds = %475, %468
  %488 = phi float [ %486, %475 ], [ %473, %468 ]
  %489 = extractelement <8 x float> %348, i64 7
  %490 = fmul float %489, %356
  %491 = extractelement <8 x float> %275, i64 7
  %492 = fmul float %491, %490
  %493 = tail call i1 @llvm.is.fpclass.f32(float %490, /* (sub norm) */ i32 408)
  br i1 %493, label %506, label %494, !prof !4

494:                                              ; preds = %487
  %495 = fpext float %491 to double
  %496 = fpext nnan float %356 to double
  %497 = fpext float %489 to double
  %498 = fmul double %495, %496
  %499 = fmul double %498, %497
  %500 = fptrunc double %499 to float
  %501 = fcmp oeq float %491, 0.000000e+00
  %502 = tail call float @llvm.fabs.f32(float %489)
  %503 = fcmp one float %502, +inf
  %504 = and i1 %501, %503
  %505 = select i1 %504, float 0.000000e+00, float %500
  br label %506

506:                                              ; preds = %494, %487
  %507 = phi float [ %505, %494 ], [ %492, %487 ]
  %508 = lshr i64 %34, 1
  %509 = and i64 %508, 112
  %510 = or disjoint i64 %116, %509
  %511 = mul nuw nsw i64 %510, 40
  %512 = or disjoint i64 %511, %35
  %513 = fptrunc float %374 to bfloat
  %514 = trunc nuw nsw i64 %512 to i32
  %515 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %514
  store bfloat %513, ptr addrspace(3) %515, align 2
  %516 = or disjoint i64 %116, 1
  %517 = or disjoint i64 %516, %509
  %518 = mul nuw nsw i64 %517, 40
  %519 = add nuw nsw i64 %518, %35
  %520 = fptrunc float %393 to bfloat
  %521 = trunc nuw nsw i64 %519 to i32
  %522 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %521
  store bfloat %520, ptr addrspace(3) %522, align 2
  %523 = or disjoint i64 %116, 2
  %524 = or disjoint i64 %523, %509
  %525 = mul nuw nsw i64 %524, 40
  %526 = or disjoint i64 %525, %35
  %527 = fptrunc float %412 to bfloat
  %528 = trunc nuw nsw i64 %526 to i32
  %529 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %528
  store bfloat %527, ptr addrspace(3) %529, align 2
  %530 = or disjoint i64 %116, 3
  %531 = or disjoint i64 %530, %509
  %532 = mul nuw nsw i64 %531, 40
  %533 = add nuw nsw i64 %532, %35
  %534 = fptrunc float %431 to bfloat
  %535 = trunc nuw nsw i64 %533 to i32
  %536 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %535
  store bfloat %534, ptr addrspace(3) %536, align 2
  %537 = or disjoint i64 %116, 4
  %538 = or disjoint i64 %537, %509
  %539 = mul nuw nsw i64 %538, 40
  %540 = or disjoint i64 %539, %35
  %541 = fptrunc float %450 to bfloat
  %542 = trunc nuw nsw i64 %540 to i32
  %543 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %542
  store bfloat %541, ptr addrspace(3) %543, align 2
  %544 = or disjoint i64 %116, 5
  %545 = or disjoint i64 %544, %509
  %546 = mul nuw nsw i64 %545, 40
  %547 = add nuw nsw i64 %546, %35
  %548 = fptrunc float %469 to bfloat
  %549 = trunc nuw nsw i64 %547 to i32
  %550 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %549
  store bfloat %548, ptr addrspace(3) %550, align 2
  %551 = or disjoint i64 %116, 6
  %552 = or disjoint i64 %551, %509
  %553 = mul nuw nsw i64 %552, 40
  %554 = or disjoint i64 %553, %35
  %555 = fptrunc float %488 to bfloat
  %556 = trunc nuw nsw i64 %554 to i32
  %557 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %556
  store bfloat %555, ptr addrspace(3) %557, align 2
  %558 = or disjoint i64 %116, 7
  %559 = or disjoint i64 %558, %509
  %560 = mul nuw nsw i64 %559, 40
  %561 = add nuw nsw i64 %560, %35
  %562 = fptrunc float %507 to bfloat
  %563 = trunc nuw nsw i64 %561 to i32
  %564 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %563
  store bfloat %562, ptr addrspace(3) %564, align 2
  %565 = or disjoint i64 %63, %35
  %566 = or disjoint i64 %565, %52
  %567 = icmp ult i64 %566, %26
  %568 = and i1 %567, %288
  %569 = and i1 %292, %568
  br i1 %569, label %570, label %576

570:                                              ; preds = %506
  %571 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %284
  %572 = load <4 x float>, ptr addrspace(1) %571, align 16
  %573 = getelementptr i8, ptr addrspace(1) %571, i64 16
  %574 = load <4 x float>, ptr addrspace(1) %573, align 16
  %575 = shufflevector <4 x float> %572, <4 x float> %574, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %624

576:                                              ; preds = %506
  %577 = icmp slt i64 %284, %25
  %578 = select i1 %577, i64 %284, i64 0
  %579 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %578
  %580 = load float, ptr addrspace(1) %579, align 4, !amdgpu.noclobber !3
  %581 = insertelement <8 x float> poison, float %580, i64 0
  %582 = or disjoint i64 %55, %516
  %583 = icmp slt i64 %582, %25
  %584 = select i1 %583, i64 %582, i64 0
  %585 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %584
  %586 = load float, ptr addrspace(1) %585, align 4, !amdgpu.noclobber !3
  %587 = insertelement <8 x float> %581, float %586, i64 1
  %588 = or disjoint i64 %55, %523
  %589 = icmp slt i64 %588, %25
  %590 = select i1 %589, i64 %588, i64 0
  %591 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %590
  %592 = load float, ptr addrspace(1) %591, align 4, !amdgpu.noclobber !3
  %593 = insertelement <8 x float> %587, float %592, i64 2
  %594 = or disjoint i64 %55, %530
  %595 = icmp slt i64 %594, %25
  %596 = select i1 %595, i64 %594, i64 0
  %597 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %596
  %598 = load float, ptr addrspace(1) %597, align 4, !amdgpu.noclobber !3
  %599 = insertelement <8 x float> %593, float %598, i64 3
  %600 = or disjoint i64 %55, %537
  %601 = icmp slt i64 %600, %25
  %602 = select i1 %601, i64 %600, i64 0
  %603 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %602
  %604 = load float, ptr addrspace(1) %603, align 4, !amdgpu.noclobber !3
  %605 = insertelement <8 x float> %599, float %604, i64 4
  %606 = or disjoint i64 %55, %544
  %607 = icmp slt i64 %606, %25
  %608 = select i1 %607, i64 %606, i64 0
  %609 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %608
  %610 = load float, ptr addrspace(1) %609, align 4, !amdgpu.noclobber !3
  %611 = insertelement <8 x float> %605, float %610, i64 5
  %612 = or disjoint i64 %55, %551
  %613 = icmp slt i64 %612, %25
  %614 = select i1 %613, i64 %612, i64 0
  %615 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %614
  %616 = load float, ptr addrspace(1) %615, align 4, !amdgpu.noclobber !3
  %617 = insertelement <8 x float> %611, float %616, i64 6
  %618 = or disjoint i64 %55, %558
  %619 = icmp slt i64 %618, %25
  %620 = select i1 %619, i64 %618, i64 0
  %621 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %620
  %622 = load float, ptr addrspace(1) %621, align 4, !amdgpu.noclobber !3
  %623 = insertelement <8 x float> %617, float %622, i64 7
  br label %624

624:                                              ; preds = %570, %576
  %625 = phi <8 x float> [ %623, %576 ], [ %575, %570 ]
  %626 = icmp slt i64 %566, %26
  %627 = select i1 %626, i64 %566, i64 0
  %628 = extractelement <8 x float> %625, i64 0
  %629 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %627
  %630 = load i8, ptr addrspace(1) %629, align 1
  %631 = zext i8 %630 to i32
  %632 = shl nuw nsw i32 %631, 23
  %633 = bitcast i32 %632 to float
  %634 = fmul float %628, %633
  %635 = extractelement <8 x float> %276, i64 0
  %636 = fmul float %635, %634
  %637 = tail call i1 @llvm.is.fpclass.f32(float %634, /* (sub norm) */ i32 408)
  br i1 %637, label %650, label %638, !prof !4

638:                                              ; preds = %624
  %639 = fpext float %635 to double
  %640 = fpext nnan float %633 to double
  %641 = fpext float %628 to double
  %642 = fmul double %639, %640
  %643 = fmul double %642, %641
  %644 = fptrunc double %643 to float
  %645 = fcmp oeq float %635, 0.000000e+00
  %646 = tail call float @llvm.fabs.f32(float %628)
  %647 = fcmp one float %646, +inf
  %648 = and i1 %645, %647
  %649 = select i1 %648, float 0.000000e+00, float %644
  br label %650

650:                                              ; preds = %638, %624
  %651 = phi float [ %649, %638 ], [ %636, %624 ]
  %652 = extractelement <8 x float> %625, i64 1
  %653 = fmul float %652, %633
  %654 = extractelement <8 x float> %276, i64 1
  %655 = fmul float %654, %653
  %656 = tail call i1 @llvm.is.fpclass.f32(float %653, /* (sub norm) */ i32 408)
  br i1 %656, label %669, label %657, !prof !4

657:                                              ; preds = %650
  %658 = fpext float %654 to double
  %659 = fpext nnan float %633 to double
  %660 = fpext float %652 to double
  %661 = fmul double %658, %659
  %662 = fmul double %661, %660
  %663 = fptrunc double %662 to float
  %664 = fcmp oeq float %654, 0.000000e+00
  %665 = tail call float @llvm.fabs.f32(float %652)
  %666 = fcmp one float %665, +inf
  %667 = and i1 %664, %666
  %668 = select i1 %667, float 0.000000e+00, float %663
  br label %669

669:                                              ; preds = %657, %650
  %670 = phi float [ %668, %657 ], [ %655, %650 ]
  %671 = extractelement <8 x float> %625, i64 2
  %672 = fmul float %671, %633
  %673 = extractelement <8 x float> %276, i64 2
  %674 = fmul float %673, %672
  %675 = tail call i1 @llvm.is.fpclass.f32(float %672, /* (sub norm) */ i32 408)
  br i1 %675, label %688, label %676, !prof !4

676:                                              ; preds = %669
  %677 = fpext float %673 to double
  %678 = fpext nnan float %633 to double
  %679 = fpext float %671 to double
  %680 = fmul double %677, %678
  %681 = fmul double %680, %679
  %682 = fptrunc double %681 to float
  %683 = fcmp oeq float %673, 0.000000e+00
  %684 = tail call float @llvm.fabs.f32(float %671)
  %685 = fcmp one float %684, +inf
  %686 = and i1 %683, %685
  %687 = select i1 %686, float 0.000000e+00, float %682
  br label %688

688:                                              ; preds = %676, %669
  %689 = phi float [ %687, %676 ], [ %674, %669 ]
  %690 = extractelement <8 x float> %625, i64 3
  %691 = fmul float %690, %633
  %692 = extractelement <8 x float> %276, i64 3
  %693 = fmul float %692, %691
  %694 = tail call i1 @llvm.is.fpclass.f32(float %691, /* (sub norm) */ i32 408)
  br i1 %694, label %707, label %695, !prof !4

695:                                              ; preds = %688
  %696 = fpext float %692 to double
  %697 = fpext nnan float %633 to double
  %698 = fpext float %690 to double
  %699 = fmul double %696, %697
  %700 = fmul double %699, %698
  %701 = fptrunc double %700 to float
  %702 = fcmp oeq float %692, 0.000000e+00
  %703 = tail call float @llvm.fabs.f32(float %690)
  %704 = fcmp one float %703, +inf
  %705 = and i1 %702, %704
  %706 = select i1 %705, float 0.000000e+00, float %701
  br label %707

707:                                              ; preds = %695, %688
  %708 = phi float [ %706, %695 ], [ %693, %688 ]
  %709 = extractelement <8 x float> %625, i64 4
  %710 = fmul float %709, %633
  %711 = extractelement <8 x float> %276, i64 4
  %712 = fmul float %711, %710
  %713 = tail call i1 @llvm.is.fpclass.f32(float %710, /* (sub norm) */ i32 408)
  br i1 %713, label %726, label %714, !prof !4

714:                                              ; preds = %707
  %715 = fpext float %711 to double
  %716 = fpext nnan float %633 to double
  %717 = fpext float %709 to double
  %718 = fmul double %715, %716
  %719 = fmul double %718, %717
  %720 = fptrunc double %719 to float
  %721 = fcmp oeq float %711, 0.000000e+00
  %722 = tail call float @llvm.fabs.f32(float %709)
  %723 = fcmp one float %722, +inf
  %724 = and i1 %721, %723
  %725 = select i1 %724, float 0.000000e+00, float %720
  br label %726

726:                                              ; preds = %714, %707
  %727 = phi float [ %725, %714 ], [ %712, %707 ]
  %728 = extractelement <8 x float> %625, i64 5
  %729 = fmul float %728, %633
  %730 = extractelement <8 x float> %276, i64 5
  %731 = fmul float %730, %729
  %732 = tail call i1 @llvm.is.fpclass.f32(float %729, /* (sub norm) */ i32 408)
  br i1 %732, label %745, label %733, !prof !4

733:                                              ; preds = %726
  %734 = fpext float %730 to double
  %735 = fpext nnan float %633 to double
  %736 = fpext float %728 to double
  %737 = fmul double %734, %735
  %738 = fmul double %737, %736
  %739 = fptrunc double %738 to float
  %740 = fcmp oeq float %730, 0.000000e+00
  %741 = tail call float @llvm.fabs.f32(float %728)
  %742 = fcmp one float %741, +inf
  %743 = and i1 %740, %742
  %744 = select i1 %743, float 0.000000e+00, float %739
  br label %745

745:                                              ; preds = %733, %726
  %746 = phi float [ %744, %733 ], [ %731, %726 ]
  %747 = extractelement <8 x float> %625, i64 6
  %748 = fmul float %747, %633
  %749 = extractelement <8 x float> %276, i64 6
  %750 = fmul float %749, %748
  %751 = tail call i1 @llvm.is.fpclass.f32(float %748, /* (sub norm) */ i32 408)
  br i1 %751, label %764, label %752, !prof !4

752:                                              ; preds = %745
  %753 = fpext float %749 to double
  %754 = fpext nnan float %633 to double
  %755 = fpext float %747 to double
  %756 = fmul double %753, %754
  %757 = fmul double %756, %755
  %758 = fptrunc double %757 to float
  %759 = fcmp oeq float %749, 0.000000e+00
  %760 = tail call float @llvm.fabs.f32(float %747)
  %761 = fcmp one float %760, +inf
  %762 = and i1 %759, %761
  %763 = select i1 %762, float 0.000000e+00, float %758
  br label %764

764:                                              ; preds = %752, %745
  %765 = phi float [ %763, %752 ], [ %750, %745 ]
  %766 = extractelement <8 x float> %625, i64 7
  %767 = fmul float %766, %633
  %768 = extractelement <8 x float> %276, i64 7
  %769 = fmul float %768, %767
  %770 = tail call i1 @llvm.is.fpclass.f32(float %767, /* (sub norm) */ i32 408)
  br i1 %770, label %783, label %771, !prof !4

771:                                              ; preds = %764
  %772 = fpext float %768 to double
  %773 = fpext nnan float %633 to double
  %774 = fpext float %766 to double
  %775 = fmul double %772, %773
  %776 = fmul double %775, %774
  %777 = fptrunc double %776 to float
  %778 = fcmp oeq float %768, 0.000000e+00
  %779 = tail call float @llvm.fabs.f32(float %766)
  %780 = fcmp one float %779, +inf
  %781 = and i1 %778, %780
  %782 = select i1 %781, float 0.000000e+00, float %777
  br label %783

783:                                              ; preds = %771, %764
  %784 = phi float [ %782, %771 ], [ %769, %764 ]
  %785 = or disjoint i64 %35, 16
  %786 = or disjoint i64 %511, %785
  %787 = fptrunc float %651 to bfloat
  %788 = trunc nuw nsw i64 %786 to i32
  %789 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %788
  store bfloat %787, ptr addrspace(3) %789, align 2
  %790 = add nuw nsw i64 %518, %785
  %791 = fptrunc float %670 to bfloat
  %792 = trunc nuw nsw i64 %790 to i32
  %793 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %792
  store bfloat %791, ptr addrspace(3) %793, align 2
  %794 = add nuw nsw i64 %525, %785
  %795 = fptrunc float %689 to bfloat
  %796 = trunc nuw nsw i64 %794 to i32
  %797 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %796
  store bfloat %795, ptr addrspace(3) %797, align 2
  %798 = add nuw nsw i64 %532, %785
  %799 = fptrunc float %708 to bfloat
  %800 = trunc nuw nsw i64 %798 to i32
  %801 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %800
  store bfloat %799, ptr addrspace(3) %801, align 2
  %802 = or disjoint i64 %539, %785
  %803 = fptrunc float %727 to bfloat
  %804 = trunc nuw nsw i64 %802 to i32
  %805 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %804
  store bfloat %803, ptr addrspace(3) %805, align 2
  %806 = add nuw nsw i64 %546, %785
  %807 = fptrunc float %746 to bfloat
  %808 = trunc nuw nsw i64 %806 to i32
  %809 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %808
  store bfloat %807, ptr addrspace(3) %809, align 2
  %810 = add nuw nsw i64 %553, %785
  %811 = fptrunc float %765 to bfloat
  %812 = trunc nuw nsw i64 %810 to i32
  %813 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %812
  store bfloat %811, ptr addrspace(3) %813, align 2
  %814 = add nuw nsw i64 %560, %785
  %815 = fptrunc float %784 to bfloat
  %816 = trunc nuw nsw i64 %814 to i32
  %817 = getelementptr inbounds nuw [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %816
  store bfloat %815, ptr addrspace(3) %817, align 2
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %818 = shl nuw nsw i64 %34, 3
  %819 = lshr i64 %34, 2
  %820 = and i64 %819, 7
  %821 = and i64 %818, 24
  %822 = or disjoint i64 %509, %820
  %823 = or disjoint i64 %820, %53
  %824 = or disjoint i64 %823, %51
  %825 = or disjoint i64 %821, %54
  %826 = or disjoint i64 %825, %52
  %827 = mul nuw nsw i64 %822, 40
  %828 = add nuw nsw i64 %827, %821
  %829 = trunc nuw nsw i64 %828 to i32
  %830 = getelementptr [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %829
  %831 = load <8 x bfloat>, ptr addrspace(3) %830, align 16
  %832 = mul i64 %824, %26
  %833 = add i64 %832, %826
  %834 = icmp ult i64 %824, %25
  %835 = or disjoint i64 %826, 7
  %836 = icmp ult i64 %835, %26
  %837 = and i1 %834, %836
  br i1 %837, label %838, label %840

838:                                              ; preds = %783
  %839 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %833
  store <8 x bfloat> %831, ptr addrspace(1) %839, align 2
  br label %894

840:                                              ; preds = %783
  %841 = icmp ult i64 %826, %26
  %842 = and i1 %834, %841
  br i1 %842, label %843, label %846

843:                                              ; preds = %840
  %844 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %833
  %845 = extractelement <8 x bfloat> %831, i64 0
  store bfloat %845, ptr addrspace(1) %844, align 2
  br label %846

846:                                              ; preds = %843, %840
  %847 = or disjoint i64 %826, 1
  %848 = icmp ult i64 %847, %26
  %849 = and i1 %834, %848
  br i1 %849, label %850, label %854

850:                                              ; preds = %846
  %851 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %833
  %852 = getelementptr i8, ptr addrspace(1) %851, i64 2
  %853 = extractelement <8 x bfloat> %831, i64 1
  store bfloat %853, ptr addrspace(1) %852, align 2
  br label %854

854:                                              ; preds = %850, %846
  %855 = or disjoint i64 %826, 2
  %856 = icmp ult i64 %855, %26
  %857 = and i1 %834, %856
  br i1 %857, label %858, label %862

858:                                              ; preds = %854
  %859 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %833
  %860 = getelementptr i8, ptr addrspace(1) %859, i64 4
  %861 = extractelement <8 x bfloat> %831, i64 2
  store bfloat %861, ptr addrspace(1) %860, align 2
  br label %862

862:                                              ; preds = %858, %854
  %863 = or disjoint i64 %826, 3
  %864 = icmp ult i64 %863, %26
  %865 = and i1 %834, %864
  br i1 %865, label %866, label %870

866:                                              ; preds = %862
  %867 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %833
  %868 = getelementptr i8, ptr addrspace(1) %867, i64 6
  %869 = extractelement <8 x bfloat> %831, i64 3
  store bfloat %869, ptr addrspace(1) %868, align 2
  br label %870

870:                                              ; preds = %866, %862
  %871 = or disjoint i64 %826, 4
  %872 = icmp ult i64 %871, %26
  %873 = and i1 %834, %872
  br i1 %873, label %874, label %878

874:                                              ; preds = %870
  %875 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %833
  %876 = getelementptr i8, ptr addrspace(1) %875, i64 8
  %877 = extractelement <8 x bfloat> %831, i64 4
  store bfloat %877, ptr addrspace(1) %876, align 2
  br label %878

878:                                              ; preds = %874, %870
  %879 = or disjoint i64 %826, 5
  %880 = icmp ult i64 %879, %26
  %881 = and i1 %834, %880
  br i1 %881, label %882, label %886

882:                                              ; preds = %878
  %883 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %833
  %884 = getelementptr i8, ptr addrspace(1) %883, i64 10
  %885 = extractelement <8 x bfloat> %831, i64 5
  store bfloat %885, ptr addrspace(1) %884, align 2
  br label %886

886:                                              ; preds = %882, %878
  %887 = or disjoint i64 %826, 6
  %888 = icmp ult i64 %887, %26
  %889 = and i1 %834, %888
  br i1 %889, label %890, label %894

890:                                              ; preds = %886
  %891 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %833
  %892 = getelementptr i8, ptr addrspace(1) %891, i64 12
  %893 = extractelement <8 x bfloat> %831, i64 6
  store bfloat %893, ptr addrspace(1) %892, align 2
  br label %894

894:                                              ; preds = %886, %890, %838
  %895 = or disjoint i64 %820, 8
  %896 = or disjoint i64 %895, %509
  %897 = or disjoint i64 %895, %53
  %898 = or disjoint i64 %897, %51
  %899 = mul nuw nsw i64 %896, 40
  %900 = add nuw nsw i64 %899, %821
  %901 = trunc nuw nsw i64 %900 to i32
  %902 = getelementptr [2 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %901
  %903 = load <8 x bfloat>, ptr addrspace(3) %902, align 16
  %904 = mul i64 %898, %26
  %905 = add i64 %904, %826
  %906 = icmp ult i64 %898, %25
  %907 = and i1 %906, %836
  br i1 %907, label %908, label %910

908:                                              ; preds = %894
  %909 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %905
  store <8 x bfloat> %903, ptr addrspace(1) %909, align 2
  br label %964

910:                                              ; preds = %894
  %911 = icmp ult i64 %826, %26
  %912 = and i1 %906, %911
  br i1 %912, label %913, label %916

913:                                              ; preds = %910
  %914 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %905
  %915 = extractelement <8 x bfloat> %903, i64 0
  store bfloat %915, ptr addrspace(1) %914, align 2
  br label %916

916:                                              ; preds = %913, %910
  %917 = or disjoint i64 %826, 1
  %918 = icmp ult i64 %917, %26
  %919 = and i1 %906, %918
  br i1 %919, label %920, label %924

920:                                              ; preds = %916
  %921 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %905
  %922 = getelementptr i8, ptr addrspace(1) %921, i64 2
  %923 = extractelement <8 x bfloat> %903, i64 1
  store bfloat %923, ptr addrspace(1) %922, align 2
  br label %924

924:                                              ; preds = %920, %916
  %925 = or disjoint i64 %826, 2
  %926 = icmp ult i64 %925, %26
  %927 = and i1 %906, %926
  br i1 %927, label %928, label %932

928:                                              ; preds = %924
  %929 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %905
  %930 = getelementptr i8, ptr addrspace(1) %929, i64 4
  %931 = extractelement <8 x bfloat> %903, i64 2
  store bfloat %931, ptr addrspace(1) %930, align 2
  br label %932

932:                                              ; preds = %928, %924
  %933 = or disjoint i64 %826, 3
  %934 = icmp ult i64 %933, %26
  %935 = and i1 %906, %934
  br i1 %935, label %936, label %940

936:                                              ; preds = %932
  %937 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %905
  %938 = getelementptr i8, ptr addrspace(1) %937, i64 6
  %939 = extractelement <8 x bfloat> %903, i64 3
  store bfloat %939, ptr addrspace(1) %938, align 2
  br label %940

940:                                              ; preds = %936, %932
  %941 = or disjoint i64 %826, 4
  %942 = icmp ult i64 %941, %26
  %943 = and i1 %906, %942
  br i1 %943, label %944, label %948

944:                                              ; preds = %940
  %945 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %905
  %946 = getelementptr i8, ptr addrspace(1) %945, i64 8
  %947 = extractelement <8 x bfloat> %903, i64 4
  store bfloat %947, ptr addrspace(1) %946, align 2
  br label %948

948:                                              ; preds = %944, %940
  %949 = or disjoint i64 %826, 5
  %950 = icmp ult i64 %949, %26
  %951 = and i1 %906, %950
  br i1 %951, label %952, label %956

952:                                              ; preds = %948
  %953 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %905
  %954 = getelementptr i8, ptr addrspace(1) %953, i64 10
  %955 = extractelement <8 x bfloat> %903, i64 5
  store bfloat %955, ptr addrspace(1) %954, align 2
  br label %956

956:                                              ; preds = %952, %948
  %957 = or disjoint i64 %826, 6
  %958 = icmp ult i64 %957, %26
  %959 = and i1 %906, %958
  br i1 %959, label %960, label %964

960:                                              ; preds = %956
  %961 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %905
  %962 = getelementptr i8, ptr addrspace(1) %961, i64 12
  %963 = extractelement <8 x bfloat> %903, i64 6
  store bfloat %963, ptr addrspace(1) %962, align 2
  br label %964

964:                                              ; preds = %956, %960, %908
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %965 = or disjoint i64 %57, %116
  %966 = or disjoint i64 %965, 7
  %967 = icmp ult i64 %966, %25
  %968 = and i1 %287, %967
  %969 = and i1 %292, %968
  br i1 %969, label %970, label %976

970:                                              ; preds = %964
  %971 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %965
  %972 = load <4 x float>, ptr addrspace(1) %971, align 16
  %973 = getelementptr i8, ptr addrspace(1) %971, i64 16
  %974 = load <4 x float>, ptr addrspace(1) %973, align 16
  %975 = shufflevector <4 x float> %972, <4 x float> %974, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1024

976:                                              ; preds = %964
  %977 = icmp slt i64 %965, %25
  %978 = select i1 %977, i64 %965, i64 0
  %979 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %978
  %980 = load float, ptr addrspace(1) %979, align 4
  %981 = insertelement <8 x float> poison, float %980, i64 0
  %982 = or disjoint i64 %57, %516
  %983 = icmp slt i64 %982, %25
  %984 = select i1 %983, i64 %982, i64 0
  %985 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %984
  %986 = load float, ptr addrspace(1) %985, align 4
  %987 = insertelement <8 x float> %981, float %986, i64 1
  %988 = or disjoint i64 %57, %523
  %989 = icmp slt i64 %988, %25
  %990 = select i1 %989, i64 %988, i64 0
  %991 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %990
  %992 = load float, ptr addrspace(1) %991, align 4
  %993 = insertelement <8 x float> %987, float %992, i64 2
  %994 = or disjoint i64 %57, %530
  %995 = icmp slt i64 %994, %25
  %996 = select i1 %995, i64 %994, i64 0
  %997 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %996
  %998 = load float, ptr addrspace(1) %997, align 4
  %999 = insertelement <8 x float> %993, float %998, i64 3
  %1000 = or disjoint i64 %57, %537
  %1001 = icmp slt i64 %1000, %25
  %1002 = select i1 %1001, i64 %1000, i64 0
  %1003 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1002
  %1004 = load float, ptr addrspace(1) %1003, align 4
  %1005 = insertelement <8 x float> %999, float %1004, i64 4
  %1006 = or disjoint i64 %57, %544
  %1007 = icmp slt i64 %1006, %25
  %1008 = select i1 %1007, i64 %1006, i64 0
  %1009 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1008
  %1010 = load float, ptr addrspace(1) %1009, align 4
  %1011 = insertelement <8 x float> %1005, float %1010, i64 5
  %1012 = or disjoint i64 %57, %551
  %1013 = icmp slt i64 %1012, %25
  %1014 = select i1 %1013, i64 %1012, i64 0
  %1015 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1014
  %1016 = load float, ptr addrspace(1) %1015, align 4
  %1017 = insertelement <8 x float> %1011, float %1016, i64 6
  %1018 = or disjoint i64 %57, %558
  %1019 = icmp slt i64 %1018, %25
  %1020 = select i1 %1019, i64 %1018, i64 0
  %1021 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1020
  %1022 = load float, ptr addrspace(1) %1021, align 4
  %1023 = insertelement <8 x float> %1017, float %1022, i64 7
  br label %1024

1024:                                             ; preds = %970, %976
  %1025 = phi <8 x float> [ %1023, %976 ], [ %975, %970 ]
  %1026 = extractelement <8 x float> %1025, i64 0
  %1027 = load i8, ptr addrspace(1) %352, align 1
  %1028 = zext i8 %1027 to i32
  %1029 = shl nuw nsw i32 %1028, 23
  %1030 = bitcast i32 %1029 to float
  %1031 = fmul float %1026, %1030
  %1032 = extractelement <8 x float> %277, i64 0
  %1033 = fmul float %1032, %1031
  %1034 = tail call i1 @llvm.is.fpclass.f32(float %1031, /* (sub norm) */ i32 408)
  br i1 %1034, label %1047, label %1035, !prof !4

1035:                                             ; preds = %1024
  %1036 = fpext float %1032 to double
  %1037 = fpext nnan float %1030 to double
  %1038 = fpext float %1026 to double
  %1039 = fmul double %1036, %1037
  %1040 = fmul double %1039, %1038
  %1041 = fptrunc double %1040 to float
  %1042 = fcmp oeq float %1032, 0.000000e+00
  %1043 = tail call float @llvm.fabs.f32(float %1026)
  %1044 = fcmp one float %1043, +inf
  %1045 = and i1 %1042, %1044
  %1046 = select i1 %1045, float 0.000000e+00, float %1041
  br label %1047

1047:                                             ; preds = %1035, %1024
  %1048 = phi float [ %1046, %1035 ], [ %1033, %1024 ]
  %1049 = extractelement <8 x float> %1025, i64 1
  %1050 = fmul float %1049, %1030
  %1051 = extractelement <8 x float> %277, i64 1
  %1052 = fmul float %1051, %1050
  %1053 = tail call i1 @llvm.is.fpclass.f32(float %1050, /* (sub norm) */ i32 408)
  br i1 %1053, label %1066, label %1054, !prof !4

1054:                                             ; preds = %1047
  %1055 = fpext float %1051 to double
  %1056 = fpext nnan float %1030 to double
  %1057 = fpext float %1049 to double
  %1058 = fmul double %1055, %1056
  %1059 = fmul double %1058, %1057
  %1060 = fptrunc double %1059 to float
  %1061 = fcmp oeq float %1051, 0.000000e+00
  %1062 = tail call float @llvm.fabs.f32(float %1049)
  %1063 = fcmp one float %1062, +inf
  %1064 = and i1 %1061, %1063
  %1065 = select i1 %1064, float 0.000000e+00, float %1060
  br label %1066

1066:                                             ; preds = %1054, %1047
  %1067 = phi float [ %1065, %1054 ], [ %1052, %1047 ]
  %1068 = extractelement <8 x float> %1025, i64 2
  %1069 = fmul float %1068, %1030
  %1070 = extractelement <8 x float> %277, i64 2
  %1071 = fmul float %1070, %1069
  %1072 = tail call i1 @llvm.is.fpclass.f32(float %1069, /* (sub norm) */ i32 408)
  br i1 %1072, label %1085, label %1073, !prof !4

1073:                                             ; preds = %1066
  %1074 = fpext float %1070 to double
  %1075 = fpext nnan float %1030 to double
  %1076 = fpext float %1068 to double
  %1077 = fmul double %1074, %1075
  %1078 = fmul double %1077, %1076
  %1079 = fptrunc double %1078 to float
  %1080 = fcmp oeq float %1070, 0.000000e+00
  %1081 = tail call float @llvm.fabs.f32(float %1068)
  %1082 = fcmp one float %1081, +inf
  %1083 = and i1 %1080, %1082
  %1084 = select i1 %1083, float 0.000000e+00, float %1079
  br label %1085

1085:                                             ; preds = %1073, %1066
  %1086 = phi float [ %1084, %1073 ], [ %1071, %1066 ]
  %1087 = extractelement <8 x float> %1025, i64 3
  %1088 = fmul float %1087, %1030
  %1089 = extractelement <8 x float> %277, i64 3
  %1090 = fmul float %1089, %1088
  %1091 = tail call i1 @llvm.is.fpclass.f32(float %1088, /* (sub norm) */ i32 408)
  br i1 %1091, label %1104, label %1092, !prof !4

1092:                                             ; preds = %1085
  %1093 = fpext float %1089 to double
  %1094 = fpext nnan float %1030 to double
  %1095 = fpext float %1087 to double
  %1096 = fmul double %1093, %1094
  %1097 = fmul double %1096, %1095
  %1098 = fptrunc double %1097 to float
  %1099 = fcmp oeq float %1089, 0.000000e+00
  %1100 = tail call float @llvm.fabs.f32(float %1087)
  %1101 = fcmp one float %1100, +inf
  %1102 = and i1 %1099, %1101
  %1103 = select i1 %1102, float 0.000000e+00, float %1098
  br label %1104

1104:                                             ; preds = %1092, %1085
  %1105 = phi float [ %1103, %1092 ], [ %1090, %1085 ]
  %1106 = extractelement <8 x float> %1025, i64 4
  %1107 = fmul float %1106, %1030
  %1108 = extractelement <8 x float> %277, i64 4
  %1109 = fmul float %1108, %1107
  %1110 = tail call i1 @llvm.is.fpclass.f32(float %1107, /* (sub norm) */ i32 408)
  br i1 %1110, label %1123, label %1111, !prof !4

1111:                                             ; preds = %1104
  %1112 = fpext float %1108 to double
  %1113 = fpext nnan float %1030 to double
  %1114 = fpext float %1106 to double
  %1115 = fmul double %1112, %1113
  %1116 = fmul double %1115, %1114
  %1117 = fptrunc double %1116 to float
  %1118 = fcmp oeq float %1108, 0.000000e+00
  %1119 = tail call float @llvm.fabs.f32(float %1106)
  %1120 = fcmp one float %1119, +inf
  %1121 = and i1 %1118, %1120
  %1122 = select i1 %1121, float 0.000000e+00, float %1117
  br label %1123

1123:                                             ; preds = %1111, %1104
  %1124 = phi float [ %1122, %1111 ], [ %1109, %1104 ]
  %1125 = extractelement <8 x float> %1025, i64 5
  %1126 = fmul float %1125, %1030
  %1127 = extractelement <8 x float> %277, i64 5
  %1128 = fmul float %1127, %1126
  %1129 = tail call i1 @llvm.is.fpclass.f32(float %1126, /* (sub norm) */ i32 408)
  br i1 %1129, label %1142, label %1130, !prof !4

1130:                                             ; preds = %1123
  %1131 = fpext float %1127 to double
  %1132 = fpext nnan float %1030 to double
  %1133 = fpext float %1125 to double
  %1134 = fmul double %1131, %1132
  %1135 = fmul double %1134, %1133
  %1136 = fptrunc double %1135 to float
  %1137 = fcmp oeq float %1127, 0.000000e+00
  %1138 = tail call float @llvm.fabs.f32(float %1125)
  %1139 = fcmp one float %1138, +inf
  %1140 = and i1 %1137, %1139
  %1141 = select i1 %1140, float 0.000000e+00, float %1136
  br label %1142

1142:                                             ; preds = %1130, %1123
  %1143 = phi float [ %1141, %1130 ], [ %1128, %1123 ]
  %1144 = extractelement <8 x float> %1025, i64 6
  %1145 = fmul float %1144, %1030
  %1146 = extractelement <8 x float> %277, i64 6
  %1147 = fmul float %1146, %1145
  %1148 = tail call i1 @llvm.is.fpclass.f32(float %1145, /* (sub norm) */ i32 408)
  br i1 %1148, label %1161, label %1149, !prof !4

1149:                                             ; preds = %1142
  %1150 = fpext float %1146 to double
  %1151 = fpext nnan float %1030 to double
  %1152 = fpext float %1144 to double
  %1153 = fmul double %1150, %1151
  %1154 = fmul double %1153, %1152
  %1155 = fptrunc double %1154 to float
  %1156 = fcmp oeq float %1146, 0.000000e+00
  %1157 = tail call float @llvm.fabs.f32(float %1144)
  %1158 = fcmp one float %1157, +inf
  %1159 = and i1 %1156, %1158
  %1160 = select i1 %1159, float 0.000000e+00, float %1155
  br label %1161

1161:                                             ; preds = %1149, %1142
  %1162 = phi float [ %1160, %1149 ], [ %1147, %1142 ]
  %1163 = extractelement <8 x float> %1025, i64 7
  %1164 = fmul float %1163, %1030
  %1165 = extractelement <8 x float> %277, i64 7
  %1166 = fmul float %1165, %1164
  %1167 = tail call i1 @llvm.is.fpclass.f32(float %1164, /* (sub norm) */ i32 408)
  br i1 %1167, label %1180, label %1168, !prof !4

1168:                                             ; preds = %1161
  %1169 = fpext float %1165 to double
  %1170 = fpext nnan float %1030 to double
  %1171 = fpext float %1163 to double
  %1172 = fmul double %1169, %1170
  %1173 = fmul double %1172, %1171
  %1174 = fptrunc double %1173 to float
  %1175 = fcmp oeq float %1165, 0.000000e+00
  %1176 = tail call float @llvm.fabs.f32(float %1163)
  %1177 = fcmp one float %1176, +inf
  %1178 = and i1 %1175, %1177
  %1179 = select i1 %1178, float 0.000000e+00, float %1174
  br label %1180

1180:                                             ; preds = %1168, %1161
  %1181 = phi float [ %1179, %1168 ], [ %1166, %1161 ]
  %1182 = fptrunc float %1048 to bfloat
  store bfloat %1182, ptr addrspace(3) %515, align 2
  %1183 = fptrunc float %1067 to bfloat
  store bfloat %1183, ptr addrspace(3) %522, align 2
  %1184 = fptrunc float %1086 to bfloat
  store bfloat %1184, ptr addrspace(3) %529, align 2
  %1185 = fptrunc float %1105 to bfloat
  store bfloat %1185, ptr addrspace(3) %536, align 2
  %1186 = fptrunc float %1124 to bfloat
  store bfloat %1186, ptr addrspace(3) %543, align 2
  %1187 = fptrunc float %1143 to bfloat
  store bfloat %1187, ptr addrspace(3) %550, align 2
  %1188 = fptrunc float %1162 to bfloat
  store bfloat %1188, ptr addrspace(3) %557, align 2
  %1189 = fptrunc float %1181 to bfloat
  store bfloat %1189, ptr addrspace(3) %564, align 2
  %1190 = and i1 %567, %967
  %1191 = and i1 %292, %1190
  br i1 %1191, label %1192, label %1198

1192:                                             ; preds = %1180
  %1193 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %965
  %1194 = load <4 x float>, ptr addrspace(1) %1193, align 16
  %1195 = getelementptr i8, ptr addrspace(1) %1193, i64 16
  %1196 = load <4 x float>, ptr addrspace(1) %1195, align 16
  %1197 = shufflevector <4 x float> %1194, <4 x float> %1196, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1246

1198:                                             ; preds = %1180
  %1199 = icmp slt i64 %965, %25
  %1200 = select i1 %1199, i64 %965, i64 0
  %1201 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1200
  %1202 = load float, ptr addrspace(1) %1201, align 4
  %1203 = insertelement <8 x float> poison, float %1202, i64 0
  %1204 = or disjoint i64 %57, %516
  %1205 = icmp slt i64 %1204, %25
  %1206 = select i1 %1205, i64 %1204, i64 0
  %1207 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1206
  %1208 = load float, ptr addrspace(1) %1207, align 4
  %1209 = insertelement <8 x float> %1203, float %1208, i64 1
  %1210 = or disjoint i64 %57, %523
  %1211 = icmp slt i64 %1210, %25
  %1212 = select i1 %1211, i64 %1210, i64 0
  %1213 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1212
  %1214 = load float, ptr addrspace(1) %1213, align 4
  %1215 = insertelement <8 x float> %1209, float %1214, i64 2
  %1216 = or disjoint i64 %57, %530
  %1217 = icmp slt i64 %1216, %25
  %1218 = select i1 %1217, i64 %1216, i64 0
  %1219 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1218
  %1220 = load float, ptr addrspace(1) %1219, align 4
  %1221 = insertelement <8 x float> %1215, float %1220, i64 3
  %1222 = or disjoint i64 %57, %537
  %1223 = icmp slt i64 %1222, %25
  %1224 = select i1 %1223, i64 %1222, i64 0
  %1225 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1224
  %1226 = load float, ptr addrspace(1) %1225, align 4
  %1227 = insertelement <8 x float> %1221, float %1226, i64 4
  %1228 = or disjoint i64 %57, %544
  %1229 = icmp slt i64 %1228, %25
  %1230 = select i1 %1229, i64 %1228, i64 0
  %1231 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1230
  %1232 = load float, ptr addrspace(1) %1231, align 4
  %1233 = insertelement <8 x float> %1227, float %1232, i64 5
  %1234 = or disjoint i64 %57, %551
  %1235 = icmp slt i64 %1234, %25
  %1236 = select i1 %1235, i64 %1234, i64 0
  %1237 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1236
  %1238 = load float, ptr addrspace(1) %1237, align 4
  %1239 = insertelement <8 x float> %1233, float %1238, i64 6
  %1240 = or disjoint i64 %57, %558
  %1241 = icmp slt i64 %1240, %25
  %1242 = select i1 %1241, i64 %1240, i64 0
  %1243 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1242
  %1244 = load float, ptr addrspace(1) %1243, align 4
  %1245 = insertelement <8 x float> %1239, float %1244, i64 7
  br label %1246

1246:                                             ; preds = %1192, %1198
  %1247 = phi <8 x float> [ %1245, %1198 ], [ %1197, %1192 ]
  %1248 = extractelement <8 x float> %1247, i64 0
  %1249 = load i8, ptr addrspace(1) %629, align 1
  %1250 = zext i8 %1249 to i32
  %1251 = shl nuw nsw i32 %1250, 23
  %1252 = bitcast i32 %1251 to float
  %1253 = fmul float %1248, %1252
  %1254 = extractelement <8 x float> %278, i64 0
  %1255 = fmul float %1254, %1253
  %1256 = tail call i1 @llvm.is.fpclass.f32(float %1253, /* (sub norm) */ i32 408)
  br i1 %1256, label %1269, label %1257, !prof !4

1257:                                             ; preds = %1246
  %1258 = fpext float %1254 to double
  %1259 = fpext nnan float %1252 to double
  %1260 = fpext float %1248 to double
  %1261 = fmul double %1258, %1259
  %1262 = fmul double %1261, %1260
  %1263 = fptrunc double %1262 to float
  %1264 = fcmp oeq float %1254, 0.000000e+00
  %1265 = tail call float @llvm.fabs.f32(float %1248)
  %1266 = fcmp one float %1265, +inf
  %1267 = and i1 %1264, %1266
  %1268 = select i1 %1267, float 0.000000e+00, float %1263
  br label %1269

1269:                                             ; preds = %1257, %1246
  %1270 = phi float [ %1268, %1257 ], [ %1255, %1246 ]
  %1271 = extractelement <8 x float> %1247, i64 1
  %1272 = fmul float %1271, %1252
  %1273 = extractelement <8 x float> %278, i64 1
  %1274 = fmul float %1273, %1272
  %1275 = tail call i1 @llvm.is.fpclass.f32(float %1272, /* (sub norm) */ i32 408)
  br i1 %1275, label %1288, label %1276, !prof !4

1276:                                             ; preds = %1269
  %1277 = fpext float %1273 to double
  %1278 = fpext nnan float %1252 to double
  %1279 = fpext float %1271 to double
  %1280 = fmul double %1277, %1278
  %1281 = fmul double %1280, %1279
  %1282 = fptrunc double %1281 to float
  %1283 = fcmp oeq float %1273, 0.000000e+00
  %1284 = tail call float @llvm.fabs.f32(float %1271)
  %1285 = fcmp one float %1284, +inf
  %1286 = and i1 %1283, %1285
  %1287 = select i1 %1286, float 0.000000e+00, float %1282
  br label %1288

1288:                                             ; preds = %1276, %1269
  %1289 = phi float [ %1287, %1276 ], [ %1274, %1269 ]
  %1290 = extractelement <8 x float> %1247, i64 2
  %1291 = fmul float %1290, %1252
  %1292 = extractelement <8 x float> %278, i64 2
  %1293 = fmul float %1292, %1291
  %1294 = tail call i1 @llvm.is.fpclass.f32(float %1291, /* (sub norm) */ i32 408)
  br i1 %1294, label %1307, label %1295, !prof !4

1295:                                             ; preds = %1288
  %1296 = fpext float %1292 to double
  %1297 = fpext nnan float %1252 to double
  %1298 = fpext float %1290 to double
  %1299 = fmul double %1296, %1297
  %1300 = fmul double %1299, %1298
  %1301 = fptrunc double %1300 to float
  %1302 = fcmp oeq float %1292, 0.000000e+00
  %1303 = tail call float @llvm.fabs.f32(float %1290)
  %1304 = fcmp one float %1303, +inf
  %1305 = and i1 %1302, %1304
  %1306 = select i1 %1305, float 0.000000e+00, float %1301
  br label %1307

1307:                                             ; preds = %1295, %1288
  %1308 = phi float [ %1306, %1295 ], [ %1293, %1288 ]
  %1309 = extractelement <8 x float> %1247, i64 3
  %1310 = fmul float %1309, %1252
  %1311 = extractelement <8 x float> %278, i64 3
  %1312 = fmul float %1311, %1310
  %1313 = tail call i1 @llvm.is.fpclass.f32(float %1310, /* (sub norm) */ i32 408)
  br i1 %1313, label %1326, label %1314, !prof !4

1314:                                             ; preds = %1307
  %1315 = fpext float %1311 to double
  %1316 = fpext nnan float %1252 to double
  %1317 = fpext float %1309 to double
  %1318 = fmul double %1315, %1316
  %1319 = fmul double %1318, %1317
  %1320 = fptrunc double %1319 to float
  %1321 = fcmp oeq float %1311, 0.000000e+00
  %1322 = tail call float @llvm.fabs.f32(float %1309)
  %1323 = fcmp one float %1322, +inf
  %1324 = and i1 %1321, %1323
  %1325 = select i1 %1324, float 0.000000e+00, float %1320
  br label %1326

1326:                                             ; preds = %1314, %1307
  %1327 = phi float [ %1325, %1314 ], [ %1312, %1307 ]
  %1328 = extractelement <8 x float> %1247, i64 4
  %1329 = fmul float %1328, %1252
  %1330 = extractelement <8 x float> %278, i64 4
  %1331 = fmul float %1330, %1329
  %1332 = tail call i1 @llvm.is.fpclass.f32(float %1329, /* (sub norm) */ i32 408)
  br i1 %1332, label %1345, label %1333, !prof !4

1333:                                             ; preds = %1326
  %1334 = fpext float %1330 to double
  %1335 = fpext nnan float %1252 to double
  %1336 = fpext float %1328 to double
  %1337 = fmul double %1334, %1335
  %1338 = fmul double %1337, %1336
  %1339 = fptrunc double %1338 to float
  %1340 = fcmp oeq float %1330, 0.000000e+00
  %1341 = tail call float @llvm.fabs.f32(float %1328)
  %1342 = fcmp one float %1341, +inf
  %1343 = and i1 %1340, %1342
  %1344 = select i1 %1343, float 0.000000e+00, float %1339
  br label %1345

1345:                                             ; preds = %1333, %1326
  %1346 = phi float [ %1344, %1333 ], [ %1331, %1326 ]
  %1347 = extractelement <8 x float> %1247, i64 5
  %1348 = fmul float %1347, %1252
  %1349 = extractelement <8 x float> %278, i64 5
  %1350 = fmul float %1349, %1348
  %1351 = tail call i1 @llvm.is.fpclass.f32(float %1348, /* (sub norm) */ i32 408)
  br i1 %1351, label %1364, label %1352, !prof !4

1352:                                             ; preds = %1345
  %1353 = fpext float %1349 to double
  %1354 = fpext nnan float %1252 to double
  %1355 = fpext float %1347 to double
  %1356 = fmul double %1353, %1354
  %1357 = fmul double %1356, %1355
  %1358 = fptrunc double %1357 to float
  %1359 = fcmp oeq float %1349, 0.000000e+00
  %1360 = tail call float @llvm.fabs.f32(float %1347)
  %1361 = fcmp one float %1360, +inf
  %1362 = and i1 %1359, %1361
  %1363 = select i1 %1362, float 0.000000e+00, float %1358
  br label %1364

1364:                                             ; preds = %1352, %1345
  %1365 = phi float [ %1363, %1352 ], [ %1350, %1345 ]
  %1366 = extractelement <8 x float> %1247, i64 6
  %1367 = fmul float %1366, %1252
  %1368 = extractelement <8 x float> %278, i64 6
  %1369 = fmul float %1368, %1367
  %1370 = tail call i1 @llvm.is.fpclass.f32(float %1367, /* (sub norm) */ i32 408)
  br i1 %1370, label %1383, label %1371, !prof !4

1371:                                             ; preds = %1364
  %1372 = fpext float %1368 to double
  %1373 = fpext nnan float %1252 to double
  %1374 = fpext float %1366 to double
  %1375 = fmul double %1372, %1373
  %1376 = fmul double %1375, %1374
  %1377 = fptrunc double %1376 to float
  %1378 = fcmp oeq float %1368, 0.000000e+00
  %1379 = tail call float @llvm.fabs.f32(float %1366)
  %1380 = fcmp one float %1379, +inf
  %1381 = and i1 %1378, %1380
  %1382 = select i1 %1381, float 0.000000e+00, float %1377
  br label %1383

1383:                                             ; preds = %1371, %1364
  %1384 = phi float [ %1382, %1371 ], [ %1369, %1364 ]
  %1385 = extractelement <8 x float> %1247, i64 7
  %1386 = fmul float %1385, %1252
  %1387 = extractelement <8 x float> %278, i64 7
  %1388 = fmul float %1387, %1386
  %1389 = tail call i1 @llvm.is.fpclass.f32(float %1386, /* (sub norm) */ i32 408)
  br i1 %1389, label %1402, label %1390, !prof !4

1390:                                             ; preds = %1383
  %1391 = fpext float %1387 to double
  %1392 = fpext nnan float %1252 to double
  %1393 = fpext float %1385 to double
  %1394 = fmul double %1391, %1392
  %1395 = fmul double %1394, %1393
  %1396 = fptrunc double %1395 to float
  %1397 = fcmp oeq float %1387, 0.000000e+00
  %1398 = tail call float @llvm.fabs.f32(float %1385)
  %1399 = fcmp one float %1398, +inf
  %1400 = and i1 %1397, %1399
  %1401 = select i1 %1400, float 0.000000e+00, float %1396
  br label %1402

1402:                                             ; preds = %1390, %1383
  %1403 = phi float [ %1401, %1390 ], [ %1388, %1383 ]
  %1404 = fptrunc float %1270 to bfloat
  store bfloat %1404, ptr addrspace(3) %789, align 2
  %1405 = fptrunc float %1289 to bfloat
  store bfloat %1405, ptr addrspace(3) %793, align 2
  %1406 = fptrunc float %1308 to bfloat
  store bfloat %1406, ptr addrspace(3) %797, align 2
  %1407 = fptrunc float %1327 to bfloat
  store bfloat %1407, ptr addrspace(3) %801, align 2
  %1408 = fptrunc float %1346 to bfloat
  store bfloat %1408, ptr addrspace(3) %805, align 2
  %1409 = fptrunc float %1365 to bfloat
  store bfloat %1409, ptr addrspace(3) %809, align 2
  %1410 = fptrunc float %1384 to bfloat
  store bfloat %1410, ptr addrspace(3) %813, align 2
  %1411 = fptrunc float %1403 to bfloat
  store bfloat %1411, ptr addrspace(3) %817, align 2
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %1412 = or disjoint i64 %820, %56
  %1413 = or disjoint i64 %1412, %51
  %1414 = load <8 x bfloat>, ptr addrspace(3) %830, align 16
  %1415 = mul i64 %1413, %26
  %1416 = add i64 %1415, %826
  %1417 = icmp ult i64 %1413, %25
  %1418 = and i1 %1417, %836
  br i1 %1418, label %1419, label %1421

1419:                                             ; preds = %1402
  %1420 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1416
  store <8 x bfloat> %1414, ptr addrspace(1) %1420, align 2
  br label %1475

1421:                                             ; preds = %1402
  %1422 = icmp ult i64 %826, %26
  %1423 = and i1 %1417, %1422
  br i1 %1423, label %1424, label %1427

1424:                                             ; preds = %1421
  %1425 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1416
  %1426 = extractelement <8 x bfloat> %1414, i64 0
  store bfloat %1426, ptr addrspace(1) %1425, align 2
  br label %1427

1427:                                             ; preds = %1424, %1421
  %1428 = or disjoint i64 %826, 1
  %1429 = icmp ult i64 %1428, %26
  %1430 = and i1 %1417, %1429
  br i1 %1430, label %1431, label %1435

1431:                                             ; preds = %1427
  %1432 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1416
  %1433 = getelementptr i8, ptr addrspace(1) %1432, i64 2
  %1434 = extractelement <8 x bfloat> %1414, i64 1
  store bfloat %1434, ptr addrspace(1) %1433, align 2
  br label %1435

1435:                                             ; preds = %1431, %1427
  %1436 = or disjoint i64 %826, 2
  %1437 = icmp ult i64 %1436, %26
  %1438 = and i1 %1417, %1437
  br i1 %1438, label %1439, label %1443

1439:                                             ; preds = %1435
  %1440 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1416
  %1441 = getelementptr i8, ptr addrspace(1) %1440, i64 4
  %1442 = extractelement <8 x bfloat> %1414, i64 2
  store bfloat %1442, ptr addrspace(1) %1441, align 2
  br label %1443

1443:                                             ; preds = %1439, %1435
  %1444 = or disjoint i64 %826, 3
  %1445 = icmp ult i64 %1444, %26
  %1446 = and i1 %1417, %1445
  br i1 %1446, label %1447, label %1451

1447:                                             ; preds = %1443
  %1448 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1416
  %1449 = getelementptr i8, ptr addrspace(1) %1448, i64 6
  %1450 = extractelement <8 x bfloat> %1414, i64 3
  store bfloat %1450, ptr addrspace(1) %1449, align 2
  br label %1451

1451:                                             ; preds = %1447, %1443
  %1452 = or disjoint i64 %826, 4
  %1453 = icmp ult i64 %1452, %26
  %1454 = and i1 %1417, %1453
  br i1 %1454, label %1455, label %1459

1455:                                             ; preds = %1451
  %1456 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1416
  %1457 = getelementptr i8, ptr addrspace(1) %1456, i64 8
  %1458 = extractelement <8 x bfloat> %1414, i64 4
  store bfloat %1458, ptr addrspace(1) %1457, align 2
  br label %1459

1459:                                             ; preds = %1455, %1451
  %1460 = or disjoint i64 %826, 5
  %1461 = icmp ult i64 %1460, %26
  %1462 = and i1 %1417, %1461
  br i1 %1462, label %1463, label %1467

1463:                                             ; preds = %1459
  %1464 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1416
  %1465 = getelementptr i8, ptr addrspace(1) %1464, i64 10
  %1466 = extractelement <8 x bfloat> %1414, i64 5
  store bfloat %1466, ptr addrspace(1) %1465, align 2
  br label %1467

1467:                                             ; preds = %1463, %1459
  %1468 = or disjoint i64 %826, 6
  %1469 = icmp ult i64 %1468, %26
  %1470 = and i1 %1417, %1469
  br i1 %1470, label %1471, label %1475

1471:                                             ; preds = %1467
  %1472 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1416
  %1473 = getelementptr i8, ptr addrspace(1) %1472, i64 12
  %1474 = extractelement <8 x bfloat> %1414, i64 6
  store bfloat %1474, ptr addrspace(1) %1473, align 2
  br label %1475

1475:                                             ; preds = %1467, %1471, %1419
  %1476 = or disjoint i64 %895, %56
  %1477 = or disjoint i64 %1476, %51
  %1478 = load <8 x bfloat>, ptr addrspace(3) %902, align 16
  %1479 = mul i64 %1477, %26
  %1480 = add i64 %1479, %826
  %1481 = icmp ult i64 %1477, %25
  %1482 = and i1 %1481, %836
  br i1 %1482, label %1483, label %1485

1483:                                             ; preds = %1475
  %1484 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1480
  store <8 x bfloat> %1478, ptr addrspace(1) %1484, align 2
  br label %1539

1485:                                             ; preds = %1475
  %1486 = icmp ult i64 %826, %26
  %1487 = and i1 %1481, %1486
  br i1 %1487, label %1488, label %1491

1488:                                             ; preds = %1485
  %1489 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1480
  %1490 = extractelement <8 x bfloat> %1478, i64 0
  store bfloat %1490, ptr addrspace(1) %1489, align 2
  br label %1491

1491:                                             ; preds = %1488, %1485
  %1492 = or disjoint i64 %826, 1
  %1493 = icmp ult i64 %1492, %26
  %1494 = and i1 %1481, %1493
  br i1 %1494, label %1495, label %1499

1495:                                             ; preds = %1491
  %1496 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1480
  %1497 = getelementptr i8, ptr addrspace(1) %1496, i64 2
  %1498 = extractelement <8 x bfloat> %1478, i64 1
  store bfloat %1498, ptr addrspace(1) %1497, align 2
  br label %1499

1499:                                             ; preds = %1495, %1491
  %1500 = or disjoint i64 %826, 2
  %1501 = icmp ult i64 %1500, %26
  %1502 = and i1 %1481, %1501
  br i1 %1502, label %1503, label %1507

1503:                                             ; preds = %1499
  %1504 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1480
  %1505 = getelementptr i8, ptr addrspace(1) %1504, i64 4
  %1506 = extractelement <8 x bfloat> %1478, i64 2
  store bfloat %1506, ptr addrspace(1) %1505, align 2
  br label %1507

1507:                                             ; preds = %1503, %1499
  %1508 = or disjoint i64 %826, 3
  %1509 = icmp ult i64 %1508, %26
  %1510 = and i1 %1481, %1509
  br i1 %1510, label %1511, label %1515

1511:                                             ; preds = %1507
  %1512 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1480
  %1513 = getelementptr i8, ptr addrspace(1) %1512, i64 6
  %1514 = extractelement <8 x bfloat> %1478, i64 3
  store bfloat %1514, ptr addrspace(1) %1513, align 2
  br label %1515

1515:                                             ; preds = %1511, %1507
  %1516 = or disjoint i64 %826, 4
  %1517 = icmp ult i64 %1516, %26
  %1518 = and i1 %1481, %1517
  br i1 %1518, label %1519, label %1523

1519:                                             ; preds = %1515
  %1520 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1480
  %1521 = getelementptr i8, ptr addrspace(1) %1520, i64 8
  %1522 = extractelement <8 x bfloat> %1478, i64 4
  store bfloat %1522, ptr addrspace(1) %1521, align 2
  br label %1523

1523:                                             ; preds = %1519, %1515
  %1524 = or disjoint i64 %826, 5
  %1525 = icmp ult i64 %1524, %26
  %1526 = and i1 %1481, %1525
  br i1 %1526, label %1527, label %1531

1527:                                             ; preds = %1523
  %1528 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1480
  %1529 = getelementptr i8, ptr addrspace(1) %1528, i64 10
  %1530 = extractelement <8 x bfloat> %1478, i64 5
  store bfloat %1530, ptr addrspace(1) %1529, align 2
  br label %1531

1531:                                             ; preds = %1527, %1523
  %1532 = or disjoint i64 %826, 6
  %1533 = icmp ult i64 %1532, %26
  %1534 = and i1 %1481, %1533
  br i1 %1534, label %1535, label %1539

1535:                                             ; preds = %1531
  %1536 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1480
  %1537 = getelementptr i8, ptr addrspace(1) %1536, i64 12
  %1538 = extractelement <8 x bfloat> %1478, i64 6
  store bfloat %1538, ptr addrspace(1) %1537, align 2
  br label %1539

1539:                                             ; preds = %1531, %1535, %1483
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %1540 = or disjoint i64 %59, %116
  %1541 = or disjoint i64 %1540, 7
  %1542 = icmp ult i64 %1541, %25
  %1543 = and i1 %287, %1542
  %1544 = and i1 %292, %1543
  br i1 %1544, label %1545, label %1551

1545:                                             ; preds = %1539
  %1546 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1540
  %1547 = load <4 x float>, ptr addrspace(1) %1546, align 16
  %1548 = getelementptr i8, ptr addrspace(1) %1546, i64 16
  %1549 = load <4 x float>, ptr addrspace(1) %1548, align 16
  %1550 = shufflevector <4 x float> %1547, <4 x float> %1549, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1599

1551:                                             ; preds = %1539
  %1552 = icmp slt i64 %1540, %25
  %1553 = select i1 %1552, i64 %1540, i64 0
  %1554 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1553
  %1555 = load float, ptr addrspace(1) %1554, align 4
  %1556 = insertelement <8 x float> poison, float %1555, i64 0
  %1557 = or disjoint i64 %59, %516
  %1558 = icmp slt i64 %1557, %25
  %1559 = select i1 %1558, i64 %1557, i64 0
  %1560 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1559
  %1561 = load float, ptr addrspace(1) %1560, align 4
  %1562 = insertelement <8 x float> %1556, float %1561, i64 1
  %1563 = or disjoint i64 %59, %523
  %1564 = icmp slt i64 %1563, %25
  %1565 = select i1 %1564, i64 %1563, i64 0
  %1566 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1565
  %1567 = load float, ptr addrspace(1) %1566, align 4
  %1568 = insertelement <8 x float> %1562, float %1567, i64 2
  %1569 = or disjoint i64 %59, %530
  %1570 = icmp slt i64 %1569, %25
  %1571 = select i1 %1570, i64 %1569, i64 0
  %1572 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1571
  %1573 = load float, ptr addrspace(1) %1572, align 4
  %1574 = insertelement <8 x float> %1568, float %1573, i64 3
  %1575 = or disjoint i64 %59, %537
  %1576 = icmp slt i64 %1575, %25
  %1577 = select i1 %1576, i64 %1575, i64 0
  %1578 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1577
  %1579 = load float, ptr addrspace(1) %1578, align 4
  %1580 = insertelement <8 x float> %1574, float %1579, i64 4
  %1581 = or disjoint i64 %59, %544
  %1582 = icmp slt i64 %1581, %25
  %1583 = select i1 %1582, i64 %1581, i64 0
  %1584 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1583
  %1585 = load float, ptr addrspace(1) %1584, align 4
  %1586 = insertelement <8 x float> %1580, float %1585, i64 5
  %1587 = or disjoint i64 %59, %551
  %1588 = icmp slt i64 %1587, %25
  %1589 = select i1 %1588, i64 %1587, i64 0
  %1590 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1589
  %1591 = load float, ptr addrspace(1) %1590, align 4
  %1592 = insertelement <8 x float> %1586, float %1591, i64 6
  %1593 = or disjoint i64 %59, %558
  %1594 = icmp slt i64 %1593, %25
  %1595 = select i1 %1594, i64 %1593, i64 0
  %1596 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1595
  %1597 = load float, ptr addrspace(1) %1596, align 4
  %1598 = insertelement <8 x float> %1592, float %1597, i64 7
  br label %1599

1599:                                             ; preds = %1545, %1551
  %1600 = phi <8 x float> [ %1598, %1551 ], [ %1550, %1545 ]
  %1601 = extractelement <8 x float> %1600, i64 0
  %1602 = load i8, ptr addrspace(1) %352, align 1
  %1603 = zext i8 %1602 to i32
  %1604 = shl nuw nsw i32 %1603, 23
  %1605 = bitcast i32 %1604 to float
  %1606 = fmul float %1601, %1605
  %1607 = extractelement <8 x float> %279, i64 0
  %1608 = fmul float %1607, %1606
  %1609 = tail call i1 @llvm.is.fpclass.f32(float %1606, /* (sub norm) */ i32 408)
  br i1 %1609, label %1622, label %1610, !prof !4

1610:                                             ; preds = %1599
  %1611 = fpext float %1607 to double
  %1612 = fpext nnan float %1605 to double
  %1613 = fpext float %1601 to double
  %1614 = fmul double %1611, %1612
  %1615 = fmul double %1614, %1613
  %1616 = fptrunc double %1615 to float
  %1617 = fcmp oeq float %1607, 0.000000e+00
  %1618 = tail call float @llvm.fabs.f32(float %1601)
  %1619 = fcmp one float %1618, +inf
  %1620 = and i1 %1617, %1619
  %1621 = select i1 %1620, float 0.000000e+00, float %1616
  br label %1622

1622:                                             ; preds = %1610, %1599
  %1623 = phi float [ %1621, %1610 ], [ %1608, %1599 ]
  %1624 = extractelement <8 x float> %1600, i64 1
  %1625 = fmul float %1624, %1605
  %1626 = extractelement <8 x float> %279, i64 1
  %1627 = fmul float %1626, %1625
  %1628 = tail call i1 @llvm.is.fpclass.f32(float %1625, /* (sub norm) */ i32 408)
  br i1 %1628, label %1641, label %1629, !prof !4

1629:                                             ; preds = %1622
  %1630 = fpext float %1626 to double
  %1631 = fpext nnan float %1605 to double
  %1632 = fpext float %1624 to double
  %1633 = fmul double %1630, %1631
  %1634 = fmul double %1633, %1632
  %1635 = fptrunc double %1634 to float
  %1636 = fcmp oeq float %1626, 0.000000e+00
  %1637 = tail call float @llvm.fabs.f32(float %1624)
  %1638 = fcmp one float %1637, +inf
  %1639 = and i1 %1636, %1638
  %1640 = select i1 %1639, float 0.000000e+00, float %1635
  br label %1641

1641:                                             ; preds = %1629, %1622
  %1642 = phi float [ %1640, %1629 ], [ %1627, %1622 ]
  %1643 = extractelement <8 x float> %1600, i64 2
  %1644 = fmul float %1643, %1605
  %1645 = extractelement <8 x float> %279, i64 2
  %1646 = fmul float %1645, %1644
  %1647 = tail call i1 @llvm.is.fpclass.f32(float %1644, /* (sub norm) */ i32 408)
  br i1 %1647, label %1660, label %1648, !prof !4

1648:                                             ; preds = %1641
  %1649 = fpext float %1645 to double
  %1650 = fpext nnan float %1605 to double
  %1651 = fpext float %1643 to double
  %1652 = fmul double %1649, %1650
  %1653 = fmul double %1652, %1651
  %1654 = fptrunc double %1653 to float
  %1655 = fcmp oeq float %1645, 0.000000e+00
  %1656 = tail call float @llvm.fabs.f32(float %1643)
  %1657 = fcmp one float %1656, +inf
  %1658 = and i1 %1655, %1657
  %1659 = select i1 %1658, float 0.000000e+00, float %1654
  br label %1660

1660:                                             ; preds = %1648, %1641
  %1661 = phi float [ %1659, %1648 ], [ %1646, %1641 ]
  %1662 = extractelement <8 x float> %1600, i64 3
  %1663 = fmul float %1662, %1605
  %1664 = extractelement <8 x float> %279, i64 3
  %1665 = fmul float %1664, %1663
  %1666 = tail call i1 @llvm.is.fpclass.f32(float %1663, /* (sub norm) */ i32 408)
  br i1 %1666, label %1679, label %1667, !prof !4

1667:                                             ; preds = %1660
  %1668 = fpext float %1664 to double
  %1669 = fpext nnan float %1605 to double
  %1670 = fpext float %1662 to double
  %1671 = fmul double %1668, %1669
  %1672 = fmul double %1671, %1670
  %1673 = fptrunc double %1672 to float
  %1674 = fcmp oeq float %1664, 0.000000e+00
  %1675 = tail call float @llvm.fabs.f32(float %1662)
  %1676 = fcmp one float %1675, +inf
  %1677 = and i1 %1674, %1676
  %1678 = select i1 %1677, float 0.000000e+00, float %1673
  br label %1679

1679:                                             ; preds = %1667, %1660
  %1680 = phi float [ %1678, %1667 ], [ %1665, %1660 ]
  %1681 = extractelement <8 x float> %1600, i64 4
  %1682 = fmul float %1681, %1605
  %1683 = extractelement <8 x float> %279, i64 4
  %1684 = fmul float %1683, %1682
  %1685 = tail call i1 @llvm.is.fpclass.f32(float %1682, /* (sub norm) */ i32 408)
  br i1 %1685, label %1698, label %1686, !prof !4

1686:                                             ; preds = %1679
  %1687 = fpext float %1683 to double
  %1688 = fpext nnan float %1605 to double
  %1689 = fpext float %1681 to double
  %1690 = fmul double %1687, %1688
  %1691 = fmul double %1690, %1689
  %1692 = fptrunc double %1691 to float
  %1693 = fcmp oeq float %1683, 0.000000e+00
  %1694 = tail call float @llvm.fabs.f32(float %1681)
  %1695 = fcmp one float %1694, +inf
  %1696 = and i1 %1693, %1695
  %1697 = select i1 %1696, float 0.000000e+00, float %1692
  br label %1698

1698:                                             ; preds = %1686, %1679
  %1699 = phi float [ %1697, %1686 ], [ %1684, %1679 ]
  %1700 = extractelement <8 x float> %1600, i64 5
  %1701 = fmul float %1700, %1605
  %1702 = extractelement <8 x float> %279, i64 5
  %1703 = fmul float %1702, %1701
  %1704 = tail call i1 @llvm.is.fpclass.f32(float %1701, /* (sub norm) */ i32 408)
  br i1 %1704, label %1717, label %1705, !prof !4

1705:                                             ; preds = %1698
  %1706 = fpext float %1702 to double
  %1707 = fpext nnan float %1605 to double
  %1708 = fpext float %1700 to double
  %1709 = fmul double %1706, %1707
  %1710 = fmul double %1709, %1708
  %1711 = fptrunc double %1710 to float
  %1712 = fcmp oeq float %1702, 0.000000e+00
  %1713 = tail call float @llvm.fabs.f32(float %1700)
  %1714 = fcmp one float %1713, +inf
  %1715 = and i1 %1712, %1714
  %1716 = select i1 %1715, float 0.000000e+00, float %1711
  br label %1717

1717:                                             ; preds = %1705, %1698
  %1718 = phi float [ %1716, %1705 ], [ %1703, %1698 ]
  %1719 = extractelement <8 x float> %1600, i64 6
  %1720 = fmul float %1719, %1605
  %1721 = extractelement <8 x float> %279, i64 6
  %1722 = fmul float %1721, %1720
  %1723 = tail call i1 @llvm.is.fpclass.f32(float %1720, /* (sub norm) */ i32 408)
  br i1 %1723, label %1736, label %1724, !prof !4

1724:                                             ; preds = %1717
  %1725 = fpext float %1721 to double
  %1726 = fpext nnan float %1605 to double
  %1727 = fpext float %1719 to double
  %1728 = fmul double %1725, %1726
  %1729 = fmul double %1728, %1727
  %1730 = fptrunc double %1729 to float
  %1731 = fcmp oeq float %1721, 0.000000e+00
  %1732 = tail call float @llvm.fabs.f32(float %1719)
  %1733 = fcmp one float %1732, +inf
  %1734 = and i1 %1731, %1733
  %1735 = select i1 %1734, float 0.000000e+00, float %1730
  br label %1736

1736:                                             ; preds = %1724, %1717
  %1737 = phi float [ %1735, %1724 ], [ %1722, %1717 ]
  %1738 = extractelement <8 x float> %1600, i64 7
  %1739 = fmul float %1738, %1605
  %1740 = extractelement <8 x float> %279, i64 7
  %1741 = fmul float %1740, %1739
  %1742 = tail call i1 @llvm.is.fpclass.f32(float %1739, /* (sub norm) */ i32 408)
  br i1 %1742, label %1755, label %1743, !prof !4

1743:                                             ; preds = %1736
  %1744 = fpext float %1740 to double
  %1745 = fpext nnan float %1605 to double
  %1746 = fpext float %1738 to double
  %1747 = fmul double %1744, %1745
  %1748 = fmul double %1747, %1746
  %1749 = fptrunc double %1748 to float
  %1750 = fcmp oeq float %1740, 0.000000e+00
  %1751 = tail call float @llvm.fabs.f32(float %1738)
  %1752 = fcmp one float %1751, +inf
  %1753 = and i1 %1750, %1752
  %1754 = select i1 %1753, float 0.000000e+00, float %1749
  br label %1755

1755:                                             ; preds = %1743, %1736
  %1756 = phi float [ %1754, %1743 ], [ %1741, %1736 ]
  %1757 = fptrunc float %1623 to bfloat
  store bfloat %1757, ptr addrspace(3) %515, align 2
  %1758 = fptrunc float %1642 to bfloat
  store bfloat %1758, ptr addrspace(3) %522, align 2
  %1759 = fptrunc float %1661 to bfloat
  store bfloat %1759, ptr addrspace(3) %529, align 2
  %1760 = fptrunc float %1680 to bfloat
  store bfloat %1760, ptr addrspace(3) %536, align 2
  %1761 = fptrunc float %1699 to bfloat
  store bfloat %1761, ptr addrspace(3) %543, align 2
  %1762 = fptrunc float %1718 to bfloat
  store bfloat %1762, ptr addrspace(3) %550, align 2
  %1763 = fptrunc float %1737 to bfloat
  store bfloat %1763, ptr addrspace(3) %557, align 2
  %1764 = fptrunc float %1756 to bfloat
  store bfloat %1764, ptr addrspace(3) %564, align 2
  %1765 = and i1 %567, %1542
  %1766 = and i1 %292, %1765
  br i1 %1766, label %1767, label %1773

1767:                                             ; preds = %1755
  %1768 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1540
  %1769 = load <4 x float>, ptr addrspace(1) %1768, align 16
  %1770 = getelementptr i8, ptr addrspace(1) %1768, i64 16
  %1771 = load <4 x float>, ptr addrspace(1) %1770, align 16
  %1772 = shufflevector <4 x float> %1769, <4 x float> %1771, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1821

1773:                                             ; preds = %1755
  %1774 = icmp slt i64 %1540, %25
  %1775 = select i1 %1774, i64 %1540, i64 0
  %1776 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1775
  %1777 = load float, ptr addrspace(1) %1776, align 4
  %1778 = insertelement <8 x float> poison, float %1777, i64 0
  %1779 = or disjoint i64 %59, %516
  %1780 = icmp slt i64 %1779, %25
  %1781 = select i1 %1780, i64 %1779, i64 0
  %1782 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1781
  %1783 = load float, ptr addrspace(1) %1782, align 4
  %1784 = insertelement <8 x float> %1778, float %1783, i64 1
  %1785 = or disjoint i64 %59, %523
  %1786 = icmp slt i64 %1785, %25
  %1787 = select i1 %1786, i64 %1785, i64 0
  %1788 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1787
  %1789 = load float, ptr addrspace(1) %1788, align 4
  %1790 = insertelement <8 x float> %1784, float %1789, i64 2
  %1791 = or disjoint i64 %59, %530
  %1792 = icmp slt i64 %1791, %25
  %1793 = select i1 %1792, i64 %1791, i64 0
  %1794 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1793
  %1795 = load float, ptr addrspace(1) %1794, align 4
  %1796 = insertelement <8 x float> %1790, float %1795, i64 3
  %1797 = or disjoint i64 %59, %537
  %1798 = icmp slt i64 %1797, %25
  %1799 = select i1 %1798, i64 %1797, i64 0
  %1800 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1799
  %1801 = load float, ptr addrspace(1) %1800, align 4
  %1802 = insertelement <8 x float> %1796, float %1801, i64 4
  %1803 = or disjoint i64 %59, %544
  %1804 = icmp slt i64 %1803, %25
  %1805 = select i1 %1804, i64 %1803, i64 0
  %1806 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1805
  %1807 = load float, ptr addrspace(1) %1806, align 4
  %1808 = insertelement <8 x float> %1802, float %1807, i64 5
  %1809 = or disjoint i64 %59, %551
  %1810 = icmp slt i64 %1809, %25
  %1811 = select i1 %1810, i64 %1809, i64 0
  %1812 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1811
  %1813 = load float, ptr addrspace(1) %1812, align 4
  %1814 = insertelement <8 x float> %1808, float %1813, i64 6
  %1815 = or disjoint i64 %59, %558
  %1816 = icmp slt i64 %1815, %25
  %1817 = select i1 %1816, i64 %1815, i64 0
  %1818 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1817
  %1819 = load float, ptr addrspace(1) %1818, align 4
  %1820 = insertelement <8 x float> %1814, float %1819, i64 7
  br label %1821

1821:                                             ; preds = %1767, %1773
  %1822 = phi <8 x float> [ %1820, %1773 ], [ %1772, %1767 ]
  %1823 = extractelement <8 x float> %1822, i64 0
  %1824 = load i8, ptr addrspace(1) %629, align 1
  %1825 = zext i8 %1824 to i32
  %1826 = shl nuw nsw i32 %1825, 23
  %1827 = bitcast i32 %1826 to float
  %1828 = fmul float %1823, %1827
  %1829 = extractelement <8 x float> %280, i64 0
  %1830 = fmul float %1829, %1828
  %1831 = tail call i1 @llvm.is.fpclass.f32(float %1828, /* (sub norm) */ i32 408)
  br i1 %1831, label %1844, label %1832, !prof !4

1832:                                             ; preds = %1821
  %1833 = fpext float %1829 to double
  %1834 = fpext nnan float %1827 to double
  %1835 = fpext float %1823 to double
  %1836 = fmul double %1833, %1834
  %1837 = fmul double %1836, %1835
  %1838 = fptrunc double %1837 to float
  %1839 = fcmp oeq float %1829, 0.000000e+00
  %1840 = tail call float @llvm.fabs.f32(float %1823)
  %1841 = fcmp one float %1840, +inf
  %1842 = and i1 %1839, %1841
  %1843 = select i1 %1842, float 0.000000e+00, float %1838
  br label %1844

1844:                                             ; preds = %1832, %1821
  %1845 = phi float [ %1843, %1832 ], [ %1830, %1821 ]
  %1846 = extractelement <8 x float> %1822, i64 1
  %1847 = fmul float %1846, %1827
  %1848 = extractelement <8 x float> %280, i64 1
  %1849 = fmul float %1848, %1847
  %1850 = tail call i1 @llvm.is.fpclass.f32(float %1847, /* (sub norm) */ i32 408)
  br i1 %1850, label %1863, label %1851, !prof !4

1851:                                             ; preds = %1844
  %1852 = fpext float %1848 to double
  %1853 = fpext nnan float %1827 to double
  %1854 = fpext float %1846 to double
  %1855 = fmul double %1852, %1853
  %1856 = fmul double %1855, %1854
  %1857 = fptrunc double %1856 to float
  %1858 = fcmp oeq float %1848, 0.000000e+00
  %1859 = tail call float @llvm.fabs.f32(float %1846)
  %1860 = fcmp one float %1859, +inf
  %1861 = and i1 %1858, %1860
  %1862 = select i1 %1861, float 0.000000e+00, float %1857
  br label %1863

1863:                                             ; preds = %1851, %1844
  %1864 = phi float [ %1862, %1851 ], [ %1849, %1844 ]
  %1865 = extractelement <8 x float> %1822, i64 2
  %1866 = fmul float %1865, %1827
  %1867 = extractelement <8 x float> %280, i64 2
  %1868 = fmul float %1867, %1866
  %1869 = tail call i1 @llvm.is.fpclass.f32(float %1866, /* (sub norm) */ i32 408)
  br i1 %1869, label %1882, label %1870, !prof !4

1870:                                             ; preds = %1863
  %1871 = fpext float %1867 to double
  %1872 = fpext nnan float %1827 to double
  %1873 = fpext float %1865 to double
  %1874 = fmul double %1871, %1872
  %1875 = fmul double %1874, %1873
  %1876 = fptrunc double %1875 to float
  %1877 = fcmp oeq float %1867, 0.000000e+00
  %1878 = tail call float @llvm.fabs.f32(float %1865)
  %1879 = fcmp one float %1878, +inf
  %1880 = and i1 %1877, %1879
  %1881 = select i1 %1880, float 0.000000e+00, float %1876
  br label %1882

1882:                                             ; preds = %1870, %1863
  %1883 = phi float [ %1881, %1870 ], [ %1868, %1863 ]
  %1884 = extractelement <8 x float> %1822, i64 3
  %1885 = fmul float %1884, %1827
  %1886 = extractelement <8 x float> %280, i64 3
  %1887 = fmul float %1886, %1885
  %1888 = tail call i1 @llvm.is.fpclass.f32(float %1885, /* (sub norm) */ i32 408)
  br i1 %1888, label %1901, label %1889, !prof !4

1889:                                             ; preds = %1882
  %1890 = fpext float %1886 to double
  %1891 = fpext nnan float %1827 to double
  %1892 = fpext float %1884 to double
  %1893 = fmul double %1890, %1891
  %1894 = fmul double %1893, %1892
  %1895 = fptrunc double %1894 to float
  %1896 = fcmp oeq float %1886, 0.000000e+00
  %1897 = tail call float @llvm.fabs.f32(float %1884)
  %1898 = fcmp one float %1897, +inf
  %1899 = and i1 %1896, %1898
  %1900 = select i1 %1899, float 0.000000e+00, float %1895
  br label %1901

1901:                                             ; preds = %1889, %1882
  %1902 = phi float [ %1900, %1889 ], [ %1887, %1882 ]
  %1903 = extractelement <8 x float> %1822, i64 4
  %1904 = fmul float %1903, %1827
  %1905 = extractelement <8 x float> %280, i64 4
  %1906 = fmul float %1905, %1904
  %1907 = tail call i1 @llvm.is.fpclass.f32(float %1904, /* (sub norm) */ i32 408)
  br i1 %1907, label %1920, label %1908, !prof !4

1908:                                             ; preds = %1901
  %1909 = fpext float %1905 to double
  %1910 = fpext nnan float %1827 to double
  %1911 = fpext float %1903 to double
  %1912 = fmul double %1909, %1910
  %1913 = fmul double %1912, %1911
  %1914 = fptrunc double %1913 to float
  %1915 = fcmp oeq float %1905, 0.000000e+00
  %1916 = tail call float @llvm.fabs.f32(float %1903)
  %1917 = fcmp one float %1916, +inf
  %1918 = and i1 %1915, %1917
  %1919 = select i1 %1918, float 0.000000e+00, float %1914
  br label %1920

1920:                                             ; preds = %1908, %1901
  %1921 = phi float [ %1919, %1908 ], [ %1906, %1901 ]
  %1922 = extractelement <8 x float> %1822, i64 5
  %1923 = fmul float %1922, %1827
  %1924 = extractelement <8 x float> %280, i64 5
  %1925 = fmul float %1924, %1923
  %1926 = tail call i1 @llvm.is.fpclass.f32(float %1923, /* (sub norm) */ i32 408)
  br i1 %1926, label %1939, label %1927, !prof !4

1927:                                             ; preds = %1920
  %1928 = fpext float %1924 to double
  %1929 = fpext nnan float %1827 to double
  %1930 = fpext float %1922 to double
  %1931 = fmul double %1928, %1929
  %1932 = fmul double %1931, %1930
  %1933 = fptrunc double %1932 to float
  %1934 = fcmp oeq float %1924, 0.000000e+00
  %1935 = tail call float @llvm.fabs.f32(float %1922)
  %1936 = fcmp one float %1935, +inf
  %1937 = and i1 %1934, %1936
  %1938 = select i1 %1937, float 0.000000e+00, float %1933
  br label %1939

1939:                                             ; preds = %1927, %1920
  %1940 = phi float [ %1938, %1927 ], [ %1925, %1920 ]
  %1941 = extractelement <8 x float> %1822, i64 6
  %1942 = fmul float %1941, %1827
  %1943 = extractelement <8 x float> %280, i64 6
  %1944 = fmul float %1943, %1942
  %1945 = tail call i1 @llvm.is.fpclass.f32(float %1942, /* (sub norm) */ i32 408)
  br i1 %1945, label %1958, label %1946, !prof !4

1946:                                             ; preds = %1939
  %1947 = fpext float %1943 to double
  %1948 = fpext nnan float %1827 to double
  %1949 = fpext float %1941 to double
  %1950 = fmul double %1947, %1948
  %1951 = fmul double %1950, %1949
  %1952 = fptrunc double %1951 to float
  %1953 = fcmp oeq float %1943, 0.000000e+00
  %1954 = tail call float @llvm.fabs.f32(float %1941)
  %1955 = fcmp one float %1954, +inf
  %1956 = and i1 %1953, %1955
  %1957 = select i1 %1956, float 0.000000e+00, float %1952
  br label %1958

1958:                                             ; preds = %1946, %1939
  %1959 = phi float [ %1957, %1946 ], [ %1944, %1939 ]
  %1960 = extractelement <8 x float> %1822, i64 7
  %1961 = fmul float %1960, %1827
  %1962 = extractelement <8 x float> %280, i64 7
  %1963 = fmul float %1962, %1961
  %1964 = tail call i1 @llvm.is.fpclass.f32(float %1961, /* (sub norm) */ i32 408)
  br i1 %1964, label %1977, label %1965, !prof !4

1965:                                             ; preds = %1958
  %1966 = fpext float %1962 to double
  %1967 = fpext nnan float %1827 to double
  %1968 = fpext float %1960 to double
  %1969 = fmul double %1966, %1967
  %1970 = fmul double %1969, %1968
  %1971 = fptrunc double %1970 to float
  %1972 = fcmp oeq float %1962, 0.000000e+00
  %1973 = tail call float @llvm.fabs.f32(float %1960)
  %1974 = fcmp one float %1973, +inf
  %1975 = and i1 %1972, %1974
  %1976 = select i1 %1975, float 0.000000e+00, float %1971
  br label %1977

1977:                                             ; preds = %1965, %1958
  %1978 = phi float [ %1976, %1965 ], [ %1963, %1958 ]
  %1979 = fptrunc float %1845 to bfloat
  store bfloat %1979, ptr addrspace(3) %789, align 2
  %1980 = fptrunc float %1864 to bfloat
  store bfloat %1980, ptr addrspace(3) %793, align 2
  %1981 = fptrunc float %1883 to bfloat
  store bfloat %1981, ptr addrspace(3) %797, align 2
  %1982 = fptrunc float %1902 to bfloat
  store bfloat %1982, ptr addrspace(3) %801, align 2
  %1983 = fptrunc float %1921 to bfloat
  store bfloat %1983, ptr addrspace(3) %805, align 2
  %1984 = fptrunc float %1940 to bfloat
  store bfloat %1984, ptr addrspace(3) %809, align 2
  %1985 = fptrunc float %1959 to bfloat
  store bfloat %1985, ptr addrspace(3) %813, align 2
  %1986 = fptrunc float %1978 to bfloat
  store bfloat %1986, ptr addrspace(3) %817, align 2
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %1987 = or disjoint i64 %820, %58
  %1988 = or disjoint i64 %1987, %51
  %1989 = load <8 x bfloat>, ptr addrspace(3) %830, align 16
  %1990 = mul i64 %1988, %26
  %1991 = add i64 %1990, %826
  %1992 = icmp ult i64 %1988, %25
  %1993 = and i1 %1992, %836
  br i1 %1993, label %1994, label %1996

1994:                                             ; preds = %1977
  %1995 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1991
  store <8 x bfloat> %1989, ptr addrspace(1) %1995, align 2
  br label %2050

1996:                                             ; preds = %1977
  %1997 = icmp ult i64 %826, %26
  %1998 = and i1 %1992, %1997
  br i1 %1998, label %1999, label %2002

1999:                                             ; preds = %1996
  %2000 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1991
  %2001 = extractelement <8 x bfloat> %1989, i64 0
  store bfloat %2001, ptr addrspace(1) %2000, align 2
  br label %2002

2002:                                             ; preds = %1999, %1996
  %2003 = or disjoint i64 %826, 1
  %2004 = icmp ult i64 %2003, %26
  %2005 = and i1 %1992, %2004
  br i1 %2005, label %2006, label %2010

2006:                                             ; preds = %2002
  %2007 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1991
  %2008 = getelementptr i8, ptr addrspace(1) %2007, i64 2
  %2009 = extractelement <8 x bfloat> %1989, i64 1
  store bfloat %2009, ptr addrspace(1) %2008, align 2
  br label %2010

2010:                                             ; preds = %2006, %2002
  %2011 = or disjoint i64 %826, 2
  %2012 = icmp ult i64 %2011, %26
  %2013 = and i1 %1992, %2012
  br i1 %2013, label %2014, label %2018

2014:                                             ; preds = %2010
  %2015 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1991
  %2016 = getelementptr i8, ptr addrspace(1) %2015, i64 4
  %2017 = extractelement <8 x bfloat> %1989, i64 2
  store bfloat %2017, ptr addrspace(1) %2016, align 2
  br label %2018

2018:                                             ; preds = %2014, %2010
  %2019 = or disjoint i64 %826, 3
  %2020 = icmp ult i64 %2019, %26
  %2021 = and i1 %1992, %2020
  br i1 %2021, label %2022, label %2026

2022:                                             ; preds = %2018
  %2023 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1991
  %2024 = getelementptr i8, ptr addrspace(1) %2023, i64 6
  %2025 = extractelement <8 x bfloat> %1989, i64 3
  store bfloat %2025, ptr addrspace(1) %2024, align 2
  br label %2026

2026:                                             ; preds = %2022, %2018
  %2027 = or disjoint i64 %826, 4
  %2028 = icmp ult i64 %2027, %26
  %2029 = and i1 %1992, %2028
  br i1 %2029, label %2030, label %2034

2030:                                             ; preds = %2026
  %2031 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1991
  %2032 = getelementptr i8, ptr addrspace(1) %2031, i64 8
  %2033 = extractelement <8 x bfloat> %1989, i64 4
  store bfloat %2033, ptr addrspace(1) %2032, align 2
  br label %2034

2034:                                             ; preds = %2030, %2026
  %2035 = or disjoint i64 %826, 5
  %2036 = icmp ult i64 %2035, %26
  %2037 = and i1 %1992, %2036
  br i1 %2037, label %2038, label %2042

2038:                                             ; preds = %2034
  %2039 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1991
  %2040 = getelementptr i8, ptr addrspace(1) %2039, i64 10
  %2041 = extractelement <8 x bfloat> %1989, i64 5
  store bfloat %2041, ptr addrspace(1) %2040, align 2
  br label %2042

2042:                                             ; preds = %2038, %2034
  %2043 = or disjoint i64 %826, 6
  %2044 = icmp ult i64 %2043, %26
  %2045 = and i1 %1992, %2044
  br i1 %2045, label %2046, label %2050

2046:                                             ; preds = %2042
  %2047 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1991
  %2048 = getelementptr i8, ptr addrspace(1) %2047, i64 12
  %2049 = extractelement <8 x bfloat> %1989, i64 6
  store bfloat %2049, ptr addrspace(1) %2048, align 2
  br label %2050

2050:                                             ; preds = %2042, %2046, %1994
  %2051 = or disjoint i64 %895, %58
  %2052 = or disjoint i64 %2051, %51
  %2053 = load <8 x bfloat>, ptr addrspace(3) %902, align 16
  %2054 = mul i64 %2052, %26
  %2055 = add i64 %2054, %826
  %2056 = icmp ult i64 %2052, %25
  %2057 = and i1 %2056, %836
  br i1 %2057, label %2058, label %2060

2058:                                             ; preds = %2050
  %2059 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2055
  store <8 x bfloat> %2053, ptr addrspace(1) %2059, align 2
  br label %2114

2060:                                             ; preds = %2050
  %2061 = icmp ult i64 %826, %26
  %2062 = and i1 %2056, %2061
  br i1 %2062, label %2063, label %2066

2063:                                             ; preds = %2060
  %2064 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2055
  %2065 = extractelement <8 x bfloat> %2053, i64 0
  store bfloat %2065, ptr addrspace(1) %2064, align 2
  br label %2066

2066:                                             ; preds = %2063, %2060
  %2067 = or disjoint i64 %826, 1
  %2068 = icmp ult i64 %2067, %26
  %2069 = and i1 %2056, %2068
  br i1 %2069, label %2070, label %2074

2070:                                             ; preds = %2066
  %2071 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2055
  %2072 = getelementptr i8, ptr addrspace(1) %2071, i64 2
  %2073 = extractelement <8 x bfloat> %2053, i64 1
  store bfloat %2073, ptr addrspace(1) %2072, align 2
  br label %2074

2074:                                             ; preds = %2070, %2066
  %2075 = or disjoint i64 %826, 2
  %2076 = icmp ult i64 %2075, %26
  %2077 = and i1 %2056, %2076
  br i1 %2077, label %2078, label %2082

2078:                                             ; preds = %2074
  %2079 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2055
  %2080 = getelementptr i8, ptr addrspace(1) %2079, i64 4
  %2081 = extractelement <8 x bfloat> %2053, i64 2
  store bfloat %2081, ptr addrspace(1) %2080, align 2
  br label %2082

2082:                                             ; preds = %2078, %2074
  %2083 = or disjoint i64 %826, 3
  %2084 = icmp ult i64 %2083, %26
  %2085 = and i1 %2056, %2084
  br i1 %2085, label %2086, label %2090

2086:                                             ; preds = %2082
  %2087 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2055
  %2088 = getelementptr i8, ptr addrspace(1) %2087, i64 6
  %2089 = extractelement <8 x bfloat> %2053, i64 3
  store bfloat %2089, ptr addrspace(1) %2088, align 2
  br label %2090

2090:                                             ; preds = %2086, %2082
  %2091 = or disjoint i64 %826, 4
  %2092 = icmp ult i64 %2091, %26
  %2093 = and i1 %2056, %2092
  br i1 %2093, label %2094, label %2098

2094:                                             ; preds = %2090
  %2095 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2055
  %2096 = getelementptr i8, ptr addrspace(1) %2095, i64 8
  %2097 = extractelement <8 x bfloat> %2053, i64 4
  store bfloat %2097, ptr addrspace(1) %2096, align 2
  br label %2098

2098:                                             ; preds = %2094, %2090
  %2099 = or disjoint i64 %826, 5
  %2100 = icmp ult i64 %2099, %26
  %2101 = and i1 %2056, %2100
  br i1 %2101, label %2102, label %2106

2102:                                             ; preds = %2098
  %2103 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2055
  %2104 = getelementptr i8, ptr addrspace(1) %2103, i64 10
  %2105 = extractelement <8 x bfloat> %2053, i64 5
  store bfloat %2105, ptr addrspace(1) %2104, align 2
  br label %2106

2106:                                             ; preds = %2102, %2098
  %2107 = or disjoint i64 %826, 6
  %2108 = icmp ult i64 %2107, %26
  %2109 = and i1 %2056, %2108
  br i1 %2109, label %2110, label %2114

2110:                                             ; preds = %2106
  %2111 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2055
  %2112 = getelementptr i8, ptr addrspace(1) %2111, i64 12
  %2113 = extractelement <8 x bfloat> %2053, i64 6
  store bfloat %2113, ptr addrspace(1) %2112, align 2
  br label %2114

2114:                                             ; preds = %2106, %2110, %2058
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %2115 = or disjoint i64 %61, %116
  %2116 = or disjoint i64 %2115, 7
  %2117 = icmp ult i64 %2116, %25
  %2118 = and i1 %287, %2117
  %2119 = and i1 %292, %2118
  br i1 %2119, label %2120, label %2126

2120:                                             ; preds = %2114
  %2121 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %2115
  %2122 = load <4 x float>, ptr addrspace(1) %2121, align 16
  %2123 = getelementptr i8, ptr addrspace(1) %2121, i64 16
  %2124 = load <4 x float>, ptr addrspace(1) %2123, align 16
  %2125 = shufflevector <4 x float> %2122, <4 x float> %2124, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2174

2126:                                             ; preds = %2114
  %2127 = icmp slt i64 %2115, %25
  %2128 = select i1 %2127, i64 %2115, i64 0
  %2129 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2128
  %2130 = load float, ptr addrspace(1) %2129, align 4
  %2131 = insertelement <8 x float> poison, float %2130, i64 0
  %2132 = or disjoint i64 %61, %516
  %2133 = icmp slt i64 %2132, %25
  %2134 = select i1 %2133, i64 %2132, i64 0
  %2135 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2134
  %2136 = load float, ptr addrspace(1) %2135, align 4
  %2137 = insertelement <8 x float> %2131, float %2136, i64 1
  %2138 = or disjoint i64 %61, %523
  %2139 = icmp slt i64 %2138, %25
  %2140 = select i1 %2139, i64 %2138, i64 0
  %2141 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2140
  %2142 = load float, ptr addrspace(1) %2141, align 4
  %2143 = insertelement <8 x float> %2137, float %2142, i64 2
  %2144 = or disjoint i64 %61, %530
  %2145 = icmp slt i64 %2144, %25
  %2146 = select i1 %2145, i64 %2144, i64 0
  %2147 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2146
  %2148 = load float, ptr addrspace(1) %2147, align 4
  %2149 = insertelement <8 x float> %2143, float %2148, i64 3
  %2150 = or disjoint i64 %61, %537
  %2151 = icmp slt i64 %2150, %25
  %2152 = select i1 %2151, i64 %2150, i64 0
  %2153 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2152
  %2154 = load float, ptr addrspace(1) %2153, align 4
  %2155 = insertelement <8 x float> %2149, float %2154, i64 4
  %2156 = or disjoint i64 %61, %544
  %2157 = icmp slt i64 %2156, %25
  %2158 = select i1 %2157, i64 %2156, i64 0
  %2159 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2158
  %2160 = load float, ptr addrspace(1) %2159, align 4
  %2161 = insertelement <8 x float> %2155, float %2160, i64 5
  %2162 = or disjoint i64 %61, %551
  %2163 = icmp slt i64 %2162, %25
  %2164 = select i1 %2163, i64 %2162, i64 0
  %2165 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2164
  %2166 = load float, ptr addrspace(1) %2165, align 4
  %2167 = insertelement <8 x float> %2161, float %2166, i64 6
  %2168 = or disjoint i64 %61, %558
  %2169 = icmp slt i64 %2168, %25
  %2170 = select i1 %2169, i64 %2168, i64 0
  %2171 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2170
  %2172 = load float, ptr addrspace(1) %2171, align 4
  %2173 = insertelement <8 x float> %2167, float %2172, i64 7
  br label %2174

2174:                                             ; preds = %2120, %2126
  %2175 = phi <8 x float> [ %2173, %2126 ], [ %2125, %2120 ]
  %2176 = extractelement <8 x float> %2175, i64 0
  %2177 = load i8, ptr addrspace(1) %352, align 1
  %2178 = zext i8 %2177 to i32
  %2179 = shl nuw nsw i32 %2178, 23
  %2180 = bitcast i32 %2179 to float
  %2181 = fmul float %2176, %2180
  %2182 = extractelement <8 x float> %281, i64 0
  %2183 = fmul float %2182, %2181
  %2184 = tail call i1 @llvm.is.fpclass.f32(float %2181, /* (sub norm) */ i32 408)
  br i1 %2184, label %2197, label %2185, !prof !4

2185:                                             ; preds = %2174
  %2186 = fpext float %2182 to double
  %2187 = fpext nnan float %2180 to double
  %2188 = fpext float %2176 to double
  %2189 = fmul double %2186, %2187
  %2190 = fmul double %2189, %2188
  %2191 = fptrunc double %2190 to float
  %2192 = fcmp oeq float %2182, 0.000000e+00
  %2193 = tail call float @llvm.fabs.f32(float %2176)
  %2194 = fcmp one float %2193, +inf
  %2195 = and i1 %2192, %2194
  %2196 = select i1 %2195, float 0.000000e+00, float %2191
  br label %2197

2197:                                             ; preds = %2185, %2174
  %2198 = phi float [ %2196, %2185 ], [ %2183, %2174 ]
  %2199 = extractelement <8 x float> %2175, i64 1
  %2200 = fmul float %2199, %2180
  %2201 = extractelement <8 x float> %281, i64 1
  %2202 = fmul float %2201, %2200
  %2203 = tail call i1 @llvm.is.fpclass.f32(float %2200, /* (sub norm) */ i32 408)
  br i1 %2203, label %2216, label %2204, !prof !4

2204:                                             ; preds = %2197
  %2205 = fpext float %2201 to double
  %2206 = fpext nnan float %2180 to double
  %2207 = fpext float %2199 to double
  %2208 = fmul double %2205, %2206
  %2209 = fmul double %2208, %2207
  %2210 = fptrunc double %2209 to float
  %2211 = fcmp oeq float %2201, 0.000000e+00
  %2212 = tail call float @llvm.fabs.f32(float %2199)
  %2213 = fcmp one float %2212, +inf
  %2214 = and i1 %2211, %2213
  %2215 = select i1 %2214, float 0.000000e+00, float %2210
  br label %2216

2216:                                             ; preds = %2204, %2197
  %2217 = phi float [ %2215, %2204 ], [ %2202, %2197 ]
  %2218 = extractelement <8 x float> %2175, i64 2
  %2219 = fmul float %2218, %2180
  %2220 = extractelement <8 x float> %281, i64 2
  %2221 = fmul float %2220, %2219
  %2222 = tail call i1 @llvm.is.fpclass.f32(float %2219, /* (sub norm) */ i32 408)
  br i1 %2222, label %2235, label %2223, !prof !4

2223:                                             ; preds = %2216
  %2224 = fpext float %2220 to double
  %2225 = fpext nnan float %2180 to double
  %2226 = fpext float %2218 to double
  %2227 = fmul double %2224, %2225
  %2228 = fmul double %2227, %2226
  %2229 = fptrunc double %2228 to float
  %2230 = fcmp oeq float %2220, 0.000000e+00
  %2231 = tail call float @llvm.fabs.f32(float %2218)
  %2232 = fcmp one float %2231, +inf
  %2233 = and i1 %2230, %2232
  %2234 = select i1 %2233, float 0.000000e+00, float %2229
  br label %2235

2235:                                             ; preds = %2223, %2216
  %2236 = phi float [ %2234, %2223 ], [ %2221, %2216 ]
  %2237 = extractelement <8 x float> %2175, i64 3
  %2238 = fmul float %2237, %2180
  %2239 = extractelement <8 x float> %281, i64 3
  %2240 = fmul float %2239, %2238
  %2241 = tail call i1 @llvm.is.fpclass.f32(float %2238, /* (sub norm) */ i32 408)
  br i1 %2241, label %2254, label %2242, !prof !4

2242:                                             ; preds = %2235
  %2243 = fpext float %2239 to double
  %2244 = fpext nnan float %2180 to double
  %2245 = fpext float %2237 to double
  %2246 = fmul double %2243, %2244
  %2247 = fmul double %2246, %2245
  %2248 = fptrunc double %2247 to float
  %2249 = fcmp oeq float %2239, 0.000000e+00
  %2250 = tail call float @llvm.fabs.f32(float %2237)
  %2251 = fcmp one float %2250, +inf
  %2252 = and i1 %2249, %2251
  %2253 = select i1 %2252, float 0.000000e+00, float %2248
  br label %2254

2254:                                             ; preds = %2242, %2235
  %2255 = phi float [ %2253, %2242 ], [ %2240, %2235 ]
  %2256 = extractelement <8 x float> %2175, i64 4
  %2257 = fmul float %2256, %2180
  %2258 = extractelement <8 x float> %281, i64 4
  %2259 = fmul float %2258, %2257
  %2260 = tail call i1 @llvm.is.fpclass.f32(float %2257, /* (sub norm) */ i32 408)
  br i1 %2260, label %2273, label %2261, !prof !4

2261:                                             ; preds = %2254
  %2262 = fpext float %2258 to double
  %2263 = fpext nnan float %2180 to double
  %2264 = fpext float %2256 to double
  %2265 = fmul double %2262, %2263
  %2266 = fmul double %2265, %2264
  %2267 = fptrunc double %2266 to float
  %2268 = fcmp oeq float %2258, 0.000000e+00
  %2269 = tail call float @llvm.fabs.f32(float %2256)
  %2270 = fcmp one float %2269, +inf
  %2271 = and i1 %2268, %2270
  %2272 = select i1 %2271, float 0.000000e+00, float %2267
  br label %2273

2273:                                             ; preds = %2261, %2254
  %2274 = phi float [ %2272, %2261 ], [ %2259, %2254 ]
  %2275 = extractelement <8 x float> %2175, i64 5
  %2276 = fmul float %2275, %2180
  %2277 = extractelement <8 x float> %281, i64 5
  %2278 = fmul float %2277, %2276
  %2279 = tail call i1 @llvm.is.fpclass.f32(float %2276, /* (sub norm) */ i32 408)
  br i1 %2279, label %2292, label %2280, !prof !4

2280:                                             ; preds = %2273
  %2281 = fpext float %2277 to double
  %2282 = fpext nnan float %2180 to double
  %2283 = fpext float %2275 to double
  %2284 = fmul double %2281, %2282
  %2285 = fmul double %2284, %2283
  %2286 = fptrunc double %2285 to float
  %2287 = fcmp oeq float %2277, 0.000000e+00
  %2288 = tail call float @llvm.fabs.f32(float %2275)
  %2289 = fcmp one float %2288, +inf
  %2290 = and i1 %2287, %2289
  %2291 = select i1 %2290, float 0.000000e+00, float %2286
  br label %2292

2292:                                             ; preds = %2280, %2273
  %2293 = phi float [ %2291, %2280 ], [ %2278, %2273 ]
  %2294 = extractelement <8 x float> %2175, i64 6
  %2295 = fmul float %2294, %2180
  %2296 = extractelement <8 x float> %281, i64 6
  %2297 = fmul float %2296, %2295
  %2298 = tail call i1 @llvm.is.fpclass.f32(float %2295, /* (sub norm) */ i32 408)
  br i1 %2298, label %2311, label %2299, !prof !4

2299:                                             ; preds = %2292
  %2300 = fpext float %2296 to double
  %2301 = fpext nnan float %2180 to double
  %2302 = fpext float %2294 to double
  %2303 = fmul double %2300, %2301
  %2304 = fmul double %2303, %2302
  %2305 = fptrunc double %2304 to float
  %2306 = fcmp oeq float %2296, 0.000000e+00
  %2307 = tail call float @llvm.fabs.f32(float %2294)
  %2308 = fcmp one float %2307, +inf
  %2309 = and i1 %2306, %2308
  %2310 = select i1 %2309, float 0.000000e+00, float %2305
  br label %2311

2311:                                             ; preds = %2299, %2292
  %2312 = phi float [ %2310, %2299 ], [ %2297, %2292 ]
  %2313 = extractelement <8 x float> %2175, i64 7
  %2314 = fmul float %2313, %2180
  %2315 = extractelement <8 x float> %281, i64 7
  %2316 = fmul float %2315, %2314
  %2317 = tail call i1 @llvm.is.fpclass.f32(float %2314, /* (sub norm) */ i32 408)
  br i1 %2317, label %2330, label %2318, !prof !4

2318:                                             ; preds = %2311
  %2319 = fpext float %2315 to double
  %2320 = fpext nnan float %2180 to double
  %2321 = fpext float %2313 to double
  %2322 = fmul double %2319, %2320
  %2323 = fmul double %2322, %2321
  %2324 = fptrunc double %2323 to float
  %2325 = fcmp oeq float %2315, 0.000000e+00
  %2326 = tail call float @llvm.fabs.f32(float %2313)
  %2327 = fcmp one float %2326, +inf
  %2328 = and i1 %2325, %2327
  %2329 = select i1 %2328, float 0.000000e+00, float %2324
  br label %2330

2330:                                             ; preds = %2318, %2311
  %2331 = phi float [ %2329, %2318 ], [ %2316, %2311 ]
  %2332 = fptrunc float %2198 to bfloat
  store bfloat %2332, ptr addrspace(3) %515, align 2
  %2333 = fptrunc float %2217 to bfloat
  store bfloat %2333, ptr addrspace(3) %522, align 2
  %2334 = fptrunc float %2236 to bfloat
  store bfloat %2334, ptr addrspace(3) %529, align 2
  %2335 = fptrunc float %2255 to bfloat
  store bfloat %2335, ptr addrspace(3) %536, align 2
  %2336 = fptrunc float %2274 to bfloat
  store bfloat %2336, ptr addrspace(3) %543, align 2
  %2337 = fptrunc float %2293 to bfloat
  store bfloat %2337, ptr addrspace(3) %550, align 2
  %2338 = fptrunc float %2312 to bfloat
  store bfloat %2338, ptr addrspace(3) %557, align 2
  %2339 = fptrunc float %2331 to bfloat
  store bfloat %2339, ptr addrspace(3) %564, align 2
  %2340 = and i1 %567, %2117
  %2341 = and i1 %292, %2340
  br i1 %2341, label %2342, label %2348

2342:                                             ; preds = %2330
  %2343 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %2115
  %2344 = load <4 x float>, ptr addrspace(1) %2343, align 16
  %2345 = getelementptr i8, ptr addrspace(1) %2343, i64 16
  %2346 = load <4 x float>, ptr addrspace(1) %2345, align 16
  %2347 = shufflevector <4 x float> %2344, <4 x float> %2346, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2396

2348:                                             ; preds = %2330
  %2349 = icmp slt i64 %2115, %25
  %2350 = select i1 %2349, i64 %2115, i64 0
  %2351 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2350
  %2352 = load float, ptr addrspace(1) %2351, align 4
  %2353 = insertelement <8 x float> poison, float %2352, i64 0
  %2354 = or disjoint i64 %61, %516
  %2355 = icmp slt i64 %2354, %25
  %2356 = select i1 %2355, i64 %2354, i64 0
  %2357 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2356
  %2358 = load float, ptr addrspace(1) %2357, align 4
  %2359 = insertelement <8 x float> %2353, float %2358, i64 1
  %2360 = or disjoint i64 %61, %523
  %2361 = icmp slt i64 %2360, %25
  %2362 = select i1 %2361, i64 %2360, i64 0
  %2363 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2362
  %2364 = load float, ptr addrspace(1) %2363, align 4
  %2365 = insertelement <8 x float> %2359, float %2364, i64 2
  %2366 = or disjoint i64 %61, %530
  %2367 = icmp slt i64 %2366, %25
  %2368 = select i1 %2367, i64 %2366, i64 0
  %2369 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2368
  %2370 = load float, ptr addrspace(1) %2369, align 4
  %2371 = insertelement <8 x float> %2365, float %2370, i64 3
  %2372 = or disjoint i64 %61, %537
  %2373 = icmp slt i64 %2372, %25
  %2374 = select i1 %2373, i64 %2372, i64 0
  %2375 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2374
  %2376 = load float, ptr addrspace(1) %2375, align 4
  %2377 = insertelement <8 x float> %2371, float %2376, i64 4
  %2378 = or disjoint i64 %61, %544
  %2379 = icmp slt i64 %2378, %25
  %2380 = select i1 %2379, i64 %2378, i64 0
  %2381 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2380
  %2382 = load float, ptr addrspace(1) %2381, align 4
  %2383 = insertelement <8 x float> %2377, float %2382, i64 5
  %2384 = or disjoint i64 %61, %551
  %2385 = icmp slt i64 %2384, %25
  %2386 = select i1 %2385, i64 %2384, i64 0
  %2387 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2386
  %2388 = load float, ptr addrspace(1) %2387, align 4
  %2389 = insertelement <8 x float> %2383, float %2388, i64 6
  %2390 = or disjoint i64 %61, %558
  %2391 = icmp slt i64 %2390, %25
  %2392 = select i1 %2391, i64 %2390, i64 0
  %2393 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2392
  %2394 = load float, ptr addrspace(1) %2393, align 4
  %2395 = insertelement <8 x float> %2389, float %2394, i64 7
  br label %2396

2396:                                             ; preds = %2342, %2348
  %2397 = phi <8 x float> [ %2395, %2348 ], [ %2347, %2342 ]
  %2398 = extractelement <8 x float> %2397, i64 0
  %2399 = load i8, ptr addrspace(1) %629, align 1
  %2400 = zext i8 %2399 to i32
  %2401 = shl nuw nsw i32 %2400, 23
  %2402 = bitcast i32 %2401 to float
  %2403 = fmul float %2398, %2402
  %2404 = extractelement <8 x float> %282, i64 0
  %2405 = fmul float %2404, %2403
  %2406 = tail call i1 @llvm.is.fpclass.f32(float %2403, /* (sub norm) */ i32 408)
  br i1 %2406, label %2419, label %2407, !prof !4

2407:                                             ; preds = %2396
  %2408 = fpext float %2404 to double
  %2409 = fpext nnan float %2402 to double
  %2410 = fpext float %2398 to double
  %2411 = fmul double %2408, %2409
  %2412 = fmul double %2411, %2410
  %2413 = fptrunc double %2412 to float
  %2414 = fcmp oeq float %2404, 0.000000e+00
  %2415 = tail call float @llvm.fabs.f32(float %2398)
  %2416 = fcmp one float %2415, +inf
  %2417 = and i1 %2414, %2416
  %2418 = select i1 %2417, float 0.000000e+00, float %2413
  br label %2419

2419:                                             ; preds = %2407, %2396
  %2420 = phi float [ %2418, %2407 ], [ %2405, %2396 ]
  %2421 = extractelement <8 x float> %2397, i64 1
  %2422 = fmul float %2421, %2402
  %2423 = extractelement <8 x float> %282, i64 1
  %2424 = fmul float %2423, %2422
  %2425 = tail call i1 @llvm.is.fpclass.f32(float %2422, /* (sub norm) */ i32 408)
  br i1 %2425, label %2438, label %2426, !prof !4

2426:                                             ; preds = %2419
  %2427 = fpext float %2423 to double
  %2428 = fpext nnan float %2402 to double
  %2429 = fpext float %2421 to double
  %2430 = fmul double %2427, %2428
  %2431 = fmul double %2430, %2429
  %2432 = fptrunc double %2431 to float
  %2433 = fcmp oeq float %2423, 0.000000e+00
  %2434 = tail call float @llvm.fabs.f32(float %2421)
  %2435 = fcmp one float %2434, +inf
  %2436 = and i1 %2433, %2435
  %2437 = select i1 %2436, float 0.000000e+00, float %2432
  br label %2438

2438:                                             ; preds = %2426, %2419
  %2439 = phi float [ %2437, %2426 ], [ %2424, %2419 ]
  %2440 = extractelement <8 x float> %2397, i64 2
  %2441 = fmul float %2440, %2402
  %2442 = extractelement <8 x float> %282, i64 2
  %2443 = fmul float %2442, %2441
  %2444 = tail call i1 @llvm.is.fpclass.f32(float %2441, /* (sub norm) */ i32 408)
  br i1 %2444, label %2457, label %2445, !prof !4

2445:                                             ; preds = %2438
  %2446 = fpext float %2442 to double
  %2447 = fpext nnan float %2402 to double
  %2448 = fpext float %2440 to double
  %2449 = fmul double %2446, %2447
  %2450 = fmul double %2449, %2448
  %2451 = fptrunc double %2450 to float
  %2452 = fcmp oeq float %2442, 0.000000e+00
  %2453 = tail call float @llvm.fabs.f32(float %2440)
  %2454 = fcmp one float %2453, +inf
  %2455 = and i1 %2452, %2454
  %2456 = select i1 %2455, float 0.000000e+00, float %2451
  br label %2457

2457:                                             ; preds = %2445, %2438
  %2458 = phi float [ %2456, %2445 ], [ %2443, %2438 ]
  %2459 = extractelement <8 x float> %2397, i64 3
  %2460 = fmul float %2459, %2402
  %2461 = extractelement <8 x float> %282, i64 3
  %2462 = fmul float %2461, %2460
  %2463 = tail call i1 @llvm.is.fpclass.f32(float %2460, /* (sub norm) */ i32 408)
  br i1 %2463, label %2476, label %2464, !prof !4

2464:                                             ; preds = %2457
  %2465 = fpext float %2461 to double
  %2466 = fpext nnan float %2402 to double
  %2467 = fpext float %2459 to double
  %2468 = fmul double %2465, %2466
  %2469 = fmul double %2468, %2467
  %2470 = fptrunc double %2469 to float
  %2471 = fcmp oeq float %2461, 0.000000e+00
  %2472 = tail call float @llvm.fabs.f32(float %2459)
  %2473 = fcmp one float %2472, +inf
  %2474 = and i1 %2471, %2473
  %2475 = select i1 %2474, float 0.000000e+00, float %2470
  br label %2476

2476:                                             ; preds = %2464, %2457
  %2477 = phi float [ %2475, %2464 ], [ %2462, %2457 ]
  %2478 = extractelement <8 x float> %2397, i64 4
  %2479 = fmul float %2478, %2402
  %2480 = extractelement <8 x float> %282, i64 4
  %2481 = fmul float %2480, %2479
  %2482 = tail call i1 @llvm.is.fpclass.f32(float %2479, /* (sub norm) */ i32 408)
  br i1 %2482, label %2495, label %2483, !prof !4

2483:                                             ; preds = %2476
  %2484 = fpext float %2480 to double
  %2485 = fpext nnan float %2402 to double
  %2486 = fpext float %2478 to double
  %2487 = fmul double %2484, %2485
  %2488 = fmul double %2487, %2486
  %2489 = fptrunc double %2488 to float
  %2490 = fcmp oeq float %2480, 0.000000e+00
  %2491 = tail call float @llvm.fabs.f32(float %2478)
  %2492 = fcmp one float %2491, +inf
  %2493 = and i1 %2490, %2492
  %2494 = select i1 %2493, float 0.000000e+00, float %2489
  br label %2495

2495:                                             ; preds = %2483, %2476
  %2496 = phi float [ %2494, %2483 ], [ %2481, %2476 ]
  %2497 = extractelement <8 x float> %2397, i64 5
  %2498 = fmul float %2497, %2402
  %2499 = extractelement <8 x float> %282, i64 5
  %2500 = fmul float %2499, %2498
  %2501 = tail call i1 @llvm.is.fpclass.f32(float %2498, /* (sub norm) */ i32 408)
  br i1 %2501, label %2514, label %2502, !prof !4

2502:                                             ; preds = %2495
  %2503 = fpext float %2499 to double
  %2504 = fpext nnan float %2402 to double
  %2505 = fpext float %2497 to double
  %2506 = fmul double %2503, %2504
  %2507 = fmul double %2506, %2505
  %2508 = fptrunc double %2507 to float
  %2509 = fcmp oeq float %2499, 0.000000e+00
  %2510 = tail call float @llvm.fabs.f32(float %2497)
  %2511 = fcmp one float %2510, +inf
  %2512 = and i1 %2509, %2511
  %2513 = select i1 %2512, float 0.000000e+00, float %2508
  br label %2514

2514:                                             ; preds = %2502, %2495
  %2515 = phi float [ %2513, %2502 ], [ %2500, %2495 ]
  %2516 = extractelement <8 x float> %2397, i64 6
  %2517 = fmul float %2516, %2402
  %2518 = extractelement <8 x float> %282, i64 6
  %2519 = fmul float %2518, %2517
  %2520 = tail call i1 @llvm.is.fpclass.f32(float %2517, /* (sub norm) */ i32 408)
  br i1 %2520, label %2533, label %2521, !prof !4

2521:                                             ; preds = %2514
  %2522 = fpext float %2518 to double
  %2523 = fpext nnan float %2402 to double
  %2524 = fpext float %2516 to double
  %2525 = fmul double %2522, %2523
  %2526 = fmul double %2525, %2524
  %2527 = fptrunc double %2526 to float
  %2528 = fcmp oeq float %2518, 0.000000e+00
  %2529 = tail call float @llvm.fabs.f32(float %2516)
  %2530 = fcmp one float %2529, +inf
  %2531 = and i1 %2528, %2530
  %2532 = select i1 %2531, float 0.000000e+00, float %2527
  br label %2533

2533:                                             ; preds = %2521, %2514
  %2534 = phi float [ %2532, %2521 ], [ %2519, %2514 ]
  %2535 = extractelement <8 x float> %2397, i64 7
  %2536 = fmul float %2535, %2402
  %2537 = extractelement <8 x float> %282, i64 7
  %2538 = fmul float %2537, %2536
  %2539 = tail call i1 @llvm.is.fpclass.f32(float %2536, /* (sub norm) */ i32 408)
  br i1 %2539, label %2552, label %2540, !prof !4

2540:                                             ; preds = %2533
  %2541 = fpext float %2537 to double
  %2542 = fpext nnan float %2402 to double
  %2543 = fpext float %2535 to double
  %2544 = fmul double %2541, %2542
  %2545 = fmul double %2544, %2543
  %2546 = fptrunc double %2545 to float
  %2547 = fcmp oeq float %2537, 0.000000e+00
  %2548 = tail call float @llvm.fabs.f32(float %2535)
  %2549 = fcmp one float %2548, +inf
  %2550 = and i1 %2547, %2549
  %2551 = select i1 %2550, float 0.000000e+00, float %2546
  br label %2552

2552:                                             ; preds = %2540, %2533
  %2553 = phi float [ %2551, %2540 ], [ %2538, %2533 ]
  %2554 = fptrunc float %2420 to bfloat
  store bfloat %2554, ptr addrspace(3) %789, align 2
  %2555 = fptrunc float %2439 to bfloat
  store bfloat %2555, ptr addrspace(3) %793, align 2
  %2556 = fptrunc float %2458 to bfloat
  store bfloat %2556, ptr addrspace(3) %797, align 2
  %2557 = fptrunc float %2477 to bfloat
  store bfloat %2557, ptr addrspace(3) %801, align 2
  %2558 = fptrunc float %2496 to bfloat
  store bfloat %2558, ptr addrspace(3) %805, align 2
  %2559 = fptrunc float %2515 to bfloat
  store bfloat %2559, ptr addrspace(3) %809, align 2
  %2560 = fptrunc float %2534 to bfloat
  store bfloat %2560, ptr addrspace(3) %813, align 2
  %2561 = fptrunc float %2553 to bfloat
  store bfloat %2561, ptr addrspace(3) %817, align 2
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %2562 = or disjoint i64 %820, %60
  %2563 = or disjoint i64 %2562, %51
  %2564 = load <8 x bfloat>, ptr addrspace(3) %830, align 16
  %2565 = mul i64 %2563, %26
  %2566 = add i64 %2565, %826
  %2567 = icmp ult i64 %2563, %25
  %2568 = and i1 %2567, %836
  br i1 %2568, label %2569, label %2571

2569:                                             ; preds = %2552
  %2570 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2566
  store <8 x bfloat> %2564, ptr addrspace(1) %2570, align 2
  br label %2625

2571:                                             ; preds = %2552
  %2572 = icmp ult i64 %826, %26
  %2573 = and i1 %2567, %2572
  br i1 %2573, label %2574, label %2577

2574:                                             ; preds = %2571
  %2575 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2566
  %2576 = extractelement <8 x bfloat> %2564, i64 0
  store bfloat %2576, ptr addrspace(1) %2575, align 2
  br label %2577

2577:                                             ; preds = %2574, %2571
  %2578 = or disjoint i64 %826, 1
  %2579 = icmp ult i64 %2578, %26
  %2580 = and i1 %2567, %2579
  br i1 %2580, label %2581, label %2585

2581:                                             ; preds = %2577
  %2582 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2566
  %2583 = getelementptr i8, ptr addrspace(1) %2582, i64 2
  %2584 = extractelement <8 x bfloat> %2564, i64 1
  store bfloat %2584, ptr addrspace(1) %2583, align 2
  br label %2585

2585:                                             ; preds = %2581, %2577
  %2586 = or disjoint i64 %826, 2
  %2587 = icmp ult i64 %2586, %26
  %2588 = and i1 %2567, %2587
  br i1 %2588, label %2589, label %2593

2589:                                             ; preds = %2585
  %2590 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2566
  %2591 = getelementptr i8, ptr addrspace(1) %2590, i64 4
  %2592 = extractelement <8 x bfloat> %2564, i64 2
  store bfloat %2592, ptr addrspace(1) %2591, align 2
  br label %2593

2593:                                             ; preds = %2589, %2585
  %2594 = or disjoint i64 %826, 3
  %2595 = icmp ult i64 %2594, %26
  %2596 = and i1 %2567, %2595
  br i1 %2596, label %2597, label %2601

2597:                                             ; preds = %2593
  %2598 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2566
  %2599 = getelementptr i8, ptr addrspace(1) %2598, i64 6
  %2600 = extractelement <8 x bfloat> %2564, i64 3
  store bfloat %2600, ptr addrspace(1) %2599, align 2
  br label %2601

2601:                                             ; preds = %2597, %2593
  %2602 = or disjoint i64 %826, 4
  %2603 = icmp ult i64 %2602, %26
  %2604 = and i1 %2567, %2603
  br i1 %2604, label %2605, label %2609

2605:                                             ; preds = %2601
  %2606 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2566
  %2607 = getelementptr i8, ptr addrspace(1) %2606, i64 8
  %2608 = extractelement <8 x bfloat> %2564, i64 4
  store bfloat %2608, ptr addrspace(1) %2607, align 2
  br label %2609

2609:                                             ; preds = %2605, %2601
  %2610 = or disjoint i64 %826, 5
  %2611 = icmp ult i64 %2610, %26
  %2612 = and i1 %2567, %2611
  br i1 %2612, label %2613, label %2617

2613:                                             ; preds = %2609
  %2614 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2566
  %2615 = getelementptr i8, ptr addrspace(1) %2614, i64 10
  %2616 = extractelement <8 x bfloat> %2564, i64 5
  store bfloat %2616, ptr addrspace(1) %2615, align 2
  br label %2617

2617:                                             ; preds = %2613, %2609
  %2618 = or disjoint i64 %826, 6
  %2619 = icmp ult i64 %2618, %26
  %2620 = and i1 %2567, %2619
  br i1 %2620, label %2621, label %2625

2621:                                             ; preds = %2617
  %2622 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2566
  %2623 = getelementptr i8, ptr addrspace(1) %2622, i64 12
  %2624 = extractelement <8 x bfloat> %2564, i64 6
  store bfloat %2624, ptr addrspace(1) %2623, align 2
  br label %2625

2625:                                             ; preds = %2617, %2621, %2569
  %2626 = or disjoint i64 %895, %60
  %2627 = or disjoint i64 %2626, %51
  %2628 = load <8 x bfloat>, ptr addrspace(3) %902, align 16
  %2629 = mul i64 %2627, %26
  %2630 = add i64 %2629, %826
  %2631 = icmp ult i64 %2627, %25
  %2632 = and i1 %2631, %836
  br i1 %2632, label %2633, label %2635

2633:                                             ; preds = %2625
  %2634 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2630
  store <8 x bfloat> %2628, ptr addrspace(1) %2634, align 2
  br label %2689

2635:                                             ; preds = %2625
  %2636 = icmp ult i64 %826, %26
  %2637 = and i1 %2631, %2636
  br i1 %2637, label %2638, label %2641

2638:                                             ; preds = %2635
  %2639 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2630
  %2640 = extractelement <8 x bfloat> %2628, i64 0
  store bfloat %2640, ptr addrspace(1) %2639, align 2
  br label %2641

2641:                                             ; preds = %2638, %2635
  %2642 = or disjoint i64 %826, 1
  %2643 = icmp ult i64 %2642, %26
  %2644 = and i1 %2631, %2643
  br i1 %2644, label %2645, label %2649

2645:                                             ; preds = %2641
  %2646 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2630
  %2647 = getelementptr i8, ptr addrspace(1) %2646, i64 2
  %2648 = extractelement <8 x bfloat> %2628, i64 1
  store bfloat %2648, ptr addrspace(1) %2647, align 2
  br label %2649

2649:                                             ; preds = %2645, %2641
  %2650 = or disjoint i64 %826, 2
  %2651 = icmp ult i64 %2650, %26
  %2652 = and i1 %2631, %2651
  br i1 %2652, label %2653, label %2657

2653:                                             ; preds = %2649
  %2654 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2630
  %2655 = getelementptr i8, ptr addrspace(1) %2654, i64 4
  %2656 = extractelement <8 x bfloat> %2628, i64 2
  store bfloat %2656, ptr addrspace(1) %2655, align 2
  br label %2657

2657:                                             ; preds = %2653, %2649
  %2658 = or disjoint i64 %826, 3
  %2659 = icmp ult i64 %2658, %26
  %2660 = and i1 %2631, %2659
  br i1 %2660, label %2661, label %2665

2661:                                             ; preds = %2657
  %2662 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2630
  %2663 = getelementptr i8, ptr addrspace(1) %2662, i64 6
  %2664 = extractelement <8 x bfloat> %2628, i64 3
  store bfloat %2664, ptr addrspace(1) %2663, align 2
  br label %2665

2665:                                             ; preds = %2661, %2657
  %2666 = or disjoint i64 %826, 4
  %2667 = icmp ult i64 %2666, %26
  %2668 = and i1 %2631, %2667
  br i1 %2668, label %2669, label %2673

2669:                                             ; preds = %2665
  %2670 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2630
  %2671 = getelementptr i8, ptr addrspace(1) %2670, i64 8
  %2672 = extractelement <8 x bfloat> %2628, i64 4
  store bfloat %2672, ptr addrspace(1) %2671, align 2
  br label %2673

2673:                                             ; preds = %2669, %2665
  %2674 = or disjoint i64 %826, 5
  %2675 = icmp ult i64 %2674, %26
  %2676 = and i1 %2631, %2675
  br i1 %2676, label %2677, label %2681

2677:                                             ; preds = %2673
  %2678 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2630
  %2679 = getelementptr i8, ptr addrspace(1) %2678, i64 10
  %2680 = extractelement <8 x bfloat> %2628, i64 5
  store bfloat %2680, ptr addrspace(1) %2679, align 2
  br label %2681

2681:                                             ; preds = %2677, %2673
  %2682 = or disjoint i64 %826, 6
  %2683 = icmp ult i64 %2682, %26
  %2684 = and i1 %2631, %2683
  br i1 %2684, label %2685, label %2689

2685:                                             ; preds = %2681
  %2686 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2630
  %2687 = getelementptr i8, ptr addrspace(1) %2686, i64 12
  %2688 = extractelement <8 x bfloat> %2628, i64 6
  store bfloat %2688, ptr addrspace(1) %2687, align 2
  br label %2689

2689:                                             ; preds = %2681, %2685, %2633
  fence syncscope("wavefront") release
  tail call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.wave.barrier() #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.is.fpclass.f32(float, i32 immarg) #6

attributes #0 = { norecurse nounwind "amdgpu-flat-work-group-size"="256,256" "amdgpu-no-cluster-id-x" "amdgpu-no-cluster-id-y" "amdgpu-no-cluster-id-z" "amdgpu-no-completion-action" "amdgpu-no-default-queue" "amdgpu-no-dispatch-id" "amdgpu-no-dispatch-ptr" "amdgpu-no-flat-scratch-init" "amdgpu-no-heap-ptr" "amdgpu-no-hostcall-ptr" "amdgpu-no-implicitarg-ptr" "amdgpu-no-lds-kernel-id" "amdgpu-no-multigrid-sync-arg" "amdgpu-no-queue-ptr" "amdgpu-no-workgroup-id-x" "amdgpu-no-workgroup-id-y" "amdgpu-no-workgroup-id-z" "amdgpu-no-workitem-id-x" "amdgpu-no-workitem-id-y" "amdgpu-no-workitem-id-z" "amdgpu-no-wwm" "target-cpu"="gfx1201" "target-features"="-cumode,+wavefrontsize32,-wavefrontsize64" "uniform-work-group-size" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #3 = { convergent mustprogress nocallback nofree nounwind willreturn "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #4 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #5 = { convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
!3 = !{}
!4 = !{!"branch_weights", !"expected", i32 2000, i32 1}
