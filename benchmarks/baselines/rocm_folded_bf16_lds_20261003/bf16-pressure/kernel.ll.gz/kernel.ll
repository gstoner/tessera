; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal addrspace(3) global [5120 x i8] undef

define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) #0 !reqd_work_group_size !1 {
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %20, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, ptr %21, 1
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, i64 %22, 2
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %23, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %24, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, ptr %16, 1
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 %17, 2
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 %18, 3, 0
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %19, 4, 0
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %10, 0
  %40 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, ptr %11, 1
  %41 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, i64 %12, 2
  %42 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %41, i64 %13, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %42, i64 %14, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %45 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %44, ptr %6, 1
  %46 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %45, i64 %7, 2
  %47 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, i64 %8, 3, 0
  %48 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, i64 %9, 4, 0
  %49 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %50 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %49, ptr %1, 1
  %51 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %50, i64 %2, 2
  %52 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %51, i64 %3, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %52, i64 %4, 4, 0
  %54 = call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %55 = sext i32 %54 to i64
  %56 = urem i64 %55, 32
  %57 = urem i64 %56, 16
  %58 = udiv i64 %56, 16
  %59 = udiv i64 %55, 32
  %60 = udiv i64 %59, 2
  %61 = urem i64 %59, 2
  %62 = call i32 @llvm.amdgcn.workgroup.id.x()
  %63 = sext i32 %62 to i64
  %64 = add i64 %25, 255
  %65 = udiv i64 %64, 256
  %66 = add i64 %26, 63
  %67 = udiv i64 %66, 64
  %68 = mul i64 %67, 4
  %69 = udiv i64 %63, %68
  %70 = mul i64 %69, 4
  %71 = sub i64 %65, %70
  %72 = icmp ult i64 %71, 4
  %73 = select i1 %72, i64 %71, i64 4
  %74 = urem i64 %63, %68
  %75 = urem i64 %74, %73
  %76 = add i64 %70, %75
  %77 = udiv i64 %74, %73
  %78 = mul i64 %76, 256
  %79 = mul i64 %77, 64
  %80 = mul i64 %60, 64
  %81 = mul i64 %61, 32
  %82 = add i64 %78, %80
  %83 = add i64 %80, 16
  %84 = add i64 %78, %83
  %85 = add i64 %80, 32
  %86 = add i64 %78, %85
  %87 = add i64 %80, 48
  %88 = add i64 %78, %87
  %89 = add i64 %79, %81
  %90 = add i64 %81, 16
  %91 = add i64 %79, %90
  %92 = udiv i64 %55, 4
  %93 = urem i64 %55, 4
  %94 = mul i64 %93, 16
  %95 = add i64 %78, %92
  %96 = mul i64 %95, %27
  %97 = add i64 %96, %94
  %98 = mul i64 %92, 80
  %99 = add i64 %98, %94
  %100 = add i64 %55, 256
  %101 = udiv i64 %100, 4
  %102 = urem i64 %100, 4
  %103 = mul i64 %102, 16
  %104 = add i64 %78, %101
  %105 = mul i64 %104, %27
  %106 = add i64 %105, %103
  %107 = mul i64 %101, 80
  %108 = add i64 %107, %103
  %109 = add i64 %55, 512
  %110 = udiv i64 %109, 4
  %111 = urem i64 %109, 4
  %112 = mul i64 %111, 16
  %113 = add i64 %78, %110
  %114 = mul i64 %113, %27
  %115 = add i64 %114, %112
  %116 = mul i64 %110, 80
  %117 = add i64 %116, %112
  %118 = add i64 %55, 768
  %119 = udiv i64 %118, 4
  %120 = urem i64 %118, 4
  %121 = mul i64 %120, 16
  %122 = add i64 %78, %119
  %123 = mul i64 %122, %27
  %124 = add i64 %123, %121
  %125 = mul i64 %119, 80
  %126 = add i64 %125, %121
  %127 = udiv i64 %55, 4
  %128 = urem i64 %55, 4
  %129 = mul i64 %128, 16
  %130 = add i64 %79, %127
  %131 = mul i64 %130, %27
  %132 = add i64 %131, %129
  %133 = mul i64 %127, 80
  %134 = add i64 %133, %129
  %135 = icmp uge i64 %27, 64
  call void @llvm.assume(i1 %135)
  %136 = udiv i64 %27, 64
  %137 = sub i64 %27, 64
  %138 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %139 = getelementptr i8, ptr %138, i64 %97
  %140 = load <16 x i8>, ptr %139, align 16
  %141 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %142 = getelementptr i8, ptr %141, i64 %106
  %143 = load <16 x i8>, ptr %142, align 16
  %144 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %145 = getelementptr i8, ptr %144, i64 %115
  %146 = load <16 x i8>, ptr %145, align 16
  %147 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %148 = getelementptr i8, ptr %147, i64 %124
  %149 = load <16 x i8>, ptr %148, align 16
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %140, ptr addrspace(3) %150, align 16
  %151 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %143, ptr addrspace(3) %151, align 16
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %146, ptr addrspace(3) %152, align 16
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %149, ptr addrspace(3) %153, align 16
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %155 = getelementptr i8, ptr %154, i64 %132
  %156 = load <16 x i8>, ptr %155, align 16
  %157 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %156, ptr addrspace(3) %157, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  br label %158

158:                                              ; preds = %169, %28
  %159 = phi i64 [ %416, %169 ], [ 0, %28 ]
  %160 = phi <8 x float> [ %403, %169 ], [ zeroinitializer, %28 ]
  %161 = phi <8 x float> [ %404, %169 ], [ zeroinitializer, %28 ]
  %162 = phi <8 x float> [ %405, %169 ], [ zeroinitializer, %28 ]
  %163 = phi <8 x float> [ %406, %169 ], [ zeroinitializer, %28 ]
  %164 = phi <8 x float> [ %407, %169 ], [ zeroinitializer, %28 ]
  %165 = phi <8 x float> [ %408, %169 ], [ zeroinitializer, %28 ]
  %166 = phi <8 x float> [ %409, %169 ], [ zeroinitializer, %28 ]
  %167 = phi <8 x float> [ %410, %169 ], [ zeroinitializer, %28 ]
  %168 = icmp slt i64 %159, %136
  br i1 %168, label %169, label %417

169:                                              ; preds = %158
  %170 = mul i64 %159, 64
  %171 = add i64 %170, 64
  %172 = call i64 @llvm.umin.i64(i64 %171, i64 %137)
  %173 = add i64 %97, %172
  %174 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %175 = getelementptr i8, ptr %174, i64 %173
  %176 = load <16 x i8>, ptr %175, align 16
  %177 = add i64 %106, %172
  %178 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %179 = getelementptr i8, ptr %178, i64 %177
  %180 = load <16 x i8>, ptr %179, align 16
  %181 = add i64 %115, %172
  %182 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %183 = getelementptr i8, ptr %182, i64 %181
  %184 = load <16 x i8>, ptr %183, align 16
  %185 = add i64 %124, %172
  %186 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %187 = getelementptr i8, ptr %186, i64 %185
  %188 = load <16 x i8>, ptr %187, align 16
  %189 = add i64 %132, %172
  %190 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %191 = getelementptr i8, ptr %190, i64 %189
  %192 = load <16 x i8>, ptr %191, align 16
  %193 = mul i64 %58, 8
  %194 = add i64 %80, %57
  %195 = mul i64 %194, 80
  %196 = add i64 %195, %193
  %197 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %196
  %198 = load <8 x i8>, ptr addrspace(3) %197, align 1
  %199 = bitcast <8 x i8> %198 to <2 x i32>
  %200 = mul i64 %58, 8
  %201 = add i64 %83, %57
  %202 = mul i64 %201, 80
  %203 = add i64 %202, %200
  %204 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %203
  %205 = load <8 x i8>, ptr addrspace(3) %204, align 1
  %206 = bitcast <8 x i8> %205 to <2 x i32>
  %207 = mul i64 %58, 8
  %208 = add i64 %85, %57
  %209 = mul i64 %208, 80
  %210 = add i64 %209, %207
  %211 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %210
  %212 = load <8 x i8>, ptr addrspace(3) %211, align 1
  %213 = bitcast <8 x i8> %212 to <2 x i32>
  %214 = mul i64 %58, 8
  %215 = add i64 %87, %57
  %216 = mul i64 %215, 80
  %217 = add i64 %216, %214
  %218 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %217
  %219 = load <8 x i8>, ptr addrspace(3) %218, align 1
  %220 = bitcast <8 x i8> %219 to <2 x i32>
  %221 = mul i64 %58, 8
  %222 = add i64 %81, %57
  %223 = mul i64 %222, 80
  %224 = add i64 %223, %221
  %225 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %224
  %226 = load <8 x i8>, ptr addrspace(3) %225, align 1
  %227 = bitcast <8 x i8> %226 to <2 x i32>
  %228 = mul i64 %58, 8
  %229 = add i64 %90, %57
  %230 = mul i64 %229, 80
  %231 = add i64 %230, %228
  %232 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %231
  %233 = load <8 x i8>, ptr addrspace(3) %232, align 1
  %234 = bitcast <8 x i8> %233 to <2 x i32>
  %235 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %227, <8 x float> %160)
  %236 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %234, <8 x float> %161)
  %237 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %227, <8 x float> %162)
  %238 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %234, <8 x float> %163)
  %239 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %227, <8 x float> %164)
  %240 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %234, <8 x float> %165)
  %241 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %227, <8 x float> %166)
  %242 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %234, <8 x float> %167)
  %243 = mul i64 %58, 8
  %244 = add i64 %80, %57
  %245 = add i64 %243, 16
  %246 = mul i64 %244, 80
  %247 = add i64 %246, %245
  %248 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %247
  %249 = load <8 x i8>, ptr addrspace(3) %248, align 1
  %250 = bitcast <8 x i8> %249 to <2 x i32>
  %251 = mul i64 %58, 8
  %252 = add i64 %83, %57
  %253 = add i64 %251, 16
  %254 = mul i64 %252, 80
  %255 = add i64 %254, %253
  %256 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %255
  %257 = load <8 x i8>, ptr addrspace(3) %256, align 1
  %258 = bitcast <8 x i8> %257 to <2 x i32>
  %259 = mul i64 %58, 8
  %260 = add i64 %85, %57
  %261 = add i64 %259, 16
  %262 = mul i64 %260, 80
  %263 = add i64 %262, %261
  %264 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %263
  %265 = load <8 x i8>, ptr addrspace(3) %264, align 1
  %266 = bitcast <8 x i8> %265 to <2 x i32>
  %267 = mul i64 %58, 8
  %268 = add i64 %87, %57
  %269 = add i64 %267, 16
  %270 = mul i64 %268, 80
  %271 = add i64 %270, %269
  %272 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %271
  %273 = load <8 x i8>, ptr addrspace(3) %272, align 1
  %274 = bitcast <8 x i8> %273 to <2 x i32>
  %275 = mul i64 %58, 8
  %276 = add i64 %275, 16
  %277 = add i64 %81, %57
  %278 = mul i64 %277, 80
  %279 = add i64 %278, %276
  %280 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %279
  %281 = load <8 x i8>, ptr addrspace(3) %280, align 1
  %282 = bitcast <8 x i8> %281 to <2 x i32>
  %283 = mul i64 %58, 8
  %284 = add i64 %283, 16
  %285 = add i64 %90, %57
  %286 = mul i64 %285, 80
  %287 = add i64 %286, %284
  %288 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %287
  %289 = load <8 x i8>, ptr addrspace(3) %288, align 1
  %290 = bitcast <8 x i8> %289 to <2 x i32>
  %291 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %282, <8 x float> %235)
  %292 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %290, <8 x float> %236)
  %293 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %282, <8 x float> %237)
  %294 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %290, <8 x float> %238)
  %295 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %282, <8 x float> %239)
  %296 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %290, <8 x float> %240)
  %297 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %282, <8 x float> %241)
  %298 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %290, <8 x float> %242)
  %299 = mul i64 %58, 8
  %300 = add i64 %80, %57
  %301 = add i64 %299, 32
  %302 = mul i64 %300, 80
  %303 = add i64 %302, %301
  %304 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %303
  %305 = load <8 x i8>, ptr addrspace(3) %304, align 1
  %306 = bitcast <8 x i8> %305 to <2 x i32>
  %307 = mul i64 %58, 8
  %308 = add i64 %83, %57
  %309 = add i64 %307, 32
  %310 = mul i64 %308, 80
  %311 = add i64 %310, %309
  %312 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %311
  %313 = load <8 x i8>, ptr addrspace(3) %312, align 1
  %314 = bitcast <8 x i8> %313 to <2 x i32>
  %315 = mul i64 %58, 8
  %316 = add i64 %85, %57
  %317 = add i64 %315, 32
  %318 = mul i64 %316, 80
  %319 = add i64 %318, %317
  %320 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %319
  %321 = load <8 x i8>, ptr addrspace(3) %320, align 1
  %322 = bitcast <8 x i8> %321 to <2 x i32>
  %323 = mul i64 %58, 8
  %324 = add i64 %87, %57
  %325 = add i64 %323, 32
  %326 = mul i64 %324, 80
  %327 = add i64 %326, %325
  %328 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %327
  %329 = load <8 x i8>, ptr addrspace(3) %328, align 1
  %330 = bitcast <8 x i8> %329 to <2 x i32>
  %331 = mul i64 %58, 8
  %332 = add i64 %331, 32
  %333 = add i64 %81, %57
  %334 = mul i64 %333, 80
  %335 = add i64 %334, %332
  %336 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %335
  %337 = load <8 x i8>, ptr addrspace(3) %336, align 1
  %338 = bitcast <8 x i8> %337 to <2 x i32>
  %339 = mul i64 %58, 8
  %340 = add i64 %339, 32
  %341 = add i64 %90, %57
  %342 = mul i64 %341, 80
  %343 = add i64 %342, %340
  %344 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %343
  %345 = load <8 x i8>, ptr addrspace(3) %344, align 1
  %346 = bitcast <8 x i8> %345 to <2 x i32>
  %347 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %338, <8 x float> %291)
  %348 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %346, <8 x float> %292)
  %349 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %338, <8 x float> %293)
  %350 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %346, <8 x float> %294)
  %351 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %338, <8 x float> %295)
  %352 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %346, <8 x float> %296)
  %353 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %338, <8 x float> %297)
  %354 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %346, <8 x float> %298)
  %355 = mul i64 %58, 8
  %356 = add i64 %80, %57
  %357 = add i64 %355, 48
  %358 = mul i64 %356, 80
  %359 = add i64 %358, %357
  %360 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %359
  %361 = load <8 x i8>, ptr addrspace(3) %360, align 1
  %362 = bitcast <8 x i8> %361 to <2 x i32>
  %363 = mul i64 %58, 8
  %364 = add i64 %83, %57
  %365 = add i64 %363, 48
  %366 = mul i64 %364, 80
  %367 = add i64 %366, %365
  %368 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %367
  %369 = load <8 x i8>, ptr addrspace(3) %368, align 1
  %370 = bitcast <8 x i8> %369 to <2 x i32>
  %371 = mul i64 %58, 8
  %372 = add i64 %85, %57
  %373 = add i64 %371, 48
  %374 = mul i64 %372, 80
  %375 = add i64 %374, %373
  %376 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %375
  %377 = load <8 x i8>, ptr addrspace(3) %376, align 1
  %378 = bitcast <8 x i8> %377 to <2 x i32>
  %379 = mul i64 %58, 8
  %380 = add i64 %87, %57
  %381 = add i64 %379, 48
  %382 = mul i64 %380, 80
  %383 = add i64 %382, %381
  %384 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %383
  %385 = load <8 x i8>, ptr addrspace(3) %384, align 1
  %386 = bitcast <8 x i8> %385 to <2 x i32>
  %387 = mul i64 %58, 8
  %388 = add i64 %387, 48
  %389 = add i64 %81, %57
  %390 = mul i64 %389, 80
  %391 = add i64 %390, %388
  %392 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %391
  %393 = load <8 x i8>, ptr addrspace(3) %392, align 1
  %394 = bitcast <8 x i8> %393 to <2 x i32>
  %395 = mul i64 %58, 8
  %396 = add i64 %395, 48
  %397 = add i64 %90, %57
  %398 = mul i64 %397, 80
  %399 = add i64 %398, %396
  %400 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %399
  %401 = load <8 x i8>, ptr addrspace(3) %400, align 1
  %402 = bitcast <8 x i8> %401 to <2 x i32>
  %403 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %394, <8 x float> %347)
  %404 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %402, <8 x float> %348)
  %405 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %394, <8 x float> %349)
  %406 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %402, <8 x float> %350)
  %407 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %394, <8 x float> %351)
  %408 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %402, <8 x float> %352)
  %409 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %394, <8 x float> %353)
  %410 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %402, <8 x float> %354)
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %411 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %176, ptr addrspace(3) %411, align 16
  %412 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %180, ptr addrspace(3) %412, align 16
  %413 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %184, ptr addrspace(3) %413, align 16
  %414 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %188, ptr addrspace(3) %414, align 16
  %415 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %192, ptr addrspace(3) %415, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %416 = add i64 %159, 1
  br label %158

417:                                              ; preds = %158
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %418 = mul i64 %58, 8
  %419 = add i64 %82, %418
  %420 = add i64 %89, %57
  %421 = add i64 %419, 7
  %422 = icmp ult i64 %420, %26
  %423 = icmp ult i64 %421, %25
  %424 = and i1 %423, %422
  %425 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %426 = ptrtoint ptr %425 to i64
  %427 = mul i64 %419, 4
  %428 = add i64 %426, %427
  %429 = urem i64 %428, 16
  %430 = icmp eq i64 %429, 0
  %431 = and i1 %424, %430
  br i1 %431, label %432, label %441

432:                                              ; preds = %417
  %433 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %434 = getelementptr float, ptr %433, i64 %419
  %435 = load <4 x float>, ptr %434, align 16
  %436 = add i64 %419, 4
  %437 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %438 = getelementptr float, ptr %437, i64 %436
  %439 = load <4 x float>, ptr %438, align 16
  %440 = shufflevector <4 x float> %435, <4 x float> %439, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %513

441:                                              ; preds = %417
  %442 = mul i64 %58, 8
  %443 = add i64 %82, %442
  %444 = icmp slt i64 %443, %25
  %445 = select i1 %444, i64 %443, i64 0
  %446 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %447 = getelementptr inbounds nuw float, ptr %446, i64 %445
  %448 = load float, ptr %447, align 4
  %449 = insertelement <8 x float> zeroinitializer, float %448, i64 0
  %450 = mul i64 %58, 8
  %451 = add i64 %450, 1
  %452 = add i64 %82, %451
  %453 = icmp slt i64 %452, %25
  %454 = select i1 %453, i64 %452, i64 0
  %455 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %456 = getelementptr inbounds nuw float, ptr %455, i64 %454
  %457 = load float, ptr %456, align 4
  %458 = insertelement <8 x float> %449, float %457, i64 1
  %459 = mul i64 %58, 8
  %460 = add i64 %459, 2
  %461 = add i64 %82, %460
  %462 = icmp slt i64 %461, %25
  %463 = select i1 %462, i64 %461, i64 0
  %464 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %465 = getelementptr inbounds nuw float, ptr %464, i64 %463
  %466 = load float, ptr %465, align 4
  %467 = insertelement <8 x float> %458, float %466, i64 2
  %468 = mul i64 %58, 8
  %469 = add i64 %468, 3
  %470 = add i64 %82, %469
  %471 = icmp slt i64 %470, %25
  %472 = select i1 %471, i64 %470, i64 0
  %473 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %474 = getelementptr inbounds nuw float, ptr %473, i64 %472
  %475 = load float, ptr %474, align 4
  %476 = insertelement <8 x float> %467, float %475, i64 3
  %477 = mul i64 %58, 8
  %478 = add i64 %477, 4
  %479 = add i64 %82, %478
  %480 = icmp slt i64 %479, %25
  %481 = select i1 %480, i64 %479, i64 0
  %482 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %483 = getelementptr inbounds nuw float, ptr %482, i64 %481
  %484 = load float, ptr %483, align 4
  %485 = insertelement <8 x float> %476, float %484, i64 4
  %486 = mul i64 %58, 8
  %487 = add i64 %486, 5
  %488 = add i64 %82, %487
  %489 = icmp slt i64 %488, %25
  %490 = select i1 %489, i64 %488, i64 0
  %491 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %492 = getelementptr inbounds nuw float, ptr %491, i64 %490
  %493 = load float, ptr %492, align 4
  %494 = insertelement <8 x float> %485, float %493, i64 5
  %495 = mul i64 %58, 8
  %496 = add i64 %495, 6
  %497 = add i64 %82, %496
  %498 = icmp slt i64 %497, %25
  %499 = select i1 %498, i64 %497, i64 0
  %500 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %501 = getelementptr inbounds nuw float, ptr %500, i64 %499
  %502 = load float, ptr %501, align 4
  %503 = insertelement <8 x float> %494, float %502, i64 6
  %504 = mul i64 %58, 8
  %505 = add i64 %504, 7
  %506 = add i64 %82, %505
  %507 = icmp slt i64 %506, %25
  %508 = select i1 %507, i64 %506, i64 0
  %509 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %510 = getelementptr inbounds nuw float, ptr %509, i64 %508
  %511 = load float, ptr %510, align 4
  %512 = insertelement <8 x float> %503, float %511, i64 7
  br label %513

513:                                              ; preds = %432, %441
  %514 = phi <8 x float> [ %512, %441 ], [ %440, %432 ]
  br label %515

515:                                              ; preds = %513
  %516 = add i64 %89, %57
  %517 = icmp slt i64 %516, %26
  %518 = select i1 %517, i64 %516, i64 0
  %519 = extractelement <8 x float> %514, i64 0
  %520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %521 = getelementptr inbounds nuw i8, ptr %520, i64 %518
  %522 = load i8, ptr %521, align 1
  %523 = zext i8 %522 to i32
  %524 = shl i32 %523, 23
  %525 = bitcast i32 %524 to float
  %526 = fmul float %525, %519
  %527 = extractelement <8 x float> %160, i64 0
  %528 = fmul float %527, %526
  %529 = call float @llvm.fabs.f32(float %526)
  %530 = fcmp olt float %529, +inf
  %531 = fcmp one float %526, 0.000000e+00
  %532 = and i1 %530, %531
  %533 = call i1 @llvm.expect.i1(i1 %532, i1 true)
  br i1 %533, label %534, label %535

534:                                              ; preds = %515
  br label %547

535:                                              ; preds = %515
  %536 = fpext float %527 to double
  %537 = fpext float %525 to double
  %538 = fpext float %519 to double
  %539 = fmul double %536, %537
  %540 = fmul double %539, %538
  %541 = fptrunc double %540 to float
  %542 = fcmp oeq float %527, 0.000000e+00
  %543 = call float @llvm.fabs.f32(float %519)
  %544 = fcmp olt float %543, +inf
  %545 = and i1 %542, %544
  %546 = select i1 %545, float 0.000000e+00, float %541
  br label %547

547:                                              ; preds = %534, %535
  %548 = phi float [ %546, %535 ], [ %528, %534 ]
  br label %549

549:                                              ; preds = %547
  %550 = add i64 %89, %57
  %551 = icmp slt i64 %550, %26
  %552 = select i1 %551, i64 %550, i64 0
  %553 = extractelement <8 x float> %514, i64 1
  %554 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %555 = getelementptr inbounds nuw i8, ptr %554, i64 %552
  %556 = load i8, ptr %555, align 1
  %557 = zext i8 %556 to i32
  %558 = shl i32 %557, 23
  %559 = bitcast i32 %558 to float
  %560 = fmul float %559, %553
  %561 = extractelement <8 x float> %160, i64 1
  %562 = fmul float %561, %560
  %563 = call float @llvm.fabs.f32(float %560)
  %564 = fcmp olt float %563, +inf
  %565 = fcmp one float %560, 0.000000e+00
  %566 = and i1 %564, %565
  %567 = call i1 @llvm.expect.i1(i1 %566, i1 true)
  br i1 %567, label %568, label %569

568:                                              ; preds = %549
  br label %581

569:                                              ; preds = %549
  %570 = fpext float %561 to double
  %571 = fpext float %559 to double
  %572 = fpext float %553 to double
  %573 = fmul double %570, %571
  %574 = fmul double %573, %572
  %575 = fptrunc double %574 to float
  %576 = fcmp oeq float %561, 0.000000e+00
  %577 = call float @llvm.fabs.f32(float %553)
  %578 = fcmp olt float %577, +inf
  %579 = and i1 %576, %578
  %580 = select i1 %579, float 0.000000e+00, float %575
  br label %581

581:                                              ; preds = %568, %569
  %582 = phi float [ %580, %569 ], [ %562, %568 ]
  br label %583

583:                                              ; preds = %581
  %584 = add i64 %89, %57
  %585 = icmp slt i64 %584, %26
  %586 = select i1 %585, i64 %584, i64 0
  %587 = extractelement <8 x float> %514, i64 2
  %588 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %589 = getelementptr inbounds nuw i8, ptr %588, i64 %586
  %590 = load i8, ptr %589, align 1
  %591 = zext i8 %590 to i32
  %592 = shl i32 %591, 23
  %593 = bitcast i32 %592 to float
  %594 = fmul float %593, %587
  %595 = extractelement <8 x float> %160, i64 2
  %596 = fmul float %595, %594
  %597 = call float @llvm.fabs.f32(float %594)
  %598 = fcmp olt float %597, +inf
  %599 = fcmp one float %594, 0.000000e+00
  %600 = and i1 %598, %599
  %601 = call i1 @llvm.expect.i1(i1 %600, i1 true)
  br i1 %601, label %602, label %603

602:                                              ; preds = %583
  br label %615

603:                                              ; preds = %583
  %604 = fpext float %595 to double
  %605 = fpext float %593 to double
  %606 = fpext float %587 to double
  %607 = fmul double %604, %605
  %608 = fmul double %607, %606
  %609 = fptrunc double %608 to float
  %610 = fcmp oeq float %595, 0.000000e+00
  %611 = call float @llvm.fabs.f32(float %587)
  %612 = fcmp olt float %611, +inf
  %613 = and i1 %610, %612
  %614 = select i1 %613, float 0.000000e+00, float %609
  br label %615

615:                                              ; preds = %602, %603
  %616 = phi float [ %614, %603 ], [ %596, %602 ]
  br label %617

617:                                              ; preds = %615
  %618 = add i64 %89, %57
  %619 = icmp slt i64 %618, %26
  %620 = select i1 %619, i64 %618, i64 0
  %621 = extractelement <8 x float> %514, i64 3
  %622 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %623 = getelementptr inbounds nuw i8, ptr %622, i64 %620
  %624 = load i8, ptr %623, align 1
  %625 = zext i8 %624 to i32
  %626 = shl i32 %625, 23
  %627 = bitcast i32 %626 to float
  %628 = fmul float %627, %621
  %629 = extractelement <8 x float> %160, i64 3
  %630 = fmul float %629, %628
  %631 = call float @llvm.fabs.f32(float %628)
  %632 = fcmp olt float %631, +inf
  %633 = fcmp one float %628, 0.000000e+00
  %634 = and i1 %632, %633
  %635 = call i1 @llvm.expect.i1(i1 %634, i1 true)
  br i1 %635, label %636, label %637

636:                                              ; preds = %617
  br label %649

637:                                              ; preds = %617
  %638 = fpext float %629 to double
  %639 = fpext float %627 to double
  %640 = fpext float %621 to double
  %641 = fmul double %638, %639
  %642 = fmul double %641, %640
  %643 = fptrunc double %642 to float
  %644 = fcmp oeq float %629, 0.000000e+00
  %645 = call float @llvm.fabs.f32(float %621)
  %646 = fcmp olt float %645, +inf
  %647 = and i1 %644, %646
  %648 = select i1 %647, float 0.000000e+00, float %643
  br label %649

649:                                              ; preds = %636, %637
  %650 = phi float [ %648, %637 ], [ %630, %636 ]
  br label %651

651:                                              ; preds = %649
  %652 = add i64 %89, %57
  %653 = icmp slt i64 %652, %26
  %654 = select i1 %653, i64 %652, i64 0
  %655 = extractelement <8 x float> %514, i64 4
  %656 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %657 = getelementptr inbounds nuw i8, ptr %656, i64 %654
  %658 = load i8, ptr %657, align 1
  %659 = zext i8 %658 to i32
  %660 = shl i32 %659, 23
  %661 = bitcast i32 %660 to float
  %662 = fmul float %661, %655
  %663 = extractelement <8 x float> %160, i64 4
  %664 = fmul float %663, %662
  %665 = call float @llvm.fabs.f32(float %662)
  %666 = fcmp olt float %665, +inf
  %667 = fcmp one float %662, 0.000000e+00
  %668 = and i1 %666, %667
  %669 = call i1 @llvm.expect.i1(i1 %668, i1 true)
  br i1 %669, label %670, label %671

670:                                              ; preds = %651
  br label %683

671:                                              ; preds = %651
  %672 = fpext float %663 to double
  %673 = fpext float %661 to double
  %674 = fpext float %655 to double
  %675 = fmul double %672, %673
  %676 = fmul double %675, %674
  %677 = fptrunc double %676 to float
  %678 = fcmp oeq float %663, 0.000000e+00
  %679 = call float @llvm.fabs.f32(float %655)
  %680 = fcmp olt float %679, +inf
  %681 = and i1 %678, %680
  %682 = select i1 %681, float 0.000000e+00, float %677
  br label %683

683:                                              ; preds = %670, %671
  %684 = phi float [ %682, %671 ], [ %664, %670 ]
  br label %685

685:                                              ; preds = %683
  %686 = add i64 %89, %57
  %687 = icmp slt i64 %686, %26
  %688 = select i1 %687, i64 %686, i64 0
  %689 = extractelement <8 x float> %514, i64 5
  %690 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %691 = getelementptr inbounds nuw i8, ptr %690, i64 %688
  %692 = load i8, ptr %691, align 1
  %693 = zext i8 %692 to i32
  %694 = shl i32 %693, 23
  %695 = bitcast i32 %694 to float
  %696 = fmul float %695, %689
  %697 = extractelement <8 x float> %160, i64 5
  %698 = fmul float %697, %696
  %699 = call float @llvm.fabs.f32(float %696)
  %700 = fcmp olt float %699, +inf
  %701 = fcmp one float %696, 0.000000e+00
  %702 = and i1 %700, %701
  %703 = call i1 @llvm.expect.i1(i1 %702, i1 true)
  br i1 %703, label %704, label %705

704:                                              ; preds = %685
  br label %717

705:                                              ; preds = %685
  %706 = fpext float %697 to double
  %707 = fpext float %695 to double
  %708 = fpext float %689 to double
  %709 = fmul double %706, %707
  %710 = fmul double %709, %708
  %711 = fptrunc double %710 to float
  %712 = fcmp oeq float %697, 0.000000e+00
  %713 = call float @llvm.fabs.f32(float %689)
  %714 = fcmp olt float %713, +inf
  %715 = and i1 %712, %714
  %716 = select i1 %715, float 0.000000e+00, float %711
  br label %717

717:                                              ; preds = %704, %705
  %718 = phi float [ %716, %705 ], [ %698, %704 ]
  br label %719

719:                                              ; preds = %717
  %720 = add i64 %89, %57
  %721 = icmp slt i64 %720, %26
  %722 = select i1 %721, i64 %720, i64 0
  %723 = extractelement <8 x float> %514, i64 6
  %724 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %725 = getelementptr inbounds nuw i8, ptr %724, i64 %722
  %726 = load i8, ptr %725, align 1
  %727 = zext i8 %726 to i32
  %728 = shl i32 %727, 23
  %729 = bitcast i32 %728 to float
  %730 = fmul float %729, %723
  %731 = extractelement <8 x float> %160, i64 6
  %732 = fmul float %731, %730
  %733 = call float @llvm.fabs.f32(float %730)
  %734 = fcmp olt float %733, +inf
  %735 = fcmp one float %730, 0.000000e+00
  %736 = and i1 %734, %735
  %737 = call i1 @llvm.expect.i1(i1 %736, i1 true)
  br i1 %737, label %738, label %739

738:                                              ; preds = %719
  br label %751

739:                                              ; preds = %719
  %740 = fpext float %731 to double
  %741 = fpext float %729 to double
  %742 = fpext float %723 to double
  %743 = fmul double %740, %741
  %744 = fmul double %743, %742
  %745 = fptrunc double %744 to float
  %746 = fcmp oeq float %731, 0.000000e+00
  %747 = call float @llvm.fabs.f32(float %723)
  %748 = fcmp olt float %747, +inf
  %749 = and i1 %746, %748
  %750 = select i1 %749, float 0.000000e+00, float %745
  br label %751

751:                                              ; preds = %738, %739
  %752 = phi float [ %750, %739 ], [ %732, %738 ]
  br label %753

753:                                              ; preds = %751
  %754 = add i64 %89, %57
  %755 = icmp slt i64 %754, %26
  %756 = select i1 %755, i64 %754, i64 0
  %757 = extractelement <8 x float> %514, i64 7
  %758 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %759 = getelementptr inbounds nuw i8, ptr %758, i64 %756
  %760 = load i8, ptr %759, align 1
  %761 = zext i8 %760 to i32
  %762 = shl i32 %761, 23
  %763 = bitcast i32 %762 to float
  %764 = fmul float %763, %757
  %765 = extractelement <8 x float> %160, i64 7
  %766 = fmul float %765, %764
  %767 = call float @llvm.fabs.f32(float %764)
  %768 = fcmp olt float %767, +inf
  %769 = fcmp one float %764, 0.000000e+00
  %770 = and i1 %768, %769
  %771 = call i1 @llvm.expect.i1(i1 %770, i1 true)
  br i1 %771, label %772, label %773

772:                                              ; preds = %753
  br label %785

773:                                              ; preds = %753
  %774 = fpext float %765 to double
  %775 = fpext float %763 to double
  %776 = fpext float %757 to double
  %777 = fmul double %774, %775
  %778 = fmul double %777, %776
  %779 = fptrunc double %778 to float
  %780 = fcmp oeq float %765, 0.000000e+00
  %781 = call float @llvm.fabs.f32(float %757)
  %782 = fcmp olt float %781, +inf
  %783 = and i1 %780, %782
  %784 = select i1 %783, float 0.000000e+00, float %779
  br label %785

785:                                              ; preds = %772, %773
  %786 = phi float [ %784, %773 ], [ %766, %772 ]
  br label %787

787:                                              ; preds = %785
  %788 = mul i64 %59, 16
  %789 = mul i64 %58, 8
  %790 = add i64 %788, %789
  %791 = mul i64 %790, 40
  %792 = add i64 %791, %57
  %793 = fptrunc float %548 to bfloat
  %794 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %792
  store bfloat %793, ptr addrspace(3) %794, align 2
  %795 = mul i64 %58, 8
  %796 = add i64 %795, 1
  %797 = add i64 %788, %796
  %798 = mul i64 %797, 40
  %799 = add i64 %798, %57
  %800 = fptrunc float %582 to bfloat
  %801 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %799
  store bfloat %800, ptr addrspace(3) %801, align 2
  %802 = mul i64 %58, 8
  %803 = add i64 %802, 2
  %804 = add i64 %788, %803
  %805 = mul i64 %804, 40
  %806 = add i64 %805, %57
  %807 = fptrunc float %616 to bfloat
  %808 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %806
  store bfloat %807, ptr addrspace(3) %808, align 2
  %809 = mul i64 %58, 8
  %810 = add i64 %809, 3
  %811 = add i64 %788, %810
  %812 = mul i64 %811, 40
  %813 = add i64 %812, %57
  %814 = fptrunc float %650 to bfloat
  %815 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %813
  store bfloat %814, ptr addrspace(3) %815, align 2
  %816 = mul i64 %58, 8
  %817 = add i64 %816, 4
  %818 = add i64 %788, %817
  %819 = mul i64 %818, 40
  %820 = add i64 %819, %57
  %821 = fptrunc float %684 to bfloat
  %822 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %820
  store bfloat %821, ptr addrspace(3) %822, align 2
  %823 = mul i64 %58, 8
  %824 = add i64 %823, 5
  %825 = add i64 %788, %824
  %826 = mul i64 %825, 40
  %827 = add i64 %826, %57
  %828 = fptrunc float %718 to bfloat
  %829 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %827
  store bfloat %828, ptr addrspace(3) %829, align 2
  %830 = mul i64 %58, 8
  %831 = add i64 %830, 6
  %832 = add i64 %788, %831
  %833 = mul i64 %832, 40
  %834 = add i64 %833, %57
  %835 = fptrunc float %752 to bfloat
  %836 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %834
  store bfloat %835, ptr addrspace(3) %836, align 2
  %837 = mul i64 %58, 8
  %838 = add i64 %837, 7
  %839 = add i64 %788, %838
  %840 = mul i64 %839, 40
  %841 = add i64 %840, %57
  %842 = fptrunc float %786 to bfloat
  %843 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %841
  store bfloat %842, ptr addrspace(3) %843, align 2
  %844 = mul i64 %58, 8
  %845 = add i64 %82, %844
  %846 = add i64 %91, %57
  %847 = add i64 %845, 7
  %848 = icmp ult i64 %846, %26
  %849 = icmp ult i64 %847, %25
  %850 = and i1 %849, %848
  %851 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %852 = ptrtoint ptr %851 to i64
  %853 = mul i64 %845, 4
  %854 = add i64 %852, %853
  %855 = urem i64 %854, 16
  %856 = icmp eq i64 %855, 0
  %857 = and i1 %850, %856
  br i1 %857, label %858, label %867

858:                                              ; preds = %787
  %859 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %860 = getelementptr float, ptr %859, i64 %845
  %861 = load <4 x float>, ptr %860, align 16
  %862 = add i64 %845, 4
  %863 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %864 = getelementptr float, ptr %863, i64 %862
  %865 = load <4 x float>, ptr %864, align 16
  %866 = shufflevector <4 x float> %861, <4 x float> %865, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %939

867:                                              ; preds = %787
  %868 = mul i64 %58, 8
  %869 = add i64 %82, %868
  %870 = icmp slt i64 %869, %25
  %871 = select i1 %870, i64 %869, i64 0
  %872 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %873 = getelementptr inbounds nuw float, ptr %872, i64 %871
  %874 = load float, ptr %873, align 4
  %875 = insertelement <8 x float> zeroinitializer, float %874, i64 0
  %876 = mul i64 %58, 8
  %877 = add i64 %876, 1
  %878 = add i64 %82, %877
  %879 = icmp slt i64 %878, %25
  %880 = select i1 %879, i64 %878, i64 0
  %881 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %882 = getelementptr inbounds nuw float, ptr %881, i64 %880
  %883 = load float, ptr %882, align 4
  %884 = insertelement <8 x float> %875, float %883, i64 1
  %885 = mul i64 %58, 8
  %886 = add i64 %885, 2
  %887 = add i64 %82, %886
  %888 = icmp slt i64 %887, %25
  %889 = select i1 %888, i64 %887, i64 0
  %890 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %891 = getelementptr inbounds nuw float, ptr %890, i64 %889
  %892 = load float, ptr %891, align 4
  %893 = insertelement <8 x float> %884, float %892, i64 2
  %894 = mul i64 %58, 8
  %895 = add i64 %894, 3
  %896 = add i64 %82, %895
  %897 = icmp slt i64 %896, %25
  %898 = select i1 %897, i64 %896, i64 0
  %899 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %900 = getelementptr inbounds nuw float, ptr %899, i64 %898
  %901 = load float, ptr %900, align 4
  %902 = insertelement <8 x float> %893, float %901, i64 3
  %903 = mul i64 %58, 8
  %904 = add i64 %903, 4
  %905 = add i64 %82, %904
  %906 = icmp slt i64 %905, %25
  %907 = select i1 %906, i64 %905, i64 0
  %908 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %909 = getelementptr inbounds nuw float, ptr %908, i64 %907
  %910 = load float, ptr %909, align 4
  %911 = insertelement <8 x float> %902, float %910, i64 4
  %912 = mul i64 %58, 8
  %913 = add i64 %912, 5
  %914 = add i64 %82, %913
  %915 = icmp slt i64 %914, %25
  %916 = select i1 %915, i64 %914, i64 0
  %917 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %918 = getelementptr inbounds nuw float, ptr %917, i64 %916
  %919 = load float, ptr %918, align 4
  %920 = insertelement <8 x float> %911, float %919, i64 5
  %921 = mul i64 %58, 8
  %922 = add i64 %921, 6
  %923 = add i64 %82, %922
  %924 = icmp slt i64 %923, %25
  %925 = select i1 %924, i64 %923, i64 0
  %926 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %927 = getelementptr inbounds nuw float, ptr %926, i64 %925
  %928 = load float, ptr %927, align 4
  %929 = insertelement <8 x float> %920, float %928, i64 6
  %930 = mul i64 %58, 8
  %931 = add i64 %930, 7
  %932 = add i64 %82, %931
  %933 = icmp slt i64 %932, %25
  %934 = select i1 %933, i64 %932, i64 0
  %935 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %936 = getelementptr inbounds nuw float, ptr %935, i64 %934
  %937 = load float, ptr %936, align 4
  %938 = insertelement <8 x float> %929, float %937, i64 7
  br label %939

939:                                              ; preds = %858, %867
  %940 = phi <8 x float> [ %938, %867 ], [ %866, %858 ]
  br label %941

941:                                              ; preds = %939
  %942 = add i64 %91, %57
  %943 = icmp slt i64 %942, %26
  %944 = select i1 %943, i64 %942, i64 0
  %945 = extractelement <8 x float> %940, i64 0
  %946 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %947 = getelementptr inbounds nuw i8, ptr %946, i64 %944
  %948 = load i8, ptr %947, align 1
  %949 = zext i8 %948 to i32
  %950 = shl i32 %949, 23
  %951 = bitcast i32 %950 to float
  %952 = fmul float %951, %945
  %953 = extractelement <8 x float> %161, i64 0
  %954 = fmul float %953, %952
  %955 = call float @llvm.fabs.f32(float %952)
  %956 = fcmp olt float %955, +inf
  %957 = fcmp one float %952, 0.000000e+00
  %958 = and i1 %956, %957
  %959 = call i1 @llvm.expect.i1(i1 %958, i1 true)
  br i1 %959, label %960, label %961

960:                                              ; preds = %941
  br label %973

961:                                              ; preds = %941
  %962 = fpext float %953 to double
  %963 = fpext float %951 to double
  %964 = fpext float %945 to double
  %965 = fmul double %962, %963
  %966 = fmul double %965, %964
  %967 = fptrunc double %966 to float
  %968 = fcmp oeq float %953, 0.000000e+00
  %969 = call float @llvm.fabs.f32(float %945)
  %970 = fcmp olt float %969, +inf
  %971 = and i1 %968, %970
  %972 = select i1 %971, float 0.000000e+00, float %967
  br label %973

973:                                              ; preds = %960, %961
  %974 = phi float [ %972, %961 ], [ %954, %960 ]
  br label %975

975:                                              ; preds = %973
  %976 = add i64 %91, %57
  %977 = icmp slt i64 %976, %26
  %978 = select i1 %977, i64 %976, i64 0
  %979 = extractelement <8 x float> %940, i64 1
  %980 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %981 = getelementptr inbounds nuw i8, ptr %980, i64 %978
  %982 = load i8, ptr %981, align 1
  %983 = zext i8 %982 to i32
  %984 = shl i32 %983, 23
  %985 = bitcast i32 %984 to float
  %986 = fmul float %985, %979
  %987 = extractelement <8 x float> %161, i64 1
  %988 = fmul float %987, %986
  %989 = call float @llvm.fabs.f32(float %986)
  %990 = fcmp olt float %989, +inf
  %991 = fcmp one float %986, 0.000000e+00
  %992 = and i1 %990, %991
  %993 = call i1 @llvm.expect.i1(i1 %992, i1 true)
  br i1 %993, label %994, label %995

994:                                              ; preds = %975
  br label %1007

995:                                              ; preds = %975
  %996 = fpext float %987 to double
  %997 = fpext float %985 to double
  %998 = fpext float %979 to double
  %999 = fmul double %996, %997
  %1000 = fmul double %999, %998
  %1001 = fptrunc double %1000 to float
  %1002 = fcmp oeq float %987, 0.000000e+00
  %1003 = call float @llvm.fabs.f32(float %979)
  %1004 = fcmp olt float %1003, +inf
  %1005 = and i1 %1002, %1004
  %1006 = select i1 %1005, float 0.000000e+00, float %1001
  br label %1007

1007:                                             ; preds = %994, %995
  %1008 = phi float [ %1006, %995 ], [ %988, %994 ]
  br label %1009

1009:                                             ; preds = %1007
  %1010 = add i64 %91, %57
  %1011 = icmp slt i64 %1010, %26
  %1012 = select i1 %1011, i64 %1010, i64 0
  %1013 = extractelement <8 x float> %940, i64 2
  %1014 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1015 = getelementptr inbounds nuw i8, ptr %1014, i64 %1012
  %1016 = load i8, ptr %1015, align 1
  %1017 = zext i8 %1016 to i32
  %1018 = shl i32 %1017, 23
  %1019 = bitcast i32 %1018 to float
  %1020 = fmul float %1019, %1013
  %1021 = extractelement <8 x float> %161, i64 2
  %1022 = fmul float %1021, %1020
  %1023 = call float @llvm.fabs.f32(float %1020)
  %1024 = fcmp olt float %1023, +inf
  %1025 = fcmp one float %1020, 0.000000e+00
  %1026 = and i1 %1024, %1025
  %1027 = call i1 @llvm.expect.i1(i1 %1026, i1 true)
  br i1 %1027, label %1028, label %1029

1028:                                             ; preds = %1009
  br label %1041

1029:                                             ; preds = %1009
  %1030 = fpext float %1021 to double
  %1031 = fpext float %1019 to double
  %1032 = fpext float %1013 to double
  %1033 = fmul double %1030, %1031
  %1034 = fmul double %1033, %1032
  %1035 = fptrunc double %1034 to float
  %1036 = fcmp oeq float %1021, 0.000000e+00
  %1037 = call float @llvm.fabs.f32(float %1013)
  %1038 = fcmp olt float %1037, +inf
  %1039 = and i1 %1036, %1038
  %1040 = select i1 %1039, float 0.000000e+00, float %1035
  br label %1041

1041:                                             ; preds = %1028, %1029
  %1042 = phi float [ %1040, %1029 ], [ %1022, %1028 ]
  br label %1043

1043:                                             ; preds = %1041
  %1044 = add i64 %91, %57
  %1045 = icmp slt i64 %1044, %26
  %1046 = select i1 %1045, i64 %1044, i64 0
  %1047 = extractelement <8 x float> %940, i64 3
  %1048 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1049 = getelementptr inbounds nuw i8, ptr %1048, i64 %1046
  %1050 = load i8, ptr %1049, align 1
  %1051 = zext i8 %1050 to i32
  %1052 = shl i32 %1051, 23
  %1053 = bitcast i32 %1052 to float
  %1054 = fmul float %1053, %1047
  %1055 = extractelement <8 x float> %161, i64 3
  %1056 = fmul float %1055, %1054
  %1057 = call float @llvm.fabs.f32(float %1054)
  %1058 = fcmp olt float %1057, +inf
  %1059 = fcmp one float %1054, 0.000000e+00
  %1060 = and i1 %1058, %1059
  %1061 = call i1 @llvm.expect.i1(i1 %1060, i1 true)
  br i1 %1061, label %1062, label %1063

1062:                                             ; preds = %1043
  br label %1075

1063:                                             ; preds = %1043
  %1064 = fpext float %1055 to double
  %1065 = fpext float %1053 to double
  %1066 = fpext float %1047 to double
  %1067 = fmul double %1064, %1065
  %1068 = fmul double %1067, %1066
  %1069 = fptrunc double %1068 to float
  %1070 = fcmp oeq float %1055, 0.000000e+00
  %1071 = call float @llvm.fabs.f32(float %1047)
  %1072 = fcmp olt float %1071, +inf
  %1073 = and i1 %1070, %1072
  %1074 = select i1 %1073, float 0.000000e+00, float %1069
  br label %1075

1075:                                             ; preds = %1062, %1063
  %1076 = phi float [ %1074, %1063 ], [ %1056, %1062 ]
  br label %1077

1077:                                             ; preds = %1075
  %1078 = add i64 %91, %57
  %1079 = icmp slt i64 %1078, %26
  %1080 = select i1 %1079, i64 %1078, i64 0
  %1081 = extractelement <8 x float> %940, i64 4
  %1082 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1083 = getelementptr inbounds nuw i8, ptr %1082, i64 %1080
  %1084 = load i8, ptr %1083, align 1
  %1085 = zext i8 %1084 to i32
  %1086 = shl i32 %1085, 23
  %1087 = bitcast i32 %1086 to float
  %1088 = fmul float %1087, %1081
  %1089 = extractelement <8 x float> %161, i64 4
  %1090 = fmul float %1089, %1088
  %1091 = call float @llvm.fabs.f32(float %1088)
  %1092 = fcmp olt float %1091, +inf
  %1093 = fcmp one float %1088, 0.000000e+00
  %1094 = and i1 %1092, %1093
  %1095 = call i1 @llvm.expect.i1(i1 %1094, i1 true)
  br i1 %1095, label %1096, label %1097

1096:                                             ; preds = %1077
  br label %1109

1097:                                             ; preds = %1077
  %1098 = fpext float %1089 to double
  %1099 = fpext float %1087 to double
  %1100 = fpext float %1081 to double
  %1101 = fmul double %1098, %1099
  %1102 = fmul double %1101, %1100
  %1103 = fptrunc double %1102 to float
  %1104 = fcmp oeq float %1089, 0.000000e+00
  %1105 = call float @llvm.fabs.f32(float %1081)
  %1106 = fcmp olt float %1105, +inf
  %1107 = and i1 %1104, %1106
  %1108 = select i1 %1107, float 0.000000e+00, float %1103
  br label %1109

1109:                                             ; preds = %1096, %1097
  %1110 = phi float [ %1108, %1097 ], [ %1090, %1096 ]
  br label %1111

1111:                                             ; preds = %1109
  %1112 = add i64 %91, %57
  %1113 = icmp slt i64 %1112, %26
  %1114 = select i1 %1113, i64 %1112, i64 0
  %1115 = extractelement <8 x float> %940, i64 5
  %1116 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1117 = getelementptr inbounds nuw i8, ptr %1116, i64 %1114
  %1118 = load i8, ptr %1117, align 1
  %1119 = zext i8 %1118 to i32
  %1120 = shl i32 %1119, 23
  %1121 = bitcast i32 %1120 to float
  %1122 = fmul float %1121, %1115
  %1123 = extractelement <8 x float> %161, i64 5
  %1124 = fmul float %1123, %1122
  %1125 = call float @llvm.fabs.f32(float %1122)
  %1126 = fcmp olt float %1125, +inf
  %1127 = fcmp one float %1122, 0.000000e+00
  %1128 = and i1 %1126, %1127
  %1129 = call i1 @llvm.expect.i1(i1 %1128, i1 true)
  br i1 %1129, label %1130, label %1131

1130:                                             ; preds = %1111
  br label %1143

1131:                                             ; preds = %1111
  %1132 = fpext float %1123 to double
  %1133 = fpext float %1121 to double
  %1134 = fpext float %1115 to double
  %1135 = fmul double %1132, %1133
  %1136 = fmul double %1135, %1134
  %1137 = fptrunc double %1136 to float
  %1138 = fcmp oeq float %1123, 0.000000e+00
  %1139 = call float @llvm.fabs.f32(float %1115)
  %1140 = fcmp olt float %1139, +inf
  %1141 = and i1 %1138, %1140
  %1142 = select i1 %1141, float 0.000000e+00, float %1137
  br label %1143

1143:                                             ; preds = %1130, %1131
  %1144 = phi float [ %1142, %1131 ], [ %1124, %1130 ]
  br label %1145

1145:                                             ; preds = %1143
  %1146 = add i64 %91, %57
  %1147 = icmp slt i64 %1146, %26
  %1148 = select i1 %1147, i64 %1146, i64 0
  %1149 = extractelement <8 x float> %940, i64 6
  %1150 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1151 = getelementptr inbounds nuw i8, ptr %1150, i64 %1148
  %1152 = load i8, ptr %1151, align 1
  %1153 = zext i8 %1152 to i32
  %1154 = shl i32 %1153, 23
  %1155 = bitcast i32 %1154 to float
  %1156 = fmul float %1155, %1149
  %1157 = extractelement <8 x float> %161, i64 6
  %1158 = fmul float %1157, %1156
  %1159 = call float @llvm.fabs.f32(float %1156)
  %1160 = fcmp olt float %1159, +inf
  %1161 = fcmp one float %1156, 0.000000e+00
  %1162 = and i1 %1160, %1161
  %1163 = call i1 @llvm.expect.i1(i1 %1162, i1 true)
  br i1 %1163, label %1164, label %1165

1164:                                             ; preds = %1145
  br label %1177

1165:                                             ; preds = %1145
  %1166 = fpext float %1157 to double
  %1167 = fpext float %1155 to double
  %1168 = fpext float %1149 to double
  %1169 = fmul double %1166, %1167
  %1170 = fmul double %1169, %1168
  %1171 = fptrunc double %1170 to float
  %1172 = fcmp oeq float %1157, 0.000000e+00
  %1173 = call float @llvm.fabs.f32(float %1149)
  %1174 = fcmp olt float %1173, +inf
  %1175 = and i1 %1172, %1174
  %1176 = select i1 %1175, float 0.000000e+00, float %1171
  br label %1177

1177:                                             ; preds = %1164, %1165
  %1178 = phi float [ %1176, %1165 ], [ %1158, %1164 ]
  br label %1179

1179:                                             ; preds = %1177
  %1180 = add i64 %91, %57
  %1181 = icmp slt i64 %1180, %26
  %1182 = select i1 %1181, i64 %1180, i64 0
  %1183 = extractelement <8 x float> %940, i64 7
  %1184 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1185 = getelementptr inbounds nuw i8, ptr %1184, i64 %1182
  %1186 = load i8, ptr %1185, align 1
  %1187 = zext i8 %1186 to i32
  %1188 = shl i32 %1187, 23
  %1189 = bitcast i32 %1188 to float
  %1190 = fmul float %1189, %1183
  %1191 = extractelement <8 x float> %161, i64 7
  %1192 = fmul float %1191, %1190
  %1193 = call float @llvm.fabs.f32(float %1190)
  %1194 = fcmp olt float %1193, +inf
  %1195 = fcmp one float %1190, 0.000000e+00
  %1196 = and i1 %1194, %1195
  %1197 = call i1 @llvm.expect.i1(i1 %1196, i1 true)
  br i1 %1197, label %1198, label %1199

1198:                                             ; preds = %1179
  br label %1211

1199:                                             ; preds = %1179
  %1200 = fpext float %1191 to double
  %1201 = fpext float %1189 to double
  %1202 = fpext float %1183 to double
  %1203 = fmul double %1200, %1201
  %1204 = fmul double %1203, %1202
  %1205 = fptrunc double %1204 to float
  %1206 = fcmp oeq float %1191, 0.000000e+00
  %1207 = call float @llvm.fabs.f32(float %1183)
  %1208 = fcmp olt float %1207, +inf
  %1209 = and i1 %1206, %1208
  %1210 = select i1 %1209, float 0.000000e+00, float %1205
  br label %1211

1211:                                             ; preds = %1198, %1199
  %1212 = phi float [ %1210, %1199 ], [ %1192, %1198 ]
  br label %1213

1213:                                             ; preds = %1211
  %1214 = mul i64 %59, 16
  %1215 = mul i64 %58, 8
  %1216 = add i64 %1214, %1215
  %1217 = add i64 %57, 16
  %1218 = mul i64 %1216, 40
  %1219 = add i64 %1218, %1217
  %1220 = fptrunc float %974 to bfloat
  %1221 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1219
  store bfloat %1220, ptr addrspace(3) %1221, align 2
  %1222 = mul i64 %58, 8
  %1223 = add i64 %1222, 1
  %1224 = add i64 %1214, %1223
  %1225 = add i64 %57, 16
  %1226 = mul i64 %1224, 40
  %1227 = add i64 %1226, %1225
  %1228 = fptrunc float %1008 to bfloat
  %1229 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1227
  store bfloat %1228, ptr addrspace(3) %1229, align 2
  %1230 = mul i64 %58, 8
  %1231 = add i64 %1230, 2
  %1232 = add i64 %1214, %1231
  %1233 = add i64 %57, 16
  %1234 = mul i64 %1232, 40
  %1235 = add i64 %1234, %1233
  %1236 = fptrunc float %1042 to bfloat
  %1237 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1235
  store bfloat %1236, ptr addrspace(3) %1237, align 2
  %1238 = mul i64 %58, 8
  %1239 = add i64 %1238, 3
  %1240 = add i64 %1214, %1239
  %1241 = add i64 %57, 16
  %1242 = mul i64 %1240, 40
  %1243 = add i64 %1242, %1241
  %1244 = fptrunc float %1076 to bfloat
  %1245 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1243
  store bfloat %1244, ptr addrspace(3) %1245, align 2
  %1246 = mul i64 %58, 8
  %1247 = add i64 %1246, 4
  %1248 = add i64 %1214, %1247
  %1249 = add i64 %57, 16
  %1250 = mul i64 %1248, 40
  %1251 = add i64 %1250, %1249
  %1252 = fptrunc float %1110 to bfloat
  %1253 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1251
  store bfloat %1252, ptr addrspace(3) %1253, align 2
  %1254 = mul i64 %58, 8
  %1255 = add i64 %1254, 5
  %1256 = add i64 %1214, %1255
  %1257 = add i64 %57, 16
  %1258 = mul i64 %1256, 40
  %1259 = add i64 %1258, %1257
  %1260 = fptrunc float %1144 to bfloat
  %1261 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1259
  store bfloat %1260, ptr addrspace(3) %1261, align 2
  %1262 = mul i64 %58, 8
  %1263 = add i64 %1262, 6
  %1264 = add i64 %1214, %1263
  %1265 = add i64 %57, 16
  %1266 = mul i64 %1264, 40
  %1267 = add i64 %1266, %1265
  %1268 = fptrunc float %1178 to bfloat
  %1269 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1267
  store bfloat %1268, ptr addrspace(3) %1269, align 2
  %1270 = mul i64 %58, 8
  %1271 = add i64 %1270, 7
  %1272 = add i64 %1214, %1271
  %1273 = add i64 %57, 16
  %1274 = mul i64 %1272, 40
  %1275 = add i64 %1274, %1273
  %1276 = fptrunc float %1212 to bfloat
  %1277 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1275
  store bfloat %1276, ptr addrspace(3) %1277, align 2
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %1278 = urem i64 %55, 32
  %1279 = mul i64 %1278, 8
  %1280 = udiv i64 %1279, 32
  %1281 = urem i64 %1279, 32
  %1282 = mul i64 %59, 16
  %1283 = add i64 %1282, %1280
  %1284 = udiv i64 %59, 2
  %1285 = mul i64 %1284, 4
  %1286 = mul i64 %1285, 16
  %1287 = add i64 %1280, %1286
  %1288 = add i64 %78, %1287
  %1289 = urem i64 %59, 2
  %1290 = mul i64 %1289, 32
  %1291 = add i64 %1281, %1290
  %1292 = add i64 %79, %1291
  %1293 = mul i64 %1283, 40
  %1294 = add i64 %1293, %1281
  %1295 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1294
  %1296 = load <8 x bfloat>, ptr addrspace(3) %1295, align 16
  %1297 = mul i64 %1288, %26
  %1298 = add i64 %1297, %1292
  %1299 = icmp ult i64 %1288, %25
  %1300 = add i64 %1292, 7
  %1301 = icmp ult i64 %1300, %26
  %1302 = and i1 %1299, %1301
  br i1 %1302, label %1303, label %1306

1303:                                             ; preds = %1213
  %1304 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1305 = getelementptr bfloat, ptr %1304, i64 %1298
  store <8 x bfloat> %1296, ptr %1305, align 2
  br label %1377

1306:                                             ; preds = %1213
  %1307 = icmp ult i64 %1292, %26
  %1308 = and i1 %1299, %1307
  br i1 %1308, label %1309, label %1313

1309:                                             ; preds = %1306
  %1310 = extractelement <8 x bfloat> %1296, i64 0
  %1311 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1312 = getelementptr inbounds nuw bfloat, ptr %1311, i64 %1298
  store bfloat %1310, ptr %1312, align 2
  br label %1313

1313:                                             ; preds = %1309, %1306
  %1314 = add i64 %1292, 1
  %1315 = icmp ult i64 %1314, %26
  %1316 = and i1 %1299, %1315
  br i1 %1316, label %1317, label %1322

1317:                                             ; preds = %1313
  %1318 = add i64 %1298, 1
  %1319 = extractelement <8 x bfloat> %1296, i64 1
  %1320 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1321 = getelementptr inbounds nuw bfloat, ptr %1320, i64 %1318
  store bfloat %1319, ptr %1321, align 2
  br label %1322

1322:                                             ; preds = %1317, %1313
  %1323 = add i64 %1292, 2
  %1324 = icmp ult i64 %1323, %26
  %1325 = and i1 %1299, %1324
  br i1 %1325, label %1326, label %1331

1326:                                             ; preds = %1322
  %1327 = add i64 %1298, 2
  %1328 = extractelement <8 x bfloat> %1296, i64 2
  %1329 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1330 = getelementptr inbounds nuw bfloat, ptr %1329, i64 %1327
  store bfloat %1328, ptr %1330, align 2
  br label %1331

1331:                                             ; preds = %1326, %1322
  %1332 = add i64 %1292, 3
  %1333 = icmp ult i64 %1332, %26
  %1334 = and i1 %1299, %1333
  br i1 %1334, label %1335, label %1340

1335:                                             ; preds = %1331
  %1336 = add i64 %1298, 3
  %1337 = extractelement <8 x bfloat> %1296, i64 3
  %1338 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1339 = getelementptr inbounds nuw bfloat, ptr %1338, i64 %1336
  store bfloat %1337, ptr %1339, align 2
  br label %1340

1340:                                             ; preds = %1335, %1331
  %1341 = add i64 %1292, 4
  %1342 = icmp ult i64 %1341, %26
  %1343 = and i1 %1299, %1342
  br i1 %1343, label %1344, label %1349

1344:                                             ; preds = %1340
  %1345 = add i64 %1298, 4
  %1346 = extractelement <8 x bfloat> %1296, i64 4
  %1347 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1348 = getelementptr inbounds nuw bfloat, ptr %1347, i64 %1345
  store bfloat %1346, ptr %1348, align 2
  br label %1349

1349:                                             ; preds = %1344, %1340
  %1350 = add i64 %1292, 5
  %1351 = icmp ult i64 %1350, %26
  %1352 = and i1 %1299, %1351
  br i1 %1352, label %1353, label %1358

1353:                                             ; preds = %1349
  %1354 = add i64 %1298, 5
  %1355 = extractelement <8 x bfloat> %1296, i64 5
  %1356 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1357 = getelementptr inbounds nuw bfloat, ptr %1356, i64 %1354
  store bfloat %1355, ptr %1357, align 2
  br label %1358

1358:                                             ; preds = %1353, %1349
  %1359 = add i64 %1292, 6
  %1360 = icmp ult i64 %1359, %26
  %1361 = and i1 %1299, %1360
  br i1 %1361, label %1362, label %1367

1362:                                             ; preds = %1358
  %1363 = add i64 %1298, 6
  %1364 = extractelement <8 x bfloat> %1296, i64 6
  %1365 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1366 = getelementptr inbounds nuw bfloat, ptr %1365, i64 %1363
  store bfloat %1364, ptr %1366, align 2
  br label %1367

1367:                                             ; preds = %1362, %1358
  %1368 = add i64 %1292, 7
  %1369 = icmp ult i64 %1368, %26
  %1370 = and i1 %1299, %1369
  br i1 %1370, label %1371, label %1376

1371:                                             ; preds = %1367
  %1372 = add i64 %1298, 7
  %1373 = extractelement <8 x bfloat> %1296, i64 7
  %1374 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1375 = getelementptr inbounds nuw bfloat, ptr %1374, i64 %1372
  store bfloat %1373, ptr %1375, align 2
  br label %1376

1376:                                             ; preds = %1371, %1367
  br label %1377

1377:                                             ; preds = %1303, %1376
  %1378 = urem i64 %55, 32
  %1379 = mul i64 %1378, 8
  %1380 = add i64 %1379, 256
  %1381 = udiv i64 %1380, 32
  %1382 = urem i64 %1380, 32
  %1383 = mul i64 %59, 16
  %1384 = add i64 %1383, %1381
  %1385 = udiv i64 %59, 2
  %1386 = mul i64 %1385, 4
  %1387 = mul i64 %1386, 16
  %1388 = add i64 %1381, %1387
  %1389 = add i64 %78, %1388
  %1390 = urem i64 %59, 2
  %1391 = mul i64 %1390, 32
  %1392 = add i64 %1382, %1391
  %1393 = add i64 %79, %1392
  %1394 = mul i64 %1384, 40
  %1395 = add i64 %1394, %1382
  %1396 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1395
  %1397 = load <8 x bfloat>, ptr addrspace(3) %1396, align 16
  %1398 = mul i64 %1389, %26
  %1399 = add i64 %1398, %1393
  %1400 = icmp ult i64 %1389, %25
  %1401 = add i64 %1393, 7
  %1402 = icmp ult i64 %1401, %26
  %1403 = and i1 %1400, %1402
  br i1 %1403, label %1404, label %1407

1404:                                             ; preds = %1377
  %1405 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1406 = getelementptr bfloat, ptr %1405, i64 %1399
  store <8 x bfloat> %1397, ptr %1406, align 2
  br label %1478

1407:                                             ; preds = %1377
  %1408 = icmp ult i64 %1393, %26
  %1409 = and i1 %1400, %1408
  br i1 %1409, label %1410, label %1414

1410:                                             ; preds = %1407
  %1411 = extractelement <8 x bfloat> %1397, i64 0
  %1412 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1413 = getelementptr inbounds nuw bfloat, ptr %1412, i64 %1399
  store bfloat %1411, ptr %1413, align 2
  br label %1414

1414:                                             ; preds = %1410, %1407
  %1415 = add i64 %1393, 1
  %1416 = icmp ult i64 %1415, %26
  %1417 = and i1 %1400, %1416
  br i1 %1417, label %1418, label %1423

1418:                                             ; preds = %1414
  %1419 = add i64 %1399, 1
  %1420 = extractelement <8 x bfloat> %1397, i64 1
  %1421 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1422 = getelementptr inbounds nuw bfloat, ptr %1421, i64 %1419
  store bfloat %1420, ptr %1422, align 2
  br label %1423

1423:                                             ; preds = %1418, %1414
  %1424 = add i64 %1393, 2
  %1425 = icmp ult i64 %1424, %26
  %1426 = and i1 %1400, %1425
  br i1 %1426, label %1427, label %1432

1427:                                             ; preds = %1423
  %1428 = add i64 %1399, 2
  %1429 = extractelement <8 x bfloat> %1397, i64 2
  %1430 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1431 = getelementptr inbounds nuw bfloat, ptr %1430, i64 %1428
  store bfloat %1429, ptr %1431, align 2
  br label %1432

1432:                                             ; preds = %1427, %1423
  %1433 = add i64 %1393, 3
  %1434 = icmp ult i64 %1433, %26
  %1435 = and i1 %1400, %1434
  br i1 %1435, label %1436, label %1441

1436:                                             ; preds = %1432
  %1437 = add i64 %1399, 3
  %1438 = extractelement <8 x bfloat> %1397, i64 3
  %1439 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1440 = getelementptr inbounds nuw bfloat, ptr %1439, i64 %1437
  store bfloat %1438, ptr %1440, align 2
  br label %1441

1441:                                             ; preds = %1436, %1432
  %1442 = add i64 %1393, 4
  %1443 = icmp ult i64 %1442, %26
  %1444 = and i1 %1400, %1443
  br i1 %1444, label %1445, label %1450

1445:                                             ; preds = %1441
  %1446 = add i64 %1399, 4
  %1447 = extractelement <8 x bfloat> %1397, i64 4
  %1448 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1449 = getelementptr inbounds nuw bfloat, ptr %1448, i64 %1446
  store bfloat %1447, ptr %1449, align 2
  br label %1450

1450:                                             ; preds = %1445, %1441
  %1451 = add i64 %1393, 5
  %1452 = icmp ult i64 %1451, %26
  %1453 = and i1 %1400, %1452
  br i1 %1453, label %1454, label %1459

1454:                                             ; preds = %1450
  %1455 = add i64 %1399, 5
  %1456 = extractelement <8 x bfloat> %1397, i64 5
  %1457 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1458 = getelementptr inbounds nuw bfloat, ptr %1457, i64 %1455
  store bfloat %1456, ptr %1458, align 2
  br label %1459

1459:                                             ; preds = %1454, %1450
  %1460 = add i64 %1393, 6
  %1461 = icmp ult i64 %1460, %26
  %1462 = and i1 %1400, %1461
  br i1 %1462, label %1463, label %1468

1463:                                             ; preds = %1459
  %1464 = add i64 %1399, 6
  %1465 = extractelement <8 x bfloat> %1397, i64 6
  %1466 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1467 = getelementptr inbounds nuw bfloat, ptr %1466, i64 %1464
  store bfloat %1465, ptr %1467, align 2
  br label %1468

1468:                                             ; preds = %1463, %1459
  %1469 = add i64 %1393, 7
  %1470 = icmp ult i64 %1469, %26
  %1471 = and i1 %1400, %1470
  br i1 %1471, label %1472, label %1477

1472:                                             ; preds = %1468
  %1473 = add i64 %1399, 7
  %1474 = extractelement <8 x bfloat> %1397, i64 7
  %1475 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1476 = getelementptr inbounds nuw bfloat, ptr %1475, i64 %1473
  store bfloat %1474, ptr %1476, align 2
  br label %1477

1477:                                             ; preds = %1472, %1468
  br label %1478

1478:                                             ; preds = %1404, %1477
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %1479 = mul i64 %58, 8
  %1480 = add i64 %84, %1479
  %1481 = add i64 %89, %57
  %1482 = add i64 %1480, 7
  %1483 = icmp ult i64 %1481, %26
  %1484 = icmp ult i64 %1482, %25
  %1485 = and i1 %1484, %1483
  %1486 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1487 = ptrtoint ptr %1486 to i64
  %1488 = mul i64 %1480, 4
  %1489 = add i64 %1487, %1488
  %1490 = urem i64 %1489, 16
  %1491 = icmp eq i64 %1490, 0
  %1492 = and i1 %1485, %1491
  br i1 %1492, label %1493, label %1502

1493:                                             ; preds = %1478
  %1494 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1495 = getelementptr float, ptr %1494, i64 %1480
  %1496 = load <4 x float>, ptr %1495, align 16
  %1497 = add i64 %1480, 4
  %1498 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1499 = getelementptr float, ptr %1498, i64 %1497
  %1500 = load <4 x float>, ptr %1499, align 16
  %1501 = shufflevector <4 x float> %1496, <4 x float> %1500, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1574

1502:                                             ; preds = %1478
  %1503 = mul i64 %58, 8
  %1504 = add i64 %84, %1503
  %1505 = icmp slt i64 %1504, %25
  %1506 = select i1 %1505, i64 %1504, i64 0
  %1507 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1508 = getelementptr inbounds nuw float, ptr %1507, i64 %1506
  %1509 = load float, ptr %1508, align 4
  %1510 = insertelement <8 x float> zeroinitializer, float %1509, i64 0
  %1511 = mul i64 %58, 8
  %1512 = add i64 %1511, 1
  %1513 = add i64 %84, %1512
  %1514 = icmp slt i64 %1513, %25
  %1515 = select i1 %1514, i64 %1513, i64 0
  %1516 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1517 = getelementptr inbounds nuw float, ptr %1516, i64 %1515
  %1518 = load float, ptr %1517, align 4
  %1519 = insertelement <8 x float> %1510, float %1518, i64 1
  %1520 = mul i64 %58, 8
  %1521 = add i64 %1520, 2
  %1522 = add i64 %84, %1521
  %1523 = icmp slt i64 %1522, %25
  %1524 = select i1 %1523, i64 %1522, i64 0
  %1525 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1526 = getelementptr inbounds nuw float, ptr %1525, i64 %1524
  %1527 = load float, ptr %1526, align 4
  %1528 = insertelement <8 x float> %1519, float %1527, i64 2
  %1529 = mul i64 %58, 8
  %1530 = add i64 %1529, 3
  %1531 = add i64 %84, %1530
  %1532 = icmp slt i64 %1531, %25
  %1533 = select i1 %1532, i64 %1531, i64 0
  %1534 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1535 = getelementptr inbounds nuw float, ptr %1534, i64 %1533
  %1536 = load float, ptr %1535, align 4
  %1537 = insertelement <8 x float> %1528, float %1536, i64 3
  %1538 = mul i64 %58, 8
  %1539 = add i64 %1538, 4
  %1540 = add i64 %84, %1539
  %1541 = icmp slt i64 %1540, %25
  %1542 = select i1 %1541, i64 %1540, i64 0
  %1543 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1544 = getelementptr inbounds nuw float, ptr %1543, i64 %1542
  %1545 = load float, ptr %1544, align 4
  %1546 = insertelement <8 x float> %1537, float %1545, i64 4
  %1547 = mul i64 %58, 8
  %1548 = add i64 %1547, 5
  %1549 = add i64 %84, %1548
  %1550 = icmp slt i64 %1549, %25
  %1551 = select i1 %1550, i64 %1549, i64 0
  %1552 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1553 = getelementptr inbounds nuw float, ptr %1552, i64 %1551
  %1554 = load float, ptr %1553, align 4
  %1555 = insertelement <8 x float> %1546, float %1554, i64 5
  %1556 = mul i64 %58, 8
  %1557 = add i64 %1556, 6
  %1558 = add i64 %84, %1557
  %1559 = icmp slt i64 %1558, %25
  %1560 = select i1 %1559, i64 %1558, i64 0
  %1561 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1562 = getelementptr inbounds nuw float, ptr %1561, i64 %1560
  %1563 = load float, ptr %1562, align 4
  %1564 = insertelement <8 x float> %1555, float %1563, i64 6
  %1565 = mul i64 %58, 8
  %1566 = add i64 %1565, 7
  %1567 = add i64 %84, %1566
  %1568 = icmp slt i64 %1567, %25
  %1569 = select i1 %1568, i64 %1567, i64 0
  %1570 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1571 = getelementptr inbounds nuw float, ptr %1570, i64 %1569
  %1572 = load float, ptr %1571, align 4
  %1573 = insertelement <8 x float> %1564, float %1572, i64 7
  br label %1574

1574:                                             ; preds = %1493, %1502
  %1575 = phi <8 x float> [ %1573, %1502 ], [ %1501, %1493 ]
  br label %1576

1576:                                             ; preds = %1574
  %1577 = add i64 %89, %57
  %1578 = icmp slt i64 %1577, %26
  %1579 = select i1 %1578, i64 %1577, i64 0
  %1580 = extractelement <8 x float> %1575, i64 0
  %1581 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1582 = getelementptr inbounds nuw i8, ptr %1581, i64 %1579
  %1583 = load i8, ptr %1582, align 1
  %1584 = zext i8 %1583 to i32
  %1585 = shl i32 %1584, 23
  %1586 = bitcast i32 %1585 to float
  %1587 = fmul float %1586, %1580
  %1588 = extractelement <8 x float> %162, i64 0
  %1589 = fmul float %1588, %1587
  %1590 = call float @llvm.fabs.f32(float %1587)
  %1591 = fcmp olt float %1590, +inf
  %1592 = fcmp one float %1587, 0.000000e+00
  %1593 = and i1 %1591, %1592
  %1594 = call i1 @llvm.expect.i1(i1 %1593, i1 true)
  br i1 %1594, label %1595, label %1596

1595:                                             ; preds = %1576
  br label %1608

1596:                                             ; preds = %1576
  %1597 = fpext float %1588 to double
  %1598 = fpext float %1586 to double
  %1599 = fpext float %1580 to double
  %1600 = fmul double %1597, %1598
  %1601 = fmul double %1600, %1599
  %1602 = fptrunc double %1601 to float
  %1603 = fcmp oeq float %1588, 0.000000e+00
  %1604 = call float @llvm.fabs.f32(float %1580)
  %1605 = fcmp olt float %1604, +inf
  %1606 = and i1 %1603, %1605
  %1607 = select i1 %1606, float 0.000000e+00, float %1602
  br label %1608

1608:                                             ; preds = %1595, %1596
  %1609 = phi float [ %1607, %1596 ], [ %1589, %1595 ]
  br label %1610

1610:                                             ; preds = %1608
  %1611 = add i64 %89, %57
  %1612 = icmp slt i64 %1611, %26
  %1613 = select i1 %1612, i64 %1611, i64 0
  %1614 = extractelement <8 x float> %1575, i64 1
  %1615 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1616 = getelementptr inbounds nuw i8, ptr %1615, i64 %1613
  %1617 = load i8, ptr %1616, align 1
  %1618 = zext i8 %1617 to i32
  %1619 = shl i32 %1618, 23
  %1620 = bitcast i32 %1619 to float
  %1621 = fmul float %1620, %1614
  %1622 = extractelement <8 x float> %162, i64 1
  %1623 = fmul float %1622, %1621
  %1624 = call float @llvm.fabs.f32(float %1621)
  %1625 = fcmp olt float %1624, +inf
  %1626 = fcmp one float %1621, 0.000000e+00
  %1627 = and i1 %1625, %1626
  %1628 = call i1 @llvm.expect.i1(i1 %1627, i1 true)
  br i1 %1628, label %1629, label %1630

1629:                                             ; preds = %1610
  br label %1642

1630:                                             ; preds = %1610
  %1631 = fpext float %1622 to double
  %1632 = fpext float %1620 to double
  %1633 = fpext float %1614 to double
  %1634 = fmul double %1631, %1632
  %1635 = fmul double %1634, %1633
  %1636 = fptrunc double %1635 to float
  %1637 = fcmp oeq float %1622, 0.000000e+00
  %1638 = call float @llvm.fabs.f32(float %1614)
  %1639 = fcmp olt float %1638, +inf
  %1640 = and i1 %1637, %1639
  %1641 = select i1 %1640, float 0.000000e+00, float %1636
  br label %1642

1642:                                             ; preds = %1629, %1630
  %1643 = phi float [ %1641, %1630 ], [ %1623, %1629 ]
  br label %1644

1644:                                             ; preds = %1642
  %1645 = add i64 %89, %57
  %1646 = icmp slt i64 %1645, %26
  %1647 = select i1 %1646, i64 %1645, i64 0
  %1648 = extractelement <8 x float> %1575, i64 2
  %1649 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1650 = getelementptr inbounds nuw i8, ptr %1649, i64 %1647
  %1651 = load i8, ptr %1650, align 1
  %1652 = zext i8 %1651 to i32
  %1653 = shl i32 %1652, 23
  %1654 = bitcast i32 %1653 to float
  %1655 = fmul float %1654, %1648
  %1656 = extractelement <8 x float> %162, i64 2
  %1657 = fmul float %1656, %1655
  %1658 = call float @llvm.fabs.f32(float %1655)
  %1659 = fcmp olt float %1658, +inf
  %1660 = fcmp one float %1655, 0.000000e+00
  %1661 = and i1 %1659, %1660
  %1662 = call i1 @llvm.expect.i1(i1 %1661, i1 true)
  br i1 %1662, label %1663, label %1664

1663:                                             ; preds = %1644
  br label %1676

1664:                                             ; preds = %1644
  %1665 = fpext float %1656 to double
  %1666 = fpext float %1654 to double
  %1667 = fpext float %1648 to double
  %1668 = fmul double %1665, %1666
  %1669 = fmul double %1668, %1667
  %1670 = fptrunc double %1669 to float
  %1671 = fcmp oeq float %1656, 0.000000e+00
  %1672 = call float @llvm.fabs.f32(float %1648)
  %1673 = fcmp olt float %1672, +inf
  %1674 = and i1 %1671, %1673
  %1675 = select i1 %1674, float 0.000000e+00, float %1670
  br label %1676

1676:                                             ; preds = %1663, %1664
  %1677 = phi float [ %1675, %1664 ], [ %1657, %1663 ]
  br label %1678

1678:                                             ; preds = %1676
  %1679 = add i64 %89, %57
  %1680 = icmp slt i64 %1679, %26
  %1681 = select i1 %1680, i64 %1679, i64 0
  %1682 = extractelement <8 x float> %1575, i64 3
  %1683 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1684 = getelementptr inbounds nuw i8, ptr %1683, i64 %1681
  %1685 = load i8, ptr %1684, align 1
  %1686 = zext i8 %1685 to i32
  %1687 = shl i32 %1686, 23
  %1688 = bitcast i32 %1687 to float
  %1689 = fmul float %1688, %1682
  %1690 = extractelement <8 x float> %162, i64 3
  %1691 = fmul float %1690, %1689
  %1692 = call float @llvm.fabs.f32(float %1689)
  %1693 = fcmp olt float %1692, +inf
  %1694 = fcmp one float %1689, 0.000000e+00
  %1695 = and i1 %1693, %1694
  %1696 = call i1 @llvm.expect.i1(i1 %1695, i1 true)
  br i1 %1696, label %1697, label %1698

1697:                                             ; preds = %1678
  br label %1710

1698:                                             ; preds = %1678
  %1699 = fpext float %1690 to double
  %1700 = fpext float %1688 to double
  %1701 = fpext float %1682 to double
  %1702 = fmul double %1699, %1700
  %1703 = fmul double %1702, %1701
  %1704 = fptrunc double %1703 to float
  %1705 = fcmp oeq float %1690, 0.000000e+00
  %1706 = call float @llvm.fabs.f32(float %1682)
  %1707 = fcmp olt float %1706, +inf
  %1708 = and i1 %1705, %1707
  %1709 = select i1 %1708, float 0.000000e+00, float %1704
  br label %1710

1710:                                             ; preds = %1697, %1698
  %1711 = phi float [ %1709, %1698 ], [ %1691, %1697 ]
  br label %1712

1712:                                             ; preds = %1710
  %1713 = add i64 %89, %57
  %1714 = icmp slt i64 %1713, %26
  %1715 = select i1 %1714, i64 %1713, i64 0
  %1716 = extractelement <8 x float> %1575, i64 4
  %1717 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1718 = getelementptr inbounds nuw i8, ptr %1717, i64 %1715
  %1719 = load i8, ptr %1718, align 1
  %1720 = zext i8 %1719 to i32
  %1721 = shl i32 %1720, 23
  %1722 = bitcast i32 %1721 to float
  %1723 = fmul float %1722, %1716
  %1724 = extractelement <8 x float> %162, i64 4
  %1725 = fmul float %1724, %1723
  %1726 = call float @llvm.fabs.f32(float %1723)
  %1727 = fcmp olt float %1726, +inf
  %1728 = fcmp one float %1723, 0.000000e+00
  %1729 = and i1 %1727, %1728
  %1730 = call i1 @llvm.expect.i1(i1 %1729, i1 true)
  br i1 %1730, label %1731, label %1732

1731:                                             ; preds = %1712
  br label %1744

1732:                                             ; preds = %1712
  %1733 = fpext float %1724 to double
  %1734 = fpext float %1722 to double
  %1735 = fpext float %1716 to double
  %1736 = fmul double %1733, %1734
  %1737 = fmul double %1736, %1735
  %1738 = fptrunc double %1737 to float
  %1739 = fcmp oeq float %1724, 0.000000e+00
  %1740 = call float @llvm.fabs.f32(float %1716)
  %1741 = fcmp olt float %1740, +inf
  %1742 = and i1 %1739, %1741
  %1743 = select i1 %1742, float 0.000000e+00, float %1738
  br label %1744

1744:                                             ; preds = %1731, %1732
  %1745 = phi float [ %1743, %1732 ], [ %1725, %1731 ]
  br label %1746

1746:                                             ; preds = %1744
  %1747 = add i64 %89, %57
  %1748 = icmp slt i64 %1747, %26
  %1749 = select i1 %1748, i64 %1747, i64 0
  %1750 = extractelement <8 x float> %1575, i64 5
  %1751 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1752 = getelementptr inbounds nuw i8, ptr %1751, i64 %1749
  %1753 = load i8, ptr %1752, align 1
  %1754 = zext i8 %1753 to i32
  %1755 = shl i32 %1754, 23
  %1756 = bitcast i32 %1755 to float
  %1757 = fmul float %1756, %1750
  %1758 = extractelement <8 x float> %162, i64 5
  %1759 = fmul float %1758, %1757
  %1760 = call float @llvm.fabs.f32(float %1757)
  %1761 = fcmp olt float %1760, +inf
  %1762 = fcmp one float %1757, 0.000000e+00
  %1763 = and i1 %1761, %1762
  %1764 = call i1 @llvm.expect.i1(i1 %1763, i1 true)
  br i1 %1764, label %1765, label %1766

1765:                                             ; preds = %1746
  br label %1778

1766:                                             ; preds = %1746
  %1767 = fpext float %1758 to double
  %1768 = fpext float %1756 to double
  %1769 = fpext float %1750 to double
  %1770 = fmul double %1767, %1768
  %1771 = fmul double %1770, %1769
  %1772 = fptrunc double %1771 to float
  %1773 = fcmp oeq float %1758, 0.000000e+00
  %1774 = call float @llvm.fabs.f32(float %1750)
  %1775 = fcmp olt float %1774, +inf
  %1776 = and i1 %1773, %1775
  %1777 = select i1 %1776, float 0.000000e+00, float %1772
  br label %1778

1778:                                             ; preds = %1765, %1766
  %1779 = phi float [ %1777, %1766 ], [ %1759, %1765 ]
  br label %1780

1780:                                             ; preds = %1778
  %1781 = add i64 %89, %57
  %1782 = icmp slt i64 %1781, %26
  %1783 = select i1 %1782, i64 %1781, i64 0
  %1784 = extractelement <8 x float> %1575, i64 6
  %1785 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1786 = getelementptr inbounds nuw i8, ptr %1785, i64 %1783
  %1787 = load i8, ptr %1786, align 1
  %1788 = zext i8 %1787 to i32
  %1789 = shl i32 %1788, 23
  %1790 = bitcast i32 %1789 to float
  %1791 = fmul float %1790, %1784
  %1792 = extractelement <8 x float> %162, i64 6
  %1793 = fmul float %1792, %1791
  %1794 = call float @llvm.fabs.f32(float %1791)
  %1795 = fcmp olt float %1794, +inf
  %1796 = fcmp one float %1791, 0.000000e+00
  %1797 = and i1 %1795, %1796
  %1798 = call i1 @llvm.expect.i1(i1 %1797, i1 true)
  br i1 %1798, label %1799, label %1800

1799:                                             ; preds = %1780
  br label %1812

1800:                                             ; preds = %1780
  %1801 = fpext float %1792 to double
  %1802 = fpext float %1790 to double
  %1803 = fpext float %1784 to double
  %1804 = fmul double %1801, %1802
  %1805 = fmul double %1804, %1803
  %1806 = fptrunc double %1805 to float
  %1807 = fcmp oeq float %1792, 0.000000e+00
  %1808 = call float @llvm.fabs.f32(float %1784)
  %1809 = fcmp olt float %1808, +inf
  %1810 = and i1 %1807, %1809
  %1811 = select i1 %1810, float 0.000000e+00, float %1806
  br label %1812

1812:                                             ; preds = %1799, %1800
  %1813 = phi float [ %1811, %1800 ], [ %1793, %1799 ]
  br label %1814

1814:                                             ; preds = %1812
  %1815 = add i64 %89, %57
  %1816 = icmp slt i64 %1815, %26
  %1817 = select i1 %1816, i64 %1815, i64 0
  %1818 = extractelement <8 x float> %1575, i64 7
  %1819 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1820 = getelementptr inbounds nuw i8, ptr %1819, i64 %1817
  %1821 = load i8, ptr %1820, align 1
  %1822 = zext i8 %1821 to i32
  %1823 = shl i32 %1822, 23
  %1824 = bitcast i32 %1823 to float
  %1825 = fmul float %1824, %1818
  %1826 = extractelement <8 x float> %162, i64 7
  %1827 = fmul float %1826, %1825
  %1828 = call float @llvm.fabs.f32(float %1825)
  %1829 = fcmp olt float %1828, +inf
  %1830 = fcmp one float %1825, 0.000000e+00
  %1831 = and i1 %1829, %1830
  %1832 = call i1 @llvm.expect.i1(i1 %1831, i1 true)
  br i1 %1832, label %1833, label %1834

1833:                                             ; preds = %1814
  br label %1846

1834:                                             ; preds = %1814
  %1835 = fpext float %1826 to double
  %1836 = fpext float %1824 to double
  %1837 = fpext float %1818 to double
  %1838 = fmul double %1835, %1836
  %1839 = fmul double %1838, %1837
  %1840 = fptrunc double %1839 to float
  %1841 = fcmp oeq float %1826, 0.000000e+00
  %1842 = call float @llvm.fabs.f32(float %1818)
  %1843 = fcmp olt float %1842, +inf
  %1844 = and i1 %1841, %1843
  %1845 = select i1 %1844, float 0.000000e+00, float %1840
  br label %1846

1846:                                             ; preds = %1833, %1834
  %1847 = phi float [ %1845, %1834 ], [ %1827, %1833 ]
  br label %1848

1848:                                             ; preds = %1846
  %1849 = mul i64 %59, 16
  %1850 = mul i64 %58, 8
  %1851 = add i64 %1849, %1850
  %1852 = mul i64 %1851, 40
  %1853 = add i64 %1852, %57
  %1854 = fptrunc float %1609 to bfloat
  %1855 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1853
  store bfloat %1854, ptr addrspace(3) %1855, align 2
  %1856 = mul i64 %58, 8
  %1857 = add i64 %1856, 1
  %1858 = add i64 %1849, %1857
  %1859 = mul i64 %1858, 40
  %1860 = add i64 %1859, %57
  %1861 = fptrunc float %1643 to bfloat
  %1862 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1860
  store bfloat %1861, ptr addrspace(3) %1862, align 2
  %1863 = mul i64 %58, 8
  %1864 = add i64 %1863, 2
  %1865 = add i64 %1849, %1864
  %1866 = mul i64 %1865, 40
  %1867 = add i64 %1866, %57
  %1868 = fptrunc float %1677 to bfloat
  %1869 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1867
  store bfloat %1868, ptr addrspace(3) %1869, align 2
  %1870 = mul i64 %58, 8
  %1871 = add i64 %1870, 3
  %1872 = add i64 %1849, %1871
  %1873 = mul i64 %1872, 40
  %1874 = add i64 %1873, %57
  %1875 = fptrunc float %1711 to bfloat
  %1876 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1874
  store bfloat %1875, ptr addrspace(3) %1876, align 2
  %1877 = mul i64 %58, 8
  %1878 = add i64 %1877, 4
  %1879 = add i64 %1849, %1878
  %1880 = mul i64 %1879, 40
  %1881 = add i64 %1880, %57
  %1882 = fptrunc float %1745 to bfloat
  %1883 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1881
  store bfloat %1882, ptr addrspace(3) %1883, align 2
  %1884 = mul i64 %58, 8
  %1885 = add i64 %1884, 5
  %1886 = add i64 %1849, %1885
  %1887 = mul i64 %1886, 40
  %1888 = add i64 %1887, %57
  %1889 = fptrunc float %1779 to bfloat
  %1890 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1888
  store bfloat %1889, ptr addrspace(3) %1890, align 2
  %1891 = mul i64 %58, 8
  %1892 = add i64 %1891, 6
  %1893 = add i64 %1849, %1892
  %1894 = mul i64 %1893, 40
  %1895 = add i64 %1894, %57
  %1896 = fptrunc float %1813 to bfloat
  %1897 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1895
  store bfloat %1896, ptr addrspace(3) %1897, align 2
  %1898 = mul i64 %58, 8
  %1899 = add i64 %1898, 7
  %1900 = add i64 %1849, %1899
  %1901 = mul i64 %1900, 40
  %1902 = add i64 %1901, %57
  %1903 = fptrunc float %1847 to bfloat
  %1904 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1902
  store bfloat %1903, ptr addrspace(3) %1904, align 2
  %1905 = mul i64 %58, 8
  %1906 = add i64 %84, %1905
  %1907 = add i64 %91, %57
  %1908 = add i64 %1906, 7
  %1909 = icmp ult i64 %1907, %26
  %1910 = icmp ult i64 %1908, %25
  %1911 = and i1 %1910, %1909
  %1912 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1913 = ptrtoint ptr %1912 to i64
  %1914 = mul i64 %1906, 4
  %1915 = add i64 %1913, %1914
  %1916 = urem i64 %1915, 16
  %1917 = icmp eq i64 %1916, 0
  %1918 = and i1 %1911, %1917
  br i1 %1918, label %1919, label %1928

1919:                                             ; preds = %1848
  %1920 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1921 = getelementptr float, ptr %1920, i64 %1906
  %1922 = load <4 x float>, ptr %1921, align 16
  %1923 = add i64 %1906, 4
  %1924 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1925 = getelementptr float, ptr %1924, i64 %1923
  %1926 = load <4 x float>, ptr %1925, align 16
  %1927 = shufflevector <4 x float> %1922, <4 x float> %1926, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2000

1928:                                             ; preds = %1848
  %1929 = mul i64 %58, 8
  %1930 = add i64 %84, %1929
  %1931 = icmp slt i64 %1930, %25
  %1932 = select i1 %1931, i64 %1930, i64 0
  %1933 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1934 = getelementptr inbounds nuw float, ptr %1933, i64 %1932
  %1935 = load float, ptr %1934, align 4
  %1936 = insertelement <8 x float> zeroinitializer, float %1935, i64 0
  %1937 = mul i64 %58, 8
  %1938 = add i64 %1937, 1
  %1939 = add i64 %84, %1938
  %1940 = icmp slt i64 %1939, %25
  %1941 = select i1 %1940, i64 %1939, i64 0
  %1942 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1943 = getelementptr inbounds nuw float, ptr %1942, i64 %1941
  %1944 = load float, ptr %1943, align 4
  %1945 = insertelement <8 x float> %1936, float %1944, i64 1
  %1946 = mul i64 %58, 8
  %1947 = add i64 %1946, 2
  %1948 = add i64 %84, %1947
  %1949 = icmp slt i64 %1948, %25
  %1950 = select i1 %1949, i64 %1948, i64 0
  %1951 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1952 = getelementptr inbounds nuw float, ptr %1951, i64 %1950
  %1953 = load float, ptr %1952, align 4
  %1954 = insertelement <8 x float> %1945, float %1953, i64 2
  %1955 = mul i64 %58, 8
  %1956 = add i64 %1955, 3
  %1957 = add i64 %84, %1956
  %1958 = icmp slt i64 %1957, %25
  %1959 = select i1 %1958, i64 %1957, i64 0
  %1960 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1961 = getelementptr inbounds nuw float, ptr %1960, i64 %1959
  %1962 = load float, ptr %1961, align 4
  %1963 = insertelement <8 x float> %1954, float %1962, i64 3
  %1964 = mul i64 %58, 8
  %1965 = add i64 %1964, 4
  %1966 = add i64 %84, %1965
  %1967 = icmp slt i64 %1966, %25
  %1968 = select i1 %1967, i64 %1966, i64 0
  %1969 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1970 = getelementptr inbounds nuw float, ptr %1969, i64 %1968
  %1971 = load float, ptr %1970, align 4
  %1972 = insertelement <8 x float> %1963, float %1971, i64 4
  %1973 = mul i64 %58, 8
  %1974 = add i64 %1973, 5
  %1975 = add i64 %84, %1974
  %1976 = icmp slt i64 %1975, %25
  %1977 = select i1 %1976, i64 %1975, i64 0
  %1978 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1979 = getelementptr inbounds nuw float, ptr %1978, i64 %1977
  %1980 = load float, ptr %1979, align 4
  %1981 = insertelement <8 x float> %1972, float %1980, i64 5
  %1982 = mul i64 %58, 8
  %1983 = add i64 %1982, 6
  %1984 = add i64 %84, %1983
  %1985 = icmp slt i64 %1984, %25
  %1986 = select i1 %1985, i64 %1984, i64 0
  %1987 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1988 = getelementptr inbounds nuw float, ptr %1987, i64 %1986
  %1989 = load float, ptr %1988, align 4
  %1990 = insertelement <8 x float> %1981, float %1989, i64 6
  %1991 = mul i64 %58, 8
  %1992 = add i64 %1991, 7
  %1993 = add i64 %84, %1992
  %1994 = icmp slt i64 %1993, %25
  %1995 = select i1 %1994, i64 %1993, i64 0
  %1996 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1997 = getelementptr inbounds nuw float, ptr %1996, i64 %1995
  %1998 = load float, ptr %1997, align 4
  %1999 = insertelement <8 x float> %1990, float %1998, i64 7
  br label %2000

2000:                                             ; preds = %1919, %1928
  %2001 = phi <8 x float> [ %1999, %1928 ], [ %1927, %1919 ]
  br label %2002

2002:                                             ; preds = %2000
  %2003 = add i64 %91, %57
  %2004 = icmp slt i64 %2003, %26
  %2005 = select i1 %2004, i64 %2003, i64 0
  %2006 = extractelement <8 x float> %2001, i64 0
  %2007 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2008 = getelementptr inbounds nuw i8, ptr %2007, i64 %2005
  %2009 = load i8, ptr %2008, align 1
  %2010 = zext i8 %2009 to i32
  %2011 = shl i32 %2010, 23
  %2012 = bitcast i32 %2011 to float
  %2013 = fmul float %2012, %2006
  %2014 = extractelement <8 x float> %163, i64 0
  %2015 = fmul float %2014, %2013
  %2016 = call float @llvm.fabs.f32(float %2013)
  %2017 = fcmp olt float %2016, +inf
  %2018 = fcmp one float %2013, 0.000000e+00
  %2019 = and i1 %2017, %2018
  %2020 = call i1 @llvm.expect.i1(i1 %2019, i1 true)
  br i1 %2020, label %2021, label %2022

2021:                                             ; preds = %2002
  br label %2034

2022:                                             ; preds = %2002
  %2023 = fpext float %2014 to double
  %2024 = fpext float %2012 to double
  %2025 = fpext float %2006 to double
  %2026 = fmul double %2023, %2024
  %2027 = fmul double %2026, %2025
  %2028 = fptrunc double %2027 to float
  %2029 = fcmp oeq float %2014, 0.000000e+00
  %2030 = call float @llvm.fabs.f32(float %2006)
  %2031 = fcmp olt float %2030, +inf
  %2032 = and i1 %2029, %2031
  %2033 = select i1 %2032, float 0.000000e+00, float %2028
  br label %2034

2034:                                             ; preds = %2021, %2022
  %2035 = phi float [ %2033, %2022 ], [ %2015, %2021 ]
  br label %2036

2036:                                             ; preds = %2034
  %2037 = add i64 %91, %57
  %2038 = icmp slt i64 %2037, %26
  %2039 = select i1 %2038, i64 %2037, i64 0
  %2040 = extractelement <8 x float> %2001, i64 1
  %2041 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2042 = getelementptr inbounds nuw i8, ptr %2041, i64 %2039
  %2043 = load i8, ptr %2042, align 1
  %2044 = zext i8 %2043 to i32
  %2045 = shl i32 %2044, 23
  %2046 = bitcast i32 %2045 to float
  %2047 = fmul float %2046, %2040
  %2048 = extractelement <8 x float> %163, i64 1
  %2049 = fmul float %2048, %2047
  %2050 = call float @llvm.fabs.f32(float %2047)
  %2051 = fcmp olt float %2050, +inf
  %2052 = fcmp one float %2047, 0.000000e+00
  %2053 = and i1 %2051, %2052
  %2054 = call i1 @llvm.expect.i1(i1 %2053, i1 true)
  br i1 %2054, label %2055, label %2056

2055:                                             ; preds = %2036
  br label %2068

2056:                                             ; preds = %2036
  %2057 = fpext float %2048 to double
  %2058 = fpext float %2046 to double
  %2059 = fpext float %2040 to double
  %2060 = fmul double %2057, %2058
  %2061 = fmul double %2060, %2059
  %2062 = fptrunc double %2061 to float
  %2063 = fcmp oeq float %2048, 0.000000e+00
  %2064 = call float @llvm.fabs.f32(float %2040)
  %2065 = fcmp olt float %2064, +inf
  %2066 = and i1 %2063, %2065
  %2067 = select i1 %2066, float 0.000000e+00, float %2062
  br label %2068

2068:                                             ; preds = %2055, %2056
  %2069 = phi float [ %2067, %2056 ], [ %2049, %2055 ]
  br label %2070

2070:                                             ; preds = %2068
  %2071 = add i64 %91, %57
  %2072 = icmp slt i64 %2071, %26
  %2073 = select i1 %2072, i64 %2071, i64 0
  %2074 = extractelement <8 x float> %2001, i64 2
  %2075 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2076 = getelementptr inbounds nuw i8, ptr %2075, i64 %2073
  %2077 = load i8, ptr %2076, align 1
  %2078 = zext i8 %2077 to i32
  %2079 = shl i32 %2078, 23
  %2080 = bitcast i32 %2079 to float
  %2081 = fmul float %2080, %2074
  %2082 = extractelement <8 x float> %163, i64 2
  %2083 = fmul float %2082, %2081
  %2084 = call float @llvm.fabs.f32(float %2081)
  %2085 = fcmp olt float %2084, +inf
  %2086 = fcmp one float %2081, 0.000000e+00
  %2087 = and i1 %2085, %2086
  %2088 = call i1 @llvm.expect.i1(i1 %2087, i1 true)
  br i1 %2088, label %2089, label %2090

2089:                                             ; preds = %2070
  br label %2102

2090:                                             ; preds = %2070
  %2091 = fpext float %2082 to double
  %2092 = fpext float %2080 to double
  %2093 = fpext float %2074 to double
  %2094 = fmul double %2091, %2092
  %2095 = fmul double %2094, %2093
  %2096 = fptrunc double %2095 to float
  %2097 = fcmp oeq float %2082, 0.000000e+00
  %2098 = call float @llvm.fabs.f32(float %2074)
  %2099 = fcmp olt float %2098, +inf
  %2100 = and i1 %2097, %2099
  %2101 = select i1 %2100, float 0.000000e+00, float %2096
  br label %2102

2102:                                             ; preds = %2089, %2090
  %2103 = phi float [ %2101, %2090 ], [ %2083, %2089 ]
  br label %2104

2104:                                             ; preds = %2102
  %2105 = add i64 %91, %57
  %2106 = icmp slt i64 %2105, %26
  %2107 = select i1 %2106, i64 %2105, i64 0
  %2108 = extractelement <8 x float> %2001, i64 3
  %2109 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2110 = getelementptr inbounds nuw i8, ptr %2109, i64 %2107
  %2111 = load i8, ptr %2110, align 1
  %2112 = zext i8 %2111 to i32
  %2113 = shl i32 %2112, 23
  %2114 = bitcast i32 %2113 to float
  %2115 = fmul float %2114, %2108
  %2116 = extractelement <8 x float> %163, i64 3
  %2117 = fmul float %2116, %2115
  %2118 = call float @llvm.fabs.f32(float %2115)
  %2119 = fcmp olt float %2118, +inf
  %2120 = fcmp one float %2115, 0.000000e+00
  %2121 = and i1 %2119, %2120
  %2122 = call i1 @llvm.expect.i1(i1 %2121, i1 true)
  br i1 %2122, label %2123, label %2124

2123:                                             ; preds = %2104
  br label %2136

2124:                                             ; preds = %2104
  %2125 = fpext float %2116 to double
  %2126 = fpext float %2114 to double
  %2127 = fpext float %2108 to double
  %2128 = fmul double %2125, %2126
  %2129 = fmul double %2128, %2127
  %2130 = fptrunc double %2129 to float
  %2131 = fcmp oeq float %2116, 0.000000e+00
  %2132 = call float @llvm.fabs.f32(float %2108)
  %2133 = fcmp olt float %2132, +inf
  %2134 = and i1 %2131, %2133
  %2135 = select i1 %2134, float 0.000000e+00, float %2130
  br label %2136

2136:                                             ; preds = %2123, %2124
  %2137 = phi float [ %2135, %2124 ], [ %2117, %2123 ]
  br label %2138

2138:                                             ; preds = %2136
  %2139 = add i64 %91, %57
  %2140 = icmp slt i64 %2139, %26
  %2141 = select i1 %2140, i64 %2139, i64 0
  %2142 = extractelement <8 x float> %2001, i64 4
  %2143 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2144 = getelementptr inbounds nuw i8, ptr %2143, i64 %2141
  %2145 = load i8, ptr %2144, align 1
  %2146 = zext i8 %2145 to i32
  %2147 = shl i32 %2146, 23
  %2148 = bitcast i32 %2147 to float
  %2149 = fmul float %2148, %2142
  %2150 = extractelement <8 x float> %163, i64 4
  %2151 = fmul float %2150, %2149
  %2152 = call float @llvm.fabs.f32(float %2149)
  %2153 = fcmp olt float %2152, +inf
  %2154 = fcmp one float %2149, 0.000000e+00
  %2155 = and i1 %2153, %2154
  %2156 = call i1 @llvm.expect.i1(i1 %2155, i1 true)
  br i1 %2156, label %2157, label %2158

2157:                                             ; preds = %2138
  br label %2170

2158:                                             ; preds = %2138
  %2159 = fpext float %2150 to double
  %2160 = fpext float %2148 to double
  %2161 = fpext float %2142 to double
  %2162 = fmul double %2159, %2160
  %2163 = fmul double %2162, %2161
  %2164 = fptrunc double %2163 to float
  %2165 = fcmp oeq float %2150, 0.000000e+00
  %2166 = call float @llvm.fabs.f32(float %2142)
  %2167 = fcmp olt float %2166, +inf
  %2168 = and i1 %2165, %2167
  %2169 = select i1 %2168, float 0.000000e+00, float %2164
  br label %2170

2170:                                             ; preds = %2157, %2158
  %2171 = phi float [ %2169, %2158 ], [ %2151, %2157 ]
  br label %2172

2172:                                             ; preds = %2170
  %2173 = add i64 %91, %57
  %2174 = icmp slt i64 %2173, %26
  %2175 = select i1 %2174, i64 %2173, i64 0
  %2176 = extractelement <8 x float> %2001, i64 5
  %2177 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2178 = getelementptr inbounds nuw i8, ptr %2177, i64 %2175
  %2179 = load i8, ptr %2178, align 1
  %2180 = zext i8 %2179 to i32
  %2181 = shl i32 %2180, 23
  %2182 = bitcast i32 %2181 to float
  %2183 = fmul float %2182, %2176
  %2184 = extractelement <8 x float> %163, i64 5
  %2185 = fmul float %2184, %2183
  %2186 = call float @llvm.fabs.f32(float %2183)
  %2187 = fcmp olt float %2186, +inf
  %2188 = fcmp one float %2183, 0.000000e+00
  %2189 = and i1 %2187, %2188
  %2190 = call i1 @llvm.expect.i1(i1 %2189, i1 true)
  br i1 %2190, label %2191, label %2192

2191:                                             ; preds = %2172
  br label %2204

2192:                                             ; preds = %2172
  %2193 = fpext float %2184 to double
  %2194 = fpext float %2182 to double
  %2195 = fpext float %2176 to double
  %2196 = fmul double %2193, %2194
  %2197 = fmul double %2196, %2195
  %2198 = fptrunc double %2197 to float
  %2199 = fcmp oeq float %2184, 0.000000e+00
  %2200 = call float @llvm.fabs.f32(float %2176)
  %2201 = fcmp olt float %2200, +inf
  %2202 = and i1 %2199, %2201
  %2203 = select i1 %2202, float 0.000000e+00, float %2198
  br label %2204

2204:                                             ; preds = %2191, %2192
  %2205 = phi float [ %2203, %2192 ], [ %2185, %2191 ]
  br label %2206

2206:                                             ; preds = %2204
  %2207 = add i64 %91, %57
  %2208 = icmp slt i64 %2207, %26
  %2209 = select i1 %2208, i64 %2207, i64 0
  %2210 = extractelement <8 x float> %2001, i64 6
  %2211 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2212 = getelementptr inbounds nuw i8, ptr %2211, i64 %2209
  %2213 = load i8, ptr %2212, align 1
  %2214 = zext i8 %2213 to i32
  %2215 = shl i32 %2214, 23
  %2216 = bitcast i32 %2215 to float
  %2217 = fmul float %2216, %2210
  %2218 = extractelement <8 x float> %163, i64 6
  %2219 = fmul float %2218, %2217
  %2220 = call float @llvm.fabs.f32(float %2217)
  %2221 = fcmp olt float %2220, +inf
  %2222 = fcmp one float %2217, 0.000000e+00
  %2223 = and i1 %2221, %2222
  %2224 = call i1 @llvm.expect.i1(i1 %2223, i1 true)
  br i1 %2224, label %2225, label %2226

2225:                                             ; preds = %2206
  br label %2238

2226:                                             ; preds = %2206
  %2227 = fpext float %2218 to double
  %2228 = fpext float %2216 to double
  %2229 = fpext float %2210 to double
  %2230 = fmul double %2227, %2228
  %2231 = fmul double %2230, %2229
  %2232 = fptrunc double %2231 to float
  %2233 = fcmp oeq float %2218, 0.000000e+00
  %2234 = call float @llvm.fabs.f32(float %2210)
  %2235 = fcmp olt float %2234, +inf
  %2236 = and i1 %2233, %2235
  %2237 = select i1 %2236, float 0.000000e+00, float %2232
  br label %2238

2238:                                             ; preds = %2225, %2226
  %2239 = phi float [ %2237, %2226 ], [ %2219, %2225 ]
  br label %2240

2240:                                             ; preds = %2238
  %2241 = add i64 %91, %57
  %2242 = icmp slt i64 %2241, %26
  %2243 = select i1 %2242, i64 %2241, i64 0
  %2244 = extractelement <8 x float> %2001, i64 7
  %2245 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2246 = getelementptr inbounds nuw i8, ptr %2245, i64 %2243
  %2247 = load i8, ptr %2246, align 1
  %2248 = zext i8 %2247 to i32
  %2249 = shl i32 %2248, 23
  %2250 = bitcast i32 %2249 to float
  %2251 = fmul float %2250, %2244
  %2252 = extractelement <8 x float> %163, i64 7
  %2253 = fmul float %2252, %2251
  %2254 = call float @llvm.fabs.f32(float %2251)
  %2255 = fcmp olt float %2254, +inf
  %2256 = fcmp one float %2251, 0.000000e+00
  %2257 = and i1 %2255, %2256
  %2258 = call i1 @llvm.expect.i1(i1 %2257, i1 true)
  br i1 %2258, label %2259, label %2260

2259:                                             ; preds = %2240
  br label %2272

2260:                                             ; preds = %2240
  %2261 = fpext float %2252 to double
  %2262 = fpext float %2250 to double
  %2263 = fpext float %2244 to double
  %2264 = fmul double %2261, %2262
  %2265 = fmul double %2264, %2263
  %2266 = fptrunc double %2265 to float
  %2267 = fcmp oeq float %2252, 0.000000e+00
  %2268 = call float @llvm.fabs.f32(float %2244)
  %2269 = fcmp olt float %2268, +inf
  %2270 = and i1 %2267, %2269
  %2271 = select i1 %2270, float 0.000000e+00, float %2266
  br label %2272

2272:                                             ; preds = %2259, %2260
  %2273 = phi float [ %2271, %2260 ], [ %2253, %2259 ]
  br label %2274

2274:                                             ; preds = %2272
  %2275 = mul i64 %59, 16
  %2276 = mul i64 %58, 8
  %2277 = add i64 %2275, %2276
  %2278 = add i64 %57, 16
  %2279 = mul i64 %2277, 40
  %2280 = add i64 %2279, %2278
  %2281 = fptrunc float %2035 to bfloat
  %2282 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2280
  store bfloat %2281, ptr addrspace(3) %2282, align 2
  %2283 = mul i64 %58, 8
  %2284 = add i64 %2283, 1
  %2285 = add i64 %2275, %2284
  %2286 = add i64 %57, 16
  %2287 = mul i64 %2285, 40
  %2288 = add i64 %2287, %2286
  %2289 = fptrunc float %2069 to bfloat
  %2290 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2288
  store bfloat %2289, ptr addrspace(3) %2290, align 2
  %2291 = mul i64 %58, 8
  %2292 = add i64 %2291, 2
  %2293 = add i64 %2275, %2292
  %2294 = add i64 %57, 16
  %2295 = mul i64 %2293, 40
  %2296 = add i64 %2295, %2294
  %2297 = fptrunc float %2103 to bfloat
  %2298 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2296
  store bfloat %2297, ptr addrspace(3) %2298, align 2
  %2299 = mul i64 %58, 8
  %2300 = add i64 %2299, 3
  %2301 = add i64 %2275, %2300
  %2302 = add i64 %57, 16
  %2303 = mul i64 %2301, 40
  %2304 = add i64 %2303, %2302
  %2305 = fptrunc float %2137 to bfloat
  %2306 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2304
  store bfloat %2305, ptr addrspace(3) %2306, align 2
  %2307 = mul i64 %58, 8
  %2308 = add i64 %2307, 4
  %2309 = add i64 %2275, %2308
  %2310 = add i64 %57, 16
  %2311 = mul i64 %2309, 40
  %2312 = add i64 %2311, %2310
  %2313 = fptrunc float %2171 to bfloat
  %2314 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2312
  store bfloat %2313, ptr addrspace(3) %2314, align 2
  %2315 = mul i64 %58, 8
  %2316 = add i64 %2315, 5
  %2317 = add i64 %2275, %2316
  %2318 = add i64 %57, 16
  %2319 = mul i64 %2317, 40
  %2320 = add i64 %2319, %2318
  %2321 = fptrunc float %2205 to bfloat
  %2322 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2320
  store bfloat %2321, ptr addrspace(3) %2322, align 2
  %2323 = mul i64 %58, 8
  %2324 = add i64 %2323, 6
  %2325 = add i64 %2275, %2324
  %2326 = add i64 %57, 16
  %2327 = mul i64 %2325, 40
  %2328 = add i64 %2327, %2326
  %2329 = fptrunc float %2239 to bfloat
  %2330 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2328
  store bfloat %2329, ptr addrspace(3) %2330, align 2
  %2331 = mul i64 %58, 8
  %2332 = add i64 %2331, 7
  %2333 = add i64 %2275, %2332
  %2334 = add i64 %57, 16
  %2335 = mul i64 %2333, 40
  %2336 = add i64 %2335, %2334
  %2337 = fptrunc float %2273 to bfloat
  %2338 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2336
  store bfloat %2337, ptr addrspace(3) %2338, align 2
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %2339 = urem i64 %55, 32
  %2340 = mul i64 %2339, 8
  %2341 = udiv i64 %2340, 32
  %2342 = urem i64 %2340, 32
  %2343 = mul i64 %59, 16
  %2344 = add i64 %2343, %2341
  %2345 = udiv i64 %59, 2
  %2346 = mul i64 %2345, 4
  %2347 = add i64 %2346, 1
  %2348 = mul i64 %2347, 16
  %2349 = add i64 %2341, %2348
  %2350 = add i64 %78, %2349
  %2351 = urem i64 %59, 2
  %2352 = mul i64 %2351, 32
  %2353 = add i64 %2342, %2352
  %2354 = add i64 %79, %2353
  %2355 = mul i64 %2344, 40
  %2356 = add i64 %2355, %2342
  %2357 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2356
  %2358 = load <8 x bfloat>, ptr addrspace(3) %2357, align 16
  %2359 = mul i64 %2350, %26
  %2360 = add i64 %2359, %2354
  %2361 = icmp ult i64 %2350, %25
  %2362 = add i64 %2354, 7
  %2363 = icmp ult i64 %2362, %26
  %2364 = and i1 %2361, %2363
  br i1 %2364, label %2365, label %2368

2365:                                             ; preds = %2274
  %2366 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2367 = getelementptr bfloat, ptr %2366, i64 %2360
  store <8 x bfloat> %2358, ptr %2367, align 2
  br label %2439

2368:                                             ; preds = %2274
  %2369 = icmp ult i64 %2354, %26
  %2370 = and i1 %2361, %2369
  br i1 %2370, label %2371, label %2375

2371:                                             ; preds = %2368
  %2372 = extractelement <8 x bfloat> %2358, i64 0
  %2373 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2374 = getelementptr inbounds nuw bfloat, ptr %2373, i64 %2360
  store bfloat %2372, ptr %2374, align 2
  br label %2375

2375:                                             ; preds = %2371, %2368
  %2376 = add i64 %2354, 1
  %2377 = icmp ult i64 %2376, %26
  %2378 = and i1 %2361, %2377
  br i1 %2378, label %2379, label %2384

2379:                                             ; preds = %2375
  %2380 = add i64 %2360, 1
  %2381 = extractelement <8 x bfloat> %2358, i64 1
  %2382 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2383 = getelementptr inbounds nuw bfloat, ptr %2382, i64 %2380
  store bfloat %2381, ptr %2383, align 2
  br label %2384

2384:                                             ; preds = %2379, %2375
  %2385 = add i64 %2354, 2
  %2386 = icmp ult i64 %2385, %26
  %2387 = and i1 %2361, %2386
  br i1 %2387, label %2388, label %2393

2388:                                             ; preds = %2384
  %2389 = add i64 %2360, 2
  %2390 = extractelement <8 x bfloat> %2358, i64 2
  %2391 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2392 = getelementptr inbounds nuw bfloat, ptr %2391, i64 %2389
  store bfloat %2390, ptr %2392, align 2
  br label %2393

2393:                                             ; preds = %2388, %2384
  %2394 = add i64 %2354, 3
  %2395 = icmp ult i64 %2394, %26
  %2396 = and i1 %2361, %2395
  br i1 %2396, label %2397, label %2402

2397:                                             ; preds = %2393
  %2398 = add i64 %2360, 3
  %2399 = extractelement <8 x bfloat> %2358, i64 3
  %2400 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2401 = getelementptr inbounds nuw bfloat, ptr %2400, i64 %2398
  store bfloat %2399, ptr %2401, align 2
  br label %2402

2402:                                             ; preds = %2397, %2393
  %2403 = add i64 %2354, 4
  %2404 = icmp ult i64 %2403, %26
  %2405 = and i1 %2361, %2404
  br i1 %2405, label %2406, label %2411

2406:                                             ; preds = %2402
  %2407 = add i64 %2360, 4
  %2408 = extractelement <8 x bfloat> %2358, i64 4
  %2409 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2410 = getelementptr inbounds nuw bfloat, ptr %2409, i64 %2407
  store bfloat %2408, ptr %2410, align 2
  br label %2411

2411:                                             ; preds = %2406, %2402
  %2412 = add i64 %2354, 5
  %2413 = icmp ult i64 %2412, %26
  %2414 = and i1 %2361, %2413
  br i1 %2414, label %2415, label %2420

2415:                                             ; preds = %2411
  %2416 = add i64 %2360, 5
  %2417 = extractelement <8 x bfloat> %2358, i64 5
  %2418 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2419 = getelementptr inbounds nuw bfloat, ptr %2418, i64 %2416
  store bfloat %2417, ptr %2419, align 2
  br label %2420

2420:                                             ; preds = %2415, %2411
  %2421 = add i64 %2354, 6
  %2422 = icmp ult i64 %2421, %26
  %2423 = and i1 %2361, %2422
  br i1 %2423, label %2424, label %2429

2424:                                             ; preds = %2420
  %2425 = add i64 %2360, 6
  %2426 = extractelement <8 x bfloat> %2358, i64 6
  %2427 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2428 = getelementptr inbounds nuw bfloat, ptr %2427, i64 %2425
  store bfloat %2426, ptr %2428, align 2
  br label %2429

2429:                                             ; preds = %2424, %2420
  %2430 = add i64 %2354, 7
  %2431 = icmp ult i64 %2430, %26
  %2432 = and i1 %2361, %2431
  br i1 %2432, label %2433, label %2438

2433:                                             ; preds = %2429
  %2434 = add i64 %2360, 7
  %2435 = extractelement <8 x bfloat> %2358, i64 7
  %2436 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2437 = getelementptr inbounds nuw bfloat, ptr %2436, i64 %2434
  store bfloat %2435, ptr %2437, align 2
  br label %2438

2438:                                             ; preds = %2433, %2429
  br label %2439

2439:                                             ; preds = %2365, %2438
  %2440 = urem i64 %55, 32
  %2441 = mul i64 %2440, 8
  %2442 = add i64 %2441, 256
  %2443 = udiv i64 %2442, 32
  %2444 = urem i64 %2442, 32
  %2445 = mul i64 %59, 16
  %2446 = add i64 %2445, %2443
  %2447 = udiv i64 %59, 2
  %2448 = mul i64 %2447, 4
  %2449 = add i64 %2448, 1
  %2450 = mul i64 %2449, 16
  %2451 = add i64 %2443, %2450
  %2452 = add i64 %78, %2451
  %2453 = urem i64 %59, 2
  %2454 = mul i64 %2453, 32
  %2455 = add i64 %2444, %2454
  %2456 = add i64 %79, %2455
  %2457 = mul i64 %2446, 40
  %2458 = add i64 %2457, %2444
  %2459 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2458
  %2460 = load <8 x bfloat>, ptr addrspace(3) %2459, align 16
  %2461 = mul i64 %2452, %26
  %2462 = add i64 %2461, %2456
  %2463 = icmp ult i64 %2452, %25
  %2464 = add i64 %2456, 7
  %2465 = icmp ult i64 %2464, %26
  %2466 = and i1 %2463, %2465
  br i1 %2466, label %2467, label %2470

2467:                                             ; preds = %2439
  %2468 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2469 = getelementptr bfloat, ptr %2468, i64 %2462
  store <8 x bfloat> %2460, ptr %2469, align 2
  br label %2541

2470:                                             ; preds = %2439
  %2471 = icmp ult i64 %2456, %26
  %2472 = and i1 %2463, %2471
  br i1 %2472, label %2473, label %2477

2473:                                             ; preds = %2470
  %2474 = extractelement <8 x bfloat> %2460, i64 0
  %2475 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2476 = getelementptr inbounds nuw bfloat, ptr %2475, i64 %2462
  store bfloat %2474, ptr %2476, align 2
  br label %2477

2477:                                             ; preds = %2473, %2470
  %2478 = add i64 %2456, 1
  %2479 = icmp ult i64 %2478, %26
  %2480 = and i1 %2463, %2479
  br i1 %2480, label %2481, label %2486

2481:                                             ; preds = %2477
  %2482 = add i64 %2462, 1
  %2483 = extractelement <8 x bfloat> %2460, i64 1
  %2484 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2485 = getelementptr inbounds nuw bfloat, ptr %2484, i64 %2482
  store bfloat %2483, ptr %2485, align 2
  br label %2486

2486:                                             ; preds = %2481, %2477
  %2487 = add i64 %2456, 2
  %2488 = icmp ult i64 %2487, %26
  %2489 = and i1 %2463, %2488
  br i1 %2489, label %2490, label %2495

2490:                                             ; preds = %2486
  %2491 = add i64 %2462, 2
  %2492 = extractelement <8 x bfloat> %2460, i64 2
  %2493 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2494 = getelementptr inbounds nuw bfloat, ptr %2493, i64 %2491
  store bfloat %2492, ptr %2494, align 2
  br label %2495

2495:                                             ; preds = %2490, %2486
  %2496 = add i64 %2456, 3
  %2497 = icmp ult i64 %2496, %26
  %2498 = and i1 %2463, %2497
  br i1 %2498, label %2499, label %2504

2499:                                             ; preds = %2495
  %2500 = add i64 %2462, 3
  %2501 = extractelement <8 x bfloat> %2460, i64 3
  %2502 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2503 = getelementptr inbounds nuw bfloat, ptr %2502, i64 %2500
  store bfloat %2501, ptr %2503, align 2
  br label %2504

2504:                                             ; preds = %2499, %2495
  %2505 = add i64 %2456, 4
  %2506 = icmp ult i64 %2505, %26
  %2507 = and i1 %2463, %2506
  br i1 %2507, label %2508, label %2513

2508:                                             ; preds = %2504
  %2509 = add i64 %2462, 4
  %2510 = extractelement <8 x bfloat> %2460, i64 4
  %2511 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2512 = getelementptr inbounds nuw bfloat, ptr %2511, i64 %2509
  store bfloat %2510, ptr %2512, align 2
  br label %2513

2513:                                             ; preds = %2508, %2504
  %2514 = add i64 %2456, 5
  %2515 = icmp ult i64 %2514, %26
  %2516 = and i1 %2463, %2515
  br i1 %2516, label %2517, label %2522

2517:                                             ; preds = %2513
  %2518 = add i64 %2462, 5
  %2519 = extractelement <8 x bfloat> %2460, i64 5
  %2520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2521 = getelementptr inbounds nuw bfloat, ptr %2520, i64 %2518
  store bfloat %2519, ptr %2521, align 2
  br label %2522

2522:                                             ; preds = %2517, %2513
  %2523 = add i64 %2456, 6
  %2524 = icmp ult i64 %2523, %26
  %2525 = and i1 %2463, %2524
  br i1 %2525, label %2526, label %2531

2526:                                             ; preds = %2522
  %2527 = add i64 %2462, 6
  %2528 = extractelement <8 x bfloat> %2460, i64 6
  %2529 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2530 = getelementptr inbounds nuw bfloat, ptr %2529, i64 %2527
  store bfloat %2528, ptr %2530, align 2
  br label %2531

2531:                                             ; preds = %2526, %2522
  %2532 = add i64 %2456, 7
  %2533 = icmp ult i64 %2532, %26
  %2534 = and i1 %2463, %2533
  br i1 %2534, label %2535, label %2540

2535:                                             ; preds = %2531
  %2536 = add i64 %2462, 7
  %2537 = extractelement <8 x bfloat> %2460, i64 7
  %2538 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2539 = getelementptr inbounds nuw bfloat, ptr %2538, i64 %2536
  store bfloat %2537, ptr %2539, align 2
  br label %2540

2540:                                             ; preds = %2535, %2531
  br label %2541

2541:                                             ; preds = %2467, %2540
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %2542 = mul i64 %58, 8
  %2543 = add i64 %86, %2542
  %2544 = add i64 %89, %57
  %2545 = add i64 %2543, 7
  %2546 = icmp ult i64 %2544, %26
  %2547 = icmp ult i64 %2545, %25
  %2548 = and i1 %2547, %2546
  %2549 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2550 = ptrtoint ptr %2549 to i64
  %2551 = mul i64 %2543, 4
  %2552 = add i64 %2550, %2551
  %2553 = urem i64 %2552, 16
  %2554 = icmp eq i64 %2553, 0
  %2555 = and i1 %2548, %2554
  br i1 %2555, label %2556, label %2565

2556:                                             ; preds = %2541
  %2557 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2558 = getelementptr float, ptr %2557, i64 %2543
  %2559 = load <4 x float>, ptr %2558, align 16
  %2560 = add i64 %2543, 4
  %2561 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2562 = getelementptr float, ptr %2561, i64 %2560
  %2563 = load <4 x float>, ptr %2562, align 16
  %2564 = shufflevector <4 x float> %2559, <4 x float> %2563, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2637

2565:                                             ; preds = %2541
  %2566 = mul i64 %58, 8
  %2567 = add i64 %86, %2566
  %2568 = icmp slt i64 %2567, %25
  %2569 = select i1 %2568, i64 %2567, i64 0
  %2570 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2571 = getelementptr inbounds nuw float, ptr %2570, i64 %2569
  %2572 = load float, ptr %2571, align 4
  %2573 = insertelement <8 x float> zeroinitializer, float %2572, i64 0
  %2574 = mul i64 %58, 8
  %2575 = add i64 %2574, 1
  %2576 = add i64 %86, %2575
  %2577 = icmp slt i64 %2576, %25
  %2578 = select i1 %2577, i64 %2576, i64 0
  %2579 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2580 = getelementptr inbounds nuw float, ptr %2579, i64 %2578
  %2581 = load float, ptr %2580, align 4
  %2582 = insertelement <8 x float> %2573, float %2581, i64 1
  %2583 = mul i64 %58, 8
  %2584 = add i64 %2583, 2
  %2585 = add i64 %86, %2584
  %2586 = icmp slt i64 %2585, %25
  %2587 = select i1 %2586, i64 %2585, i64 0
  %2588 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2589 = getelementptr inbounds nuw float, ptr %2588, i64 %2587
  %2590 = load float, ptr %2589, align 4
  %2591 = insertelement <8 x float> %2582, float %2590, i64 2
  %2592 = mul i64 %58, 8
  %2593 = add i64 %2592, 3
  %2594 = add i64 %86, %2593
  %2595 = icmp slt i64 %2594, %25
  %2596 = select i1 %2595, i64 %2594, i64 0
  %2597 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2598 = getelementptr inbounds nuw float, ptr %2597, i64 %2596
  %2599 = load float, ptr %2598, align 4
  %2600 = insertelement <8 x float> %2591, float %2599, i64 3
  %2601 = mul i64 %58, 8
  %2602 = add i64 %2601, 4
  %2603 = add i64 %86, %2602
  %2604 = icmp slt i64 %2603, %25
  %2605 = select i1 %2604, i64 %2603, i64 0
  %2606 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2607 = getelementptr inbounds nuw float, ptr %2606, i64 %2605
  %2608 = load float, ptr %2607, align 4
  %2609 = insertelement <8 x float> %2600, float %2608, i64 4
  %2610 = mul i64 %58, 8
  %2611 = add i64 %2610, 5
  %2612 = add i64 %86, %2611
  %2613 = icmp slt i64 %2612, %25
  %2614 = select i1 %2613, i64 %2612, i64 0
  %2615 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2616 = getelementptr inbounds nuw float, ptr %2615, i64 %2614
  %2617 = load float, ptr %2616, align 4
  %2618 = insertelement <8 x float> %2609, float %2617, i64 5
  %2619 = mul i64 %58, 8
  %2620 = add i64 %2619, 6
  %2621 = add i64 %86, %2620
  %2622 = icmp slt i64 %2621, %25
  %2623 = select i1 %2622, i64 %2621, i64 0
  %2624 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2625 = getelementptr inbounds nuw float, ptr %2624, i64 %2623
  %2626 = load float, ptr %2625, align 4
  %2627 = insertelement <8 x float> %2618, float %2626, i64 6
  %2628 = mul i64 %58, 8
  %2629 = add i64 %2628, 7
  %2630 = add i64 %86, %2629
  %2631 = icmp slt i64 %2630, %25
  %2632 = select i1 %2631, i64 %2630, i64 0
  %2633 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2634 = getelementptr inbounds nuw float, ptr %2633, i64 %2632
  %2635 = load float, ptr %2634, align 4
  %2636 = insertelement <8 x float> %2627, float %2635, i64 7
  br label %2637

2637:                                             ; preds = %2556, %2565
  %2638 = phi <8 x float> [ %2636, %2565 ], [ %2564, %2556 ]
  br label %2639

2639:                                             ; preds = %2637
  %2640 = add i64 %89, %57
  %2641 = icmp slt i64 %2640, %26
  %2642 = select i1 %2641, i64 %2640, i64 0
  %2643 = extractelement <8 x float> %2638, i64 0
  %2644 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2645 = getelementptr inbounds nuw i8, ptr %2644, i64 %2642
  %2646 = load i8, ptr %2645, align 1
  %2647 = zext i8 %2646 to i32
  %2648 = shl i32 %2647, 23
  %2649 = bitcast i32 %2648 to float
  %2650 = fmul float %2649, %2643
  %2651 = extractelement <8 x float> %164, i64 0
  %2652 = fmul float %2651, %2650
  %2653 = call float @llvm.fabs.f32(float %2650)
  %2654 = fcmp olt float %2653, +inf
  %2655 = fcmp one float %2650, 0.000000e+00
  %2656 = and i1 %2654, %2655
  %2657 = call i1 @llvm.expect.i1(i1 %2656, i1 true)
  br i1 %2657, label %2658, label %2659

2658:                                             ; preds = %2639
  br label %2671

2659:                                             ; preds = %2639
  %2660 = fpext float %2651 to double
  %2661 = fpext float %2649 to double
  %2662 = fpext float %2643 to double
  %2663 = fmul double %2660, %2661
  %2664 = fmul double %2663, %2662
  %2665 = fptrunc double %2664 to float
  %2666 = fcmp oeq float %2651, 0.000000e+00
  %2667 = call float @llvm.fabs.f32(float %2643)
  %2668 = fcmp olt float %2667, +inf
  %2669 = and i1 %2666, %2668
  %2670 = select i1 %2669, float 0.000000e+00, float %2665
  br label %2671

2671:                                             ; preds = %2658, %2659
  %2672 = phi float [ %2670, %2659 ], [ %2652, %2658 ]
  br label %2673

2673:                                             ; preds = %2671
  %2674 = add i64 %89, %57
  %2675 = icmp slt i64 %2674, %26
  %2676 = select i1 %2675, i64 %2674, i64 0
  %2677 = extractelement <8 x float> %2638, i64 1
  %2678 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2679 = getelementptr inbounds nuw i8, ptr %2678, i64 %2676
  %2680 = load i8, ptr %2679, align 1
  %2681 = zext i8 %2680 to i32
  %2682 = shl i32 %2681, 23
  %2683 = bitcast i32 %2682 to float
  %2684 = fmul float %2683, %2677
  %2685 = extractelement <8 x float> %164, i64 1
  %2686 = fmul float %2685, %2684
  %2687 = call float @llvm.fabs.f32(float %2684)
  %2688 = fcmp olt float %2687, +inf
  %2689 = fcmp one float %2684, 0.000000e+00
  %2690 = and i1 %2688, %2689
  %2691 = call i1 @llvm.expect.i1(i1 %2690, i1 true)
  br i1 %2691, label %2692, label %2693

2692:                                             ; preds = %2673
  br label %2705

2693:                                             ; preds = %2673
  %2694 = fpext float %2685 to double
  %2695 = fpext float %2683 to double
  %2696 = fpext float %2677 to double
  %2697 = fmul double %2694, %2695
  %2698 = fmul double %2697, %2696
  %2699 = fptrunc double %2698 to float
  %2700 = fcmp oeq float %2685, 0.000000e+00
  %2701 = call float @llvm.fabs.f32(float %2677)
  %2702 = fcmp olt float %2701, +inf
  %2703 = and i1 %2700, %2702
  %2704 = select i1 %2703, float 0.000000e+00, float %2699
  br label %2705

2705:                                             ; preds = %2692, %2693
  %2706 = phi float [ %2704, %2693 ], [ %2686, %2692 ]
  br label %2707

2707:                                             ; preds = %2705
  %2708 = add i64 %89, %57
  %2709 = icmp slt i64 %2708, %26
  %2710 = select i1 %2709, i64 %2708, i64 0
  %2711 = extractelement <8 x float> %2638, i64 2
  %2712 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2713 = getelementptr inbounds nuw i8, ptr %2712, i64 %2710
  %2714 = load i8, ptr %2713, align 1
  %2715 = zext i8 %2714 to i32
  %2716 = shl i32 %2715, 23
  %2717 = bitcast i32 %2716 to float
  %2718 = fmul float %2717, %2711
  %2719 = extractelement <8 x float> %164, i64 2
  %2720 = fmul float %2719, %2718
  %2721 = call float @llvm.fabs.f32(float %2718)
  %2722 = fcmp olt float %2721, +inf
  %2723 = fcmp one float %2718, 0.000000e+00
  %2724 = and i1 %2722, %2723
  %2725 = call i1 @llvm.expect.i1(i1 %2724, i1 true)
  br i1 %2725, label %2726, label %2727

2726:                                             ; preds = %2707
  br label %2739

2727:                                             ; preds = %2707
  %2728 = fpext float %2719 to double
  %2729 = fpext float %2717 to double
  %2730 = fpext float %2711 to double
  %2731 = fmul double %2728, %2729
  %2732 = fmul double %2731, %2730
  %2733 = fptrunc double %2732 to float
  %2734 = fcmp oeq float %2719, 0.000000e+00
  %2735 = call float @llvm.fabs.f32(float %2711)
  %2736 = fcmp olt float %2735, +inf
  %2737 = and i1 %2734, %2736
  %2738 = select i1 %2737, float 0.000000e+00, float %2733
  br label %2739

2739:                                             ; preds = %2726, %2727
  %2740 = phi float [ %2738, %2727 ], [ %2720, %2726 ]
  br label %2741

2741:                                             ; preds = %2739
  %2742 = add i64 %89, %57
  %2743 = icmp slt i64 %2742, %26
  %2744 = select i1 %2743, i64 %2742, i64 0
  %2745 = extractelement <8 x float> %2638, i64 3
  %2746 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2747 = getelementptr inbounds nuw i8, ptr %2746, i64 %2744
  %2748 = load i8, ptr %2747, align 1
  %2749 = zext i8 %2748 to i32
  %2750 = shl i32 %2749, 23
  %2751 = bitcast i32 %2750 to float
  %2752 = fmul float %2751, %2745
  %2753 = extractelement <8 x float> %164, i64 3
  %2754 = fmul float %2753, %2752
  %2755 = call float @llvm.fabs.f32(float %2752)
  %2756 = fcmp olt float %2755, +inf
  %2757 = fcmp one float %2752, 0.000000e+00
  %2758 = and i1 %2756, %2757
  %2759 = call i1 @llvm.expect.i1(i1 %2758, i1 true)
  br i1 %2759, label %2760, label %2761

2760:                                             ; preds = %2741
  br label %2773

2761:                                             ; preds = %2741
  %2762 = fpext float %2753 to double
  %2763 = fpext float %2751 to double
  %2764 = fpext float %2745 to double
  %2765 = fmul double %2762, %2763
  %2766 = fmul double %2765, %2764
  %2767 = fptrunc double %2766 to float
  %2768 = fcmp oeq float %2753, 0.000000e+00
  %2769 = call float @llvm.fabs.f32(float %2745)
  %2770 = fcmp olt float %2769, +inf
  %2771 = and i1 %2768, %2770
  %2772 = select i1 %2771, float 0.000000e+00, float %2767
  br label %2773

2773:                                             ; preds = %2760, %2761
  %2774 = phi float [ %2772, %2761 ], [ %2754, %2760 ]
  br label %2775

2775:                                             ; preds = %2773
  %2776 = add i64 %89, %57
  %2777 = icmp slt i64 %2776, %26
  %2778 = select i1 %2777, i64 %2776, i64 0
  %2779 = extractelement <8 x float> %2638, i64 4
  %2780 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2781 = getelementptr inbounds nuw i8, ptr %2780, i64 %2778
  %2782 = load i8, ptr %2781, align 1
  %2783 = zext i8 %2782 to i32
  %2784 = shl i32 %2783, 23
  %2785 = bitcast i32 %2784 to float
  %2786 = fmul float %2785, %2779
  %2787 = extractelement <8 x float> %164, i64 4
  %2788 = fmul float %2787, %2786
  %2789 = call float @llvm.fabs.f32(float %2786)
  %2790 = fcmp olt float %2789, +inf
  %2791 = fcmp one float %2786, 0.000000e+00
  %2792 = and i1 %2790, %2791
  %2793 = call i1 @llvm.expect.i1(i1 %2792, i1 true)
  br i1 %2793, label %2794, label %2795

2794:                                             ; preds = %2775
  br label %2807

2795:                                             ; preds = %2775
  %2796 = fpext float %2787 to double
  %2797 = fpext float %2785 to double
  %2798 = fpext float %2779 to double
  %2799 = fmul double %2796, %2797
  %2800 = fmul double %2799, %2798
  %2801 = fptrunc double %2800 to float
  %2802 = fcmp oeq float %2787, 0.000000e+00
  %2803 = call float @llvm.fabs.f32(float %2779)
  %2804 = fcmp olt float %2803, +inf
  %2805 = and i1 %2802, %2804
  %2806 = select i1 %2805, float 0.000000e+00, float %2801
  br label %2807

2807:                                             ; preds = %2794, %2795
  %2808 = phi float [ %2806, %2795 ], [ %2788, %2794 ]
  br label %2809

2809:                                             ; preds = %2807
  %2810 = add i64 %89, %57
  %2811 = icmp slt i64 %2810, %26
  %2812 = select i1 %2811, i64 %2810, i64 0
  %2813 = extractelement <8 x float> %2638, i64 5
  %2814 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2815 = getelementptr inbounds nuw i8, ptr %2814, i64 %2812
  %2816 = load i8, ptr %2815, align 1
  %2817 = zext i8 %2816 to i32
  %2818 = shl i32 %2817, 23
  %2819 = bitcast i32 %2818 to float
  %2820 = fmul float %2819, %2813
  %2821 = extractelement <8 x float> %164, i64 5
  %2822 = fmul float %2821, %2820
  %2823 = call float @llvm.fabs.f32(float %2820)
  %2824 = fcmp olt float %2823, +inf
  %2825 = fcmp one float %2820, 0.000000e+00
  %2826 = and i1 %2824, %2825
  %2827 = call i1 @llvm.expect.i1(i1 %2826, i1 true)
  br i1 %2827, label %2828, label %2829

2828:                                             ; preds = %2809
  br label %2841

2829:                                             ; preds = %2809
  %2830 = fpext float %2821 to double
  %2831 = fpext float %2819 to double
  %2832 = fpext float %2813 to double
  %2833 = fmul double %2830, %2831
  %2834 = fmul double %2833, %2832
  %2835 = fptrunc double %2834 to float
  %2836 = fcmp oeq float %2821, 0.000000e+00
  %2837 = call float @llvm.fabs.f32(float %2813)
  %2838 = fcmp olt float %2837, +inf
  %2839 = and i1 %2836, %2838
  %2840 = select i1 %2839, float 0.000000e+00, float %2835
  br label %2841

2841:                                             ; preds = %2828, %2829
  %2842 = phi float [ %2840, %2829 ], [ %2822, %2828 ]
  br label %2843

2843:                                             ; preds = %2841
  %2844 = add i64 %89, %57
  %2845 = icmp slt i64 %2844, %26
  %2846 = select i1 %2845, i64 %2844, i64 0
  %2847 = extractelement <8 x float> %2638, i64 6
  %2848 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2849 = getelementptr inbounds nuw i8, ptr %2848, i64 %2846
  %2850 = load i8, ptr %2849, align 1
  %2851 = zext i8 %2850 to i32
  %2852 = shl i32 %2851, 23
  %2853 = bitcast i32 %2852 to float
  %2854 = fmul float %2853, %2847
  %2855 = extractelement <8 x float> %164, i64 6
  %2856 = fmul float %2855, %2854
  %2857 = call float @llvm.fabs.f32(float %2854)
  %2858 = fcmp olt float %2857, +inf
  %2859 = fcmp one float %2854, 0.000000e+00
  %2860 = and i1 %2858, %2859
  %2861 = call i1 @llvm.expect.i1(i1 %2860, i1 true)
  br i1 %2861, label %2862, label %2863

2862:                                             ; preds = %2843
  br label %2875

2863:                                             ; preds = %2843
  %2864 = fpext float %2855 to double
  %2865 = fpext float %2853 to double
  %2866 = fpext float %2847 to double
  %2867 = fmul double %2864, %2865
  %2868 = fmul double %2867, %2866
  %2869 = fptrunc double %2868 to float
  %2870 = fcmp oeq float %2855, 0.000000e+00
  %2871 = call float @llvm.fabs.f32(float %2847)
  %2872 = fcmp olt float %2871, +inf
  %2873 = and i1 %2870, %2872
  %2874 = select i1 %2873, float 0.000000e+00, float %2869
  br label %2875

2875:                                             ; preds = %2862, %2863
  %2876 = phi float [ %2874, %2863 ], [ %2856, %2862 ]
  br label %2877

2877:                                             ; preds = %2875
  %2878 = add i64 %89, %57
  %2879 = icmp slt i64 %2878, %26
  %2880 = select i1 %2879, i64 %2878, i64 0
  %2881 = extractelement <8 x float> %2638, i64 7
  %2882 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2883 = getelementptr inbounds nuw i8, ptr %2882, i64 %2880
  %2884 = load i8, ptr %2883, align 1
  %2885 = zext i8 %2884 to i32
  %2886 = shl i32 %2885, 23
  %2887 = bitcast i32 %2886 to float
  %2888 = fmul float %2887, %2881
  %2889 = extractelement <8 x float> %164, i64 7
  %2890 = fmul float %2889, %2888
  %2891 = call float @llvm.fabs.f32(float %2888)
  %2892 = fcmp olt float %2891, +inf
  %2893 = fcmp one float %2888, 0.000000e+00
  %2894 = and i1 %2892, %2893
  %2895 = call i1 @llvm.expect.i1(i1 %2894, i1 true)
  br i1 %2895, label %2896, label %2897

2896:                                             ; preds = %2877
  br label %2909

2897:                                             ; preds = %2877
  %2898 = fpext float %2889 to double
  %2899 = fpext float %2887 to double
  %2900 = fpext float %2881 to double
  %2901 = fmul double %2898, %2899
  %2902 = fmul double %2901, %2900
  %2903 = fptrunc double %2902 to float
  %2904 = fcmp oeq float %2889, 0.000000e+00
  %2905 = call float @llvm.fabs.f32(float %2881)
  %2906 = fcmp olt float %2905, +inf
  %2907 = and i1 %2904, %2906
  %2908 = select i1 %2907, float 0.000000e+00, float %2903
  br label %2909

2909:                                             ; preds = %2896, %2897
  %2910 = phi float [ %2908, %2897 ], [ %2890, %2896 ]
  br label %2911

2911:                                             ; preds = %2909
  %2912 = mul i64 %59, 16
  %2913 = mul i64 %58, 8
  %2914 = add i64 %2912, %2913
  %2915 = mul i64 %2914, 40
  %2916 = add i64 %2915, %57
  %2917 = fptrunc float %2672 to bfloat
  %2918 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2916
  store bfloat %2917, ptr addrspace(3) %2918, align 2
  %2919 = mul i64 %58, 8
  %2920 = add i64 %2919, 1
  %2921 = add i64 %2912, %2920
  %2922 = mul i64 %2921, 40
  %2923 = add i64 %2922, %57
  %2924 = fptrunc float %2706 to bfloat
  %2925 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2923
  store bfloat %2924, ptr addrspace(3) %2925, align 2
  %2926 = mul i64 %58, 8
  %2927 = add i64 %2926, 2
  %2928 = add i64 %2912, %2927
  %2929 = mul i64 %2928, 40
  %2930 = add i64 %2929, %57
  %2931 = fptrunc float %2740 to bfloat
  %2932 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2930
  store bfloat %2931, ptr addrspace(3) %2932, align 2
  %2933 = mul i64 %58, 8
  %2934 = add i64 %2933, 3
  %2935 = add i64 %2912, %2934
  %2936 = mul i64 %2935, 40
  %2937 = add i64 %2936, %57
  %2938 = fptrunc float %2774 to bfloat
  %2939 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2937
  store bfloat %2938, ptr addrspace(3) %2939, align 2
  %2940 = mul i64 %58, 8
  %2941 = add i64 %2940, 4
  %2942 = add i64 %2912, %2941
  %2943 = mul i64 %2942, 40
  %2944 = add i64 %2943, %57
  %2945 = fptrunc float %2808 to bfloat
  %2946 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2944
  store bfloat %2945, ptr addrspace(3) %2946, align 2
  %2947 = mul i64 %58, 8
  %2948 = add i64 %2947, 5
  %2949 = add i64 %2912, %2948
  %2950 = mul i64 %2949, 40
  %2951 = add i64 %2950, %57
  %2952 = fptrunc float %2842 to bfloat
  %2953 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2951
  store bfloat %2952, ptr addrspace(3) %2953, align 2
  %2954 = mul i64 %58, 8
  %2955 = add i64 %2954, 6
  %2956 = add i64 %2912, %2955
  %2957 = mul i64 %2956, 40
  %2958 = add i64 %2957, %57
  %2959 = fptrunc float %2876 to bfloat
  %2960 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2958
  store bfloat %2959, ptr addrspace(3) %2960, align 2
  %2961 = mul i64 %58, 8
  %2962 = add i64 %2961, 7
  %2963 = add i64 %2912, %2962
  %2964 = mul i64 %2963, 40
  %2965 = add i64 %2964, %57
  %2966 = fptrunc float %2910 to bfloat
  %2967 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2965
  store bfloat %2966, ptr addrspace(3) %2967, align 2
  %2968 = mul i64 %58, 8
  %2969 = add i64 %86, %2968
  %2970 = add i64 %91, %57
  %2971 = add i64 %2969, 7
  %2972 = icmp ult i64 %2970, %26
  %2973 = icmp ult i64 %2971, %25
  %2974 = and i1 %2973, %2972
  %2975 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2976 = ptrtoint ptr %2975 to i64
  %2977 = mul i64 %2969, 4
  %2978 = add i64 %2976, %2977
  %2979 = urem i64 %2978, 16
  %2980 = icmp eq i64 %2979, 0
  %2981 = and i1 %2974, %2980
  br i1 %2981, label %2982, label %2991

2982:                                             ; preds = %2911
  %2983 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2984 = getelementptr float, ptr %2983, i64 %2969
  %2985 = load <4 x float>, ptr %2984, align 16
  %2986 = add i64 %2969, 4
  %2987 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2988 = getelementptr float, ptr %2987, i64 %2986
  %2989 = load <4 x float>, ptr %2988, align 16
  %2990 = shufflevector <4 x float> %2985, <4 x float> %2989, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3063

2991:                                             ; preds = %2911
  %2992 = mul i64 %58, 8
  %2993 = add i64 %86, %2992
  %2994 = icmp slt i64 %2993, %25
  %2995 = select i1 %2994, i64 %2993, i64 0
  %2996 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2997 = getelementptr inbounds nuw float, ptr %2996, i64 %2995
  %2998 = load float, ptr %2997, align 4
  %2999 = insertelement <8 x float> zeroinitializer, float %2998, i64 0
  %3000 = mul i64 %58, 8
  %3001 = add i64 %3000, 1
  %3002 = add i64 %86, %3001
  %3003 = icmp slt i64 %3002, %25
  %3004 = select i1 %3003, i64 %3002, i64 0
  %3005 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3006 = getelementptr inbounds nuw float, ptr %3005, i64 %3004
  %3007 = load float, ptr %3006, align 4
  %3008 = insertelement <8 x float> %2999, float %3007, i64 1
  %3009 = mul i64 %58, 8
  %3010 = add i64 %3009, 2
  %3011 = add i64 %86, %3010
  %3012 = icmp slt i64 %3011, %25
  %3013 = select i1 %3012, i64 %3011, i64 0
  %3014 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3015 = getelementptr inbounds nuw float, ptr %3014, i64 %3013
  %3016 = load float, ptr %3015, align 4
  %3017 = insertelement <8 x float> %3008, float %3016, i64 2
  %3018 = mul i64 %58, 8
  %3019 = add i64 %3018, 3
  %3020 = add i64 %86, %3019
  %3021 = icmp slt i64 %3020, %25
  %3022 = select i1 %3021, i64 %3020, i64 0
  %3023 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3024 = getelementptr inbounds nuw float, ptr %3023, i64 %3022
  %3025 = load float, ptr %3024, align 4
  %3026 = insertelement <8 x float> %3017, float %3025, i64 3
  %3027 = mul i64 %58, 8
  %3028 = add i64 %3027, 4
  %3029 = add i64 %86, %3028
  %3030 = icmp slt i64 %3029, %25
  %3031 = select i1 %3030, i64 %3029, i64 0
  %3032 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3033 = getelementptr inbounds nuw float, ptr %3032, i64 %3031
  %3034 = load float, ptr %3033, align 4
  %3035 = insertelement <8 x float> %3026, float %3034, i64 4
  %3036 = mul i64 %58, 8
  %3037 = add i64 %3036, 5
  %3038 = add i64 %86, %3037
  %3039 = icmp slt i64 %3038, %25
  %3040 = select i1 %3039, i64 %3038, i64 0
  %3041 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3042 = getelementptr inbounds nuw float, ptr %3041, i64 %3040
  %3043 = load float, ptr %3042, align 4
  %3044 = insertelement <8 x float> %3035, float %3043, i64 5
  %3045 = mul i64 %58, 8
  %3046 = add i64 %3045, 6
  %3047 = add i64 %86, %3046
  %3048 = icmp slt i64 %3047, %25
  %3049 = select i1 %3048, i64 %3047, i64 0
  %3050 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3051 = getelementptr inbounds nuw float, ptr %3050, i64 %3049
  %3052 = load float, ptr %3051, align 4
  %3053 = insertelement <8 x float> %3044, float %3052, i64 6
  %3054 = mul i64 %58, 8
  %3055 = add i64 %3054, 7
  %3056 = add i64 %86, %3055
  %3057 = icmp slt i64 %3056, %25
  %3058 = select i1 %3057, i64 %3056, i64 0
  %3059 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3060 = getelementptr inbounds nuw float, ptr %3059, i64 %3058
  %3061 = load float, ptr %3060, align 4
  %3062 = insertelement <8 x float> %3053, float %3061, i64 7
  br label %3063

3063:                                             ; preds = %2982, %2991
  %3064 = phi <8 x float> [ %3062, %2991 ], [ %2990, %2982 ]
  br label %3065

3065:                                             ; preds = %3063
  %3066 = add i64 %91, %57
  %3067 = icmp slt i64 %3066, %26
  %3068 = select i1 %3067, i64 %3066, i64 0
  %3069 = extractelement <8 x float> %3064, i64 0
  %3070 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3071 = getelementptr inbounds nuw i8, ptr %3070, i64 %3068
  %3072 = load i8, ptr %3071, align 1
  %3073 = zext i8 %3072 to i32
  %3074 = shl i32 %3073, 23
  %3075 = bitcast i32 %3074 to float
  %3076 = fmul float %3075, %3069
  %3077 = extractelement <8 x float> %165, i64 0
  %3078 = fmul float %3077, %3076
  %3079 = call float @llvm.fabs.f32(float %3076)
  %3080 = fcmp olt float %3079, +inf
  %3081 = fcmp one float %3076, 0.000000e+00
  %3082 = and i1 %3080, %3081
  %3083 = call i1 @llvm.expect.i1(i1 %3082, i1 true)
  br i1 %3083, label %3084, label %3085

3084:                                             ; preds = %3065
  br label %3097

3085:                                             ; preds = %3065
  %3086 = fpext float %3077 to double
  %3087 = fpext float %3075 to double
  %3088 = fpext float %3069 to double
  %3089 = fmul double %3086, %3087
  %3090 = fmul double %3089, %3088
  %3091 = fptrunc double %3090 to float
  %3092 = fcmp oeq float %3077, 0.000000e+00
  %3093 = call float @llvm.fabs.f32(float %3069)
  %3094 = fcmp olt float %3093, +inf
  %3095 = and i1 %3092, %3094
  %3096 = select i1 %3095, float 0.000000e+00, float %3091
  br label %3097

3097:                                             ; preds = %3084, %3085
  %3098 = phi float [ %3096, %3085 ], [ %3078, %3084 ]
  br label %3099

3099:                                             ; preds = %3097
  %3100 = add i64 %91, %57
  %3101 = icmp slt i64 %3100, %26
  %3102 = select i1 %3101, i64 %3100, i64 0
  %3103 = extractelement <8 x float> %3064, i64 1
  %3104 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3105 = getelementptr inbounds nuw i8, ptr %3104, i64 %3102
  %3106 = load i8, ptr %3105, align 1
  %3107 = zext i8 %3106 to i32
  %3108 = shl i32 %3107, 23
  %3109 = bitcast i32 %3108 to float
  %3110 = fmul float %3109, %3103
  %3111 = extractelement <8 x float> %165, i64 1
  %3112 = fmul float %3111, %3110
  %3113 = call float @llvm.fabs.f32(float %3110)
  %3114 = fcmp olt float %3113, +inf
  %3115 = fcmp one float %3110, 0.000000e+00
  %3116 = and i1 %3114, %3115
  %3117 = call i1 @llvm.expect.i1(i1 %3116, i1 true)
  br i1 %3117, label %3118, label %3119

3118:                                             ; preds = %3099
  br label %3131

3119:                                             ; preds = %3099
  %3120 = fpext float %3111 to double
  %3121 = fpext float %3109 to double
  %3122 = fpext float %3103 to double
  %3123 = fmul double %3120, %3121
  %3124 = fmul double %3123, %3122
  %3125 = fptrunc double %3124 to float
  %3126 = fcmp oeq float %3111, 0.000000e+00
  %3127 = call float @llvm.fabs.f32(float %3103)
  %3128 = fcmp olt float %3127, +inf
  %3129 = and i1 %3126, %3128
  %3130 = select i1 %3129, float 0.000000e+00, float %3125
  br label %3131

3131:                                             ; preds = %3118, %3119
  %3132 = phi float [ %3130, %3119 ], [ %3112, %3118 ]
  br label %3133

3133:                                             ; preds = %3131
  %3134 = add i64 %91, %57
  %3135 = icmp slt i64 %3134, %26
  %3136 = select i1 %3135, i64 %3134, i64 0
  %3137 = extractelement <8 x float> %3064, i64 2
  %3138 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3139 = getelementptr inbounds nuw i8, ptr %3138, i64 %3136
  %3140 = load i8, ptr %3139, align 1
  %3141 = zext i8 %3140 to i32
  %3142 = shl i32 %3141, 23
  %3143 = bitcast i32 %3142 to float
  %3144 = fmul float %3143, %3137
  %3145 = extractelement <8 x float> %165, i64 2
  %3146 = fmul float %3145, %3144
  %3147 = call float @llvm.fabs.f32(float %3144)
  %3148 = fcmp olt float %3147, +inf
  %3149 = fcmp one float %3144, 0.000000e+00
  %3150 = and i1 %3148, %3149
  %3151 = call i1 @llvm.expect.i1(i1 %3150, i1 true)
  br i1 %3151, label %3152, label %3153

3152:                                             ; preds = %3133
  br label %3165

3153:                                             ; preds = %3133
  %3154 = fpext float %3145 to double
  %3155 = fpext float %3143 to double
  %3156 = fpext float %3137 to double
  %3157 = fmul double %3154, %3155
  %3158 = fmul double %3157, %3156
  %3159 = fptrunc double %3158 to float
  %3160 = fcmp oeq float %3145, 0.000000e+00
  %3161 = call float @llvm.fabs.f32(float %3137)
  %3162 = fcmp olt float %3161, +inf
  %3163 = and i1 %3160, %3162
  %3164 = select i1 %3163, float 0.000000e+00, float %3159
  br label %3165

3165:                                             ; preds = %3152, %3153
  %3166 = phi float [ %3164, %3153 ], [ %3146, %3152 ]
  br label %3167

3167:                                             ; preds = %3165
  %3168 = add i64 %91, %57
  %3169 = icmp slt i64 %3168, %26
  %3170 = select i1 %3169, i64 %3168, i64 0
  %3171 = extractelement <8 x float> %3064, i64 3
  %3172 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3173 = getelementptr inbounds nuw i8, ptr %3172, i64 %3170
  %3174 = load i8, ptr %3173, align 1
  %3175 = zext i8 %3174 to i32
  %3176 = shl i32 %3175, 23
  %3177 = bitcast i32 %3176 to float
  %3178 = fmul float %3177, %3171
  %3179 = extractelement <8 x float> %165, i64 3
  %3180 = fmul float %3179, %3178
  %3181 = call float @llvm.fabs.f32(float %3178)
  %3182 = fcmp olt float %3181, +inf
  %3183 = fcmp one float %3178, 0.000000e+00
  %3184 = and i1 %3182, %3183
  %3185 = call i1 @llvm.expect.i1(i1 %3184, i1 true)
  br i1 %3185, label %3186, label %3187

3186:                                             ; preds = %3167
  br label %3199

3187:                                             ; preds = %3167
  %3188 = fpext float %3179 to double
  %3189 = fpext float %3177 to double
  %3190 = fpext float %3171 to double
  %3191 = fmul double %3188, %3189
  %3192 = fmul double %3191, %3190
  %3193 = fptrunc double %3192 to float
  %3194 = fcmp oeq float %3179, 0.000000e+00
  %3195 = call float @llvm.fabs.f32(float %3171)
  %3196 = fcmp olt float %3195, +inf
  %3197 = and i1 %3194, %3196
  %3198 = select i1 %3197, float 0.000000e+00, float %3193
  br label %3199

3199:                                             ; preds = %3186, %3187
  %3200 = phi float [ %3198, %3187 ], [ %3180, %3186 ]
  br label %3201

3201:                                             ; preds = %3199
  %3202 = add i64 %91, %57
  %3203 = icmp slt i64 %3202, %26
  %3204 = select i1 %3203, i64 %3202, i64 0
  %3205 = extractelement <8 x float> %3064, i64 4
  %3206 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3207 = getelementptr inbounds nuw i8, ptr %3206, i64 %3204
  %3208 = load i8, ptr %3207, align 1
  %3209 = zext i8 %3208 to i32
  %3210 = shl i32 %3209, 23
  %3211 = bitcast i32 %3210 to float
  %3212 = fmul float %3211, %3205
  %3213 = extractelement <8 x float> %165, i64 4
  %3214 = fmul float %3213, %3212
  %3215 = call float @llvm.fabs.f32(float %3212)
  %3216 = fcmp olt float %3215, +inf
  %3217 = fcmp one float %3212, 0.000000e+00
  %3218 = and i1 %3216, %3217
  %3219 = call i1 @llvm.expect.i1(i1 %3218, i1 true)
  br i1 %3219, label %3220, label %3221

3220:                                             ; preds = %3201
  br label %3233

3221:                                             ; preds = %3201
  %3222 = fpext float %3213 to double
  %3223 = fpext float %3211 to double
  %3224 = fpext float %3205 to double
  %3225 = fmul double %3222, %3223
  %3226 = fmul double %3225, %3224
  %3227 = fptrunc double %3226 to float
  %3228 = fcmp oeq float %3213, 0.000000e+00
  %3229 = call float @llvm.fabs.f32(float %3205)
  %3230 = fcmp olt float %3229, +inf
  %3231 = and i1 %3228, %3230
  %3232 = select i1 %3231, float 0.000000e+00, float %3227
  br label %3233

3233:                                             ; preds = %3220, %3221
  %3234 = phi float [ %3232, %3221 ], [ %3214, %3220 ]
  br label %3235

3235:                                             ; preds = %3233
  %3236 = add i64 %91, %57
  %3237 = icmp slt i64 %3236, %26
  %3238 = select i1 %3237, i64 %3236, i64 0
  %3239 = extractelement <8 x float> %3064, i64 5
  %3240 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3241 = getelementptr inbounds nuw i8, ptr %3240, i64 %3238
  %3242 = load i8, ptr %3241, align 1
  %3243 = zext i8 %3242 to i32
  %3244 = shl i32 %3243, 23
  %3245 = bitcast i32 %3244 to float
  %3246 = fmul float %3245, %3239
  %3247 = extractelement <8 x float> %165, i64 5
  %3248 = fmul float %3247, %3246
  %3249 = call float @llvm.fabs.f32(float %3246)
  %3250 = fcmp olt float %3249, +inf
  %3251 = fcmp one float %3246, 0.000000e+00
  %3252 = and i1 %3250, %3251
  %3253 = call i1 @llvm.expect.i1(i1 %3252, i1 true)
  br i1 %3253, label %3254, label %3255

3254:                                             ; preds = %3235
  br label %3267

3255:                                             ; preds = %3235
  %3256 = fpext float %3247 to double
  %3257 = fpext float %3245 to double
  %3258 = fpext float %3239 to double
  %3259 = fmul double %3256, %3257
  %3260 = fmul double %3259, %3258
  %3261 = fptrunc double %3260 to float
  %3262 = fcmp oeq float %3247, 0.000000e+00
  %3263 = call float @llvm.fabs.f32(float %3239)
  %3264 = fcmp olt float %3263, +inf
  %3265 = and i1 %3262, %3264
  %3266 = select i1 %3265, float 0.000000e+00, float %3261
  br label %3267

3267:                                             ; preds = %3254, %3255
  %3268 = phi float [ %3266, %3255 ], [ %3248, %3254 ]
  br label %3269

3269:                                             ; preds = %3267
  %3270 = add i64 %91, %57
  %3271 = icmp slt i64 %3270, %26
  %3272 = select i1 %3271, i64 %3270, i64 0
  %3273 = extractelement <8 x float> %3064, i64 6
  %3274 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3275 = getelementptr inbounds nuw i8, ptr %3274, i64 %3272
  %3276 = load i8, ptr %3275, align 1
  %3277 = zext i8 %3276 to i32
  %3278 = shl i32 %3277, 23
  %3279 = bitcast i32 %3278 to float
  %3280 = fmul float %3279, %3273
  %3281 = extractelement <8 x float> %165, i64 6
  %3282 = fmul float %3281, %3280
  %3283 = call float @llvm.fabs.f32(float %3280)
  %3284 = fcmp olt float %3283, +inf
  %3285 = fcmp one float %3280, 0.000000e+00
  %3286 = and i1 %3284, %3285
  %3287 = call i1 @llvm.expect.i1(i1 %3286, i1 true)
  br i1 %3287, label %3288, label %3289

3288:                                             ; preds = %3269
  br label %3301

3289:                                             ; preds = %3269
  %3290 = fpext float %3281 to double
  %3291 = fpext float %3279 to double
  %3292 = fpext float %3273 to double
  %3293 = fmul double %3290, %3291
  %3294 = fmul double %3293, %3292
  %3295 = fptrunc double %3294 to float
  %3296 = fcmp oeq float %3281, 0.000000e+00
  %3297 = call float @llvm.fabs.f32(float %3273)
  %3298 = fcmp olt float %3297, +inf
  %3299 = and i1 %3296, %3298
  %3300 = select i1 %3299, float 0.000000e+00, float %3295
  br label %3301

3301:                                             ; preds = %3288, %3289
  %3302 = phi float [ %3300, %3289 ], [ %3282, %3288 ]
  br label %3303

3303:                                             ; preds = %3301
  %3304 = add i64 %91, %57
  %3305 = icmp slt i64 %3304, %26
  %3306 = select i1 %3305, i64 %3304, i64 0
  %3307 = extractelement <8 x float> %3064, i64 7
  %3308 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3309 = getelementptr inbounds nuw i8, ptr %3308, i64 %3306
  %3310 = load i8, ptr %3309, align 1
  %3311 = zext i8 %3310 to i32
  %3312 = shl i32 %3311, 23
  %3313 = bitcast i32 %3312 to float
  %3314 = fmul float %3313, %3307
  %3315 = extractelement <8 x float> %165, i64 7
  %3316 = fmul float %3315, %3314
  %3317 = call float @llvm.fabs.f32(float %3314)
  %3318 = fcmp olt float %3317, +inf
  %3319 = fcmp one float %3314, 0.000000e+00
  %3320 = and i1 %3318, %3319
  %3321 = call i1 @llvm.expect.i1(i1 %3320, i1 true)
  br i1 %3321, label %3322, label %3323

3322:                                             ; preds = %3303
  br label %3335

3323:                                             ; preds = %3303
  %3324 = fpext float %3315 to double
  %3325 = fpext float %3313 to double
  %3326 = fpext float %3307 to double
  %3327 = fmul double %3324, %3325
  %3328 = fmul double %3327, %3326
  %3329 = fptrunc double %3328 to float
  %3330 = fcmp oeq float %3315, 0.000000e+00
  %3331 = call float @llvm.fabs.f32(float %3307)
  %3332 = fcmp olt float %3331, +inf
  %3333 = and i1 %3330, %3332
  %3334 = select i1 %3333, float 0.000000e+00, float %3329
  br label %3335

3335:                                             ; preds = %3322, %3323
  %3336 = phi float [ %3334, %3323 ], [ %3316, %3322 ]
  br label %3337

3337:                                             ; preds = %3335
  %3338 = mul i64 %59, 16
  %3339 = mul i64 %58, 8
  %3340 = add i64 %3338, %3339
  %3341 = add i64 %57, 16
  %3342 = mul i64 %3340, 40
  %3343 = add i64 %3342, %3341
  %3344 = fptrunc float %3098 to bfloat
  %3345 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3343
  store bfloat %3344, ptr addrspace(3) %3345, align 2
  %3346 = mul i64 %58, 8
  %3347 = add i64 %3346, 1
  %3348 = add i64 %3338, %3347
  %3349 = add i64 %57, 16
  %3350 = mul i64 %3348, 40
  %3351 = add i64 %3350, %3349
  %3352 = fptrunc float %3132 to bfloat
  %3353 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3351
  store bfloat %3352, ptr addrspace(3) %3353, align 2
  %3354 = mul i64 %58, 8
  %3355 = add i64 %3354, 2
  %3356 = add i64 %3338, %3355
  %3357 = add i64 %57, 16
  %3358 = mul i64 %3356, 40
  %3359 = add i64 %3358, %3357
  %3360 = fptrunc float %3166 to bfloat
  %3361 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3359
  store bfloat %3360, ptr addrspace(3) %3361, align 2
  %3362 = mul i64 %58, 8
  %3363 = add i64 %3362, 3
  %3364 = add i64 %3338, %3363
  %3365 = add i64 %57, 16
  %3366 = mul i64 %3364, 40
  %3367 = add i64 %3366, %3365
  %3368 = fptrunc float %3200 to bfloat
  %3369 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3367
  store bfloat %3368, ptr addrspace(3) %3369, align 2
  %3370 = mul i64 %58, 8
  %3371 = add i64 %3370, 4
  %3372 = add i64 %3338, %3371
  %3373 = add i64 %57, 16
  %3374 = mul i64 %3372, 40
  %3375 = add i64 %3374, %3373
  %3376 = fptrunc float %3234 to bfloat
  %3377 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3375
  store bfloat %3376, ptr addrspace(3) %3377, align 2
  %3378 = mul i64 %58, 8
  %3379 = add i64 %3378, 5
  %3380 = add i64 %3338, %3379
  %3381 = add i64 %57, 16
  %3382 = mul i64 %3380, 40
  %3383 = add i64 %3382, %3381
  %3384 = fptrunc float %3268 to bfloat
  %3385 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3383
  store bfloat %3384, ptr addrspace(3) %3385, align 2
  %3386 = mul i64 %58, 8
  %3387 = add i64 %3386, 6
  %3388 = add i64 %3338, %3387
  %3389 = add i64 %57, 16
  %3390 = mul i64 %3388, 40
  %3391 = add i64 %3390, %3389
  %3392 = fptrunc float %3302 to bfloat
  %3393 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3391
  store bfloat %3392, ptr addrspace(3) %3393, align 2
  %3394 = mul i64 %58, 8
  %3395 = add i64 %3394, 7
  %3396 = add i64 %3338, %3395
  %3397 = add i64 %57, 16
  %3398 = mul i64 %3396, 40
  %3399 = add i64 %3398, %3397
  %3400 = fptrunc float %3336 to bfloat
  %3401 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3399
  store bfloat %3400, ptr addrspace(3) %3401, align 2
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %3402 = urem i64 %55, 32
  %3403 = mul i64 %3402, 8
  %3404 = udiv i64 %3403, 32
  %3405 = urem i64 %3403, 32
  %3406 = mul i64 %59, 16
  %3407 = add i64 %3406, %3404
  %3408 = udiv i64 %59, 2
  %3409 = mul i64 %3408, 4
  %3410 = add i64 %3409, 2
  %3411 = mul i64 %3410, 16
  %3412 = add i64 %3404, %3411
  %3413 = add i64 %78, %3412
  %3414 = urem i64 %59, 2
  %3415 = mul i64 %3414, 32
  %3416 = add i64 %3405, %3415
  %3417 = add i64 %79, %3416
  %3418 = mul i64 %3407, 40
  %3419 = add i64 %3418, %3405
  %3420 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3419
  %3421 = load <8 x bfloat>, ptr addrspace(3) %3420, align 16
  %3422 = mul i64 %3413, %26
  %3423 = add i64 %3422, %3417
  %3424 = icmp ult i64 %3413, %25
  %3425 = add i64 %3417, 7
  %3426 = icmp ult i64 %3425, %26
  %3427 = and i1 %3424, %3426
  br i1 %3427, label %3428, label %3431

3428:                                             ; preds = %3337
  %3429 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3430 = getelementptr bfloat, ptr %3429, i64 %3423
  store <8 x bfloat> %3421, ptr %3430, align 2
  br label %3502

3431:                                             ; preds = %3337
  %3432 = icmp ult i64 %3417, %26
  %3433 = and i1 %3424, %3432
  br i1 %3433, label %3434, label %3438

3434:                                             ; preds = %3431
  %3435 = extractelement <8 x bfloat> %3421, i64 0
  %3436 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3437 = getelementptr inbounds nuw bfloat, ptr %3436, i64 %3423
  store bfloat %3435, ptr %3437, align 2
  br label %3438

3438:                                             ; preds = %3434, %3431
  %3439 = add i64 %3417, 1
  %3440 = icmp ult i64 %3439, %26
  %3441 = and i1 %3424, %3440
  br i1 %3441, label %3442, label %3447

3442:                                             ; preds = %3438
  %3443 = add i64 %3423, 1
  %3444 = extractelement <8 x bfloat> %3421, i64 1
  %3445 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3446 = getelementptr inbounds nuw bfloat, ptr %3445, i64 %3443
  store bfloat %3444, ptr %3446, align 2
  br label %3447

3447:                                             ; preds = %3442, %3438
  %3448 = add i64 %3417, 2
  %3449 = icmp ult i64 %3448, %26
  %3450 = and i1 %3424, %3449
  br i1 %3450, label %3451, label %3456

3451:                                             ; preds = %3447
  %3452 = add i64 %3423, 2
  %3453 = extractelement <8 x bfloat> %3421, i64 2
  %3454 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3455 = getelementptr inbounds nuw bfloat, ptr %3454, i64 %3452
  store bfloat %3453, ptr %3455, align 2
  br label %3456

3456:                                             ; preds = %3451, %3447
  %3457 = add i64 %3417, 3
  %3458 = icmp ult i64 %3457, %26
  %3459 = and i1 %3424, %3458
  br i1 %3459, label %3460, label %3465

3460:                                             ; preds = %3456
  %3461 = add i64 %3423, 3
  %3462 = extractelement <8 x bfloat> %3421, i64 3
  %3463 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3464 = getelementptr inbounds nuw bfloat, ptr %3463, i64 %3461
  store bfloat %3462, ptr %3464, align 2
  br label %3465

3465:                                             ; preds = %3460, %3456
  %3466 = add i64 %3417, 4
  %3467 = icmp ult i64 %3466, %26
  %3468 = and i1 %3424, %3467
  br i1 %3468, label %3469, label %3474

3469:                                             ; preds = %3465
  %3470 = add i64 %3423, 4
  %3471 = extractelement <8 x bfloat> %3421, i64 4
  %3472 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3473 = getelementptr inbounds nuw bfloat, ptr %3472, i64 %3470
  store bfloat %3471, ptr %3473, align 2
  br label %3474

3474:                                             ; preds = %3469, %3465
  %3475 = add i64 %3417, 5
  %3476 = icmp ult i64 %3475, %26
  %3477 = and i1 %3424, %3476
  br i1 %3477, label %3478, label %3483

3478:                                             ; preds = %3474
  %3479 = add i64 %3423, 5
  %3480 = extractelement <8 x bfloat> %3421, i64 5
  %3481 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3482 = getelementptr inbounds nuw bfloat, ptr %3481, i64 %3479
  store bfloat %3480, ptr %3482, align 2
  br label %3483

3483:                                             ; preds = %3478, %3474
  %3484 = add i64 %3417, 6
  %3485 = icmp ult i64 %3484, %26
  %3486 = and i1 %3424, %3485
  br i1 %3486, label %3487, label %3492

3487:                                             ; preds = %3483
  %3488 = add i64 %3423, 6
  %3489 = extractelement <8 x bfloat> %3421, i64 6
  %3490 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3491 = getelementptr inbounds nuw bfloat, ptr %3490, i64 %3488
  store bfloat %3489, ptr %3491, align 2
  br label %3492

3492:                                             ; preds = %3487, %3483
  %3493 = add i64 %3417, 7
  %3494 = icmp ult i64 %3493, %26
  %3495 = and i1 %3424, %3494
  br i1 %3495, label %3496, label %3501

3496:                                             ; preds = %3492
  %3497 = add i64 %3423, 7
  %3498 = extractelement <8 x bfloat> %3421, i64 7
  %3499 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3500 = getelementptr inbounds nuw bfloat, ptr %3499, i64 %3497
  store bfloat %3498, ptr %3500, align 2
  br label %3501

3501:                                             ; preds = %3496, %3492
  br label %3502

3502:                                             ; preds = %3428, %3501
  %3503 = urem i64 %55, 32
  %3504 = mul i64 %3503, 8
  %3505 = add i64 %3504, 256
  %3506 = udiv i64 %3505, 32
  %3507 = urem i64 %3505, 32
  %3508 = mul i64 %59, 16
  %3509 = add i64 %3508, %3506
  %3510 = udiv i64 %59, 2
  %3511 = mul i64 %3510, 4
  %3512 = add i64 %3511, 2
  %3513 = mul i64 %3512, 16
  %3514 = add i64 %3506, %3513
  %3515 = add i64 %78, %3514
  %3516 = urem i64 %59, 2
  %3517 = mul i64 %3516, 32
  %3518 = add i64 %3507, %3517
  %3519 = add i64 %79, %3518
  %3520 = mul i64 %3509, 40
  %3521 = add i64 %3520, %3507
  %3522 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3521
  %3523 = load <8 x bfloat>, ptr addrspace(3) %3522, align 16
  %3524 = mul i64 %3515, %26
  %3525 = add i64 %3524, %3519
  %3526 = icmp ult i64 %3515, %25
  %3527 = add i64 %3519, 7
  %3528 = icmp ult i64 %3527, %26
  %3529 = and i1 %3526, %3528
  br i1 %3529, label %3530, label %3533

3530:                                             ; preds = %3502
  %3531 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3532 = getelementptr bfloat, ptr %3531, i64 %3525
  store <8 x bfloat> %3523, ptr %3532, align 2
  br label %3604

3533:                                             ; preds = %3502
  %3534 = icmp ult i64 %3519, %26
  %3535 = and i1 %3526, %3534
  br i1 %3535, label %3536, label %3540

3536:                                             ; preds = %3533
  %3537 = extractelement <8 x bfloat> %3523, i64 0
  %3538 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3539 = getelementptr inbounds nuw bfloat, ptr %3538, i64 %3525
  store bfloat %3537, ptr %3539, align 2
  br label %3540

3540:                                             ; preds = %3536, %3533
  %3541 = add i64 %3519, 1
  %3542 = icmp ult i64 %3541, %26
  %3543 = and i1 %3526, %3542
  br i1 %3543, label %3544, label %3549

3544:                                             ; preds = %3540
  %3545 = add i64 %3525, 1
  %3546 = extractelement <8 x bfloat> %3523, i64 1
  %3547 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3548 = getelementptr inbounds nuw bfloat, ptr %3547, i64 %3545
  store bfloat %3546, ptr %3548, align 2
  br label %3549

3549:                                             ; preds = %3544, %3540
  %3550 = add i64 %3519, 2
  %3551 = icmp ult i64 %3550, %26
  %3552 = and i1 %3526, %3551
  br i1 %3552, label %3553, label %3558

3553:                                             ; preds = %3549
  %3554 = add i64 %3525, 2
  %3555 = extractelement <8 x bfloat> %3523, i64 2
  %3556 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3557 = getelementptr inbounds nuw bfloat, ptr %3556, i64 %3554
  store bfloat %3555, ptr %3557, align 2
  br label %3558

3558:                                             ; preds = %3553, %3549
  %3559 = add i64 %3519, 3
  %3560 = icmp ult i64 %3559, %26
  %3561 = and i1 %3526, %3560
  br i1 %3561, label %3562, label %3567

3562:                                             ; preds = %3558
  %3563 = add i64 %3525, 3
  %3564 = extractelement <8 x bfloat> %3523, i64 3
  %3565 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3566 = getelementptr inbounds nuw bfloat, ptr %3565, i64 %3563
  store bfloat %3564, ptr %3566, align 2
  br label %3567

3567:                                             ; preds = %3562, %3558
  %3568 = add i64 %3519, 4
  %3569 = icmp ult i64 %3568, %26
  %3570 = and i1 %3526, %3569
  br i1 %3570, label %3571, label %3576

3571:                                             ; preds = %3567
  %3572 = add i64 %3525, 4
  %3573 = extractelement <8 x bfloat> %3523, i64 4
  %3574 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3575 = getelementptr inbounds nuw bfloat, ptr %3574, i64 %3572
  store bfloat %3573, ptr %3575, align 2
  br label %3576

3576:                                             ; preds = %3571, %3567
  %3577 = add i64 %3519, 5
  %3578 = icmp ult i64 %3577, %26
  %3579 = and i1 %3526, %3578
  br i1 %3579, label %3580, label %3585

3580:                                             ; preds = %3576
  %3581 = add i64 %3525, 5
  %3582 = extractelement <8 x bfloat> %3523, i64 5
  %3583 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3584 = getelementptr inbounds nuw bfloat, ptr %3583, i64 %3581
  store bfloat %3582, ptr %3584, align 2
  br label %3585

3585:                                             ; preds = %3580, %3576
  %3586 = add i64 %3519, 6
  %3587 = icmp ult i64 %3586, %26
  %3588 = and i1 %3526, %3587
  br i1 %3588, label %3589, label %3594

3589:                                             ; preds = %3585
  %3590 = add i64 %3525, 6
  %3591 = extractelement <8 x bfloat> %3523, i64 6
  %3592 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3593 = getelementptr inbounds nuw bfloat, ptr %3592, i64 %3590
  store bfloat %3591, ptr %3593, align 2
  br label %3594

3594:                                             ; preds = %3589, %3585
  %3595 = add i64 %3519, 7
  %3596 = icmp ult i64 %3595, %26
  %3597 = and i1 %3526, %3596
  br i1 %3597, label %3598, label %3603

3598:                                             ; preds = %3594
  %3599 = add i64 %3525, 7
  %3600 = extractelement <8 x bfloat> %3523, i64 7
  %3601 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3602 = getelementptr inbounds nuw bfloat, ptr %3601, i64 %3599
  store bfloat %3600, ptr %3602, align 2
  br label %3603

3603:                                             ; preds = %3598, %3594
  br label %3604

3604:                                             ; preds = %3530, %3603
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %3605 = mul i64 %58, 8
  %3606 = add i64 %88, %3605
  %3607 = add i64 %89, %57
  %3608 = add i64 %3606, 7
  %3609 = icmp ult i64 %3607, %26
  %3610 = icmp ult i64 %3608, %25
  %3611 = and i1 %3610, %3609
  %3612 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3613 = ptrtoint ptr %3612 to i64
  %3614 = mul i64 %3606, 4
  %3615 = add i64 %3613, %3614
  %3616 = urem i64 %3615, 16
  %3617 = icmp eq i64 %3616, 0
  %3618 = and i1 %3611, %3617
  br i1 %3618, label %3619, label %3628

3619:                                             ; preds = %3604
  %3620 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3621 = getelementptr float, ptr %3620, i64 %3606
  %3622 = load <4 x float>, ptr %3621, align 16
  %3623 = add i64 %3606, 4
  %3624 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3625 = getelementptr float, ptr %3624, i64 %3623
  %3626 = load <4 x float>, ptr %3625, align 16
  %3627 = shufflevector <4 x float> %3622, <4 x float> %3626, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3700

3628:                                             ; preds = %3604
  %3629 = mul i64 %58, 8
  %3630 = add i64 %88, %3629
  %3631 = icmp slt i64 %3630, %25
  %3632 = select i1 %3631, i64 %3630, i64 0
  %3633 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3634 = getelementptr inbounds nuw float, ptr %3633, i64 %3632
  %3635 = load float, ptr %3634, align 4
  %3636 = insertelement <8 x float> zeroinitializer, float %3635, i64 0
  %3637 = mul i64 %58, 8
  %3638 = add i64 %3637, 1
  %3639 = add i64 %88, %3638
  %3640 = icmp slt i64 %3639, %25
  %3641 = select i1 %3640, i64 %3639, i64 0
  %3642 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3643 = getelementptr inbounds nuw float, ptr %3642, i64 %3641
  %3644 = load float, ptr %3643, align 4
  %3645 = insertelement <8 x float> %3636, float %3644, i64 1
  %3646 = mul i64 %58, 8
  %3647 = add i64 %3646, 2
  %3648 = add i64 %88, %3647
  %3649 = icmp slt i64 %3648, %25
  %3650 = select i1 %3649, i64 %3648, i64 0
  %3651 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3652 = getelementptr inbounds nuw float, ptr %3651, i64 %3650
  %3653 = load float, ptr %3652, align 4
  %3654 = insertelement <8 x float> %3645, float %3653, i64 2
  %3655 = mul i64 %58, 8
  %3656 = add i64 %3655, 3
  %3657 = add i64 %88, %3656
  %3658 = icmp slt i64 %3657, %25
  %3659 = select i1 %3658, i64 %3657, i64 0
  %3660 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3661 = getelementptr inbounds nuw float, ptr %3660, i64 %3659
  %3662 = load float, ptr %3661, align 4
  %3663 = insertelement <8 x float> %3654, float %3662, i64 3
  %3664 = mul i64 %58, 8
  %3665 = add i64 %3664, 4
  %3666 = add i64 %88, %3665
  %3667 = icmp slt i64 %3666, %25
  %3668 = select i1 %3667, i64 %3666, i64 0
  %3669 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3670 = getelementptr inbounds nuw float, ptr %3669, i64 %3668
  %3671 = load float, ptr %3670, align 4
  %3672 = insertelement <8 x float> %3663, float %3671, i64 4
  %3673 = mul i64 %58, 8
  %3674 = add i64 %3673, 5
  %3675 = add i64 %88, %3674
  %3676 = icmp slt i64 %3675, %25
  %3677 = select i1 %3676, i64 %3675, i64 0
  %3678 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3679 = getelementptr inbounds nuw float, ptr %3678, i64 %3677
  %3680 = load float, ptr %3679, align 4
  %3681 = insertelement <8 x float> %3672, float %3680, i64 5
  %3682 = mul i64 %58, 8
  %3683 = add i64 %3682, 6
  %3684 = add i64 %88, %3683
  %3685 = icmp slt i64 %3684, %25
  %3686 = select i1 %3685, i64 %3684, i64 0
  %3687 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3688 = getelementptr inbounds nuw float, ptr %3687, i64 %3686
  %3689 = load float, ptr %3688, align 4
  %3690 = insertelement <8 x float> %3681, float %3689, i64 6
  %3691 = mul i64 %58, 8
  %3692 = add i64 %3691, 7
  %3693 = add i64 %88, %3692
  %3694 = icmp slt i64 %3693, %25
  %3695 = select i1 %3694, i64 %3693, i64 0
  %3696 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3697 = getelementptr inbounds nuw float, ptr %3696, i64 %3695
  %3698 = load float, ptr %3697, align 4
  %3699 = insertelement <8 x float> %3690, float %3698, i64 7
  br label %3700

3700:                                             ; preds = %3619, %3628
  %3701 = phi <8 x float> [ %3699, %3628 ], [ %3627, %3619 ]
  br label %3702

3702:                                             ; preds = %3700
  %3703 = add i64 %89, %57
  %3704 = icmp slt i64 %3703, %26
  %3705 = select i1 %3704, i64 %3703, i64 0
  %3706 = extractelement <8 x float> %3701, i64 0
  %3707 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3708 = getelementptr inbounds nuw i8, ptr %3707, i64 %3705
  %3709 = load i8, ptr %3708, align 1
  %3710 = zext i8 %3709 to i32
  %3711 = shl i32 %3710, 23
  %3712 = bitcast i32 %3711 to float
  %3713 = fmul float %3712, %3706
  %3714 = extractelement <8 x float> %166, i64 0
  %3715 = fmul float %3714, %3713
  %3716 = call float @llvm.fabs.f32(float %3713)
  %3717 = fcmp olt float %3716, +inf
  %3718 = fcmp one float %3713, 0.000000e+00
  %3719 = and i1 %3717, %3718
  %3720 = call i1 @llvm.expect.i1(i1 %3719, i1 true)
  br i1 %3720, label %3721, label %3722

3721:                                             ; preds = %3702
  br label %3734

3722:                                             ; preds = %3702
  %3723 = fpext float %3714 to double
  %3724 = fpext float %3712 to double
  %3725 = fpext float %3706 to double
  %3726 = fmul double %3723, %3724
  %3727 = fmul double %3726, %3725
  %3728 = fptrunc double %3727 to float
  %3729 = fcmp oeq float %3714, 0.000000e+00
  %3730 = call float @llvm.fabs.f32(float %3706)
  %3731 = fcmp olt float %3730, +inf
  %3732 = and i1 %3729, %3731
  %3733 = select i1 %3732, float 0.000000e+00, float %3728
  br label %3734

3734:                                             ; preds = %3721, %3722
  %3735 = phi float [ %3733, %3722 ], [ %3715, %3721 ]
  br label %3736

3736:                                             ; preds = %3734
  %3737 = add i64 %89, %57
  %3738 = icmp slt i64 %3737, %26
  %3739 = select i1 %3738, i64 %3737, i64 0
  %3740 = extractelement <8 x float> %3701, i64 1
  %3741 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3742 = getelementptr inbounds nuw i8, ptr %3741, i64 %3739
  %3743 = load i8, ptr %3742, align 1
  %3744 = zext i8 %3743 to i32
  %3745 = shl i32 %3744, 23
  %3746 = bitcast i32 %3745 to float
  %3747 = fmul float %3746, %3740
  %3748 = extractelement <8 x float> %166, i64 1
  %3749 = fmul float %3748, %3747
  %3750 = call float @llvm.fabs.f32(float %3747)
  %3751 = fcmp olt float %3750, +inf
  %3752 = fcmp one float %3747, 0.000000e+00
  %3753 = and i1 %3751, %3752
  %3754 = call i1 @llvm.expect.i1(i1 %3753, i1 true)
  br i1 %3754, label %3755, label %3756

3755:                                             ; preds = %3736
  br label %3768

3756:                                             ; preds = %3736
  %3757 = fpext float %3748 to double
  %3758 = fpext float %3746 to double
  %3759 = fpext float %3740 to double
  %3760 = fmul double %3757, %3758
  %3761 = fmul double %3760, %3759
  %3762 = fptrunc double %3761 to float
  %3763 = fcmp oeq float %3748, 0.000000e+00
  %3764 = call float @llvm.fabs.f32(float %3740)
  %3765 = fcmp olt float %3764, +inf
  %3766 = and i1 %3763, %3765
  %3767 = select i1 %3766, float 0.000000e+00, float %3762
  br label %3768

3768:                                             ; preds = %3755, %3756
  %3769 = phi float [ %3767, %3756 ], [ %3749, %3755 ]
  br label %3770

3770:                                             ; preds = %3768
  %3771 = add i64 %89, %57
  %3772 = icmp slt i64 %3771, %26
  %3773 = select i1 %3772, i64 %3771, i64 0
  %3774 = extractelement <8 x float> %3701, i64 2
  %3775 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3776 = getelementptr inbounds nuw i8, ptr %3775, i64 %3773
  %3777 = load i8, ptr %3776, align 1
  %3778 = zext i8 %3777 to i32
  %3779 = shl i32 %3778, 23
  %3780 = bitcast i32 %3779 to float
  %3781 = fmul float %3780, %3774
  %3782 = extractelement <8 x float> %166, i64 2
  %3783 = fmul float %3782, %3781
  %3784 = call float @llvm.fabs.f32(float %3781)
  %3785 = fcmp olt float %3784, +inf
  %3786 = fcmp one float %3781, 0.000000e+00
  %3787 = and i1 %3785, %3786
  %3788 = call i1 @llvm.expect.i1(i1 %3787, i1 true)
  br i1 %3788, label %3789, label %3790

3789:                                             ; preds = %3770
  br label %3802

3790:                                             ; preds = %3770
  %3791 = fpext float %3782 to double
  %3792 = fpext float %3780 to double
  %3793 = fpext float %3774 to double
  %3794 = fmul double %3791, %3792
  %3795 = fmul double %3794, %3793
  %3796 = fptrunc double %3795 to float
  %3797 = fcmp oeq float %3782, 0.000000e+00
  %3798 = call float @llvm.fabs.f32(float %3774)
  %3799 = fcmp olt float %3798, +inf
  %3800 = and i1 %3797, %3799
  %3801 = select i1 %3800, float 0.000000e+00, float %3796
  br label %3802

3802:                                             ; preds = %3789, %3790
  %3803 = phi float [ %3801, %3790 ], [ %3783, %3789 ]
  br label %3804

3804:                                             ; preds = %3802
  %3805 = add i64 %89, %57
  %3806 = icmp slt i64 %3805, %26
  %3807 = select i1 %3806, i64 %3805, i64 0
  %3808 = extractelement <8 x float> %3701, i64 3
  %3809 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3810 = getelementptr inbounds nuw i8, ptr %3809, i64 %3807
  %3811 = load i8, ptr %3810, align 1
  %3812 = zext i8 %3811 to i32
  %3813 = shl i32 %3812, 23
  %3814 = bitcast i32 %3813 to float
  %3815 = fmul float %3814, %3808
  %3816 = extractelement <8 x float> %166, i64 3
  %3817 = fmul float %3816, %3815
  %3818 = call float @llvm.fabs.f32(float %3815)
  %3819 = fcmp olt float %3818, +inf
  %3820 = fcmp one float %3815, 0.000000e+00
  %3821 = and i1 %3819, %3820
  %3822 = call i1 @llvm.expect.i1(i1 %3821, i1 true)
  br i1 %3822, label %3823, label %3824

3823:                                             ; preds = %3804
  br label %3836

3824:                                             ; preds = %3804
  %3825 = fpext float %3816 to double
  %3826 = fpext float %3814 to double
  %3827 = fpext float %3808 to double
  %3828 = fmul double %3825, %3826
  %3829 = fmul double %3828, %3827
  %3830 = fptrunc double %3829 to float
  %3831 = fcmp oeq float %3816, 0.000000e+00
  %3832 = call float @llvm.fabs.f32(float %3808)
  %3833 = fcmp olt float %3832, +inf
  %3834 = and i1 %3831, %3833
  %3835 = select i1 %3834, float 0.000000e+00, float %3830
  br label %3836

3836:                                             ; preds = %3823, %3824
  %3837 = phi float [ %3835, %3824 ], [ %3817, %3823 ]
  br label %3838

3838:                                             ; preds = %3836
  %3839 = add i64 %89, %57
  %3840 = icmp slt i64 %3839, %26
  %3841 = select i1 %3840, i64 %3839, i64 0
  %3842 = extractelement <8 x float> %3701, i64 4
  %3843 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3844 = getelementptr inbounds nuw i8, ptr %3843, i64 %3841
  %3845 = load i8, ptr %3844, align 1
  %3846 = zext i8 %3845 to i32
  %3847 = shl i32 %3846, 23
  %3848 = bitcast i32 %3847 to float
  %3849 = fmul float %3848, %3842
  %3850 = extractelement <8 x float> %166, i64 4
  %3851 = fmul float %3850, %3849
  %3852 = call float @llvm.fabs.f32(float %3849)
  %3853 = fcmp olt float %3852, +inf
  %3854 = fcmp one float %3849, 0.000000e+00
  %3855 = and i1 %3853, %3854
  %3856 = call i1 @llvm.expect.i1(i1 %3855, i1 true)
  br i1 %3856, label %3857, label %3858

3857:                                             ; preds = %3838
  br label %3870

3858:                                             ; preds = %3838
  %3859 = fpext float %3850 to double
  %3860 = fpext float %3848 to double
  %3861 = fpext float %3842 to double
  %3862 = fmul double %3859, %3860
  %3863 = fmul double %3862, %3861
  %3864 = fptrunc double %3863 to float
  %3865 = fcmp oeq float %3850, 0.000000e+00
  %3866 = call float @llvm.fabs.f32(float %3842)
  %3867 = fcmp olt float %3866, +inf
  %3868 = and i1 %3865, %3867
  %3869 = select i1 %3868, float 0.000000e+00, float %3864
  br label %3870

3870:                                             ; preds = %3857, %3858
  %3871 = phi float [ %3869, %3858 ], [ %3851, %3857 ]
  br label %3872

3872:                                             ; preds = %3870
  %3873 = add i64 %89, %57
  %3874 = icmp slt i64 %3873, %26
  %3875 = select i1 %3874, i64 %3873, i64 0
  %3876 = extractelement <8 x float> %3701, i64 5
  %3877 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3878 = getelementptr inbounds nuw i8, ptr %3877, i64 %3875
  %3879 = load i8, ptr %3878, align 1
  %3880 = zext i8 %3879 to i32
  %3881 = shl i32 %3880, 23
  %3882 = bitcast i32 %3881 to float
  %3883 = fmul float %3882, %3876
  %3884 = extractelement <8 x float> %166, i64 5
  %3885 = fmul float %3884, %3883
  %3886 = call float @llvm.fabs.f32(float %3883)
  %3887 = fcmp olt float %3886, +inf
  %3888 = fcmp one float %3883, 0.000000e+00
  %3889 = and i1 %3887, %3888
  %3890 = call i1 @llvm.expect.i1(i1 %3889, i1 true)
  br i1 %3890, label %3891, label %3892

3891:                                             ; preds = %3872
  br label %3904

3892:                                             ; preds = %3872
  %3893 = fpext float %3884 to double
  %3894 = fpext float %3882 to double
  %3895 = fpext float %3876 to double
  %3896 = fmul double %3893, %3894
  %3897 = fmul double %3896, %3895
  %3898 = fptrunc double %3897 to float
  %3899 = fcmp oeq float %3884, 0.000000e+00
  %3900 = call float @llvm.fabs.f32(float %3876)
  %3901 = fcmp olt float %3900, +inf
  %3902 = and i1 %3899, %3901
  %3903 = select i1 %3902, float 0.000000e+00, float %3898
  br label %3904

3904:                                             ; preds = %3891, %3892
  %3905 = phi float [ %3903, %3892 ], [ %3885, %3891 ]
  br label %3906

3906:                                             ; preds = %3904
  %3907 = add i64 %89, %57
  %3908 = icmp slt i64 %3907, %26
  %3909 = select i1 %3908, i64 %3907, i64 0
  %3910 = extractelement <8 x float> %3701, i64 6
  %3911 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3912 = getelementptr inbounds nuw i8, ptr %3911, i64 %3909
  %3913 = load i8, ptr %3912, align 1
  %3914 = zext i8 %3913 to i32
  %3915 = shl i32 %3914, 23
  %3916 = bitcast i32 %3915 to float
  %3917 = fmul float %3916, %3910
  %3918 = extractelement <8 x float> %166, i64 6
  %3919 = fmul float %3918, %3917
  %3920 = call float @llvm.fabs.f32(float %3917)
  %3921 = fcmp olt float %3920, +inf
  %3922 = fcmp one float %3917, 0.000000e+00
  %3923 = and i1 %3921, %3922
  %3924 = call i1 @llvm.expect.i1(i1 %3923, i1 true)
  br i1 %3924, label %3925, label %3926

3925:                                             ; preds = %3906
  br label %3938

3926:                                             ; preds = %3906
  %3927 = fpext float %3918 to double
  %3928 = fpext float %3916 to double
  %3929 = fpext float %3910 to double
  %3930 = fmul double %3927, %3928
  %3931 = fmul double %3930, %3929
  %3932 = fptrunc double %3931 to float
  %3933 = fcmp oeq float %3918, 0.000000e+00
  %3934 = call float @llvm.fabs.f32(float %3910)
  %3935 = fcmp olt float %3934, +inf
  %3936 = and i1 %3933, %3935
  %3937 = select i1 %3936, float 0.000000e+00, float %3932
  br label %3938

3938:                                             ; preds = %3925, %3926
  %3939 = phi float [ %3937, %3926 ], [ %3919, %3925 ]
  br label %3940

3940:                                             ; preds = %3938
  %3941 = add i64 %89, %57
  %3942 = icmp slt i64 %3941, %26
  %3943 = select i1 %3942, i64 %3941, i64 0
  %3944 = extractelement <8 x float> %3701, i64 7
  %3945 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3946 = getelementptr inbounds nuw i8, ptr %3945, i64 %3943
  %3947 = load i8, ptr %3946, align 1
  %3948 = zext i8 %3947 to i32
  %3949 = shl i32 %3948, 23
  %3950 = bitcast i32 %3949 to float
  %3951 = fmul float %3950, %3944
  %3952 = extractelement <8 x float> %166, i64 7
  %3953 = fmul float %3952, %3951
  %3954 = call float @llvm.fabs.f32(float %3951)
  %3955 = fcmp olt float %3954, +inf
  %3956 = fcmp one float %3951, 0.000000e+00
  %3957 = and i1 %3955, %3956
  %3958 = call i1 @llvm.expect.i1(i1 %3957, i1 true)
  br i1 %3958, label %3959, label %3960

3959:                                             ; preds = %3940
  br label %3972

3960:                                             ; preds = %3940
  %3961 = fpext float %3952 to double
  %3962 = fpext float %3950 to double
  %3963 = fpext float %3944 to double
  %3964 = fmul double %3961, %3962
  %3965 = fmul double %3964, %3963
  %3966 = fptrunc double %3965 to float
  %3967 = fcmp oeq float %3952, 0.000000e+00
  %3968 = call float @llvm.fabs.f32(float %3944)
  %3969 = fcmp olt float %3968, +inf
  %3970 = and i1 %3967, %3969
  %3971 = select i1 %3970, float 0.000000e+00, float %3966
  br label %3972

3972:                                             ; preds = %3959, %3960
  %3973 = phi float [ %3971, %3960 ], [ %3953, %3959 ]
  br label %3974

3974:                                             ; preds = %3972
  %3975 = mul i64 %59, 16
  %3976 = mul i64 %58, 8
  %3977 = add i64 %3975, %3976
  %3978 = mul i64 %3977, 40
  %3979 = add i64 %3978, %57
  %3980 = fptrunc float %3735 to bfloat
  %3981 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3979
  store bfloat %3980, ptr addrspace(3) %3981, align 2
  %3982 = mul i64 %58, 8
  %3983 = add i64 %3982, 1
  %3984 = add i64 %3975, %3983
  %3985 = mul i64 %3984, 40
  %3986 = add i64 %3985, %57
  %3987 = fptrunc float %3769 to bfloat
  %3988 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3986
  store bfloat %3987, ptr addrspace(3) %3988, align 2
  %3989 = mul i64 %58, 8
  %3990 = add i64 %3989, 2
  %3991 = add i64 %3975, %3990
  %3992 = mul i64 %3991, 40
  %3993 = add i64 %3992, %57
  %3994 = fptrunc float %3803 to bfloat
  %3995 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3993
  store bfloat %3994, ptr addrspace(3) %3995, align 2
  %3996 = mul i64 %58, 8
  %3997 = add i64 %3996, 3
  %3998 = add i64 %3975, %3997
  %3999 = mul i64 %3998, 40
  %4000 = add i64 %3999, %57
  %4001 = fptrunc float %3837 to bfloat
  %4002 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4000
  store bfloat %4001, ptr addrspace(3) %4002, align 2
  %4003 = mul i64 %58, 8
  %4004 = add i64 %4003, 4
  %4005 = add i64 %3975, %4004
  %4006 = mul i64 %4005, 40
  %4007 = add i64 %4006, %57
  %4008 = fptrunc float %3871 to bfloat
  %4009 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4007
  store bfloat %4008, ptr addrspace(3) %4009, align 2
  %4010 = mul i64 %58, 8
  %4011 = add i64 %4010, 5
  %4012 = add i64 %3975, %4011
  %4013 = mul i64 %4012, 40
  %4014 = add i64 %4013, %57
  %4015 = fptrunc float %3905 to bfloat
  %4016 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4014
  store bfloat %4015, ptr addrspace(3) %4016, align 2
  %4017 = mul i64 %58, 8
  %4018 = add i64 %4017, 6
  %4019 = add i64 %3975, %4018
  %4020 = mul i64 %4019, 40
  %4021 = add i64 %4020, %57
  %4022 = fptrunc float %3939 to bfloat
  %4023 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4021
  store bfloat %4022, ptr addrspace(3) %4023, align 2
  %4024 = mul i64 %58, 8
  %4025 = add i64 %4024, 7
  %4026 = add i64 %3975, %4025
  %4027 = mul i64 %4026, 40
  %4028 = add i64 %4027, %57
  %4029 = fptrunc float %3973 to bfloat
  %4030 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4028
  store bfloat %4029, ptr addrspace(3) %4030, align 2
  %4031 = mul i64 %58, 8
  %4032 = add i64 %88, %4031
  %4033 = add i64 %91, %57
  %4034 = add i64 %4032, 7
  %4035 = icmp ult i64 %4033, %26
  %4036 = icmp ult i64 %4034, %25
  %4037 = and i1 %4036, %4035
  %4038 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4039 = ptrtoint ptr %4038 to i64
  %4040 = mul i64 %4032, 4
  %4041 = add i64 %4039, %4040
  %4042 = urem i64 %4041, 16
  %4043 = icmp eq i64 %4042, 0
  %4044 = and i1 %4037, %4043
  br i1 %4044, label %4045, label %4054

4045:                                             ; preds = %3974
  %4046 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4047 = getelementptr float, ptr %4046, i64 %4032
  %4048 = load <4 x float>, ptr %4047, align 16
  %4049 = add i64 %4032, 4
  %4050 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4051 = getelementptr float, ptr %4050, i64 %4049
  %4052 = load <4 x float>, ptr %4051, align 16
  %4053 = shufflevector <4 x float> %4048, <4 x float> %4052, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %4126

4054:                                             ; preds = %3974
  %4055 = mul i64 %58, 8
  %4056 = add i64 %88, %4055
  %4057 = icmp slt i64 %4056, %25
  %4058 = select i1 %4057, i64 %4056, i64 0
  %4059 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4060 = getelementptr inbounds nuw float, ptr %4059, i64 %4058
  %4061 = load float, ptr %4060, align 4
  %4062 = insertelement <8 x float> zeroinitializer, float %4061, i64 0
  %4063 = mul i64 %58, 8
  %4064 = add i64 %4063, 1
  %4065 = add i64 %88, %4064
  %4066 = icmp slt i64 %4065, %25
  %4067 = select i1 %4066, i64 %4065, i64 0
  %4068 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4069 = getelementptr inbounds nuw float, ptr %4068, i64 %4067
  %4070 = load float, ptr %4069, align 4
  %4071 = insertelement <8 x float> %4062, float %4070, i64 1
  %4072 = mul i64 %58, 8
  %4073 = add i64 %4072, 2
  %4074 = add i64 %88, %4073
  %4075 = icmp slt i64 %4074, %25
  %4076 = select i1 %4075, i64 %4074, i64 0
  %4077 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4078 = getelementptr inbounds nuw float, ptr %4077, i64 %4076
  %4079 = load float, ptr %4078, align 4
  %4080 = insertelement <8 x float> %4071, float %4079, i64 2
  %4081 = mul i64 %58, 8
  %4082 = add i64 %4081, 3
  %4083 = add i64 %88, %4082
  %4084 = icmp slt i64 %4083, %25
  %4085 = select i1 %4084, i64 %4083, i64 0
  %4086 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4087 = getelementptr inbounds nuw float, ptr %4086, i64 %4085
  %4088 = load float, ptr %4087, align 4
  %4089 = insertelement <8 x float> %4080, float %4088, i64 3
  %4090 = mul i64 %58, 8
  %4091 = add i64 %4090, 4
  %4092 = add i64 %88, %4091
  %4093 = icmp slt i64 %4092, %25
  %4094 = select i1 %4093, i64 %4092, i64 0
  %4095 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4096 = getelementptr inbounds nuw float, ptr %4095, i64 %4094
  %4097 = load float, ptr %4096, align 4
  %4098 = insertelement <8 x float> %4089, float %4097, i64 4
  %4099 = mul i64 %58, 8
  %4100 = add i64 %4099, 5
  %4101 = add i64 %88, %4100
  %4102 = icmp slt i64 %4101, %25
  %4103 = select i1 %4102, i64 %4101, i64 0
  %4104 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4105 = getelementptr inbounds nuw float, ptr %4104, i64 %4103
  %4106 = load float, ptr %4105, align 4
  %4107 = insertelement <8 x float> %4098, float %4106, i64 5
  %4108 = mul i64 %58, 8
  %4109 = add i64 %4108, 6
  %4110 = add i64 %88, %4109
  %4111 = icmp slt i64 %4110, %25
  %4112 = select i1 %4111, i64 %4110, i64 0
  %4113 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4114 = getelementptr inbounds nuw float, ptr %4113, i64 %4112
  %4115 = load float, ptr %4114, align 4
  %4116 = insertelement <8 x float> %4107, float %4115, i64 6
  %4117 = mul i64 %58, 8
  %4118 = add i64 %4117, 7
  %4119 = add i64 %88, %4118
  %4120 = icmp slt i64 %4119, %25
  %4121 = select i1 %4120, i64 %4119, i64 0
  %4122 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4123 = getelementptr inbounds nuw float, ptr %4122, i64 %4121
  %4124 = load float, ptr %4123, align 4
  %4125 = insertelement <8 x float> %4116, float %4124, i64 7
  br label %4126

4126:                                             ; preds = %4045, %4054
  %4127 = phi <8 x float> [ %4125, %4054 ], [ %4053, %4045 ]
  br label %4128

4128:                                             ; preds = %4126
  %4129 = add i64 %91, %57
  %4130 = icmp slt i64 %4129, %26
  %4131 = select i1 %4130, i64 %4129, i64 0
  %4132 = extractelement <8 x float> %4127, i64 0
  %4133 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4134 = getelementptr inbounds nuw i8, ptr %4133, i64 %4131
  %4135 = load i8, ptr %4134, align 1
  %4136 = zext i8 %4135 to i32
  %4137 = shl i32 %4136, 23
  %4138 = bitcast i32 %4137 to float
  %4139 = fmul float %4138, %4132
  %4140 = extractelement <8 x float> %167, i64 0
  %4141 = fmul float %4140, %4139
  %4142 = call float @llvm.fabs.f32(float %4139)
  %4143 = fcmp olt float %4142, +inf
  %4144 = fcmp one float %4139, 0.000000e+00
  %4145 = and i1 %4143, %4144
  %4146 = call i1 @llvm.expect.i1(i1 %4145, i1 true)
  br i1 %4146, label %4147, label %4148

4147:                                             ; preds = %4128
  br label %4160

4148:                                             ; preds = %4128
  %4149 = fpext float %4140 to double
  %4150 = fpext float %4138 to double
  %4151 = fpext float %4132 to double
  %4152 = fmul double %4149, %4150
  %4153 = fmul double %4152, %4151
  %4154 = fptrunc double %4153 to float
  %4155 = fcmp oeq float %4140, 0.000000e+00
  %4156 = call float @llvm.fabs.f32(float %4132)
  %4157 = fcmp olt float %4156, +inf
  %4158 = and i1 %4155, %4157
  %4159 = select i1 %4158, float 0.000000e+00, float %4154
  br label %4160

4160:                                             ; preds = %4147, %4148
  %4161 = phi float [ %4159, %4148 ], [ %4141, %4147 ]
  br label %4162

4162:                                             ; preds = %4160
  %4163 = add i64 %91, %57
  %4164 = icmp slt i64 %4163, %26
  %4165 = select i1 %4164, i64 %4163, i64 0
  %4166 = extractelement <8 x float> %4127, i64 1
  %4167 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4168 = getelementptr inbounds nuw i8, ptr %4167, i64 %4165
  %4169 = load i8, ptr %4168, align 1
  %4170 = zext i8 %4169 to i32
  %4171 = shl i32 %4170, 23
  %4172 = bitcast i32 %4171 to float
  %4173 = fmul float %4172, %4166
  %4174 = extractelement <8 x float> %167, i64 1
  %4175 = fmul float %4174, %4173
  %4176 = call float @llvm.fabs.f32(float %4173)
  %4177 = fcmp olt float %4176, +inf
  %4178 = fcmp one float %4173, 0.000000e+00
  %4179 = and i1 %4177, %4178
  %4180 = call i1 @llvm.expect.i1(i1 %4179, i1 true)
  br i1 %4180, label %4181, label %4182

4181:                                             ; preds = %4162
  br label %4194

4182:                                             ; preds = %4162
  %4183 = fpext float %4174 to double
  %4184 = fpext float %4172 to double
  %4185 = fpext float %4166 to double
  %4186 = fmul double %4183, %4184
  %4187 = fmul double %4186, %4185
  %4188 = fptrunc double %4187 to float
  %4189 = fcmp oeq float %4174, 0.000000e+00
  %4190 = call float @llvm.fabs.f32(float %4166)
  %4191 = fcmp olt float %4190, +inf
  %4192 = and i1 %4189, %4191
  %4193 = select i1 %4192, float 0.000000e+00, float %4188
  br label %4194

4194:                                             ; preds = %4181, %4182
  %4195 = phi float [ %4193, %4182 ], [ %4175, %4181 ]
  br label %4196

4196:                                             ; preds = %4194
  %4197 = add i64 %91, %57
  %4198 = icmp slt i64 %4197, %26
  %4199 = select i1 %4198, i64 %4197, i64 0
  %4200 = extractelement <8 x float> %4127, i64 2
  %4201 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4202 = getelementptr inbounds nuw i8, ptr %4201, i64 %4199
  %4203 = load i8, ptr %4202, align 1
  %4204 = zext i8 %4203 to i32
  %4205 = shl i32 %4204, 23
  %4206 = bitcast i32 %4205 to float
  %4207 = fmul float %4206, %4200
  %4208 = extractelement <8 x float> %167, i64 2
  %4209 = fmul float %4208, %4207
  %4210 = call float @llvm.fabs.f32(float %4207)
  %4211 = fcmp olt float %4210, +inf
  %4212 = fcmp one float %4207, 0.000000e+00
  %4213 = and i1 %4211, %4212
  %4214 = call i1 @llvm.expect.i1(i1 %4213, i1 true)
  br i1 %4214, label %4215, label %4216

4215:                                             ; preds = %4196
  br label %4228

4216:                                             ; preds = %4196
  %4217 = fpext float %4208 to double
  %4218 = fpext float %4206 to double
  %4219 = fpext float %4200 to double
  %4220 = fmul double %4217, %4218
  %4221 = fmul double %4220, %4219
  %4222 = fptrunc double %4221 to float
  %4223 = fcmp oeq float %4208, 0.000000e+00
  %4224 = call float @llvm.fabs.f32(float %4200)
  %4225 = fcmp olt float %4224, +inf
  %4226 = and i1 %4223, %4225
  %4227 = select i1 %4226, float 0.000000e+00, float %4222
  br label %4228

4228:                                             ; preds = %4215, %4216
  %4229 = phi float [ %4227, %4216 ], [ %4209, %4215 ]
  br label %4230

4230:                                             ; preds = %4228
  %4231 = add i64 %91, %57
  %4232 = icmp slt i64 %4231, %26
  %4233 = select i1 %4232, i64 %4231, i64 0
  %4234 = extractelement <8 x float> %4127, i64 3
  %4235 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4236 = getelementptr inbounds nuw i8, ptr %4235, i64 %4233
  %4237 = load i8, ptr %4236, align 1
  %4238 = zext i8 %4237 to i32
  %4239 = shl i32 %4238, 23
  %4240 = bitcast i32 %4239 to float
  %4241 = fmul float %4240, %4234
  %4242 = extractelement <8 x float> %167, i64 3
  %4243 = fmul float %4242, %4241
  %4244 = call float @llvm.fabs.f32(float %4241)
  %4245 = fcmp olt float %4244, +inf
  %4246 = fcmp one float %4241, 0.000000e+00
  %4247 = and i1 %4245, %4246
  %4248 = call i1 @llvm.expect.i1(i1 %4247, i1 true)
  br i1 %4248, label %4249, label %4250

4249:                                             ; preds = %4230
  br label %4262

4250:                                             ; preds = %4230
  %4251 = fpext float %4242 to double
  %4252 = fpext float %4240 to double
  %4253 = fpext float %4234 to double
  %4254 = fmul double %4251, %4252
  %4255 = fmul double %4254, %4253
  %4256 = fptrunc double %4255 to float
  %4257 = fcmp oeq float %4242, 0.000000e+00
  %4258 = call float @llvm.fabs.f32(float %4234)
  %4259 = fcmp olt float %4258, +inf
  %4260 = and i1 %4257, %4259
  %4261 = select i1 %4260, float 0.000000e+00, float %4256
  br label %4262

4262:                                             ; preds = %4249, %4250
  %4263 = phi float [ %4261, %4250 ], [ %4243, %4249 ]
  br label %4264

4264:                                             ; preds = %4262
  %4265 = add i64 %91, %57
  %4266 = icmp slt i64 %4265, %26
  %4267 = select i1 %4266, i64 %4265, i64 0
  %4268 = extractelement <8 x float> %4127, i64 4
  %4269 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4270 = getelementptr inbounds nuw i8, ptr %4269, i64 %4267
  %4271 = load i8, ptr %4270, align 1
  %4272 = zext i8 %4271 to i32
  %4273 = shl i32 %4272, 23
  %4274 = bitcast i32 %4273 to float
  %4275 = fmul float %4274, %4268
  %4276 = extractelement <8 x float> %167, i64 4
  %4277 = fmul float %4276, %4275
  %4278 = call float @llvm.fabs.f32(float %4275)
  %4279 = fcmp olt float %4278, +inf
  %4280 = fcmp one float %4275, 0.000000e+00
  %4281 = and i1 %4279, %4280
  %4282 = call i1 @llvm.expect.i1(i1 %4281, i1 true)
  br i1 %4282, label %4283, label %4284

4283:                                             ; preds = %4264
  br label %4296

4284:                                             ; preds = %4264
  %4285 = fpext float %4276 to double
  %4286 = fpext float %4274 to double
  %4287 = fpext float %4268 to double
  %4288 = fmul double %4285, %4286
  %4289 = fmul double %4288, %4287
  %4290 = fptrunc double %4289 to float
  %4291 = fcmp oeq float %4276, 0.000000e+00
  %4292 = call float @llvm.fabs.f32(float %4268)
  %4293 = fcmp olt float %4292, +inf
  %4294 = and i1 %4291, %4293
  %4295 = select i1 %4294, float 0.000000e+00, float %4290
  br label %4296

4296:                                             ; preds = %4283, %4284
  %4297 = phi float [ %4295, %4284 ], [ %4277, %4283 ]
  br label %4298

4298:                                             ; preds = %4296
  %4299 = add i64 %91, %57
  %4300 = icmp slt i64 %4299, %26
  %4301 = select i1 %4300, i64 %4299, i64 0
  %4302 = extractelement <8 x float> %4127, i64 5
  %4303 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4304 = getelementptr inbounds nuw i8, ptr %4303, i64 %4301
  %4305 = load i8, ptr %4304, align 1
  %4306 = zext i8 %4305 to i32
  %4307 = shl i32 %4306, 23
  %4308 = bitcast i32 %4307 to float
  %4309 = fmul float %4308, %4302
  %4310 = extractelement <8 x float> %167, i64 5
  %4311 = fmul float %4310, %4309
  %4312 = call float @llvm.fabs.f32(float %4309)
  %4313 = fcmp olt float %4312, +inf
  %4314 = fcmp one float %4309, 0.000000e+00
  %4315 = and i1 %4313, %4314
  %4316 = call i1 @llvm.expect.i1(i1 %4315, i1 true)
  br i1 %4316, label %4317, label %4318

4317:                                             ; preds = %4298
  br label %4330

4318:                                             ; preds = %4298
  %4319 = fpext float %4310 to double
  %4320 = fpext float %4308 to double
  %4321 = fpext float %4302 to double
  %4322 = fmul double %4319, %4320
  %4323 = fmul double %4322, %4321
  %4324 = fptrunc double %4323 to float
  %4325 = fcmp oeq float %4310, 0.000000e+00
  %4326 = call float @llvm.fabs.f32(float %4302)
  %4327 = fcmp olt float %4326, +inf
  %4328 = and i1 %4325, %4327
  %4329 = select i1 %4328, float 0.000000e+00, float %4324
  br label %4330

4330:                                             ; preds = %4317, %4318
  %4331 = phi float [ %4329, %4318 ], [ %4311, %4317 ]
  br label %4332

4332:                                             ; preds = %4330
  %4333 = add i64 %91, %57
  %4334 = icmp slt i64 %4333, %26
  %4335 = select i1 %4334, i64 %4333, i64 0
  %4336 = extractelement <8 x float> %4127, i64 6
  %4337 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4338 = getelementptr inbounds nuw i8, ptr %4337, i64 %4335
  %4339 = load i8, ptr %4338, align 1
  %4340 = zext i8 %4339 to i32
  %4341 = shl i32 %4340, 23
  %4342 = bitcast i32 %4341 to float
  %4343 = fmul float %4342, %4336
  %4344 = extractelement <8 x float> %167, i64 6
  %4345 = fmul float %4344, %4343
  %4346 = call float @llvm.fabs.f32(float %4343)
  %4347 = fcmp olt float %4346, +inf
  %4348 = fcmp one float %4343, 0.000000e+00
  %4349 = and i1 %4347, %4348
  %4350 = call i1 @llvm.expect.i1(i1 %4349, i1 true)
  br i1 %4350, label %4351, label %4352

4351:                                             ; preds = %4332
  br label %4364

4352:                                             ; preds = %4332
  %4353 = fpext float %4344 to double
  %4354 = fpext float %4342 to double
  %4355 = fpext float %4336 to double
  %4356 = fmul double %4353, %4354
  %4357 = fmul double %4356, %4355
  %4358 = fptrunc double %4357 to float
  %4359 = fcmp oeq float %4344, 0.000000e+00
  %4360 = call float @llvm.fabs.f32(float %4336)
  %4361 = fcmp olt float %4360, +inf
  %4362 = and i1 %4359, %4361
  %4363 = select i1 %4362, float 0.000000e+00, float %4358
  br label %4364

4364:                                             ; preds = %4351, %4352
  %4365 = phi float [ %4363, %4352 ], [ %4345, %4351 ]
  br label %4366

4366:                                             ; preds = %4364
  %4367 = add i64 %91, %57
  %4368 = icmp slt i64 %4367, %26
  %4369 = select i1 %4368, i64 %4367, i64 0
  %4370 = extractelement <8 x float> %4127, i64 7
  %4371 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4372 = getelementptr inbounds nuw i8, ptr %4371, i64 %4369
  %4373 = load i8, ptr %4372, align 1
  %4374 = zext i8 %4373 to i32
  %4375 = shl i32 %4374, 23
  %4376 = bitcast i32 %4375 to float
  %4377 = fmul float %4376, %4370
  %4378 = extractelement <8 x float> %167, i64 7
  %4379 = fmul float %4378, %4377
  %4380 = call float @llvm.fabs.f32(float %4377)
  %4381 = fcmp olt float %4380, +inf
  %4382 = fcmp one float %4377, 0.000000e+00
  %4383 = and i1 %4381, %4382
  %4384 = call i1 @llvm.expect.i1(i1 %4383, i1 true)
  br i1 %4384, label %4385, label %4386

4385:                                             ; preds = %4366
  br label %4398

4386:                                             ; preds = %4366
  %4387 = fpext float %4378 to double
  %4388 = fpext float %4376 to double
  %4389 = fpext float %4370 to double
  %4390 = fmul double %4387, %4388
  %4391 = fmul double %4390, %4389
  %4392 = fptrunc double %4391 to float
  %4393 = fcmp oeq float %4378, 0.000000e+00
  %4394 = call float @llvm.fabs.f32(float %4370)
  %4395 = fcmp olt float %4394, +inf
  %4396 = and i1 %4393, %4395
  %4397 = select i1 %4396, float 0.000000e+00, float %4392
  br label %4398

4398:                                             ; preds = %4385, %4386
  %4399 = phi float [ %4397, %4386 ], [ %4379, %4385 ]
  br label %4400

4400:                                             ; preds = %4398
  %4401 = mul i64 %59, 16
  %4402 = mul i64 %58, 8
  %4403 = add i64 %4401, %4402
  %4404 = add i64 %57, 16
  %4405 = mul i64 %4403, 40
  %4406 = add i64 %4405, %4404
  %4407 = fptrunc float %4161 to bfloat
  %4408 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4406
  store bfloat %4407, ptr addrspace(3) %4408, align 2
  %4409 = mul i64 %58, 8
  %4410 = add i64 %4409, 1
  %4411 = add i64 %4401, %4410
  %4412 = add i64 %57, 16
  %4413 = mul i64 %4411, 40
  %4414 = add i64 %4413, %4412
  %4415 = fptrunc float %4195 to bfloat
  %4416 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4414
  store bfloat %4415, ptr addrspace(3) %4416, align 2
  %4417 = mul i64 %58, 8
  %4418 = add i64 %4417, 2
  %4419 = add i64 %4401, %4418
  %4420 = add i64 %57, 16
  %4421 = mul i64 %4419, 40
  %4422 = add i64 %4421, %4420
  %4423 = fptrunc float %4229 to bfloat
  %4424 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4422
  store bfloat %4423, ptr addrspace(3) %4424, align 2
  %4425 = mul i64 %58, 8
  %4426 = add i64 %4425, 3
  %4427 = add i64 %4401, %4426
  %4428 = add i64 %57, 16
  %4429 = mul i64 %4427, 40
  %4430 = add i64 %4429, %4428
  %4431 = fptrunc float %4263 to bfloat
  %4432 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4430
  store bfloat %4431, ptr addrspace(3) %4432, align 2
  %4433 = mul i64 %58, 8
  %4434 = add i64 %4433, 4
  %4435 = add i64 %4401, %4434
  %4436 = add i64 %57, 16
  %4437 = mul i64 %4435, 40
  %4438 = add i64 %4437, %4436
  %4439 = fptrunc float %4297 to bfloat
  %4440 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4438
  store bfloat %4439, ptr addrspace(3) %4440, align 2
  %4441 = mul i64 %58, 8
  %4442 = add i64 %4441, 5
  %4443 = add i64 %4401, %4442
  %4444 = add i64 %57, 16
  %4445 = mul i64 %4443, 40
  %4446 = add i64 %4445, %4444
  %4447 = fptrunc float %4331 to bfloat
  %4448 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4446
  store bfloat %4447, ptr addrspace(3) %4448, align 2
  %4449 = mul i64 %58, 8
  %4450 = add i64 %4449, 6
  %4451 = add i64 %4401, %4450
  %4452 = add i64 %57, 16
  %4453 = mul i64 %4451, 40
  %4454 = add i64 %4453, %4452
  %4455 = fptrunc float %4365 to bfloat
  %4456 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4454
  store bfloat %4455, ptr addrspace(3) %4456, align 2
  %4457 = mul i64 %58, 8
  %4458 = add i64 %4457, 7
  %4459 = add i64 %4401, %4458
  %4460 = add i64 %57, 16
  %4461 = mul i64 %4459, 40
  %4462 = add i64 %4461, %4460
  %4463 = fptrunc float %4399 to bfloat
  %4464 = getelementptr inbounds nuw bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4462
  store bfloat %4463, ptr addrspace(3) %4464, align 2
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %4465 = urem i64 %55, 32
  %4466 = mul i64 %4465, 8
  %4467 = udiv i64 %4466, 32
  %4468 = urem i64 %4466, 32
  %4469 = mul i64 %59, 16
  %4470 = add i64 %4469, %4467
  %4471 = udiv i64 %59, 2
  %4472 = mul i64 %4471, 4
  %4473 = add i64 %4472, 3
  %4474 = mul i64 %4473, 16
  %4475 = add i64 %4467, %4474
  %4476 = add i64 %78, %4475
  %4477 = urem i64 %59, 2
  %4478 = mul i64 %4477, 32
  %4479 = add i64 %4468, %4478
  %4480 = add i64 %79, %4479
  %4481 = mul i64 %4470, 40
  %4482 = add i64 %4481, %4468
  %4483 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4482
  %4484 = load <8 x bfloat>, ptr addrspace(3) %4483, align 16
  %4485 = mul i64 %4476, %26
  %4486 = add i64 %4485, %4480
  %4487 = icmp ult i64 %4476, %25
  %4488 = add i64 %4480, 7
  %4489 = icmp ult i64 %4488, %26
  %4490 = and i1 %4487, %4489
  br i1 %4490, label %4491, label %4494

4491:                                             ; preds = %4400
  %4492 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4493 = getelementptr bfloat, ptr %4492, i64 %4486
  store <8 x bfloat> %4484, ptr %4493, align 2
  br label %4565

4494:                                             ; preds = %4400
  %4495 = icmp ult i64 %4480, %26
  %4496 = and i1 %4487, %4495
  br i1 %4496, label %4497, label %4501

4497:                                             ; preds = %4494
  %4498 = extractelement <8 x bfloat> %4484, i64 0
  %4499 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4500 = getelementptr inbounds nuw bfloat, ptr %4499, i64 %4486
  store bfloat %4498, ptr %4500, align 2
  br label %4501

4501:                                             ; preds = %4497, %4494
  %4502 = add i64 %4480, 1
  %4503 = icmp ult i64 %4502, %26
  %4504 = and i1 %4487, %4503
  br i1 %4504, label %4505, label %4510

4505:                                             ; preds = %4501
  %4506 = add i64 %4486, 1
  %4507 = extractelement <8 x bfloat> %4484, i64 1
  %4508 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4509 = getelementptr inbounds nuw bfloat, ptr %4508, i64 %4506
  store bfloat %4507, ptr %4509, align 2
  br label %4510

4510:                                             ; preds = %4505, %4501
  %4511 = add i64 %4480, 2
  %4512 = icmp ult i64 %4511, %26
  %4513 = and i1 %4487, %4512
  br i1 %4513, label %4514, label %4519

4514:                                             ; preds = %4510
  %4515 = add i64 %4486, 2
  %4516 = extractelement <8 x bfloat> %4484, i64 2
  %4517 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4518 = getelementptr inbounds nuw bfloat, ptr %4517, i64 %4515
  store bfloat %4516, ptr %4518, align 2
  br label %4519

4519:                                             ; preds = %4514, %4510
  %4520 = add i64 %4480, 3
  %4521 = icmp ult i64 %4520, %26
  %4522 = and i1 %4487, %4521
  br i1 %4522, label %4523, label %4528

4523:                                             ; preds = %4519
  %4524 = add i64 %4486, 3
  %4525 = extractelement <8 x bfloat> %4484, i64 3
  %4526 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4527 = getelementptr inbounds nuw bfloat, ptr %4526, i64 %4524
  store bfloat %4525, ptr %4527, align 2
  br label %4528

4528:                                             ; preds = %4523, %4519
  %4529 = add i64 %4480, 4
  %4530 = icmp ult i64 %4529, %26
  %4531 = and i1 %4487, %4530
  br i1 %4531, label %4532, label %4537

4532:                                             ; preds = %4528
  %4533 = add i64 %4486, 4
  %4534 = extractelement <8 x bfloat> %4484, i64 4
  %4535 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4536 = getelementptr inbounds nuw bfloat, ptr %4535, i64 %4533
  store bfloat %4534, ptr %4536, align 2
  br label %4537

4537:                                             ; preds = %4532, %4528
  %4538 = add i64 %4480, 5
  %4539 = icmp ult i64 %4538, %26
  %4540 = and i1 %4487, %4539
  br i1 %4540, label %4541, label %4546

4541:                                             ; preds = %4537
  %4542 = add i64 %4486, 5
  %4543 = extractelement <8 x bfloat> %4484, i64 5
  %4544 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4545 = getelementptr inbounds nuw bfloat, ptr %4544, i64 %4542
  store bfloat %4543, ptr %4545, align 2
  br label %4546

4546:                                             ; preds = %4541, %4537
  %4547 = add i64 %4480, 6
  %4548 = icmp ult i64 %4547, %26
  %4549 = and i1 %4487, %4548
  br i1 %4549, label %4550, label %4555

4550:                                             ; preds = %4546
  %4551 = add i64 %4486, 6
  %4552 = extractelement <8 x bfloat> %4484, i64 6
  %4553 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4554 = getelementptr inbounds nuw bfloat, ptr %4553, i64 %4551
  store bfloat %4552, ptr %4554, align 2
  br label %4555

4555:                                             ; preds = %4550, %4546
  %4556 = add i64 %4480, 7
  %4557 = icmp ult i64 %4556, %26
  %4558 = and i1 %4487, %4557
  br i1 %4558, label %4559, label %4564

4559:                                             ; preds = %4555
  %4560 = add i64 %4486, 7
  %4561 = extractelement <8 x bfloat> %4484, i64 7
  %4562 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4563 = getelementptr inbounds nuw bfloat, ptr %4562, i64 %4560
  store bfloat %4561, ptr %4563, align 2
  br label %4564

4564:                                             ; preds = %4559, %4555
  br label %4565

4565:                                             ; preds = %4491, %4564
  %4566 = urem i64 %55, 32
  %4567 = mul i64 %4566, 8
  %4568 = add i64 %4567, 256
  %4569 = udiv i64 %4568, 32
  %4570 = urem i64 %4568, 32
  %4571 = mul i64 %59, 16
  %4572 = add i64 %4571, %4569
  %4573 = udiv i64 %59, 2
  %4574 = mul i64 %4573, 4
  %4575 = add i64 %4574, 3
  %4576 = mul i64 %4575, 16
  %4577 = add i64 %4569, %4576
  %4578 = add i64 %78, %4577
  %4579 = urem i64 %59, 2
  %4580 = mul i64 %4579, 32
  %4581 = add i64 %4570, %4580
  %4582 = add i64 %79, %4581
  %4583 = mul i64 %4572, 40
  %4584 = add i64 %4583, %4570
  %4585 = getelementptr bfloat, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4584
  %4586 = load <8 x bfloat>, ptr addrspace(3) %4585, align 16
  %4587 = mul i64 %4578, %26
  %4588 = add i64 %4587, %4582
  %4589 = icmp ult i64 %4578, %25
  %4590 = add i64 %4582, 7
  %4591 = icmp ult i64 %4590, %26
  %4592 = and i1 %4589, %4591
  br i1 %4592, label %4593, label %4596

4593:                                             ; preds = %4565
  %4594 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4595 = getelementptr bfloat, ptr %4594, i64 %4588
  store <8 x bfloat> %4586, ptr %4595, align 2
  br label %4667

4596:                                             ; preds = %4565
  %4597 = icmp ult i64 %4582, %26
  %4598 = and i1 %4589, %4597
  br i1 %4598, label %4599, label %4603

4599:                                             ; preds = %4596
  %4600 = extractelement <8 x bfloat> %4586, i64 0
  %4601 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4602 = getelementptr inbounds nuw bfloat, ptr %4601, i64 %4588
  store bfloat %4600, ptr %4602, align 2
  br label %4603

4603:                                             ; preds = %4599, %4596
  %4604 = add i64 %4582, 1
  %4605 = icmp ult i64 %4604, %26
  %4606 = and i1 %4589, %4605
  br i1 %4606, label %4607, label %4612

4607:                                             ; preds = %4603
  %4608 = add i64 %4588, 1
  %4609 = extractelement <8 x bfloat> %4586, i64 1
  %4610 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4611 = getelementptr inbounds nuw bfloat, ptr %4610, i64 %4608
  store bfloat %4609, ptr %4611, align 2
  br label %4612

4612:                                             ; preds = %4607, %4603
  %4613 = add i64 %4582, 2
  %4614 = icmp ult i64 %4613, %26
  %4615 = and i1 %4589, %4614
  br i1 %4615, label %4616, label %4621

4616:                                             ; preds = %4612
  %4617 = add i64 %4588, 2
  %4618 = extractelement <8 x bfloat> %4586, i64 2
  %4619 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4620 = getelementptr inbounds nuw bfloat, ptr %4619, i64 %4617
  store bfloat %4618, ptr %4620, align 2
  br label %4621

4621:                                             ; preds = %4616, %4612
  %4622 = add i64 %4582, 3
  %4623 = icmp ult i64 %4622, %26
  %4624 = and i1 %4589, %4623
  br i1 %4624, label %4625, label %4630

4625:                                             ; preds = %4621
  %4626 = add i64 %4588, 3
  %4627 = extractelement <8 x bfloat> %4586, i64 3
  %4628 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4629 = getelementptr inbounds nuw bfloat, ptr %4628, i64 %4626
  store bfloat %4627, ptr %4629, align 2
  br label %4630

4630:                                             ; preds = %4625, %4621
  %4631 = add i64 %4582, 4
  %4632 = icmp ult i64 %4631, %26
  %4633 = and i1 %4589, %4632
  br i1 %4633, label %4634, label %4639

4634:                                             ; preds = %4630
  %4635 = add i64 %4588, 4
  %4636 = extractelement <8 x bfloat> %4586, i64 4
  %4637 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4638 = getelementptr inbounds nuw bfloat, ptr %4637, i64 %4635
  store bfloat %4636, ptr %4638, align 2
  br label %4639

4639:                                             ; preds = %4634, %4630
  %4640 = add i64 %4582, 5
  %4641 = icmp ult i64 %4640, %26
  %4642 = and i1 %4589, %4641
  br i1 %4642, label %4643, label %4648

4643:                                             ; preds = %4639
  %4644 = add i64 %4588, 5
  %4645 = extractelement <8 x bfloat> %4586, i64 5
  %4646 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4647 = getelementptr inbounds nuw bfloat, ptr %4646, i64 %4644
  store bfloat %4645, ptr %4647, align 2
  br label %4648

4648:                                             ; preds = %4643, %4639
  %4649 = add i64 %4582, 6
  %4650 = icmp ult i64 %4649, %26
  %4651 = and i1 %4589, %4650
  br i1 %4651, label %4652, label %4657

4652:                                             ; preds = %4648
  %4653 = add i64 %4588, 6
  %4654 = extractelement <8 x bfloat> %4586, i64 6
  %4655 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4656 = getelementptr inbounds nuw bfloat, ptr %4655, i64 %4653
  store bfloat %4654, ptr %4656, align 2
  br label %4657

4657:                                             ; preds = %4652, %4648
  %4658 = add i64 %4582, 7
  %4659 = icmp ult i64 %4658, %26
  %4660 = and i1 %4589, %4659
  br i1 %4660, label %4661, label %4666

4661:                                             ; preds = %4657
  %4662 = add i64 %4588, 7
  %4663 = extractelement <8 x bfloat> %4586, i64 7
  %4664 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4665 = getelementptr inbounds nuw bfloat, ptr %4664, i64 %4662
  store bfloat %4663, ptr %4665, align 2
  br label %4666

4666:                                             ; preds = %4661, %4657
  br label %4667

4667:                                             ; preds = %4593, %4666
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.expect.i1(i1, i1) #5

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.wave.barrier() #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #6

attributes #0 = { "amdgpu-flat-work-group-size"="256,256" "target-features"="-cumode" "uniform-work-group-size" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { convergent nocallback nofree nounwind willreturn }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #6 = { convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
