; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal addrspace(3) global [5120 x i8] undef

define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) #0 !reqd_work_group_size !1 {
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %20, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, ptr %21, 1
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, i64 %22, 2
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %23, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %24, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, ptr %16, 1
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 %17, 2
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 %18, 3, 0
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %19, 4, 0
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %10, 0
  %40 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, ptr %11, 1
  %41 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, i64 %12, 2
  %42 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %41, i64 %13, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %42, i64 %14, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %45 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %44, ptr %6, 1
  %46 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %45, i64 %7, 2
  %47 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, i64 %8, 3, 0
  %48 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, i64 %9, 4, 0
  %49 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %50 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %49, ptr %1, 1
  %51 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %50, i64 %2, 2
  %52 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %51, i64 %3, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %52, i64 %4, 4, 0
  %54 = call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %55 = sext i32 %54 to i64
  %56 = urem i64 %55, 32
  %57 = urem i64 %56, 16
  %58 = udiv i64 %56, 16
  %59 = udiv i64 %55, 32
  %60 = udiv i64 %59, 2
  %61 = urem i64 %59, 2
  %62 = call i32 @llvm.amdgcn.workgroup.id.x()
  %63 = sext i32 %62 to i64
  %64 = add i64 %25, 255
  %65 = udiv i64 %64, 256
  %66 = add i64 %26, 63
  %67 = udiv i64 %66, 64
  %68 = mul i64 %67, 4
  %69 = udiv i64 %63, %68
  %70 = mul i64 %69, 4
  %71 = sub i64 %65, %70
  %72 = icmp ult i64 %71, 4
  %73 = select i1 %72, i64 %71, i64 4
  %74 = urem i64 %63, %68
  %75 = urem i64 %74, %73
  %76 = add i64 %70, %75
  %77 = udiv i64 %74, %73
  %78 = mul i64 %76, 256
  %79 = mul i64 %77, 64
  %80 = mul i64 %60, 64
  %81 = mul i64 %61, 32
  %82 = add i64 %78, %80
  %83 = add i64 %80, 16
  %84 = add i64 %78, %83
  %85 = add i64 %80, 32
  %86 = add i64 %78, %85
  %87 = add i64 %80, 48
  %88 = add i64 %78, %87
  %89 = add i64 %79, %81
  %90 = add i64 %81, 16
  %91 = add i64 %79, %90
  %92 = udiv i64 %55, 4
  %93 = urem i64 %55, 4
  %94 = mul i64 %93, 16
  %95 = add i64 %78, %92
  %96 = mul i64 %95, %27
  %97 = add i64 %96, %94
  %98 = mul i64 %92, 80
  %99 = add i64 %98, %94
  %100 = add i64 %55, 256
  %101 = udiv i64 %100, 4
  %102 = urem i64 %100, 4
  %103 = mul i64 %102, 16
  %104 = add i64 %78, %101
  %105 = mul i64 %104, %27
  %106 = add i64 %105, %103
  %107 = mul i64 %101, 80
  %108 = add i64 %107, %103
  %109 = add i64 %55, 512
  %110 = udiv i64 %109, 4
  %111 = urem i64 %109, 4
  %112 = mul i64 %111, 16
  %113 = add i64 %78, %110
  %114 = mul i64 %113, %27
  %115 = add i64 %114, %112
  %116 = mul i64 %110, 80
  %117 = add i64 %116, %112
  %118 = add i64 %55, 768
  %119 = udiv i64 %118, 4
  %120 = urem i64 %118, 4
  %121 = mul i64 %120, 16
  %122 = add i64 %78, %119
  %123 = mul i64 %122, %27
  %124 = add i64 %123, %121
  %125 = mul i64 %119, 80
  %126 = add i64 %125, %121
  %127 = udiv i64 %55, 4
  %128 = urem i64 %55, 4
  %129 = mul i64 %128, 16
  %130 = add i64 %79, %127
  %131 = mul i64 %130, %27
  %132 = add i64 %131, %129
  %133 = mul i64 %127, 80
  %134 = add i64 %133, %129
  %135 = icmp uge i64 %27, 64
  call void @llvm.assume(i1 %135)
  %136 = udiv i64 %27, 64
  %137 = sub i64 %27, 64
  %138 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %139 = getelementptr i8, ptr %138, i64 %97
  %140 = load <16 x i8>, ptr %139, align 16
  %141 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %142 = getelementptr i8, ptr %141, i64 %106
  %143 = load <16 x i8>, ptr %142, align 16
  %144 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %145 = getelementptr i8, ptr %144, i64 %115
  %146 = load <16 x i8>, ptr %145, align 16
  %147 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %148 = getelementptr i8, ptr %147, i64 %124
  %149 = load <16 x i8>, ptr %148, align 16
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %140, ptr addrspace(3) %150, align 16
  %151 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %143, ptr addrspace(3) %151, align 16
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %146, ptr addrspace(3) %152, align 16
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %149, ptr addrspace(3) %153, align 16
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %155 = getelementptr i8, ptr %154, i64 %132
  %156 = load <16 x i8>, ptr %155, align 16
  %157 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %156, ptr addrspace(3) %157, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  br label %158

158:                                              ; preds = %169, %28
  %159 = phi i64 [ %416, %169 ], [ 0, %28 ]
  %160 = phi <8 x float> [ %403, %169 ], [ zeroinitializer, %28 ]
  %161 = phi <8 x float> [ %404, %169 ], [ zeroinitializer, %28 ]
  %162 = phi <8 x float> [ %405, %169 ], [ zeroinitializer, %28 ]
  %163 = phi <8 x float> [ %406, %169 ], [ zeroinitializer, %28 ]
  %164 = phi <8 x float> [ %407, %169 ], [ zeroinitializer, %28 ]
  %165 = phi <8 x float> [ %408, %169 ], [ zeroinitializer, %28 ]
  %166 = phi <8 x float> [ %409, %169 ], [ zeroinitializer, %28 ]
  %167 = phi <8 x float> [ %410, %169 ], [ zeroinitializer, %28 ]
  %168 = icmp slt i64 %159, %136
  br i1 %168, label %169, label %417

169:                                              ; preds = %158
  %170 = mul i64 %159, 64
  %171 = add i64 %170, 64
  %172 = call i64 @llvm.umin.i64(i64 %171, i64 %137)
  %173 = add i64 %97, %172
  %174 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %175 = getelementptr i8, ptr %174, i64 %173
  %176 = load <16 x i8>, ptr %175, align 16
  %177 = add i64 %106, %172
  %178 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %179 = getelementptr i8, ptr %178, i64 %177
  %180 = load <16 x i8>, ptr %179, align 16
  %181 = add i64 %115, %172
  %182 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %183 = getelementptr i8, ptr %182, i64 %181
  %184 = load <16 x i8>, ptr %183, align 16
  %185 = add i64 %124, %172
  %186 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %187 = getelementptr i8, ptr %186, i64 %185
  %188 = load <16 x i8>, ptr %187, align 16
  %189 = add i64 %132, %172
  %190 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %191 = getelementptr i8, ptr %190, i64 %189
  %192 = load <16 x i8>, ptr %191, align 16
  %193 = mul i64 %58, 8
  %194 = add i64 %80, %57
  %195 = mul i64 %194, 80
  %196 = add i64 %195, %193
  %197 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %196
  %198 = load <8 x i8>, ptr addrspace(3) %197, align 1
  %199 = bitcast <8 x i8> %198 to <2 x i32>
  %200 = mul i64 %58, 8
  %201 = add i64 %83, %57
  %202 = mul i64 %201, 80
  %203 = add i64 %202, %200
  %204 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %203
  %205 = load <8 x i8>, ptr addrspace(3) %204, align 1
  %206 = bitcast <8 x i8> %205 to <2 x i32>
  %207 = mul i64 %58, 8
  %208 = add i64 %85, %57
  %209 = mul i64 %208, 80
  %210 = add i64 %209, %207
  %211 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %210
  %212 = load <8 x i8>, ptr addrspace(3) %211, align 1
  %213 = bitcast <8 x i8> %212 to <2 x i32>
  %214 = mul i64 %58, 8
  %215 = add i64 %87, %57
  %216 = mul i64 %215, 80
  %217 = add i64 %216, %214
  %218 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %217
  %219 = load <8 x i8>, ptr addrspace(3) %218, align 1
  %220 = bitcast <8 x i8> %219 to <2 x i32>
  %221 = mul i64 %58, 8
  %222 = add i64 %81, %57
  %223 = mul i64 %222, 80
  %224 = add i64 %223, %221
  %225 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %224
  %226 = load <8 x i8>, ptr addrspace(3) %225, align 1
  %227 = bitcast <8 x i8> %226 to <2 x i32>
  %228 = mul i64 %58, 8
  %229 = add i64 %90, %57
  %230 = mul i64 %229, 80
  %231 = add i64 %230, %228
  %232 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %231
  %233 = load <8 x i8>, ptr addrspace(3) %232, align 1
  %234 = bitcast <8 x i8> %233 to <2 x i32>
  %235 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %227, <8 x float> %160)
  %236 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %234, <8 x float> %161)
  %237 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %227, <8 x float> %162)
  %238 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %234, <8 x float> %163)
  %239 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %227, <8 x float> %164)
  %240 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %234, <8 x float> %165)
  %241 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %227, <8 x float> %166)
  %242 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %234, <8 x float> %167)
  %243 = mul i64 %58, 8
  %244 = add i64 %80, %57
  %245 = add i64 %243, 16
  %246 = mul i64 %244, 80
  %247 = add i64 %246, %245
  %248 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %247
  %249 = load <8 x i8>, ptr addrspace(3) %248, align 1
  %250 = bitcast <8 x i8> %249 to <2 x i32>
  %251 = mul i64 %58, 8
  %252 = add i64 %83, %57
  %253 = add i64 %251, 16
  %254 = mul i64 %252, 80
  %255 = add i64 %254, %253
  %256 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %255
  %257 = load <8 x i8>, ptr addrspace(3) %256, align 1
  %258 = bitcast <8 x i8> %257 to <2 x i32>
  %259 = mul i64 %58, 8
  %260 = add i64 %85, %57
  %261 = add i64 %259, 16
  %262 = mul i64 %260, 80
  %263 = add i64 %262, %261
  %264 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %263
  %265 = load <8 x i8>, ptr addrspace(3) %264, align 1
  %266 = bitcast <8 x i8> %265 to <2 x i32>
  %267 = mul i64 %58, 8
  %268 = add i64 %87, %57
  %269 = add i64 %267, 16
  %270 = mul i64 %268, 80
  %271 = add i64 %270, %269
  %272 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %271
  %273 = load <8 x i8>, ptr addrspace(3) %272, align 1
  %274 = bitcast <8 x i8> %273 to <2 x i32>
  %275 = mul i64 %58, 8
  %276 = add i64 %275, 16
  %277 = add i64 %81, %57
  %278 = mul i64 %277, 80
  %279 = add i64 %278, %276
  %280 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %279
  %281 = load <8 x i8>, ptr addrspace(3) %280, align 1
  %282 = bitcast <8 x i8> %281 to <2 x i32>
  %283 = mul i64 %58, 8
  %284 = add i64 %283, 16
  %285 = add i64 %90, %57
  %286 = mul i64 %285, 80
  %287 = add i64 %286, %284
  %288 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %287
  %289 = load <8 x i8>, ptr addrspace(3) %288, align 1
  %290 = bitcast <8 x i8> %289 to <2 x i32>
  %291 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %282, <8 x float> %235)
  %292 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %290, <8 x float> %236)
  %293 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %282, <8 x float> %237)
  %294 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %290, <8 x float> %238)
  %295 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %282, <8 x float> %239)
  %296 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %290, <8 x float> %240)
  %297 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %282, <8 x float> %241)
  %298 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %290, <8 x float> %242)
  %299 = mul i64 %58, 8
  %300 = add i64 %80, %57
  %301 = add i64 %299, 32
  %302 = mul i64 %300, 80
  %303 = add i64 %302, %301
  %304 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %303
  %305 = load <8 x i8>, ptr addrspace(3) %304, align 1
  %306 = bitcast <8 x i8> %305 to <2 x i32>
  %307 = mul i64 %58, 8
  %308 = add i64 %83, %57
  %309 = add i64 %307, 32
  %310 = mul i64 %308, 80
  %311 = add i64 %310, %309
  %312 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %311
  %313 = load <8 x i8>, ptr addrspace(3) %312, align 1
  %314 = bitcast <8 x i8> %313 to <2 x i32>
  %315 = mul i64 %58, 8
  %316 = add i64 %85, %57
  %317 = add i64 %315, 32
  %318 = mul i64 %316, 80
  %319 = add i64 %318, %317
  %320 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %319
  %321 = load <8 x i8>, ptr addrspace(3) %320, align 1
  %322 = bitcast <8 x i8> %321 to <2 x i32>
  %323 = mul i64 %58, 8
  %324 = add i64 %87, %57
  %325 = add i64 %323, 32
  %326 = mul i64 %324, 80
  %327 = add i64 %326, %325
  %328 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %327
  %329 = load <8 x i8>, ptr addrspace(3) %328, align 1
  %330 = bitcast <8 x i8> %329 to <2 x i32>
  %331 = mul i64 %58, 8
  %332 = add i64 %331, 32
  %333 = add i64 %81, %57
  %334 = mul i64 %333, 80
  %335 = add i64 %334, %332
  %336 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %335
  %337 = load <8 x i8>, ptr addrspace(3) %336, align 1
  %338 = bitcast <8 x i8> %337 to <2 x i32>
  %339 = mul i64 %58, 8
  %340 = add i64 %339, 32
  %341 = add i64 %90, %57
  %342 = mul i64 %341, 80
  %343 = add i64 %342, %340
  %344 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %343
  %345 = load <8 x i8>, ptr addrspace(3) %344, align 1
  %346 = bitcast <8 x i8> %345 to <2 x i32>
  %347 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %338, <8 x float> %291)
  %348 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %346, <8 x float> %292)
  %349 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %338, <8 x float> %293)
  %350 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %346, <8 x float> %294)
  %351 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %338, <8 x float> %295)
  %352 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %346, <8 x float> %296)
  %353 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %338, <8 x float> %297)
  %354 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %346, <8 x float> %298)
  %355 = mul i64 %58, 8
  %356 = add i64 %80, %57
  %357 = add i64 %355, 48
  %358 = mul i64 %356, 80
  %359 = add i64 %358, %357
  %360 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %359
  %361 = load <8 x i8>, ptr addrspace(3) %360, align 1
  %362 = bitcast <8 x i8> %361 to <2 x i32>
  %363 = mul i64 %58, 8
  %364 = add i64 %83, %57
  %365 = add i64 %363, 48
  %366 = mul i64 %364, 80
  %367 = add i64 %366, %365
  %368 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %367
  %369 = load <8 x i8>, ptr addrspace(3) %368, align 1
  %370 = bitcast <8 x i8> %369 to <2 x i32>
  %371 = mul i64 %58, 8
  %372 = add i64 %85, %57
  %373 = add i64 %371, 48
  %374 = mul i64 %372, 80
  %375 = add i64 %374, %373
  %376 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %375
  %377 = load <8 x i8>, ptr addrspace(3) %376, align 1
  %378 = bitcast <8 x i8> %377 to <2 x i32>
  %379 = mul i64 %58, 8
  %380 = add i64 %87, %57
  %381 = add i64 %379, 48
  %382 = mul i64 %380, 80
  %383 = add i64 %382, %381
  %384 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %383
  %385 = load <8 x i8>, ptr addrspace(3) %384, align 1
  %386 = bitcast <8 x i8> %385 to <2 x i32>
  %387 = mul i64 %58, 8
  %388 = add i64 %387, 48
  %389 = add i64 %81, %57
  %390 = mul i64 %389, 80
  %391 = add i64 %390, %388
  %392 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %391
  %393 = load <8 x i8>, ptr addrspace(3) %392, align 1
  %394 = bitcast <8 x i8> %393 to <2 x i32>
  %395 = mul i64 %58, 8
  %396 = add i64 %395, 48
  %397 = add i64 %90, %57
  %398 = mul i64 %397, 80
  %399 = add i64 %398, %396
  %400 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %399
  %401 = load <8 x i8>, ptr addrspace(3) %400, align 1
  %402 = bitcast <8 x i8> %401 to <2 x i32>
  %403 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %394, <8 x float> %347)
  %404 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %402, <8 x float> %348)
  %405 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %394, <8 x float> %349)
  %406 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %402, <8 x float> %350)
  %407 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %394, <8 x float> %351)
  %408 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %402, <8 x float> %352)
  %409 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %394, <8 x float> %353)
  %410 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %402, <8 x float> %354)
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %411 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %176, ptr addrspace(3) %411, align 16
  %412 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %180, ptr addrspace(3) %412, align 16
  %413 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %184, ptr addrspace(3) %413, align 16
  %414 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %188, ptr addrspace(3) %414, align 16
  %415 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %192, ptr addrspace(3) %415, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %416 = add i64 %159, 1
  br label %158

417:                                              ; preds = %158
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %418 = mul i64 %58, 8
  %419 = add i64 %82, %418
  %420 = add i64 %89, %57
  %421 = add i64 %419, 7
  %422 = icmp ult i64 %420, %26
  %423 = icmp ult i64 %421, %25
  %424 = and i1 %423, %422
  %425 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %426 = ptrtoint ptr %425 to i64
  %427 = mul i64 %419, 4
  %428 = add i64 %426, %427
  %429 = urem i64 %428, 16
  %430 = icmp eq i64 %429, 0
  %431 = and i1 %424, %430
  br i1 %431, label %432, label %441

432:                                              ; preds = %417
  %433 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %434 = getelementptr float, ptr %433, i64 %419
  %435 = load <4 x float>, ptr %434, align 16
  %436 = add i64 %419, 4
  %437 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %438 = getelementptr float, ptr %437, i64 %436
  %439 = load <4 x float>, ptr %438, align 16
  %440 = shufflevector <4 x float> %435, <4 x float> %439, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %513

441:                                              ; preds = %417
  %442 = mul i64 %58, 8
  %443 = add i64 %82, %442
  %444 = icmp slt i64 %443, %25
  %445 = select i1 %444, i64 %443, i64 0
  %446 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %447 = getelementptr inbounds nuw float, ptr %446, i64 %445
  %448 = load float, ptr %447, align 4
  %449 = insertelement <8 x float> zeroinitializer, float %448, i64 0
  %450 = mul i64 %58, 8
  %451 = add i64 %450, 1
  %452 = add i64 %82, %451
  %453 = icmp slt i64 %452, %25
  %454 = select i1 %453, i64 %452, i64 0
  %455 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %456 = getelementptr inbounds nuw float, ptr %455, i64 %454
  %457 = load float, ptr %456, align 4
  %458 = insertelement <8 x float> %449, float %457, i64 1
  %459 = mul i64 %58, 8
  %460 = add i64 %459, 2
  %461 = add i64 %82, %460
  %462 = icmp slt i64 %461, %25
  %463 = select i1 %462, i64 %461, i64 0
  %464 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %465 = getelementptr inbounds nuw float, ptr %464, i64 %463
  %466 = load float, ptr %465, align 4
  %467 = insertelement <8 x float> %458, float %466, i64 2
  %468 = mul i64 %58, 8
  %469 = add i64 %468, 3
  %470 = add i64 %82, %469
  %471 = icmp slt i64 %470, %25
  %472 = select i1 %471, i64 %470, i64 0
  %473 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %474 = getelementptr inbounds nuw float, ptr %473, i64 %472
  %475 = load float, ptr %474, align 4
  %476 = insertelement <8 x float> %467, float %475, i64 3
  %477 = mul i64 %58, 8
  %478 = add i64 %477, 4
  %479 = add i64 %82, %478
  %480 = icmp slt i64 %479, %25
  %481 = select i1 %480, i64 %479, i64 0
  %482 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %483 = getelementptr inbounds nuw float, ptr %482, i64 %481
  %484 = load float, ptr %483, align 4
  %485 = insertelement <8 x float> %476, float %484, i64 4
  %486 = mul i64 %58, 8
  %487 = add i64 %486, 5
  %488 = add i64 %82, %487
  %489 = icmp slt i64 %488, %25
  %490 = select i1 %489, i64 %488, i64 0
  %491 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %492 = getelementptr inbounds nuw float, ptr %491, i64 %490
  %493 = load float, ptr %492, align 4
  %494 = insertelement <8 x float> %485, float %493, i64 5
  %495 = mul i64 %58, 8
  %496 = add i64 %495, 6
  %497 = add i64 %82, %496
  %498 = icmp slt i64 %497, %25
  %499 = select i1 %498, i64 %497, i64 0
  %500 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %501 = getelementptr inbounds nuw float, ptr %500, i64 %499
  %502 = load float, ptr %501, align 4
  %503 = insertelement <8 x float> %494, float %502, i64 6
  %504 = mul i64 %58, 8
  %505 = add i64 %504, 7
  %506 = add i64 %82, %505
  %507 = icmp slt i64 %506, %25
  %508 = select i1 %507, i64 %506, i64 0
  %509 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %510 = getelementptr inbounds nuw float, ptr %509, i64 %508
  %511 = load float, ptr %510, align 4
  %512 = insertelement <8 x float> %503, float %511, i64 7
  br label %513

513:                                              ; preds = %432, %441
  %514 = phi <8 x float> [ %512, %441 ], [ %440, %432 ]
  br label %515

515:                                              ; preds = %513
  %516 = add i64 %89, %57
  %517 = icmp slt i64 %516, %26
  %518 = select i1 %517, i64 %516, i64 0
  %519 = extractelement <8 x float> %514, i64 0
  %520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %521 = getelementptr inbounds nuw i8, ptr %520, i64 %518
  %522 = load i8, ptr %521, align 1
  %523 = zext i8 %522 to i32
  %524 = shl i32 %523, 23
  %525 = bitcast i32 %524 to float
  %526 = fmul float %525, %519
  %527 = extractelement <8 x float> %160, i64 0
  %528 = fmul float %527, %526
  %529 = call float @llvm.fabs.f32(float %526)
  %530 = fcmp olt float %529, +inf
  %531 = fcmp one float %526, 0.000000e+00
  %532 = and i1 %530, %531
  %533 = call i1 @llvm.expect.i1(i1 %532, i1 true)
  br i1 %533, label %534, label %535

534:                                              ; preds = %515
  br label %547

535:                                              ; preds = %515
  %536 = fpext float %527 to double
  %537 = fpext float %525 to double
  %538 = fpext float %519 to double
  %539 = fmul double %536, %537
  %540 = fmul double %539, %538
  %541 = fptrunc double %540 to float
  %542 = fcmp oeq float %527, 0.000000e+00
  %543 = call float @llvm.fabs.f32(float %519)
  %544 = fcmp olt float %543, +inf
  %545 = and i1 %542, %544
  %546 = select i1 %545, float 0.000000e+00, float %541
  br label %547

547:                                              ; preds = %534, %535
  %548 = phi float [ %546, %535 ], [ %528, %534 ]
  br label %549

549:                                              ; preds = %547
  %550 = add i64 %89, %57
  %551 = icmp slt i64 %550, %26
  %552 = select i1 %551, i64 %550, i64 0
  %553 = extractelement <8 x float> %514, i64 1
  %554 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %555 = getelementptr inbounds nuw i8, ptr %554, i64 %552
  %556 = load i8, ptr %555, align 1
  %557 = zext i8 %556 to i32
  %558 = shl i32 %557, 23
  %559 = bitcast i32 %558 to float
  %560 = fmul float %559, %553
  %561 = extractelement <8 x float> %160, i64 1
  %562 = fmul float %561, %560
  %563 = call float @llvm.fabs.f32(float %560)
  %564 = fcmp olt float %563, +inf
  %565 = fcmp one float %560, 0.000000e+00
  %566 = and i1 %564, %565
  %567 = call i1 @llvm.expect.i1(i1 %566, i1 true)
  br i1 %567, label %568, label %569

568:                                              ; preds = %549
  br label %581

569:                                              ; preds = %549
  %570 = fpext float %561 to double
  %571 = fpext float %559 to double
  %572 = fpext float %553 to double
  %573 = fmul double %570, %571
  %574 = fmul double %573, %572
  %575 = fptrunc double %574 to float
  %576 = fcmp oeq float %561, 0.000000e+00
  %577 = call float @llvm.fabs.f32(float %553)
  %578 = fcmp olt float %577, +inf
  %579 = and i1 %576, %578
  %580 = select i1 %579, float 0.000000e+00, float %575
  br label %581

581:                                              ; preds = %568, %569
  %582 = phi float [ %580, %569 ], [ %562, %568 ]
  br label %583

583:                                              ; preds = %581
  %584 = add i64 %89, %57
  %585 = icmp slt i64 %584, %26
  %586 = select i1 %585, i64 %584, i64 0
  %587 = extractelement <8 x float> %514, i64 2
  %588 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %589 = getelementptr inbounds nuw i8, ptr %588, i64 %586
  %590 = load i8, ptr %589, align 1
  %591 = zext i8 %590 to i32
  %592 = shl i32 %591, 23
  %593 = bitcast i32 %592 to float
  %594 = fmul float %593, %587
  %595 = extractelement <8 x float> %160, i64 2
  %596 = fmul float %595, %594
  %597 = call float @llvm.fabs.f32(float %594)
  %598 = fcmp olt float %597, +inf
  %599 = fcmp one float %594, 0.000000e+00
  %600 = and i1 %598, %599
  %601 = call i1 @llvm.expect.i1(i1 %600, i1 true)
  br i1 %601, label %602, label %603

602:                                              ; preds = %583
  br label %615

603:                                              ; preds = %583
  %604 = fpext float %595 to double
  %605 = fpext float %593 to double
  %606 = fpext float %587 to double
  %607 = fmul double %604, %605
  %608 = fmul double %607, %606
  %609 = fptrunc double %608 to float
  %610 = fcmp oeq float %595, 0.000000e+00
  %611 = call float @llvm.fabs.f32(float %587)
  %612 = fcmp olt float %611, +inf
  %613 = and i1 %610, %612
  %614 = select i1 %613, float 0.000000e+00, float %609
  br label %615

615:                                              ; preds = %602, %603
  %616 = phi float [ %614, %603 ], [ %596, %602 ]
  br label %617

617:                                              ; preds = %615
  %618 = add i64 %89, %57
  %619 = icmp slt i64 %618, %26
  %620 = select i1 %619, i64 %618, i64 0
  %621 = extractelement <8 x float> %514, i64 3
  %622 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %623 = getelementptr inbounds nuw i8, ptr %622, i64 %620
  %624 = load i8, ptr %623, align 1
  %625 = zext i8 %624 to i32
  %626 = shl i32 %625, 23
  %627 = bitcast i32 %626 to float
  %628 = fmul float %627, %621
  %629 = extractelement <8 x float> %160, i64 3
  %630 = fmul float %629, %628
  %631 = call float @llvm.fabs.f32(float %628)
  %632 = fcmp olt float %631, +inf
  %633 = fcmp one float %628, 0.000000e+00
  %634 = and i1 %632, %633
  %635 = call i1 @llvm.expect.i1(i1 %634, i1 true)
  br i1 %635, label %636, label %637

636:                                              ; preds = %617
  br label %649

637:                                              ; preds = %617
  %638 = fpext float %629 to double
  %639 = fpext float %627 to double
  %640 = fpext float %621 to double
  %641 = fmul double %638, %639
  %642 = fmul double %641, %640
  %643 = fptrunc double %642 to float
  %644 = fcmp oeq float %629, 0.000000e+00
  %645 = call float @llvm.fabs.f32(float %621)
  %646 = fcmp olt float %645, +inf
  %647 = and i1 %644, %646
  %648 = select i1 %647, float 0.000000e+00, float %643
  br label %649

649:                                              ; preds = %636, %637
  %650 = phi float [ %648, %637 ], [ %630, %636 ]
  br label %651

651:                                              ; preds = %649
  %652 = add i64 %89, %57
  %653 = icmp slt i64 %652, %26
  %654 = select i1 %653, i64 %652, i64 0
  %655 = extractelement <8 x float> %514, i64 4
  %656 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %657 = getelementptr inbounds nuw i8, ptr %656, i64 %654
  %658 = load i8, ptr %657, align 1
  %659 = zext i8 %658 to i32
  %660 = shl i32 %659, 23
  %661 = bitcast i32 %660 to float
  %662 = fmul float %661, %655
  %663 = extractelement <8 x float> %160, i64 4
  %664 = fmul float %663, %662
  %665 = call float @llvm.fabs.f32(float %662)
  %666 = fcmp olt float %665, +inf
  %667 = fcmp one float %662, 0.000000e+00
  %668 = and i1 %666, %667
  %669 = call i1 @llvm.expect.i1(i1 %668, i1 true)
  br i1 %669, label %670, label %671

670:                                              ; preds = %651
  br label %683

671:                                              ; preds = %651
  %672 = fpext float %663 to double
  %673 = fpext float %661 to double
  %674 = fpext float %655 to double
  %675 = fmul double %672, %673
  %676 = fmul double %675, %674
  %677 = fptrunc double %676 to float
  %678 = fcmp oeq float %663, 0.000000e+00
  %679 = call float @llvm.fabs.f32(float %655)
  %680 = fcmp olt float %679, +inf
  %681 = and i1 %678, %680
  %682 = select i1 %681, float 0.000000e+00, float %677
  br label %683

683:                                              ; preds = %670, %671
  %684 = phi float [ %682, %671 ], [ %664, %670 ]
  br label %685

685:                                              ; preds = %683
  %686 = add i64 %89, %57
  %687 = icmp slt i64 %686, %26
  %688 = select i1 %687, i64 %686, i64 0
  %689 = extractelement <8 x float> %514, i64 5
  %690 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %691 = getelementptr inbounds nuw i8, ptr %690, i64 %688
  %692 = load i8, ptr %691, align 1
  %693 = zext i8 %692 to i32
  %694 = shl i32 %693, 23
  %695 = bitcast i32 %694 to float
  %696 = fmul float %695, %689
  %697 = extractelement <8 x float> %160, i64 5
  %698 = fmul float %697, %696
  %699 = call float @llvm.fabs.f32(float %696)
  %700 = fcmp olt float %699, +inf
  %701 = fcmp one float %696, 0.000000e+00
  %702 = and i1 %700, %701
  %703 = call i1 @llvm.expect.i1(i1 %702, i1 true)
  br i1 %703, label %704, label %705

704:                                              ; preds = %685
  br label %717

705:                                              ; preds = %685
  %706 = fpext float %697 to double
  %707 = fpext float %695 to double
  %708 = fpext float %689 to double
  %709 = fmul double %706, %707
  %710 = fmul double %709, %708
  %711 = fptrunc double %710 to float
  %712 = fcmp oeq float %697, 0.000000e+00
  %713 = call float @llvm.fabs.f32(float %689)
  %714 = fcmp olt float %713, +inf
  %715 = and i1 %712, %714
  %716 = select i1 %715, float 0.000000e+00, float %711
  br label %717

717:                                              ; preds = %704, %705
  %718 = phi float [ %716, %705 ], [ %698, %704 ]
  br label %719

719:                                              ; preds = %717
  %720 = add i64 %89, %57
  %721 = icmp slt i64 %720, %26
  %722 = select i1 %721, i64 %720, i64 0
  %723 = extractelement <8 x float> %514, i64 6
  %724 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %725 = getelementptr inbounds nuw i8, ptr %724, i64 %722
  %726 = load i8, ptr %725, align 1
  %727 = zext i8 %726 to i32
  %728 = shl i32 %727, 23
  %729 = bitcast i32 %728 to float
  %730 = fmul float %729, %723
  %731 = extractelement <8 x float> %160, i64 6
  %732 = fmul float %731, %730
  %733 = call float @llvm.fabs.f32(float %730)
  %734 = fcmp olt float %733, +inf
  %735 = fcmp one float %730, 0.000000e+00
  %736 = and i1 %734, %735
  %737 = call i1 @llvm.expect.i1(i1 %736, i1 true)
  br i1 %737, label %738, label %739

738:                                              ; preds = %719
  br label %751

739:                                              ; preds = %719
  %740 = fpext float %731 to double
  %741 = fpext float %729 to double
  %742 = fpext float %723 to double
  %743 = fmul double %740, %741
  %744 = fmul double %743, %742
  %745 = fptrunc double %744 to float
  %746 = fcmp oeq float %731, 0.000000e+00
  %747 = call float @llvm.fabs.f32(float %723)
  %748 = fcmp olt float %747, +inf
  %749 = and i1 %746, %748
  %750 = select i1 %749, float 0.000000e+00, float %745
  br label %751

751:                                              ; preds = %738, %739
  %752 = phi float [ %750, %739 ], [ %732, %738 ]
  br label %753

753:                                              ; preds = %751
  %754 = add i64 %89, %57
  %755 = icmp slt i64 %754, %26
  %756 = select i1 %755, i64 %754, i64 0
  %757 = extractelement <8 x float> %514, i64 7
  %758 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %759 = getelementptr inbounds nuw i8, ptr %758, i64 %756
  %760 = load i8, ptr %759, align 1
  %761 = zext i8 %760 to i32
  %762 = shl i32 %761, 23
  %763 = bitcast i32 %762 to float
  %764 = fmul float %763, %757
  %765 = extractelement <8 x float> %160, i64 7
  %766 = fmul float %765, %764
  %767 = call float @llvm.fabs.f32(float %764)
  %768 = fcmp olt float %767, +inf
  %769 = fcmp one float %764, 0.000000e+00
  %770 = and i1 %768, %769
  %771 = call i1 @llvm.expect.i1(i1 %770, i1 true)
  br i1 %771, label %772, label %773

772:                                              ; preds = %753
  br label %785

773:                                              ; preds = %753
  %774 = fpext float %765 to double
  %775 = fpext float %763 to double
  %776 = fpext float %757 to double
  %777 = fmul double %774, %775
  %778 = fmul double %777, %776
  %779 = fptrunc double %778 to float
  %780 = fcmp oeq float %765, 0.000000e+00
  %781 = call float @llvm.fabs.f32(float %757)
  %782 = fcmp olt float %781, +inf
  %783 = and i1 %780, %782
  %784 = select i1 %783, float 0.000000e+00, float %779
  br label %785

785:                                              ; preds = %772, %773
  %786 = phi float [ %784, %773 ], [ %766, %772 ]
  br label %787

787:                                              ; preds = %785
  %788 = mul i64 %59, 16
  %789 = mul i64 %58, 8
  %790 = add i64 %788, %789
  %791 = mul i64 %790, 40
  %792 = add i64 %791, %57
  %793 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %792
  store float %548, ptr addrspace(3) %793, align 4
  %794 = mul i64 %58, 8
  %795 = add i64 %794, 1
  %796 = add i64 %788, %795
  %797 = mul i64 %796, 40
  %798 = add i64 %797, %57
  %799 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %798
  store float %582, ptr addrspace(3) %799, align 4
  %800 = mul i64 %58, 8
  %801 = add i64 %800, 2
  %802 = add i64 %788, %801
  %803 = mul i64 %802, 40
  %804 = add i64 %803, %57
  %805 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %804
  store float %616, ptr addrspace(3) %805, align 4
  %806 = mul i64 %58, 8
  %807 = add i64 %806, 3
  %808 = add i64 %788, %807
  %809 = mul i64 %808, 40
  %810 = add i64 %809, %57
  %811 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %810
  store float %650, ptr addrspace(3) %811, align 4
  %812 = mul i64 %58, 8
  %813 = add i64 %812, 4
  %814 = add i64 %788, %813
  %815 = mul i64 %814, 40
  %816 = add i64 %815, %57
  %817 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %816
  store float %684, ptr addrspace(3) %817, align 4
  %818 = mul i64 %58, 8
  %819 = add i64 %818, 5
  %820 = add i64 %788, %819
  %821 = mul i64 %820, 40
  %822 = add i64 %821, %57
  %823 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %822
  store float %718, ptr addrspace(3) %823, align 4
  %824 = mul i64 %58, 8
  %825 = add i64 %824, 6
  %826 = add i64 %788, %825
  %827 = mul i64 %826, 40
  %828 = add i64 %827, %57
  %829 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %828
  store float %752, ptr addrspace(3) %829, align 4
  %830 = mul i64 %58, 8
  %831 = add i64 %830, 7
  %832 = add i64 %788, %831
  %833 = mul i64 %832, 40
  %834 = add i64 %833, %57
  %835 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %834
  store float %786, ptr addrspace(3) %835, align 4
  %836 = mul i64 %58, 8
  %837 = add i64 %82, %836
  %838 = add i64 %91, %57
  %839 = add i64 %837, 7
  %840 = icmp ult i64 %838, %26
  %841 = icmp ult i64 %839, %25
  %842 = and i1 %841, %840
  %843 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %844 = ptrtoint ptr %843 to i64
  %845 = mul i64 %837, 4
  %846 = add i64 %844, %845
  %847 = urem i64 %846, 16
  %848 = icmp eq i64 %847, 0
  %849 = and i1 %842, %848
  br i1 %849, label %850, label %859

850:                                              ; preds = %787
  %851 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %852 = getelementptr float, ptr %851, i64 %837
  %853 = load <4 x float>, ptr %852, align 16
  %854 = add i64 %837, 4
  %855 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %856 = getelementptr float, ptr %855, i64 %854
  %857 = load <4 x float>, ptr %856, align 16
  %858 = shufflevector <4 x float> %853, <4 x float> %857, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %931

859:                                              ; preds = %787
  %860 = mul i64 %58, 8
  %861 = add i64 %82, %860
  %862 = icmp slt i64 %861, %25
  %863 = select i1 %862, i64 %861, i64 0
  %864 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %865 = getelementptr inbounds nuw float, ptr %864, i64 %863
  %866 = load float, ptr %865, align 4
  %867 = insertelement <8 x float> zeroinitializer, float %866, i64 0
  %868 = mul i64 %58, 8
  %869 = add i64 %868, 1
  %870 = add i64 %82, %869
  %871 = icmp slt i64 %870, %25
  %872 = select i1 %871, i64 %870, i64 0
  %873 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %874 = getelementptr inbounds nuw float, ptr %873, i64 %872
  %875 = load float, ptr %874, align 4
  %876 = insertelement <8 x float> %867, float %875, i64 1
  %877 = mul i64 %58, 8
  %878 = add i64 %877, 2
  %879 = add i64 %82, %878
  %880 = icmp slt i64 %879, %25
  %881 = select i1 %880, i64 %879, i64 0
  %882 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %883 = getelementptr inbounds nuw float, ptr %882, i64 %881
  %884 = load float, ptr %883, align 4
  %885 = insertelement <8 x float> %876, float %884, i64 2
  %886 = mul i64 %58, 8
  %887 = add i64 %886, 3
  %888 = add i64 %82, %887
  %889 = icmp slt i64 %888, %25
  %890 = select i1 %889, i64 %888, i64 0
  %891 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %892 = getelementptr inbounds nuw float, ptr %891, i64 %890
  %893 = load float, ptr %892, align 4
  %894 = insertelement <8 x float> %885, float %893, i64 3
  %895 = mul i64 %58, 8
  %896 = add i64 %895, 4
  %897 = add i64 %82, %896
  %898 = icmp slt i64 %897, %25
  %899 = select i1 %898, i64 %897, i64 0
  %900 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %901 = getelementptr inbounds nuw float, ptr %900, i64 %899
  %902 = load float, ptr %901, align 4
  %903 = insertelement <8 x float> %894, float %902, i64 4
  %904 = mul i64 %58, 8
  %905 = add i64 %904, 5
  %906 = add i64 %82, %905
  %907 = icmp slt i64 %906, %25
  %908 = select i1 %907, i64 %906, i64 0
  %909 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %910 = getelementptr inbounds nuw float, ptr %909, i64 %908
  %911 = load float, ptr %910, align 4
  %912 = insertelement <8 x float> %903, float %911, i64 5
  %913 = mul i64 %58, 8
  %914 = add i64 %913, 6
  %915 = add i64 %82, %914
  %916 = icmp slt i64 %915, %25
  %917 = select i1 %916, i64 %915, i64 0
  %918 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %919 = getelementptr inbounds nuw float, ptr %918, i64 %917
  %920 = load float, ptr %919, align 4
  %921 = insertelement <8 x float> %912, float %920, i64 6
  %922 = mul i64 %58, 8
  %923 = add i64 %922, 7
  %924 = add i64 %82, %923
  %925 = icmp slt i64 %924, %25
  %926 = select i1 %925, i64 %924, i64 0
  %927 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %928 = getelementptr inbounds nuw float, ptr %927, i64 %926
  %929 = load float, ptr %928, align 4
  %930 = insertelement <8 x float> %921, float %929, i64 7
  br label %931

931:                                              ; preds = %850, %859
  %932 = phi <8 x float> [ %930, %859 ], [ %858, %850 ]
  br label %933

933:                                              ; preds = %931
  %934 = add i64 %91, %57
  %935 = icmp slt i64 %934, %26
  %936 = select i1 %935, i64 %934, i64 0
  %937 = extractelement <8 x float> %932, i64 0
  %938 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %939 = getelementptr inbounds nuw i8, ptr %938, i64 %936
  %940 = load i8, ptr %939, align 1
  %941 = zext i8 %940 to i32
  %942 = shl i32 %941, 23
  %943 = bitcast i32 %942 to float
  %944 = fmul float %943, %937
  %945 = extractelement <8 x float> %161, i64 0
  %946 = fmul float %945, %944
  %947 = call float @llvm.fabs.f32(float %944)
  %948 = fcmp olt float %947, +inf
  %949 = fcmp one float %944, 0.000000e+00
  %950 = and i1 %948, %949
  %951 = call i1 @llvm.expect.i1(i1 %950, i1 true)
  br i1 %951, label %952, label %953

952:                                              ; preds = %933
  br label %965

953:                                              ; preds = %933
  %954 = fpext float %945 to double
  %955 = fpext float %943 to double
  %956 = fpext float %937 to double
  %957 = fmul double %954, %955
  %958 = fmul double %957, %956
  %959 = fptrunc double %958 to float
  %960 = fcmp oeq float %945, 0.000000e+00
  %961 = call float @llvm.fabs.f32(float %937)
  %962 = fcmp olt float %961, +inf
  %963 = and i1 %960, %962
  %964 = select i1 %963, float 0.000000e+00, float %959
  br label %965

965:                                              ; preds = %952, %953
  %966 = phi float [ %964, %953 ], [ %946, %952 ]
  br label %967

967:                                              ; preds = %965
  %968 = add i64 %91, %57
  %969 = icmp slt i64 %968, %26
  %970 = select i1 %969, i64 %968, i64 0
  %971 = extractelement <8 x float> %932, i64 1
  %972 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %973 = getelementptr inbounds nuw i8, ptr %972, i64 %970
  %974 = load i8, ptr %973, align 1
  %975 = zext i8 %974 to i32
  %976 = shl i32 %975, 23
  %977 = bitcast i32 %976 to float
  %978 = fmul float %977, %971
  %979 = extractelement <8 x float> %161, i64 1
  %980 = fmul float %979, %978
  %981 = call float @llvm.fabs.f32(float %978)
  %982 = fcmp olt float %981, +inf
  %983 = fcmp one float %978, 0.000000e+00
  %984 = and i1 %982, %983
  %985 = call i1 @llvm.expect.i1(i1 %984, i1 true)
  br i1 %985, label %986, label %987

986:                                              ; preds = %967
  br label %999

987:                                              ; preds = %967
  %988 = fpext float %979 to double
  %989 = fpext float %977 to double
  %990 = fpext float %971 to double
  %991 = fmul double %988, %989
  %992 = fmul double %991, %990
  %993 = fptrunc double %992 to float
  %994 = fcmp oeq float %979, 0.000000e+00
  %995 = call float @llvm.fabs.f32(float %971)
  %996 = fcmp olt float %995, +inf
  %997 = and i1 %994, %996
  %998 = select i1 %997, float 0.000000e+00, float %993
  br label %999

999:                                              ; preds = %986, %987
  %1000 = phi float [ %998, %987 ], [ %980, %986 ]
  br label %1001

1001:                                             ; preds = %999
  %1002 = add i64 %91, %57
  %1003 = icmp slt i64 %1002, %26
  %1004 = select i1 %1003, i64 %1002, i64 0
  %1005 = extractelement <8 x float> %932, i64 2
  %1006 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1007 = getelementptr inbounds nuw i8, ptr %1006, i64 %1004
  %1008 = load i8, ptr %1007, align 1
  %1009 = zext i8 %1008 to i32
  %1010 = shl i32 %1009, 23
  %1011 = bitcast i32 %1010 to float
  %1012 = fmul float %1011, %1005
  %1013 = extractelement <8 x float> %161, i64 2
  %1014 = fmul float %1013, %1012
  %1015 = call float @llvm.fabs.f32(float %1012)
  %1016 = fcmp olt float %1015, +inf
  %1017 = fcmp one float %1012, 0.000000e+00
  %1018 = and i1 %1016, %1017
  %1019 = call i1 @llvm.expect.i1(i1 %1018, i1 true)
  br i1 %1019, label %1020, label %1021

1020:                                             ; preds = %1001
  br label %1033

1021:                                             ; preds = %1001
  %1022 = fpext float %1013 to double
  %1023 = fpext float %1011 to double
  %1024 = fpext float %1005 to double
  %1025 = fmul double %1022, %1023
  %1026 = fmul double %1025, %1024
  %1027 = fptrunc double %1026 to float
  %1028 = fcmp oeq float %1013, 0.000000e+00
  %1029 = call float @llvm.fabs.f32(float %1005)
  %1030 = fcmp olt float %1029, +inf
  %1031 = and i1 %1028, %1030
  %1032 = select i1 %1031, float 0.000000e+00, float %1027
  br label %1033

1033:                                             ; preds = %1020, %1021
  %1034 = phi float [ %1032, %1021 ], [ %1014, %1020 ]
  br label %1035

1035:                                             ; preds = %1033
  %1036 = add i64 %91, %57
  %1037 = icmp slt i64 %1036, %26
  %1038 = select i1 %1037, i64 %1036, i64 0
  %1039 = extractelement <8 x float> %932, i64 3
  %1040 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1041 = getelementptr inbounds nuw i8, ptr %1040, i64 %1038
  %1042 = load i8, ptr %1041, align 1
  %1043 = zext i8 %1042 to i32
  %1044 = shl i32 %1043, 23
  %1045 = bitcast i32 %1044 to float
  %1046 = fmul float %1045, %1039
  %1047 = extractelement <8 x float> %161, i64 3
  %1048 = fmul float %1047, %1046
  %1049 = call float @llvm.fabs.f32(float %1046)
  %1050 = fcmp olt float %1049, +inf
  %1051 = fcmp one float %1046, 0.000000e+00
  %1052 = and i1 %1050, %1051
  %1053 = call i1 @llvm.expect.i1(i1 %1052, i1 true)
  br i1 %1053, label %1054, label %1055

1054:                                             ; preds = %1035
  br label %1067

1055:                                             ; preds = %1035
  %1056 = fpext float %1047 to double
  %1057 = fpext float %1045 to double
  %1058 = fpext float %1039 to double
  %1059 = fmul double %1056, %1057
  %1060 = fmul double %1059, %1058
  %1061 = fptrunc double %1060 to float
  %1062 = fcmp oeq float %1047, 0.000000e+00
  %1063 = call float @llvm.fabs.f32(float %1039)
  %1064 = fcmp olt float %1063, +inf
  %1065 = and i1 %1062, %1064
  %1066 = select i1 %1065, float 0.000000e+00, float %1061
  br label %1067

1067:                                             ; preds = %1054, %1055
  %1068 = phi float [ %1066, %1055 ], [ %1048, %1054 ]
  br label %1069

1069:                                             ; preds = %1067
  %1070 = add i64 %91, %57
  %1071 = icmp slt i64 %1070, %26
  %1072 = select i1 %1071, i64 %1070, i64 0
  %1073 = extractelement <8 x float> %932, i64 4
  %1074 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1075 = getelementptr inbounds nuw i8, ptr %1074, i64 %1072
  %1076 = load i8, ptr %1075, align 1
  %1077 = zext i8 %1076 to i32
  %1078 = shl i32 %1077, 23
  %1079 = bitcast i32 %1078 to float
  %1080 = fmul float %1079, %1073
  %1081 = extractelement <8 x float> %161, i64 4
  %1082 = fmul float %1081, %1080
  %1083 = call float @llvm.fabs.f32(float %1080)
  %1084 = fcmp olt float %1083, +inf
  %1085 = fcmp one float %1080, 0.000000e+00
  %1086 = and i1 %1084, %1085
  %1087 = call i1 @llvm.expect.i1(i1 %1086, i1 true)
  br i1 %1087, label %1088, label %1089

1088:                                             ; preds = %1069
  br label %1101

1089:                                             ; preds = %1069
  %1090 = fpext float %1081 to double
  %1091 = fpext float %1079 to double
  %1092 = fpext float %1073 to double
  %1093 = fmul double %1090, %1091
  %1094 = fmul double %1093, %1092
  %1095 = fptrunc double %1094 to float
  %1096 = fcmp oeq float %1081, 0.000000e+00
  %1097 = call float @llvm.fabs.f32(float %1073)
  %1098 = fcmp olt float %1097, +inf
  %1099 = and i1 %1096, %1098
  %1100 = select i1 %1099, float 0.000000e+00, float %1095
  br label %1101

1101:                                             ; preds = %1088, %1089
  %1102 = phi float [ %1100, %1089 ], [ %1082, %1088 ]
  br label %1103

1103:                                             ; preds = %1101
  %1104 = add i64 %91, %57
  %1105 = icmp slt i64 %1104, %26
  %1106 = select i1 %1105, i64 %1104, i64 0
  %1107 = extractelement <8 x float> %932, i64 5
  %1108 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1109 = getelementptr inbounds nuw i8, ptr %1108, i64 %1106
  %1110 = load i8, ptr %1109, align 1
  %1111 = zext i8 %1110 to i32
  %1112 = shl i32 %1111, 23
  %1113 = bitcast i32 %1112 to float
  %1114 = fmul float %1113, %1107
  %1115 = extractelement <8 x float> %161, i64 5
  %1116 = fmul float %1115, %1114
  %1117 = call float @llvm.fabs.f32(float %1114)
  %1118 = fcmp olt float %1117, +inf
  %1119 = fcmp one float %1114, 0.000000e+00
  %1120 = and i1 %1118, %1119
  %1121 = call i1 @llvm.expect.i1(i1 %1120, i1 true)
  br i1 %1121, label %1122, label %1123

1122:                                             ; preds = %1103
  br label %1135

1123:                                             ; preds = %1103
  %1124 = fpext float %1115 to double
  %1125 = fpext float %1113 to double
  %1126 = fpext float %1107 to double
  %1127 = fmul double %1124, %1125
  %1128 = fmul double %1127, %1126
  %1129 = fptrunc double %1128 to float
  %1130 = fcmp oeq float %1115, 0.000000e+00
  %1131 = call float @llvm.fabs.f32(float %1107)
  %1132 = fcmp olt float %1131, +inf
  %1133 = and i1 %1130, %1132
  %1134 = select i1 %1133, float 0.000000e+00, float %1129
  br label %1135

1135:                                             ; preds = %1122, %1123
  %1136 = phi float [ %1134, %1123 ], [ %1116, %1122 ]
  br label %1137

1137:                                             ; preds = %1135
  %1138 = add i64 %91, %57
  %1139 = icmp slt i64 %1138, %26
  %1140 = select i1 %1139, i64 %1138, i64 0
  %1141 = extractelement <8 x float> %932, i64 6
  %1142 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1143 = getelementptr inbounds nuw i8, ptr %1142, i64 %1140
  %1144 = load i8, ptr %1143, align 1
  %1145 = zext i8 %1144 to i32
  %1146 = shl i32 %1145, 23
  %1147 = bitcast i32 %1146 to float
  %1148 = fmul float %1147, %1141
  %1149 = extractelement <8 x float> %161, i64 6
  %1150 = fmul float %1149, %1148
  %1151 = call float @llvm.fabs.f32(float %1148)
  %1152 = fcmp olt float %1151, +inf
  %1153 = fcmp one float %1148, 0.000000e+00
  %1154 = and i1 %1152, %1153
  %1155 = call i1 @llvm.expect.i1(i1 %1154, i1 true)
  br i1 %1155, label %1156, label %1157

1156:                                             ; preds = %1137
  br label %1169

1157:                                             ; preds = %1137
  %1158 = fpext float %1149 to double
  %1159 = fpext float %1147 to double
  %1160 = fpext float %1141 to double
  %1161 = fmul double %1158, %1159
  %1162 = fmul double %1161, %1160
  %1163 = fptrunc double %1162 to float
  %1164 = fcmp oeq float %1149, 0.000000e+00
  %1165 = call float @llvm.fabs.f32(float %1141)
  %1166 = fcmp olt float %1165, +inf
  %1167 = and i1 %1164, %1166
  %1168 = select i1 %1167, float 0.000000e+00, float %1163
  br label %1169

1169:                                             ; preds = %1156, %1157
  %1170 = phi float [ %1168, %1157 ], [ %1150, %1156 ]
  br label %1171

1171:                                             ; preds = %1169
  %1172 = add i64 %91, %57
  %1173 = icmp slt i64 %1172, %26
  %1174 = select i1 %1173, i64 %1172, i64 0
  %1175 = extractelement <8 x float> %932, i64 7
  %1176 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1177 = getelementptr inbounds nuw i8, ptr %1176, i64 %1174
  %1178 = load i8, ptr %1177, align 1
  %1179 = zext i8 %1178 to i32
  %1180 = shl i32 %1179, 23
  %1181 = bitcast i32 %1180 to float
  %1182 = fmul float %1181, %1175
  %1183 = extractelement <8 x float> %161, i64 7
  %1184 = fmul float %1183, %1182
  %1185 = call float @llvm.fabs.f32(float %1182)
  %1186 = fcmp olt float %1185, +inf
  %1187 = fcmp one float %1182, 0.000000e+00
  %1188 = and i1 %1186, %1187
  %1189 = call i1 @llvm.expect.i1(i1 %1188, i1 true)
  br i1 %1189, label %1190, label %1191

1190:                                             ; preds = %1171
  br label %1203

1191:                                             ; preds = %1171
  %1192 = fpext float %1183 to double
  %1193 = fpext float %1181 to double
  %1194 = fpext float %1175 to double
  %1195 = fmul double %1192, %1193
  %1196 = fmul double %1195, %1194
  %1197 = fptrunc double %1196 to float
  %1198 = fcmp oeq float %1183, 0.000000e+00
  %1199 = call float @llvm.fabs.f32(float %1175)
  %1200 = fcmp olt float %1199, +inf
  %1201 = and i1 %1198, %1200
  %1202 = select i1 %1201, float 0.000000e+00, float %1197
  br label %1203

1203:                                             ; preds = %1190, %1191
  %1204 = phi float [ %1202, %1191 ], [ %1184, %1190 ]
  br label %1205

1205:                                             ; preds = %1203
  %1206 = mul i64 %59, 16
  %1207 = mul i64 %58, 8
  %1208 = add i64 %1206, %1207
  %1209 = add i64 %57, 16
  %1210 = mul i64 %1208, 40
  %1211 = add i64 %1210, %1209
  %1212 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1211
  store float %966, ptr addrspace(3) %1212, align 4
  %1213 = mul i64 %58, 8
  %1214 = add i64 %1213, 1
  %1215 = add i64 %1206, %1214
  %1216 = add i64 %57, 16
  %1217 = mul i64 %1215, 40
  %1218 = add i64 %1217, %1216
  %1219 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1218
  store float %1000, ptr addrspace(3) %1219, align 4
  %1220 = mul i64 %58, 8
  %1221 = add i64 %1220, 2
  %1222 = add i64 %1206, %1221
  %1223 = add i64 %57, 16
  %1224 = mul i64 %1222, 40
  %1225 = add i64 %1224, %1223
  %1226 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1225
  store float %1034, ptr addrspace(3) %1226, align 4
  %1227 = mul i64 %58, 8
  %1228 = add i64 %1227, 3
  %1229 = add i64 %1206, %1228
  %1230 = add i64 %57, 16
  %1231 = mul i64 %1229, 40
  %1232 = add i64 %1231, %1230
  %1233 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1232
  store float %1068, ptr addrspace(3) %1233, align 4
  %1234 = mul i64 %58, 8
  %1235 = add i64 %1234, 4
  %1236 = add i64 %1206, %1235
  %1237 = add i64 %57, 16
  %1238 = mul i64 %1236, 40
  %1239 = add i64 %1238, %1237
  %1240 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1239
  store float %1102, ptr addrspace(3) %1240, align 4
  %1241 = mul i64 %58, 8
  %1242 = add i64 %1241, 5
  %1243 = add i64 %1206, %1242
  %1244 = add i64 %57, 16
  %1245 = mul i64 %1243, 40
  %1246 = add i64 %1245, %1244
  %1247 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1246
  store float %1136, ptr addrspace(3) %1247, align 4
  %1248 = mul i64 %58, 8
  %1249 = add i64 %1248, 6
  %1250 = add i64 %1206, %1249
  %1251 = add i64 %57, 16
  %1252 = mul i64 %1250, 40
  %1253 = add i64 %1252, %1251
  %1254 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1253
  store float %1170, ptr addrspace(3) %1254, align 4
  %1255 = mul i64 %58, 8
  %1256 = add i64 %1255, 7
  %1257 = add i64 %1206, %1256
  %1258 = add i64 %57, 16
  %1259 = mul i64 %1257, 40
  %1260 = add i64 %1259, %1258
  %1261 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1260
  store float %1204, ptr addrspace(3) %1261, align 4
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %1262 = urem i64 %55, 32
  %1263 = mul i64 %1262, 8
  %1264 = udiv i64 %1263, 32
  %1265 = urem i64 %1263, 32
  %1266 = mul i64 %59, 16
  %1267 = add i64 %1266, %1264
  %1268 = udiv i64 %59, 2
  %1269 = mul i64 %1268, 4
  %1270 = mul i64 %1269, 16
  %1271 = add i64 %1264, %1270
  %1272 = add i64 %78, %1271
  %1273 = urem i64 %59, 2
  %1274 = mul i64 %1273, 32
  %1275 = add i64 %1265, %1274
  %1276 = add i64 %79, %1275
  %1277 = mul i64 %1267, 40
  %1278 = add i64 %1277, %1265
  %1279 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1278
  %1280 = load <8 x float>, ptr addrspace(3) %1279, align 16
  %1281 = fptrunc <8 x float> %1280 to <8 x bfloat>
  %1282 = mul i64 %1272, %26
  %1283 = add i64 %1282, %1276
  %1284 = icmp ult i64 %1272, %25
  %1285 = add i64 %1276, 7
  %1286 = icmp ult i64 %1285, %26
  %1287 = and i1 %1284, %1286
  br i1 %1287, label %1288, label %1291

1288:                                             ; preds = %1205
  %1289 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1290 = getelementptr bfloat, ptr %1289, i64 %1283
  store <8 x bfloat> %1281, ptr %1290, align 2
  br label %1362

1291:                                             ; preds = %1205
  %1292 = icmp ult i64 %1276, %26
  %1293 = and i1 %1284, %1292
  br i1 %1293, label %1294, label %1298

1294:                                             ; preds = %1291
  %1295 = extractelement <8 x bfloat> %1281, i64 0
  %1296 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1297 = getelementptr inbounds nuw bfloat, ptr %1296, i64 %1283
  store bfloat %1295, ptr %1297, align 2
  br label %1298

1298:                                             ; preds = %1294, %1291
  %1299 = add i64 %1276, 1
  %1300 = icmp ult i64 %1299, %26
  %1301 = and i1 %1284, %1300
  br i1 %1301, label %1302, label %1307

1302:                                             ; preds = %1298
  %1303 = add i64 %1283, 1
  %1304 = extractelement <8 x bfloat> %1281, i64 1
  %1305 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1306 = getelementptr inbounds nuw bfloat, ptr %1305, i64 %1303
  store bfloat %1304, ptr %1306, align 2
  br label %1307

1307:                                             ; preds = %1302, %1298
  %1308 = add i64 %1276, 2
  %1309 = icmp ult i64 %1308, %26
  %1310 = and i1 %1284, %1309
  br i1 %1310, label %1311, label %1316

1311:                                             ; preds = %1307
  %1312 = add i64 %1283, 2
  %1313 = extractelement <8 x bfloat> %1281, i64 2
  %1314 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1315 = getelementptr inbounds nuw bfloat, ptr %1314, i64 %1312
  store bfloat %1313, ptr %1315, align 2
  br label %1316

1316:                                             ; preds = %1311, %1307
  %1317 = add i64 %1276, 3
  %1318 = icmp ult i64 %1317, %26
  %1319 = and i1 %1284, %1318
  br i1 %1319, label %1320, label %1325

1320:                                             ; preds = %1316
  %1321 = add i64 %1283, 3
  %1322 = extractelement <8 x bfloat> %1281, i64 3
  %1323 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1324 = getelementptr inbounds nuw bfloat, ptr %1323, i64 %1321
  store bfloat %1322, ptr %1324, align 2
  br label %1325

1325:                                             ; preds = %1320, %1316
  %1326 = add i64 %1276, 4
  %1327 = icmp ult i64 %1326, %26
  %1328 = and i1 %1284, %1327
  br i1 %1328, label %1329, label %1334

1329:                                             ; preds = %1325
  %1330 = add i64 %1283, 4
  %1331 = extractelement <8 x bfloat> %1281, i64 4
  %1332 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1333 = getelementptr inbounds nuw bfloat, ptr %1332, i64 %1330
  store bfloat %1331, ptr %1333, align 2
  br label %1334

1334:                                             ; preds = %1329, %1325
  %1335 = add i64 %1276, 5
  %1336 = icmp ult i64 %1335, %26
  %1337 = and i1 %1284, %1336
  br i1 %1337, label %1338, label %1343

1338:                                             ; preds = %1334
  %1339 = add i64 %1283, 5
  %1340 = extractelement <8 x bfloat> %1281, i64 5
  %1341 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1342 = getelementptr inbounds nuw bfloat, ptr %1341, i64 %1339
  store bfloat %1340, ptr %1342, align 2
  br label %1343

1343:                                             ; preds = %1338, %1334
  %1344 = add i64 %1276, 6
  %1345 = icmp ult i64 %1344, %26
  %1346 = and i1 %1284, %1345
  br i1 %1346, label %1347, label %1352

1347:                                             ; preds = %1343
  %1348 = add i64 %1283, 6
  %1349 = extractelement <8 x bfloat> %1281, i64 6
  %1350 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1351 = getelementptr inbounds nuw bfloat, ptr %1350, i64 %1348
  store bfloat %1349, ptr %1351, align 2
  br label %1352

1352:                                             ; preds = %1347, %1343
  %1353 = add i64 %1276, 7
  %1354 = icmp ult i64 %1353, %26
  %1355 = and i1 %1284, %1354
  br i1 %1355, label %1356, label %1361

1356:                                             ; preds = %1352
  %1357 = add i64 %1283, 7
  %1358 = extractelement <8 x bfloat> %1281, i64 7
  %1359 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1360 = getelementptr inbounds nuw bfloat, ptr %1359, i64 %1357
  store bfloat %1358, ptr %1360, align 2
  br label %1361

1361:                                             ; preds = %1356, %1352
  br label %1362

1362:                                             ; preds = %1288, %1361
  %1363 = urem i64 %55, 32
  %1364 = mul i64 %1363, 8
  %1365 = add i64 %1364, 256
  %1366 = udiv i64 %1365, 32
  %1367 = urem i64 %1365, 32
  %1368 = mul i64 %59, 16
  %1369 = add i64 %1368, %1366
  %1370 = udiv i64 %59, 2
  %1371 = mul i64 %1370, 4
  %1372 = mul i64 %1371, 16
  %1373 = add i64 %1366, %1372
  %1374 = add i64 %78, %1373
  %1375 = urem i64 %59, 2
  %1376 = mul i64 %1375, 32
  %1377 = add i64 %1367, %1376
  %1378 = add i64 %79, %1377
  %1379 = mul i64 %1369, 40
  %1380 = add i64 %1379, %1367
  %1381 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1380
  %1382 = load <8 x float>, ptr addrspace(3) %1381, align 16
  %1383 = fptrunc <8 x float> %1382 to <8 x bfloat>
  %1384 = mul i64 %1374, %26
  %1385 = add i64 %1384, %1378
  %1386 = icmp ult i64 %1374, %25
  %1387 = add i64 %1378, 7
  %1388 = icmp ult i64 %1387, %26
  %1389 = and i1 %1386, %1388
  br i1 %1389, label %1390, label %1393

1390:                                             ; preds = %1362
  %1391 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1392 = getelementptr bfloat, ptr %1391, i64 %1385
  store <8 x bfloat> %1383, ptr %1392, align 2
  br label %1464

1393:                                             ; preds = %1362
  %1394 = icmp ult i64 %1378, %26
  %1395 = and i1 %1386, %1394
  br i1 %1395, label %1396, label %1400

1396:                                             ; preds = %1393
  %1397 = extractelement <8 x bfloat> %1383, i64 0
  %1398 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1399 = getelementptr inbounds nuw bfloat, ptr %1398, i64 %1385
  store bfloat %1397, ptr %1399, align 2
  br label %1400

1400:                                             ; preds = %1396, %1393
  %1401 = add i64 %1378, 1
  %1402 = icmp ult i64 %1401, %26
  %1403 = and i1 %1386, %1402
  br i1 %1403, label %1404, label %1409

1404:                                             ; preds = %1400
  %1405 = add i64 %1385, 1
  %1406 = extractelement <8 x bfloat> %1383, i64 1
  %1407 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1408 = getelementptr inbounds nuw bfloat, ptr %1407, i64 %1405
  store bfloat %1406, ptr %1408, align 2
  br label %1409

1409:                                             ; preds = %1404, %1400
  %1410 = add i64 %1378, 2
  %1411 = icmp ult i64 %1410, %26
  %1412 = and i1 %1386, %1411
  br i1 %1412, label %1413, label %1418

1413:                                             ; preds = %1409
  %1414 = add i64 %1385, 2
  %1415 = extractelement <8 x bfloat> %1383, i64 2
  %1416 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1417 = getelementptr inbounds nuw bfloat, ptr %1416, i64 %1414
  store bfloat %1415, ptr %1417, align 2
  br label %1418

1418:                                             ; preds = %1413, %1409
  %1419 = add i64 %1378, 3
  %1420 = icmp ult i64 %1419, %26
  %1421 = and i1 %1386, %1420
  br i1 %1421, label %1422, label %1427

1422:                                             ; preds = %1418
  %1423 = add i64 %1385, 3
  %1424 = extractelement <8 x bfloat> %1383, i64 3
  %1425 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1426 = getelementptr inbounds nuw bfloat, ptr %1425, i64 %1423
  store bfloat %1424, ptr %1426, align 2
  br label %1427

1427:                                             ; preds = %1422, %1418
  %1428 = add i64 %1378, 4
  %1429 = icmp ult i64 %1428, %26
  %1430 = and i1 %1386, %1429
  br i1 %1430, label %1431, label %1436

1431:                                             ; preds = %1427
  %1432 = add i64 %1385, 4
  %1433 = extractelement <8 x bfloat> %1383, i64 4
  %1434 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1435 = getelementptr inbounds nuw bfloat, ptr %1434, i64 %1432
  store bfloat %1433, ptr %1435, align 2
  br label %1436

1436:                                             ; preds = %1431, %1427
  %1437 = add i64 %1378, 5
  %1438 = icmp ult i64 %1437, %26
  %1439 = and i1 %1386, %1438
  br i1 %1439, label %1440, label %1445

1440:                                             ; preds = %1436
  %1441 = add i64 %1385, 5
  %1442 = extractelement <8 x bfloat> %1383, i64 5
  %1443 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1444 = getelementptr inbounds nuw bfloat, ptr %1443, i64 %1441
  store bfloat %1442, ptr %1444, align 2
  br label %1445

1445:                                             ; preds = %1440, %1436
  %1446 = add i64 %1378, 6
  %1447 = icmp ult i64 %1446, %26
  %1448 = and i1 %1386, %1447
  br i1 %1448, label %1449, label %1454

1449:                                             ; preds = %1445
  %1450 = add i64 %1385, 6
  %1451 = extractelement <8 x bfloat> %1383, i64 6
  %1452 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1453 = getelementptr inbounds nuw bfloat, ptr %1452, i64 %1450
  store bfloat %1451, ptr %1453, align 2
  br label %1454

1454:                                             ; preds = %1449, %1445
  %1455 = add i64 %1378, 7
  %1456 = icmp ult i64 %1455, %26
  %1457 = and i1 %1386, %1456
  br i1 %1457, label %1458, label %1463

1458:                                             ; preds = %1454
  %1459 = add i64 %1385, 7
  %1460 = extractelement <8 x bfloat> %1383, i64 7
  %1461 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1462 = getelementptr inbounds nuw bfloat, ptr %1461, i64 %1459
  store bfloat %1460, ptr %1462, align 2
  br label %1463

1463:                                             ; preds = %1458, %1454
  br label %1464

1464:                                             ; preds = %1390, %1463
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %1465 = mul i64 %58, 8
  %1466 = add i64 %84, %1465
  %1467 = add i64 %89, %57
  %1468 = add i64 %1466, 7
  %1469 = icmp ult i64 %1467, %26
  %1470 = icmp ult i64 %1468, %25
  %1471 = and i1 %1470, %1469
  %1472 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1473 = ptrtoint ptr %1472 to i64
  %1474 = mul i64 %1466, 4
  %1475 = add i64 %1473, %1474
  %1476 = urem i64 %1475, 16
  %1477 = icmp eq i64 %1476, 0
  %1478 = and i1 %1471, %1477
  br i1 %1478, label %1479, label %1488

1479:                                             ; preds = %1464
  %1480 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1481 = getelementptr float, ptr %1480, i64 %1466
  %1482 = load <4 x float>, ptr %1481, align 16
  %1483 = add i64 %1466, 4
  %1484 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1485 = getelementptr float, ptr %1484, i64 %1483
  %1486 = load <4 x float>, ptr %1485, align 16
  %1487 = shufflevector <4 x float> %1482, <4 x float> %1486, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1560

1488:                                             ; preds = %1464
  %1489 = mul i64 %58, 8
  %1490 = add i64 %84, %1489
  %1491 = icmp slt i64 %1490, %25
  %1492 = select i1 %1491, i64 %1490, i64 0
  %1493 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1494 = getelementptr inbounds nuw float, ptr %1493, i64 %1492
  %1495 = load float, ptr %1494, align 4
  %1496 = insertelement <8 x float> zeroinitializer, float %1495, i64 0
  %1497 = mul i64 %58, 8
  %1498 = add i64 %1497, 1
  %1499 = add i64 %84, %1498
  %1500 = icmp slt i64 %1499, %25
  %1501 = select i1 %1500, i64 %1499, i64 0
  %1502 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1503 = getelementptr inbounds nuw float, ptr %1502, i64 %1501
  %1504 = load float, ptr %1503, align 4
  %1505 = insertelement <8 x float> %1496, float %1504, i64 1
  %1506 = mul i64 %58, 8
  %1507 = add i64 %1506, 2
  %1508 = add i64 %84, %1507
  %1509 = icmp slt i64 %1508, %25
  %1510 = select i1 %1509, i64 %1508, i64 0
  %1511 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1512 = getelementptr inbounds nuw float, ptr %1511, i64 %1510
  %1513 = load float, ptr %1512, align 4
  %1514 = insertelement <8 x float> %1505, float %1513, i64 2
  %1515 = mul i64 %58, 8
  %1516 = add i64 %1515, 3
  %1517 = add i64 %84, %1516
  %1518 = icmp slt i64 %1517, %25
  %1519 = select i1 %1518, i64 %1517, i64 0
  %1520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1521 = getelementptr inbounds nuw float, ptr %1520, i64 %1519
  %1522 = load float, ptr %1521, align 4
  %1523 = insertelement <8 x float> %1514, float %1522, i64 3
  %1524 = mul i64 %58, 8
  %1525 = add i64 %1524, 4
  %1526 = add i64 %84, %1525
  %1527 = icmp slt i64 %1526, %25
  %1528 = select i1 %1527, i64 %1526, i64 0
  %1529 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1530 = getelementptr inbounds nuw float, ptr %1529, i64 %1528
  %1531 = load float, ptr %1530, align 4
  %1532 = insertelement <8 x float> %1523, float %1531, i64 4
  %1533 = mul i64 %58, 8
  %1534 = add i64 %1533, 5
  %1535 = add i64 %84, %1534
  %1536 = icmp slt i64 %1535, %25
  %1537 = select i1 %1536, i64 %1535, i64 0
  %1538 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1539 = getelementptr inbounds nuw float, ptr %1538, i64 %1537
  %1540 = load float, ptr %1539, align 4
  %1541 = insertelement <8 x float> %1532, float %1540, i64 5
  %1542 = mul i64 %58, 8
  %1543 = add i64 %1542, 6
  %1544 = add i64 %84, %1543
  %1545 = icmp slt i64 %1544, %25
  %1546 = select i1 %1545, i64 %1544, i64 0
  %1547 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1548 = getelementptr inbounds nuw float, ptr %1547, i64 %1546
  %1549 = load float, ptr %1548, align 4
  %1550 = insertelement <8 x float> %1541, float %1549, i64 6
  %1551 = mul i64 %58, 8
  %1552 = add i64 %1551, 7
  %1553 = add i64 %84, %1552
  %1554 = icmp slt i64 %1553, %25
  %1555 = select i1 %1554, i64 %1553, i64 0
  %1556 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1557 = getelementptr inbounds nuw float, ptr %1556, i64 %1555
  %1558 = load float, ptr %1557, align 4
  %1559 = insertelement <8 x float> %1550, float %1558, i64 7
  br label %1560

1560:                                             ; preds = %1479, %1488
  %1561 = phi <8 x float> [ %1559, %1488 ], [ %1487, %1479 ]
  br label %1562

1562:                                             ; preds = %1560
  %1563 = add i64 %89, %57
  %1564 = icmp slt i64 %1563, %26
  %1565 = select i1 %1564, i64 %1563, i64 0
  %1566 = extractelement <8 x float> %1561, i64 0
  %1567 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1568 = getelementptr inbounds nuw i8, ptr %1567, i64 %1565
  %1569 = load i8, ptr %1568, align 1
  %1570 = zext i8 %1569 to i32
  %1571 = shl i32 %1570, 23
  %1572 = bitcast i32 %1571 to float
  %1573 = fmul float %1572, %1566
  %1574 = extractelement <8 x float> %162, i64 0
  %1575 = fmul float %1574, %1573
  %1576 = call float @llvm.fabs.f32(float %1573)
  %1577 = fcmp olt float %1576, +inf
  %1578 = fcmp one float %1573, 0.000000e+00
  %1579 = and i1 %1577, %1578
  %1580 = call i1 @llvm.expect.i1(i1 %1579, i1 true)
  br i1 %1580, label %1581, label %1582

1581:                                             ; preds = %1562
  br label %1594

1582:                                             ; preds = %1562
  %1583 = fpext float %1574 to double
  %1584 = fpext float %1572 to double
  %1585 = fpext float %1566 to double
  %1586 = fmul double %1583, %1584
  %1587 = fmul double %1586, %1585
  %1588 = fptrunc double %1587 to float
  %1589 = fcmp oeq float %1574, 0.000000e+00
  %1590 = call float @llvm.fabs.f32(float %1566)
  %1591 = fcmp olt float %1590, +inf
  %1592 = and i1 %1589, %1591
  %1593 = select i1 %1592, float 0.000000e+00, float %1588
  br label %1594

1594:                                             ; preds = %1581, %1582
  %1595 = phi float [ %1593, %1582 ], [ %1575, %1581 ]
  br label %1596

1596:                                             ; preds = %1594
  %1597 = add i64 %89, %57
  %1598 = icmp slt i64 %1597, %26
  %1599 = select i1 %1598, i64 %1597, i64 0
  %1600 = extractelement <8 x float> %1561, i64 1
  %1601 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1602 = getelementptr inbounds nuw i8, ptr %1601, i64 %1599
  %1603 = load i8, ptr %1602, align 1
  %1604 = zext i8 %1603 to i32
  %1605 = shl i32 %1604, 23
  %1606 = bitcast i32 %1605 to float
  %1607 = fmul float %1606, %1600
  %1608 = extractelement <8 x float> %162, i64 1
  %1609 = fmul float %1608, %1607
  %1610 = call float @llvm.fabs.f32(float %1607)
  %1611 = fcmp olt float %1610, +inf
  %1612 = fcmp one float %1607, 0.000000e+00
  %1613 = and i1 %1611, %1612
  %1614 = call i1 @llvm.expect.i1(i1 %1613, i1 true)
  br i1 %1614, label %1615, label %1616

1615:                                             ; preds = %1596
  br label %1628

1616:                                             ; preds = %1596
  %1617 = fpext float %1608 to double
  %1618 = fpext float %1606 to double
  %1619 = fpext float %1600 to double
  %1620 = fmul double %1617, %1618
  %1621 = fmul double %1620, %1619
  %1622 = fptrunc double %1621 to float
  %1623 = fcmp oeq float %1608, 0.000000e+00
  %1624 = call float @llvm.fabs.f32(float %1600)
  %1625 = fcmp olt float %1624, +inf
  %1626 = and i1 %1623, %1625
  %1627 = select i1 %1626, float 0.000000e+00, float %1622
  br label %1628

1628:                                             ; preds = %1615, %1616
  %1629 = phi float [ %1627, %1616 ], [ %1609, %1615 ]
  br label %1630

1630:                                             ; preds = %1628
  %1631 = add i64 %89, %57
  %1632 = icmp slt i64 %1631, %26
  %1633 = select i1 %1632, i64 %1631, i64 0
  %1634 = extractelement <8 x float> %1561, i64 2
  %1635 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1636 = getelementptr inbounds nuw i8, ptr %1635, i64 %1633
  %1637 = load i8, ptr %1636, align 1
  %1638 = zext i8 %1637 to i32
  %1639 = shl i32 %1638, 23
  %1640 = bitcast i32 %1639 to float
  %1641 = fmul float %1640, %1634
  %1642 = extractelement <8 x float> %162, i64 2
  %1643 = fmul float %1642, %1641
  %1644 = call float @llvm.fabs.f32(float %1641)
  %1645 = fcmp olt float %1644, +inf
  %1646 = fcmp one float %1641, 0.000000e+00
  %1647 = and i1 %1645, %1646
  %1648 = call i1 @llvm.expect.i1(i1 %1647, i1 true)
  br i1 %1648, label %1649, label %1650

1649:                                             ; preds = %1630
  br label %1662

1650:                                             ; preds = %1630
  %1651 = fpext float %1642 to double
  %1652 = fpext float %1640 to double
  %1653 = fpext float %1634 to double
  %1654 = fmul double %1651, %1652
  %1655 = fmul double %1654, %1653
  %1656 = fptrunc double %1655 to float
  %1657 = fcmp oeq float %1642, 0.000000e+00
  %1658 = call float @llvm.fabs.f32(float %1634)
  %1659 = fcmp olt float %1658, +inf
  %1660 = and i1 %1657, %1659
  %1661 = select i1 %1660, float 0.000000e+00, float %1656
  br label %1662

1662:                                             ; preds = %1649, %1650
  %1663 = phi float [ %1661, %1650 ], [ %1643, %1649 ]
  br label %1664

1664:                                             ; preds = %1662
  %1665 = add i64 %89, %57
  %1666 = icmp slt i64 %1665, %26
  %1667 = select i1 %1666, i64 %1665, i64 0
  %1668 = extractelement <8 x float> %1561, i64 3
  %1669 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1670 = getelementptr inbounds nuw i8, ptr %1669, i64 %1667
  %1671 = load i8, ptr %1670, align 1
  %1672 = zext i8 %1671 to i32
  %1673 = shl i32 %1672, 23
  %1674 = bitcast i32 %1673 to float
  %1675 = fmul float %1674, %1668
  %1676 = extractelement <8 x float> %162, i64 3
  %1677 = fmul float %1676, %1675
  %1678 = call float @llvm.fabs.f32(float %1675)
  %1679 = fcmp olt float %1678, +inf
  %1680 = fcmp one float %1675, 0.000000e+00
  %1681 = and i1 %1679, %1680
  %1682 = call i1 @llvm.expect.i1(i1 %1681, i1 true)
  br i1 %1682, label %1683, label %1684

1683:                                             ; preds = %1664
  br label %1696

1684:                                             ; preds = %1664
  %1685 = fpext float %1676 to double
  %1686 = fpext float %1674 to double
  %1687 = fpext float %1668 to double
  %1688 = fmul double %1685, %1686
  %1689 = fmul double %1688, %1687
  %1690 = fptrunc double %1689 to float
  %1691 = fcmp oeq float %1676, 0.000000e+00
  %1692 = call float @llvm.fabs.f32(float %1668)
  %1693 = fcmp olt float %1692, +inf
  %1694 = and i1 %1691, %1693
  %1695 = select i1 %1694, float 0.000000e+00, float %1690
  br label %1696

1696:                                             ; preds = %1683, %1684
  %1697 = phi float [ %1695, %1684 ], [ %1677, %1683 ]
  br label %1698

1698:                                             ; preds = %1696
  %1699 = add i64 %89, %57
  %1700 = icmp slt i64 %1699, %26
  %1701 = select i1 %1700, i64 %1699, i64 0
  %1702 = extractelement <8 x float> %1561, i64 4
  %1703 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1704 = getelementptr inbounds nuw i8, ptr %1703, i64 %1701
  %1705 = load i8, ptr %1704, align 1
  %1706 = zext i8 %1705 to i32
  %1707 = shl i32 %1706, 23
  %1708 = bitcast i32 %1707 to float
  %1709 = fmul float %1708, %1702
  %1710 = extractelement <8 x float> %162, i64 4
  %1711 = fmul float %1710, %1709
  %1712 = call float @llvm.fabs.f32(float %1709)
  %1713 = fcmp olt float %1712, +inf
  %1714 = fcmp one float %1709, 0.000000e+00
  %1715 = and i1 %1713, %1714
  %1716 = call i1 @llvm.expect.i1(i1 %1715, i1 true)
  br i1 %1716, label %1717, label %1718

1717:                                             ; preds = %1698
  br label %1730

1718:                                             ; preds = %1698
  %1719 = fpext float %1710 to double
  %1720 = fpext float %1708 to double
  %1721 = fpext float %1702 to double
  %1722 = fmul double %1719, %1720
  %1723 = fmul double %1722, %1721
  %1724 = fptrunc double %1723 to float
  %1725 = fcmp oeq float %1710, 0.000000e+00
  %1726 = call float @llvm.fabs.f32(float %1702)
  %1727 = fcmp olt float %1726, +inf
  %1728 = and i1 %1725, %1727
  %1729 = select i1 %1728, float 0.000000e+00, float %1724
  br label %1730

1730:                                             ; preds = %1717, %1718
  %1731 = phi float [ %1729, %1718 ], [ %1711, %1717 ]
  br label %1732

1732:                                             ; preds = %1730
  %1733 = add i64 %89, %57
  %1734 = icmp slt i64 %1733, %26
  %1735 = select i1 %1734, i64 %1733, i64 0
  %1736 = extractelement <8 x float> %1561, i64 5
  %1737 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1738 = getelementptr inbounds nuw i8, ptr %1737, i64 %1735
  %1739 = load i8, ptr %1738, align 1
  %1740 = zext i8 %1739 to i32
  %1741 = shl i32 %1740, 23
  %1742 = bitcast i32 %1741 to float
  %1743 = fmul float %1742, %1736
  %1744 = extractelement <8 x float> %162, i64 5
  %1745 = fmul float %1744, %1743
  %1746 = call float @llvm.fabs.f32(float %1743)
  %1747 = fcmp olt float %1746, +inf
  %1748 = fcmp one float %1743, 0.000000e+00
  %1749 = and i1 %1747, %1748
  %1750 = call i1 @llvm.expect.i1(i1 %1749, i1 true)
  br i1 %1750, label %1751, label %1752

1751:                                             ; preds = %1732
  br label %1764

1752:                                             ; preds = %1732
  %1753 = fpext float %1744 to double
  %1754 = fpext float %1742 to double
  %1755 = fpext float %1736 to double
  %1756 = fmul double %1753, %1754
  %1757 = fmul double %1756, %1755
  %1758 = fptrunc double %1757 to float
  %1759 = fcmp oeq float %1744, 0.000000e+00
  %1760 = call float @llvm.fabs.f32(float %1736)
  %1761 = fcmp olt float %1760, +inf
  %1762 = and i1 %1759, %1761
  %1763 = select i1 %1762, float 0.000000e+00, float %1758
  br label %1764

1764:                                             ; preds = %1751, %1752
  %1765 = phi float [ %1763, %1752 ], [ %1745, %1751 ]
  br label %1766

1766:                                             ; preds = %1764
  %1767 = add i64 %89, %57
  %1768 = icmp slt i64 %1767, %26
  %1769 = select i1 %1768, i64 %1767, i64 0
  %1770 = extractelement <8 x float> %1561, i64 6
  %1771 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1772 = getelementptr inbounds nuw i8, ptr %1771, i64 %1769
  %1773 = load i8, ptr %1772, align 1
  %1774 = zext i8 %1773 to i32
  %1775 = shl i32 %1774, 23
  %1776 = bitcast i32 %1775 to float
  %1777 = fmul float %1776, %1770
  %1778 = extractelement <8 x float> %162, i64 6
  %1779 = fmul float %1778, %1777
  %1780 = call float @llvm.fabs.f32(float %1777)
  %1781 = fcmp olt float %1780, +inf
  %1782 = fcmp one float %1777, 0.000000e+00
  %1783 = and i1 %1781, %1782
  %1784 = call i1 @llvm.expect.i1(i1 %1783, i1 true)
  br i1 %1784, label %1785, label %1786

1785:                                             ; preds = %1766
  br label %1798

1786:                                             ; preds = %1766
  %1787 = fpext float %1778 to double
  %1788 = fpext float %1776 to double
  %1789 = fpext float %1770 to double
  %1790 = fmul double %1787, %1788
  %1791 = fmul double %1790, %1789
  %1792 = fptrunc double %1791 to float
  %1793 = fcmp oeq float %1778, 0.000000e+00
  %1794 = call float @llvm.fabs.f32(float %1770)
  %1795 = fcmp olt float %1794, +inf
  %1796 = and i1 %1793, %1795
  %1797 = select i1 %1796, float 0.000000e+00, float %1792
  br label %1798

1798:                                             ; preds = %1785, %1786
  %1799 = phi float [ %1797, %1786 ], [ %1779, %1785 ]
  br label %1800

1800:                                             ; preds = %1798
  %1801 = add i64 %89, %57
  %1802 = icmp slt i64 %1801, %26
  %1803 = select i1 %1802, i64 %1801, i64 0
  %1804 = extractelement <8 x float> %1561, i64 7
  %1805 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1806 = getelementptr inbounds nuw i8, ptr %1805, i64 %1803
  %1807 = load i8, ptr %1806, align 1
  %1808 = zext i8 %1807 to i32
  %1809 = shl i32 %1808, 23
  %1810 = bitcast i32 %1809 to float
  %1811 = fmul float %1810, %1804
  %1812 = extractelement <8 x float> %162, i64 7
  %1813 = fmul float %1812, %1811
  %1814 = call float @llvm.fabs.f32(float %1811)
  %1815 = fcmp olt float %1814, +inf
  %1816 = fcmp one float %1811, 0.000000e+00
  %1817 = and i1 %1815, %1816
  %1818 = call i1 @llvm.expect.i1(i1 %1817, i1 true)
  br i1 %1818, label %1819, label %1820

1819:                                             ; preds = %1800
  br label %1832

1820:                                             ; preds = %1800
  %1821 = fpext float %1812 to double
  %1822 = fpext float %1810 to double
  %1823 = fpext float %1804 to double
  %1824 = fmul double %1821, %1822
  %1825 = fmul double %1824, %1823
  %1826 = fptrunc double %1825 to float
  %1827 = fcmp oeq float %1812, 0.000000e+00
  %1828 = call float @llvm.fabs.f32(float %1804)
  %1829 = fcmp olt float %1828, +inf
  %1830 = and i1 %1827, %1829
  %1831 = select i1 %1830, float 0.000000e+00, float %1826
  br label %1832

1832:                                             ; preds = %1819, %1820
  %1833 = phi float [ %1831, %1820 ], [ %1813, %1819 ]
  br label %1834

1834:                                             ; preds = %1832
  %1835 = mul i64 %59, 16
  %1836 = mul i64 %58, 8
  %1837 = add i64 %1835, %1836
  %1838 = mul i64 %1837, 40
  %1839 = add i64 %1838, %57
  %1840 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1839
  store float %1595, ptr addrspace(3) %1840, align 4
  %1841 = mul i64 %58, 8
  %1842 = add i64 %1841, 1
  %1843 = add i64 %1835, %1842
  %1844 = mul i64 %1843, 40
  %1845 = add i64 %1844, %57
  %1846 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1845
  store float %1629, ptr addrspace(3) %1846, align 4
  %1847 = mul i64 %58, 8
  %1848 = add i64 %1847, 2
  %1849 = add i64 %1835, %1848
  %1850 = mul i64 %1849, 40
  %1851 = add i64 %1850, %57
  %1852 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1851
  store float %1663, ptr addrspace(3) %1852, align 4
  %1853 = mul i64 %58, 8
  %1854 = add i64 %1853, 3
  %1855 = add i64 %1835, %1854
  %1856 = mul i64 %1855, 40
  %1857 = add i64 %1856, %57
  %1858 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1857
  store float %1697, ptr addrspace(3) %1858, align 4
  %1859 = mul i64 %58, 8
  %1860 = add i64 %1859, 4
  %1861 = add i64 %1835, %1860
  %1862 = mul i64 %1861, 40
  %1863 = add i64 %1862, %57
  %1864 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1863
  store float %1731, ptr addrspace(3) %1864, align 4
  %1865 = mul i64 %58, 8
  %1866 = add i64 %1865, 5
  %1867 = add i64 %1835, %1866
  %1868 = mul i64 %1867, 40
  %1869 = add i64 %1868, %57
  %1870 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1869
  store float %1765, ptr addrspace(3) %1870, align 4
  %1871 = mul i64 %58, 8
  %1872 = add i64 %1871, 6
  %1873 = add i64 %1835, %1872
  %1874 = mul i64 %1873, 40
  %1875 = add i64 %1874, %57
  %1876 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1875
  store float %1799, ptr addrspace(3) %1876, align 4
  %1877 = mul i64 %58, 8
  %1878 = add i64 %1877, 7
  %1879 = add i64 %1835, %1878
  %1880 = mul i64 %1879, 40
  %1881 = add i64 %1880, %57
  %1882 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1881
  store float %1833, ptr addrspace(3) %1882, align 4
  %1883 = mul i64 %58, 8
  %1884 = add i64 %84, %1883
  %1885 = add i64 %91, %57
  %1886 = add i64 %1884, 7
  %1887 = icmp ult i64 %1885, %26
  %1888 = icmp ult i64 %1886, %25
  %1889 = and i1 %1888, %1887
  %1890 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1891 = ptrtoint ptr %1890 to i64
  %1892 = mul i64 %1884, 4
  %1893 = add i64 %1891, %1892
  %1894 = urem i64 %1893, 16
  %1895 = icmp eq i64 %1894, 0
  %1896 = and i1 %1889, %1895
  br i1 %1896, label %1897, label %1906

1897:                                             ; preds = %1834
  %1898 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1899 = getelementptr float, ptr %1898, i64 %1884
  %1900 = load <4 x float>, ptr %1899, align 16
  %1901 = add i64 %1884, 4
  %1902 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1903 = getelementptr float, ptr %1902, i64 %1901
  %1904 = load <4 x float>, ptr %1903, align 16
  %1905 = shufflevector <4 x float> %1900, <4 x float> %1904, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1978

1906:                                             ; preds = %1834
  %1907 = mul i64 %58, 8
  %1908 = add i64 %84, %1907
  %1909 = icmp slt i64 %1908, %25
  %1910 = select i1 %1909, i64 %1908, i64 0
  %1911 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1912 = getelementptr inbounds nuw float, ptr %1911, i64 %1910
  %1913 = load float, ptr %1912, align 4
  %1914 = insertelement <8 x float> zeroinitializer, float %1913, i64 0
  %1915 = mul i64 %58, 8
  %1916 = add i64 %1915, 1
  %1917 = add i64 %84, %1916
  %1918 = icmp slt i64 %1917, %25
  %1919 = select i1 %1918, i64 %1917, i64 0
  %1920 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1921 = getelementptr inbounds nuw float, ptr %1920, i64 %1919
  %1922 = load float, ptr %1921, align 4
  %1923 = insertelement <8 x float> %1914, float %1922, i64 1
  %1924 = mul i64 %58, 8
  %1925 = add i64 %1924, 2
  %1926 = add i64 %84, %1925
  %1927 = icmp slt i64 %1926, %25
  %1928 = select i1 %1927, i64 %1926, i64 0
  %1929 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1930 = getelementptr inbounds nuw float, ptr %1929, i64 %1928
  %1931 = load float, ptr %1930, align 4
  %1932 = insertelement <8 x float> %1923, float %1931, i64 2
  %1933 = mul i64 %58, 8
  %1934 = add i64 %1933, 3
  %1935 = add i64 %84, %1934
  %1936 = icmp slt i64 %1935, %25
  %1937 = select i1 %1936, i64 %1935, i64 0
  %1938 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1939 = getelementptr inbounds nuw float, ptr %1938, i64 %1937
  %1940 = load float, ptr %1939, align 4
  %1941 = insertelement <8 x float> %1932, float %1940, i64 3
  %1942 = mul i64 %58, 8
  %1943 = add i64 %1942, 4
  %1944 = add i64 %84, %1943
  %1945 = icmp slt i64 %1944, %25
  %1946 = select i1 %1945, i64 %1944, i64 0
  %1947 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1948 = getelementptr inbounds nuw float, ptr %1947, i64 %1946
  %1949 = load float, ptr %1948, align 4
  %1950 = insertelement <8 x float> %1941, float %1949, i64 4
  %1951 = mul i64 %58, 8
  %1952 = add i64 %1951, 5
  %1953 = add i64 %84, %1952
  %1954 = icmp slt i64 %1953, %25
  %1955 = select i1 %1954, i64 %1953, i64 0
  %1956 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1957 = getelementptr inbounds nuw float, ptr %1956, i64 %1955
  %1958 = load float, ptr %1957, align 4
  %1959 = insertelement <8 x float> %1950, float %1958, i64 5
  %1960 = mul i64 %58, 8
  %1961 = add i64 %1960, 6
  %1962 = add i64 %84, %1961
  %1963 = icmp slt i64 %1962, %25
  %1964 = select i1 %1963, i64 %1962, i64 0
  %1965 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1966 = getelementptr inbounds nuw float, ptr %1965, i64 %1964
  %1967 = load float, ptr %1966, align 4
  %1968 = insertelement <8 x float> %1959, float %1967, i64 6
  %1969 = mul i64 %58, 8
  %1970 = add i64 %1969, 7
  %1971 = add i64 %84, %1970
  %1972 = icmp slt i64 %1971, %25
  %1973 = select i1 %1972, i64 %1971, i64 0
  %1974 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1975 = getelementptr inbounds nuw float, ptr %1974, i64 %1973
  %1976 = load float, ptr %1975, align 4
  %1977 = insertelement <8 x float> %1968, float %1976, i64 7
  br label %1978

1978:                                             ; preds = %1897, %1906
  %1979 = phi <8 x float> [ %1977, %1906 ], [ %1905, %1897 ]
  br label %1980

1980:                                             ; preds = %1978
  %1981 = add i64 %91, %57
  %1982 = icmp slt i64 %1981, %26
  %1983 = select i1 %1982, i64 %1981, i64 0
  %1984 = extractelement <8 x float> %1979, i64 0
  %1985 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1986 = getelementptr inbounds nuw i8, ptr %1985, i64 %1983
  %1987 = load i8, ptr %1986, align 1
  %1988 = zext i8 %1987 to i32
  %1989 = shl i32 %1988, 23
  %1990 = bitcast i32 %1989 to float
  %1991 = fmul float %1990, %1984
  %1992 = extractelement <8 x float> %163, i64 0
  %1993 = fmul float %1992, %1991
  %1994 = call float @llvm.fabs.f32(float %1991)
  %1995 = fcmp olt float %1994, +inf
  %1996 = fcmp one float %1991, 0.000000e+00
  %1997 = and i1 %1995, %1996
  %1998 = call i1 @llvm.expect.i1(i1 %1997, i1 true)
  br i1 %1998, label %1999, label %2000

1999:                                             ; preds = %1980
  br label %2012

2000:                                             ; preds = %1980
  %2001 = fpext float %1992 to double
  %2002 = fpext float %1990 to double
  %2003 = fpext float %1984 to double
  %2004 = fmul double %2001, %2002
  %2005 = fmul double %2004, %2003
  %2006 = fptrunc double %2005 to float
  %2007 = fcmp oeq float %1992, 0.000000e+00
  %2008 = call float @llvm.fabs.f32(float %1984)
  %2009 = fcmp olt float %2008, +inf
  %2010 = and i1 %2007, %2009
  %2011 = select i1 %2010, float 0.000000e+00, float %2006
  br label %2012

2012:                                             ; preds = %1999, %2000
  %2013 = phi float [ %2011, %2000 ], [ %1993, %1999 ]
  br label %2014

2014:                                             ; preds = %2012
  %2015 = add i64 %91, %57
  %2016 = icmp slt i64 %2015, %26
  %2017 = select i1 %2016, i64 %2015, i64 0
  %2018 = extractelement <8 x float> %1979, i64 1
  %2019 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2020 = getelementptr inbounds nuw i8, ptr %2019, i64 %2017
  %2021 = load i8, ptr %2020, align 1
  %2022 = zext i8 %2021 to i32
  %2023 = shl i32 %2022, 23
  %2024 = bitcast i32 %2023 to float
  %2025 = fmul float %2024, %2018
  %2026 = extractelement <8 x float> %163, i64 1
  %2027 = fmul float %2026, %2025
  %2028 = call float @llvm.fabs.f32(float %2025)
  %2029 = fcmp olt float %2028, +inf
  %2030 = fcmp one float %2025, 0.000000e+00
  %2031 = and i1 %2029, %2030
  %2032 = call i1 @llvm.expect.i1(i1 %2031, i1 true)
  br i1 %2032, label %2033, label %2034

2033:                                             ; preds = %2014
  br label %2046

2034:                                             ; preds = %2014
  %2035 = fpext float %2026 to double
  %2036 = fpext float %2024 to double
  %2037 = fpext float %2018 to double
  %2038 = fmul double %2035, %2036
  %2039 = fmul double %2038, %2037
  %2040 = fptrunc double %2039 to float
  %2041 = fcmp oeq float %2026, 0.000000e+00
  %2042 = call float @llvm.fabs.f32(float %2018)
  %2043 = fcmp olt float %2042, +inf
  %2044 = and i1 %2041, %2043
  %2045 = select i1 %2044, float 0.000000e+00, float %2040
  br label %2046

2046:                                             ; preds = %2033, %2034
  %2047 = phi float [ %2045, %2034 ], [ %2027, %2033 ]
  br label %2048

2048:                                             ; preds = %2046
  %2049 = add i64 %91, %57
  %2050 = icmp slt i64 %2049, %26
  %2051 = select i1 %2050, i64 %2049, i64 0
  %2052 = extractelement <8 x float> %1979, i64 2
  %2053 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2054 = getelementptr inbounds nuw i8, ptr %2053, i64 %2051
  %2055 = load i8, ptr %2054, align 1
  %2056 = zext i8 %2055 to i32
  %2057 = shl i32 %2056, 23
  %2058 = bitcast i32 %2057 to float
  %2059 = fmul float %2058, %2052
  %2060 = extractelement <8 x float> %163, i64 2
  %2061 = fmul float %2060, %2059
  %2062 = call float @llvm.fabs.f32(float %2059)
  %2063 = fcmp olt float %2062, +inf
  %2064 = fcmp one float %2059, 0.000000e+00
  %2065 = and i1 %2063, %2064
  %2066 = call i1 @llvm.expect.i1(i1 %2065, i1 true)
  br i1 %2066, label %2067, label %2068

2067:                                             ; preds = %2048
  br label %2080

2068:                                             ; preds = %2048
  %2069 = fpext float %2060 to double
  %2070 = fpext float %2058 to double
  %2071 = fpext float %2052 to double
  %2072 = fmul double %2069, %2070
  %2073 = fmul double %2072, %2071
  %2074 = fptrunc double %2073 to float
  %2075 = fcmp oeq float %2060, 0.000000e+00
  %2076 = call float @llvm.fabs.f32(float %2052)
  %2077 = fcmp olt float %2076, +inf
  %2078 = and i1 %2075, %2077
  %2079 = select i1 %2078, float 0.000000e+00, float %2074
  br label %2080

2080:                                             ; preds = %2067, %2068
  %2081 = phi float [ %2079, %2068 ], [ %2061, %2067 ]
  br label %2082

2082:                                             ; preds = %2080
  %2083 = add i64 %91, %57
  %2084 = icmp slt i64 %2083, %26
  %2085 = select i1 %2084, i64 %2083, i64 0
  %2086 = extractelement <8 x float> %1979, i64 3
  %2087 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2088 = getelementptr inbounds nuw i8, ptr %2087, i64 %2085
  %2089 = load i8, ptr %2088, align 1
  %2090 = zext i8 %2089 to i32
  %2091 = shl i32 %2090, 23
  %2092 = bitcast i32 %2091 to float
  %2093 = fmul float %2092, %2086
  %2094 = extractelement <8 x float> %163, i64 3
  %2095 = fmul float %2094, %2093
  %2096 = call float @llvm.fabs.f32(float %2093)
  %2097 = fcmp olt float %2096, +inf
  %2098 = fcmp one float %2093, 0.000000e+00
  %2099 = and i1 %2097, %2098
  %2100 = call i1 @llvm.expect.i1(i1 %2099, i1 true)
  br i1 %2100, label %2101, label %2102

2101:                                             ; preds = %2082
  br label %2114

2102:                                             ; preds = %2082
  %2103 = fpext float %2094 to double
  %2104 = fpext float %2092 to double
  %2105 = fpext float %2086 to double
  %2106 = fmul double %2103, %2104
  %2107 = fmul double %2106, %2105
  %2108 = fptrunc double %2107 to float
  %2109 = fcmp oeq float %2094, 0.000000e+00
  %2110 = call float @llvm.fabs.f32(float %2086)
  %2111 = fcmp olt float %2110, +inf
  %2112 = and i1 %2109, %2111
  %2113 = select i1 %2112, float 0.000000e+00, float %2108
  br label %2114

2114:                                             ; preds = %2101, %2102
  %2115 = phi float [ %2113, %2102 ], [ %2095, %2101 ]
  br label %2116

2116:                                             ; preds = %2114
  %2117 = add i64 %91, %57
  %2118 = icmp slt i64 %2117, %26
  %2119 = select i1 %2118, i64 %2117, i64 0
  %2120 = extractelement <8 x float> %1979, i64 4
  %2121 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2122 = getelementptr inbounds nuw i8, ptr %2121, i64 %2119
  %2123 = load i8, ptr %2122, align 1
  %2124 = zext i8 %2123 to i32
  %2125 = shl i32 %2124, 23
  %2126 = bitcast i32 %2125 to float
  %2127 = fmul float %2126, %2120
  %2128 = extractelement <8 x float> %163, i64 4
  %2129 = fmul float %2128, %2127
  %2130 = call float @llvm.fabs.f32(float %2127)
  %2131 = fcmp olt float %2130, +inf
  %2132 = fcmp one float %2127, 0.000000e+00
  %2133 = and i1 %2131, %2132
  %2134 = call i1 @llvm.expect.i1(i1 %2133, i1 true)
  br i1 %2134, label %2135, label %2136

2135:                                             ; preds = %2116
  br label %2148

2136:                                             ; preds = %2116
  %2137 = fpext float %2128 to double
  %2138 = fpext float %2126 to double
  %2139 = fpext float %2120 to double
  %2140 = fmul double %2137, %2138
  %2141 = fmul double %2140, %2139
  %2142 = fptrunc double %2141 to float
  %2143 = fcmp oeq float %2128, 0.000000e+00
  %2144 = call float @llvm.fabs.f32(float %2120)
  %2145 = fcmp olt float %2144, +inf
  %2146 = and i1 %2143, %2145
  %2147 = select i1 %2146, float 0.000000e+00, float %2142
  br label %2148

2148:                                             ; preds = %2135, %2136
  %2149 = phi float [ %2147, %2136 ], [ %2129, %2135 ]
  br label %2150

2150:                                             ; preds = %2148
  %2151 = add i64 %91, %57
  %2152 = icmp slt i64 %2151, %26
  %2153 = select i1 %2152, i64 %2151, i64 0
  %2154 = extractelement <8 x float> %1979, i64 5
  %2155 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2156 = getelementptr inbounds nuw i8, ptr %2155, i64 %2153
  %2157 = load i8, ptr %2156, align 1
  %2158 = zext i8 %2157 to i32
  %2159 = shl i32 %2158, 23
  %2160 = bitcast i32 %2159 to float
  %2161 = fmul float %2160, %2154
  %2162 = extractelement <8 x float> %163, i64 5
  %2163 = fmul float %2162, %2161
  %2164 = call float @llvm.fabs.f32(float %2161)
  %2165 = fcmp olt float %2164, +inf
  %2166 = fcmp one float %2161, 0.000000e+00
  %2167 = and i1 %2165, %2166
  %2168 = call i1 @llvm.expect.i1(i1 %2167, i1 true)
  br i1 %2168, label %2169, label %2170

2169:                                             ; preds = %2150
  br label %2182

2170:                                             ; preds = %2150
  %2171 = fpext float %2162 to double
  %2172 = fpext float %2160 to double
  %2173 = fpext float %2154 to double
  %2174 = fmul double %2171, %2172
  %2175 = fmul double %2174, %2173
  %2176 = fptrunc double %2175 to float
  %2177 = fcmp oeq float %2162, 0.000000e+00
  %2178 = call float @llvm.fabs.f32(float %2154)
  %2179 = fcmp olt float %2178, +inf
  %2180 = and i1 %2177, %2179
  %2181 = select i1 %2180, float 0.000000e+00, float %2176
  br label %2182

2182:                                             ; preds = %2169, %2170
  %2183 = phi float [ %2181, %2170 ], [ %2163, %2169 ]
  br label %2184

2184:                                             ; preds = %2182
  %2185 = add i64 %91, %57
  %2186 = icmp slt i64 %2185, %26
  %2187 = select i1 %2186, i64 %2185, i64 0
  %2188 = extractelement <8 x float> %1979, i64 6
  %2189 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2190 = getelementptr inbounds nuw i8, ptr %2189, i64 %2187
  %2191 = load i8, ptr %2190, align 1
  %2192 = zext i8 %2191 to i32
  %2193 = shl i32 %2192, 23
  %2194 = bitcast i32 %2193 to float
  %2195 = fmul float %2194, %2188
  %2196 = extractelement <8 x float> %163, i64 6
  %2197 = fmul float %2196, %2195
  %2198 = call float @llvm.fabs.f32(float %2195)
  %2199 = fcmp olt float %2198, +inf
  %2200 = fcmp one float %2195, 0.000000e+00
  %2201 = and i1 %2199, %2200
  %2202 = call i1 @llvm.expect.i1(i1 %2201, i1 true)
  br i1 %2202, label %2203, label %2204

2203:                                             ; preds = %2184
  br label %2216

2204:                                             ; preds = %2184
  %2205 = fpext float %2196 to double
  %2206 = fpext float %2194 to double
  %2207 = fpext float %2188 to double
  %2208 = fmul double %2205, %2206
  %2209 = fmul double %2208, %2207
  %2210 = fptrunc double %2209 to float
  %2211 = fcmp oeq float %2196, 0.000000e+00
  %2212 = call float @llvm.fabs.f32(float %2188)
  %2213 = fcmp olt float %2212, +inf
  %2214 = and i1 %2211, %2213
  %2215 = select i1 %2214, float 0.000000e+00, float %2210
  br label %2216

2216:                                             ; preds = %2203, %2204
  %2217 = phi float [ %2215, %2204 ], [ %2197, %2203 ]
  br label %2218

2218:                                             ; preds = %2216
  %2219 = add i64 %91, %57
  %2220 = icmp slt i64 %2219, %26
  %2221 = select i1 %2220, i64 %2219, i64 0
  %2222 = extractelement <8 x float> %1979, i64 7
  %2223 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2224 = getelementptr inbounds nuw i8, ptr %2223, i64 %2221
  %2225 = load i8, ptr %2224, align 1
  %2226 = zext i8 %2225 to i32
  %2227 = shl i32 %2226, 23
  %2228 = bitcast i32 %2227 to float
  %2229 = fmul float %2228, %2222
  %2230 = extractelement <8 x float> %163, i64 7
  %2231 = fmul float %2230, %2229
  %2232 = call float @llvm.fabs.f32(float %2229)
  %2233 = fcmp olt float %2232, +inf
  %2234 = fcmp one float %2229, 0.000000e+00
  %2235 = and i1 %2233, %2234
  %2236 = call i1 @llvm.expect.i1(i1 %2235, i1 true)
  br i1 %2236, label %2237, label %2238

2237:                                             ; preds = %2218
  br label %2250

2238:                                             ; preds = %2218
  %2239 = fpext float %2230 to double
  %2240 = fpext float %2228 to double
  %2241 = fpext float %2222 to double
  %2242 = fmul double %2239, %2240
  %2243 = fmul double %2242, %2241
  %2244 = fptrunc double %2243 to float
  %2245 = fcmp oeq float %2230, 0.000000e+00
  %2246 = call float @llvm.fabs.f32(float %2222)
  %2247 = fcmp olt float %2246, +inf
  %2248 = and i1 %2245, %2247
  %2249 = select i1 %2248, float 0.000000e+00, float %2244
  br label %2250

2250:                                             ; preds = %2237, %2238
  %2251 = phi float [ %2249, %2238 ], [ %2231, %2237 ]
  br label %2252

2252:                                             ; preds = %2250
  %2253 = mul i64 %59, 16
  %2254 = mul i64 %58, 8
  %2255 = add i64 %2253, %2254
  %2256 = add i64 %57, 16
  %2257 = mul i64 %2255, 40
  %2258 = add i64 %2257, %2256
  %2259 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2258
  store float %2013, ptr addrspace(3) %2259, align 4
  %2260 = mul i64 %58, 8
  %2261 = add i64 %2260, 1
  %2262 = add i64 %2253, %2261
  %2263 = add i64 %57, 16
  %2264 = mul i64 %2262, 40
  %2265 = add i64 %2264, %2263
  %2266 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2265
  store float %2047, ptr addrspace(3) %2266, align 4
  %2267 = mul i64 %58, 8
  %2268 = add i64 %2267, 2
  %2269 = add i64 %2253, %2268
  %2270 = add i64 %57, 16
  %2271 = mul i64 %2269, 40
  %2272 = add i64 %2271, %2270
  %2273 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2272
  store float %2081, ptr addrspace(3) %2273, align 4
  %2274 = mul i64 %58, 8
  %2275 = add i64 %2274, 3
  %2276 = add i64 %2253, %2275
  %2277 = add i64 %57, 16
  %2278 = mul i64 %2276, 40
  %2279 = add i64 %2278, %2277
  %2280 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2279
  store float %2115, ptr addrspace(3) %2280, align 4
  %2281 = mul i64 %58, 8
  %2282 = add i64 %2281, 4
  %2283 = add i64 %2253, %2282
  %2284 = add i64 %57, 16
  %2285 = mul i64 %2283, 40
  %2286 = add i64 %2285, %2284
  %2287 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2286
  store float %2149, ptr addrspace(3) %2287, align 4
  %2288 = mul i64 %58, 8
  %2289 = add i64 %2288, 5
  %2290 = add i64 %2253, %2289
  %2291 = add i64 %57, 16
  %2292 = mul i64 %2290, 40
  %2293 = add i64 %2292, %2291
  %2294 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2293
  store float %2183, ptr addrspace(3) %2294, align 4
  %2295 = mul i64 %58, 8
  %2296 = add i64 %2295, 6
  %2297 = add i64 %2253, %2296
  %2298 = add i64 %57, 16
  %2299 = mul i64 %2297, 40
  %2300 = add i64 %2299, %2298
  %2301 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2300
  store float %2217, ptr addrspace(3) %2301, align 4
  %2302 = mul i64 %58, 8
  %2303 = add i64 %2302, 7
  %2304 = add i64 %2253, %2303
  %2305 = add i64 %57, 16
  %2306 = mul i64 %2304, 40
  %2307 = add i64 %2306, %2305
  %2308 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2307
  store float %2251, ptr addrspace(3) %2308, align 4
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %2309 = urem i64 %55, 32
  %2310 = mul i64 %2309, 8
  %2311 = udiv i64 %2310, 32
  %2312 = urem i64 %2310, 32
  %2313 = mul i64 %59, 16
  %2314 = add i64 %2313, %2311
  %2315 = udiv i64 %59, 2
  %2316 = mul i64 %2315, 4
  %2317 = add i64 %2316, 1
  %2318 = mul i64 %2317, 16
  %2319 = add i64 %2311, %2318
  %2320 = add i64 %78, %2319
  %2321 = urem i64 %59, 2
  %2322 = mul i64 %2321, 32
  %2323 = add i64 %2312, %2322
  %2324 = add i64 %79, %2323
  %2325 = mul i64 %2314, 40
  %2326 = add i64 %2325, %2312
  %2327 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2326
  %2328 = load <8 x float>, ptr addrspace(3) %2327, align 16
  %2329 = fptrunc <8 x float> %2328 to <8 x bfloat>
  %2330 = mul i64 %2320, %26
  %2331 = add i64 %2330, %2324
  %2332 = icmp ult i64 %2320, %25
  %2333 = add i64 %2324, 7
  %2334 = icmp ult i64 %2333, %26
  %2335 = and i1 %2332, %2334
  br i1 %2335, label %2336, label %2339

2336:                                             ; preds = %2252
  %2337 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2338 = getelementptr bfloat, ptr %2337, i64 %2331
  store <8 x bfloat> %2329, ptr %2338, align 2
  br label %2410

2339:                                             ; preds = %2252
  %2340 = icmp ult i64 %2324, %26
  %2341 = and i1 %2332, %2340
  br i1 %2341, label %2342, label %2346

2342:                                             ; preds = %2339
  %2343 = extractelement <8 x bfloat> %2329, i64 0
  %2344 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2345 = getelementptr inbounds nuw bfloat, ptr %2344, i64 %2331
  store bfloat %2343, ptr %2345, align 2
  br label %2346

2346:                                             ; preds = %2342, %2339
  %2347 = add i64 %2324, 1
  %2348 = icmp ult i64 %2347, %26
  %2349 = and i1 %2332, %2348
  br i1 %2349, label %2350, label %2355

2350:                                             ; preds = %2346
  %2351 = add i64 %2331, 1
  %2352 = extractelement <8 x bfloat> %2329, i64 1
  %2353 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2354 = getelementptr inbounds nuw bfloat, ptr %2353, i64 %2351
  store bfloat %2352, ptr %2354, align 2
  br label %2355

2355:                                             ; preds = %2350, %2346
  %2356 = add i64 %2324, 2
  %2357 = icmp ult i64 %2356, %26
  %2358 = and i1 %2332, %2357
  br i1 %2358, label %2359, label %2364

2359:                                             ; preds = %2355
  %2360 = add i64 %2331, 2
  %2361 = extractelement <8 x bfloat> %2329, i64 2
  %2362 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2363 = getelementptr inbounds nuw bfloat, ptr %2362, i64 %2360
  store bfloat %2361, ptr %2363, align 2
  br label %2364

2364:                                             ; preds = %2359, %2355
  %2365 = add i64 %2324, 3
  %2366 = icmp ult i64 %2365, %26
  %2367 = and i1 %2332, %2366
  br i1 %2367, label %2368, label %2373

2368:                                             ; preds = %2364
  %2369 = add i64 %2331, 3
  %2370 = extractelement <8 x bfloat> %2329, i64 3
  %2371 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2372 = getelementptr inbounds nuw bfloat, ptr %2371, i64 %2369
  store bfloat %2370, ptr %2372, align 2
  br label %2373

2373:                                             ; preds = %2368, %2364
  %2374 = add i64 %2324, 4
  %2375 = icmp ult i64 %2374, %26
  %2376 = and i1 %2332, %2375
  br i1 %2376, label %2377, label %2382

2377:                                             ; preds = %2373
  %2378 = add i64 %2331, 4
  %2379 = extractelement <8 x bfloat> %2329, i64 4
  %2380 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2381 = getelementptr inbounds nuw bfloat, ptr %2380, i64 %2378
  store bfloat %2379, ptr %2381, align 2
  br label %2382

2382:                                             ; preds = %2377, %2373
  %2383 = add i64 %2324, 5
  %2384 = icmp ult i64 %2383, %26
  %2385 = and i1 %2332, %2384
  br i1 %2385, label %2386, label %2391

2386:                                             ; preds = %2382
  %2387 = add i64 %2331, 5
  %2388 = extractelement <8 x bfloat> %2329, i64 5
  %2389 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2390 = getelementptr inbounds nuw bfloat, ptr %2389, i64 %2387
  store bfloat %2388, ptr %2390, align 2
  br label %2391

2391:                                             ; preds = %2386, %2382
  %2392 = add i64 %2324, 6
  %2393 = icmp ult i64 %2392, %26
  %2394 = and i1 %2332, %2393
  br i1 %2394, label %2395, label %2400

2395:                                             ; preds = %2391
  %2396 = add i64 %2331, 6
  %2397 = extractelement <8 x bfloat> %2329, i64 6
  %2398 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2399 = getelementptr inbounds nuw bfloat, ptr %2398, i64 %2396
  store bfloat %2397, ptr %2399, align 2
  br label %2400

2400:                                             ; preds = %2395, %2391
  %2401 = add i64 %2324, 7
  %2402 = icmp ult i64 %2401, %26
  %2403 = and i1 %2332, %2402
  br i1 %2403, label %2404, label %2409

2404:                                             ; preds = %2400
  %2405 = add i64 %2331, 7
  %2406 = extractelement <8 x bfloat> %2329, i64 7
  %2407 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2408 = getelementptr inbounds nuw bfloat, ptr %2407, i64 %2405
  store bfloat %2406, ptr %2408, align 2
  br label %2409

2409:                                             ; preds = %2404, %2400
  br label %2410

2410:                                             ; preds = %2336, %2409
  %2411 = urem i64 %55, 32
  %2412 = mul i64 %2411, 8
  %2413 = add i64 %2412, 256
  %2414 = udiv i64 %2413, 32
  %2415 = urem i64 %2413, 32
  %2416 = mul i64 %59, 16
  %2417 = add i64 %2416, %2414
  %2418 = udiv i64 %59, 2
  %2419 = mul i64 %2418, 4
  %2420 = add i64 %2419, 1
  %2421 = mul i64 %2420, 16
  %2422 = add i64 %2414, %2421
  %2423 = add i64 %78, %2422
  %2424 = urem i64 %59, 2
  %2425 = mul i64 %2424, 32
  %2426 = add i64 %2415, %2425
  %2427 = add i64 %79, %2426
  %2428 = mul i64 %2417, 40
  %2429 = add i64 %2428, %2415
  %2430 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2429
  %2431 = load <8 x float>, ptr addrspace(3) %2430, align 16
  %2432 = fptrunc <8 x float> %2431 to <8 x bfloat>
  %2433 = mul i64 %2423, %26
  %2434 = add i64 %2433, %2427
  %2435 = icmp ult i64 %2423, %25
  %2436 = add i64 %2427, 7
  %2437 = icmp ult i64 %2436, %26
  %2438 = and i1 %2435, %2437
  br i1 %2438, label %2439, label %2442

2439:                                             ; preds = %2410
  %2440 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2441 = getelementptr bfloat, ptr %2440, i64 %2434
  store <8 x bfloat> %2432, ptr %2441, align 2
  br label %2513

2442:                                             ; preds = %2410
  %2443 = icmp ult i64 %2427, %26
  %2444 = and i1 %2435, %2443
  br i1 %2444, label %2445, label %2449

2445:                                             ; preds = %2442
  %2446 = extractelement <8 x bfloat> %2432, i64 0
  %2447 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2448 = getelementptr inbounds nuw bfloat, ptr %2447, i64 %2434
  store bfloat %2446, ptr %2448, align 2
  br label %2449

2449:                                             ; preds = %2445, %2442
  %2450 = add i64 %2427, 1
  %2451 = icmp ult i64 %2450, %26
  %2452 = and i1 %2435, %2451
  br i1 %2452, label %2453, label %2458

2453:                                             ; preds = %2449
  %2454 = add i64 %2434, 1
  %2455 = extractelement <8 x bfloat> %2432, i64 1
  %2456 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2457 = getelementptr inbounds nuw bfloat, ptr %2456, i64 %2454
  store bfloat %2455, ptr %2457, align 2
  br label %2458

2458:                                             ; preds = %2453, %2449
  %2459 = add i64 %2427, 2
  %2460 = icmp ult i64 %2459, %26
  %2461 = and i1 %2435, %2460
  br i1 %2461, label %2462, label %2467

2462:                                             ; preds = %2458
  %2463 = add i64 %2434, 2
  %2464 = extractelement <8 x bfloat> %2432, i64 2
  %2465 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2466 = getelementptr inbounds nuw bfloat, ptr %2465, i64 %2463
  store bfloat %2464, ptr %2466, align 2
  br label %2467

2467:                                             ; preds = %2462, %2458
  %2468 = add i64 %2427, 3
  %2469 = icmp ult i64 %2468, %26
  %2470 = and i1 %2435, %2469
  br i1 %2470, label %2471, label %2476

2471:                                             ; preds = %2467
  %2472 = add i64 %2434, 3
  %2473 = extractelement <8 x bfloat> %2432, i64 3
  %2474 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2475 = getelementptr inbounds nuw bfloat, ptr %2474, i64 %2472
  store bfloat %2473, ptr %2475, align 2
  br label %2476

2476:                                             ; preds = %2471, %2467
  %2477 = add i64 %2427, 4
  %2478 = icmp ult i64 %2477, %26
  %2479 = and i1 %2435, %2478
  br i1 %2479, label %2480, label %2485

2480:                                             ; preds = %2476
  %2481 = add i64 %2434, 4
  %2482 = extractelement <8 x bfloat> %2432, i64 4
  %2483 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2484 = getelementptr inbounds nuw bfloat, ptr %2483, i64 %2481
  store bfloat %2482, ptr %2484, align 2
  br label %2485

2485:                                             ; preds = %2480, %2476
  %2486 = add i64 %2427, 5
  %2487 = icmp ult i64 %2486, %26
  %2488 = and i1 %2435, %2487
  br i1 %2488, label %2489, label %2494

2489:                                             ; preds = %2485
  %2490 = add i64 %2434, 5
  %2491 = extractelement <8 x bfloat> %2432, i64 5
  %2492 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2493 = getelementptr inbounds nuw bfloat, ptr %2492, i64 %2490
  store bfloat %2491, ptr %2493, align 2
  br label %2494

2494:                                             ; preds = %2489, %2485
  %2495 = add i64 %2427, 6
  %2496 = icmp ult i64 %2495, %26
  %2497 = and i1 %2435, %2496
  br i1 %2497, label %2498, label %2503

2498:                                             ; preds = %2494
  %2499 = add i64 %2434, 6
  %2500 = extractelement <8 x bfloat> %2432, i64 6
  %2501 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2502 = getelementptr inbounds nuw bfloat, ptr %2501, i64 %2499
  store bfloat %2500, ptr %2502, align 2
  br label %2503

2503:                                             ; preds = %2498, %2494
  %2504 = add i64 %2427, 7
  %2505 = icmp ult i64 %2504, %26
  %2506 = and i1 %2435, %2505
  br i1 %2506, label %2507, label %2512

2507:                                             ; preds = %2503
  %2508 = add i64 %2434, 7
  %2509 = extractelement <8 x bfloat> %2432, i64 7
  %2510 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2511 = getelementptr inbounds nuw bfloat, ptr %2510, i64 %2508
  store bfloat %2509, ptr %2511, align 2
  br label %2512

2512:                                             ; preds = %2507, %2503
  br label %2513

2513:                                             ; preds = %2439, %2512
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %2514 = mul i64 %58, 8
  %2515 = add i64 %86, %2514
  %2516 = add i64 %89, %57
  %2517 = add i64 %2515, 7
  %2518 = icmp ult i64 %2516, %26
  %2519 = icmp ult i64 %2517, %25
  %2520 = and i1 %2519, %2518
  %2521 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2522 = ptrtoint ptr %2521 to i64
  %2523 = mul i64 %2515, 4
  %2524 = add i64 %2522, %2523
  %2525 = urem i64 %2524, 16
  %2526 = icmp eq i64 %2525, 0
  %2527 = and i1 %2520, %2526
  br i1 %2527, label %2528, label %2537

2528:                                             ; preds = %2513
  %2529 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2530 = getelementptr float, ptr %2529, i64 %2515
  %2531 = load <4 x float>, ptr %2530, align 16
  %2532 = add i64 %2515, 4
  %2533 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2534 = getelementptr float, ptr %2533, i64 %2532
  %2535 = load <4 x float>, ptr %2534, align 16
  %2536 = shufflevector <4 x float> %2531, <4 x float> %2535, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2609

2537:                                             ; preds = %2513
  %2538 = mul i64 %58, 8
  %2539 = add i64 %86, %2538
  %2540 = icmp slt i64 %2539, %25
  %2541 = select i1 %2540, i64 %2539, i64 0
  %2542 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2543 = getelementptr inbounds nuw float, ptr %2542, i64 %2541
  %2544 = load float, ptr %2543, align 4
  %2545 = insertelement <8 x float> zeroinitializer, float %2544, i64 0
  %2546 = mul i64 %58, 8
  %2547 = add i64 %2546, 1
  %2548 = add i64 %86, %2547
  %2549 = icmp slt i64 %2548, %25
  %2550 = select i1 %2549, i64 %2548, i64 0
  %2551 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2552 = getelementptr inbounds nuw float, ptr %2551, i64 %2550
  %2553 = load float, ptr %2552, align 4
  %2554 = insertelement <8 x float> %2545, float %2553, i64 1
  %2555 = mul i64 %58, 8
  %2556 = add i64 %2555, 2
  %2557 = add i64 %86, %2556
  %2558 = icmp slt i64 %2557, %25
  %2559 = select i1 %2558, i64 %2557, i64 0
  %2560 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2561 = getelementptr inbounds nuw float, ptr %2560, i64 %2559
  %2562 = load float, ptr %2561, align 4
  %2563 = insertelement <8 x float> %2554, float %2562, i64 2
  %2564 = mul i64 %58, 8
  %2565 = add i64 %2564, 3
  %2566 = add i64 %86, %2565
  %2567 = icmp slt i64 %2566, %25
  %2568 = select i1 %2567, i64 %2566, i64 0
  %2569 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2570 = getelementptr inbounds nuw float, ptr %2569, i64 %2568
  %2571 = load float, ptr %2570, align 4
  %2572 = insertelement <8 x float> %2563, float %2571, i64 3
  %2573 = mul i64 %58, 8
  %2574 = add i64 %2573, 4
  %2575 = add i64 %86, %2574
  %2576 = icmp slt i64 %2575, %25
  %2577 = select i1 %2576, i64 %2575, i64 0
  %2578 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2579 = getelementptr inbounds nuw float, ptr %2578, i64 %2577
  %2580 = load float, ptr %2579, align 4
  %2581 = insertelement <8 x float> %2572, float %2580, i64 4
  %2582 = mul i64 %58, 8
  %2583 = add i64 %2582, 5
  %2584 = add i64 %86, %2583
  %2585 = icmp slt i64 %2584, %25
  %2586 = select i1 %2585, i64 %2584, i64 0
  %2587 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2588 = getelementptr inbounds nuw float, ptr %2587, i64 %2586
  %2589 = load float, ptr %2588, align 4
  %2590 = insertelement <8 x float> %2581, float %2589, i64 5
  %2591 = mul i64 %58, 8
  %2592 = add i64 %2591, 6
  %2593 = add i64 %86, %2592
  %2594 = icmp slt i64 %2593, %25
  %2595 = select i1 %2594, i64 %2593, i64 0
  %2596 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2597 = getelementptr inbounds nuw float, ptr %2596, i64 %2595
  %2598 = load float, ptr %2597, align 4
  %2599 = insertelement <8 x float> %2590, float %2598, i64 6
  %2600 = mul i64 %58, 8
  %2601 = add i64 %2600, 7
  %2602 = add i64 %86, %2601
  %2603 = icmp slt i64 %2602, %25
  %2604 = select i1 %2603, i64 %2602, i64 0
  %2605 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2606 = getelementptr inbounds nuw float, ptr %2605, i64 %2604
  %2607 = load float, ptr %2606, align 4
  %2608 = insertelement <8 x float> %2599, float %2607, i64 7
  br label %2609

2609:                                             ; preds = %2528, %2537
  %2610 = phi <8 x float> [ %2608, %2537 ], [ %2536, %2528 ]
  br label %2611

2611:                                             ; preds = %2609
  %2612 = add i64 %89, %57
  %2613 = icmp slt i64 %2612, %26
  %2614 = select i1 %2613, i64 %2612, i64 0
  %2615 = extractelement <8 x float> %2610, i64 0
  %2616 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2617 = getelementptr inbounds nuw i8, ptr %2616, i64 %2614
  %2618 = load i8, ptr %2617, align 1
  %2619 = zext i8 %2618 to i32
  %2620 = shl i32 %2619, 23
  %2621 = bitcast i32 %2620 to float
  %2622 = fmul float %2621, %2615
  %2623 = extractelement <8 x float> %164, i64 0
  %2624 = fmul float %2623, %2622
  %2625 = call float @llvm.fabs.f32(float %2622)
  %2626 = fcmp olt float %2625, +inf
  %2627 = fcmp one float %2622, 0.000000e+00
  %2628 = and i1 %2626, %2627
  %2629 = call i1 @llvm.expect.i1(i1 %2628, i1 true)
  br i1 %2629, label %2630, label %2631

2630:                                             ; preds = %2611
  br label %2643

2631:                                             ; preds = %2611
  %2632 = fpext float %2623 to double
  %2633 = fpext float %2621 to double
  %2634 = fpext float %2615 to double
  %2635 = fmul double %2632, %2633
  %2636 = fmul double %2635, %2634
  %2637 = fptrunc double %2636 to float
  %2638 = fcmp oeq float %2623, 0.000000e+00
  %2639 = call float @llvm.fabs.f32(float %2615)
  %2640 = fcmp olt float %2639, +inf
  %2641 = and i1 %2638, %2640
  %2642 = select i1 %2641, float 0.000000e+00, float %2637
  br label %2643

2643:                                             ; preds = %2630, %2631
  %2644 = phi float [ %2642, %2631 ], [ %2624, %2630 ]
  br label %2645

2645:                                             ; preds = %2643
  %2646 = add i64 %89, %57
  %2647 = icmp slt i64 %2646, %26
  %2648 = select i1 %2647, i64 %2646, i64 0
  %2649 = extractelement <8 x float> %2610, i64 1
  %2650 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2651 = getelementptr inbounds nuw i8, ptr %2650, i64 %2648
  %2652 = load i8, ptr %2651, align 1
  %2653 = zext i8 %2652 to i32
  %2654 = shl i32 %2653, 23
  %2655 = bitcast i32 %2654 to float
  %2656 = fmul float %2655, %2649
  %2657 = extractelement <8 x float> %164, i64 1
  %2658 = fmul float %2657, %2656
  %2659 = call float @llvm.fabs.f32(float %2656)
  %2660 = fcmp olt float %2659, +inf
  %2661 = fcmp one float %2656, 0.000000e+00
  %2662 = and i1 %2660, %2661
  %2663 = call i1 @llvm.expect.i1(i1 %2662, i1 true)
  br i1 %2663, label %2664, label %2665

2664:                                             ; preds = %2645
  br label %2677

2665:                                             ; preds = %2645
  %2666 = fpext float %2657 to double
  %2667 = fpext float %2655 to double
  %2668 = fpext float %2649 to double
  %2669 = fmul double %2666, %2667
  %2670 = fmul double %2669, %2668
  %2671 = fptrunc double %2670 to float
  %2672 = fcmp oeq float %2657, 0.000000e+00
  %2673 = call float @llvm.fabs.f32(float %2649)
  %2674 = fcmp olt float %2673, +inf
  %2675 = and i1 %2672, %2674
  %2676 = select i1 %2675, float 0.000000e+00, float %2671
  br label %2677

2677:                                             ; preds = %2664, %2665
  %2678 = phi float [ %2676, %2665 ], [ %2658, %2664 ]
  br label %2679

2679:                                             ; preds = %2677
  %2680 = add i64 %89, %57
  %2681 = icmp slt i64 %2680, %26
  %2682 = select i1 %2681, i64 %2680, i64 0
  %2683 = extractelement <8 x float> %2610, i64 2
  %2684 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2685 = getelementptr inbounds nuw i8, ptr %2684, i64 %2682
  %2686 = load i8, ptr %2685, align 1
  %2687 = zext i8 %2686 to i32
  %2688 = shl i32 %2687, 23
  %2689 = bitcast i32 %2688 to float
  %2690 = fmul float %2689, %2683
  %2691 = extractelement <8 x float> %164, i64 2
  %2692 = fmul float %2691, %2690
  %2693 = call float @llvm.fabs.f32(float %2690)
  %2694 = fcmp olt float %2693, +inf
  %2695 = fcmp one float %2690, 0.000000e+00
  %2696 = and i1 %2694, %2695
  %2697 = call i1 @llvm.expect.i1(i1 %2696, i1 true)
  br i1 %2697, label %2698, label %2699

2698:                                             ; preds = %2679
  br label %2711

2699:                                             ; preds = %2679
  %2700 = fpext float %2691 to double
  %2701 = fpext float %2689 to double
  %2702 = fpext float %2683 to double
  %2703 = fmul double %2700, %2701
  %2704 = fmul double %2703, %2702
  %2705 = fptrunc double %2704 to float
  %2706 = fcmp oeq float %2691, 0.000000e+00
  %2707 = call float @llvm.fabs.f32(float %2683)
  %2708 = fcmp olt float %2707, +inf
  %2709 = and i1 %2706, %2708
  %2710 = select i1 %2709, float 0.000000e+00, float %2705
  br label %2711

2711:                                             ; preds = %2698, %2699
  %2712 = phi float [ %2710, %2699 ], [ %2692, %2698 ]
  br label %2713

2713:                                             ; preds = %2711
  %2714 = add i64 %89, %57
  %2715 = icmp slt i64 %2714, %26
  %2716 = select i1 %2715, i64 %2714, i64 0
  %2717 = extractelement <8 x float> %2610, i64 3
  %2718 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2719 = getelementptr inbounds nuw i8, ptr %2718, i64 %2716
  %2720 = load i8, ptr %2719, align 1
  %2721 = zext i8 %2720 to i32
  %2722 = shl i32 %2721, 23
  %2723 = bitcast i32 %2722 to float
  %2724 = fmul float %2723, %2717
  %2725 = extractelement <8 x float> %164, i64 3
  %2726 = fmul float %2725, %2724
  %2727 = call float @llvm.fabs.f32(float %2724)
  %2728 = fcmp olt float %2727, +inf
  %2729 = fcmp one float %2724, 0.000000e+00
  %2730 = and i1 %2728, %2729
  %2731 = call i1 @llvm.expect.i1(i1 %2730, i1 true)
  br i1 %2731, label %2732, label %2733

2732:                                             ; preds = %2713
  br label %2745

2733:                                             ; preds = %2713
  %2734 = fpext float %2725 to double
  %2735 = fpext float %2723 to double
  %2736 = fpext float %2717 to double
  %2737 = fmul double %2734, %2735
  %2738 = fmul double %2737, %2736
  %2739 = fptrunc double %2738 to float
  %2740 = fcmp oeq float %2725, 0.000000e+00
  %2741 = call float @llvm.fabs.f32(float %2717)
  %2742 = fcmp olt float %2741, +inf
  %2743 = and i1 %2740, %2742
  %2744 = select i1 %2743, float 0.000000e+00, float %2739
  br label %2745

2745:                                             ; preds = %2732, %2733
  %2746 = phi float [ %2744, %2733 ], [ %2726, %2732 ]
  br label %2747

2747:                                             ; preds = %2745
  %2748 = add i64 %89, %57
  %2749 = icmp slt i64 %2748, %26
  %2750 = select i1 %2749, i64 %2748, i64 0
  %2751 = extractelement <8 x float> %2610, i64 4
  %2752 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2753 = getelementptr inbounds nuw i8, ptr %2752, i64 %2750
  %2754 = load i8, ptr %2753, align 1
  %2755 = zext i8 %2754 to i32
  %2756 = shl i32 %2755, 23
  %2757 = bitcast i32 %2756 to float
  %2758 = fmul float %2757, %2751
  %2759 = extractelement <8 x float> %164, i64 4
  %2760 = fmul float %2759, %2758
  %2761 = call float @llvm.fabs.f32(float %2758)
  %2762 = fcmp olt float %2761, +inf
  %2763 = fcmp one float %2758, 0.000000e+00
  %2764 = and i1 %2762, %2763
  %2765 = call i1 @llvm.expect.i1(i1 %2764, i1 true)
  br i1 %2765, label %2766, label %2767

2766:                                             ; preds = %2747
  br label %2779

2767:                                             ; preds = %2747
  %2768 = fpext float %2759 to double
  %2769 = fpext float %2757 to double
  %2770 = fpext float %2751 to double
  %2771 = fmul double %2768, %2769
  %2772 = fmul double %2771, %2770
  %2773 = fptrunc double %2772 to float
  %2774 = fcmp oeq float %2759, 0.000000e+00
  %2775 = call float @llvm.fabs.f32(float %2751)
  %2776 = fcmp olt float %2775, +inf
  %2777 = and i1 %2774, %2776
  %2778 = select i1 %2777, float 0.000000e+00, float %2773
  br label %2779

2779:                                             ; preds = %2766, %2767
  %2780 = phi float [ %2778, %2767 ], [ %2760, %2766 ]
  br label %2781

2781:                                             ; preds = %2779
  %2782 = add i64 %89, %57
  %2783 = icmp slt i64 %2782, %26
  %2784 = select i1 %2783, i64 %2782, i64 0
  %2785 = extractelement <8 x float> %2610, i64 5
  %2786 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2787 = getelementptr inbounds nuw i8, ptr %2786, i64 %2784
  %2788 = load i8, ptr %2787, align 1
  %2789 = zext i8 %2788 to i32
  %2790 = shl i32 %2789, 23
  %2791 = bitcast i32 %2790 to float
  %2792 = fmul float %2791, %2785
  %2793 = extractelement <8 x float> %164, i64 5
  %2794 = fmul float %2793, %2792
  %2795 = call float @llvm.fabs.f32(float %2792)
  %2796 = fcmp olt float %2795, +inf
  %2797 = fcmp one float %2792, 0.000000e+00
  %2798 = and i1 %2796, %2797
  %2799 = call i1 @llvm.expect.i1(i1 %2798, i1 true)
  br i1 %2799, label %2800, label %2801

2800:                                             ; preds = %2781
  br label %2813

2801:                                             ; preds = %2781
  %2802 = fpext float %2793 to double
  %2803 = fpext float %2791 to double
  %2804 = fpext float %2785 to double
  %2805 = fmul double %2802, %2803
  %2806 = fmul double %2805, %2804
  %2807 = fptrunc double %2806 to float
  %2808 = fcmp oeq float %2793, 0.000000e+00
  %2809 = call float @llvm.fabs.f32(float %2785)
  %2810 = fcmp olt float %2809, +inf
  %2811 = and i1 %2808, %2810
  %2812 = select i1 %2811, float 0.000000e+00, float %2807
  br label %2813

2813:                                             ; preds = %2800, %2801
  %2814 = phi float [ %2812, %2801 ], [ %2794, %2800 ]
  br label %2815

2815:                                             ; preds = %2813
  %2816 = add i64 %89, %57
  %2817 = icmp slt i64 %2816, %26
  %2818 = select i1 %2817, i64 %2816, i64 0
  %2819 = extractelement <8 x float> %2610, i64 6
  %2820 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2821 = getelementptr inbounds nuw i8, ptr %2820, i64 %2818
  %2822 = load i8, ptr %2821, align 1
  %2823 = zext i8 %2822 to i32
  %2824 = shl i32 %2823, 23
  %2825 = bitcast i32 %2824 to float
  %2826 = fmul float %2825, %2819
  %2827 = extractelement <8 x float> %164, i64 6
  %2828 = fmul float %2827, %2826
  %2829 = call float @llvm.fabs.f32(float %2826)
  %2830 = fcmp olt float %2829, +inf
  %2831 = fcmp one float %2826, 0.000000e+00
  %2832 = and i1 %2830, %2831
  %2833 = call i1 @llvm.expect.i1(i1 %2832, i1 true)
  br i1 %2833, label %2834, label %2835

2834:                                             ; preds = %2815
  br label %2847

2835:                                             ; preds = %2815
  %2836 = fpext float %2827 to double
  %2837 = fpext float %2825 to double
  %2838 = fpext float %2819 to double
  %2839 = fmul double %2836, %2837
  %2840 = fmul double %2839, %2838
  %2841 = fptrunc double %2840 to float
  %2842 = fcmp oeq float %2827, 0.000000e+00
  %2843 = call float @llvm.fabs.f32(float %2819)
  %2844 = fcmp olt float %2843, +inf
  %2845 = and i1 %2842, %2844
  %2846 = select i1 %2845, float 0.000000e+00, float %2841
  br label %2847

2847:                                             ; preds = %2834, %2835
  %2848 = phi float [ %2846, %2835 ], [ %2828, %2834 ]
  br label %2849

2849:                                             ; preds = %2847
  %2850 = add i64 %89, %57
  %2851 = icmp slt i64 %2850, %26
  %2852 = select i1 %2851, i64 %2850, i64 0
  %2853 = extractelement <8 x float> %2610, i64 7
  %2854 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2855 = getelementptr inbounds nuw i8, ptr %2854, i64 %2852
  %2856 = load i8, ptr %2855, align 1
  %2857 = zext i8 %2856 to i32
  %2858 = shl i32 %2857, 23
  %2859 = bitcast i32 %2858 to float
  %2860 = fmul float %2859, %2853
  %2861 = extractelement <8 x float> %164, i64 7
  %2862 = fmul float %2861, %2860
  %2863 = call float @llvm.fabs.f32(float %2860)
  %2864 = fcmp olt float %2863, +inf
  %2865 = fcmp one float %2860, 0.000000e+00
  %2866 = and i1 %2864, %2865
  %2867 = call i1 @llvm.expect.i1(i1 %2866, i1 true)
  br i1 %2867, label %2868, label %2869

2868:                                             ; preds = %2849
  br label %2881

2869:                                             ; preds = %2849
  %2870 = fpext float %2861 to double
  %2871 = fpext float %2859 to double
  %2872 = fpext float %2853 to double
  %2873 = fmul double %2870, %2871
  %2874 = fmul double %2873, %2872
  %2875 = fptrunc double %2874 to float
  %2876 = fcmp oeq float %2861, 0.000000e+00
  %2877 = call float @llvm.fabs.f32(float %2853)
  %2878 = fcmp olt float %2877, +inf
  %2879 = and i1 %2876, %2878
  %2880 = select i1 %2879, float 0.000000e+00, float %2875
  br label %2881

2881:                                             ; preds = %2868, %2869
  %2882 = phi float [ %2880, %2869 ], [ %2862, %2868 ]
  br label %2883

2883:                                             ; preds = %2881
  %2884 = mul i64 %59, 16
  %2885 = mul i64 %58, 8
  %2886 = add i64 %2884, %2885
  %2887 = mul i64 %2886, 40
  %2888 = add i64 %2887, %57
  %2889 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2888
  store float %2644, ptr addrspace(3) %2889, align 4
  %2890 = mul i64 %58, 8
  %2891 = add i64 %2890, 1
  %2892 = add i64 %2884, %2891
  %2893 = mul i64 %2892, 40
  %2894 = add i64 %2893, %57
  %2895 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2894
  store float %2678, ptr addrspace(3) %2895, align 4
  %2896 = mul i64 %58, 8
  %2897 = add i64 %2896, 2
  %2898 = add i64 %2884, %2897
  %2899 = mul i64 %2898, 40
  %2900 = add i64 %2899, %57
  %2901 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2900
  store float %2712, ptr addrspace(3) %2901, align 4
  %2902 = mul i64 %58, 8
  %2903 = add i64 %2902, 3
  %2904 = add i64 %2884, %2903
  %2905 = mul i64 %2904, 40
  %2906 = add i64 %2905, %57
  %2907 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2906
  store float %2746, ptr addrspace(3) %2907, align 4
  %2908 = mul i64 %58, 8
  %2909 = add i64 %2908, 4
  %2910 = add i64 %2884, %2909
  %2911 = mul i64 %2910, 40
  %2912 = add i64 %2911, %57
  %2913 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2912
  store float %2780, ptr addrspace(3) %2913, align 4
  %2914 = mul i64 %58, 8
  %2915 = add i64 %2914, 5
  %2916 = add i64 %2884, %2915
  %2917 = mul i64 %2916, 40
  %2918 = add i64 %2917, %57
  %2919 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2918
  store float %2814, ptr addrspace(3) %2919, align 4
  %2920 = mul i64 %58, 8
  %2921 = add i64 %2920, 6
  %2922 = add i64 %2884, %2921
  %2923 = mul i64 %2922, 40
  %2924 = add i64 %2923, %57
  %2925 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2924
  store float %2848, ptr addrspace(3) %2925, align 4
  %2926 = mul i64 %58, 8
  %2927 = add i64 %2926, 7
  %2928 = add i64 %2884, %2927
  %2929 = mul i64 %2928, 40
  %2930 = add i64 %2929, %57
  %2931 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2930
  store float %2882, ptr addrspace(3) %2931, align 4
  %2932 = mul i64 %58, 8
  %2933 = add i64 %86, %2932
  %2934 = add i64 %91, %57
  %2935 = add i64 %2933, 7
  %2936 = icmp ult i64 %2934, %26
  %2937 = icmp ult i64 %2935, %25
  %2938 = and i1 %2937, %2936
  %2939 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2940 = ptrtoint ptr %2939 to i64
  %2941 = mul i64 %2933, 4
  %2942 = add i64 %2940, %2941
  %2943 = urem i64 %2942, 16
  %2944 = icmp eq i64 %2943, 0
  %2945 = and i1 %2938, %2944
  br i1 %2945, label %2946, label %2955

2946:                                             ; preds = %2883
  %2947 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2948 = getelementptr float, ptr %2947, i64 %2933
  %2949 = load <4 x float>, ptr %2948, align 16
  %2950 = add i64 %2933, 4
  %2951 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2952 = getelementptr float, ptr %2951, i64 %2950
  %2953 = load <4 x float>, ptr %2952, align 16
  %2954 = shufflevector <4 x float> %2949, <4 x float> %2953, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3027

2955:                                             ; preds = %2883
  %2956 = mul i64 %58, 8
  %2957 = add i64 %86, %2956
  %2958 = icmp slt i64 %2957, %25
  %2959 = select i1 %2958, i64 %2957, i64 0
  %2960 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2961 = getelementptr inbounds nuw float, ptr %2960, i64 %2959
  %2962 = load float, ptr %2961, align 4
  %2963 = insertelement <8 x float> zeroinitializer, float %2962, i64 0
  %2964 = mul i64 %58, 8
  %2965 = add i64 %2964, 1
  %2966 = add i64 %86, %2965
  %2967 = icmp slt i64 %2966, %25
  %2968 = select i1 %2967, i64 %2966, i64 0
  %2969 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2970 = getelementptr inbounds nuw float, ptr %2969, i64 %2968
  %2971 = load float, ptr %2970, align 4
  %2972 = insertelement <8 x float> %2963, float %2971, i64 1
  %2973 = mul i64 %58, 8
  %2974 = add i64 %2973, 2
  %2975 = add i64 %86, %2974
  %2976 = icmp slt i64 %2975, %25
  %2977 = select i1 %2976, i64 %2975, i64 0
  %2978 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2979 = getelementptr inbounds nuw float, ptr %2978, i64 %2977
  %2980 = load float, ptr %2979, align 4
  %2981 = insertelement <8 x float> %2972, float %2980, i64 2
  %2982 = mul i64 %58, 8
  %2983 = add i64 %2982, 3
  %2984 = add i64 %86, %2983
  %2985 = icmp slt i64 %2984, %25
  %2986 = select i1 %2985, i64 %2984, i64 0
  %2987 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2988 = getelementptr inbounds nuw float, ptr %2987, i64 %2986
  %2989 = load float, ptr %2988, align 4
  %2990 = insertelement <8 x float> %2981, float %2989, i64 3
  %2991 = mul i64 %58, 8
  %2992 = add i64 %2991, 4
  %2993 = add i64 %86, %2992
  %2994 = icmp slt i64 %2993, %25
  %2995 = select i1 %2994, i64 %2993, i64 0
  %2996 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2997 = getelementptr inbounds nuw float, ptr %2996, i64 %2995
  %2998 = load float, ptr %2997, align 4
  %2999 = insertelement <8 x float> %2990, float %2998, i64 4
  %3000 = mul i64 %58, 8
  %3001 = add i64 %3000, 5
  %3002 = add i64 %86, %3001
  %3003 = icmp slt i64 %3002, %25
  %3004 = select i1 %3003, i64 %3002, i64 0
  %3005 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3006 = getelementptr inbounds nuw float, ptr %3005, i64 %3004
  %3007 = load float, ptr %3006, align 4
  %3008 = insertelement <8 x float> %2999, float %3007, i64 5
  %3009 = mul i64 %58, 8
  %3010 = add i64 %3009, 6
  %3011 = add i64 %86, %3010
  %3012 = icmp slt i64 %3011, %25
  %3013 = select i1 %3012, i64 %3011, i64 0
  %3014 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3015 = getelementptr inbounds nuw float, ptr %3014, i64 %3013
  %3016 = load float, ptr %3015, align 4
  %3017 = insertelement <8 x float> %3008, float %3016, i64 6
  %3018 = mul i64 %58, 8
  %3019 = add i64 %3018, 7
  %3020 = add i64 %86, %3019
  %3021 = icmp slt i64 %3020, %25
  %3022 = select i1 %3021, i64 %3020, i64 0
  %3023 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3024 = getelementptr inbounds nuw float, ptr %3023, i64 %3022
  %3025 = load float, ptr %3024, align 4
  %3026 = insertelement <8 x float> %3017, float %3025, i64 7
  br label %3027

3027:                                             ; preds = %2946, %2955
  %3028 = phi <8 x float> [ %3026, %2955 ], [ %2954, %2946 ]
  br label %3029

3029:                                             ; preds = %3027
  %3030 = add i64 %91, %57
  %3031 = icmp slt i64 %3030, %26
  %3032 = select i1 %3031, i64 %3030, i64 0
  %3033 = extractelement <8 x float> %3028, i64 0
  %3034 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3035 = getelementptr inbounds nuw i8, ptr %3034, i64 %3032
  %3036 = load i8, ptr %3035, align 1
  %3037 = zext i8 %3036 to i32
  %3038 = shl i32 %3037, 23
  %3039 = bitcast i32 %3038 to float
  %3040 = fmul float %3039, %3033
  %3041 = extractelement <8 x float> %165, i64 0
  %3042 = fmul float %3041, %3040
  %3043 = call float @llvm.fabs.f32(float %3040)
  %3044 = fcmp olt float %3043, +inf
  %3045 = fcmp one float %3040, 0.000000e+00
  %3046 = and i1 %3044, %3045
  %3047 = call i1 @llvm.expect.i1(i1 %3046, i1 true)
  br i1 %3047, label %3048, label %3049

3048:                                             ; preds = %3029
  br label %3061

3049:                                             ; preds = %3029
  %3050 = fpext float %3041 to double
  %3051 = fpext float %3039 to double
  %3052 = fpext float %3033 to double
  %3053 = fmul double %3050, %3051
  %3054 = fmul double %3053, %3052
  %3055 = fptrunc double %3054 to float
  %3056 = fcmp oeq float %3041, 0.000000e+00
  %3057 = call float @llvm.fabs.f32(float %3033)
  %3058 = fcmp olt float %3057, +inf
  %3059 = and i1 %3056, %3058
  %3060 = select i1 %3059, float 0.000000e+00, float %3055
  br label %3061

3061:                                             ; preds = %3048, %3049
  %3062 = phi float [ %3060, %3049 ], [ %3042, %3048 ]
  br label %3063

3063:                                             ; preds = %3061
  %3064 = add i64 %91, %57
  %3065 = icmp slt i64 %3064, %26
  %3066 = select i1 %3065, i64 %3064, i64 0
  %3067 = extractelement <8 x float> %3028, i64 1
  %3068 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3069 = getelementptr inbounds nuw i8, ptr %3068, i64 %3066
  %3070 = load i8, ptr %3069, align 1
  %3071 = zext i8 %3070 to i32
  %3072 = shl i32 %3071, 23
  %3073 = bitcast i32 %3072 to float
  %3074 = fmul float %3073, %3067
  %3075 = extractelement <8 x float> %165, i64 1
  %3076 = fmul float %3075, %3074
  %3077 = call float @llvm.fabs.f32(float %3074)
  %3078 = fcmp olt float %3077, +inf
  %3079 = fcmp one float %3074, 0.000000e+00
  %3080 = and i1 %3078, %3079
  %3081 = call i1 @llvm.expect.i1(i1 %3080, i1 true)
  br i1 %3081, label %3082, label %3083

3082:                                             ; preds = %3063
  br label %3095

3083:                                             ; preds = %3063
  %3084 = fpext float %3075 to double
  %3085 = fpext float %3073 to double
  %3086 = fpext float %3067 to double
  %3087 = fmul double %3084, %3085
  %3088 = fmul double %3087, %3086
  %3089 = fptrunc double %3088 to float
  %3090 = fcmp oeq float %3075, 0.000000e+00
  %3091 = call float @llvm.fabs.f32(float %3067)
  %3092 = fcmp olt float %3091, +inf
  %3093 = and i1 %3090, %3092
  %3094 = select i1 %3093, float 0.000000e+00, float %3089
  br label %3095

3095:                                             ; preds = %3082, %3083
  %3096 = phi float [ %3094, %3083 ], [ %3076, %3082 ]
  br label %3097

3097:                                             ; preds = %3095
  %3098 = add i64 %91, %57
  %3099 = icmp slt i64 %3098, %26
  %3100 = select i1 %3099, i64 %3098, i64 0
  %3101 = extractelement <8 x float> %3028, i64 2
  %3102 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3103 = getelementptr inbounds nuw i8, ptr %3102, i64 %3100
  %3104 = load i8, ptr %3103, align 1
  %3105 = zext i8 %3104 to i32
  %3106 = shl i32 %3105, 23
  %3107 = bitcast i32 %3106 to float
  %3108 = fmul float %3107, %3101
  %3109 = extractelement <8 x float> %165, i64 2
  %3110 = fmul float %3109, %3108
  %3111 = call float @llvm.fabs.f32(float %3108)
  %3112 = fcmp olt float %3111, +inf
  %3113 = fcmp one float %3108, 0.000000e+00
  %3114 = and i1 %3112, %3113
  %3115 = call i1 @llvm.expect.i1(i1 %3114, i1 true)
  br i1 %3115, label %3116, label %3117

3116:                                             ; preds = %3097
  br label %3129

3117:                                             ; preds = %3097
  %3118 = fpext float %3109 to double
  %3119 = fpext float %3107 to double
  %3120 = fpext float %3101 to double
  %3121 = fmul double %3118, %3119
  %3122 = fmul double %3121, %3120
  %3123 = fptrunc double %3122 to float
  %3124 = fcmp oeq float %3109, 0.000000e+00
  %3125 = call float @llvm.fabs.f32(float %3101)
  %3126 = fcmp olt float %3125, +inf
  %3127 = and i1 %3124, %3126
  %3128 = select i1 %3127, float 0.000000e+00, float %3123
  br label %3129

3129:                                             ; preds = %3116, %3117
  %3130 = phi float [ %3128, %3117 ], [ %3110, %3116 ]
  br label %3131

3131:                                             ; preds = %3129
  %3132 = add i64 %91, %57
  %3133 = icmp slt i64 %3132, %26
  %3134 = select i1 %3133, i64 %3132, i64 0
  %3135 = extractelement <8 x float> %3028, i64 3
  %3136 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3137 = getelementptr inbounds nuw i8, ptr %3136, i64 %3134
  %3138 = load i8, ptr %3137, align 1
  %3139 = zext i8 %3138 to i32
  %3140 = shl i32 %3139, 23
  %3141 = bitcast i32 %3140 to float
  %3142 = fmul float %3141, %3135
  %3143 = extractelement <8 x float> %165, i64 3
  %3144 = fmul float %3143, %3142
  %3145 = call float @llvm.fabs.f32(float %3142)
  %3146 = fcmp olt float %3145, +inf
  %3147 = fcmp one float %3142, 0.000000e+00
  %3148 = and i1 %3146, %3147
  %3149 = call i1 @llvm.expect.i1(i1 %3148, i1 true)
  br i1 %3149, label %3150, label %3151

3150:                                             ; preds = %3131
  br label %3163

3151:                                             ; preds = %3131
  %3152 = fpext float %3143 to double
  %3153 = fpext float %3141 to double
  %3154 = fpext float %3135 to double
  %3155 = fmul double %3152, %3153
  %3156 = fmul double %3155, %3154
  %3157 = fptrunc double %3156 to float
  %3158 = fcmp oeq float %3143, 0.000000e+00
  %3159 = call float @llvm.fabs.f32(float %3135)
  %3160 = fcmp olt float %3159, +inf
  %3161 = and i1 %3158, %3160
  %3162 = select i1 %3161, float 0.000000e+00, float %3157
  br label %3163

3163:                                             ; preds = %3150, %3151
  %3164 = phi float [ %3162, %3151 ], [ %3144, %3150 ]
  br label %3165

3165:                                             ; preds = %3163
  %3166 = add i64 %91, %57
  %3167 = icmp slt i64 %3166, %26
  %3168 = select i1 %3167, i64 %3166, i64 0
  %3169 = extractelement <8 x float> %3028, i64 4
  %3170 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3171 = getelementptr inbounds nuw i8, ptr %3170, i64 %3168
  %3172 = load i8, ptr %3171, align 1
  %3173 = zext i8 %3172 to i32
  %3174 = shl i32 %3173, 23
  %3175 = bitcast i32 %3174 to float
  %3176 = fmul float %3175, %3169
  %3177 = extractelement <8 x float> %165, i64 4
  %3178 = fmul float %3177, %3176
  %3179 = call float @llvm.fabs.f32(float %3176)
  %3180 = fcmp olt float %3179, +inf
  %3181 = fcmp one float %3176, 0.000000e+00
  %3182 = and i1 %3180, %3181
  %3183 = call i1 @llvm.expect.i1(i1 %3182, i1 true)
  br i1 %3183, label %3184, label %3185

3184:                                             ; preds = %3165
  br label %3197

3185:                                             ; preds = %3165
  %3186 = fpext float %3177 to double
  %3187 = fpext float %3175 to double
  %3188 = fpext float %3169 to double
  %3189 = fmul double %3186, %3187
  %3190 = fmul double %3189, %3188
  %3191 = fptrunc double %3190 to float
  %3192 = fcmp oeq float %3177, 0.000000e+00
  %3193 = call float @llvm.fabs.f32(float %3169)
  %3194 = fcmp olt float %3193, +inf
  %3195 = and i1 %3192, %3194
  %3196 = select i1 %3195, float 0.000000e+00, float %3191
  br label %3197

3197:                                             ; preds = %3184, %3185
  %3198 = phi float [ %3196, %3185 ], [ %3178, %3184 ]
  br label %3199

3199:                                             ; preds = %3197
  %3200 = add i64 %91, %57
  %3201 = icmp slt i64 %3200, %26
  %3202 = select i1 %3201, i64 %3200, i64 0
  %3203 = extractelement <8 x float> %3028, i64 5
  %3204 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3205 = getelementptr inbounds nuw i8, ptr %3204, i64 %3202
  %3206 = load i8, ptr %3205, align 1
  %3207 = zext i8 %3206 to i32
  %3208 = shl i32 %3207, 23
  %3209 = bitcast i32 %3208 to float
  %3210 = fmul float %3209, %3203
  %3211 = extractelement <8 x float> %165, i64 5
  %3212 = fmul float %3211, %3210
  %3213 = call float @llvm.fabs.f32(float %3210)
  %3214 = fcmp olt float %3213, +inf
  %3215 = fcmp one float %3210, 0.000000e+00
  %3216 = and i1 %3214, %3215
  %3217 = call i1 @llvm.expect.i1(i1 %3216, i1 true)
  br i1 %3217, label %3218, label %3219

3218:                                             ; preds = %3199
  br label %3231

3219:                                             ; preds = %3199
  %3220 = fpext float %3211 to double
  %3221 = fpext float %3209 to double
  %3222 = fpext float %3203 to double
  %3223 = fmul double %3220, %3221
  %3224 = fmul double %3223, %3222
  %3225 = fptrunc double %3224 to float
  %3226 = fcmp oeq float %3211, 0.000000e+00
  %3227 = call float @llvm.fabs.f32(float %3203)
  %3228 = fcmp olt float %3227, +inf
  %3229 = and i1 %3226, %3228
  %3230 = select i1 %3229, float 0.000000e+00, float %3225
  br label %3231

3231:                                             ; preds = %3218, %3219
  %3232 = phi float [ %3230, %3219 ], [ %3212, %3218 ]
  br label %3233

3233:                                             ; preds = %3231
  %3234 = add i64 %91, %57
  %3235 = icmp slt i64 %3234, %26
  %3236 = select i1 %3235, i64 %3234, i64 0
  %3237 = extractelement <8 x float> %3028, i64 6
  %3238 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3239 = getelementptr inbounds nuw i8, ptr %3238, i64 %3236
  %3240 = load i8, ptr %3239, align 1
  %3241 = zext i8 %3240 to i32
  %3242 = shl i32 %3241, 23
  %3243 = bitcast i32 %3242 to float
  %3244 = fmul float %3243, %3237
  %3245 = extractelement <8 x float> %165, i64 6
  %3246 = fmul float %3245, %3244
  %3247 = call float @llvm.fabs.f32(float %3244)
  %3248 = fcmp olt float %3247, +inf
  %3249 = fcmp one float %3244, 0.000000e+00
  %3250 = and i1 %3248, %3249
  %3251 = call i1 @llvm.expect.i1(i1 %3250, i1 true)
  br i1 %3251, label %3252, label %3253

3252:                                             ; preds = %3233
  br label %3265

3253:                                             ; preds = %3233
  %3254 = fpext float %3245 to double
  %3255 = fpext float %3243 to double
  %3256 = fpext float %3237 to double
  %3257 = fmul double %3254, %3255
  %3258 = fmul double %3257, %3256
  %3259 = fptrunc double %3258 to float
  %3260 = fcmp oeq float %3245, 0.000000e+00
  %3261 = call float @llvm.fabs.f32(float %3237)
  %3262 = fcmp olt float %3261, +inf
  %3263 = and i1 %3260, %3262
  %3264 = select i1 %3263, float 0.000000e+00, float %3259
  br label %3265

3265:                                             ; preds = %3252, %3253
  %3266 = phi float [ %3264, %3253 ], [ %3246, %3252 ]
  br label %3267

3267:                                             ; preds = %3265
  %3268 = add i64 %91, %57
  %3269 = icmp slt i64 %3268, %26
  %3270 = select i1 %3269, i64 %3268, i64 0
  %3271 = extractelement <8 x float> %3028, i64 7
  %3272 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3273 = getelementptr inbounds nuw i8, ptr %3272, i64 %3270
  %3274 = load i8, ptr %3273, align 1
  %3275 = zext i8 %3274 to i32
  %3276 = shl i32 %3275, 23
  %3277 = bitcast i32 %3276 to float
  %3278 = fmul float %3277, %3271
  %3279 = extractelement <8 x float> %165, i64 7
  %3280 = fmul float %3279, %3278
  %3281 = call float @llvm.fabs.f32(float %3278)
  %3282 = fcmp olt float %3281, +inf
  %3283 = fcmp one float %3278, 0.000000e+00
  %3284 = and i1 %3282, %3283
  %3285 = call i1 @llvm.expect.i1(i1 %3284, i1 true)
  br i1 %3285, label %3286, label %3287

3286:                                             ; preds = %3267
  br label %3299

3287:                                             ; preds = %3267
  %3288 = fpext float %3279 to double
  %3289 = fpext float %3277 to double
  %3290 = fpext float %3271 to double
  %3291 = fmul double %3288, %3289
  %3292 = fmul double %3291, %3290
  %3293 = fptrunc double %3292 to float
  %3294 = fcmp oeq float %3279, 0.000000e+00
  %3295 = call float @llvm.fabs.f32(float %3271)
  %3296 = fcmp olt float %3295, +inf
  %3297 = and i1 %3294, %3296
  %3298 = select i1 %3297, float 0.000000e+00, float %3293
  br label %3299

3299:                                             ; preds = %3286, %3287
  %3300 = phi float [ %3298, %3287 ], [ %3280, %3286 ]
  br label %3301

3301:                                             ; preds = %3299
  %3302 = mul i64 %59, 16
  %3303 = mul i64 %58, 8
  %3304 = add i64 %3302, %3303
  %3305 = add i64 %57, 16
  %3306 = mul i64 %3304, 40
  %3307 = add i64 %3306, %3305
  %3308 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3307
  store float %3062, ptr addrspace(3) %3308, align 4
  %3309 = mul i64 %58, 8
  %3310 = add i64 %3309, 1
  %3311 = add i64 %3302, %3310
  %3312 = add i64 %57, 16
  %3313 = mul i64 %3311, 40
  %3314 = add i64 %3313, %3312
  %3315 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3314
  store float %3096, ptr addrspace(3) %3315, align 4
  %3316 = mul i64 %58, 8
  %3317 = add i64 %3316, 2
  %3318 = add i64 %3302, %3317
  %3319 = add i64 %57, 16
  %3320 = mul i64 %3318, 40
  %3321 = add i64 %3320, %3319
  %3322 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3321
  store float %3130, ptr addrspace(3) %3322, align 4
  %3323 = mul i64 %58, 8
  %3324 = add i64 %3323, 3
  %3325 = add i64 %3302, %3324
  %3326 = add i64 %57, 16
  %3327 = mul i64 %3325, 40
  %3328 = add i64 %3327, %3326
  %3329 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3328
  store float %3164, ptr addrspace(3) %3329, align 4
  %3330 = mul i64 %58, 8
  %3331 = add i64 %3330, 4
  %3332 = add i64 %3302, %3331
  %3333 = add i64 %57, 16
  %3334 = mul i64 %3332, 40
  %3335 = add i64 %3334, %3333
  %3336 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3335
  store float %3198, ptr addrspace(3) %3336, align 4
  %3337 = mul i64 %58, 8
  %3338 = add i64 %3337, 5
  %3339 = add i64 %3302, %3338
  %3340 = add i64 %57, 16
  %3341 = mul i64 %3339, 40
  %3342 = add i64 %3341, %3340
  %3343 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3342
  store float %3232, ptr addrspace(3) %3343, align 4
  %3344 = mul i64 %58, 8
  %3345 = add i64 %3344, 6
  %3346 = add i64 %3302, %3345
  %3347 = add i64 %57, 16
  %3348 = mul i64 %3346, 40
  %3349 = add i64 %3348, %3347
  %3350 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3349
  store float %3266, ptr addrspace(3) %3350, align 4
  %3351 = mul i64 %58, 8
  %3352 = add i64 %3351, 7
  %3353 = add i64 %3302, %3352
  %3354 = add i64 %57, 16
  %3355 = mul i64 %3353, 40
  %3356 = add i64 %3355, %3354
  %3357 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3356
  store float %3300, ptr addrspace(3) %3357, align 4
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %3358 = urem i64 %55, 32
  %3359 = mul i64 %3358, 8
  %3360 = udiv i64 %3359, 32
  %3361 = urem i64 %3359, 32
  %3362 = mul i64 %59, 16
  %3363 = add i64 %3362, %3360
  %3364 = udiv i64 %59, 2
  %3365 = mul i64 %3364, 4
  %3366 = add i64 %3365, 2
  %3367 = mul i64 %3366, 16
  %3368 = add i64 %3360, %3367
  %3369 = add i64 %78, %3368
  %3370 = urem i64 %59, 2
  %3371 = mul i64 %3370, 32
  %3372 = add i64 %3361, %3371
  %3373 = add i64 %79, %3372
  %3374 = mul i64 %3363, 40
  %3375 = add i64 %3374, %3361
  %3376 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3375
  %3377 = load <8 x float>, ptr addrspace(3) %3376, align 16
  %3378 = fptrunc <8 x float> %3377 to <8 x bfloat>
  %3379 = mul i64 %3369, %26
  %3380 = add i64 %3379, %3373
  %3381 = icmp ult i64 %3369, %25
  %3382 = add i64 %3373, 7
  %3383 = icmp ult i64 %3382, %26
  %3384 = and i1 %3381, %3383
  br i1 %3384, label %3385, label %3388

3385:                                             ; preds = %3301
  %3386 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3387 = getelementptr bfloat, ptr %3386, i64 %3380
  store <8 x bfloat> %3378, ptr %3387, align 2
  br label %3459

3388:                                             ; preds = %3301
  %3389 = icmp ult i64 %3373, %26
  %3390 = and i1 %3381, %3389
  br i1 %3390, label %3391, label %3395

3391:                                             ; preds = %3388
  %3392 = extractelement <8 x bfloat> %3378, i64 0
  %3393 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3394 = getelementptr inbounds nuw bfloat, ptr %3393, i64 %3380
  store bfloat %3392, ptr %3394, align 2
  br label %3395

3395:                                             ; preds = %3391, %3388
  %3396 = add i64 %3373, 1
  %3397 = icmp ult i64 %3396, %26
  %3398 = and i1 %3381, %3397
  br i1 %3398, label %3399, label %3404

3399:                                             ; preds = %3395
  %3400 = add i64 %3380, 1
  %3401 = extractelement <8 x bfloat> %3378, i64 1
  %3402 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3403 = getelementptr inbounds nuw bfloat, ptr %3402, i64 %3400
  store bfloat %3401, ptr %3403, align 2
  br label %3404

3404:                                             ; preds = %3399, %3395
  %3405 = add i64 %3373, 2
  %3406 = icmp ult i64 %3405, %26
  %3407 = and i1 %3381, %3406
  br i1 %3407, label %3408, label %3413

3408:                                             ; preds = %3404
  %3409 = add i64 %3380, 2
  %3410 = extractelement <8 x bfloat> %3378, i64 2
  %3411 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3412 = getelementptr inbounds nuw bfloat, ptr %3411, i64 %3409
  store bfloat %3410, ptr %3412, align 2
  br label %3413

3413:                                             ; preds = %3408, %3404
  %3414 = add i64 %3373, 3
  %3415 = icmp ult i64 %3414, %26
  %3416 = and i1 %3381, %3415
  br i1 %3416, label %3417, label %3422

3417:                                             ; preds = %3413
  %3418 = add i64 %3380, 3
  %3419 = extractelement <8 x bfloat> %3378, i64 3
  %3420 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3421 = getelementptr inbounds nuw bfloat, ptr %3420, i64 %3418
  store bfloat %3419, ptr %3421, align 2
  br label %3422

3422:                                             ; preds = %3417, %3413
  %3423 = add i64 %3373, 4
  %3424 = icmp ult i64 %3423, %26
  %3425 = and i1 %3381, %3424
  br i1 %3425, label %3426, label %3431

3426:                                             ; preds = %3422
  %3427 = add i64 %3380, 4
  %3428 = extractelement <8 x bfloat> %3378, i64 4
  %3429 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3430 = getelementptr inbounds nuw bfloat, ptr %3429, i64 %3427
  store bfloat %3428, ptr %3430, align 2
  br label %3431

3431:                                             ; preds = %3426, %3422
  %3432 = add i64 %3373, 5
  %3433 = icmp ult i64 %3432, %26
  %3434 = and i1 %3381, %3433
  br i1 %3434, label %3435, label %3440

3435:                                             ; preds = %3431
  %3436 = add i64 %3380, 5
  %3437 = extractelement <8 x bfloat> %3378, i64 5
  %3438 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3439 = getelementptr inbounds nuw bfloat, ptr %3438, i64 %3436
  store bfloat %3437, ptr %3439, align 2
  br label %3440

3440:                                             ; preds = %3435, %3431
  %3441 = add i64 %3373, 6
  %3442 = icmp ult i64 %3441, %26
  %3443 = and i1 %3381, %3442
  br i1 %3443, label %3444, label %3449

3444:                                             ; preds = %3440
  %3445 = add i64 %3380, 6
  %3446 = extractelement <8 x bfloat> %3378, i64 6
  %3447 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3448 = getelementptr inbounds nuw bfloat, ptr %3447, i64 %3445
  store bfloat %3446, ptr %3448, align 2
  br label %3449

3449:                                             ; preds = %3444, %3440
  %3450 = add i64 %3373, 7
  %3451 = icmp ult i64 %3450, %26
  %3452 = and i1 %3381, %3451
  br i1 %3452, label %3453, label %3458

3453:                                             ; preds = %3449
  %3454 = add i64 %3380, 7
  %3455 = extractelement <8 x bfloat> %3378, i64 7
  %3456 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3457 = getelementptr inbounds nuw bfloat, ptr %3456, i64 %3454
  store bfloat %3455, ptr %3457, align 2
  br label %3458

3458:                                             ; preds = %3453, %3449
  br label %3459

3459:                                             ; preds = %3385, %3458
  %3460 = urem i64 %55, 32
  %3461 = mul i64 %3460, 8
  %3462 = add i64 %3461, 256
  %3463 = udiv i64 %3462, 32
  %3464 = urem i64 %3462, 32
  %3465 = mul i64 %59, 16
  %3466 = add i64 %3465, %3463
  %3467 = udiv i64 %59, 2
  %3468 = mul i64 %3467, 4
  %3469 = add i64 %3468, 2
  %3470 = mul i64 %3469, 16
  %3471 = add i64 %3463, %3470
  %3472 = add i64 %78, %3471
  %3473 = urem i64 %59, 2
  %3474 = mul i64 %3473, 32
  %3475 = add i64 %3464, %3474
  %3476 = add i64 %79, %3475
  %3477 = mul i64 %3466, 40
  %3478 = add i64 %3477, %3464
  %3479 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3478
  %3480 = load <8 x float>, ptr addrspace(3) %3479, align 16
  %3481 = fptrunc <8 x float> %3480 to <8 x bfloat>
  %3482 = mul i64 %3472, %26
  %3483 = add i64 %3482, %3476
  %3484 = icmp ult i64 %3472, %25
  %3485 = add i64 %3476, 7
  %3486 = icmp ult i64 %3485, %26
  %3487 = and i1 %3484, %3486
  br i1 %3487, label %3488, label %3491

3488:                                             ; preds = %3459
  %3489 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3490 = getelementptr bfloat, ptr %3489, i64 %3483
  store <8 x bfloat> %3481, ptr %3490, align 2
  br label %3562

3491:                                             ; preds = %3459
  %3492 = icmp ult i64 %3476, %26
  %3493 = and i1 %3484, %3492
  br i1 %3493, label %3494, label %3498

3494:                                             ; preds = %3491
  %3495 = extractelement <8 x bfloat> %3481, i64 0
  %3496 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3497 = getelementptr inbounds nuw bfloat, ptr %3496, i64 %3483
  store bfloat %3495, ptr %3497, align 2
  br label %3498

3498:                                             ; preds = %3494, %3491
  %3499 = add i64 %3476, 1
  %3500 = icmp ult i64 %3499, %26
  %3501 = and i1 %3484, %3500
  br i1 %3501, label %3502, label %3507

3502:                                             ; preds = %3498
  %3503 = add i64 %3483, 1
  %3504 = extractelement <8 x bfloat> %3481, i64 1
  %3505 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3506 = getelementptr inbounds nuw bfloat, ptr %3505, i64 %3503
  store bfloat %3504, ptr %3506, align 2
  br label %3507

3507:                                             ; preds = %3502, %3498
  %3508 = add i64 %3476, 2
  %3509 = icmp ult i64 %3508, %26
  %3510 = and i1 %3484, %3509
  br i1 %3510, label %3511, label %3516

3511:                                             ; preds = %3507
  %3512 = add i64 %3483, 2
  %3513 = extractelement <8 x bfloat> %3481, i64 2
  %3514 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3515 = getelementptr inbounds nuw bfloat, ptr %3514, i64 %3512
  store bfloat %3513, ptr %3515, align 2
  br label %3516

3516:                                             ; preds = %3511, %3507
  %3517 = add i64 %3476, 3
  %3518 = icmp ult i64 %3517, %26
  %3519 = and i1 %3484, %3518
  br i1 %3519, label %3520, label %3525

3520:                                             ; preds = %3516
  %3521 = add i64 %3483, 3
  %3522 = extractelement <8 x bfloat> %3481, i64 3
  %3523 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3524 = getelementptr inbounds nuw bfloat, ptr %3523, i64 %3521
  store bfloat %3522, ptr %3524, align 2
  br label %3525

3525:                                             ; preds = %3520, %3516
  %3526 = add i64 %3476, 4
  %3527 = icmp ult i64 %3526, %26
  %3528 = and i1 %3484, %3527
  br i1 %3528, label %3529, label %3534

3529:                                             ; preds = %3525
  %3530 = add i64 %3483, 4
  %3531 = extractelement <8 x bfloat> %3481, i64 4
  %3532 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3533 = getelementptr inbounds nuw bfloat, ptr %3532, i64 %3530
  store bfloat %3531, ptr %3533, align 2
  br label %3534

3534:                                             ; preds = %3529, %3525
  %3535 = add i64 %3476, 5
  %3536 = icmp ult i64 %3535, %26
  %3537 = and i1 %3484, %3536
  br i1 %3537, label %3538, label %3543

3538:                                             ; preds = %3534
  %3539 = add i64 %3483, 5
  %3540 = extractelement <8 x bfloat> %3481, i64 5
  %3541 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3542 = getelementptr inbounds nuw bfloat, ptr %3541, i64 %3539
  store bfloat %3540, ptr %3542, align 2
  br label %3543

3543:                                             ; preds = %3538, %3534
  %3544 = add i64 %3476, 6
  %3545 = icmp ult i64 %3544, %26
  %3546 = and i1 %3484, %3545
  br i1 %3546, label %3547, label %3552

3547:                                             ; preds = %3543
  %3548 = add i64 %3483, 6
  %3549 = extractelement <8 x bfloat> %3481, i64 6
  %3550 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3551 = getelementptr inbounds nuw bfloat, ptr %3550, i64 %3548
  store bfloat %3549, ptr %3551, align 2
  br label %3552

3552:                                             ; preds = %3547, %3543
  %3553 = add i64 %3476, 7
  %3554 = icmp ult i64 %3553, %26
  %3555 = and i1 %3484, %3554
  br i1 %3555, label %3556, label %3561

3556:                                             ; preds = %3552
  %3557 = add i64 %3483, 7
  %3558 = extractelement <8 x bfloat> %3481, i64 7
  %3559 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3560 = getelementptr inbounds nuw bfloat, ptr %3559, i64 %3557
  store bfloat %3558, ptr %3560, align 2
  br label %3561

3561:                                             ; preds = %3556, %3552
  br label %3562

3562:                                             ; preds = %3488, %3561
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %3563 = mul i64 %58, 8
  %3564 = add i64 %88, %3563
  %3565 = add i64 %89, %57
  %3566 = add i64 %3564, 7
  %3567 = icmp ult i64 %3565, %26
  %3568 = icmp ult i64 %3566, %25
  %3569 = and i1 %3568, %3567
  %3570 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3571 = ptrtoint ptr %3570 to i64
  %3572 = mul i64 %3564, 4
  %3573 = add i64 %3571, %3572
  %3574 = urem i64 %3573, 16
  %3575 = icmp eq i64 %3574, 0
  %3576 = and i1 %3569, %3575
  br i1 %3576, label %3577, label %3586

3577:                                             ; preds = %3562
  %3578 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3579 = getelementptr float, ptr %3578, i64 %3564
  %3580 = load <4 x float>, ptr %3579, align 16
  %3581 = add i64 %3564, 4
  %3582 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3583 = getelementptr float, ptr %3582, i64 %3581
  %3584 = load <4 x float>, ptr %3583, align 16
  %3585 = shufflevector <4 x float> %3580, <4 x float> %3584, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3658

3586:                                             ; preds = %3562
  %3587 = mul i64 %58, 8
  %3588 = add i64 %88, %3587
  %3589 = icmp slt i64 %3588, %25
  %3590 = select i1 %3589, i64 %3588, i64 0
  %3591 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3592 = getelementptr inbounds nuw float, ptr %3591, i64 %3590
  %3593 = load float, ptr %3592, align 4
  %3594 = insertelement <8 x float> zeroinitializer, float %3593, i64 0
  %3595 = mul i64 %58, 8
  %3596 = add i64 %3595, 1
  %3597 = add i64 %88, %3596
  %3598 = icmp slt i64 %3597, %25
  %3599 = select i1 %3598, i64 %3597, i64 0
  %3600 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3601 = getelementptr inbounds nuw float, ptr %3600, i64 %3599
  %3602 = load float, ptr %3601, align 4
  %3603 = insertelement <8 x float> %3594, float %3602, i64 1
  %3604 = mul i64 %58, 8
  %3605 = add i64 %3604, 2
  %3606 = add i64 %88, %3605
  %3607 = icmp slt i64 %3606, %25
  %3608 = select i1 %3607, i64 %3606, i64 0
  %3609 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3610 = getelementptr inbounds nuw float, ptr %3609, i64 %3608
  %3611 = load float, ptr %3610, align 4
  %3612 = insertelement <8 x float> %3603, float %3611, i64 2
  %3613 = mul i64 %58, 8
  %3614 = add i64 %3613, 3
  %3615 = add i64 %88, %3614
  %3616 = icmp slt i64 %3615, %25
  %3617 = select i1 %3616, i64 %3615, i64 0
  %3618 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3619 = getelementptr inbounds nuw float, ptr %3618, i64 %3617
  %3620 = load float, ptr %3619, align 4
  %3621 = insertelement <8 x float> %3612, float %3620, i64 3
  %3622 = mul i64 %58, 8
  %3623 = add i64 %3622, 4
  %3624 = add i64 %88, %3623
  %3625 = icmp slt i64 %3624, %25
  %3626 = select i1 %3625, i64 %3624, i64 0
  %3627 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3628 = getelementptr inbounds nuw float, ptr %3627, i64 %3626
  %3629 = load float, ptr %3628, align 4
  %3630 = insertelement <8 x float> %3621, float %3629, i64 4
  %3631 = mul i64 %58, 8
  %3632 = add i64 %3631, 5
  %3633 = add i64 %88, %3632
  %3634 = icmp slt i64 %3633, %25
  %3635 = select i1 %3634, i64 %3633, i64 0
  %3636 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3637 = getelementptr inbounds nuw float, ptr %3636, i64 %3635
  %3638 = load float, ptr %3637, align 4
  %3639 = insertelement <8 x float> %3630, float %3638, i64 5
  %3640 = mul i64 %58, 8
  %3641 = add i64 %3640, 6
  %3642 = add i64 %88, %3641
  %3643 = icmp slt i64 %3642, %25
  %3644 = select i1 %3643, i64 %3642, i64 0
  %3645 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3646 = getelementptr inbounds nuw float, ptr %3645, i64 %3644
  %3647 = load float, ptr %3646, align 4
  %3648 = insertelement <8 x float> %3639, float %3647, i64 6
  %3649 = mul i64 %58, 8
  %3650 = add i64 %3649, 7
  %3651 = add i64 %88, %3650
  %3652 = icmp slt i64 %3651, %25
  %3653 = select i1 %3652, i64 %3651, i64 0
  %3654 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3655 = getelementptr inbounds nuw float, ptr %3654, i64 %3653
  %3656 = load float, ptr %3655, align 4
  %3657 = insertelement <8 x float> %3648, float %3656, i64 7
  br label %3658

3658:                                             ; preds = %3577, %3586
  %3659 = phi <8 x float> [ %3657, %3586 ], [ %3585, %3577 ]
  br label %3660

3660:                                             ; preds = %3658
  %3661 = add i64 %89, %57
  %3662 = icmp slt i64 %3661, %26
  %3663 = select i1 %3662, i64 %3661, i64 0
  %3664 = extractelement <8 x float> %3659, i64 0
  %3665 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3666 = getelementptr inbounds nuw i8, ptr %3665, i64 %3663
  %3667 = load i8, ptr %3666, align 1
  %3668 = zext i8 %3667 to i32
  %3669 = shl i32 %3668, 23
  %3670 = bitcast i32 %3669 to float
  %3671 = fmul float %3670, %3664
  %3672 = extractelement <8 x float> %166, i64 0
  %3673 = fmul float %3672, %3671
  %3674 = call float @llvm.fabs.f32(float %3671)
  %3675 = fcmp olt float %3674, +inf
  %3676 = fcmp one float %3671, 0.000000e+00
  %3677 = and i1 %3675, %3676
  %3678 = call i1 @llvm.expect.i1(i1 %3677, i1 true)
  br i1 %3678, label %3679, label %3680

3679:                                             ; preds = %3660
  br label %3692

3680:                                             ; preds = %3660
  %3681 = fpext float %3672 to double
  %3682 = fpext float %3670 to double
  %3683 = fpext float %3664 to double
  %3684 = fmul double %3681, %3682
  %3685 = fmul double %3684, %3683
  %3686 = fptrunc double %3685 to float
  %3687 = fcmp oeq float %3672, 0.000000e+00
  %3688 = call float @llvm.fabs.f32(float %3664)
  %3689 = fcmp olt float %3688, +inf
  %3690 = and i1 %3687, %3689
  %3691 = select i1 %3690, float 0.000000e+00, float %3686
  br label %3692

3692:                                             ; preds = %3679, %3680
  %3693 = phi float [ %3691, %3680 ], [ %3673, %3679 ]
  br label %3694

3694:                                             ; preds = %3692
  %3695 = add i64 %89, %57
  %3696 = icmp slt i64 %3695, %26
  %3697 = select i1 %3696, i64 %3695, i64 0
  %3698 = extractelement <8 x float> %3659, i64 1
  %3699 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3700 = getelementptr inbounds nuw i8, ptr %3699, i64 %3697
  %3701 = load i8, ptr %3700, align 1
  %3702 = zext i8 %3701 to i32
  %3703 = shl i32 %3702, 23
  %3704 = bitcast i32 %3703 to float
  %3705 = fmul float %3704, %3698
  %3706 = extractelement <8 x float> %166, i64 1
  %3707 = fmul float %3706, %3705
  %3708 = call float @llvm.fabs.f32(float %3705)
  %3709 = fcmp olt float %3708, +inf
  %3710 = fcmp one float %3705, 0.000000e+00
  %3711 = and i1 %3709, %3710
  %3712 = call i1 @llvm.expect.i1(i1 %3711, i1 true)
  br i1 %3712, label %3713, label %3714

3713:                                             ; preds = %3694
  br label %3726

3714:                                             ; preds = %3694
  %3715 = fpext float %3706 to double
  %3716 = fpext float %3704 to double
  %3717 = fpext float %3698 to double
  %3718 = fmul double %3715, %3716
  %3719 = fmul double %3718, %3717
  %3720 = fptrunc double %3719 to float
  %3721 = fcmp oeq float %3706, 0.000000e+00
  %3722 = call float @llvm.fabs.f32(float %3698)
  %3723 = fcmp olt float %3722, +inf
  %3724 = and i1 %3721, %3723
  %3725 = select i1 %3724, float 0.000000e+00, float %3720
  br label %3726

3726:                                             ; preds = %3713, %3714
  %3727 = phi float [ %3725, %3714 ], [ %3707, %3713 ]
  br label %3728

3728:                                             ; preds = %3726
  %3729 = add i64 %89, %57
  %3730 = icmp slt i64 %3729, %26
  %3731 = select i1 %3730, i64 %3729, i64 0
  %3732 = extractelement <8 x float> %3659, i64 2
  %3733 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3734 = getelementptr inbounds nuw i8, ptr %3733, i64 %3731
  %3735 = load i8, ptr %3734, align 1
  %3736 = zext i8 %3735 to i32
  %3737 = shl i32 %3736, 23
  %3738 = bitcast i32 %3737 to float
  %3739 = fmul float %3738, %3732
  %3740 = extractelement <8 x float> %166, i64 2
  %3741 = fmul float %3740, %3739
  %3742 = call float @llvm.fabs.f32(float %3739)
  %3743 = fcmp olt float %3742, +inf
  %3744 = fcmp one float %3739, 0.000000e+00
  %3745 = and i1 %3743, %3744
  %3746 = call i1 @llvm.expect.i1(i1 %3745, i1 true)
  br i1 %3746, label %3747, label %3748

3747:                                             ; preds = %3728
  br label %3760

3748:                                             ; preds = %3728
  %3749 = fpext float %3740 to double
  %3750 = fpext float %3738 to double
  %3751 = fpext float %3732 to double
  %3752 = fmul double %3749, %3750
  %3753 = fmul double %3752, %3751
  %3754 = fptrunc double %3753 to float
  %3755 = fcmp oeq float %3740, 0.000000e+00
  %3756 = call float @llvm.fabs.f32(float %3732)
  %3757 = fcmp olt float %3756, +inf
  %3758 = and i1 %3755, %3757
  %3759 = select i1 %3758, float 0.000000e+00, float %3754
  br label %3760

3760:                                             ; preds = %3747, %3748
  %3761 = phi float [ %3759, %3748 ], [ %3741, %3747 ]
  br label %3762

3762:                                             ; preds = %3760
  %3763 = add i64 %89, %57
  %3764 = icmp slt i64 %3763, %26
  %3765 = select i1 %3764, i64 %3763, i64 0
  %3766 = extractelement <8 x float> %3659, i64 3
  %3767 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3768 = getelementptr inbounds nuw i8, ptr %3767, i64 %3765
  %3769 = load i8, ptr %3768, align 1
  %3770 = zext i8 %3769 to i32
  %3771 = shl i32 %3770, 23
  %3772 = bitcast i32 %3771 to float
  %3773 = fmul float %3772, %3766
  %3774 = extractelement <8 x float> %166, i64 3
  %3775 = fmul float %3774, %3773
  %3776 = call float @llvm.fabs.f32(float %3773)
  %3777 = fcmp olt float %3776, +inf
  %3778 = fcmp one float %3773, 0.000000e+00
  %3779 = and i1 %3777, %3778
  %3780 = call i1 @llvm.expect.i1(i1 %3779, i1 true)
  br i1 %3780, label %3781, label %3782

3781:                                             ; preds = %3762
  br label %3794

3782:                                             ; preds = %3762
  %3783 = fpext float %3774 to double
  %3784 = fpext float %3772 to double
  %3785 = fpext float %3766 to double
  %3786 = fmul double %3783, %3784
  %3787 = fmul double %3786, %3785
  %3788 = fptrunc double %3787 to float
  %3789 = fcmp oeq float %3774, 0.000000e+00
  %3790 = call float @llvm.fabs.f32(float %3766)
  %3791 = fcmp olt float %3790, +inf
  %3792 = and i1 %3789, %3791
  %3793 = select i1 %3792, float 0.000000e+00, float %3788
  br label %3794

3794:                                             ; preds = %3781, %3782
  %3795 = phi float [ %3793, %3782 ], [ %3775, %3781 ]
  br label %3796

3796:                                             ; preds = %3794
  %3797 = add i64 %89, %57
  %3798 = icmp slt i64 %3797, %26
  %3799 = select i1 %3798, i64 %3797, i64 0
  %3800 = extractelement <8 x float> %3659, i64 4
  %3801 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3802 = getelementptr inbounds nuw i8, ptr %3801, i64 %3799
  %3803 = load i8, ptr %3802, align 1
  %3804 = zext i8 %3803 to i32
  %3805 = shl i32 %3804, 23
  %3806 = bitcast i32 %3805 to float
  %3807 = fmul float %3806, %3800
  %3808 = extractelement <8 x float> %166, i64 4
  %3809 = fmul float %3808, %3807
  %3810 = call float @llvm.fabs.f32(float %3807)
  %3811 = fcmp olt float %3810, +inf
  %3812 = fcmp one float %3807, 0.000000e+00
  %3813 = and i1 %3811, %3812
  %3814 = call i1 @llvm.expect.i1(i1 %3813, i1 true)
  br i1 %3814, label %3815, label %3816

3815:                                             ; preds = %3796
  br label %3828

3816:                                             ; preds = %3796
  %3817 = fpext float %3808 to double
  %3818 = fpext float %3806 to double
  %3819 = fpext float %3800 to double
  %3820 = fmul double %3817, %3818
  %3821 = fmul double %3820, %3819
  %3822 = fptrunc double %3821 to float
  %3823 = fcmp oeq float %3808, 0.000000e+00
  %3824 = call float @llvm.fabs.f32(float %3800)
  %3825 = fcmp olt float %3824, +inf
  %3826 = and i1 %3823, %3825
  %3827 = select i1 %3826, float 0.000000e+00, float %3822
  br label %3828

3828:                                             ; preds = %3815, %3816
  %3829 = phi float [ %3827, %3816 ], [ %3809, %3815 ]
  br label %3830

3830:                                             ; preds = %3828
  %3831 = add i64 %89, %57
  %3832 = icmp slt i64 %3831, %26
  %3833 = select i1 %3832, i64 %3831, i64 0
  %3834 = extractelement <8 x float> %3659, i64 5
  %3835 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3836 = getelementptr inbounds nuw i8, ptr %3835, i64 %3833
  %3837 = load i8, ptr %3836, align 1
  %3838 = zext i8 %3837 to i32
  %3839 = shl i32 %3838, 23
  %3840 = bitcast i32 %3839 to float
  %3841 = fmul float %3840, %3834
  %3842 = extractelement <8 x float> %166, i64 5
  %3843 = fmul float %3842, %3841
  %3844 = call float @llvm.fabs.f32(float %3841)
  %3845 = fcmp olt float %3844, +inf
  %3846 = fcmp one float %3841, 0.000000e+00
  %3847 = and i1 %3845, %3846
  %3848 = call i1 @llvm.expect.i1(i1 %3847, i1 true)
  br i1 %3848, label %3849, label %3850

3849:                                             ; preds = %3830
  br label %3862

3850:                                             ; preds = %3830
  %3851 = fpext float %3842 to double
  %3852 = fpext float %3840 to double
  %3853 = fpext float %3834 to double
  %3854 = fmul double %3851, %3852
  %3855 = fmul double %3854, %3853
  %3856 = fptrunc double %3855 to float
  %3857 = fcmp oeq float %3842, 0.000000e+00
  %3858 = call float @llvm.fabs.f32(float %3834)
  %3859 = fcmp olt float %3858, +inf
  %3860 = and i1 %3857, %3859
  %3861 = select i1 %3860, float 0.000000e+00, float %3856
  br label %3862

3862:                                             ; preds = %3849, %3850
  %3863 = phi float [ %3861, %3850 ], [ %3843, %3849 ]
  br label %3864

3864:                                             ; preds = %3862
  %3865 = add i64 %89, %57
  %3866 = icmp slt i64 %3865, %26
  %3867 = select i1 %3866, i64 %3865, i64 0
  %3868 = extractelement <8 x float> %3659, i64 6
  %3869 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3870 = getelementptr inbounds nuw i8, ptr %3869, i64 %3867
  %3871 = load i8, ptr %3870, align 1
  %3872 = zext i8 %3871 to i32
  %3873 = shl i32 %3872, 23
  %3874 = bitcast i32 %3873 to float
  %3875 = fmul float %3874, %3868
  %3876 = extractelement <8 x float> %166, i64 6
  %3877 = fmul float %3876, %3875
  %3878 = call float @llvm.fabs.f32(float %3875)
  %3879 = fcmp olt float %3878, +inf
  %3880 = fcmp one float %3875, 0.000000e+00
  %3881 = and i1 %3879, %3880
  %3882 = call i1 @llvm.expect.i1(i1 %3881, i1 true)
  br i1 %3882, label %3883, label %3884

3883:                                             ; preds = %3864
  br label %3896

3884:                                             ; preds = %3864
  %3885 = fpext float %3876 to double
  %3886 = fpext float %3874 to double
  %3887 = fpext float %3868 to double
  %3888 = fmul double %3885, %3886
  %3889 = fmul double %3888, %3887
  %3890 = fptrunc double %3889 to float
  %3891 = fcmp oeq float %3876, 0.000000e+00
  %3892 = call float @llvm.fabs.f32(float %3868)
  %3893 = fcmp olt float %3892, +inf
  %3894 = and i1 %3891, %3893
  %3895 = select i1 %3894, float 0.000000e+00, float %3890
  br label %3896

3896:                                             ; preds = %3883, %3884
  %3897 = phi float [ %3895, %3884 ], [ %3877, %3883 ]
  br label %3898

3898:                                             ; preds = %3896
  %3899 = add i64 %89, %57
  %3900 = icmp slt i64 %3899, %26
  %3901 = select i1 %3900, i64 %3899, i64 0
  %3902 = extractelement <8 x float> %3659, i64 7
  %3903 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3904 = getelementptr inbounds nuw i8, ptr %3903, i64 %3901
  %3905 = load i8, ptr %3904, align 1
  %3906 = zext i8 %3905 to i32
  %3907 = shl i32 %3906, 23
  %3908 = bitcast i32 %3907 to float
  %3909 = fmul float %3908, %3902
  %3910 = extractelement <8 x float> %166, i64 7
  %3911 = fmul float %3910, %3909
  %3912 = call float @llvm.fabs.f32(float %3909)
  %3913 = fcmp olt float %3912, +inf
  %3914 = fcmp one float %3909, 0.000000e+00
  %3915 = and i1 %3913, %3914
  %3916 = call i1 @llvm.expect.i1(i1 %3915, i1 true)
  br i1 %3916, label %3917, label %3918

3917:                                             ; preds = %3898
  br label %3930

3918:                                             ; preds = %3898
  %3919 = fpext float %3910 to double
  %3920 = fpext float %3908 to double
  %3921 = fpext float %3902 to double
  %3922 = fmul double %3919, %3920
  %3923 = fmul double %3922, %3921
  %3924 = fptrunc double %3923 to float
  %3925 = fcmp oeq float %3910, 0.000000e+00
  %3926 = call float @llvm.fabs.f32(float %3902)
  %3927 = fcmp olt float %3926, +inf
  %3928 = and i1 %3925, %3927
  %3929 = select i1 %3928, float 0.000000e+00, float %3924
  br label %3930

3930:                                             ; preds = %3917, %3918
  %3931 = phi float [ %3929, %3918 ], [ %3911, %3917 ]
  br label %3932

3932:                                             ; preds = %3930
  %3933 = mul i64 %59, 16
  %3934 = mul i64 %58, 8
  %3935 = add i64 %3933, %3934
  %3936 = mul i64 %3935, 40
  %3937 = add i64 %3936, %57
  %3938 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3937
  store float %3693, ptr addrspace(3) %3938, align 4
  %3939 = mul i64 %58, 8
  %3940 = add i64 %3939, 1
  %3941 = add i64 %3933, %3940
  %3942 = mul i64 %3941, 40
  %3943 = add i64 %3942, %57
  %3944 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3943
  store float %3727, ptr addrspace(3) %3944, align 4
  %3945 = mul i64 %58, 8
  %3946 = add i64 %3945, 2
  %3947 = add i64 %3933, %3946
  %3948 = mul i64 %3947, 40
  %3949 = add i64 %3948, %57
  %3950 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3949
  store float %3761, ptr addrspace(3) %3950, align 4
  %3951 = mul i64 %58, 8
  %3952 = add i64 %3951, 3
  %3953 = add i64 %3933, %3952
  %3954 = mul i64 %3953, 40
  %3955 = add i64 %3954, %57
  %3956 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3955
  store float %3795, ptr addrspace(3) %3956, align 4
  %3957 = mul i64 %58, 8
  %3958 = add i64 %3957, 4
  %3959 = add i64 %3933, %3958
  %3960 = mul i64 %3959, 40
  %3961 = add i64 %3960, %57
  %3962 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3961
  store float %3829, ptr addrspace(3) %3962, align 4
  %3963 = mul i64 %58, 8
  %3964 = add i64 %3963, 5
  %3965 = add i64 %3933, %3964
  %3966 = mul i64 %3965, 40
  %3967 = add i64 %3966, %57
  %3968 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3967
  store float %3863, ptr addrspace(3) %3968, align 4
  %3969 = mul i64 %58, 8
  %3970 = add i64 %3969, 6
  %3971 = add i64 %3933, %3970
  %3972 = mul i64 %3971, 40
  %3973 = add i64 %3972, %57
  %3974 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3973
  store float %3897, ptr addrspace(3) %3974, align 4
  %3975 = mul i64 %58, 8
  %3976 = add i64 %3975, 7
  %3977 = add i64 %3933, %3976
  %3978 = mul i64 %3977, 40
  %3979 = add i64 %3978, %57
  %3980 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3979
  store float %3931, ptr addrspace(3) %3980, align 4
  %3981 = mul i64 %58, 8
  %3982 = add i64 %88, %3981
  %3983 = add i64 %91, %57
  %3984 = add i64 %3982, 7
  %3985 = icmp ult i64 %3983, %26
  %3986 = icmp ult i64 %3984, %25
  %3987 = and i1 %3986, %3985
  %3988 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3989 = ptrtoint ptr %3988 to i64
  %3990 = mul i64 %3982, 4
  %3991 = add i64 %3989, %3990
  %3992 = urem i64 %3991, 16
  %3993 = icmp eq i64 %3992, 0
  %3994 = and i1 %3987, %3993
  br i1 %3994, label %3995, label %4004

3995:                                             ; preds = %3932
  %3996 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3997 = getelementptr float, ptr %3996, i64 %3982
  %3998 = load <4 x float>, ptr %3997, align 16
  %3999 = add i64 %3982, 4
  %4000 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4001 = getelementptr float, ptr %4000, i64 %3999
  %4002 = load <4 x float>, ptr %4001, align 16
  %4003 = shufflevector <4 x float> %3998, <4 x float> %4002, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %4076

4004:                                             ; preds = %3932
  %4005 = mul i64 %58, 8
  %4006 = add i64 %88, %4005
  %4007 = icmp slt i64 %4006, %25
  %4008 = select i1 %4007, i64 %4006, i64 0
  %4009 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4010 = getelementptr inbounds nuw float, ptr %4009, i64 %4008
  %4011 = load float, ptr %4010, align 4
  %4012 = insertelement <8 x float> zeroinitializer, float %4011, i64 0
  %4013 = mul i64 %58, 8
  %4014 = add i64 %4013, 1
  %4015 = add i64 %88, %4014
  %4016 = icmp slt i64 %4015, %25
  %4017 = select i1 %4016, i64 %4015, i64 0
  %4018 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4019 = getelementptr inbounds nuw float, ptr %4018, i64 %4017
  %4020 = load float, ptr %4019, align 4
  %4021 = insertelement <8 x float> %4012, float %4020, i64 1
  %4022 = mul i64 %58, 8
  %4023 = add i64 %4022, 2
  %4024 = add i64 %88, %4023
  %4025 = icmp slt i64 %4024, %25
  %4026 = select i1 %4025, i64 %4024, i64 0
  %4027 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4028 = getelementptr inbounds nuw float, ptr %4027, i64 %4026
  %4029 = load float, ptr %4028, align 4
  %4030 = insertelement <8 x float> %4021, float %4029, i64 2
  %4031 = mul i64 %58, 8
  %4032 = add i64 %4031, 3
  %4033 = add i64 %88, %4032
  %4034 = icmp slt i64 %4033, %25
  %4035 = select i1 %4034, i64 %4033, i64 0
  %4036 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4037 = getelementptr inbounds nuw float, ptr %4036, i64 %4035
  %4038 = load float, ptr %4037, align 4
  %4039 = insertelement <8 x float> %4030, float %4038, i64 3
  %4040 = mul i64 %58, 8
  %4041 = add i64 %4040, 4
  %4042 = add i64 %88, %4041
  %4043 = icmp slt i64 %4042, %25
  %4044 = select i1 %4043, i64 %4042, i64 0
  %4045 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4046 = getelementptr inbounds nuw float, ptr %4045, i64 %4044
  %4047 = load float, ptr %4046, align 4
  %4048 = insertelement <8 x float> %4039, float %4047, i64 4
  %4049 = mul i64 %58, 8
  %4050 = add i64 %4049, 5
  %4051 = add i64 %88, %4050
  %4052 = icmp slt i64 %4051, %25
  %4053 = select i1 %4052, i64 %4051, i64 0
  %4054 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4055 = getelementptr inbounds nuw float, ptr %4054, i64 %4053
  %4056 = load float, ptr %4055, align 4
  %4057 = insertelement <8 x float> %4048, float %4056, i64 5
  %4058 = mul i64 %58, 8
  %4059 = add i64 %4058, 6
  %4060 = add i64 %88, %4059
  %4061 = icmp slt i64 %4060, %25
  %4062 = select i1 %4061, i64 %4060, i64 0
  %4063 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4064 = getelementptr inbounds nuw float, ptr %4063, i64 %4062
  %4065 = load float, ptr %4064, align 4
  %4066 = insertelement <8 x float> %4057, float %4065, i64 6
  %4067 = mul i64 %58, 8
  %4068 = add i64 %4067, 7
  %4069 = add i64 %88, %4068
  %4070 = icmp slt i64 %4069, %25
  %4071 = select i1 %4070, i64 %4069, i64 0
  %4072 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4073 = getelementptr inbounds nuw float, ptr %4072, i64 %4071
  %4074 = load float, ptr %4073, align 4
  %4075 = insertelement <8 x float> %4066, float %4074, i64 7
  br label %4076

4076:                                             ; preds = %3995, %4004
  %4077 = phi <8 x float> [ %4075, %4004 ], [ %4003, %3995 ]
  br label %4078

4078:                                             ; preds = %4076
  %4079 = add i64 %91, %57
  %4080 = icmp slt i64 %4079, %26
  %4081 = select i1 %4080, i64 %4079, i64 0
  %4082 = extractelement <8 x float> %4077, i64 0
  %4083 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4084 = getelementptr inbounds nuw i8, ptr %4083, i64 %4081
  %4085 = load i8, ptr %4084, align 1
  %4086 = zext i8 %4085 to i32
  %4087 = shl i32 %4086, 23
  %4088 = bitcast i32 %4087 to float
  %4089 = fmul float %4088, %4082
  %4090 = extractelement <8 x float> %167, i64 0
  %4091 = fmul float %4090, %4089
  %4092 = call float @llvm.fabs.f32(float %4089)
  %4093 = fcmp olt float %4092, +inf
  %4094 = fcmp one float %4089, 0.000000e+00
  %4095 = and i1 %4093, %4094
  %4096 = call i1 @llvm.expect.i1(i1 %4095, i1 true)
  br i1 %4096, label %4097, label %4098

4097:                                             ; preds = %4078
  br label %4110

4098:                                             ; preds = %4078
  %4099 = fpext float %4090 to double
  %4100 = fpext float %4088 to double
  %4101 = fpext float %4082 to double
  %4102 = fmul double %4099, %4100
  %4103 = fmul double %4102, %4101
  %4104 = fptrunc double %4103 to float
  %4105 = fcmp oeq float %4090, 0.000000e+00
  %4106 = call float @llvm.fabs.f32(float %4082)
  %4107 = fcmp olt float %4106, +inf
  %4108 = and i1 %4105, %4107
  %4109 = select i1 %4108, float 0.000000e+00, float %4104
  br label %4110

4110:                                             ; preds = %4097, %4098
  %4111 = phi float [ %4109, %4098 ], [ %4091, %4097 ]
  br label %4112

4112:                                             ; preds = %4110
  %4113 = add i64 %91, %57
  %4114 = icmp slt i64 %4113, %26
  %4115 = select i1 %4114, i64 %4113, i64 0
  %4116 = extractelement <8 x float> %4077, i64 1
  %4117 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4118 = getelementptr inbounds nuw i8, ptr %4117, i64 %4115
  %4119 = load i8, ptr %4118, align 1
  %4120 = zext i8 %4119 to i32
  %4121 = shl i32 %4120, 23
  %4122 = bitcast i32 %4121 to float
  %4123 = fmul float %4122, %4116
  %4124 = extractelement <8 x float> %167, i64 1
  %4125 = fmul float %4124, %4123
  %4126 = call float @llvm.fabs.f32(float %4123)
  %4127 = fcmp olt float %4126, +inf
  %4128 = fcmp one float %4123, 0.000000e+00
  %4129 = and i1 %4127, %4128
  %4130 = call i1 @llvm.expect.i1(i1 %4129, i1 true)
  br i1 %4130, label %4131, label %4132

4131:                                             ; preds = %4112
  br label %4144

4132:                                             ; preds = %4112
  %4133 = fpext float %4124 to double
  %4134 = fpext float %4122 to double
  %4135 = fpext float %4116 to double
  %4136 = fmul double %4133, %4134
  %4137 = fmul double %4136, %4135
  %4138 = fptrunc double %4137 to float
  %4139 = fcmp oeq float %4124, 0.000000e+00
  %4140 = call float @llvm.fabs.f32(float %4116)
  %4141 = fcmp olt float %4140, +inf
  %4142 = and i1 %4139, %4141
  %4143 = select i1 %4142, float 0.000000e+00, float %4138
  br label %4144

4144:                                             ; preds = %4131, %4132
  %4145 = phi float [ %4143, %4132 ], [ %4125, %4131 ]
  br label %4146

4146:                                             ; preds = %4144
  %4147 = add i64 %91, %57
  %4148 = icmp slt i64 %4147, %26
  %4149 = select i1 %4148, i64 %4147, i64 0
  %4150 = extractelement <8 x float> %4077, i64 2
  %4151 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4152 = getelementptr inbounds nuw i8, ptr %4151, i64 %4149
  %4153 = load i8, ptr %4152, align 1
  %4154 = zext i8 %4153 to i32
  %4155 = shl i32 %4154, 23
  %4156 = bitcast i32 %4155 to float
  %4157 = fmul float %4156, %4150
  %4158 = extractelement <8 x float> %167, i64 2
  %4159 = fmul float %4158, %4157
  %4160 = call float @llvm.fabs.f32(float %4157)
  %4161 = fcmp olt float %4160, +inf
  %4162 = fcmp one float %4157, 0.000000e+00
  %4163 = and i1 %4161, %4162
  %4164 = call i1 @llvm.expect.i1(i1 %4163, i1 true)
  br i1 %4164, label %4165, label %4166

4165:                                             ; preds = %4146
  br label %4178

4166:                                             ; preds = %4146
  %4167 = fpext float %4158 to double
  %4168 = fpext float %4156 to double
  %4169 = fpext float %4150 to double
  %4170 = fmul double %4167, %4168
  %4171 = fmul double %4170, %4169
  %4172 = fptrunc double %4171 to float
  %4173 = fcmp oeq float %4158, 0.000000e+00
  %4174 = call float @llvm.fabs.f32(float %4150)
  %4175 = fcmp olt float %4174, +inf
  %4176 = and i1 %4173, %4175
  %4177 = select i1 %4176, float 0.000000e+00, float %4172
  br label %4178

4178:                                             ; preds = %4165, %4166
  %4179 = phi float [ %4177, %4166 ], [ %4159, %4165 ]
  br label %4180

4180:                                             ; preds = %4178
  %4181 = add i64 %91, %57
  %4182 = icmp slt i64 %4181, %26
  %4183 = select i1 %4182, i64 %4181, i64 0
  %4184 = extractelement <8 x float> %4077, i64 3
  %4185 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4186 = getelementptr inbounds nuw i8, ptr %4185, i64 %4183
  %4187 = load i8, ptr %4186, align 1
  %4188 = zext i8 %4187 to i32
  %4189 = shl i32 %4188, 23
  %4190 = bitcast i32 %4189 to float
  %4191 = fmul float %4190, %4184
  %4192 = extractelement <8 x float> %167, i64 3
  %4193 = fmul float %4192, %4191
  %4194 = call float @llvm.fabs.f32(float %4191)
  %4195 = fcmp olt float %4194, +inf
  %4196 = fcmp one float %4191, 0.000000e+00
  %4197 = and i1 %4195, %4196
  %4198 = call i1 @llvm.expect.i1(i1 %4197, i1 true)
  br i1 %4198, label %4199, label %4200

4199:                                             ; preds = %4180
  br label %4212

4200:                                             ; preds = %4180
  %4201 = fpext float %4192 to double
  %4202 = fpext float %4190 to double
  %4203 = fpext float %4184 to double
  %4204 = fmul double %4201, %4202
  %4205 = fmul double %4204, %4203
  %4206 = fptrunc double %4205 to float
  %4207 = fcmp oeq float %4192, 0.000000e+00
  %4208 = call float @llvm.fabs.f32(float %4184)
  %4209 = fcmp olt float %4208, +inf
  %4210 = and i1 %4207, %4209
  %4211 = select i1 %4210, float 0.000000e+00, float %4206
  br label %4212

4212:                                             ; preds = %4199, %4200
  %4213 = phi float [ %4211, %4200 ], [ %4193, %4199 ]
  br label %4214

4214:                                             ; preds = %4212
  %4215 = add i64 %91, %57
  %4216 = icmp slt i64 %4215, %26
  %4217 = select i1 %4216, i64 %4215, i64 0
  %4218 = extractelement <8 x float> %4077, i64 4
  %4219 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4220 = getelementptr inbounds nuw i8, ptr %4219, i64 %4217
  %4221 = load i8, ptr %4220, align 1
  %4222 = zext i8 %4221 to i32
  %4223 = shl i32 %4222, 23
  %4224 = bitcast i32 %4223 to float
  %4225 = fmul float %4224, %4218
  %4226 = extractelement <8 x float> %167, i64 4
  %4227 = fmul float %4226, %4225
  %4228 = call float @llvm.fabs.f32(float %4225)
  %4229 = fcmp olt float %4228, +inf
  %4230 = fcmp one float %4225, 0.000000e+00
  %4231 = and i1 %4229, %4230
  %4232 = call i1 @llvm.expect.i1(i1 %4231, i1 true)
  br i1 %4232, label %4233, label %4234

4233:                                             ; preds = %4214
  br label %4246

4234:                                             ; preds = %4214
  %4235 = fpext float %4226 to double
  %4236 = fpext float %4224 to double
  %4237 = fpext float %4218 to double
  %4238 = fmul double %4235, %4236
  %4239 = fmul double %4238, %4237
  %4240 = fptrunc double %4239 to float
  %4241 = fcmp oeq float %4226, 0.000000e+00
  %4242 = call float @llvm.fabs.f32(float %4218)
  %4243 = fcmp olt float %4242, +inf
  %4244 = and i1 %4241, %4243
  %4245 = select i1 %4244, float 0.000000e+00, float %4240
  br label %4246

4246:                                             ; preds = %4233, %4234
  %4247 = phi float [ %4245, %4234 ], [ %4227, %4233 ]
  br label %4248

4248:                                             ; preds = %4246
  %4249 = add i64 %91, %57
  %4250 = icmp slt i64 %4249, %26
  %4251 = select i1 %4250, i64 %4249, i64 0
  %4252 = extractelement <8 x float> %4077, i64 5
  %4253 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4254 = getelementptr inbounds nuw i8, ptr %4253, i64 %4251
  %4255 = load i8, ptr %4254, align 1
  %4256 = zext i8 %4255 to i32
  %4257 = shl i32 %4256, 23
  %4258 = bitcast i32 %4257 to float
  %4259 = fmul float %4258, %4252
  %4260 = extractelement <8 x float> %167, i64 5
  %4261 = fmul float %4260, %4259
  %4262 = call float @llvm.fabs.f32(float %4259)
  %4263 = fcmp olt float %4262, +inf
  %4264 = fcmp one float %4259, 0.000000e+00
  %4265 = and i1 %4263, %4264
  %4266 = call i1 @llvm.expect.i1(i1 %4265, i1 true)
  br i1 %4266, label %4267, label %4268

4267:                                             ; preds = %4248
  br label %4280

4268:                                             ; preds = %4248
  %4269 = fpext float %4260 to double
  %4270 = fpext float %4258 to double
  %4271 = fpext float %4252 to double
  %4272 = fmul double %4269, %4270
  %4273 = fmul double %4272, %4271
  %4274 = fptrunc double %4273 to float
  %4275 = fcmp oeq float %4260, 0.000000e+00
  %4276 = call float @llvm.fabs.f32(float %4252)
  %4277 = fcmp olt float %4276, +inf
  %4278 = and i1 %4275, %4277
  %4279 = select i1 %4278, float 0.000000e+00, float %4274
  br label %4280

4280:                                             ; preds = %4267, %4268
  %4281 = phi float [ %4279, %4268 ], [ %4261, %4267 ]
  br label %4282

4282:                                             ; preds = %4280
  %4283 = add i64 %91, %57
  %4284 = icmp slt i64 %4283, %26
  %4285 = select i1 %4284, i64 %4283, i64 0
  %4286 = extractelement <8 x float> %4077, i64 6
  %4287 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4288 = getelementptr inbounds nuw i8, ptr %4287, i64 %4285
  %4289 = load i8, ptr %4288, align 1
  %4290 = zext i8 %4289 to i32
  %4291 = shl i32 %4290, 23
  %4292 = bitcast i32 %4291 to float
  %4293 = fmul float %4292, %4286
  %4294 = extractelement <8 x float> %167, i64 6
  %4295 = fmul float %4294, %4293
  %4296 = call float @llvm.fabs.f32(float %4293)
  %4297 = fcmp olt float %4296, +inf
  %4298 = fcmp one float %4293, 0.000000e+00
  %4299 = and i1 %4297, %4298
  %4300 = call i1 @llvm.expect.i1(i1 %4299, i1 true)
  br i1 %4300, label %4301, label %4302

4301:                                             ; preds = %4282
  br label %4314

4302:                                             ; preds = %4282
  %4303 = fpext float %4294 to double
  %4304 = fpext float %4292 to double
  %4305 = fpext float %4286 to double
  %4306 = fmul double %4303, %4304
  %4307 = fmul double %4306, %4305
  %4308 = fptrunc double %4307 to float
  %4309 = fcmp oeq float %4294, 0.000000e+00
  %4310 = call float @llvm.fabs.f32(float %4286)
  %4311 = fcmp olt float %4310, +inf
  %4312 = and i1 %4309, %4311
  %4313 = select i1 %4312, float 0.000000e+00, float %4308
  br label %4314

4314:                                             ; preds = %4301, %4302
  %4315 = phi float [ %4313, %4302 ], [ %4295, %4301 ]
  br label %4316

4316:                                             ; preds = %4314
  %4317 = add i64 %91, %57
  %4318 = icmp slt i64 %4317, %26
  %4319 = select i1 %4318, i64 %4317, i64 0
  %4320 = extractelement <8 x float> %4077, i64 7
  %4321 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4322 = getelementptr inbounds nuw i8, ptr %4321, i64 %4319
  %4323 = load i8, ptr %4322, align 1
  %4324 = zext i8 %4323 to i32
  %4325 = shl i32 %4324, 23
  %4326 = bitcast i32 %4325 to float
  %4327 = fmul float %4326, %4320
  %4328 = extractelement <8 x float> %167, i64 7
  %4329 = fmul float %4328, %4327
  %4330 = call float @llvm.fabs.f32(float %4327)
  %4331 = fcmp olt float %4330, +inf
  %4332 = fcmp one float %4327, 0.000000e+00
  %4333 = and i1 %4331, %4332
  %4334 = call i1 @llvm.expect.i1(i1 %4333, i1 true)
  br i1 %4334, label %4335, label %4336

4335:                                             ; preds = %4316
  br label %4348

4336:                                             ; preds = %4316
  %4337 = fpext float %4328 to double
  %4338 = fpext float %4326 to double
  %4339 = fpext float %4320 to double
  %4340 = fmul double %4337, %4338
  %4341 = fmul double %4340, %4339
  %4342 = fptrunc double %4341 to float
  %4343 = fcmp oeq float %4328, 0.000000e+00
  %4344 = call float @llvm.fabs.f32(float %4320)
  %4345 = fcmp olt float %4344, +inf
  %4346 = and i1 %4343, %4345
  %4347 = select i1 %4346, float 0.000000e+00, float %4342
  br label %4348

4348:                                             ; preds = %4335, %4336
  %4349 = phi float [ %4347, %4336 ], [ %4329, %4335 ]
  br label %4350

4350:                                             ; preds = %4348
  %4351 = mul i64 %59, 16
  %4352 = mul i64 %58, 8
  %4353 = add i64 %4351, %4352
  %4354 = add i64 %57, 16
  %4355 = mul i64 %4353, 40
  %4356 = add i64 %4355, %4354
  %4357 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4356
  store float %4111, ptr addrspace(3) %4357, align 4
  %4358 = mul i64 %58, 8
  %4359 = add i64 %4358, 1
  %4360 = add i64 %4351, %4359
  %4361 = add i64 %57, 16
  %4362 = mul i64 %4360, 40
  %4363 = add i64 %4362, %4361
  %4364 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4363
  store float %4145, ptr addrspace(3) %4364, align 4
  %4365 = mul i64 %58, 8
  %4366 = add i64 %4365, 2
  %4367 = add i64 %4351, %4366
  %4368 = add i64 %57, 16
  %4369 = mul i64 %4367, 40
  %4370 = add i64 %4369, %4368
  %4371 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4370
  store float %4179, ptr addrspace(3) %4371, align 4
  %4372 = mul i64 %58, 8
  %4373 = add i64 %4372, 3
  %4374 = add i64 %4351, %4373
  %4375 = add i64 %57, 16
  %4376 = mul i64 %4374, 40
  %4377 = add i64 %4376, %4375
  %4378 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4377
  store float %4213, ptr addrspace(3) %4378, align 4
  %4379 = mul i64 %58, 8
  %4380 = add i64 %4379, 4
  %4381 = add i64 %4351, %4380
  %4382 = add i64 %57, 16
  %4383 = mul i64 %4381, 40
  %4384 = add i64 %4383, %4382
  %4385 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4384
  store float %4247, ptr addrspace(3) %4385, align 4
  %4386 = mul i64 %58, 8
  %4387 = add i64 %4386, 5
  %4388 = add i64 %4351, %4387
  %4389 = add i64 %57, 16
  %4390 = mul i64 %4388, 40
  %4391 = add i64 %4390, %4389
  %4392 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4391
  store float %4281, ptr addrspace(3) %4392, align 4
  %4393 = mul i64 %58, 8
  %4394 = add i64 %4393, 6
  %4395 = add i64 %4351, %4394
  %4396 = add i64 %57, 16
  %4397 = mul i64 %4395, 40
  %4398 = add i64 %4397, %4396
  %4399 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4398
  store float %4315, ptr addrspace(3) %4399, align 4
  %4400 = mul i64 %58, 8
  %4401 = add i64 %4400, 7
  %4402 = add i64 %4351, %4401
  %4403 = add i64 %57, 16
  %4404 = mul i64 %4402, 40
  %4405 = add i64 %4404, %4403
  %4406 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4405
  store float %4349, ptr addrspace(3) %4406, align 4
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  %4407 = urem i64 %55, 32
  %4408 = mul i64 %4407, 8
  %4409 = udiv i64 %4408, 32
  %4410 = urem i64 %4408, 32
  %4411 = mul i64 %59, 16
  %4412 = add i64 %4411, %4409
  %4413 = udiv i64 %59, 2
  %4414 = mul i64 %4413, 4
  %4415 = add i64 %4414, 3
  %4416 = mul i64 %4415, 16
  %4417 = add i64 %4409, %4416
  %4418 = add i64 %78, %4417
  %4419 = urem i64 %59, 2
  %4420 = mul i64 %4419, 32
  %4421 = add i64 %4410, %4420
  %4422 = add i64 %79, %4421
  %4423 = mul i64 %4412, 40
  %4424 = add i64 %4423, %4410
  %4425 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4424
  %4426 = load <8 x float>, ptr addrspace(3) %4425, align 16
  %4427 = fptrunc <8 x float> %4426 to <8 x bfloat>
  %4428 = mul i64 %4418, %26
  %4429 = add i64 %4428, %4422
  %4430 = icmp ult i64 %4418, %25
  %4431 = add i64 %4422, 7
  %4432 = icmp ult i64 %4431, %26
  %4433 = and i1 %4430, %4432
  br i1 %4433, label %4434, label %4437

4434:                                             ; preds = %4350
  %4435 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4436 = getelementptr bfloat, ptr %4435, i64 %4429
  store <8 x bfloat> %4427, ptr %4436, align 2
  br label %4508

4437:                                             ; preds = %4350
  %4438 = icmp ult i64 %4422, %26
  %4439 = and i1 %4430, %4438
  br i1 %4439, label %4440, label %4444

4440:                                             ; preds = %4437
  %4441 = extractelement <8 x bfloat> %4427, i64 0
  %4442 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4443 = getelementptr inbounds nuw bfloat, ptr %4442, i64 %4429
  store bfloat %4441, ptr %4443, align 2
  br label %4444

4444:                                             ; preds = %4440, %4437
  %4445 = add i64 %4422, 1
  %4446 = icmp ult i64 %4445, %26
  %4447 = and i1 %4430, %4446
  br i1 %4447, label %4448, label %4453

4448:                                             ; preds = %4444
  %4449 = add i64 %4429, 1
  %4450 = extractelement <8 x bfloat> %4427, i64 1
  %4451 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4452 = getelementptr inbounds nuw bfloat, ptr %4451, i64 %4449
  store bfloat %4450, ptr %4452, align 2
  br label %4453

4453:                                             ; preds = %4448, %4444
  %4454 = add i64 %4422, 2
  %4455 = icmp ult i64 %4454, %26
  %4456 = and i1 %4430, %4455
  br i1 %4456, label %4457, label %4462

4457:                                             ; preds = %4453
  %4458 = add i64 %4429, 2
  %4459 = extractelement <8 x bfloat> %4427, i64 2
  %4460 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4461 = getelementptr inbounds nuw bfloat, ptr %4460, i64 %4458
  store bfloat %4459, ptr %4461, align 2
  br label %4462

4462:                                             ; preds = %4457, %4453
  %4463 = add i64 %4422, 3
  %4464 = icmp ult i64 %4463, %26
  %4465 = and i1 %4430, %4464
  br i1 %4465, label %4466, label %4471

4466:                                             ; preds = %4462
  %4467 = add i64 %4429, 3
  %4468 = extractelement <8 x bfloat> %4427, i64 3
  %4469 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4470 = getelementptr inbounds nuw bfloat, ptr %4469, i64 %4467
  store bfloat %4468, ptr %4470, align 2
  br label %4471

4471:                                             ; preds = %4466, %4462
  %4472 = add i64 %4422, 4
  %4473 = icmp ult i64 %4472, %26
  %4474 = and i1 %4430, %4473
  br i1 %4474, label %4475, label %4480

4475:                                             ; preds = %4471
  %4476 = add i64 %4429, 4
  %4477 = extractelement <8 x bfloat> %4427, i64 4
  %4478 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4479 = getelementptr inbounds nuw bfloat, ptr %4478, i64 %4476
  store bfloat %4477, ptr %4479, align 2
  br label %4480

4480:                                             ; preds = %4475, %4471
  %4481 = add i64 %4422, 5
  %4482 = icmp ult i64 %4481, %26
  %4483 = and i1 %4430, %4482
  br i1 %4483, label %4484, label %4489

4484:                                             ; preds = %4480
  %4485 = add i64 %4429, 5
  %4486 = extractelement <8 x bfloat> %4427, i64 5
  %4487 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4488 = getelementptr inbounds nuw bfloat, ptr %4487, i64 %4485
  store bfloat %4486, ptr %4488, align 2
  br label %4489

4489:                                             ; preds = %4484, %4480
  %4490 = add i64 %4422, 6
  %4491 = icmp ult i64 %4490, %26
  %4492 = and i1 %4430, %4491
  br i1 %4492, label %4493, label %4498

4493:                                             ; preds = %4489
  %4494 = add i64 %4429, 6
  %4495 = extractelement <8 x bfloat> %4427, i64 6
  %4496 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4497 = getelementptr inbounds nuw bfloat, ptr %4496, i64 %4494
  store bfloat %4495, ptr %4497, align 2
  br label %4498

4498:                                             ; preds = %4493, %4489
  %4499 = add i64 %4422, 7
  %4500 = icmp ult i64 %4499, %26
  %4501 = and i1 %4430, %4500
  br i1 %4501, label %4502, label %4507

4502:                                             ; preds = %4498
  %4503 = add i64 %4429, 7
  %4504 = extractelement <8 x bfloat> %4427, i64 7
  %4505 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4506 = getelementptr inbounds nuw bfloat, ptr %4505, i64 %4503
  store bfloat %4504, ptr %4506, align 2
  br label %4507

4507:                                             ; preds = %4502, %4498
  br label %4508

4508:                                             ; preds = %4434, %4507
  %4509 = urem i64 %55, 32
  %4510 = mul i64 %4509, 8
  %4511 = add i64 %4510, 256
  %4512 = udiv i64 %4511, 32
  %4513 = urem i64 %4511, 32
  %4514 = mul i64 %59, 16
  %4515 = add i64 %4514, %4512
  %4516 = udiv i64 %59, 2
  %4517 = mul i64 %4516, 4
  %4518 = add i64 %4517, 3
  %4519 = mul i64 %4518, 16
  %4520 = add i64 %4512, %4519
  %4521 = add i64 %78, %4520
  %4522 = urem i64 %59, 2
  %4523 = mul i64 %4522, 32
  %4524 = add i64 %4513, %4523
  %4525 = add i64 %79, %4524
  %4526 = mul i64 %4515, 40
  %4527 = add i64 %4526, %4513
  %4528 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4527
  %4529 = load <8 x float>, ptr addrspace(3) %4528, align 16
  %4530 = fptrunc <8 x float> %4529 to <8 x bfloat>
  %4531 = mul i64 %4521, %26
  %4532 = add i64 %4531, %4525
  %4533 = icmp ult i64 %4521, %25
  %4534 = add i64 %4525, 7
  %4535 = icmp ult i64 %4534, %26
  %4536 = and i1 %4533, %4535
  br i1 %4536, label %4537, label %4540

4537:                                             ; preds = %4508
  %4538 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4539 = getelementptr bfloat, ptr %4538, i64 %4532
  store <8 x bfloat> %4530, ptr %4539, align 2
  br label %4611

4540:                                             ; preds = %4508
  %4541 = icmp ult i64 %4525, %26
  %4542 = and i1 %4533, %4541
  br i1 %4542, label %4543, label %4547

4543:                                             ; preds = %4540
  %4544 = extractelement <8 x bfloat> %4530, i64 0
  %4545 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4546 = getelementptr inbounds nuw bfloat, ptr %4545, i64 %4532
  store bfloat %4544, ptr %4546, align 2
  br label %4547

4547:                                             ; preds = %4543, %4540
  %4548 = add i64 %4525, 1
  %4549 = icmp ult i64 %4548, %26
  %4550 = and i1 %4533, %4549
  br i1 %4550, label %4551, label %4556

4551:                                             ; preds = %4547
  %4552 = add i64 %4532, 1
  %4553 = extractelement <8 x bfloat> %4530, i64 1
  %4554 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4555 = getelementptr inbounds nuw bfloat, ptr %4554, i64 %4552
  store bfloat %4553, ptr %4555, align 2
  br label %4556

4556:                                             ; preds = %4551, %4547
  %4557 = add i64 %4525, 2
  %4558 = icmp ult i64 %4557, %26
  %4559 = and i1 %4533, %4558
  br i1 %4559, label %4560, label %4565

4560:                                             ; preds = %4556
  %4561 = add i64 %4532, 2
  %4562 = extractelement <8 x bfloat> %4530, i64 2
  %4563 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4564 = getelementptr inbounds nuw bfloat, ptr %4563, i64 %4561
  store bfloat %4562, ptr %4564, align 2
  br label %4565

4565:                                             ; preds = %4560, %4556
  %4566 = add i64 %4525, 3
  %4567 = icmp ult i64 %4566, %26
  %4568 = and i1 %4533, %4567
  br i1 %4568, label %4569, label %4574

4569:                                             ; preds = %4565
  %4570 = add i64 %4532, 3
  %4571 = extractelement <8 x bfloat> %4530, i64 3
  %4572 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4573 = getelementptr inbounds nuw bfloat, ptr %4572, i64 %4570
  store bfloat %4571, ptr %4573, align 2
  br label %4574

4574:                                             ; preds = %4569, %4565
  %4575 = add i64 %4525, 4
  %4576 = icmp ult i64 %4575, %26
  %4577 = and i1 %4533, %4576
  br i1 %4577, label %4578, label %4583

4578:                                             ; preds = %4574
  %4579 = add i64 %4532, 4
  %4580 = extractelement <8 x bfloat> %4530, i64 4
  %4581 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4582 = getelementptr inbounds nuw bfloat, ptr %4581, i64 %4579
  store bfloat %4580, ptr %4582, align 2
  br label %4583

4583:                                             ; preds = %4578, %4574
  %4584 = add i64 %4525, 5
  %4585 = icmp ult i64 %4584, %26
  %4586 = and i1 %4533, %4585
  br i1 %4586, label %4587, label %4592

4587:                                             ; preds = %4583
  %4588 = add i64 %4532, 5
  %4589 = extractelement <8 x bfloat> %4530, i64 5
  %4590 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4591 = getelementptr inbounds nuw bfloat, ptr %4590, i64 %4588
  store bfloat %4589, ptr %4591, align 2
  br label %4592

4592:                                             ; preds = %4587, %4583
  %4593 = add i64 %4525, 6
  %4594 = icmp ult i64 %4593, %26
  %4595 = and i1 %4533, %4594
  br i1 %4595, label %4596, label %4601

4596:                                             ; preds = %4592
  %4597 = add i64 %4532, 6
  %4598 = extractelement <8 x bfloat> %4530, i64 6
  %4599 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4600 = getelementptr inbounds nuw bfloat, ptr %4599, i64 %4597
  store bfloat %4598, ptr %4600, align 2
  br label %4601

4601:                                             ; preds = %4596, %4592
  %4602 = add i64 %4525, 7
  %4603 = icmp ult i64 %4602, %26
  %4604 = and i1 %4533, %4603
  br i1 %4604, label %4605, label %4610

4605:                                             ; preds = %4601
  %4606 = add i64 %4532, 7
  %4607 = extractelement <8 x bfloat> %4530, i64 7
  %4608 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4609 = getelementptr inbounds nuw bfloat, ptr %4608, i64 %4606
  store bfloat %4607, ptr %4609, align 2
  br label %4610

4610:                                             ; preds = %4605, %4601
  br label %4611

4611:                                             ; preds = %4537, %4610
  fence syncscope("wavefront") release
  call void @llvm.amdgcn.wave.barrier()
  fence syncscope("wavefront") acquire
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.expect.i1(i1, i1) #5

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.wave.barrier() #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #6

attributes #0 = { "amdgpu-flat-work-group-size"="256,256" "target-features"="-cumode" "uniform-work-group-size" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { convergent nocallback nofree nounwind willreturn }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #6 = { convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
