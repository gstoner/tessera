; ModuleID = 'benchmarks/baselines/rocm_folded_c_lds_transpose_20261002/pressure/kernel.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"
target triple = "amdgcn-amd-amdhsa"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal unnamed_addr addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal unnamed_addr addrspace(3) global [5120 x i8] undef

; Function Attrs: norecurse nounwind
define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr nofree readnone captures(none) %0, ptr nofree readonly captures(none) %1, i64 %2, i64 %3, i64 %4, ptr nofree readnone captures(none) %5, ptr nofree readonly captures(none) %6, i64 %7, i64 %8, i64 %9, ptr nofree readnone captures(none) %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr nofree readnone captures(none) %15, ptr nofree readonly captures(none) %16, i64 %17, i64 %18, i64 %19, ptr nofree readnone captures(none) %20, ptr nofree writeonly %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) local_unnamed_addr #0 !reqd_work_group_size !1 {
.lr.ph:
  %28 = addrspacecast ptr %21 to ptr addrspace(1)
  %29 = addrspacecast ptr %16 to ptr addrspace(1)
  %30 = addrspacecast ptr %11 to ptr addrspace(1)
  %31 = addrspacecast ptr %6 to ptr addrspace(1)
  %32 = addrspacecast ptr %1 to ptr addrspace(1)
  %33 = tail call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %34 = zext nneg i32 %33 to i64
  %35 = and i64 %34, 15
  %36 = and i64 %34, 192
  %37 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %38 = sext i32 %37 to i64
  %39 = add i64 %25, 255
  %40 = lshr i64 %39, 8
  %41 = add i64 %26, 63
  %42 = lshr i64 %41, 4
  %43 = and i64 %42, 1152921504606846972
  %.frozen = freeze i64 %43
  %44 = udiv i64 %38, %.frozen
  %45 = shl i64 %44, 2
  %46 = sub i64 %40, %45
  %47 = tail call i64 @llvm.umin.i64(i64 %46, i64 4)
  %48 = mul i64 %44, %.frozen
  %.decomposed = sub i64 %38, %48
  %.frozen59 = freeze i64 %47
  %49 = udiv i64 %.decomposed, %.frozen59
  %50 = mul i64 %49, %.frozen59
  %.decomposed60 = sub i64 %.decomposed, %50
  %51 = add nuw i64 %.decomposed60, %45
  %52 = shl i64 %51, 8
  %53 = shl i64 %49, 6
  %54 = and i64 %34, 32
  %55 = or disjoint i64 %52, %36
  %56 = or disjoint i64 %36, 16
  %57 = or disjoint i64 %52, %56
  %58 = or disjoint i64 %36, 32
  %59 = or disjoint i64 %52, %58
  %60 = or disjoint i64 %36, 48
  %61 = or disjoint i64 %52, %60
  %62 = or disjoint i64 %54, 16
  %63 = lshr i64 %34, 2
  %64 = shl nuw nsw i64 %34, 4
  %65 = and i64 %64, 48
  %66 = or disjoint i64 %52, %63
  %67 = mul i64 %66, %27
  %68 = mul nuw nsw i64 %63, 80
  %69 = add nuw nsw i64 %68, %65
  %70 = or disjoint i64 %63, 64
  %71 = or disjoint i64 %52, %70
  %72 = mul i64 %71, %27
  %73 = mul nuw nsw i64 %70, 80
  %74 = add nuw nsw i64 %73, %65
  %75 = or disjoint i64 %63, 128
  %76 = or disjoint i64 %52, %75
  %77 = mul i64 %76, %27
  %78 = mul nuw nsw i64 %75, 80
  %79 = add nuw nsw i64 %78, %65
  %80 = or disjoint i64 %63, 192
  %81 = or disjoint i64 %52, %80
  %82 = mul i64 %81, %27
  %83 = mul nuw nsw i64 %80, 80
  %84 = add nuw nsw i64 %83, %65
  %85 = or disjoint i64 %53, %63
  %86 = mul i64 %85, %27
  %87 = icmp ugt i64 %27, 63
  tail call void @llvm.assume(i1 %87)
  %88 = lshr i64 %27, 6
  %89 = add i64 %27, -64
  %90 = getelementptr i8, ptr addrspace(1) %32, i64 %67
  %91 = getelementptr i8, ptr addrspace(1) %90, i64 %65
  %92 = load <16 x i8>, ptr addrspace(1) %91, align 16
  %93 = getelementptr i8, ptr addrspace(1) %32, i64 %72
  %94 = getelementptr i8, ptr addrspace(1) %93, i64 %65
  %95 = load <16 x i8>, ptr addrspace(1) %94, align 16
  %96 = getelementptr i8, ptr addrspace(1) %32, i64 %77
  %97 = getelementptr i8, ptr addrspace(1) %96, i64 %65
  %98 = load <16 x i8>, ptr addrspace(1) %97, align 16
  %99 = getelementptr i8, ptr addrspace(1) %32, i64 %82
  %100 = getelementptr i8, ptr addrspace(1) %99, i64 %65
  %101 = load <16 x i8>, ptr addrspace(1) %100, align 16
  %102 = trunc nuw nsw i64 %69 to i32
  %103 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %102
  store <16 x i8> %92, ptr addrspace(3) %103, align 16
  %104 = trunc nuw nsw i64 %74 to i32
  %105 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %104
  store <16 x i8> %95, ptr addrspace(3) %105, align 16
  %106 = trunc nuw nsw i64 %79 to i32
  %107 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %106
  store <16 x i8> %98, ptr addrspace(3) %107, align 16
  %108 = trunc nuw nsw i64 %84 to i32
  %109 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %108
  store <16 x i8> %101, ptr addrspace(3) %109, align 16
  %110 = getelementptr i8, ptr addrspace(1) %31, i64 %86
  %111 = getelementptr i8, ptr addrspace(1) %110, i64 %65
  %112 = load <16 x i8>, ptr addrspace(1) %111, align 16
  %113 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %102
  store <16 x i8> %112, ptr addrspace(3) %113, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %114 = lshr i64 %34, 1
  %115 = and i64 %114, 8
  %116 = and i64 %34, 207
  %117 = mul nuw nsw i64 %116, 80
  %118 = or disjoint i64 %115, %117
  %119 = trunc nuw nsw i64 %118 to i32
  %120 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %119
  %121 = or disjoint i64 %56, %35
  %122 = mul nuw nsw i64 %121, 80
  %123 = or disjoint i64 %122, %115
  %124 = trunc nuw nsw i64 %123 to i32
  %125 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %124
  %126 = or disjoint i64 %58, %35
  %127 = mul nuw nsw i64 %126, 80
  %128 = or disjoint i64 %127, %115
  %129 = trunc nuw nsw i64 %128 to i32
  %130 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %129
  %131 = or disjoint i64 %60, %35
  %132 = mul nuw nsw i64 %131, 80
  %133 = or disjoint i64 %132, %115
  %134 = trunc nuw nsw i64 %133 to i32
  %135 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %134
  %136 = and i64 %34, 47
  %137 = mul nuw nsw i64 %136, 80
  %138 = or disjoint i64 %115, %137
  %139 = trunc nuw nsw i64 %138 to i32
  %140 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %139
  %141 = or disjoint i64 %62, %35
  %142 = mul nuw nsw i64 %141, 80
  %143 = or disjoint i64 %142, %115
  %144 = trunc nuw nsw i64 %143 to i32
  %145 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %144
  %146 = or disjoint i64 %115, 16
  %147 = add nuw nsw i64 %146, %117
  %148 = trunc nuw nsw i64 %147 to i32
  %149 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %148
  %150 = add nuw nsw i64 %122, %146
  %151 = trunc nuw nsw i64 %150 to i32
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %151
  %153 = add nuw nsw i64 %127, %146
  %154 = trunc nuw nsw i64 %153 to i32
  %155 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %154
  %156 = add nuw nsw i64 %132, %146
  %157 = trunc nuw nsw i64 %156 to i32
  %158 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %157
  %159 = add nuw nsw i64 %146, %137
  %160 = trunc nuw nsw i64 %159 to i32
  %161 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %160
  %162 = add nuw nsw i64 %142, %146
  %163 = trunc nuw nsw i64 %162 to i32
  %164 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %163
  %165 = or disjoint i64 %115, 32
  %166 = add nuw nsw i64 %165, %117
  %167 = trunc nuw nsw i64 %166 to i32
  %168 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %167
  %169 = add nuw nsw i64 %122, %165
  %170 = trunc nuw nsw i64 %169 to i32
  %171 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %170
  %172 = add nuw nsw i64 %127, %165
  %173 = trunc nuw nsw i64 %172 to i32
  %174 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %173
  %175 = add nuw nsw i64 %132, %165
  %176 = trunc nuw nsw i64 %175 to i32
  %177 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %176
  %178 = add nuw nsw i64 %165, %137
  %179 = trunc nuw nsw i64 %178 to i32
  %180 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %179
  %181 = add nuw nsw i64 %142, %165
  %182 = trunc nuw nsw i64 %181 to i32
  %183 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %182
  %184 = or disjoint i64 %115, 48
  %185 = add nuw nsw i64 %184, %117
  %186 = trunc nuw nsw i64 %185 to i32
  %187 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %186
  %188 = add nuw nsw i64 %122, %184
  %189 = trunc nuw nsw i64 %188 to i32
  %190 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %189
  %191 = add nuw nsw i64 %127, %184
  %192 = trunc nuw nsw i64 %191 to i32
  %193 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %192
  %194 = add nuw nsw i64 %132, %184
  %195 = trunc nuw nsw i64 %194 to i32
  %196 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %195
  %197 = add nuw nsw i64 %184, %137
  %198 = trunc nuw nsw i64 %197 to i32
  %199 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %198
  %200 = add nuw nsw i64 %142, %184
  %201 = trunc nuw nsw i64 %200 to i32
  %202 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %201
  br label %203

203:                                              ; preds = %.lr.ph, %203
  %204 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %281, %203 ]
  %205 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %280, %203 ]
  %206 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %279, %203 ]
  %207 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %278, %203 ]
  %208 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %277, %203 ]
  %209 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %276, %203 ]
  %210 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %275, %203 ]
  %211 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %274, %203 ]
  %212 = phi i64 [ 0, %.lr.ph ], [ %282, %203 ]
  %213 = shl i64 %212, 6
  %214 = add nuw i64 %213, 64
  %215 = tail call i64 @llvm.umin.i64(i64 %214, i64 %89)
  %216 = getelementptr i8, ptr addrspace(1) %91, i64 %215
  %217 = load <16 x i8>, ptr addrspace(1) %216, align 16
  %218 = getelementptr i8, ptr addrspace(1) %94, i64 %215
  %219 = load <16 x i8>, ptr addrspace(1) %218, align 16
  %220 = getelementptr i8, ptr addrspace(1) %97, i64 %215
  %221 = load <16 x i8>, ptr addrspace(1) %220, align 16
  %222 = getelementptr i8, ptr addrspace(1) %100, i64 %215
  %223 = load <16 x i8>, ptr addrspace(1) %222, align 16
  %224 = getelementptr i8, ptr addrspace(1) %111, i64 %215
  %225 = load <16 x i8>, ptr addrspace(1) %224, align 16
  %226 = load <2 x i32>, ptr addrspace(3) %120, align 8
  %227 = load <2 x i32>, ptr addrspace(3) %125, align 8
  %228 = load <2 x i32>, ptr addrspace(3) %130, align 8
  %229 = load <2 x i32>, ptr addrspace(3) %135, align 8
  %230 = load <2 x i32>, ptr addrspace(3) %140, align 8
  %231 = load <2 x i32>, ptr addrspace(3) %145, align 8
  %232 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %226, <2 x i32> %230, <8 x float> %211)
  %233 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %226, <2 x i32> %231, <8 x float> %210)
  %234 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %230, <8 x float> %209)
  %235 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %231, <8 x float> %208)
  %236 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %230, <8 x float> %207)
  %237 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %231, <8 x float> %206)
  %238 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %230, <8 x float> %205)
  %239 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %231, <8 x float> %204)
  %240 = load <2 x i32>, ptr addrspace(3) %149, align 8
  %241 = load <2 x i32>, ptr addrspace(3) %152, align 8
  %242 = load <2 x i32>, ptr addrspace(3) %155, align 8
  %243 = load <2 x i32>, ptr addrspace(3) %158, align 8
  %244 = load <2 x i32>, ptr addrspace(3) %161, align 8
  %245 = load <2 x i32>, ptr addrspace(3) %164, align 8
  %246 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %240, <2 x i32> %244, <8 x float> %232)
  %247 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %240, <2 x i32> %245, <8 x float> %233)
  %248 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %244, <8 x float> %234)
  %249 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %245, <8 x float> %235)
  %250 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %244, <8 x float> %236)
  %251 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %245, <8 x float> %237)
  %252 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %244, <8 x float> %238)
  %253 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %245, <8 x float> %239)
  %254 = load <2 x i32>, ptr addrspace(3) %168, align 8
  %255 = load <2 x i32>, ptr addrspace(3) %171, align 8
  %256 = load <2 x i32>, ptr addrspace(3) %174, align 8
  %257 = load <2 x i32>, ptr addrspace(3) %177, align 8
  %258 = load <2 x i32>, ptr addrspace(3) %180, align 8
  %259 = load <2 x i32>, ptr addrspace(3) %183, align 8
  %260 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %254, <2 x i32> %258, <8 x float> %246)
  %261 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %254, <2 x i32> %259, <8 x float> %247)
  %262 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %258, <8 x float> %248)
  %263 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %259, <8 x float> %249)
  %264 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %258, <8 x float> %250)
  %265 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %259, <8 x float> %251)
  %266 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %258, <8 x float> %252)
  %267 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %259, <8 x float> %253)
  %268 = load <2 x i32>, ptr addrspace(3) %187, align 8
  %269 = load <2 x i32>, ptr addrspace(3) %190, align 8
  %270 = load <2 x i32>, ptr addrspace(3) %193, align 8
  %271 = load <2 x i32>, ptr addrspace(3) %196, align 8
  %272 = load <2 x i32>, ptr addrspace(3) %199, align 8
  %273 = load <2 x i32>, ptr addrspace(3) %202, align 8
  %274 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %268, <2 x i32> %272, <8 x float> %260)
  %275 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %268, <2 x i32> %273, <8 x float> %261)
  %276 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %272, <8 x float> %262)
  %277 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %273, <8 x float> %263)
  %278 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %272, <8 x float> %264)
  %279 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %273, <8 x float> %265)
  %280 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %272, <8 x float> %266)
  %281 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %273, <8 x float> %267)
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  store <16 x i8> %217, ptr addrspace(3) %103, align 16
  store <16 x i8> %219, ptr addrspace(3) %105, align 16
  store <16 x i8> %221, ptr addrspace(3) %107, align 16
  store <16 x i8> %223, ptr addrspace(3) %109, align 16
  store <16 x i8> %225, ptr addrspace(3) %113, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %282 = add nuw nsw i64 %212, 1
  %exitcond.not = icmp eq i64 %282, %88
  br i1 %exitcond.not, label %._crit_edge, label %203

._crit_edge:                                      ; preds = %203
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %283 = or disjoint i64 %55, %115
  %284 = or disjoint i64 %53, %35
  %285 = or disjoint i64 %284, %54
  %286 = or disjoint i64 %283, 7
  %287 = icmp ult i64 %285, %26
  %288 = icmp ult i64 %286, %25
  %289 = and i1 %287, %288
  %290 = ptrtoint ptr %11 to i64
  %291 = and i64 %290, 15
  %292 = icmp eq i64 %291, 0
  %293 = and i1 %292, %289
  br i1 %293, label %294, label %300

294:                                              ; preds = %._crit_edge
  %295 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %283
  %296 = load <4 x float>, ptr addrspace(1) %295, align 16
  %297 = getelementptr i8, ptr addrspace(1) %295, i64 16
  %298 = load <4 x float>, ptr addrspace(1) %297, align 16
  %299 = shufflevector <4 x float> %296, <4 x float> %298, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %347

300:                                              ; preds = %._crit_edge
  %301 = icmp slt i64 %283, %25
  %302 = select i1 %301, i64 %283, i64 0
  %303 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %302
  %304 = load float, ptr addrspace(1) %303, align 4, !amdgpu.noclobber !3
  %305 = insertelement <8 x float> poison, float %304, i64 0
  %306 = or disjoint i64 %283, 1
  %307 = icmp slt i64 %306, %25
  %308 = select i1 %307, i64 %306, i64 0
  %309 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %308
  %310 = load float, ptr addrspace(1) %309, align 4, !amdgpu.noclobber !3
  %311 = insertelement <8 x float> %305, float %310, i64 1
  %312 = or disjoint i64 %283, 2
  %313 = icmp slt i64 %312, %25
  %314 = select i1 %313, i64 %312, i64 0
  %315 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %314
  %316 = load float, ptr addrspace(1) %315, align 4, !amdgpu.noclobber !3
  %317 = insertelement <8 x float> %311, float %316, i64 2
  %318 = or disjoint i64 %283, 3
  %319 = icmp slt i64 %318, %25
  %320 = select i1 %319, i64 %318, i64 0
  %321 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %320
  %322 = load float, ptr addrspace(1) %321, align 4, !amdgpu.noclobber !3
  %323 = insertelement <8 x float> %317, float %322, i64 3
  %324 = or disjoint i64 %283, 4
  %325 = icmp slt i64 %324, %25
  %326 = select i1 %325, i64 %324, i64 0
  %327 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %326
  %328 = load float, ptr addrspace(1) %327, align 4, !amdgpu.noclobber !3
  %329 = insertelement <8 x float> %323, float %328, i64 4
  %330 = or disjoint i64 %283, 5
  %331 = icmp slt i64 %330, %25
  %332 = select i1 %331, i64 %330, i64 0
  %333 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %332
  %334 = load float, ptr addrspace(1) %333, align 4, !amdgpu.noclobber !3
  %335 = insertelement <8 x float> %329, float %334, i64 5
  %336 = or disjoint i64 %283, 6
  %337 = icmp slt i64 %336, %25
  %338 = select i1 %337, i64 %336, i64 0
  %339 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %338
  %340 = load float, ptr addrspace(1) %339, align 4, !amdgpu.noclobber !3
  %341 = insertelement <8 x float> %335, float %340, i64 6
  %342 = icmp slt i64 %286, %25
  %343 = select i1 %342, i64 %286, i64 0
  %344 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %343
  %345 = load float, ptr addrspace(1) %344, align 4, !amdgpu.noclobber !3
  %346 = insertelement <8 x float> %341, float %345, i64 7
  br label %347

347:                                              ; preds = %294, %300
  %348 = phi <8 x float> [ %346, %300 ], [ %299, %294 ]
  %349 = icmp slt i64 %285, %26
  %350 = select i1 %349, i64 %285, i64 0
  %351 = extractelement <8 x float> %348, i64 0
  %352 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %350
  %353 = load i8, ptr addrspace(1) %352, align 1
  %354 = zext i8 %353 to i32
  %355 = shl nuw nsw i32 %354, 23
  %356 = bitcast i32 %355 to float
  %357 = fmul float %351, %356
  %358 = extractelement <8 x float> %274, i64 0
  %359 = fmul float %358, %357
  %360 = tail call i1 @llvm.is.fpclass.f32(float %357, /* (sub norm) */ i32 408)
  br i1 %360, label %373, label %361, !prof !4

361:                                              ; preds = %347
  %362 = fpext float %358 to double
  %363 = fpext nnan float %356 to double
  %364 = fpext float %351 to double
  %365 = fmul double %362, %363
  %366 = fmul double %365, %364
  %367 = fptrunc double %366 to float
  %368 = fcmp oeq float %358, 0.000000e+00
  %369 = tail call float @llvm.fabs.f32(float %351)
  %370 = fcmp one float %369, +inf
  %371 = and i1 %368, %370
  %372 = select i1 %371, float 0.000000e+00, float %367
  br label %373

373:                                              ; preds = %361, %347
  %374 = phi float [ %372, %361 ], [ %359, %347 ]
  %375 = extractelement <8 x float> %348, i64 1
  %376 = fmul float %375, %356
  %377 = extractelement <8 x float> %274, i64 1
  %378 = fmul float %377, %376
  %379 = tail call i1 @llvm.is.fpclass.f32(float %376, /* (sub norm) */ i32 408)
  br i1 %379, label %392, label %380, !prof !4

380:                                              ; preds = %373
  %381 = fpext float %377 to double
  %382 = fpext nnan float %356 to double
  %383 = fpext float %375 to double
  %384 = fmul double %381, %382
  %385 = fmul double %384, %383
  %386 = fptrunc double %385 to float
  %387 = fcmp oeq float %377, 0.000000e+00
  %388 = tail call float @llvm.fabs.f32(float %375)
  %389 = fcmp one float %388, +inf
  %390 = and i1 %387, %389
  %391 = select i1 %390, float 0.000000e+00, float %386
  br label %392

392:                                              ; preds = %380, %373
  %393 = phi float [ %391, %380 ], [ %378, %373 ]
  %394 = extractelement <8 x float> %348, i64 2
  %395 = fmul float %394, %356
  %396 = extractelement <8 x float> %274, i64 2
  %397 = fmul float %396, %395
  %398 = tail call i1 @llvm.is.fpclass.f32(float %395, /* (sub norm) */ i32 408)
  br i1 %398, label %411, label %399, !prof !4

399:                                              ; preds = %392
  %400 = fpext float %396 to double
  %401 = fpext nnan float %356 to double
  %402 = fpext float %394 to double
  %403 = fmul double %400, %401
  %404 = fmul double %403, %402
  %405 = fptrunc double %404 to float
  %406 = fcmp oeq float %396, 0.000000e+00
  %407 = tail call float @llvm.fabs.f32(float %394)
  %408 = fcmp one float %407, +inf
  %409 = and i1 %406, %408
  %410 = select i1 %409, float 0.000000e+00, float %405
  br label %411

411:                                              ; preds = %399, %392
  %412 = phi float [ %410, %399 ], [ %397, %392 ]
  %413 = extractelement <8 x float> %348, i64 3
  %414 = fmul float %413, %356
  %415 = extractelement <8 x float> %274, i64 3
  %416 = fmul float %415, %414
  %417 = tail call i1 @llvm.is.fpclass.f32(float %414, /* (sub norm) */ i32 408)
  br i1 %417, label %430, label %418, !prof !4

418:                                              ; preds = %411
  %419 = fpext float %415 to double
  %420 = fpext nnan float %356 to double
  %421 = fpext float %413 to double
  %422 = fmul double %419, %420
  %423 = fmul double %422, %421
  %424 = fptrunc double %423 to float
  %425 = fcmp oeq float %415, 0.000000e+00
  %426 = tail call float @llvm.fabs.f32(float %413)
  %427 = fcmp one float %426, +inf
  %428 = and i1 %425, %427
  %429 = select i1 %428, float 0.000000e+00, float %424
  br label %430

430:                                              ; preds = %418, %411
  %431 = phi float [ %429, %418 ], [ %416, %411 ]
  %432 = extractelement <8 x float> %348, i64 4
  %433 = fmul float %432, %356
  %434 = extractelement <8 x float> %274, i64 4
  %435 = fmul float %434, %433
  %436 = tail call i1 @llvm.is.fpclass.f32(float %433, /* (sub norm) */ i32 408)
  br i1 %436, label %449, label %437, !prof !4

437:                                              ; preds = %430
  %438 = fpext float %434 to double
  %439 = fpext nnan float %356 to double
  %440 = fpext float %432 to double
  %441 = fmul double %438, %439
  %442 = fmul double %441, %440
  %443 = fptrunc double %442 to float
  %444 = fcmp oeq float %434, 0.000000e+00
  %445 = tail call float @llvm.fabs.f32(float %432)
  %446 = fcmp one float %445, +inf
  %447 = and i1 %444, %446
  %448 = select i1 %447, float 0.000000e+00, float %443
  br label %449

449:                                              ; preds = %437, %430
  %450 = phi float [ %448, %437 ], [ %435, %430 ]
  %451 = extractelement <8 x float> %348, i64 5
  %452 = fmul float %451, %356
  %453 = extractelement <8 x float> %274, i64 5
  %454 = fmul float %453, %452
  %455 = tail call i1 @llvm.is.fpclass.f32(float %452, /* (sub norm) */ i32 408)
  br i1 %455, label %468, label %456, !prof !4

456:                                              ; preds = %449
  %457 = fpext float %453 to double
  %458 = fpext nnan float %356 to double
  %459 = fpext float %451 to double
  %460 = fmul double %457, %458
  %461 = fmul double %460, %459
  %462 = fptrunc double %461 to float
  %463 = fcmp oeq float %453, 0.000000e+00
  %464 = tail call float @llvm.fabs.f32(float %451)
  %465 = fcmp one float %464, +inf
  %466 = and i1 %463, %465
  %467 = select i1 %466, float 0.000000e+00, float %462
  br label %468

468:                                              ; preds = %456, %449
  %469 = phi float [ %467, %456 ], [ %454, %449 ]
  %470 = extractelement <8 x float> %348, i64 6
  %471 = fmul float %470, %356
  %472 = extractelement <8 x float> %274, i64 6
  %473 = fmul float %472, %471
  %474 = tail call i1 @llvm.is.fpclass.f32(float %471, /* (sub norm) */ i32 408)
  br i1 %474, label %487, label %475, !prof !4

475:                                              ; preds = %468
  %476 = fpext float %472 to double
  %477 = fpext nnan float %356 to double
  %478 = fpext float %470 to double
  %479 = fmul double %476, %477
  %480 = fmul double %479, %478
  %481 = fptrunc double %480 to float
  %482 = fcmp oeq float %472, 0.000000e+00
  %483 = tail call float @llvm.fabs.f32(float %470)
  %484 = fcmp one float %483, +inf
  %485 = and i1 %482, %484
  %486 = select i1 %485, float 0.000000e+00, float %481
  br label %487

487:                                              ; preds = %475, %468
  %488 = phi float [ %486, %475 ], [ %473, %468 ]
  %489 = extractelement <8 x float> %348, i64 7
  %490 = fmul float %489, %356
  %491 = extractelement <8 x float> %274, i64 7
  %492 = fmul float %491, %490
  %493 = tail call i1 @llvm.is.fpclass.f32(float %490, /* (sub norm) */ i32 408)
  br i1 %493, label %506, label %494, !prof !4

494:                                              ; preds = %487
  %495 = fpext float %491 to double
  %496 = fpext nnan float %356 to double
  %497 = fpext float %489 to double
  %498 = fmul double %495, %496
  %499 = fmul double %498, %497
  %500 = fptrunc double %499 to float
  %501 = fcmp oeq float %491, 0.000000e+00
  %502 = tail call float @llvm.fabs.f32(float %489)
  %503 = fcmp one float %502, +inf
  %504 = and i1 %501, %503
  %505 = select i1 %504, float 0.000000e+00, float %500
  br label %506

506:                                              ; preds = %494, %487
  %507 = phi float [ %505, %494 ], [ %492, %487 ]
  %508 = lshr i64 %34, 1
  %509 = and i64 %508, 112
  %510 = or disjoint i64 %115, %509
  %511 = mul nuw nsw i64 %510, 40
  %512 = or disjoint i64 %511, %35
  %513 = trunc nuw nsw i64 %512 to i32
  %514 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %513
  store float %374, ptr addrspace(3) %514, align 4
  %515 = or disjoint i64 %115, 1
  %516 = or disjoint i64 %515, %509
  %517 = mul nuw nsw i64 %516, 40
  %518 = add nuw nsw i64 %517, %35
  %519 = trunc nuw nsw i64 %518 to i32
  %520 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %519
  store float %393, ptr addrspace(3) %520, align 4
  %521 = or disjoint i64 %115, 2
  %522 = or disjoint i64 %521, %509
  %523 = mul nuw nsw i64 %522, 40
  %524 = or disjoint i64 %523, %35
  %525 = trunc nuw nsw i64 %524 to i32
  %526 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %525
  store float %412, ptr addrspace(3) %526, align 4
  %527 = or disjoint i64 %115, 3
  %528 = or disjoint i64 %527, %509
  %529 = mul nuw nsw i64 %528, 40
  %530 = add nuw nsw i64 %529, %35
  %531 = trunc nuw nsw i64 %530 to i32
  %532 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %531
  store float %431, ptr addrspace(3) %532, align 4
  %533 = or disjoint i64 %115, 4
  %534 = or disjoint i64 %533, %509
  %535 = mul nuw nsw i64 %534, 40
  %536 = or disjoint i64 %535, %35
  %537 = trunc nuw nsw i64 %536 to i32
  %538 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %537
  store float %450, ptr addrspace(3) %538, align 4
  %539 = or disjoint i64 %115, 5
  %540 = or disjoint i64 %539, %509
  %541 = mul nuw nsw i64 %540, 40
  %542 = add nuw nsw i64 %541, %35
  %543 = trunc nuw nsw i64 %542 to i32
  %544 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %543
  store float %469, ptr addrspace(3) %544, align 4
  %545 = or disjoint i64 %115, 6
  %546 = or disjoint i64 %545, %509
  %547 = mul nuw nsw i64 %546, 40
  %548 = or disjoint i64 %547, %35
  %549 = trunc nuw nsw i64 %548 to i32
  %550 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %549
  store float %488, ptr addrspace(3) %550, align 4
  %551 = or disjoint i64 %115, 7
  %552 = or disjoint i64 %551, %509
  %553 = mul nuw nsw i64 %552, 40
  %554 = add nuw nsw i64 %553, %35
  %555 = trunc nuw nsw i64 %554 to i32
  %556 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %555
  store float %507, ptr addrspace(3) %556, align 4
  %557 = or disjoint i64 %62, %35
  %558 = or disjoint i64 %557, %53
  %559 = icmp ult i64 %558, %26
  %560 = and i1 %559, %288
  %561 = and i1 %292, %560
  br i1 %561, label %562, label %568

562:                                              ; preds = %506
  %563 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %283
  %564 = load <4 x float>, ptr addrspace(1) %563, align 16
  %565 = getelementptr i8, ptr addrspace(1) %563, i64 16
  %566 = load <4 x float>, ptr addrspace(1) %565, align 16
  %567 = shufflevector <4 x float> %564, <4 x float> %566, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %616

568:                                              ; preds = %506
  %569 = icmp slt i64 %283, %25
  %570 = select i1 %569, i64 %283, i64 0
  %571 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %570
  %572 = load float, ptr addrspace(1) %571, align 4, !amdgpu.noclobber !3
  %573 = insertelement <8 x float> poison, float %572, i64 0
  %574 = or disjoint i64 %55, %515
  %575 = icmp slt i64 %574, %25
  %576 = select i1 %575, i64 %574, i64 0
  %577 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %576
  %578 = load float, ptr addrspace(1) %577, align 4, !amdgpu.noclobber !3
  %579 = insertelement <8 x float> %573, float %578, i64 1
  %580 = or disjoint i64 %55, %521
  %581 = icmp slt i64 %580, %25
  %582 = select i1 %581, i64 %580, i64 0
  %583 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %582
  %584 = load float, ptr addrspace(1) %583, align 4, !amdgpu.noclobber !3
  %585 = insertelement <8 x float> %579, float %584, i64 2
  %586 = or disjoint i64 %55, %527
  %587 = icmp slt i64 %586, %25
  %588 = select i1 %587, i64 %586, i64 0
  %589 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %588
  %590 = load float, ptr addrspace(1) %589, align 4, !amdgpu.noclobber !3
  %591 = insertelement <8 x float> %585, float %590, i64 3
  %592 = or disjoint i64 %55, %533
  %593 = icmp slt i64 %592, %25
  %594 = select i1 %593, i64 %592, i64 0
  %595 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %594
  %596 = load float, ptr addrspace(1) %595, align 4, !amdgpu.noclobber !3
  %597 = insertelement <8 x float> %591, float %596, i64 4
  %598 = or disjoint i64 %55, %539
  %599 = icmp slt i64 %598, %25
  %600 = select i1 %599, i64 %598, i64 0
  %601 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %600
  %602 = load float, ptr addrspace(1) %601, align 4, !amdgpu.noclobber !3
  %603 = insertelement <8 x float> %597, float %602, i64 5
  %604 = or disjoint i64 %55, %545
  %605 = icmp slt i64 %604, %25
  %606 = select i1 %605, i64 %604, i64 0
  %607 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %606
  %608 = load float, ptr addrspace(1) %607, align 4, !amdgpu.noclobber !3
  %609 = insertelement <8 x float> %603, float %608, i64 6
  %610 = or disjoint i64 %55, %551
  %611 = icmp slt i64 %610, %25
  %612 = select i1 %611, i64 %610, i64 0
  %613 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %612
  %614 = load float, ptr addrspace(1) %613, align 4, !amdgpu.noclobber !3
  %615 = insertelement <8 x float> %609, float %614, i64 7
  br label %616

616:                                              ; preds = %562, %568
  %617 = phi <8 x float> [ %615, %568 ], [ %567, %562 ]
  %618 = icmp slt i64 %558, %26
  %619 = select i1 %618, i64 %558, i64 0
  %620 = extractelement <8 x float> %617, i64 0
  %621 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %619
  %622 = load i8, ptr addrspace(1) %621, align 1
  %623 = zext i8 %622 to i32
  %624 = shl nuw nsw i32 %623, 23
  %625 = bitcast i32 %624 to float
  %626 = fmul float %620, %625
  %627 = extractelement <8 x float> %275, i64 0
  %628 = fmul float %627, %626
  %629 = tail call i1 @llvm.is.fpclass.f32(float %626, /* (sub norm) */ i32 408)
  br i1 %629, label %642, label %630, !prof !4

630:                                              ; preds = %616
  %631 = fpext float %627 to double
  %632 = fpext nnan float %625 to double
  %633 = fpext float %620 to double
  %634 = fmul double %631, %632
  %635 = fmul double %634, %633
  %636 = fptrunc double %635 to float
  %637 = fcmp oeq float %627, 0.000000e+00
  %638 = tail call float @llvm.fabs.f32(float %620)
  %639 = fcmp one float %638, +inf
  %640 = and i1 %637, %639
  %641 = select i1 %640, float 0.000000e+00, float %636
  br label %642

642:                                              ; preds = %630, %616
  %643 = phi float [ %641, %630 ], [ %628, %616 ]
  %644 = extractelement <8 x float> %617, i64 1
  %645 = fmul float %644, %625
  %646 = extractelement <8 x float> %275, i64 1
  %647 = fmul float %646, %645
  %648 = tail call i1 @llvm.is.fpclass.f32(float %645, /* (sub norm) */ i32 408)
  br i1 %648, label %661, label %649, !prof !4

649:                                              ; preds = %642
  %650 = fpext float %646 to double
  %651 = fpext nnan float %625 to double
  %652 = fpext float %644 to double
  %653 = fmul double %650, %651
  %654 = fmul double %653, %652
  %655 = fptrunc double %654 to float
  %656 = fcmp oeq float %646, 0.000000e+00
  %657 = tail call float @llvm.fabs.f32(float %644)
  %658 = fcmp one float %657, +inf
  %659 = and i1 %656, %658
  %660 = select i1 %659, float 0.000000e+00, float %655
  br label %661

661:                                              ; preds = %649, %642
  %662 = phi float [ %660, %649 ], [ %647, %642 ]
  %663 = extractelement <8 x float> %617, i64 2
  %664 = fmul float %663, %625
  %665 = extractelement <8 x float> %275, i64 2
  %666 = fmul float %665, %664
  %667 = tail call i1 @llvm.is.fpclass.f32(float %664, /* (sub norm) */ i32 408)
  br i1 %667, label %680, label %668, !prof !4

668:                                              ; preds = %661
  %669 = fpext float %665 to double
  %670 = fpext nnan float %625 to double
  %671 = fpext float %663 to double
  %672 = fmul double %669, %670
  %673 = fmul double %672, %671
  %674 = fptrunc double %673 to float
  %675 = fcmp oeq float %665, 0.000000e+00
  %676 = tail call float @llvm.fabs.f32(float %663)
  %677 = fcmp one float %676, +inf
  %678 = and i1 %675, %677
  %679 = select i1 %678, float 0.000000e+00, float %674
  br label %680

680:                                              ; preds = %668, %661
  %681 = phi float [ %679, %668 ], [ %666, %661 ]
  %682 = extractelement <8 x float> %617, i64 3
  %683 = fmul float %682, %625
  %684 = extractelement <8 x float> %275, i64 3
  %685 = fmul float %684, %683
  %686 = tail call i1 @llvm.is.fpclass.f32(float %683, /* (sub norm) */ i32 408)
  br i1 %686, label %699, label %687, !prof !4

687:                                              ; preds = %680
  %688 = fpext float %684 to double
  %689 = fpext nnan float %625 to double
  %690 = fpext float %682 to double
  %691 = fmul double %688, %689
  %692 = fmul double %691, %690
  %693 = fptrunc double %692 to float
  %694 = fcmp oeq float %684, 0.000000e+00
  %695 = tail call float @llvm.fabs.f32(float %682)
  %696 = fcmp one float %695, +inf
  %697 = and i1 %694, %696
  %698 = select i1 %697, float 0.000000e+00, float %693
  br label %699

699:                                              ; preds = %687, %680
  %700 = phi float [ %698, %687 ], [ %685, %680 ]
  %701 = extractelement <8 x float> %617, i64 4
  %702 = fmul float %701, %625
  %703 = extractelement <8 x float> %275, i64 4
  %704 = fmul float %703, %702
  %705 = tail call i1 @llvm.is.fpclass.f32(float %702, /* (sub norm) */ i32 408)
  br i1 %705, label %718, label %706, !prof !4

706:                                              ; preds = %699
  %707 = fpext float %703 to double
  %708 = fpext nnan float %625 to double
  %709 = fpext float %701 to double
  %710 = fmul double %707, %708
  %711 = fmul double %710, %709
  %712 = fptrunc double %711 to float
  %713 = fcmp oeq float %703, 0.000000e+00
  %714 = tail call float @llvm.fabs.f32(float %701)
  %715 = fcmp one float %714, +inf
  %716 = and i1 %713, %715
  %717 = select i1 %716, float 0.000000e+00, float %712
  br label %718

718:                                              ; preds = %706, %699
  %719 = phi float [ %717, %706 ], [ %704, %699 ]
  %720 = extractelement <8 x float> %617, i64 5
  %721 = fmul float %720, %625
  %722 = extractelement <8 x float> %275, i64 5
  %723 = fmul float %722, %721
  %724 = tail call i1 @llvm.is.fpclass.f32(float %721, /* (sub norm) */ i32 408)
  br i1 %724, label %737, label %725, !prof !4

725:                                              ; preds = %718
  %726 = fpext float %722 to double
  %727 = fpext nnan float %625 to double
  %728 = fpext float %720 to double
  %729 = fmul double %726, %727
  %730 = fmul double %729, %728
  %731 = fptrunc double %730 to float
  %732 = fcmp oeq float %722, 0.000000e+00
  %733 = tail call float @llvm.fabs.f32(float %720)
  %734 = fcmp one float %733, +inf
  %735 = and i1 %732, %734
  %736 = select i1 %735, float 0.000000e+00, float %731
  br label %737

737:                                              ; preds = %725, %718
  %738 = phi float [ %736, %725 ], [ %723, %718 ]
  %739 = extractelement <8 x float> %617, i64 6
  %740 = fmul float %739, %625
  %741 = extractelement <8 x float> %275, i64 6
  %742 = fmul float %741, %740
  %743 = tail call i1 @llvm.is.fpclass.f32(float %740, /* (sub norm) */ i32 408)
  br i1 %743, label %756, label %744, !prof !4

744:                                              ; preds = %737
  %745 = fpext float %741 to double
  %746 = fpext nnan float %625 to double
  %747 = fpext float %739 to double
  %748 = fmul double %745, %746
  %749 = fmul double %748, %747
  %750 = fptrunc double %749 to float
  %751 = fcmp oeq float %741, 0.000000e+00
  %752 = tail call float @llvm.fabs.f32(float %739)
  %753 = fcmp one float %752, +inf
  %754 = and i1 %751, %753
  %755 = select i1 %754, float 0.000000e+00, float %750
  br label %756

756:                                              ; preds = %744, %737
  %757 = phi float [ %755, %744 ], [ %742, %737 ]
  %758 = extractelement <8 x float> %617, i64 7
  %759 = fmul float %758, %625
  %760 = extractelement <8 x float> %275, i64 7
  %761 = fmul float %760, %759
  %762 = tail call i1 @llvm.is.fpclass.f32(float %759, /* (sub norm) */ i32 408)
  br i1 %762, label %775, label %763, !prof !4

763:                                              ; preds = %756
  %764 = fpext float %760 to double
  %765 = fpext nnan float %625 to double
  %766 = fpext float %758 to double
  %767 = fmul double %764, %765
  %768 = fmul double %767, %766
  %769 = fptrunc double %768 to float
  %770 = fcmp oeq float %760, 0.000000e+00
  %771 = tail call float @llvm.fabs.f32(float %758)
  %772 = fcmp one float %771, +inf
  %773 = and i1 %770, %772
  %774 = select i1 %773, float 0.000000e+00, float %769
  br label %775

775:                                              ; preds = %763, %756
  %776 = phi float [ %774, %763 ], [ %761, %756 ]
  %777 = or disjoint i64 %35, 16
  %778 = or disjoint i64 %511, %777
  %779 = trunc nuw nsw i64 %778 to i32
  %780 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %779
  store float %643, ptr addrspace(3) %780, align 4
  %781 = add nuw nsw i64 %517, %777
  %782 = trunc nuw nsw i64 %781 to i32
  %783 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %782
  store float %662, ptr addrspace(3) %783, align 4
  %784 = add nuw nsw i64 %523, %777
  %785 = trunc nuw nsw i64 %784 to i32
  %786 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %785
  store float %681, ptr addrspace(3) %786, align 4
  %787 = add nuw nsw i64 %529, %777
  %788 = trunc nuw nsw i64 %787 to i32
  %789 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %788
  store float %700, ptr addrspace(3) %789, align 4
  %790 = or disjoint i64 %535, %777
  %791 = trunc nuw nsw i64 %790 to i32
  %792 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %791
  store float %719, ptr addrspace(3) %792, align 4
  %793 = add nuw nsw i64 %541, %777
  %794 = trunc nuw nsw i64 %793 to i32
  %795 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %794
  store float %738, ptr addrspace(3) %795, align 4
  %796 = add nuw nsw i64 %547, %777
  %797 = trunc nuw nsw i64 %796 to i32
  %798 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %797
  store float %757, ptr addrspace(3) %798, align 4
  %799 = add nuw nsw i64 %553, %777
  %800 = trunc nuw nsw i64 %799 to i32
  %801 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %800
  store float %776, ptr addrspace(3) %801, align 4
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %802 = shl nuw nsw i64 %34, 3
  %803 = and i64 %802, 24
  %804 = and i64 %63, 15
  %805 = lshr i64 %34, 1
  %806 = and i64 %805, 64
  %807 = and i64 %805, 64
  %808 = or disjoint i64 %807, %804
  %809 = or disjoint i64 %808, %52
  %810 = and i64 %508, 32
  %811 = or disjoint i64 %803, %810
  %812 = or disjoint i64 %811, %53
  %813 = mul nuw nsw i64 %63, 40
  %814 = add nuw nsw i64 %813, %803
  %815 = trunc nuw nsw i64 %814 to i32
  %816 = getelementptr [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %815
  %817 = load <8 x float>, ptr addrspace(3) %816, align 16
  %818 = fptrunc <8 x float> %817 to <8 x bfloat>
  %819 = mul i64 %809, %26
  %820 = add i64 %819, %812
  %821 = icmp ult i64 %809, %25
  %822 = or disjoint i64 %812, 7
  %823 = icmp ult i64 %822, %26
  %824 = and i1 %821, %823
  br i1 %824, label %825, label %827

825:                                              ; preds = %775
  %826 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %820
  store <8 x bfloat> %818, ptr addrspace(1) %826, align 2
  br label %881

827:                                              ; preds = %775
  %828 = icmp ult i64 %812, %26
  %829 = and i1 %821, %828
  br i1 %829, label %830, label %833

830:                                              ; preds = %827
  %831 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %820
  %832 = extractelement <8 x bfloat> %818, i64 0
  store bfloat %832, ptr addrspace(1) %831, align 2
  br label %833

833:                                              ; preds = %830, %827
  %834 = or disjoint i64 %812, 1
  %835 = icmp ult i64 %834, %26
  %836 = and i1 %821, %835
  br i1 %836, label %837, label %841

837:                                              ; preds = %833
  %838 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %820
  %839 = getelementptr i8, ptr addrspace(1) %838, i64 2
  %840 = extractelement <8 x bfloat> %818, i64 1
  store bfloat %840, ptr addrspace(1) %839, align 2
  br label %841

841:                                              ; preds = %837, %833
  %842 = or disjoint i64 %812, 2
  %843 = icmp ult i64 %842, %26
  %844 = and i1 %821, %843
  br i1 %844, label %845, label %849

845:                                              ; preds = %841
  %846 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %820
  %847 = getelementptr i8, ptr addrspace(1) %846, i64 4
  %848 = extractelement <8 x bfloat> %818, i64 2
  store bfloat %848, ptr addrspace(1) %847, align 2
  br label %849

849:                                              ; preds = %845, %841
  %850 = or disjoint i64 %812, 3
  %851 = icmp ult i64 %850, %26
  %852 = and i1 %821, %851
  br i1 %852, label %853, label %857

853:                                              ; preds = %849
  %854 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %820
  %855 = getelementptr i8, ptr addrspace(1) %854, i64 6
  %856 = extractelement <8 x bfloat> %818, i64 3
  store bfloat %856, ptr addrspace(1) %855, align 2
  br label %857

857:                                              ; preds = %853, %849
  %858 = or disjoint i64 %812, 4
  %859 = icmp ult i64 %858, %26
  %860 = and i1 %821, %859
  br i1 %860, label %861, label %865

861:                                              ; preds = %857
  %862 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %820
  %863 = getelementptr i8, ptr addrspace(1) %862, i64 8
  %864 = extractelement <8 x bfloat> %818, i64 4
  store bfloat %864, ptr addrspace(1) %863, align 2
  br label %865

865:                                              ; preds = %861, %857
  %866 = or disjoint i64 %812, 5
  %867 = icmp ult i64 %866, %26
  %868 = and i1 %821, %867
  br i1 %868, label %869, label %873

869:                                              ; preds = %865
  %870 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %820
  %871 = getelementptr i8, ptr addrspace(1) %870, i64 10
  %872 = extractelement <8 x bfloat> %818, i64 5
  store bfloat %872, ptr addrspace(1) %871, align 2
  br label %873

873:                                              ; preds = %869, %865
  %874 = or disjoint i64 %812, 6
  %875 = icmp ult i64 %874, %26
  %876 = and i1 %821, %875
  br i1 %876, label %877, label %881

877:                                              ; preds = %873
  %878 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %820
  %879 = getelementptr i8, ptr addrspace(1) %878, i64 12
  %880 = extractelement <8 x bfloat> %818, i64 6
  store bfloat %880, ptr addrspace(1) %879, align 2
  br label %881

881:                                              ; preds = %873, %877, %825
  %882 = shl nuw nsw i64 %70, 1
  %883 = and i64 %882, 192
  %884 = or disjoint i64 %883, %804
  %885 = or disjoint i64 %884, %52
  %886 = mul nuw nsw i64 %70, 40
  %887 = add nuw nsw i64 %886, %803
  %888 = trunc nuw nsw i64 %887 to i32
  %889 = getelementptr [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %888
  %890 = load <8 x float>, ptr addrspace(3) %889, align 16
  %891 = fptrunc <8 x float> %890 to <8 x bfloat>
  %892 = mul i64 %885, %26
  %893 = add i64 %892, %812
  %894 = icmp ult i64 %885, %25
  %895 = and i1 %894, %823
  br i1 %895, label %896, label %898

896:                                              ; preds = %881
  %897 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %893
  store <8 x bfloat> %891, ptr addrspace(1) %897, align 2
  br label %952

898:                                              ; preds = %881
  %899 = icmp ult i64 %812, %26
  %900 = and i1 %894, %899
  br i1 %900, label %901, label %904

901:                                              ; preds = %898
  %902 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %893
  %903 = extractelement <8 x bfloat> %891, i64 0
  store bfloat %903, ptr addrspace(1) %902, align 2
  br label %904

904:                                              ; preds = %901, %898
  %905 = or disjoint i64 %812, 1
  %906 = icmp ult i64 %905, %26
  %907 = and i1 %894, %906
  br i1 %907, label %908, label %912

908:                                              ; preds = %904
  %909 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %893
  %910 = getelementptr i8, ptr addrspace(1) %909, i64 2
  %911 = extractelement <8 x bfloat> %891, i64 1
  store bfloat %911, ptr addrspace(1) %910, align 2
  br label %912

912:                                              ; preds = %908, %904
  %913 = or disjoint i64 %812, 2
  %914 = icmp ult i64 %913, %26
  %915 = and i1 %894, %914
  br i1 %915, label %916, label %920

916:                                              ; preds = %912
  %917 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %893
  %918 = getelementptr i8, ptr addrspace(1) %917, i64 4
  %919 = extractelement <8 x bfloat> %891, i64 2
  store bfloat %919, ptr addrspace(1) %918, align 2
  br label %920

920:                                              ; preds = %916, %912
  %921 = or disjoint i64 %812, 3
  %922 = icmp ult i64 %921, %26
  %923 = and i1 %894, %922
  br i1 %923, label %924, label %928

924:                                              ; preds = %920
  %925 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %893
  %926 = getelementptr i8, ptr addrspace(1) %925, i64 6
  %927 = extractelement <8 x bfloat> %891, i64 3
  store bfloat %927, ptr addrspace(1) %926, align 2
  br label %928

928:                                              ; preds = %924, %920
  %929 = or disjoint i64 %812, 4
  %930 = icmp ult i64 %929, %26
  %931 = and i1 %894, %930
  br i1 %931, label %932, label %936

932:                                              ; preds = %928
  %933 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %893
  %934 = getelementptr i8, ptr addrspace(1) %933, i64 8
  %935 = extractelement <8 x bfloat> %891, i64 4
  store bfloat %935, ptr addrspace(1) %934, align 2
  br label %936

936:                                              ; preds = %932, %928
  %937 = or disjoint i64 %812, 5
  %938 = icmp ult i64 %937, %26
  %939 = and i1 %894, %938
  br i1 %939, label %940, label %944

940:                                              ; preds = %936
  %941 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %893
  %942 = getelementptr i8, ptr addrspace(1) %941, i64 10
  %943 = extractelement <8 x bfloat> %891, i64 5
  store bfloat %943, ptr addrspace(1) %942, align 2
  br label %944

944:                                              ; preds = %940, %936
  %945 = or disjoint i64 %812, 6
  %946 = icmp ult i64 %945, %26
  %947 = and i1 %894, %946
  br i1 %947, label %948, label %952

948:                                              ; preds = %944
  %949 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %893
  %950 = getelementptr i8, ptr addrspace(1) %949, i64 12
  %951 = extractelement <8 x bfloat> %891, i64 6
  store bfloat %951, ptr addrspace(1) %950, align 2
  br label %952

952:                                              ; preds = %944, %948, %896
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %953 = or disjoint i64 %57, %115
  %954 = or disjoint i64 %953, 7
  %955 = icmp ult i64 %954, %25
  %956 = and i1 %287, %955
  %957 = and i1 %292, %956
  br i1 %957, label %958, label %964

958:                                              ; preds = %952
  %959 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %953
  %960 = load <4 x float>, ptr addrspace(1) %959, align 16
  %961 = getelementptr i8, ptr addrspace(1) %959, i64 16
  %962 = load <4 x float>, ptr addrspace(1) %961, align 16
  %963 = shufflevector <4 x float> %960, <4 x float> %962, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1012

964:                                              ; preds = %952
  %965 = icmp slt i64 %953, %25
  %966 = select i1 %965, i64 %953, i64 0
  %967 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %966
  %968 = load float, ptr addrspace(1) %967, align 4
  %969 = insertelement <8 x float> poison, float %968, i64 0
  %970 = or disjoint i64 %57, %515
  %971 = icmp slt i64 %970, %25
  %972 = select i1 %971, i64 %970, i64 0
  %973 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %972
  %974 = load float, ptr addrspace(1) %973, align 4
  %975 = insertelement <8 x float> %969, float %974, i64 1
  %976 = or disjoint i64 %57, %521
  %977 = icmp slt i64 %976, %25
  %978 = select i1 %977, i64 %976, i64 0
  %979 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %978
  %980 = load float, ptr addrspace(1) %979, align 4
  %981 = insertelement <8 x float> %975, float %980, i64 2
  %982 = or disjoint i64 %57, %527
  %983 = icmp slt i64 %982, %25
  %984 = select i1 %983, i64 %982, i64 0
  %985 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %984
  %986 = load float, ptr addrspace(1) %985, align 4
  %987 = insertelement <8 x float> %981, float %986, i64 3
  %988 = or disjoint i64 %57, %533
  %989 = icmp slt i64 %988, %25
  %990 = select i1 %989, i64 %988, i64 0
  %991 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %990
  %992 = load float, ptr addrspace(1) %991, align 4
  %993 = insertelement <8 x float> %987, float %992, i64 4
  %994 = or disjoint i64 %57, %539
  %995 = icmp slt i64 %994, %25
  %996 = select i1 %995, i64 %994, i64 0
  %997 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %996
  %998 = load float, ptr addrspace(1) %997, align 4
  %999 = insertelement <8 x float> %993, float %998, i64 5
  %1000 = or disjoint i64 %57, %545
  %1001 = icmp slt i64 %1000, %25
  %1002 = select i1 %1001, i64 %1000, i64 0
  %1003 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1002
  %1004 = load float, ptr addrspace(1) %1003, align 4
  %1005 = insertelement <8 x float> %999, float %1004, i64 6
  %1006 = or disjoint i64 %57, %551
  %1007 = icmp slt i64 %1006, %25
  %1008 = select i1 %1007, i64 %1006, i64 0
  %1009 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1008
  %1010 = load float, ptr addrspace(1) %1009, align 4
  %1011 = insertelement <8 x float> %1005, float %1010, i64 7
  br label %1012

1012:                                             ; preds = %958, %964
  %1013 = phi <8 x float> [ %1011, %964 ], [ %963, %958 ]
  %1014 = extractelement <8 x float> %1013, i64 0
  %1015 = load i8, ptr addrspace(1) %352, align 1
  %1016 = zext i8 %1015 to i32
  %1017 = shl nuw nsw i32 %1016, 23
  %1018 = bitcast i32 %1017 to float
  %1019 = fmul float %1014, %1018
  %1020 = extractelement <8 x float> %276, i64 0
  %1021 = fmul float %1020, %1019
  %1022 = tail call i1 @llvm.is.fpclass.f32(float %1019, /* (sub norm) */ i32 408)
  br i1 %1022, label %1035, label %1023, !prof !4

1023:                                             ; preds = %1012
  %1024 = fpext float %1020 to double
  %1025 = fpext nnan float %1018 to double
  %1026 = fpext float %1014 to double
  %1027 = fmul double %1024, %1025
  %1028 = fmul double %1027, %1026
  %1029 = fptrunc double %1028 to float
  %1030 = fcmp oeq float %1020, 0.000000e+00
  %1031 = tail call float @llvm.fabs.f32(float %1014)
  %1032 = fcmp one float %1031, +inf
  %1033 = and i1 %1030, %1032
  %1034 = select i1 %1033, float 0.000000e+00, float %1029
  br label %1035

1035:                                             ; preds = %1023, %1012
  %1036 = phi float [ %1034, %1023 ], [ %1021, %1012 ]
  %1037 = extractelement <8 x float> %1013, i64 1
  %1038 = fmul float %1037, %1018
  %1039 = extractelement <8 x float> %276, i64 1
  %1040 = fmul float %1039, %1038
  %1041 = tail call i1 @llvm.is.fpclass.f32(float %1038, /* (sub norm) */ i32 408)
  br i1 %1041, label %1054, label %1042, !prof !4

1042:                                             ; preds = %1035
  %1043 = fpext float %1039 to double
  %1044 = fpext nnan float %1018 to double
  %1045 = fpext float %1037 to double
  %1046 = fmul double %1043, %1044
  %1047 = fmul double %1046, %1045
  %1048 = fptrunc double %1047 to float
  %1049 = fcmp oeq float %1039, 0.000000e+00
  %1050 = tail call float @llvm.fabs.f32(float %1037)
  %1051 = fcmp one float %1050, +inf
  %1052 = and i1 %1049, %1051
  %1053 = select i1 %1052, float 0.000000e+00, float %1048
  br label %1054

1054:                                             ; preds = %1042, %1035
  %1055 = phi float [ %1053, %1042 ], [ %1040, %1035 ]
  %1056 = extractelement <8 x float> %1013, i64 2
  %1057 = fmul float %1056, %1018
  %1058 = extractelement <8 x float> %276, i64 2
  %1059 = fmul float %1058, %1057
  %1060 = tail call i1 @llvm.is.fpclass.f32(float %1057, /* (sub norm) */ i32 408)
  br i1 %1060, label %1073, label %1061, !prof !4

1061:                                             ; preds = %1054
  %1062 = fpext float %1058 to double
  %1063 = fpext nnan float %1018 to double
  %1064 = fpext float %1056 to double
  %1065 = fmul double %1062, %1063
  %1066 = fmul double %1065, %1064
  %1067 = fptrunc double %1066 to float
  %1068 = fcmp oeq float %1058, 0.000000e+00
  %1069 = tail call float @llvm.fabs.f32(float %1056)
  %1070 = fcmp one float %1069, +inf
  %1071 = and i1 %1068, %1070
  %1072 = select i1 %1071, float 0.000000e+00, float %1067
  br label %1073

1073:                                             ; preds = %1061, %1054
  %1074 = phi float [ %1072, %1061 ], [ %1059, %1054 ]
  %1075 = extractelement <8 x float> %1013, i64 3
  %1076 = fmul float %1075, %1018
  %1077 = extractelement <8 x float> %276, i64 3
  %1078 = fmul float %1077, %1076
  %1079 = tail call i1 @llvm.is.fpclass.f32(float %1076, /* (sub norm) */ i32 408)
  br i1 %1079, label %1092, label %1080, !prof !4

1080:                                             ; preds = %1073
  %1081 = fpext float %1077 to double
  %1082 = fpext nnan float %1018 to double
  %1083 = fpext float %1075 to double
  %1084 = fmul double %1081, %1082
  %1085 = fmul double %1084, %1083
  %1086 = fptrunc double %1085 to float
  %1087 = fcmp oeq float %1077, 0.000000e+00
  %1088 = tail call float @llvm.fabs.f32(float %1075)
  %1089 = fcmp one float %1088, +inf
  %1090 = and i1 %1087, %1089
  %1091 = select i1 %1090, float 0.000000e+00, float %1086
  br label %1092

1092:                                             ; preds = %1080, %1073
  %1093 = phi float [ %1091, %1080 ], [ %1078, %1073 ]
  %1094 = extractelement <8 x float> %1013, i64 4
  %1095 = fmul float %1094, %1018
  %1096 = extractelement <8 x float> %276, i64 4
  %1097 = fmul float %1096, %1095
  %1098 = tail call i1 @llvm.is.fpclass.f32(float %1095, /* (sub norm) */ i32 408)
  br i1 %1098, label %1111, label %1099, !prof !4

1099:                                             ; preds = %1092
  %1100 = fpext float %1096 to double
  %1101 = fpext nnan float %1018 to double
  %1102 = fpext float %1094 to double
  %1103 = fmul double %1100, %1101
  %1104 = fmul double %1103, %1102
  %1105 = fptrunc double %1104 to float
  %1106 = fcmp oeq float %1096, 0.000000e+00
  %1107 = tail call float @llvm.fabs.f32(float %1094)
  %1108 = fcmp one float %1107, +inf
  %1109 = and i1 %1106, %1108
  %1110 = select i1 %1109, float 0.000000e+00, float %1105
  br label %1111

1111:                                             ; preds = %1099, %1092
  %1112 = phi float [ %1110, %1099 ], [ %1097, %1092 ]
  %1113 = extractelement <8 x float> %1013, i64 5
  %1114 = fmul float %1113, %1018
  %1115 = extractelement <8 x float> %276, i64 5
  %1116 = fmul float %1115, %1114
  %1117 = tail call i1 @llvm.is.fpclass.f32(float %1114, /* (sub norm) */ i32 408)
  br i1 %1117, label %1130, label %1118, !prof !4

1118:                                             ; preds = %1111
  %1119 = fpext float %1115 to double
  %1120 = fpext nnan float %1018 to double
  %1121 = fpext float %1113 to double
  %1122 = fmul double %1119, %1120
  %1123 = fmul double %1122, %1121
  %1124 = fptrunc double %1123 to float
  %1125 = fcmp oeq float %1115, 0.000000e+00
  %1126 = tail call float @llvm.fabs.f32(float %1113)
  %1127 = fcmp one float %1126, +inf
  %1128 = and i1 %1125, %1127
  %1129 = select i1 %1128, float 0.000000e+00, float %1124
  br label %1130

1130:                                             ; preds = %1118, %1111
  %1131 = phi float [ %1129, %1118 ], [ %1116, %1111 ]
  %1132 = extractelement <8 x float> %1013, i64 6
  %1133 = fmul float %1132, %1018
  %1134 = extractelement <8 x float> %276, i64 6
  %1135 = fmul float %1134, %1133
  %1136 = tail call i1 @llvm.is.fpclass.f32(float %1133, /* (sub norm) */ i32 408)
  br i1 %1136, label %1149, label %1137, !prof !4

1137:                                             ; preds = %1130
  %1138 = fpext float %1134 to double
  %1139 = fpext nnan float %1018 to double
  %1140 = fpext float %1132 to double
  %1141 = fmul double %1138, %1139
  %1142 = fmul double %1141, %1140
  %1143 = fptrunc double %1142 to float
  %1144 = fcmp oeq float %1134, 0.000000e+00
  %1145 = tail call float @llvm.fabs.f32(float %1132)
  %1146 = fcmp one float %1145, +inf
  %1147 = and i1 %1144, %1146
  %1148 = select i1 %1147, float 0.000000e+00, float %1143
  br label %1149

1149:                                             ; preds = %1137, %1130
  %1150 = phi float [ %1148, %1137 ], [ %1135, %1130 ]
  %1151 = extractelement <8 x float> %1013, i64 7
  %1152 = fmul float %1151, %1018
  %1153 = extractelement <8 x float> %276, i64 7
  %1154 = fmul float %1153, %1152
  %1155 = tail call i1 @llvm.is.fpclass.f32(float %1152, /* (sub norm) */ i32 408)
  br i1 %1155, label %1168, label %1156, !prof !4

1156:                                             ; preds = %1149
  %1157 = fpext float %1153 to double
  %1158 = fpext nnan float %1018 to double
  %1159 = fpext float %1151 to double
  %1160 = fmul double %1157, %1158
  %1161 = fmul double %1160, %1159
  %1162 = fptrunc double %1161 to float
  %1163 = fcmp oeq float %1153, 0.000000e+00
  %1164 = tail call float @llvm.fabs.f32(float %1151)
  %1165 = fcmp one float %1164, +inf
  %1166 = and i1 %1163, %1165
  %1167 = select i1 %1166, float 0.000000e+00, float %1162
  br label %1168

1168:                                             ; preds = %1156, %1149
  %1169 = phi float [ %1167, %1156 ], [ %1154, %1149 ]
  store float %1036, ptr addrspace(3) %514, align 4
  store float %1055, ptr addrspace(3) %520, align 4
  store float %1074, ptr addrspace(3) %526, align 4
  store float %1093, ptr addrspace(3) %532, align 4
  store float %1112, ptr addrspace(3) %538, align 4
  store float %1131, ptr addrspace(3) %544, align 4
  store float %1150, ptr addrspace(3) %550, align 4
  store float %1169, ptr addrspace(3) %556, align 4
  %1170 = and i1 %559, %955
  %1171 = and i1 %292, %1170
  br i1 %1171, label %1172, label %1178

1172:                                             ; preds = %1168
  %1173 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %953
  %1174 = load <4 x float>, ptr addrspace(1) %1173, align 16
  %1175 = getelementptr i8, ptr addrspace(1) %1173, i64 16
  %1176 = load <4 x float>, ptr addrspace(1) %1175, align 16
  %1177 = shufflevector <4 x float> %1174, <4 x float> %1176, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1226

1178:                                             ; preds = %1168
  %1179 = icmp slt i64 %953, %25
  %1180 = select i1 %1179, i64 %953, i64 0
  %1181 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1180
  %1182 = load float, ptr addrspace(1) %1181, align 4
  %1183 = insertelement <8 x float> poison, float %1182, i64 0
  %1184 = or disjoint i64 %57, %515
  %1185 = icmp slt i64 %1184, %25
  %1186 = select i1 %1185, i64 %1184, i64 0
  %1187 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1186
  %1188 = load float, ptr addrspace(1) %1187, align 4
  %1189 = insertelement <8 x float> %1183, float %1188, i64 1
  %1190 = or disjoint i64 %57, %521
  %1191 = icmp slt i64 %1190, %25
  %1192 = select i1 %1191, i64 %1190, i64 0
  %1193 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1192
  %1194 = load float, ptr addrspace(1) %1193, align 4
  %1195 = insertelement <8 x float> %1189, float %1194, i64 2
  %1196 = or disjoint i64 %57, %527
  %1197 = icmp slt i64 %1196, %25
  %1198 = select i1 %1197, i64 %1196, i64 0
  %1199 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1198
  %1200 = load float, ptr addrspace(1) %1199, align 4
  %1201 = insertelement <8 x float> %1195, float %1200, i64 3
  %1202 = or disjoint i64 %57, %533
  %1203 = icmp slt i64 %1202, %25
  %1204 = select i1 %1203, i64 %1202, i64 0
  %1205 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1204
  %1206 = load float, ptr addrspace(1) %1205, align 4
  %1207 = insertelement <8 x float> %1201, float %1206, i64 4
  %1208 = or disjoint i64 %57, %539
  %1209 = icmp slt i64 %1208, %25
  %1210 = select i1 %1209, i64 %1208, i64 0
  %1211 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1210
  %1212 = load float, ptr addrspace(1) %1211, align 4
  %1213 = insertelement <8 x float> %1207, float %1212, i64 5
  %1214 = or disjoint i64 %57, %545
  %1215 = icmp slt i64 %1214, %25
  %1216 = select i1 %1215, i64 %1214, i64 0
  %1217 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1216
  %1218 = load float, ptr addrspace(1) %1217, align 4
  %1219 = insertelement <8 x float> %1213, float %1218, i64 6
  %1220 = or disjoint i64 %57, %551
  %1221 = icmp slt i64 %1220, %25
  %1222 = select i1 %1221, i64 %1220, i64 0
  %1223 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1222
  %1224 = load float, ptr addrspace(1) %1223, align 4
  %1225 = insertelement <8 x float> %1219, float %1224, i64 7
  br label %1226

1226:                                             ; preds = %1172, %1178
  %1227 = phi <8 x float> [ %1225, %1178 ], [ %1177, %1172 ]
  %1228 = extractelement <8 x float> %1227, i64 0
  %1229 = load i8, ptr addrspace(1) %621, align 1
  %1230 = zext i8 %1229 to i32
  %1231 = shl nuw nsw i32 %1230, 23
  %1232 = bitcast i32 %1231 to float
  %1233 = fmul float %1228, %1232
  %1234 = extractelement <8 x float> %277, i64 0
  %1235 = fmul float %1234, %1233
  %1236 = tail call i1 @llvm.is.fpclass.f32(float %1233, /* (sub norm) */ i32 408)
  br i1 %1236, label %1249, label %1237, !prof !4

1237:                                             ; preds = %1226
  %1238 = fpext float %1234 to double
  %1239 = fpext nnan float %1232 to double
  %1240 = fpext float %1228 to double
  %1241 = fmul double %1238, %1239
  %1242 = fmul double %1241, %1240
  %1243 = fptrunc double %1242 to float
  %1244 = fcmp oeq float %1234, 0.000000e+00
  %1245 = tail call float @llvm.fabs.f32(float %1228)
  %1246 = fcmp one float %1245, +inf
  %1247 = and i1 %1244, %1246
  %1248 = select i1 %1247, float 0.000000e+00, float %1243
  br label %1249

1249:                                             ; preds = %1237, %1226
  %1250 = phi float [ %1248, %1237 ], [ %1235, %1226 ]
  %1251 = extractelement <8 x float> %1227, i64 1
  %1252 = fmul float %1251, %1232
  %1253 = extractelement <8 x float> %277, i64 1
  %1254 = fmul float %1253, %1252
  %1255 = tail call i1 @llvm.is.fpclass.f32(float %1252, /* (sub norm) */ i32 408)
  br i1 %1255, label %1268, label %1256, !prof !4

1256:                                             ; preds = %1249
  %1257 = fpext float %1253 to double
  %1258 = fpext nnan float %1232 to double
  %1259 = fpext float %1251 to double
  %1260 = fmul double %1257, %1258
  %1261 = fmul double %1260, %1259
  %1262 = fptrunc double %1261 to float
  %1263 = fcmp oeq float %1253, 0.000000e+00
  %1264 = tail call float @llvm.fabs.f32(float %1251)
  %1265 = fcmp one float %1264, +inf
  %1266 = and i1 %1263, %1265
  %1267 = select i1 %1266, float 0.000000e+00, float %1262
  br label %1268

1268:                                             ; preds = %1256, %1249
  %1269 = phi float [ %1267, %1256 ], [ %1254, %1249 ]
  %1270 = extractelement <8 x float> %1227, i64 2
  %1271 = fmul float %1270, %1232
  %1272 = extractelement <8 x float> %277, i64 2
  %1273 = fmul float %1272, %1271
  %1274 = tail call i1 @llvm.is.fpclass.f32(float %1271, /* (sub norm) */ i32 408)
  br i1 %1274, label %1287, label %1275, !prof !4

1275:                                             ; preds = %1268
  %1276 = fpext float %1272 to double
  %1277 = fpext nnan float %1232 to double
  %1278 = fpext float %1270 to double
  %1279 = fmul double %1276, %1277
  %1280 = fmul double %1279, %1278
  %1281 = fptrunc double %1280 to float
  %1282 = fcmp oeq float %1272, 0.000000e+00
  %1283 = tail call float @llvm.fabs.f32(float %1270)
  %1284 = fcmp one float %1283, +inf
  %1285 = and i1 %1282, %1284
  %1286 = select i1 %1285, float 0.000000e+00, float %1281
  br label %1287

1287:                                             ; preds = %1275, %1268
  %1288 = phi float [ %1286, %1275 ], [ %1273, %1268 ]
  %1289 = extractelement <8 x float> %1227, i64 3
  %1290 = fmul float %1289, %1232
  %1291 = extractelement <8 x float> %277, i64 3
  %1292 = fmul float %1291, %1290
  %1293 = tail call i1 @llvm.is.fpclass.f32(float %1290, /* (sub norm) */ i32 408)
  br i1 %1293, label %1306, label %1294, !prof !4

1294:                                             ; preds = %1287
  %1295 = fpext float %1291 to double
  %1296 = fpext nnan float %1232 to double
  %1297 = fpext float %1289 to double
  %1298 = fmul double %1295, %1296
  %1299 = fmul double %1298, %1297
  %1300 = fptrunc double %1299 to float
  %1301 = fcmp oeq float %1291, 0.000000e+00
  %1302 = tail call float @llvm.fabs.f32(float %1289)
  %1303 = fcmp one float %1302, +inf
  %1304 = and i1 %1301, %1303
  %1305 = select i1 %1304, float 0.000000e+00, float %1300
  br label %1306

1306:                                             ; preds = %1294, %1287
  %1307 = phi float [ %1305, %1294 ], [ %1292, %1287 ]
  %1308 = extractelement <8 x float> %1227, i64 4
  %1309 = fmul float %1308, %1232
  %1310 = extractelement <8 x float> %277, i64 4
  %1311 = fmul float %1310, %1309
  %1312 = tail call i1 @llvm.is.fpclass.f32(float %1309, /* (sub norm) */ i32 408)
  br i1 %1312, label %1325, label %1313, !prof !4

1313:                                             ; preds = %1306
  %1314 = fpext float %1310 to double
  %1315 = fpext nnan float %1232 to double
  %1316 = fpext float %1308 to double
  %1317 = fmul double %1314, %1315
  %1318 = fmul double %1317, %1316
  %1319 = fptrunc double %1318 to float
  %1320 = fcmp oeq float %1310, 0.000000e+00
  %1321 = tail call float @llvm.fabs.f32(float %1308)
  %1322 = fcmp one float %1321, +inf
  %1323 = and i1 %1320, %1322
  %1324 = select i1 %1323, float 0.000000e+00, float %1319
  br label %1325

1325:                                             ; preds = %1313, %1306
  %1326 = phi float [ %1324, %1313 ], [ %1311, %1306 ]
  %1327 = extractelement <8 x float> %1227, i64 5
  %1328 = fmul float %1327, %1232
  %1329 = extractelement <8 x float> %277, i64 5
  %1330 = fmul float %1329, %1328
  %1331 = tail call i1 @llvm.is.fpclass.f32(float %1328, /* (sub norm) */ i32 408)
  br i1 %1331, label %1344, label %1332, !prof !4

1332:                                             ; preds = %1325
  %1333 = fpext float %1329 to double
  %1334 = fpext nnan float %1232 to double
  %1335 = fpext float %1327 to double
  %1336 = fmul double %1333, %1334
  %1337 = fmul double %1336, %1335
  %1338 = fptrunc double %1337 to float
  %1339 = fcmp oeq float %1329, 0.000000e+00
  %1340 = tail call float @llvm.fabs.f32(float %1327)
  %1341 = fcmp one float %1340, +inf
  %1342 = and i1 %1339, %1341
  %1343 = select i1 %1342, float 0.000000e+00, float %1338
  br label %1344

1344:                                             ; preds = %1332, %1325
  %1345 = phi float [ %1343, %1332 ], [ %1330, %1325 ]
  %1346 = extractelement <8 x float> %1227, i64 6
  %1347 = fmul float %1346, %1232
  %1348 = extractelement <8 x float> %277, i64 6
  %1349 = fmul float %1348, %1347
  %1350 = tail call i1 @llvm.is.fpclass.f32(float %1347, /* (sub norm) */ i32 408)
  br i1 %1350, label %1363, label %1351, !prof !4

1351:                                             ; preds = %1344
  %1352 = fpext float %1348 to double
  %1353 = fpext nnan float %1232 to double
  %1354 = fpext float %1346 to double
  %1355 = fmul double %1352, %1353
  %1356 = fmul double %1355, %1354
  %1357 = fptrunc double %1356 to float
  %1358 = fcmp oeq float %1348, 0.000000e+00
  %1359 = tail call float @llvm.fabs.f32(float %1346)
  %1360 = fcmp one float %1359, +inf
  %1361 = and i1 %1358, %1360
  %1362 = select i1 %1361, float 0.000000e+00, float %1357
  br label %1363

1363:                                             ; preds = %1351, %1344
  %1364 = phi float [ %1362, %1351 ], [ %1349, %1344 ]
  %1365 = extractelement <8 x float> %1227, i64 7
  %1366 = fmul float %1365, %1232
  %1367 = extractelement <8 x float> %277, i64 7
  %1368 = fmul float %1367, %1366
  %1369 = tail call i1 @llvm.is.fpclass.f32(float %1366, /* (sub norm) */ i32 408)
  br i1 %1369, label %1382, label %1370, !prof !4

1370:                                             ; preds = %1363
  %1371 = fpext float %1367 to double
  %1372 = fpext nnan float %1232 to double
  %1373 = fpext float %1365 to double
  %1374 = fmul double %1371, %1372
  %1375 = fmul double %1374, %1373
  %1376 = fptrunc double %1375 to float
  %1377 = fcmp oeq float %1367, 0.000000e+00
  %1378 = tail call float @llvm.fabs.f32(float %1365)
  %1379 = fcmp one float %1378, +inf
  %1380 = and i1 %1377, %1379
  %1381 = select i1 %1380, float 0.000000e+00, float %1376
  br label %1382

1382:                                             ; preds = %1370, %1363
  %1383 = phi float [ %1381, %1370 ], [ %1368, %1363 ]
  store float %1250, ptr addrspace(3) %780, align 4
  store float %1269, ptr addrspace(3) %783, align 4
  store float %1288, ptr addrspace(3) %786, align 4
  store float %1307, ptr addrspace(3) %789, align 4
  store float %1326, ptr addrspace(3) %792, align 4
  store float %1345, ptr addrspace(3) %795, align 4
  store float %1364, ptr addrspace(3) %798, align 4
  store float %1383, ptr addrspace(3) %801, align 4
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %1384 = or disjoint i64 %809, 16
  %1385 = load <8 x float>, ptr addrspace(3) %816, align 16
  %1386 = fptrunc <8 x float> %1385 to <8 x bfloat>
  %1387 = mul i64 %1384, %26
  %1388 = add i64 %1387, %812
  %1389 = icmp ult i64 %1384, %25
  %1390 = and i1 %1389, %823
  br i1 %1390, label %1391, label %1393

1391:                                             ; preds = %1382
  %1392 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1388
  store <8 x bfloat> %1386, ptr addrspace(1) %1392, align 2
  br label %1447

1393:                                             ; preds = %1382
  %1394 = icmp ult i64 %812, %26
  %1395 = and i1 %1389, %1394
  br i1 %1395, label %1396, label %1399

1396:                                             ; preds = %1393
  %1397 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1388
  %1398 = extractelement <8 x bfloat> %1386, i64 0
  store bfloat %1398, ptr addrspace(1) %1397, align 2
  br label %1399

1399:                                             ; preds = %1396, %1393
  %1400 = or disjoint i64 %812, 1
  %1401 = icmp ult i64 %1400, %26
  %1402 = and i1 %1389, %1401
  br i1 %1402, label %1403, label %1407

1403:                                             ; preds = %1399
  %1404 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1388
  %1405 = getelementptr i8, ptr addrspace(1) %1404, i64 2
  %1406 = extractelement <8 x bfloat> %1386, i64 1
  store bfloat %1406, ptr addrspace(1) %1405, align 2
  br label %1407

1407:                                             ; preds = %1403, %1399
  %1408 = or disjoint i64 %812, 2
  %1409 = icmp ult i64 %1408, %26
  %1410 = and i1 %1389, %1409
  br i1 %1410, label %1411, label %1415

1411:                                             ; preds = %1407
  %1412 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1388
  %1413 = getelementptr i8, ptr addrspace(1) %1412, i64 4
  %1414 = extractelement <8 x bfloat> %1386, i64 2
  store bfloat %1414, ptr addrspace(1) %1413, align 2
  br label %1415

1415:                                             ; preds = %1411, %1407
  %1416 = or disjoint i64 %812, 3
  %1417 = icmp ult i64 %1416, %26
  %1418 = and i1 %1389, %1417
  br i1 %1418, label %1419, label %1423

1419:                                             ; preds = %1415
  %1420 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1388
  %1421 = getelementptr i8, ptr addrspace(1) %1420, i64 6
  %1422 = extractelement <8 x bfloat> %1386, i64 3
  store bfloat %1422, ptr addrspace(1) %1421, align 2
  br label %1423

1423:                                             ; preds = %1419, %1415
  %1424 = or disjoint i64 %812, 4
  %1425 = icmp ult i64 %1424, %26
  %1426 = and i1 %1389, %1425
  br i1 %1426, label %1427, label %1431

1427:                                             ; preds = %1423
  %1428 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1388
  %1429 = getelementptr i8, ptr addrspace(1) %1428, i64 8
  %1430 = extractelement <8 x bfloat> %1386, i64 4
  store bfloat %1430, ptr addrspace(1) %1429, align 2
  br label %1431

1431:                                             ; preds = %1427, %1423
  %1432 = or disjoint i64 %812, 5
  %1433 = icmp ult i64 %1432, %26
  %1434 = and i1 %1389, %1433
  br i1 %1434, label %1435, label %1439

1435:                                             ; preds = %1431
  %1436 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1388
  %1437 = getelementptr i8, ptr addrspace(1) %1436, i64 10
  %1438 = extractelement <8 x bfloat> %1386, i64 5
  store bfloat %1438, ptr addrspace(1) %1437, align 2
  br label %1439

1439:                                             ; preds = %1435, %1431
  %1440 = or disjoint i64 %812, 6
  %1441 = icmp ult i64 %1440, %26
  %1442 = and i1 %1389, %1441
  br i1 %1442, label %1443, label %1447

1443:                                             ; preds = %1439
  %1444 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1388
  %1445 = getelementptr i8, ptr addrspace(1) %1444, i64 12
  %1446 = extractelement <8 x bfloat> %1386, i64 6
  store bfloat %1446, ptr addrspace(1) %1445, align 2
  br label %1447

1447:                                             ; preds = %1439, %1443, %1391
  %1448 = or disjoint i64 %885, 16
  %1449 = load <8 x float>, ptr addrspace(3) %889, align 16
  %1450 = fptrunc <8 x float> %1449 to <8 x bfloat>
  %1451 = mul i64 %1448, %26
  %1452 = add i64 %1451, %812
  %1453 = icmp ult i64 %1448, %25
  %1454 = and i1 %1453, %823
  br i1 %1454, label %1455, label %1457

1455:                                             ; preds = %1447
  %1456 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  store <8 x bfloat> %1450, ptr addrspace(1) %1456, align 2
  br label %1511

1457:                                             ; preds = %1447
  %1458 = icmp ult i64 %812, %26
  %1459 = and i1 %1453, %1458
  br i1 %1459, label %1460, label %1463

1460:                                             ; preds = %1457
  %1461 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1462 = extractelement <8 x bfloat> %1450, i64 0
  store bfloat %1462, ptr addrspace(1) %1461, align 2
  br label %1463

1463:                                             ; preds = %1460, %1457
  %1464 = or disjoint i64 %812, 1
  %1465 = icmp ult i64 %1464, %26
  %1466 = and i1 %1453, %1465
  br i1 %1466, label %1467, label %1471

1467:                                             ; preds = %1463
  %1468 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1469 = getelementptr i8, ptr addrspace(1) %1468, i64 2
  %1470 = extractelement <8 x bfloat> %1450, i64 1
  store bfloat %1470, ptr addrspace(1) %1469, align 2
  br label %1471

1471:                                             ; preds = %1467, %1463
  %1472 = or disjoint i64 %812, 2
  %1473 = icmp ult i64 %1472, %26
  %1474 = and i1 %1453, %1473
  br i1 %1474, label %1475, label %1479

1475:                                             ; preds = %1471
  %1476 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1477 = getelementptr i8, ptr addrspace(1) %1476, i64 4
  %1478 = extractelement <8 x bfloat> %1450, i64 2
  store bfloat %1478, ptr addrspace(1) %1477, align 2
  br label %1479

1479:                                             ; preds = %1475, %1471
  %1480 = or disjoint i64 %812, 3
  %1481 = icmp ult i64 %1480, %26
  %1482 = and i1 %1453, %1481
  br i1 %1482, label %1483, label %1487

1483:                                             ; preds = %1479
  %1484 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1485 = getelementptr i8, ptr addrspace(1) %1484, i64 6
  %1486 = extractelement <8 x bfloat> %1450, i64 3
  store bfloat %1486, ptr addrspace(1) %1485, align 2
  br label %1487

1487:                                             ; preds = %1483, %1479
  %1488 = or disjoint i64 %812, 4
  %1489 = icmp ult i64 %1488, %26
  %1490 = and i1 %1453, %1489
  br i1 %1490, label %1491, label %1495

1491:                                             ; preds = %1487
  %1492 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1493 = getelementptr i8, ptr addrspace(1) %1492, i64 8
  %1494 = extractelement <8 x bfloat> %1450, i64 4
  store bfloat %1494, ptr addrspace(1) %1493, align 2
  br label %1495

1495:                                             ; preds = %1491, %1487
  %1496 = or disjoint i64 %812, 5
  %1497 = icmp ult i64 %1496, %26
  %1498 = and i1 %1453, %1497
  br i1 %1498, label %1499, label %1503

1499:                                             ; preds = %1495
  %1500 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1501 = getelementptr i8, ptr addrspace(1) %1500, i64 10
  %1502 = extractelement <8 x bfloat> %1450, i64 5
  store bfloat %1502, ptr addrspace(1) %1501, align 2
  br label %1503

1503:                                             ; preds = %1499, %1495
  %1504 = or disjoint i64 %812, 6
  %1505 = icmp ult i64 %1504, %26
  %1506 = and i1 %1453, %1505
  br i1 %1506, label %1507, label %1511

1507:                                             ; preds = %1503
  %1508 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1509 = getelementptr i8, ptr addrspace(1) %1508, i64 12
  %1510 = extractelement <8 x bfloat> %1450, i64 6
  store bfloat %1510, ptr addrspace(1) %1509, align 2
  br label %1511

1511:                                             ; preds = %1503, %1507, %1455
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %1512 = or disjoint i64 %59, %115
  %1513 = or disjoint i64 %1512, 7
  %1514 = icmp ult i64 %1513, %25
  %1515 = and i1 %287, %1514
  %1516 = and i1 %292, %1515
  br i1 %1516, label %1517, label %1523

1517:                                             ; preds = %1511
  %1518 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1512
  %1519 = load <4 x float>, ptr addrspace(1) %1518, align 16
  %1520 = getelementptr i8, ptr addrspace(1) %1518, i64 16
  %1521 = load <4 x float>, ptr addrspace(1) %1520, align 16
  %1522 = shufflevector <4 x float> %1519, <4 x float> %1521, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1571

1523:                                             ; preds = %1511
  %1524 = icmp slt i64 %1512, %25
  %1525 = select i1 %1524, i64 %1512, i64 0
  %1526 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1525
  %1527 = load float, ptr addrspace(1) %1526, align 4
  %1528 = insertelement <8 x float> poison, float %1527, i64 0
  %1529 = or disjoint i64 %59, %515
  %1530 = icmp slt i64 %1529, %25
  %1531 = select i1 %1530, i64 %1529, i64 0
  %1532 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1531
  %1533 = load float, ptr addrspace(1) %1532, align 4
  %1534 = insertelement <8 x float> %1528, float %1533, i64 1
  %1535 = or disjoint i64 %59, %521
  %1536 = icmp slt i64 %1535, %25
  %1537 = select i1 %1536, i64 %1535, i64 0
  %1538 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1537
  %1539 = load float, ptr addrspace(1) %1538, align 4
  %1540 = insertelement <8 x float> %1534, float %1539, i64 2
  %1541 = or disjoint i64 %59, %527
  %1542 = icmp slt i64 %1541, %25
  %1543 = select i1 %1542, i64 %1541, i64 0
  %1544 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1543
  %1545 = load float, ptr addrspace(1) %1544, align 4
  %1546 = insertelement <8 x float> %1540, float %1545, i64 3
  %1547 = or disjoint i64 %59, %533
  %1548 = icmp slt i64 %1547, %25
  %1549 = select i1 %1548, i64 %1547, i64 0
  %1550 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1549
  %1551 = load float, ptr addrspace(1) %1550, align 4
  %1552 = insertelement <8 x float> %1546, float %1551, i64 4
  %1553 = or disjoint i64 %59, %539
  %1554 = icmp slt i64 %1553, %25
  %1555 = select i1 %1554, i64 %1553, i64 0
  %1556 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1555
  %1557 = load float, ptr addrspace(1) %1556, align 4
  %1558 = insertelement <8 x float> %1552, float %1557, i64 5
  %1559 = or disjoint i64 %59, %545
  %1560 = icmp slt i64 %1559, %25
  %1561 = select i1 %1560, i64 %1559, i64 0
  %1562 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1561
  %1563 = load float, ptr addrspace(1) %1562, align 4
  %1564 = insertelement <8 x float> %1558, float %1563, i64 6
  %1565 = or disjoint i64 %59, %551
  %1566 = icmp slt i64 %1565, %25
  %1567 = select i1 %1566, i64 %1565, i64 0
  %1568 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1567
  %1569 = load float, ptr addrspace(1) %1568, align 4
  %1570 = insertelement <8 x float> %1564, float %1569, i64 7
  br label %1571

1571:                                             ; preds = %1517, %1523
  %1572 = phi <8 x float> [ %1570, %1523 ], [ %1522, %1517 ]
  %1573 = extractelement <8 x float> %1572, i64 0
  %1574 = load i8, ptr addrspace(1) %352, align 1
  %1575 = zext i8 %1574 to i32
  %1576 = shl nuw nsw i32 %1575, 23
  %1577 = bitcast i32 %1576 to float
  %1578 = fmul float %1573, %1577
  %1579 = extractelement <8 x float> %278, i64 0
  %1580 = fmul float %1579, %1578
  %1581 = tail call i1 @llvm.is.fpclass.f32(float %1578, /* (sub norm) */ i32 408)
  br i1 %1581, label %1594, label %1582, !prof !4

1582:                                             ; preds = %1571
  %1583 = fpext float %1579 to double
  %1584 = fpext nnan float %1577 to double
  %1585 = fpext float %1573 to double
  %1586 = fmul double %1583, %1584
  %1587 = fmul double %1586, %1585
  %1588 = fptrunc double %1587 to float
  %1589 = fcmp oeq float %1579, 0.000000e+00
  %1590 = tail call float @llvm.fabs.f32(float %1573)
  %1591 = fcmp one float %1590, +inf
  %1592 = and i1 %1589, %1591
  %1593 = select i1 %1592, float 0.000000e+00, float %1588
  br label %1594

1594:                                             ; preds = %1582, %1571
  %1595 = phi float [ %1593, %1582 ], [ %1580, %1571 ]
  %1596 = extractelement <8 x float> %1572, i64 1
  %1597 = fmul float %1596, %1577
  %1598 = extractelement <8 x float> %278, i64 1
  %1599 = fmul float %1598, %1597
  %1600 = tail call i1 @llvm.is.fpclass.f32(float %1597, /* (sub norm) */ i32 408)
  br i1 %1600, label %1613, label %1601, !prof !4

1601:                                             ; preds = %1594
  %1602 = fpext float %1598 to double
  %1603 = fpext nnan float %1577 to double
  %1604 = fpext float %1596 to double
  %1605 = fmul double %1602, %1603
  %1606 = fmul double %1605, %1604
  %1607 = fptrunc double %1606 to float
  %1608 = fcmp oeq float %1598, 0.000000e+00
  %1609 = tail call float @llvm.fabs.f32(float %1596)
  %1610 = fcmp one float %1609, +inf
  %1611 = and i1 %1608, %1610
  %1612 = select i1 %1611, float 0.000000e+00, float %1607
  br label %1613

1613:                                             ; preds = %1601, %1594
  %1614 = phi float [ %1612, %1601 ], [ %1599, %1594 ]
  %1615 = extractelement <8 x float> %1572, i64 2
  %1616 = fmul float %1615, %1577
  %1617 = extractelement <8 x float> %278, i64 2
  %1618 = fmul float %1617, %1616
  %1619 = tail call i1 @llvm.is.fpclass.f32(float %1616, /* (sub norm) */ i32 408)
  br i1 %1619, label %1632, label %1620, !prof !4

1620:                                             ; preds = %1613
  %1621 = fpext float %1617 to double
  %1622 = fpext nnan float %1577 to double
  %1623 = fpext float %1615 to double
  %1624 = fmul double %1621, %1622
  %1625 = fmul double %1624, %1623
  %1626 = fptrunc double %1625 to float
  %1627 = fcmp oeq float %1617, 0.000000e+00
  %1628 = tail call float @llvm.fabs.f32(float %1615)
  %1629 = fcmp one float %1628, +inf
  %1630 = and i1 %1627, %1629
  %1631 = select i1 %1630, float 0.000000e+00, float %1626
  br label %1632

1632:                                             ; preds = %1620, %1613
  %1633 = phi float [ %1631, %1620 ], [ %1618, %1613 ]
  %1634 = extractelement <8 x float> %1572, i64 3
  %1635 = fmul float %1634, %1577
  %1636 = extractelement <8 x float> %278, i64 3
  %1637 = fmul float %1636, %1635
  %1638 = tail call i1 @llvm.is.fpclass.f32(float %1635, /* (sub norm) */ i32 408)
  br i1 %1638, label %1651, label %1639, !prof !4

1639:                                             ; preds = %1632
  %1640 = fpext float %1636 to double
  %1641 = fpext nnan float %1577 to double
  %1642 = fpext float %1634 to double
  %1643 = fmul double %1640, %1641
  %1644 = fmul double %1643, %1642
  %1645 = fptrunc double %1644 to float
  %1646 = fcmp oeq float %1636, 0.000000e+00
  %1647 = tail call float @llvm.fabs.f32(float %1634)
  %1648 = fcmp one float %1647, +inf
  %1649 = and i1 %1646, %1648
  %1650 = select i1 %1649, float 0.000000e+00, float %1645
  br label %1651

1651:                                             ; preds = %1639, %1632
  %1652 = phi float [ %1650, %1639 ], [ %1637, %1632 ]
  %1653 = extractelement <8 x float> %1572, i64 4
  %1654 = fmul float %1653, %1577
  %1655 = extractelement <8 x float> %278, i64 4
  %1656 = fmul float %1655, %1654
  %1657 = tail call i1 @llvm.is.fpclass.f32(float %1654, /* (sub norm) */ i32 408)
  br i1 %1657, label %1670, label %1658, !prof !4

1658:                                             ; preds = %1651
  %1659 = fpext float %1655 to double
  %1660 = fpext nnan float %1577 to double
  %1661 = fpext float %1653 to double
  %1662 = fmul double %1659, %1660
  %1663 = fmul double %1662, %1661
  %1664 = fptrunc double %1663 to float
  %1665 = fcmp oeq float %1655, 0.000000e+00
  %1666 = tail call float @llvm.fabs.f32(float %1653)
  %1667 = fcmp one float %1666, +inf
  %1668 = and i1 %1665, %1667
  %1669 = select i1 %1668, float 0.000000e+00, float %1664
  br label %1670

1670:                                             ; preds = %1658, %1651
  %1671 = phi float [ %1669, %1658 ], [ %1656, %1651 ]
  %1672 = extractelement <8 x float> %1572, i64 5
  %1673 = fmul float %1672, %1577
  %1674 = extractelement <8 x float> %278, i64 5
  %1675 = fmul float %1674, %1673
  %1676 = tail call i1 @llvm.is.fpclass.f32(float %1673, /* (sub norm) */ i32 408)
  br i1 %1676, label %1689, label %1677, !prof !4

1677:                                             ; preds = %1670
  %1678 = fpext float %1674 to double
  %1679 = fpext nnan float %1577 to double
  %1680 = fpext float %1672 to double
  %1681 = fmul double %1678, %1679
  %1682 = fmul double %1681, %1680
  %1683 = fptrunc double %1682 to float
  %1684 = fcmp oeq float %1674, 0.000000e+00
  %1685 = tail call float @llvm.fabs.f32(float %1672)
  %1686 = fcmp one float %1685, +inf
  %1687 = and i1 %1684, %1686
  %1688 = select i1 %1687, float 0.000000e+00, float %1683
  br label %1689

1689:                                             ; preds = %1677, %1670
  %1690 = phi float [ %1688, %1677 ], [ %1675, %1670 ]
  %1691 = extractelement <8 x float> %1572, i64 6
  %1692 = fmul float %1691, %1577
  %1693 = extractelement <8 x float> %278, i64 6
  %1694 = fmul float %1693, %1692
  %1695 = tail call i1 @llvm.is.fpclass.f32(float %1692, /* (sub norm) */ i32 408)
  br i1 %1695, label %1708, label %1696, !prof !4

1696:                                             ; preds = %1689
  %1697 = fpext float %1693 to double
  %1698 = fpext nnan float %1577 to double
  %1699 = fpext float %1691 to double
  %1700 = fmul double %1697, %1698
  %1701 = fmul double %1700, %1699
  %1702 = fptrunc double %1701 to float
  %1703 = fcmp oeq float %1693, 0.000000e+00
  %1704 = tail call float @llvm.fabs.f32(float %1691)
  %1705 = fcmp one float %1704, +inf
  %1706 = and i1 %1703, %1705
  %1707 = select i1 %1706, float 0.000000e+00, float %1702
  br label %1708

1708:                                             ; preds = %1696, %1689
  %1709 = phi float [ %1707, %1696 ], [ %1694, %1689 ]
  %1710 = extractelement <8 x float> %1572, i64 7
  %1711 = fmul float %1710, %1577
  %1712 = extractelement <8 x float> %278, i64 7
  %1713 = fmul float %1712, %1711
  %1714 = tail call i1 @llvm.is.fpclass.f32(float %1711, /* (sub norm) */ i32 408)
  br i1 %1714, label %1727, label %1715, !prof !4

1715:                                             ; preds = %1708
  %1716 = fpext float %1712 to double
  %1717 = fpext nnan float %1577 to double
  %1718 = fpext float %1710 to double
  %1719 = fmul double %1716, %1717
  %1720 = fmul double %1719, %1718
  %1721 = fptrunc double %1720 to float
  %1722 = fcmp oeq float %1712, 0.000000e+00
  %1723 = tail call float @llvm.fabs.f32(float %1710)
  %1724 = fcmp one float %1723, +inf
  %1725 = and i1 %1722, %1724
  %1726 = select i1 %1725, float 0.000000e+00, float %1721
  br label %1727

1727:                                             ; preds = %1715, %1708
  %1728 = phi float [ %1726, %1715 ], [ %1713, %1708 ]
  store float %1595, ptr addrspace(3) %514, align 4
  store float %1614, ptr addrspace(3) %520, align 4
  store float %1633, ptr addrspace(3) %526, align 4
  store float %1652, ptr addrspace(3) %532, align 4
  store float %1671, ptr addrspace(3) %538, align 4
  store float %1690, ptr addrspace(3) %544, align 4
  store float %1709, ptr addrspace(3) %550, align 4
  store float %1728, ptr addrspace(3) %556, align 4
  %1729 = and i1 %559, %1514
  %1730 = and i1 %292, %1729
  br i1 %1730, label %1731, label %1737

1731:                                             ; preds = %1727
  %1732 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1512
  %1733 = load <4 x float>, ptr addrspace(1) %1732, align 16
  %1734 = getelementptr i8, ptr addrspace(1) %1732, i64 16
  %1735 = load <4 x float>, ptr addrspace(1) %1734, align 16
  %1736 = shufflevector <4 x float> %1733, <4 x float> %1735, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1785

1737:                                             ; preds = %1727
  %1738 = icmp slt i64 %1512, %25
  %1739 = select i1 %1738, i64 %1512, i64 0
  %1740 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1739
  %1741 = load float, ptr addrspace(1) %1740, align 4
  %1742 = insertelement <8 x float> poison, float %1741, i64 0
  %1743 = or disjoint i64 %59, %515
  %1744 = icmp slt i64 %1743, %25
  %1745 = select i1 %1744, i64 %1743, i64 0
  %1746 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1745
  %1747 = load float, ptr addrspace(1) %1746, align 4
  %1748 = insertelement <8 x float> %1742, float %1747, i64 1
  %1749 = or disjoint i64 %59, %521
  %1750 = icmp slt i64 %1749, %25
  %1751 = select i1 %1750, i64 %1749, i64 0
  %1752 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1751
  %1753 = load float, ptr addrspace(1) %1752, align 4
  %1754 = insertelement <8 x float> %1748, float %1753, i64 2
  %1755 = or disjoint i64 %59, %527
  %1756 = icmp slt i64 %1755, %25
  %1757 = select i1 %1756, i64 %1755, i64 0
  %1758 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1757
  %1759 = load float, ptr addrspace(1) %1758, align 4
  %1760 = insertelement <8 x float> %1754, float %1759, i64 3
  %1761 = or disjoint i64 %59, %533
  %1762 = icmp slt i64 %1761, %25
  %1763 = select i1 %1762, i64 %1761, i64 0
  %1764 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1763
  %1765 = load float, ptr addrspace(1) %1764, align 4
  %1766 = insertelement <8 x float> %1760, float %1765, i64 4
  %1767 = or disjoint i64 %59, %539
  %1768 = icmp slt i64 %1767, %25
  %1769 = select i1 %1768, i64 %1767, i64 0
  %1770 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1769
  %1771 = load float, ptr addrspace(1) %1770, align 4
  %1772 = insertelement <8 x float> %1766, float %1771, i64 5
  %1773 = or disjoint i64 %59, %545
  %1774 = icmp slt i64 %1773, %25
  %1775 = select i1 %1774, i64 %1773, i64 0
  %1776 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1775
  %1777 = load float, ptr addrspace(1) %1776, align 4
  %1778 = insertelement <8 x float> %1772, float %1777, i64 6
  %1779 = or disjoint i64 %59, %551
  %1780 = icmp slt i64 %1779, %25
  %1781 = select i1 %1780, i64 %1779, i64 0
  %1782 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1781
  %1783 = load float, ptr addrspace(1) %1782, align 4
  %1784 = insertelement <8 x float> %1778, float %1783, i64 7
  br label %1785

1785:                                             ; preds = %1731, %1737
  %1786 = phi <8 x float> [ %1784, %1737 ], [ %1736, %1731 ]
  %1787 = extractelement <8 x float> %1786, i64 0
  %1788 = load i8, ptr addrspace(1) %621, align 1
  %1789 = zext i8 %1788 to i32
  %1790 = shl nuw nsw i32 %1789, 23
  %1791 = bitcast i32 %1790 to float
  %1792 = fmul float %1787, %1791
  %1793 = extractelement <8 x float> %279, i64 0
  %1794 = fmul float %1793, %1792
  %1795 = tail call i1 @llvm.is.fpclass.f32(float %1792, /* (sub norm) */ i32 408)
  br i1 %1795, label %1808, label %1796, !prof !4

1796:                                             ; preds = %1785
  %1797 = fpext float %1793 to double
  %1798 = fpext nnan float %1791 to double
  %1799 = fpext float %1787 to double
  %1800 = fmul double %1797, %1798
  %1801 = fmul double %1800, %1799
  %1802 = fptrunc double %1801 to float
  %1803 = fcmp oeq float %1793, 0.000000e+00
  %1804 = tail call float @llvm.fabs.f32(float %1787)
  %1805 = fcmp one float %1804, +inf
  %1806 = and i1 %1803, %1805
  %1807 = select i1 %1806, float 0.000000e+00, float %1802
  br label %1808

1808:                                             ; preds = %1796, %1785
  %1809 = phi float [ %1807, %1796 ], [ %1794, %1785 ]
  %1810 = extractelement <8 x float> %1786, i64 1
  %1811 = fmul float %1810, %1791
  %1812 = extractelement <8 x float> %279, i64 1
  %1813 = fmul float %1812, %1811
  %1814 = tail call i1 @llvm.is.fpclass.f32(float %1811, /* (sub norm) */ i32 408)
  br i1 %1814, label %1827, label %1815, !prof !4

1815:                                             ; preds = %1808
  %1816 = fpext float %1812 to double
  %1817 = fpext nnan float %1791 to double
  %1818 = fpext float %1810 to double
  %1819 = fmul double %1816, %1817
  %1820 = fmul double %1819, %1818
  %1821 = fptrunc double %1820 to float
  %1822 = fcmp oeq float %1812, 0.000000e+00
  %1823 = tail call float @llvm.fabs.f32(float %1810)
  %1824 = fcmp one float %1823, +inf
  %1825 = and i1 %1822, %1824
  %1826 = select i1 %1825, float 0.000000e+00, float %1821
  br label %1827

1827:                                             ; preds = %1815, %1808
  %1828 = phi float [ %1826, %1815 ], [ %1813, %1808 ]
  %1829 = extractelement <8 x float> %1786, i64 2
  %1830 = fmul float %1829, %1791
  %1831 = extractelement <8 x float> %279, i64 2
  %1832 = fmul float %1831, %1830
  %1833 = tail call i1 @llvm.is.fpclass.f32(float %1830, /* (sub norm) */ i32 408)
  br i1 %1833, label %1846, label %1834, !prof !4

1834:                                             ; preds = %1827
  %1835 = fpext float %1831 to double
  %1836 = fpext nnan float %1791 to double
  %1837 = fpext float %1829 to double
  %1838 = fmul double %1835, %1836
  %1839 = fmul double %1838, %1837
  %1840 = fptrunc double %1839 to float
  %1841 = fcmp oeq float %1831, 0.000000e+00
  %1842 = tail call float @llvm.fabs.f32(float %1829)
  %1843 = fcmp one float %1842, +inf
  %1844 = and i1 %1841, %1843
  %1845 = select i1 %1844, float 0.000000e+00, float %1840
  br label %1846

1846:                                             ; preds = %1834, %1827
  %1847 = phi float [ %1845, %1834 ], [ %1832, %1827 ]
  %1848 = extractelement <8 x float> %1786, i64 3
  %1849 = fmul float %1848, %1791
  %1850 = extractelement <8 x float> %279, i64 3
  %1851 = fmul float %1850, %1849
  %1852 = tail call i1 @llvm.is.fpclass.f32(float %1849, /* (sub norm) */ i32 408)
  br i1 %1852, label %1865, label %1853, !prof !4

1853:                                             ; preds = %1846
  %1854 = fpext float %1850 to double
  %1855 = fpext nnan float %1791 to double
  %1856 = fpext float %1848 to double
  %1857 = fmul double %1854, %1855
  %1858 = fmul double %1857, %1856
  %1859 = fptrunc double %1858 to float
  %1860 = fcmp oeq float %1850, 0.000000e+00
  %1861 = tail call float @llvm.fabs.f32(float %1848)
  %1862 = fcmp one float %1861, +inf
  %1863 = and i1 %1860, %1862
  %1864 = select i1 %1863, float 0.000000e+00, float %1859
  br label %1865

1865:                                             ; preds = %1853, %1846
  %1866 = phi float [ %1864, %1853 ], [ %1851, %1846 ]
  %1867 = extractelement <8 x float> %1786, i64 4
  %1868 = fmul float %1867, %1791
  %1869 = extractelement <8 x float> %279, i64 4
  %1870 = fmul float %1869, %1868
  %1871 = tail call i1 @llvm.is.fpclass.f32(float %1868, /* (sub norm) */ i32 408)
  br i1 %1871, label %1884, label %1872, !prof !4

1872:                                             ; preds = %1865
  %1873 = fpext float %1869 to double
  %1874 = fpext nnan float %1791 to double
  %1875 = fpext float %1867 to double
  %1876 = fmul double %1873, %1874
  %1877 = fmul double %1876, %1875
  %1878 = fptrunc double %1877 to float
  %1879 = fcmp oeq float %1869, 0.000000e+00
  %1880 = tail call float @llvm.fabs.f32(float %1867)
  %1881 = fcmp one float %1880, +inf
  %1882 = and i1 %1879, %1881
  %1883 = select i1 %1882, float 0.000000e+00, float %1878
  br label %1884

1884:                                             ; preds = %1872, %1865
  %1885 = phi float [ %1883, %1872 ], [ %1870, %1865 ]
  %1886 = extractelement <8 x float> %1786, i64 5
  %1887 = fmul float %1886, %1791
  %1888 = extractelement <8 x float> %279, i64 5
  %1889 = fmul float %1888, %1887
  %1890 = tail call i1 @llvm.is.fpclass.f32(float %1887, /* (sub norm) */ i32 408)
  br i1 %1890, label %1903, label %1891, !prof !4

1891:                                             ; preds = %1884
  %1892 = fpext float %1888 to double
  %1893 = fpext nnan float %1791 to double
  %1894 = fpext float %1886 to double
  %1895 = fmul double %1892, %1893
  %1896 = fmul double %1895, %1894
  %1897 = fptrunc double %1896 to float
  %1898 = fcmp oeq float %1888, 0.000000e+00
  %1899 = tail call float @llvm.fabs.f32(float %1886)
  %1900 = fcmp one float %1899, +inf
  %1901 = and i1 %1898, %1900
  %1902 = select i1 %1901, float 0.000000e+00, float %1897
  br label %1903

1903:                                             ; preds = %1891, %1884
  %1904 = phi float [ %1902, %1891 ], [ %1889, %1884 ]
  %1905 = extractelement <8 x float> %1786, i64 6
  %1906 = fmul float %1905, %1791
  %1907 = extractelement <8 x float> %279, i64 6
  %1908 = fmul float %1907, %1906
  %1909 = tail call i1 @llvm.is.fpclass.f32(float %1906, /* (sub norm) */ i32 408)
  br i1 %1909, label %1922, label %1910, !prof !4

1910:                                             ; preds = %1903
  %1911 = fpext float %1907 to double
  %1912 = fpext nnan float %1791 to double
  %1913 = fpext float %1905 to double
  %1914 = fmul double %1911, %1912
  %1915 = fmul double %1914, %1913
  %1916 = fptrunc double %1915 to float
  %1917 = fcmp oeq float %1907, 0.000000e+00
  %1918 = tail call float @llvm.fabs.f32(float %1905)
  %1919 = fcmp one float %1918, +inf
  %1920 = and i1 %1917, %1919
  %1921 = select i1 %1920, float 0.000000e+00, float %1916
  br label %1922

1922:                                             ; preds = %1910, %1903
  %1923 = phi float [ %1921, %1910 ], [ %1908, %1903 ]
  %1924 = extractelement <8 x float> %1786, i64 7
  %1925 = fmul float %1924, %1791
  %1926 = extractelement <8 x float> %279, i64 7
  %1927 = fmul float %1926, %1925
  %1928 = tail call i1 @llvm.is.fpclass.f32(float %1925, /* (sub norm) */ i32 408)
  br i1 %1928, label %1941, label %1929, !prof !4

1929:                                             ; preds = %1922
  %1930 = fpext float %1926 to double
  %1931 = fpext nnan float %1791 to double
  %1932 = fpext float %1924 to double
  %1933 = fmul double %1930, %1931
  %1934 = fmul double %1933, %1932
  %1935 = fptrunc double %1934 to float
  %1936 = fcmp oeq float %1926, 0.000000e+00
  %1937 = tail call float @llvm.fabs.f32(float %1924)
  %1938 = fcmp one float %1937, +inf
  %1939 = and i1 %1936, %1938
  %1940 = select i1 %1939, float 0.000000e+00, float %1935
  br label %1941

1941:                                             ; preds = %1929, %1922
  %1942 = phi float [ %1940, %1929 ], [ %1927, %1922 ]
  store float %1809, ptr addrspace(3) %780, align 4
  store float %1828, ptr addrspace(3) %783, align 4
  store float %1847, ptr addrspace(3) %786, align 4
  store float %1866, ptr addrspace(3) %789, align 4
  store float %1885, ptr addrspace(3) %792, align 4
  store float %1904, ptr addrspace(3) %795, align 4
  store float %1923, ptr addrspace(3) %798, align 4
  store float %1942, ptr addrspace(3) %801, align 4
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %1943 = or disjoint i64 %809, 32
  %1944 = load <8 x float>, ptr addrspace(3) %816, align 16
  %1945 = fptrunc <8 x float> %1944 to <8 x bfloat>
  %1946 = mul i64 %1943, %26
  %1947 = add i64 %1946, %812
  %1948 = icmp ult i64 %1943, %25
  %1949 = and i1 %1948, %823
  br i1 %1949, label %1950, label %1952

1950:                                             ; preds = %1941
  %1951 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1947
  store <8 x bfloat> %1945, ptr addrspace(1) %1951, align 2
  br label %2006

1952:                                             ; preds = %1941
  %1953 = icmp ult i64 %812, %26
  %1954 = and i1 %1948, %1953
  br i1 %1954, label %1955, label %1958

1955:                                             ; preds = %1952
  %1956 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1947
  %1957 = extractelement <8 x bfloat> %1945, i64 0
  store bfloat %1957, ptr addrspace(1) %1956, align 2
  br label %1958

1958:                                             ; preds = %1955, %1952
  %1959 = or disjoint i64 %812, 1
  %1960 = icmp ult i64 %1959, %26
  %1961 = and i1 %1948, %1960
  br i1 %1961, label %1962, label %1966

1962:                                             ; preds = %1958
  %1963 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1947
  %1964 = getelementptr i8, ptr addrspace(1) %1963, i64 2
  %1965 = extractelement <8 x bfloat> %1945, i64 1
  store bfloat %1965, ptr addrspace(1) %1964, align 2
  br label %1966

1966:                                             ; preds = %1962, %1958
  %1967 = or disjoint i64 %812, 2
  %1968 = icmp ult i64 %1967, %26
  %1969 = and i1 %1948, %1968
  br i1 %1969, label %1970, label %1974

1970:                                             ; preds = %1966
  %1971 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1947
  %1972 = getelementptr i8, ptr addrspace(1) %1971, i64 4
  %1973 = extractelement <8 x bfloat> %1945, i64 2
  store bfloat %1973, ptr addrspace(1) %1972, align 2
  br label %1974

1974:                                             ; preds = %1970, %1966
  %1975 = or disjoint i64 %812, 3
  %1976 = icmp ult i64 %1975, %26
  %1977 = and i1 %1948, %1976
  br i1 %1977, label %1978, label %1982

1978:                                             ; preds = %1974
  %1979 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1947
  %1980 = getelementptr i8, ptr addrspace(1) %1979, i64 6
  %1981 = extractelement <8 x bfloat> %1945, i64 3
  store bfloat %1981, ptr addrspace(1) %1980, align 2
  br label %1982

1982:                                             ; preds = %1978, %1974
  %1983 = or disjoint i64 %812, 4
  %1984 = icmp ult i64 %1983, %26
  %1985 = and i1 %1948, %1984
  br i1 %1985, label %1986, label %1990

1986:                                             ; preds = %1982
  %1987 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1947
  %1988 = getelementptr i8, ptr addrspace(1) %1987, i64 8
  %1989 = extractelement <8 x bfloat> %1945, i64 4
  store bfloat %1989, ptr addrspace(1) %1988, align 2
  br label %1990

1990:                                             ; preds = %1986, %1982
  %1991 = or disjoint i64 %812, 5
  %1992 = icmp ult i64 %1991, %26
  %1993 = and i1 %1948, %1992
  br i1 %1993, label %1994, label %1998

1994:                                             ; preds = %1990
  %1995 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1947
  %1996 = getelementptr i8, ptr addrspace(1) %1995, i64 10
  %1997 = extractelement <8 x bfloat> %1945, i64 5
  store bfloat %1997, ptr addrspace(1) %1996, align 2
  br label %1998

1998:                                             ; preds = %1994, %1990
  %1999 = or disjoint i64 %812, 6
  %2000 = icmp ult i64 %1999, %26
  %2001 = and i1 %1948, %2000
  br i1 %2001, label %2002, label %2006

2002:                                             ; preds = %1998
  %2003 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1947
  %2004 = getelementptr i8, ptr addrspace(1) %2003, i64 12
  %2005 = extractelement <8 x bfloat> %1945, i64 6
  store bfloat %2005, ptr addrspace(1) %2004, align 2
  br label %2006

2006:                                             ; preds = %1998, %2002, %1950
  %2007 = or disjoint i64 %885, 32
  %2008 = load <8 x float>, ptr addrspace(3) %889, align 16
  %2009 = fptrunc <8 x float> %2008 to <8 x bfloat>
  %2010 = mul i64 %2007, %26
  %2011 = add i64 %2010, %812
  %2012 = icmp ult i64 %2007, %25
  %2013 = and i1 %2012, %823
  br i1 %2013, label %2014, label %2016

2014:                                             ; preds = %2006
  %2015 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2011
  store <8 x bfloat> %2009, ptr addrspace(1) %2015, align 2
  br label %2070

2016:                                             ; preds = %2006
  %2017 = icmp ult i64 %812, %26
  %2018 = and i1 %2012, %2017
  br i1 %2018, label %2019, label %2022

2019:                                             ; preds = %2016
  %2020 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2011
  %2021 = extractelement <8 x bfloat> %2009, i64 0
  store bfloat %2021, ptr addrspace(1) %2020, align 2
  br label %2022

2022:                                             ; preds = %2019, %2016
  %2023 = or disjoint i64 %812, 1
  %2024 = icmp ult i64 %2023, %26
  %2025 = and i1 %2012, %2024
  br i1 %2025, label %2026, label %2030

2026:                                             ; preds = %2022
  %2027 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2011
  %2028 = getelementptr i8, ptr addrspace(1) %2027, i64 2
  %2029 = extractelement <8 x bfloat> %2009, i64 1
  store bfloat %2029, ptr addrspace(1) %2028, align 2
  br label %2030

2030:                                             ; preds = %2026, %2022
  %2031 = or disjoint i64 %812, 2
  %2032 = icmp ult i64 %2031, %26
  %2033 = and i1 %2012, %2032
  br i1 %2033, label %2034, label %2038

2034:                                             ; preds = %2030
  %2035 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2011
  %2036 = getelementptr i8, ptr addrspace(1) %2035, i64 4
  %2037 = extractelement <8 x bfloat> %2009, i64 2
  store bfloat %2037, ptr addrspace(1) %2036, align 2
  br label %2038

2038:                                             ; preds = %2034, %2030
  %2039 = or disjoint i64 %812, 3
  %2040 = icmp ult i64 %2039, %26
  %2041 = and i1 %2012, %2040
  br i1 %2041, label %2042, label %2046

2042:                                             ; preds = %2038
  %2043 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2011
  %2044 = getelementptr i8, ptr addrspace(1) %2043, i64 6
  %2045 = extractelement <8 x bfloat> %2009, i64 3
  store bfloat %2045, ptr addrspace(1) %2044, align 2
  br label %2046

2046:                                             ; preds = %2042, %2038
  %2047 = or disjoint i64 %812, 4
  %2048 = icmp ult i64 %2047, %26
  %2049 = and i1 %2012, %2048
  br i1 %2049, label %2050, label %2054

2050:                                             ; preds = %2046
  %2051 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2011
  %2052 = getelementptr i8, ptr addrspace(1) %2051, i64 8
  %2053 = extractelement <8 x bfloat> %2009, i64 4
  store bfloat %2053, ptr addrspace(1) %2052, align 2
  br label %2054

2054:                                             ; preds = %2050, %2046
  %2055 = or disjoint i64 %812, 5
  %2056 = icmp ult i64 %2055, %26
  %2057 = and i1 %2012, %2056
  br i1 %2057, label %2058, label %2062

2058:                                             ; preds = %2054
  %2059 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2011
  %2060 = getelementptr i8, ptr addrspace(1) %2059, i64 10
  %2061 = extractelement <8 x bfloat> %2009, i64 5
  store bfloat %2061, ptr addrspace(1) %2060, align 2
  br label %2062

2062:                                             ; preds = %2058, %2054
  %2063 = or disjoint i64 %812, 6
  %2064 = icmp ult i64 %2063, %26
  %2065 = and i1 %2012, %2064
  br i1 %2065, label %2066, label %2070

2066:                                             ; preds = %2062
  %2067 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2011
  %2068 = getelementptr i8, ptr addrspace(1) %2067, i64 12
  %2069 = extractelement <8 x bfloat> %2009, i64 6
  store bfloat %2069, ptr addrspace(1) %2068, align 2
  br label %2070

2070:                                             ; preds = %2062, %2066, %2014
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %2071 = or disjoint i64 %61, %115
  %2072 = or disjoint i64 %2071, 7
  %2073 = icmp ult i64 %2072, %25
  %2074 = and i1 %287, %2073
  %2075 = and i1 %292, %2074
  br i1 %2075, label %2076, label %2082

2076:                                             ; preds = %2070
  %2077 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %2071
  %2078 = load <4 x float>, ptr addrspace(1) %2077, align 16
  %2079 = getelementptr i8, ptr addrspace(1) %2077, i64 16
  %2080 = load <4 x float>, ptr addrspace(1) %2079, align 16
  %2081 = shufflevector <4 x float> %2078, <4 x float> %2080, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2130

2082:                                             ; preds = %2070
  %2083 = icmp slt i64 %2071, %25
  %2084 = select i1 %2083, i64 %2071, i64 0
  %2085 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2084
  %2086 = load float, ptr addrspace(1) %2085, align 4
  %2087 = insertelement <8 x float> poison, float %2086, i64 0
  %2088 = or disjoint i64 %61, %515
  %2089 = icmp slt i64 %2088, %25
  %2090 = select i1 %2089, i64 %2088, i64 0
  %2091 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2090
  %2092 = load float, ptr addrspace(1) %2091, align 4
  %2093 = insertelement <8 x float> %2087, float %2092, i64 1
  %2094 = or disjoint i64 %61, %521
  %2095 = icmp slt i64 %2094, %25
  %2096 = select i1 %2095, i64 %2094, i64 0
  %2097 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2096
  %2098 = load float, ptr addrspace(1) %2097, align 4
  %2099 = insertelement <8 x float> %2093, float %2098, i64 2
  %2100 = or disjoint i64 %61, %527
  %2101 = icmp slt i64 %2100, %25
  %2102 = select i1 %2101, i64 %2100, i64 0
  %2103 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2102
  %2104 = load float, ptr addrspace(1) %2103, align 4
  %2105 = insertelement <8 x float> %2099, float %2104, i64 3
  %2106 = or disjoint i64 %61, %533
  %2107 = icmp slt i64 %2106, %25
  %2108 = select i1 %2107, i64 %2106, i64 0
  %2109 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2108
  %2110 = load float, ptr addrspace(1) %2109, align 4
  %2111 = insertelement <8 x float> %2105, float %2110, i64 4
  %2112 = or disjoint i64 %61, %539
  %2113 = icmp slt i64 %2112, %25
  %2114 = select i1 %2113, i64 %2112, i64 0
  %2115 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2114
  %2116 = load float, ptr addrspace(1) %2115, align 4
  %2117 = insertelement <8 x float> %2111, float %2116, i64 5
  %2118 = or disjoint i64 %61, %545
  %2119 = icmp slt i64 %2118, %25
  %2120 = select i1 %2119, i64 %2118, i64 0
  %2121 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2120
  %2122 = load float, ptr addrspace(1) %2121, align 4
  %2123 = insertelement <8 x float> %2117, float %2122, i64 6
  %2124 = or disjoint i64 %61, %551
  %2125 = icmp slt i64 %2124, %25
  %2126 = select i1 %2125, i64 %2124, i64 0
  %2127 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2126
  %2128 = load float, ptr addrspace(1) %2127, align 4
  %2129 = insertelement <8 x float> %2123, float %2128, i64 7
  br label %2130

2130:                                             ; preds = %2076, %2082
  %2131 = phi <8 x float> [ %2129, %2082 ], [ %2081, %2076 ]
  %2132 = extractelement <8 x float> %2131, i64 0
  %2133 = load i8, ptr addrspace(1) %352, align 1
  %2134 = zext i8 %2133 to i32
  %2135 = shl nuw nsw i32 %2134, 23
  %2136 = bitcast i32 %2135 to float
  %2137 = fmul float %2132, %2136
  %2138 = extractelement <8 x float> %280, i64 0
  %2139 = fmul float %2138, %2137
  %2140 = tail call i1 @llvm.is.fpclass.f32(float %2137, /* (sub norm) */ i32 408)
  br i1 %2140, label %2153, label %2141, !prof !4

2141:                                             ; preds = %2130
  %2142 = fpext float %2138 to double
  %2143 = fpext nnan float %2136 to double
  %2144 = fpext float %2132 to double
  %2145 = fmul double %2142, %2143
  %2146 = fmul double %2145, %2144
  %2147 = fptrunc double %2146 to float
  %2148 = fcmp oeq float %2138, 0.000000e+00
  %2149 = tail call float @llvm.fabs.f32(float %2132)
  %2150 = fcmp one float %2149, +inf
  %2151 = and i1 %2148, %2150
  %2152 = select i1 %2151, float 0.000000e+00, float %2147
  br label %2153

2153:                                             ; preds = %2141, %2130
  %2154 = phi float [ %2152, %2141 ], [ %2139, %2130 ]
  %2155 = extractelement <8 x float> %2131, i64 1
  %2156 = fmul float %2155, %2136
  %2157 = extractelement <8 x float> %280, i64 1
  %2158 = fmul float %2157, %2156
  %2159 = tail call i1 @llvm.is.fpclass.f32(float %2156, /* (sub norm) */ i32 408)
  br i1 %2159, label %2172, label %2160, !prof !4

2160:                                             ; preds = %2153
  %2161 = fpext float %2157 to double
  %2162 = fpext nnan float %2136 to double
  %2163 = fpext float %2155 to double
  %2164 = fmul double %2161, %2162
  %2165 = fmul double %2164, %2163
  %2166 = fptrunc double %2165 to float
  %2167 = fcmp oeq float %2157, 0.000000e+00
  %2168 = tail call float @llvm.fabs.f32(float %2155)
  %2169 = fcmp one float %2168, +inf
  %2170 = and i1 %2167, %2169
  %2171 = select i1 %2170, float 0.000000e+00, float %2166
  br label %2172

2172:                                             ; preds = %2160, %2153
  %2173 = phi float [ %2171, %2160 ], [ %2158, %2153 ]
  %2174 = extractelement <8 x float> %2131, i64 2
  %2175 = fmul float %2174, %2136
  %2176 = extractelement <8 x float> %280, i64 2
  %2177 = fmul float %2176, %2175
  %2178 = tail call i1 @llvm.is.fpclass.f32(float %2175, /* (sub norm) */ i32 408)
  br i1 %2178, label %2191, label %2179, !prof !4

2179:                                             ; preds = %2172
  %2180 = fpext float %2176 to double
  %2181 = fpext nnan float %2136 to double
  %2182 = fpext float %2174 to double
  %2183 = fmul double %2180, %2181
  %2184 = fmul double %2183, %2182
  %2185 = fptrunc double %2184 to float
  %2186 = fcmp oeq float %2176, 0.000000e+00
  %2187 = tail call float @llvm.fabs.f32(float %2174)
  %2188 = fcmp one float %2187, +inf
  %2189 = and i1 %2186, %2188
  %2190 = select i1 %2189, float 0.000000e+00, float %2185
  br label %2191

2191:                                             ; preds = %2179, %2172
  %2192 = phi float [ %2190, %2179 ], [ %2177, %2172 ]
  %2193 = extractelement <8 x float> %2131, i64 3
  %2194 = fmul float %2193, %2136
  %2195 = extractelement <8 x float> %280, i64 3
  %2196 = fmul float %2195, %2194
  %2197 = tail call i1 @llvm.is.fpclass.f32(float %2194, /* (sub norm) */ i32 408)
  br i1 %2197, label %2210, label %2198, !prof !4

2198:                                             ; preds = %2191
  %2199 = fpext float %2195 to double
  %2200 = fpext nnan float %2136 to double
  %2201 = fpext float %2193 to double
  %2202 = fmul double %2199, %2200
  %2203 = fmul double %2202, %2201
  %2204 = fptrunc double %2203 to float
  %2205 = fcmp oeq float %2195, 0.000000e+00
  %2206 = tail call float @llvm.fabs.f32(float %2193)
  %2207 = fcmp one float %2206, +inf
  %2208 = and i1 %2205, %2207
  %2209 = select i1 %2208, float 0.000000e+00, float %2204
  br label %2210

2210:                                             ; preds = %2198, %2191
  %2211 = phi float [ %2209, %2198 ], [ %2196, %2191 ]
  %2212 = extractelement <8 x float> %2131, i64 4
  %2213 = fmul float %2212, %2136
  %2214 = extractelement <8 x float> %280, i64 4
  %2215 = fmul float %2214, %2213
  %2216 = tail call i1 @llvm.is.fpclass.f32(float %2213, /* (sub norm) */ i32 408)
  br i1 %2216, label %2229, label %2217, !prof !4

2217:                                             ; preds = %2210
  %2218 = fpext float %2214 to double
  %2219 = fpext nnan float %2136 to double
  %2220 = fpext float %2212 to double
  %2221 = fmul double %2218, %2219
  %2222 = fmul double %2221, %2220
  %2223 = fptrunc double %2222 to float
  %2224 = fcmp oeq float %2214, 0.000000e+00
  %2225 = tail call float @llvm.fabs.f32(float %2212)
  %2226 = fcmp one float %2225, +inf
  %2227 = and i1 %2224, %2226
  %2228 = select i1 %2227, float 0.000000e+00, float %2223
  br label %2229

2229:                                             ; preds = %2217, %2210
  %2230 = phi float [ %2228, %2217 ], [ %2215, %2210 ]
  %2231 = extractelement <8 x float> %2131, i64 5
  %2232 = fmul float %2231, %2136
  %2233 = extractelement <8 x float> %280, i64 5
  %2234 = fmul float %2233, %2232
  %2235 = tail call i1 @llvm.is.fpclass.f32(float %2232, /* (sub norm) */ i32 408)
  br i1 %2235, label %2248, label %2236, !prof !4

2236:                                             ; preds = %2229
  %2237 = fpext float %2233 to double
  %2238 = fpext nnan float %2136 to double
  %2239 = fpext float %2231 to double
  %2240 = fmul double %2237, %2238
  %2241 = fmul double %2240, %2239
  %2242 = fptrunc double %2241 to float
  %2243 = fcmp oeq float %2233, 0.000000e+00
  %2244 = tail call float @llvm.fabs.f32(float %2231)
  %2245 = fcmp one float %2244, +inf
  %2246 = and i1 %2243, %2245
  %2247 = select i1 %2246, float 0.000000e+00, float %2242
  br label %2248

2248:                                             ; preds = %2236, %2229
  %2249 = phi float [ %2247, %2236 ], [ %2234, %2229 ]
  %2250 = extractelement <8 x float> %2131, i64 6
  %2251 = fmul float %2250, %2136
  %2252 = extractelement <8 x float> %280, i64 6
  %2253 = fmul float %2252, %2251
  %2254 = tail call i1 @llvm.is.fpclass.f32(float %2251, /* (sub norm) */ i32 408)
  br i1 %2254, label %2267, label %2255, !prof !4

2255:                                             ; preds = %2248
  %2256 = fpext float %2252 to double
  %2257 = fpext nnan float %2136 to double
  %2258 = fpext float %2250 to double
  %2259 = fmul double %2256, %2257
  %2260 = fmul double %2259, %2258
  %2261 = fptrunc double %2260 to float
  %2262 = fcmp oeq float %2252, 0.000000e+00
  %2263 = tail call float @llvm.fabs.f32(float %2250)
  %2264 = fcmp one float %2263, +inf
  %2265 = and i1 %2262, %2264
  %2266 = select i1 %2265, float 0.000000e+00, float %2261
  br label %2267

2267:                                             ; preds = %2255, %2248
  %2268 = phi float [ %2266, %2255 ], [ %2253, %2248 ]
  %2269 = extractelement <8 x float> %2131, i64 7
  %2270 = fmul float %2269, %2136
  %2271 = extractelement <8 x float> %280, i64 7
  %2272 = fmul float %2271, %2270
  %2273 = tail call i1 @llvm.is.fpclass.f32(float %2270, /* (sub norm) */ i32 408)
  br i1 %2273, label %2286, label %2274, !prof !4

2274:                                             ; preds = %2267
  %2275 = fpext float %2271 to double
  %2276 = fpext nnan float %2136 to double
  %2277 = fpext float %2269 to double
  %2278 = fmul double %2275, %2276
  %2279 = fmul double %2278, %2277
  %2280 = fptrunc double %2279 to float
  %2281 = fcmp oeq float %2271, 0.000000e+00
  %2282 = tail call float @llvm.fabs.f32(float %2269)
  %2283 = fcmp one float %2282, +inf
  %2284 = and i1 %2281, %2283
  %2285 = select i1 %2284, float 0.000000e+00, float %2280
  br label %2286

2286:                                             ; preds = %2274, %2267
  %2287 = phi float [ %2285, %2274 ], [ %2272, %2267 ]
  store float %2154, ptr addrspace(3) %514, align 4
  store float %2173, ptr addrspace(3) %520, align 4
  store float %2192, ptr addrspace(3) %526, align 4
  store float %2211, ptr addrspace(3) %532, align 4
  store float %2230, ptr addrspace(3) %538, align 4
  store float %2249, ptr addrspace(3) %544, align 4
  store float %2268, ptr addrspace(3) %550, align 4
  store float %2287, ptr addrspace(3) %556, align 4
  %2288 = and i1 %559, %2073
  %2289 = and i1 %292, %2288
  br i1 %2289, label %2290, label %2296

2290:                                             ; preds = %2286
  %2291 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %2071
  %2292 = load <4 x float>, ptr addrspace(1) %2291, align 16
  %2293 = getelementptr i8, ptr addrspace(1) %2291, i64 16
  %2294 = load <4 x float>, ptr addrspace(1) %2293, align 16
  %2295 = shufflevector <4 x float> %2292, <4 x float> %2294, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2344

2296:                                             ; preds = %2286
  %2297 = icmp slt i64 %2071, %25
  %2298 = select i1 %2297, i64 %2071, i64 0
  %2299 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2298
  %2300 = load float, ptr addrspace(1) %2299, align 4
  %2301 = insertelement <8 x float> poison, float %2300, i64 0
  %2302 = or disjoint i64 %61, %515
  %2303 = icmp slt i64 %2302, %25
  %2304 = select i1 %2303, i64 %2302, i64 0
  %2305 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2304
  %2306 = load float, ptr addrspace(1) %2305, align 4
  %2307 = insertelement <8 x float> %2301, float %2306, i64 1
  %2308 = or disjoint i64 %61, %521
  %2309 = icmp slt i64 %2308, %25
  %2310 = select i1 %2309, i64 %2308, i64 0
  %2311 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2310
  %2312 = load float, ptr addrspace(1) %2311, align 4
  %2313 = insertelement <8 x float> %2307, float %2312, i64 2
  %2314 = or disjoint i64 %61, %527
  %2315 = icmp slt i64 %2314, %25
  %2316 = select i1 %2315, i64 %2314, i64 0
  %2317 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2316
  %2318 = load float, ptr addrspace(1) %2317, align 4
  %2319 = insertelement <8 x float> %2313, float %2318, i64 3
  %2320 = or disjoint i64 %61, %533
  %2321 = icmp slt i64 %2320, %25
  %2322 = select i1 %2321, i64 %2320, i64 0
  %2323 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2322
  %2324 = load float, ptr addrspace(1) %2323, align 4
  %2325 = insertelement <8 x float> %2319, float %2324, i64 4
  %2326 = or disjoint i64 %61, %539
  %2327 = icmp slt i64 %2326, %25
  %2328 = select i1 %2327, i64 %2326, i64 0
  %2329 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2328
  %2330 = load float, ptr addrspace(1) %2329, align 4
  %2331 = insertelement <8 x float> %2325, float %2330, i64 5
  %2332 = or disjoint i64 %61, %545
  %2333 = icmp slt i64 %2332, %25
  %2334 = select i1 %2333, i64 %2332, i64 0
  %2335 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2334
  %2336 = load float, ptr addrspace(1) %2335, align 4
  %2337 = insertelement <8 x float> %2331, float %2336, i64 6
  %2338 = or disjoint i64 %61, %551
  %2339 = icmp slt i64 %2338, %25
  %2340 = select i1 %2339, i64 %2338, i64 0
  %2341 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2340
  %2342 = load float, ptr addrspace(1) %2341, align 4
  %2343 = insertelement <8 x float> %2337, float %2342, i64 7
  br label %2344

2344:                                             ; preds = %2290, %2296
  %2345 = phi <8 x float> [ %2343, %2296 ], [ %2295, %2290 ]
  %2346 = extractelement <8 x float> %2345, i64 0
  %2347 = load i8, ptr addrspace(1) %621, align 1
  %2348 = zext i8 %2347 to i32
  %2349 = shl nuw nsw i32 %2348, 23
  %2350 = bitcast i32 %2349 to float
  %2351 = fmul float %2346, %2350
  %2352 = extractelement <8 x float> %281, i64 0
  %2353 = fmul float %2352, %2351
  %2354 = tail call i1 @llvm.is.fpclass.f32(float %2351, /* (sub norm) */ i32 408)
  br i1 %2354, label %2367, label %2355, !prof !4

2355:                                             ; preds = %2344
  %2356 = fpext float %2352 to double
  %2357 = fpext nnan float %2350 to double
  %2358 = fpext float %2346 to double
  %2359 = fmul double %2356, %2357
  %2360 = fmul double %2359, %2358
  %2361 = fptrunc double %2360 to float
  %2362 = fcmp oeq float %2352, 0.000000e+00
  %2363 = tail call float @llvm.fabs.f32(float %2346)
  %2364 = fcmp one float %2363, +inf
  %2365 = and i1 %2362, %2364
  %2366 = select i1 %2365, float 0.000000e+00, float %2361
  br label %2367

2367:                                             ; preds = %2355, %2344
  %2368 = phi float [ %2366, %2355 ], [ %2353, %2344 ]
  %2369 = extractelement <8 x float> %2345, i64 1
  %2370 = fmul float %2369, %2350
  %2371 = extractelement <8 x float> %281, i64 1
  %2372 = fmul float %2371, %2370
  %2373 = tail call i1 @llvm.is.fpclass.f32(float %2370, /* (sub norm) */ i32 408)
  br i1 %2373, label %2386, label %2374, !prof !4

2374:                                             ; preds = %2367
  %2375 = fpext float %2371 to double
  %2376 = fpext nnan float %2350 to double
  %2377 = fpext float %2369 to double
  %2378 = fmul double %2375, %2376
  %2379 = fmul double %2378, %2377
  %2380 = fptrunc double %2379 to float
  %2381 = fcmp oeq float %2371, 0.000000e+00
  %2382 = tail call float @llvm.fabs.f32(float %2369)
  %2383 = fcmp one float %2382, +inf
  %2384 = and i1 %2381, %2383
  %2385 = select i1 %2384, float 0.000000e+00, float %2380
  br label %2386

2386:                                             ; preds = %2374, %2367
  %2387 = phi float [ %2385, %2374 ], [ %2372, %2367 ]
  %2388 = extractelement <8 x float> %2345, i64 2
  %2389 = fmul float %2388, %2350
  %2390 = extractelement <8 x float> %281, i64 2
  %2391 = fmul float %2390, %2389
  %2392 = tail call i1 @llvm.is.fpclass.f32(float %2389, /* (sub norm) */ i32 408)
  br i1 %2392, label %2405, label %2393, !prof !4

2393:                                             ; preds = %2386
  %2394 = fpext float %2390 to double
  %2395 = fpext nnan float %2350 to double
  %2396 = fpext float %2388 to double
  %2397 = fmul double %2394, %2395
  %2398 = fmul double %2397, %2396
  %2399 = fptrunc double %2398 to float
  %2400 = fcmp oeq float %2390, 0.000000e+00
  %2401 = tail call float @llvm.fabs.f32(float %2388)
  %2402 = fcmp one float %2401, +inf
  %2403 = and i1 %2400, %2402
  %2404 = select i1 %2403, float 0.000000e+00, float %2399
  br label %2405

2405:                                             ; preds = %2393, %2386
  %2406 = phi float [ %2404, %2393 ], [ %2391, %2386 ]
  %2407 = extractelement <8 x float> %2345, i64 3
  %2408 = fmul float %2407, %2350
  %2409 = extractelement <8 x float> %281, i64 3
  %2410 = fmul float %2409, %2408
  %2411 = tail call i1 @llvm.is.fpclass.f32(float %2408, /* (sub norm) */ i32 408)
  br i1 %2411, label %2424, label %2412, !prof !4

2412:                                             ; preds = %2405
  %2413 = fpext float %2409 to double
  %2414 = fpext nnan float %2350 to double
  %2415 = fpext float %2407 to double
  %2416 = fmul double %2413, %2414
  %2417 = fmul double %2416, %2415
  %2418 = fptrunc double %2417 to float
  %2419 = fcmp oeq float %2409, 0.000000e+00
  %2420 = tail call float @llvm.fabs.f32(float %2407)
  %2421 = fcmp one float %2420, +inf
  %2422 = and i1 %2419, %2421
  %2423 = select i1 %2422, float 0.000000e+00, float %2418
  br label %2424

2424:                                             ; preds = %2412, %2405
  %2425 = phi float [ %2423, %2412 ], [ %2410, %2405 ]
  %2426 = extractelement <8 x float> %2345, i64 4
  %2427 = fmul float %2426, %2350
  %2428 = extractelement <8 x float> %281, i64 4
  %2429 = fmul float %2428, %2427
  %2430 = tail call i1 @llvm.is.fpclass.f32(float %2427, /* (sub norm) */ i32 408)
  br i1 %2430, label %2443, label %2431, !prof !4

2431:                                             ; preds = %2424
  %2432 = fpext float %2428 to double
  %2433 = fpext nnan float %2350 to double
  %2434 = fpext float %2426 to double
  %2435 = fmul double %2432, %2433
  %2436 = fmul double %2435, %2434
  %2437 = fptrunc double %2436 to float
  %2438 = fcmp oeq float %2428, 0.000000e+00
  %2439 = tail call float @llvm.fabs.f32(float %2426)
  %2440 = fcmp one float %2439, +inf
  %2441 = and i1 %2438, %2440
  %2442 = select i1 %2441, float 0.000000e+00, float %2437
  br label %2443

2443:                                             ; preds = %2431, %2424
  %2444 = phi float [ %2442, %2431 ], [ %2429, %2424 ]
  %2445 = extractelement <8 x float> %2345, i64 5
  %2446 = fmul float %2445, %2350
  %2447 = extractelement <8 x float> %281, i64 5
  %2448 = fmul float %2447, %2446
  %2449 = tail call i1 @llvm.is.fpclass.f32(float %2446, /* (sub norm) */ i32 408)
  br i1 %2449, label %2462, label %2450, !prof !4

2450:                                             ; preds = %2443
  %2451 = fpext float %2447 to double
  %2452 = fpext nnan float %2350 to double
  %2453 = fpext float %2445 to double
  %2454 = fmul double %2451, %2452
  %2455 = fmul double %2454, %2453
  %2456 = fptrunc double %2455 to float
  %2457 = fcmp oeq float %2447, 0.000000e+00
  %2458 = tail call float @llvm.fabs.f32(float %2445)
  %2459 = fcmp one float %2458, +inf
  %2460 = and i1 %2457, %2459
  %2461 = select i1 %2460, float 0.000000e+00, float %2456
  br label %2462

2462:                                             ; preds = %2450, %2443
  %2463 = phi float [ %2461, %2450 ], [ %2448, %2443 ]
  %2464 = extractelement <8 x float> %2345, i64 6
  %2465 = fmul float %2464, %2350
  %2466 = extractelement <8 x float> %281, i64 6
  %2467 = fmul float %2466, %2465
  %2468 = tail call i1 @llvm.is.fpclass.f32(float %2465, /* (sub norm) */ i32 408)
  br i1 %2468, label %2481, label %2469, !prof !4

2469:                                             ; preds = %2462
  %2470 = fpext float %2466 to double
  %2471 = fpext nnan float %2350 to double
  %2472 = fpext float %2464 to double
  %2473 = fmul double %2470, %2471
  %2474 = fmul double %2473, %2472
  %2475 = fptrunc double %2474 to float
  %2476 = fcmp oeq float %2466, 0.000000e+00
  %2477 = tail call float @llvm.fabs.f32(float %2464)
  %2478 = fcmp one float %2477, +inf
  %2479 = and i1 %2476, %2478
  %2480 = select i1 %2479, float 0.000000e+00, float %2475
  br label %2481

2481:                                             ; preds = %2469, %2462
  %2482 = phi float [ %2480, %2469 ], [ %2467, %2462 ]
  %2483 = extractelement <8 x float> %2345, i64 7
  %2484 = fmul float %2483, %2350
  %2485 = extractelement <8 x float> %281, i64 7
  %2486 = fmul float %2485, %2484
  %2487 = tail call i1 @llvm.is.fpclass.f32(float %2484, /* (sub norm) */ i32 408)
  br i1 %2487, label %2500, label %2488, !prof !4

2488:                                             ; preds = %2481
  %2489 = fpext float %2485 to double
  %2490 = fpext nnan float %2350 to double
  %2491 = fpext float %2483 to double
  %2492 = fmul double %2489, %2490
  %2493 = fmul double %2492, %2491
  %2494 = fptrunc double %2493 to float
  %2495 = fcmp oeq float %2485, 0.000000e+00
  %2496 = tail call float @llvm.fabs.f32(float %2483)
  %2497 = fcmp one float %2496, +inf
  %2498 = and i1 %2495, %2497
  %2499 = select i1 %2498, float 0.000000e+00, float %2494
  br label %2500

2500:                                             ; preds = %2488, %2481
  %2501 = phi float [ %2499, %2488 ], [ %2486, %2481 ]
  store float %2368, ptr addrspace(3) %780, align 4
  store float %2387, ptr addrspace(3) %783, align 4
  store float %2406, ptr addrspace(3) %786, align 4
  store float %2425, ptr addrspace(3) %789, align 4
  store float %2444, ptr addrspace(3) %792, align 4
  store float %2463, ptr addrspace(3) %795, align 4
  store float %2482, ptr addrspace(3) %798, align 4
  store float %2501, ptr addrspace(3) %801, align 4
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %2502 = or disjoint i64 %63, %806
  %2503 = or disjoint i64 %2502, %52
  %2504 = or i64 %2503, 48
  %2505 = load <8 x float>, ptr addrspace(3) %816, align 16
  %2506 = fptrunc <8 x float> %2505 to <8 x bfloat>
  %2507 = mul i64 %2504, %26
  %2508 = add i64 %2507, %812
  %2509 = icmp ult i64 %2504, %25
  %2510 = and i1 %2509, %823
  br i1 %2510, label %2511, label %2513

2511:                                             ; preds = %2500
  %2512 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2508
  store <8 x bfloat> %2506, ptr addrspace(1) %2512, align 2
  br label %2567

2513:                                             ; preds = %2500
  %2514 = icmp ult i64 %812, %26
  %2515 = and i1 %2509, %2514
  br i1 %2515, label %2516, label %2519

2516:                                             ; preds = %2513
  %2517 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2508
  %2518 = extractelement <8 x bfloat> %2506, i64 0
  store bfloat %2518, ptr addrspace(1) %2517, align 2
  br label %2519

2519:                                             ; preds = %2516, %2513
  %2520 = or disjoint i64 %812, 1
  %2521 = icmp ult i64 %2520, %26
  %2522 = and i1 %2509, %2521
  br i1 %2522, label %2523, label %2527

2523:                                             ; preds = %2519
  %2524 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2508
  %2525 = getelementptr i8, ptr addrspace(1) %2524, i64 2
  %2526 = extractelement <8 x bfloat> %2506, i64 1
  store bfloat %2526, ptr addrspace(1) %2525, align 2
  br label %2527

2527:                                             ; preds = %2523, %2519
  %2528 = or disjoint i64 %812, 2
  %2529 = icmp ult i64 %2528, %26
  %2530 = and i1 %2509, %2529
  br i1 %2530, label %2531, label %2535

2531:                                             ; preds = %2527
  %2532 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2508
  %2533 = getelementptr i8, ptr addrspace(1) %2532, i64 4
  %2534 = extractelement <8 x bfloat> %2506, i64 2
  store bfloat %2534, ptr addrspace(1) %2533, align 2
  br label %2535

2535:                                             ; preds = %2531, %2527
  %2536 = or disjoint i64 %812, 3
  %2537 = icmp ult i64 %2536, %26
  %2538 = and i1 %2509, %2537
  br i1 %2538, label %2539, label %2543

2539:                                             ; preds = %2535
  %2540 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2508
  %2541 = getelementptr i8, ptr addrspace(1) %2540, i64 6
  %2542 = extractelement <8 x bfloat> %2506, i64 3
  store bfloat %2542, ptr addrspace(1) %2541, align 2
  br label %2543

2543:                                             ; preds = %2539, %2535
  %2544 = or disjoint i64 %812, 4
  %2545 = icmp ult i64 %2544, %26
  %2546 = and i1 %2509, %2545
  br i1 %2546, label %2547, label %2551

2547:                                             ; preds = %2543
  %2548 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2508
  %2549 = getelementptr i8, ptr addrspace(1) %2548, i64 8
  %2550 = extractelement <8 x bfloat> %2506, i64 4
  store bfloat %2550, ptr addrspace(1) %2549, align 2
  br label %2551

2551:                                             ; preds = %2547, %2543
  %2552 = or disjoint i64 %812, 5
  %2553 = icmp ult i64 %2552, %26
  %2554 = and i1 %2509, %2553
  br i1 %2554, label %2555, label %2559

2555:                                             ; preds = %2551
  %2556 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2508
  %2557 = getelementptr i8, ptr addrspace(1) %2556, i64 10
  %2558 = extractelement <8 x bfloat> %2506, i64 5
  store bfloat %2558, ptr addrspace(1) %2557, align 2
  br label %2559

2559:                                             ; preds = %2555, %2551
  %2560 = or disjoint i64 %812, 6
  %2561 = icmp ult i64 %2560, %26
  %2562 = and i1 %2509, %2561
  br i1 %2562, label %2563, label %2567

2563:                                             ; preds = %2559
  %2564 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2508
  %2565 = getelementptr i8, ptr addrspace(1) %2564, i64 12
  %2566 = extractelement <8 x bfloat> %2506, i64 6
  store bfloat %2566, ptr addrspace(1) %2565, align 2
  br label %2567

2567:                                             ; preds = %2559, %2563, %2511
  %2568 = or disjoint i64 %63, %883
  %2569 = or disjoint i64 %2568, %52
  %2570 = or i64 %2569, 48
  %2571 = load <8 x float>, ptr addrspace(3) %889, align 16
  %2572 = fptrunc <8 x float> %2571 to <8 x bfloat>
  %2573 = mul i64 %2570, %26
  %2574 = add i64 %2573, %812
  %2575 = icmp ult i64 %2570, %25
  %2576 = and i1 %2575, %823
  br i1 %2576, label %2577, label %2579

2577:                                             ; preds = %2567
  %2578 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  store <8 x bfloat> %2572, ptr addrspace(1) %2578, align 2
  br label %2633

2579:                                             ; preds = %2567
  %2580 = icmp ult i64 %812, %26
  %2581 = and i1 %2575, %2580
  br i1 %2581, label %2582, label %2585

2582:                                             ; preds = %2579
  %2583 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2584 = extractelement <8 x bfloat> %2572, i64 0
  store bfloat %2584, ptr addrspace(1) %2583, align 2
  br label %2585

2585:                                             ; preds = %2582, %2579
  %2586 = or disjoint i64 %812, 1
  %2587 = icmp ult i64 %2586, %26
  %2588 = and i1 %2575, %2587
  br i1 %2588, label %2589, label %2593

2589:                                             ; preds = %2585
  %2590 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2591 = getelementptr i8, ptr addrspace(1) %2590, i64 2
  %2592 = extractelement <8 x bfloat> %2572, i64 1
  store bfloat %2592, ptr addrspace(1) %2591, align 2
  br label %2593

2593:                                             ; preds = %2589, %2585
  %2594 = or disjoint i64 %812, 2
  %2595 = icmp ult i64 %2594, %26
  %2596 = and i1 %2575, %2595
  br i1 %2596, label %2597, label %2601

2597:                                             ; preds = %2593
  %2598 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2599 = getelementptr i8, ptr addrspace(1) %2598, i64 4
  %2600 = extractelement <8 x bfloat> %2572, i64 2
  store bfloat %2600, ptr addrspace(1) %2599, align 2
  br label %2601

2601:                                             ; preds = %2597, %2593
  %2602 = or disjoint i64 %812, 3
  %2603 = icmp ult i64 %2602, %26
  %2604 = and i1 %2575, %2603
  br i1 %2604, label %2605, label %2609

2605:                                             ; preds = %2601
  %2606 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2607 = getelementptr i8, ptr addrspace(1) %2606, i64 6
  %2608 = extractelement <8 x bfloat> %2572, i64 3
  store bfloat %2608, ptr addrspace(1) %2607, align 2
  br label %2609

2609:                                             ; preds = %2605, %2601
  %2610 = or disjoint i64 %812, 4
  %2611 = icmp ult i64 %2610, %26
  %2612 = and i1 %2575, %2611
  br i1 %2612, label %2613, label %2617

2613:                                             ; preds = %2609
  %2614 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2615 = getelementptr i8, ptr addrspace(1) %2614, i64 8
  %2616 = extractelement <8 x bfloat> %2572, i64 4
  store bfloat %2616, ptr addrspace(1) %2615, align 2
  br label %2617

2617:                                             ; preds = %2613, %2609
  %2618 = or disjoint i64 %812, 5
  %2619 = icmp ult i64 %2618, %26
  %2620 = and i1 %2575, %2619
  br i1 %2620, label %2621, label %2625

2621:                                             ; preds = %2617
  %2622 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2623 = getelementptr i8, ptr addrspace(1) %2622, i64 10
  %2624 = extractelement <8 x bfloat> %2572, i64 5
  store bfloat %2624, ptr addrspace(1) %2623, align 2
  br label %2625

2625:                                             ; preds = %2621, %2617
  %2626 = or disjoint i64 %812, 6
  %2627 = icmp ult i64 %2626, %26
  %2628 = and i1 %2575, %2627
  br i1 %2628, label %2629, label %2633

2629:                                             ; preds = %2625
  %2630 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2631 = getelementptr i8, ptr addrspace(1) %2630, i64 12
  %2632 = extractelement <8 x bfloat> %2572, i64 6
  store bfloat %2632, ptr addrspace(1) %2631, align 2
  br label %2633

2633:                                             ; preds = %2625, %2629, %2577
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.is.fpclass.f32(float, i32 immarg) #6

attributes #0 = { norecurse nounwind "amdgpu-flat-work-group-size"="256,256" "amdgpu-no-cluster-id-x" "amdgpu-no-cluster-id-y" "amdgpu-no-cluster-id-z" "amdgpu-no-completion-action" "amdgpu-no-default-queue" "amdgpu-no-dispatch-id" "amdgpu-no-dispatch-ptr" "amdgpu-no-flat-scratch-init" "amdgpu-no-heap-ptr" "amdgpu-no-hostcall-ptr" "amdgpu-no-implicitarg-ptr" "amdgpu-no-lds-kernel-id" "amdgpu-no-multigrid-sync-arg" "amdgpu-no-queue-ptr" "amdgpu-no-workgroup-id-x" "amdgpu-no-workgroup-id-y" "amdgpu-no-workgroup-id-z" "amdgpu-no-workitem-id-x" "amdgpu-no-workitem-id-y" "amdgpu-no-workitem-id-z" "amdgpu-no-wwm" "target-cpu"="gfx1201" "target-features"="-cumode,+wavefrontsize32,-wavefrontsize64" "uniform-work-group-size" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #3 = { convergent mustprogress nocallback nofree nounwind willreturn "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #4 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #5 = { convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
!3 = !{}
!4 = !{!"branch_weights", !"expected", i32 2000, i32 1}
