; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal addrspace(3) global [5120 x i8] undef

define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) #0 !reqd_work_group_size !1 {
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %20, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, ptr %21, 1
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, i64 %22, 2
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %23, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %24, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, ptr %16, 1
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 %17, 2
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 %18, 3, 0
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %19, 4, 0
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %10, 0
  %40 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, ptr %11, 1
  %41 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, i64 %12, 2
  %42 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %41, i64 %13, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %42, i64 %14, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %45 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %44, ptr %6, 1
  %46 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %45, i64 %7, 2
  %47 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, i64 %8, 3, 0
  %48 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, i64 %9, 4, 0
  %49 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %50 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %49, ptr %1, 1
  %51 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %50, i64 %2, 2
  %52 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %51, i64 %3, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %52, i64 %4, 4, 0
  %54 = call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %55 = sext i32 %54 to i64
  %56 = urem i64 %55, 32
  %57 = urem i64 %56, 16
  %58 = udiv i64 %56, 16
  %59 = udiv i64 %55, 32
  %60 = udiv i64 %59, 2
  %61 = urem i64 %59, 2
  %62 = call i32 @llvm.amdgcn.workgroup.id.x()
  %63 = sext i32 %62 to i64
  %64 = add i64 %25, 255
  %65 = udiv i64 %64, 256
  %66 = add i64 %26, 63
  %67 = udiv i64 %66, 64
  %68 = mul i64 %67, 4
  %69 = udiv i64 %63, %68
  %70 = mul i64 %69, 4
  %71 = sub i64 %65, %70
  %72 = icmp ult i64 %71, 4
  %73 = select i1 %72, i64 %71, i64 4
  %74 = urem i64 %63, %68
  %75 = urem i64 %74, %73
  %76 = add i64 %70, %75
  %77 = udiv i64 %74, %73
  %78 = mul i64 %76, 256
  %79 = mul i64 %77, 64
  %80 = mul i64 %60, 64
  %81 = mul i64 %61, 32
  %82 = add i64 %78, %80
  %83 = add i64 %80, 16
  %84 = add i64 %78, %83
  %85 = add i64 %80, 32
  %86 = add i64 %78, %85
  %87 = add i64 %80, 48
  %88 = add i64 %78, %87
  %89 = add i64 %79, %81
  %90 = add i64 %81, 16
  %91 = add i64 %79, %90
  %92 = udiv i64 %55, 4
  %93 = urem i64 %55, 4
  %94 = mul i64 %93, 16
  %95 = add i64 %78, %92
  %96 = mul i64 %95, %27
  %97 = add i64 %96, %94
  %98 = mul i64 %92, 80
  %99 = add i64 %98, %94
  %100 = add i64 %55, 256
  %101 = udiv i64 %100, 4
  %102 = urem i64 %100, 4
  %103 = mul i64 %102, 16
  %104 = add i64 %78, %101
  %105 = mul i64 %104, %27
  %106 = add i64 %105, %103
  %107 = mul i64 %101, 80
  %108 = add i64 %107, %103
  %109 = add i64 %55, 512
  %110 = udiv i64 %109, 4
  %111 = urem i64 %109, 4
  %112 = mul i64 %111, 16
  %113 = add i64 %78, %110
  %114 = mul i64 %113, %27
  %115 = add i64 %114, %112
  %116 = mul i64 %110, 80
  %117 = add i64 %116, %112
  %118 = add i64 %55, 768
  %119 = udiv i64 %118, 4
  %120 = urem i64 %118, 4
  %121 = mul i64 %120, 16
  %122 = add i64 %78, %119
  %123 = mul i64 %122, %27
  %124 = add i64 %123, %121
  %125 = mul i64 %119, 80
  %126 = add i64 %125, %121
  %127 = udiv i64 %55, 4
  %128 = urem i64 %55, 4
  %129 = mul i64 %128, 16
  %130 = add i64 %79, %127
  %131 = mul i64 %130, %27
  %132 = add i64 %131, %129
  %133 = mul i64 %127, 80
  %134 = add i64 %133, %129
  %135 = icmp uge i64 %27, 64
  call void @llvm.assume(i1 %135)
  %136 = udiv i64 %27, 64
  %137 = sub i64 %27, 64
  %138 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %139 = getelementptr i8, ptr %138, i64 %97
  %140 = load <16 x i8>, ptr %139, align 16
  %141 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %142 = getelementptr i8, ptr %141, i64 %106
  %143 = load <16 x i8>, ptr %142, align 16
  %144 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %145 = getelementptr i8, ptr %144, i64 %115
  %146 = load <16 x i8>, ptr %145, align 16
  %147 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %148 = getelementptr i8, ptr %147, i64 %124
  %149 = load <16 x i8>, ptr %148, align 16
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %140, ptr addrspace(3) %150, align 16
  %151 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %143, ptr addrspace(3) %151, align 16
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %146, ptr addrspace(3) %152, align 16
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %149, ptr addrspace(3) %153, align 16
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %155 = getelementptr i8, ptr %154, i64 %132
  %156 = load <16 x i8>, ptr %155, align 16
  %157 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %156, ptr addrspace(3) %157, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  br label %158

158:                                              ; preds = %169, %28
  %159 = phi i64 [ %416, %169 ], [ 0, %28 ]
  %160 = phi <8 x float> [ %403, %169 ], [ zeroinitializer, %28 ]
  %161 = phi <8 x float> [ %404, %169 ], [ zeroinitializer, %28 ]
  %162 = phi <8 x float> [ %405, %169 ], [ zeroinitializer, %28 ]
  %163 = phi <8 x float> [ %406, %169 ], [ zeroinitializer, %28 ]
  %164 = phi <8 x float> [ %407, %169 ], [ zeroinitializer, %28 ]
  %165 = phi <8 x float> [ %408, %169 ], [ zeroinitializer, %28 ]
  %166 = phi <8 x float> [ %409, %169 ], [ zeroinitializer, %28 ]
  %167 = phi <8 x float> [ %410, %169 ], [ zeroinitializer, %28 ]
  %168 = icmp slt i64 %159, %136
  br i1 %168, label %169, label %417

169:                                              ; preds = %158
  %170 = mul i64 %159, 64
  %171 = add i64 %170, 64
  %172 = call i64 @llvm.umin.i64(i64 %171, i64 %137)
  %173 = add i64 %97, %172
  %174 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %175 = getelementptr i8, ptr %174, i64 %173
  %176 = load <16 x i8>, ptr %175, align 16
  %177 = add i64 %106, %172
  %178 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %179 = getelementptr i8, ptr %178, i64 %177
  %180 = load <16 x i8>, ptr %179, align 16
  %181 = add i64 %115, %172
  %182 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %183 = getelementptr i8, ptr %182, i64 %181
  %184 = load <16 x i8>, ptr %183, align 16
  %185 = add i64 %124, %172
  %186 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %187 = getelementptr i8, ptr %186, i64 %185
  %188 = load <16 x i8>, ptr %187, align 16
  %189 = add i64 %132, %172
  %190 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %191 = getelementptr i8, ptr %190, i64 %189
  %192 = load <16 x i8>, ptr %191, align 16
  %193 = mul i64 %58, 8
  %194 = add i64 %80, %57
  %195 = mul i64 %194, 80
  %196 = add i64 %195, %193
  %197 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %196
  %198 = load <8 x i8>, ptr addrspace(3) %197, align 1
  %199 = bitcast <8 x i8> %198 to <2 x i32>
  %200 = mul i64 %58, 8
  %201 = add i64 %83, %57
  %202 = mul i64 %201, 80
  %203 = add i64 %202, %200
  %204 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %203
  %205 = load <8 x i8>, ptr addrspace(3) %204, align 1
  %206 = bitcast <8 x i8> %205 to <2 x i32>
  %207 = mul i64 %58, 8
  %208 = add i64 %85, %57
  %209 = mul i64 %208, 80
  %210 = add i64 %209, %207
  %211 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %210
  %212 = load <8 x i8>, ptr addrspace(3) %211, align 1
  %213 = bitcast <8 x i8> %212 to <2 x i32>
  %214 = mul i64 %58, 8
  %215 = add i64 %87, %57
  %216 = mul i64 %215, 80
  %217 = add i64 %216, %214
  %218 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %217
  %219 = load <8 x i8>, ptr addrspace(3) %218, align 1
  %220 = bitcast <8 x i8> %219 to <2 x i32>
  %221 = mul i64 %58, 8
  %222 = add i64 %81, %57
  %223 = mul i64 %222, 80
  %224 = add i64 %223, %221
  %225 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %224
  %226 = load <8 x i8>, ptr addrspace(3) %225, align 1
  %227 = bitcast <8 x i8> %226 to <2 x i32>
  %228 = mul i64 %58, 8
  %229 = add i64 %90, %57
  %230 = mul i64 %229, 80
  %231 = add i64 %230, %228
  %232 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %231
  %233 = load <8 x i8>, ptr addrspace(3) %232, align 1
  %234 = bitcast <8 x i8> %233 to <2 x i32>
  %235 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %227, <8 x float> %160)
  %236 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %234, <8 x float> %161)
  %237 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %227, <8 x float> %162)
  %238 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %234, <8 x float> %163)
  %239 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %227, <8 x float> %164)
  %240 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %234, <8 x float> %165)
  %241 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %227, <8 x float> %166)
  %242 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %234, <8 x float> %167)
  %243 = mul i64 %58, 8
  %244 = add i64 %80, %57
  %245 = add i64 %243, 16
  %246 = mul i64 %244, 80
  %247 = add i64 %246, %245
  %248 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %247
  %249 = load <8 x i8>, ptr addrspace(3) %248, align 1
  %250 = bitcast <8 x i8> %249 to <2 x i32>
  %251 = mul i64 %58, 8
  %252 = add i64 %83, %57
  %253 = add i64 %251, 16
  %254 = mul i64 %252, 80
  %255 = add i64 %254, %253
  %256 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %255
  %257 = load <8 x i8>, ptr addrspace(3) %256, align 1
  %258 = bitcast <8 x i8> %257 to <2 x i32>
  %259 = mul i64 %58, 8
  %260 = add i64 %85, %57
  %261 = add i64 %259, 16
  %262 = mul i64 %260, 80
  %263 = add i64 %262, %261
  %264 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %263
  %265 = load <8 x i8>, ptr addrspace(3) %264, align 1
  %266 = bitcast <8 x i8> %265 to <2 x i32>
  %267 = mul i64 %58, 8
  %268 = add i64 %87, %57
  %269 = add i64 %267, 16
  %270 = mul i64 %268, 80
  %271 = add i64 %270, %269
  %272 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %271
  %273 = load <8 x i8>, ptr addrspace(3) %272, align 1
  %274 = bitcast <8 x i8> %273 to <2 x i32>
  %275 = mul i64 %58, 8
  %276 = add i64 %275, 16
  %277 = add i64 %81, %57
  %278 = mul i64 %277, 80
  %279 = add i64 %278, %276
  %280 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %279
  %281 = load <8 x i8>, ptr addrspace(3) %280, align 1
  %282 = bitcast <8 x i8> %281 to <2 x i32>
  %283 = mul i64 %58, 8
  %284 = add i64 %283, 16
  %285 = add i64 %90, %57
  %286 = mul i64 %285, 80
  %287 = add i64 %286, %284
  %288 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %287
  %289 = load <8 x i8>, ptr addrspace(3) %288, align 1
  %290 = bitcast <8 x i8> %289 to <2 x i32>
  %291 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %282, <8 x float> %235)
  %292 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %290, <8 x float> %236)
  %293 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %282, <8 x float> %237)
  %294 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %290, <8 x float> %238)
  %295 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %282, <8 x float> %239)
  %296 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %290, <8 x float> %240)
  %297 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %282, <8 x float> %241)
  %298 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %290, <8 x float> %242)
  %299 = mul i64 %58, 8
  %300 = add i64 %80, %57
  %301 = add i64 %299, 32
  %302 = mul i64 %300, 80
  %303 = add i64 %302, %301
  %304 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %303
  %305 = load <8 x i8>, ptr addrspace(3) %304, align 1
  %306 = bitcast <8 x i8> %305 to <2 x i32>
  %307 = mul i64 %58, 8
  %308 = add i64 %83, %57
  %309 = add i64 %307, 32
  %310 = mul i64 %308, 80
  %311 = add i64 %310, %309
  %312 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %311
  %313 = load <8 x i8>, ptr addrspace(3) %312, align 1
  %314 = bitcast <8 x i8> %313 to <2 x i32>
  %315 = mul i64 %58, 8
  %316 = add i64 %85, %57
  %317 = add i64 %315, 32
  %318 = mul i64 %316, 80
  %319 = add i64 %318, %317
  %320 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %319
  %321 = load <8 x i8>, ptr addrspace(3) %320, align 1
  %322 = bitcast <8 x i8> %321 to <2 x i32>
  %323 = mul i64 %58, 8
  %324 = add i64 %87, %57
  %325 = add i64 %323, 32
  %326 = mul i64 %324, 80
  %327 = add i64 %326, %325
  %328 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %327
  %329 = load <8 x i8>, ptr addrspace(3) %328, align 1
  %330 = bitcast <8 x i8> %329 to <2 x i32>
  %331 = mul i64 %58, 8
  %332 = add i64 %331, 32
  %333 = add i64 %81, %57
  %334 = mul i64 %333, 80
  %335 = add i64 %334, %332
  %336 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %335
  %337 = load <8 x i8>, ptr addrspace(3) %336, align 1
  %338 = bitcast <8 x i8> %337 to <2 x i32>
  %339 = mul i64 %58, 8
  %340 = add i64 %339, 32
  %341 = add i64 %90, %57
  %342 = mul i64 %341, 80
  %343 = add i64 %342, %340
  %344 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %343
  %345 = load <8 x i8>, ptr addrspace(3) %344, align 1
  %346 = bitcast <8 x i8> %345 to <2 x i32>
  %347 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %338, <8 x float> %291)
  %348 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %346, <8 x float> %292)
  %349 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %338, <8 x float> %293)
  %350 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %346, <8 x float> %294)
  %351 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %338, <8 x float> %295)
  %352 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %346, <8 x float> %296)
  %353 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %338, <8 x float> %297)
  %354 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %346, <8 x float> %298)
  %355 = mul i64 %58, 8
  %356 = add i64 %80, %57
  %357 = add i64 %355, 48
  %358 = mul i64 %356, 80
  %359 = add i64 %358, %357
  %360 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %359
  %361 = load <8 x i8>, ptr addrspace(3) %360, align 1
  %362 = bitcast <8 x i8> %361 to <2 x i32>
  %363 = mul i64 %58, 8
  %364 = add i64 %83, %57
  %365 = add i64 %363, 48
  %366 = mul i64 %364, 80
  %367 = add i64 %366, %365
  %368 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %367
  %369 = load <8 x i8>, ptr addrspace(3) %368, align 1
  %370 = bitcast <8 x i8> %369 to <2 x i32>
  %371 = mul i64 %58, 8
  %372 = add i64 %85, %57
  %373 = add i64 %371, 48
  %374 = mul i64 %372, 80
  %375 = add i64 %374, %373
  %376 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %375
  %377 = load <8 x i8>, ptr addrspace(3) %376, align 1
  %378 = bitcast <8 x i8> %377 to <2 x i32>
  %379 = mul i64 %58, 8
  %380 = add i64 %87, %57
  %381 = add i64 %379, 48
  %382 = mul i64 %380, 80
  %383 = add i64 %382, %381
  %384 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %383
  %385 = load <8 x i8>, ptr addrspace(3) %384, align 1
  %386 = bitcast <8 x i8> %385 to <2 x i32>
  %387 = mul i64 %58, 8
  %388 = add i64 %387, 48
  %389 = add i64 %81, %57
  %390 = mul i64 %389, 80
  %391 = add i64 %390, %388
  %392 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %391
  %393 = load <8 x i8>, ptr addrspace(3) %392, align 1
  %394 = bitcast <8 x i8> %393 to <2 x i32>
  %395 = mul i64 %58, 8
  %396 = add i64 %395, 48
  %397 = add i64 %90, %57
  %398 = mul i64 %397, 80
  %399 = add i64 %398, %396
  %400 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %399
  %401 = load <8 x i8>, ptr addrspace(3) %400, align 1
  %402 = bitcast <8 x i8> %401 to <2 x i32>
  %403 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %394, <8 x float> %347)
  %404 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %402, <8 x float> %348)
  %405 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %394, <8 x float> %349)
  %406 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %402, <8 x float> %350)
  %407 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %394, <8 x float> %351)
  %408 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %402, <8 x float> %352)
  %409 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %394, <8 x float> %353)
  %410 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %402, <8 x float> %354)
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %411 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %176, ptr addrspace(3) %411, align 16
  %412 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %180, ptr addrspace(3) %412, align 16
  %413 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %184, ptr addrspace(3) %413, align 16
  %414 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %188, ptr addrspace(3) %414, align 16
  %415 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %192, ptr addrspace(3) %415, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %416 = add i64 %159, 1
  br label %158

417:                                              ; preds = %158
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %418 = mul i64 %58, 8
  %419 = add i64 %82, %418
  %420 = add i64 %89, %57
  %421 = add i64 %419, 7
  %422 = icmp ult i64 %420, %26
  %423 = icmp ult i64 %421, %25
  %424 = and i1 %423, %422
  %425 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %426 = ptrtoint ptr %425 to i64
  %427 = mul i64 %419, 4
  %428 = add i64 %426, %427
  %429 = urem i64 %428, 16
  %430 = icmp eq i64 %429, 0
  %431 = and i1 %424, %430
  br i1 %431, label %432, label %441

432:                                              ; preds = %417
  %433 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %434 = getelementptr float, ptr %433, i64 %419
  %435 = load <4 x float>, ptr %434, align 16
  %436 = add i64 %419, 4
  %437 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %438 = getelementptr float, ptr %437, i64 %436
  %439 = load <4 x float>, ptr %438, align 16
  %440 = shufflevector <4 x float> %435, <4 x float> %439, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %513

441:                                              ; preds = %417
  %442 = mul i64 %58, 8
  %443 = add i64 %82, %442
  %444 = icmp slt i64 %443, %25
  %445 = select i1 %444, i64 %443, i64 0
  %446 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %447 = getelementptr inbounds nuw float, ptr %446, i64 %445
  %448 = load float, ptr %447, align 4
  %449 = insertelement <8 x float> zeroinitializer, float %448, i64 0
  %450 = mul i64 %58, 8
  %451 = add i64 %450, 1
  %452 = add i64 %82, %451
  %453 = icmp slt i64 %452, %25
  %454 = select i1 %453, i64 %452, i64 0
  %455 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %456 = getelementptr inbounds nuw float, ptr %455, i64 %454
  %457 = load float, ptr %456, align 4
  %458 = insertelement <8 x float> %449, float %457, i64 1
  %459 = mul i64 %58, 8
  %460 = add i64 %459, 2
  %461 = add i64 %82, %460
  %462 = icmp slt i64 %461, %25
  %463 = select i1 %462, i64 %461, i64 0
  %464 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %465 = getelementptr inbounds nuw float, ptr %464, i64 %463
  %466 = load float, ptr %465, align 4
  %467 = insertelement <8 x float> %458, float %466, i64 2
  %468 = mul i64 %58, 8
  %469 = add i64 %468, 3
  %470 = add i64 %82, %469
  %471 = icmp slt i64 %470, %25
  %472 = select i1 %471, i64 %470, i64 0
  %473 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %474 = getelementptr inbounds nuw float, ptr %473, i64 %472
  %475 = load float, ptr %474, align 4
  %476 = insertelement <8 x float> %467, float %475, i64 3
  %477 = mul i64 %58, 8
  %478 = add i64 %477, 4
  %479 = add i64 %82, %478
  %480 = icmp slt i64 %479, %25
  %481 = select i1 %480, i64 %479, i64 0
  %482 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %483 = getelementptr inbounds nuw float, ptr %482, i64 %481
  %484 = load float, ptr %483, align 4
  %485 = insertelement <8 x float> %476, float %484, i64 4
  %486 = mul i64 %58, 8
  %487 = add i64 %486, 5
  %488 = add i64 %82, %487
  %489 = icmp slt i64 %488, %25
  %490 = select i1 %489, i64 %488, i64 0
  %491 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %492 = getelementptr inbounds nuw float, ptr %491, i64 %490
  %493 = load float, ptr %492, align 4
  %494 = insertelement <8 x float> %485, float %493, i64 5
  %495 = mul i64 %58, 8
  %496 = add i64 %495, 6
  %497 = add i64 %82, %496
  %498 = icmp slt i64 %497, %25
  %499 = select i1 %498, i64 %497, i64 0
  %500 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %501 = getelementptr inbounds nuw float, ptr %500, i64 %499
  %502 = load float, ptr %501, align 4
  %503 = insertelement <8 x float> %494, float %502, i64 6
  %504 = mul i64 %58, 8
  %505 = add i64 %504, 7
  %506 = add i64 %82, %505
  %507 = icmp slt i64 %506, %25
  %508 = select i1 %507, i64 %506, i64 0
  %509 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %510 = getelementptr inbounds nuw float, ptr %509, i64 %508
  %511 = load float, ptr %510, align 4
  %512 = insertelement <8 x float> %503, float %511, i64 7
  br label %513

513:                                              ; preds = %432, %441
  %514 = phi <8 x float> [ %512, %441 ], [ %440, %432 ]
  br label %515

515:                                              ; preds = %513
  %516 = add i64 %89, %57
  %517 = icmp slt i64 %516, %26
  %518 = select i1 %517, i64 %516, i64 0
  %519 = extractelement <8 x float> %514, i64 0
  %520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %521 = getelementptr inbounds nuw i8, ptr %520, i64 %518
  %522 = load i8, ptr %521, align 1
  %523 = zext i8 %522 to i32
  %524 = shl i32 %523, 23
  %525 = bitcast i32 %524 to float
  %526 = fmul float %525, %519
  %527 = extractelement <8 x float> %160, i64 0
  %528 = fmul float %527, %526
  %529 = call float @llvm.fabs.f32(float %526)
  %530 = fcmp olt float %529, +inf
  %531 = fcmp one float %526, 0.000000e+00
  %532 = and i1 %530, %531
  %533 = call i1 @llvm.expect.i1(i1 %532, i1 true)
  br i1 %533, label %534, label %535

534:                                              ; preds = %515
  br label %547

535:                                              ; preds = %515
  %536 = fpext float %527 to double
  %537 = fpext float %525 to double
  %538 = fpext float %519 to double
  %539 = fmul double %536, %537
  %540 = fmul double %539, %538
  %541 = fptrunc double %540 to float
  %542 = fcmp oeq float %527, 0.000000e+00
  %543 = call float @llvm.fabs.f32(float %519)
  %544 = fcmp olt float %543, +inf
  %545 = and i1 %542, %544
  %546 = select i1 %545, float 0.000000e+00, float %541
  br label %547

547:                                              ; preds = %534, %535
  %548 = phi float [ %546, %535 ], [ %528, %534 ]
  br label %549

549:                                              ; preds = %547
  %550 = add i64 %89, %57
  %551 = icmp slt i64 %550, %26
  %552 = select i1 %551, i64 %550, i64 0
  %553 = extractelement <8 x float> %514, i64 1
  %554 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %555 = getelementptr inbounds nuw i8, ptr %554, i64 %552
  %556 = load i8, ptr %555, align 1
  %557 = zext i8 %556 to i32
  %558 = shl i32 %557, 23
  %559 = bitcast i32 %558 to float
  %560 = fmul float %559, %553
  %561 = extractelement <8 x float> %160, i64 1
  %562 = fmul float %561, %560
  %563 = call float @llvm.fabs.f32(float %560)
  %564 = fcmp olt float %563, +inf
  %565 = fcmp one float %560, 0.000000e+00
  %566 = and i1 %564, %565
  %567 = call i1 @llvm.expect.i1(i1 %566, i1 true)
  br i1 %567, label %568, label %569

568:                                              ; preds = %549
  br label %581

569:                                              ; preds = %549
  %570 = fpext float %561 to double
  %571 = fpext float %559 to double
  %572 = fpext float %553 to double
  %573 = fmul double %570, %571
  %574 = fmul double %573, %572
  %575 = fptrunc double %574 to float
  %576 = fcmp oeq float %561, 0.000000e+00
  %577 = call float @llvm.fabs.f32(float %553)
  %578 = fcmp olt float %577, +inf
  %579 = and i1 %576, %578
  %580 = select i1 %579, float 0.000000e+00, float %575
  br label %581

581:                                              ; preds = %568, %569
  %582 = phi float [ %580, %569 ], [ %562, %568 ]
  br label %583

583:                                              ; preds = %581
  %584 = add i64 %89, %57
  %585 = icmp slt i64 %584, %26
  %586 = select i1 %585, i64 %584, i64 0
  %587 = extractelement <8 x float> %514, i64 2
  %588 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %589 = getelementptr inbounds nuw i8, ptr %588, i64 %586
  %590 = load i8, ptr %589, align 1
  %591 = zext i8 %590 to i32
  %592 = shl i32 %591, 23
  %593 = bitcast i32 %592 to float
  %594 = fmul float %593, %587
  %595 = extractelement <8 x float> %160, i64 2
  %596 = fmul float %595, %594
  %597 = call float @llvm.fabs.f32(float %594)
  %598 = fcmp olt float %597, +inf
  %599 = fcmp one float %594, 0.000000e+00
  %600 = and i1 %598, %599
  %601 = call i1 @llvm.expect.i1(i1 %600, i1 true)
  br i1 %601, label %602, label %603

602:                                              ; preds = %583
  br label %615

603:                                              ; preds = %583
  %604 = fpext float %595 to double
  %605 = fpext float %593 to double
  %606 = fpext float %587 to double
  %607 = fmul double %604, %605
  %608 = fmul double %607, %606
  %609 = fptrunc double %608 to float
  %610 = fcmp oeq float %595, 0.000000e+00
  %611 = call float @llvm.fabs.f32(float %587)
  %612 = fcmp olt float %611, +inf
  %613 = and i1 %610, %612
  %614 = select i1 %613, float 0.000000e+00, float %609
  br label %615

615:                                              ; preds = %602, %603
  %616 = phi float [ %614, %603 ], [ %596, %602 ]
  br label %617

617:                                              ; preds = %615
  %618 = add i64 %89, %57
  %619 = icmp slt i64 %618, %26
  %620 = select i1 %619, i64 %618, i64 0
  %621 = extractelement <8 x float> %514, i64 3
  %622 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %623 = getelementptr inbounds nuw i8, ptr %622, i64 %620
  %624 = load i8, ptr %623, align 1
  %625 = zext i8 %624 to i32
  %626 = shl i32 %625, 23
  %627 = bitcast i32 %626 to float
  %628 = fmul float %627, %621
  %629 = extractelement <8 x float> %160, i64 3
  %630 = fmul float %629, %628
  %631 = call float @llvm.fabs.f32(float %628)
  %632 = fcmp olt float %631, +inf
  %633 = fcmp one float %628, 0.000000e+00
  %634 = and i1 %632, %633
  %635 = call i1 @llvm.expect.i1(i1 %634, i1 true)
  br i1 %635, label %636, label %637

636:                                              ; preds = %617
  br label %649

637:                                              ; preds = %617
  %638 = fpext float %629 to double
  %639 = fpext float %627 to double
  %640 = fpext float %621 to double
  %641 = fmul double %638, %639
  %642 = fmul double %641, %640
  %643 = fptrunc double %642 to float
  %644 = fcmp oeq float %629, 0.000000e+00
  %645 = call float @llvm.fabs.f32(float %621)
  %646 = fcmp olt float %645, +inf
  %647 = and i1 %644, %646
  %648 = select i1 %647, float 0.000000e+00, float %643
  br label %649

649:                                              ; preds = %636, %637
  %650 = phi float [ %648, %637 ], [ %630, %636 ]
  br label %651

651:                                              ; preds = %649
  %652 = add i64 %89, %57
  %653 = icmp slt i64 %652, %26
  %654 = select i1 %653, i64 %652, i64 0
  %655 = extractelement <8 x float> %514, i64 4
  %656 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %657 = getelementptr inbounds nuw i8, ptr %656, i64 %654
  %658 = load i8, ptr %657, align 1
  %659 = zext i8 %658 to i32
  %660 = shl i32 %659, 23
  %661 = bitcast i32 %660 to float
  %662 = fmul float %661, %655
  %663 = extractelement <8 x float> %160, i64 4
  %664 = fmul float %663, %662
  %665 = call float @llvm.fabs.f32(float %662)
  %666 = fcmp olt float %665, +inf
  %667 = fcmp one float %662, 0.000000e+00
  %668 = and i1 %666, %667
  %669 = call i1 @llvm.expect.i1(i1 %668, i1 true)
  br i1 %669, label %670, label %671

670:                                              ; preds = %651
  br label %683

671:                                              ; preds = %651
  %672 = fpext float %663 to double
  %673 = fpext float %661 to double
  %674 = fpext float %655 to double
  %675 = fmul double %672, %673
  %676 = fmul double %675, %674
  %677 = fptrunc double %676 to float
  %678 = fcmp oeq float %663, 0.000000e+00
  %679 = call float @llvm.fabs.f32(float %655)
  %680 = fcmp olt float %679, +inf
  %681 = and i1 %678, %680
  %682 = select i1 %681, float 0.000000e+00, float %677
  br label %683

683:                                              ; preds = %670, %671
  %684 = phi float [ %682, %671 ], [ %664, %670 ]
  br label %685

685:                                              ; preds = %683
  %686 = add i64 %89, %57
  %687 = icmp slt i64 %686, %26
  %688 = select i1 %687, i64 %686, i64 0
  %689 = extractelement <8 x float> %514, i64 5
  %690 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %691 = getelementptr inbounds nuw i8, ptr %690, i64 %688
  %692 = load i8, ptr %691, align 1
  %693 = zext i8 %692 to i32
  %694 = shl i32 %693, 23
  %695 = bitcast i32 %694 to float
  %696 = fmul float %695, %689
  %697 = extractelement <8 x float> %160, i64 5
  %698 = fmul float %697, %696
  %699 = call float @llvm.fabs.f32(float %696)
  %700 = fcmp olt float %699, +inf
  %701 = fcmp one float %696, 0.000000e+00
  %702 = and i1 %700, %701
  %703 = call i1 @llvm.expect.i1(i1 %702, i1 true)
  br i1 %703, label %704, label %705

704:                                              ; preds = %685
  br label %717

705:                                              ; preds = %685
  %706 = fpext float %697 to double
  %707 = fpext float %695 to double
  %708 = fpext float %689 to double
  %709 = fmul double %706, %707
  %710 = fmul double %709, %708
  %711 = fptrunc double %710 to float
  %712 = fcmp oeq float %697, 0.000000e+00
  %713 = call float @llvm.fabs.f32(float %689)
  %714 = fcmp olt float %713, +inf
  %715 = and i1 %712, %714
  %716 = select i1 %715, float 0.000000e+00, float %711
  br label %717

717:                                              ; preds = %704, %705
  %718 = phi float [ %716, %705 ], [ %698, %704 ]
  br label %719

719:                                              ; preds = %717
  %720 = add i64 %89, %57
  %721 = icmp slt i64 %720, %26
  %722 = select i1 %721, i64 %720, i64 0
  %723 = extractelement <8 x float> %514, i64 6
  %724 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %725 = getelementptr inbounds nuw i8, ptr %724, i64 %722
  %726 = load i8, ptr %725, align 1
  %727 = zext i8 %726 to i32
  %728 = shl i32 %727, 23
  %729 = bitcast i32 %728 to float
  %730 = fmul float %729, %723
  %731 = extractelement <8 x float> %160, i64 6
  %732 = fmul float %731, %730
  %733 = call float @llvm.fabs.f32(float %730)
  %734 = fcmp olt float %733, +inf
  %735 = fcmp one float %730, 0.000000e+00
  %736 = and i1 %734, %735
  %737 = call i1 @llvm.expect.i1(i1 %736, i1 true)
  br i1 %737, label %738, label %739

738:                                              ; preds = %719
  br label %751

739:                                              ; preds = %719
  %740 = fpext float %731 to double
  %741 = fpext float %729 to double
  %742 = fpext float %723 to double
  %743 = fmul double %740, %741
  %744 = fmul double %743, %742
  %745 = fptrunc double %744 to float
  %746 = fcmp oeq float %731, 0.000000e+00
  %747 = call float @llvm.fabs.f32(float %723)
  %748 = fcmp olt float %747, +inf
  %749 = and i1 %746, %748
  %750 = select i1 %749, float 0.000000e+00, float %745
  br label %751

751:                                              ; preds = %738, %739
  %752 = phi float [ %750, %739 ], [ %732, %738 ]
  br label %753

753:                                              ; preds = %751
  %754 = add i64 %89, %57
  %755 = icmp slt i64 %754, %26
  %756 = select i1 %755, i64 %754, i64 0
  %757 = extractelement <8 x float> %514, i64 7
  %758 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %759 = getelementptr inbounds nuw i8, ptr %758, i64 %756
  %760 = load i8, ptr %759, align 1
  %761 = zext i8 %760 to i32
  %762 = shl i32 %761, 23
  %763 = bitcast i32 %762 to float
  %764 = fmul float %763, %757
  %765 = extractelement <8 x float> %160, i64 7
  %766 = fmul float %765, %764
  %767 = call float @llvm.fabs.f32(float %764)
  %768 = fcmp olt float %767, +inf
  %769 = fcmp one float %764, 0.000000e+00
  %770 = and i1 %768, %769
  %771 = call i1 @llvm.expect.i1(i1 %770, i1 true)
  br i1 %771, label %772, label %773

772:                                              ; preds = %753
  br label %785

773:                                              ; preds = %753
  %774 = fpext float %765 to double
  %775 = fpext float %763 to double
  %776 = fpext float %757 to double
  %777 = fmul double %774, %775
  %778 = fmul double %777, %776
  %779 = fptrunc double %778 to float
  %780 = fcmp oeq float %765, 0.000000e+00
  %781 = call float @llvm.fabs.f32(float %757)
  %782 = fcmp olt float %781, +inf
  %783 = and i1 %780, %782
  %784 = select i1 %783, float 0.000000e+00, float %779
  br label %785

785:                                              ; preds = %772, %773
  %786 = phi float [ %784, %773 ], [ %766, %772 ]
  br label %787

787:                                              ; preds = %785
  %788 = mul i64 %59, 16
  %789 = mul i64 %58, 8
  %790 = add i64 %788, %789
  %791 = mul i64 %790, 40
  %792 = add i64 %791, %57
  %793 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %792
  store float %548, ptr addrspace(3) %793, align 4
  %794 = mul i64 %58, 8
  %795 = add i64 %794, 1
  %796 = add i64 %788, %795
  %797 = mul i64 %796, 40
  %798 = add i64 %797, %57
  %799 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %798
  store float %582, ptr addrspace(3) %799, align 4
  %800 = mul i64 %58, 8
  %801 = add i64 %800, 2
  %802 = add i64 %788, %801
  %803 = mul i64 %802, 40
  %804 = add i64 %803, %57
  %805 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %804
  store float %616, ptr addrspace(3) %805, align 4
  %806 = mul i64 %58, 8
  %807 = add i64 %806, 3
  %808 = add i64 %788, %807
  %809 = mul i64 %808, 40
  %810 = add i64 %809, %57
  %811 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %810
  store float %650, ptr addrspace(3) %811, align 4
  %812 = mul i64 %58, 8
  %813 = add i64 %812, 4
  %814 = add i64 %788, %813
  %815 = mul i64 %814, 40
  %816 = add i64 %815, %57
  %817 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %816
  store float %684, ptr addrspace(3) %817, align 4
  %818 = mul i64 %58, 8
  %819 = add i64 %818, 5
  %820 = add i64 %788, %819
  %821 = mul i64 %820, 40
  %822 = add i64 %821, %57
  %823 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %822
  store float %718, ptr addrspace(3) %823, align 4
  %824 = mul i64 %58, 8
  %825 = add i64 %824, 6
  %826 = add i64 %788, %825
  %827 = mul i64 %826, 40
  %828 = add i64 %827, %57
  %829 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %828
  store float %752, ptr addrspace(3) %829, align 4
  %830 = mul i64 %58, 8
  %831 = add i64 %830, 7
  %832 = add i64 %788, %831
  %833 = mul i64 %832, 40
  %834 = add i64 %833, %57
  %835 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %834
  store float %786, ptr addrspace(3) %835, align 4
  %836 = mul i64 %58, 8
  %837 = add i64 %82, %836
  %838 = add i64 %91, %57
  %839 = add i64 %837, 7
  %840 = icmp ult i64 %838, %26
  %841 = icmp ult i64 %839, %25
  %842 = and i1 %841, %840
  %843 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %844 = ptrtoint ptr %843 to i64
  %845 = mul i64 %837, 4
  %846 = add i64 %844, %845
  %847 = urem i64 %846, 16
  %848 = icmp eq i64 %847, 0
  %849 = and i1 %842, %848
  br i1 %849, label %850, label %859

850:                                              ; preds = %787
  %851 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %852 = getelementptr float, ptr %851, i64 %837
  %853 = load <4 x float>, ptr %852, align 16
  %854 = add i64 %837, 4
  %855 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %856 = getelementptr float, ptr %855, i64 %854
  %857 = load <4 x float>, ptr %856, align 16
  %858 = shufflevector <4 x float> %853, <4 x float> %857, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %931

859:                                              ; preds = %787
  %860 = mul i64 %58, 8
  %861 = add i64 %82, %860
  %862 = icmp slt i64 %861, %25
  %863 = select i1 %862, i64 %861, i64 0
  %864 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %865 = getelementptr inbounds nuw float, ptr %864, i64 %863
  %866 = load float, ptr %865, align 4
  %867 = insertelement <8 x float> zeroinitializer, float %866, i64 0
  %868 = mul i64 %58, 8
  %869 = add i64 %868, 1
  %870 = add i64 %82, %869
  %871 = icmp slt i64 %870, %25
  %872 = select i1 %871, i64 %870, i64 0
  %873 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %874 = getelementptr inbounds nuw float, ptr %873, i64 %872
  %875 = load float, ptr %874, align 4
  %876 = insertelement <8 x float> %867, float %875, i64 1
  %877 = mul i64 %58, 8
  %878 = add i64 %877, 2
  %879 = add i64 %82, %878
  %880 = icmp slt i64 %879, %25
  %881 = select i1 %880, i64 %879, i64 0
  %882 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %883 = getelementptr inbounds nuw float, ptr %882, i64 %881
  %884 = load float, ptr %883, align 4
  %885 = insertelement <8 x float> %876, float %884, i64 2
  %886 = mul i64 %58, 8
  %887 = add i64 %886, 3
  %888 = add i64 %82, %887
  %889 = icmp slt i64 %888, %25
  %890 = select i1 %889, i64 %888, i64 0
  %891 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %892 = getelementptr inbounds nuw float, ptr %891, i64 %890
  %893 = load float, ptr %892, align 4
  %894 = insertelement <8 x float> %885, float %893, i64 3
  %895 = mul i64 %58, 8
  %896 = add i64 %895, 4
  %897 = add i64 %82, %896
  %898 = icmp slt i64 %897, %25
  %899 = select i1 %898, i64 %897, i64 0
  %900 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %901 = getelementptr inbounds nuw float, ptr %900, i64 %899
  %902 = load float, ptr %901, align 4
  %903 = insertelement <8 x float> %894, float %902, i64 4
  %904 = mul i64 %58, 8
  %905 = add i64 %904, 5
  %906 = add i64 %82, %905
  %907 = icmp slt i64 %906, %25
  %908 = select i1 %907, i64 %906, i64 0
  %909 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %910 = getelementptr inbounds nuw float, ptr %909, i64 %908
  %911 = load float, ptr %910, align 4
  %912 = insertelement <8 x float> %903, float %911, i64 5
  %913 = mul i64 %58, 8
  %914 = add i64 %913, 6
  %915 = add i64 %82, %914
  %916 = icmp slt i64 %915, %25
  %917 = select i1 %916, i64 %915, i64 0
  %918 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %919 = getelementptr inbounds nuw float, ptr %918, i64 %917
  %920 = load float, ptr %919, align 4
  %921 = insertelement <8 x float> %912, float %920, i64 6
  %922 = mul i64 %58, 8
  %923 = add i64 %922, 7
  %924 = add i64 %82, %923
  %925 = icmp slt i64 %924, %25
  %926 = select i1 %925, i64 %924, i64 0
  %927 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %928 = getelementptr inbounds nuw float, ptr %927, i64 %926
  %929 = load float, ptr %928, align 4
  %930 = insertelement <8 x float> %921, float %929, i64 7
  br label %931

931:                                              ; preds = %850, %859
  %932 = phi <8 x float> [ %930, %859 ], [ %858, %850 ]
  br label %933

933:                                              ; preds = %931
  %934 = add i64 %91, %57
  %935 = icmp slt i64 %934, %26
  %936 = select i1 %935, i64 %934, i64 0
  %937 = extractelement <8 x float> %932, i64 0
  %938 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %939 = getelementptr inbounds nuw i8, ptr %938, i64 %936
  %940 = load i8, ptr %939, align 1
  %941 = zext i8 %940 to i32
  %942 = shl i32 %941, 23
  %943 = bitcast i32 %942 to float
  %944 = fmul float %943, %937
  %945 = extractelement <8 x float> %161, i64 0
  %946 = fmul float %945, %944
  %947 = call float @llvm.fabs.f32(float %944)
  %948 = fcmp olt float %947, +inf
  %949 = fcmp one float %944, 0.000000e+00
  %950 = and i1 %948, %949
  %951 = call i1 @llvm.expect.i1(i1 %950, i1 true)
  br i1 %951, label %952, label %953

952:                                              ; preds = %933
  br label %965

953:                                              ; preds = %933
  %954 = fpext float %945 to double
  %955 = fpext float %943 to double
  %956 = fpext float %937 to double
  %957 = fmul double %954, %955
  %958 = fmul double %957, %956
  %959 = fptrunc double %958 to float
  %960 = fcmp oeq float %945, 0.000000e+00
  %961 = call float @llvm.fabs.f32(float %937)
  %962 = fcmp olt float %961, +inf
  %963 = and i1 %960, %962
  %964 = select i1 %963, float 0.000000e+00, float %959
  br label %965

965:                                              ; preds = %952, %953
  %966 = phi float [ %964, %953 ], [ %946, %952 ]
  br label %967

967:                                              ; preds = %965
  %968 = add i64 %91, %57
  %969 = icmp slt i64 %968, %26
  %970 = select i1 %969, i64 %968, i64 0
  %971 = extractelement <8 x float> %932, i64 1
  %972 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %973 = getelementptr inbounds nuw i8, ptr %972, i64 %970
  %974 = load i8, ptr %973, align 1
  %975 = zext i8 %974 to i32
  %976 = shl i32 %975, 23
  %977 = bitcast i32 %976 to float
  %978 = fmul float %977, %971
  %979 = extractelement <8 x float> %161, i64 1
  %980 = fmul float %979, %978
  %981 = call float @llvm.fabs.f32(float %978)
  %982 = fcmp olt float %981, +inf
  %983 = fcmp one float %978, 0.000000e+00
  %984 = and i1 %982, %983
  %985 = call i1 @llvm.expect.i1(i1 %984, i1 true)
  br i1 %985, label %986, label %987

986:                                              ; preds = %967
  br label %999

987:                                              ; preds = %967
  %988 = fpext float %979 to double
  %989 = fpext float %977 to double
  %990 = fpext float %971 to double
  %991 = fmul double %988, %989
  %992 = fmul double %991, %990
  %993 = fptrunc double %992 to float
  %994 = fcmp oeq float %979, 0.000000e+00
  %995 = call float @llvm.fabs.f32(float %971)
  %996 = fcmp olt float %995, +inf
  %997 = and i1 %994, %996
  %998 = select i1 %997, float 0.000000e+00, float %993
  br label %999

999:                                              ; preds = %986, %987
  %1000 = phi float [ %998, %987 ], [ %980, %986 ]
  br label %1001

1001:                                             ; preds = %999
  %1002 = add i64 %91, %57
  %1003 = icmp slt i64 %1002, %26
  %1004 = select i1 %1003, i64 %1002, i64 0
  %1005 = extractelement <8 x float> %932, i64 2
  %1006 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1007 = getelementptr inbounds nuw i8, ptr %1006, i64 %1004
  %1008 = load i8, ptr %1007, align 1
  %1009 = zext i8 %1008 to i32
  %1010 = shl i32 %1009, 23
  %1011 = bitcast i32 %1010 to float
  %1012 = fmul float %1011, %1005
  %1013 = extractelement <8 x float> %161, i64 2
  %1014 = fmul float %1013, %1012
  %1015 = call float @llvm.fabs.f32(float %1012)
  %1016 = fcmp olt float %1015, +inf
  %1017 = fcmp one float %1012, 0.000000e+00
  %1018 = and i1 %1016, %1017
  %1019 = call i1 @llvm.expect.i1(i1 %1018, i1 true)
  br i1 %1019, label %1020, label %1021

1020:                                             ; preds = %1001
  br label %1033

1021:                                             ; preds = %1001
  %1022 = fpext float %1013 to double
  %1023 = fpext float %1011 to double
  %1024 = fpext float %1005 to double
  %1025 = fmul double %1022, %1023
  %1026 = fmul double %1025, %1024
  %1027 = fptrunc double %1026 to float
  %1028 = fcmp oeq float %1013, 0.000000e+00
  %1029 = call float @llvm.fabs.f32(float %1005)
  %1030 = fcmp olt float %1029, +inf
  %1031 = and i1 %1028, %1030
  %1032 = select i1 %1031, float 0.000000e+00, float %1027
  br label %1033

1033:                                             ; preds = %1020, %1021
  %1034 = phi float [ %1032, %1021 ], [ %1014, %1020 ]
  br label %1035

1035:                                             ; preds = %1033
  %1036 = add i64 %91, %57
  %1037 = icmp slt i64 %1036, %26
  %1038 = select i1 %1037, i64 %1036, i64 0
  %1039 = extractelement <8 x float> %932, i64 3
  %1040 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1041 = getelementptr inbounds nuw i8, ptr %1040, i64 %1038
  %1042 = load i8, ptr %1041, align 1
  %1043 = zext i8 %1042 to i32
  %1044 = shl i32 %1043, 23
  %1045 = bitcast i32 %1044 to float
  %1046 = fmul float %1045, %1039
  %1047 = extractelement <8 x float> %161, i64 3
  %1048 = fmul float %1047, %1046
  %1049 = call float @llvm.fabs.f32(float %1046)
  %1050 = fcmp olt float %1049, +inf
  %1051 = fcmp one float %1046, 0.000000e+00
  %1052 = and i1 %1050, %1051
  %1053 = call i1 @llvm.expect.i1(i1 %1052, i1 true)
  br i1 %1053, label %1054, label %1055

1054:                                             ; preds = %1035
  br label %1067

1055:                                             ; preds = %1035
  %1056 = fpext float %1047 to double
  %1057 = fpext float %1045 to double
  %1058 = fpext float %1039 to double
  %1059 = fmul double %1056, %1057
  %1060 = fmul double %1059, %1058
  %1061 = fptrunc double %1060 to float
  %1062 = fcmp oeq float %1047, 0.000000e+00
  %1063 = call float @llvm.fabs.f32(float %1039)
  %1064 = fcmp olt float %1063, +inf
  %1065 = and i1 %1062, %1064
  %1066 = select i1 %1065, float 0.000000e+00, float %1061
  br label %1067

1067:                                             ; preds = %1054, %1055
  %1068 = phi float [ %1066, %1055 ], [ %1048, %1054 ]
  br label %1069

1069:                                             ; preds = %1067
  %1070 = add i64 %91, %57
  %1071 = icmp slt i64 %1070, %26
  %1072 = select i1 %1071, i64 %1070, i64 0
  %1073 = extractelement <8 x float> %932, i64 4
  %1074 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1075 = getelementptr inbounds nuw i8, ptr %1074, i64 %1072
  %1076 = load i8, ptr %1075, align 1
  %1077 = zext i8 %1076 to i32
  %1078 = shl i32 %1077, 23
  %1079 = bitcast i32 %1078 to float
  %1080 = fmul float %1079, %1073
  %1081 = extractelement <8 x float> %161, i64 4
  %1082 = fmul float %1081, %1080
  %1083 = call float @llvm.fabs.f32(float %1080)
  %1084 = fcmp olt float %1083, +inf
  %1085 = fcmp one float %1080, 0.000000e+00
  %1086 = and i1 %1084, %1085
  %1087 = call i1 @llvm.expect.i1(i1 %1086, i1 true)
  br i1 %1087, label %1088, label %1089

1088:                                             ; preds = %1069
  br label %1101

1089:                                             ; preds = %1069
  %1090 = fpext float %1081 to double
  %1091 = fpext float %1079 to double
  %1092 = fpext float %1073 to double
  %1093 = fmul double %1090, %1091
  %1094 = fmul double %1093, %1092
  %1095 = fptrunc double %1094 to float
  %1096 = fcmp oeq float %1081, 0.000000e+00
  %1097 = call float @llvm.fabs.f32(float %1073)
  %1098 = fcmp olt float %1097, +inf
  %1099 = and i1 %1096, %1098
  %1100 = select i1 %1099, float 0.000000e+00, float %1095
  br label %1101

1101:                                             ; preds = %1088, %1089
  %1102 = phi float [ %1100, %1089 ], [ %1082, %1088 ]
  br label %1103

1103:                                             ; preds = %1101
  %1104 = add i64 %91, %57
  %1105 = icmp slt i64 %1104, %26
  %1106 = select i1 %1105, i64 %1104, i64 0
  %1107 = extractelement <8 x float> %932, i64 5
  %1108 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1109 = getelementptr inbounds nuw i8, ptr %1108, i64 %1106
  %1110 = load i8, ptr %1109, align 1
  %1111 = zext i8 %1110 to i32
  %1112 = shl i32 %1111, 23
  %1113 = bitcast i32 %1112 to float
  %1114 = fmul float %1113, %1107
  %1115 = extractelement <8 x float> %161, i64 5
  %1116 = fmul float %1115, %1114
  %1117 = call float @llvm.fabs.f32(float %1114)
  %1118 = fcmp olt float %1117, +inf
  %1119 = fcmp one float %1114, 0.000000e+00
  %1120 = and i1 %1118, %1119
  %1121 = call i1 @llvm.expect.i1(i1 %1120, i1 true)
  br i1 %1121, label %1122, label %1123

1122:                                             ; preds = %1103
  br label %1135

1123:                                             ; preds = %1103
  %1124 = fpext float %1115 to double
  %1125 = fpext float %1113 to double
  %1126 = fpext float %1107 to double
  %1127 = fmul double %1124, %1125
  %1128 = fmul double %1127, %1126
  %1129 = fptrunc double %1128 to float
  %1130 = fcmp oeq float %1115, 0.000000e+00
  %1131 = call float @llvm.fabs.f32(float %1107)
  %1132 = fcmp olt float %1131, +inf
  %1133 = and i1 %1130, %1132
  %1134 = select i1 %1133, float 0.000000e+00, float %1129
  br label %1135

1135:                                             ; preds = %1122, %1123
  %1136 = phi float [ %1134, %1123 ], [ %1116, %1122 ]
  br label %1137

1137:                                             ; preds = %1135
  %1138 = add i64 %91, %57
  %1139 = icmp slt i64 %1138, %26
  %1140 = select i1 %1139, i64 %1138, i64 0
  %1141 = extractelement <8 x float> %932, i64 6
  %1142 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1143 = getelementptr inbounds nuw i8, ptr %1142, i64 %1140
  %1144 = load i8, ptr %1143, align 1
  %1145 = zext i8 %1144 to i32
  %1146 = shl i32 %1145, 23
  %1147 = bitcast i32 %1146 to float
  %1148 = fmul float %1147, %1141
  %1149 = extractelement <8 x float> %161, i64 6
  %1150 = fmul float %1149, %1148
  %1151 = call float @llvm.fabs.f32(float %1148)
  %1152 = fcmp olt float %1151, +inf
  %1153 = fcmp one float %1148, 0.000000e+00
  %1154 = and i1 %1152, %1153
  %1155 = call i1 @llvm.expect.i1(i1 %1154, i1 true)
  br i1 %1155, label %1156, label %1157

1156:                                             ; preds = %1137
  br label %1169

1157:                                             ; preds = %1137
  %1158 = fpext float %1149 to double
  %1159 = fpext float %1147 to double
  %1160 = fpext float %1141 to double
  %1161 = fmul double %1158, %1159
  %1162 = fmul double %1161, %1160
  %1163 = fptrunc double %1162 to float
  %1164 = fcmp oeq float %1149, 0.000000e+00
  %1165 = call float @llvm.fabs.f32(float %1141)
  %1166 = fcmp olt float %1165, +inf
  %1167 = and i1 %1164, %1166
  %1168 = select i1 %1167, float 0.000000e+00, float %1163
  br label %1169

1169:                                             ; preds = %1156, %1157
  %1170 = phi float [ %1168, %1157 ], [ %1150, %1156 ]
  br label %1171

1171:                                             ; preds = %1169
  %1172 = add i64 %91, %57
  %1173 = icmp slt i64 %1172, %26
  %1174 = select i1 %1173, i64 %1172, i64 0
  %1175 = extractelement <8 x float> %932, i64 7
  %1176 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1177 = getelementptr inbounds nuw i8, ptr %1176, i64 %1174
  %1178 = load i8, ptr %1177, align 1
  %1179 = zext i8 %1178 to i32
  %1180 = shl i32 %1179, 23
  %1181 = bitcast i32 %1180 to float
  %1182 = fmul float %1181, %1175
  %1183 = extractelement <8 x float> %161, i64 7
  %1184 = fmul float %1183, %1182
  %1185 = call float @llvm.fabs.f32(float %1182)
  %1186 = fcmp olt float %1185, +inf
  %1187 = fcmp one float %1182, 0.000000e+00
  %1188 = and i1 %1186, %1187
  %1189 = call i1 @llvm.expect.i1(i1 %1188, i1 true)
  br i1 %1189, label %1190, label %1191

1190:                                             ; preds = %1171
  br label %1203

1191:                                             ; preds = %1171
  %1192 = fpext float %1183 to double
  %1193 = fpext float %1181 to double
  %1194 = fpext float %1175 to double
  %1195 = fmul double %1192, %1193
  %1196 = fmul double %1195, %1194
  %1197 = fptrunc double %1196 to float
  %1198 = fcmp oeq float %1183, 0.000000e+00
  %1199 = call float @llvm.fabs.f32(float %1175)
  %1200 = fcmp olt float %1199, +inf
  %1201 = and i1 %1198, %1200
  %1202 = select i1 %1201, float 0.000000e+00, float %1197
  br label %1203

1203:                                             ; preds = %1190, %1191
  %1204 = phi float [ %1202, %1191 ], [ %1184, %1190 ]
  br label %1205

1205:                                             ; preds = %1203
  %1206 = mul i64 %59, 16
  %1207 = mul i64 %58, 8
  %1208 = add i64 %1206, %1207
  %1209 = add i64 %57, 16
  %1210 = mul i64 %1208, 40
  %1211 = add i64 %1210, %1209
  %1212 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1211
  store float %966, ptr addrspace(3) %1212, align 4
  %1213 = mul i64 %58, 8
  %1214 = add i64 %1213, 1
  %1215 = add i64 %1206, %1214
  %1216 = add i64 %57, 16
  %1217 = mul i64 %1215, 40
  %1218 = add i64 %1217, %1216
  %1219 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1218
  store float %1000, ptr addrspace(3) %1219, align 4
  %1220 = mul i64 %58, 8
  %1221 = add i64 %1220, 2
  %1222 = add i64 %1206, %1221
  %1223 = add i64 %57, 16
  %1224 = mul i64 %1222, 40
  %1225 = add i64 %1224, %1223
  %1226 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1225
  store float %1034, ptr addrspace(3) %1226, align 4
  %1227 = mul i64 %58, 8
  %1228 = add i64 %1227, 3
  %1229 = add i64 %1206, %1228
  %1230 = add i64 %57, 16
  %1231 = mul i64 %1229, 40
  %1232 = add i64 %1231, %1230
  %1233 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1232
  store float %1068, ptr addrspace(3) %1233, align 4
  %1234 = mul i64 %58, 8
  %1235 = add i64 %1234, 4
  %1236 = add i64 %1206, %1235
  %1237 = add i64 %57, 16
  %1238 = mul i64 %1236, 40
  %1239 = add i64 %1238, %1237
  %1240 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1239
  store float %1102, ptr addrspace(3) %1240, align 4
  %1241 = mul i64 %58, 8
  %1242 = add i64 %1241, 5
  %1243 = add i64 %1206, %1242
  %1244 = add i64 %57, 16
  %1245 = mul i64 %1243, 40
  %1246 = add i64 %1245, %1244
  %1247 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1246
  store float %1136, ptr addrspace(3) %1247, align 4
  %1248 = mul i64 %58, 8
  %1249 = add i64 %1248, 6
  %1250 = add i64 %1206, %1249
  %1251 = add i64 %57, 16
  %1252 = mul i64 %1250, 40
  %1253 = add i64 %1252, %1251
  %1254 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1253
  store float %1170, ptr addrspace(3) %1254, align 4
  %1255 = mul i64 %58, 8
  %1256 = add i64 %1255, 7
  %1257 = add i64 %1206, %1256
  %1258 = add i64 %57, 16
  %1259 = mul i64 %1257, 40
  %1260 = add i64 %1259, %1258
  %1261 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1260
  store float %1204, ptr addrspace(3) %1261, align 4
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %1262 = mul i64 %55, 8
  %1263 = udiv i64 %1262, 32
  %1264 = urem i64 %1262, 32
  %1265 = udiv i64 %1263, 16
  %1266 = urem i64 %1263, 16
  %1267 = udiv i64 %1265, 2
  %1268 = mul i64 %1267, 4
  %1269 = mul i64 %1268, 16
  %1270 = add i64 %1266, %1269
  %1271 = add i64 %78, %1270
  %1272 = urem i64 %1265, 2
  %1273 = mul i64 %1272, 32
  %1274 = add i64 %1264, %1273
  %1275 = add i64 %79, %1274
  %1276 = mul i64 %1263, 40
  %1277 = add i64 %1276, %1264
  %1278 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1277
  %1279 = load <8 x float>, ptr addrspace(3) %1278, align 16
  %1280 = fptrunc <8 x float> %1279 to <8 x bfloat>
  %1281 = mul i64 %1271, %26
  %1282 = add i64 %1281, %1275
  %1283 = icmp ult i64 %1271, %25
  %1284 = add i64 %1275, 7
  %1285 = icmp ult i64 %1284, %26
  %1286 = and i1 %1283, %1285
  br i1 %1286, label %1287, label %1290

1287:                                             ; preds = %1205
  %1288 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1289 = getelementptr bfloat, ptr %1288, i64 %1282
  store <8 x bfloat> %1280, ptr %1289, align 2
  br label %1361

1290:                                             ; preds = %1205
  %1291 = icmp ult i64 %1275, %26
  %1292 = and i1 %1283, %1291
  br i1 %1292, label %1293, label %1297

1293:                                             ; preds = %1290
  %1294 = extractelement <8 x bfloat> %1280, i64 0
  %1295 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1296 = getelementptr inbounds nuw bfloat, ptr %1295, i64 %1282
  store bfloat %1294, ptr %1296, align 2
  br label %1297

1297:                                             ; preds = %1293, %1290
  %1298 = add i64 %1275, 1
  %1299 = icmp ult i64 %1298, %26
  %1300 = and i1 %1283, %1299
  br i1 %1300, label %1301, label %1306

1301:                                             ; preds = %1297
  %1302 = add i64 %1282, 1
  %1303 = extractelement <8 x bfloat> %1280, i64 1
  %1304 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1305 = getelementptr inbounds nuw bfloat, ptr %1304, i64 %1302
  store bfloat %1303, ptr %1305, align 2
  br label %1306

1306:                                             ; preds = %1301, %1297
  %1307 = add i64 %1275, 2
  %1308 = icmp ult i64 %1307, %26
  %1309 = and i1 %1283, %1308
  br i1 %1309, label %1310, label %1315

1310:                                             ; preds = %1306
  %1311 = add i64 %1282, 2
  %1312 = extractelement <8 x bfloat> %1280, i64 2
  %1313 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1314 = getelementptr inbounds nuw bfloat, ptr %1313, i64 %1311
  store bfloat %1312, ptr %1314, align 2
  br label %1315

1315:                                             ; preds = %1310, %1306
  %1316 = add i64 %1275, 3
  %1317 = icmp ult i64 %1316, %26
  %1318 = and i1 %1283, %1317
  br i1 %1318, label %1319, label %1324

1319:                                             ; preds = %1315
  %1320 = add i64 %1282, 3
  %1321 = extractelement <8 x bfloat> %1280, i64 3
  %1322 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1323 = getelementptr inbounds nuw bfloat, ptr %1322, i64 %1320
  store bfloat %1321, ptr %1323, align 2
  br label %1324

1324:                                             ; preds = %1319, %1315
  %1325 = add i64 %1275, 4
  %1326 = icmp ult i64 %1325, %26
  %1327 = and i1 %1283, %1326
  br i1 %1327, label %1328, label %1333

1328:                                             ; preds = %1324
  %1329 = add i64 %1282, 4
  %1330 = extractelement <8 x bfloat> %1280, i64 4
  %1331 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1332 = getelementptr inbounds nuw bfloat, ptr %1331, i64 %1329
  store bfloat %1330, ptr %1332, align 2
  br label %1333

1333:                                             ; preds = %1328, %1324
  %1334 = add i64 %1275, 5
  %1335 = icmp ult i64 %1334, %26
  %1336 = and i1 %1283, %1335
  br i1 %1336, label %1337, label %1342

1337:                                             ; preds = %1333
  %1338 = add i64 %1282, 5
  %1339 = extractelement <8 x bfloat> %1280, i64 5
  %1340 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1341 = getelementptr inbounds nuw bfloat, ptr %1340, i64 %1338
  store bfloat %1339, ptr %1341, align 2
  br label %1342

1342:                                             ; preds = %1337, %1333
  %1343 = add i64 %1275, 6
  %1344 = icmp ult i64 %1343, %26
  %1345 = and i1 %1283, %1344
  br i1 %1345, label %1346, label %1351

1346:                                             ; preds = %1342
  %1347 = add i64 %1282, 6
  %1348 = extractelement <8 x bfloat> %1280, i64 6
  %1349 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1350 = getelementptr inbounds nuw bfloat, ptr %1349, i64 %1347
  store bfloat %1348, ptr %1350, align 2
  br label %1351

1351:                                             ; preds = %1346, %1342
  %1352 = add i64 %1275, 7
  %1353 = icmp ult i64 %1352, %26
  %1354 = and i1 %1283, %1353
  br i1 %1354, label %1355, label %1360

1355:                                             ; preds = %1351
  %1356 = add i64 %1282, 7
  %1357 = extractelement <8 x bfloat> %1280, i64 7
  %1358 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1359 = getelementptr inbounds nuw bfloat, ptr %1358, i64 %1356
  store bfloat %1357, ptr %1359, align 2
  br label %1360

1360:                                             ; preds = %1355, %1351
  br label %1361

1361:                                             ; preds = %1287, %1360
  %1362 = mul i64 %55, 8
  %1363 = add i64 %1362, 2048
  %1364 = udiv i64 %1363, 32
  %1365 = urem i64 %1363, 32
  %1366 = udiv i64 %1364, 16
  %1367 = urem i64 %1364, 16
  %1368 = udiv i64 %1366, 2
  %1369 = mul i64 %1368, 4
  %1370 = mul i64 %1369, 16
  %1371 = add i64 %1367, %1370
  %1372 = add i64 %78, %1371
  %1373 = urem i64 %1366, 2
  %1374 = mul i64 %1373, 32
  %1375 = add i64 %1365, %1374
  %1376 = add i64 %79, %1375
  %1377 = mul i64 %1364, 40
  %1378 = add i64 %1377, %1365
  %1379 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1378
  %1380 = load <8 x float>, ptr addrspace(3) %1379, align 16
  %1381 = fptrunc <8 x float> %1380 to <8 x bfloat>
  %1382 = mul i64 %1372, %26
  %1383 = add i64 %1382, %1376
  %1384 = icmp ult i64 %1372, %25
  %1385 = add i64 %1376, 7
  %1386 = icmp ult i64 %1385, %26
  %1387 = and i1 %1384, %1386
  br i1 %1387, label %1388, label %1391

1388:                                             ; preds = %1361
  %1389 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1390 = getelementptr bfloat, ptr %1389, i64 %1383
  store <8 x bfloat> %1381, ptr %1390, align 2
  br label %1462

1391:                                             ; preds = %1361
  %1392 = icmp ult i64 %1376, %26
  %1393 = and i1 %1384, %1392
  br i1 %1393, label %1394, label %1398

1394:                                             ; preds = %1391
  %1395 = extractelement <8 x bfloat> %1381, i64 0
  %1396 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1397 = getelementptr inbounds nuw bfloat, ptr %1396, i64 %1383
  store bfloat %1395, ptr %1397, align 2
  br label %1398

1398:                                             ; preds = %1394, %1391
  %1399 = add i64 %1376, 1
  %1400 = icmp ult i64 %1399, %26
  %1401 = and i1 %1384, %1400
  br i1 %1401, label %1402, label %1407

1402:                                             ; preds = %1398
  %1403 = add i64 %1383, 1
  %1404 = extractelement <8 x bfloat> %1381, i64 1
  %1405 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1406 = getelementptr inbounds nuw bfloat, ptr %1405, i64 %1403
  store bfloat %1404, ptr %1406, align 2
  br label %1407

1407:                                             ; preds = %1402, %1398
  %1408 = add i64 %1376, 2
  %1409 = icmp ult i64 %1408, %26
  %1410 = and i1 %1384, %1409
  br i1 %1410, label %1411, label %1416

1411:                                             ; preds = %1407
  %1412 = add i64 %1383, 2
  %1413 = extractelement <8 x bfloat> %1381, i64 2
  %1414 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1415 = getelementptr inbounds nuw bfloat, ptr %1414, i64 %1412
  store bfloat %1413, ptr %1415, align 2
  br label %1416

1416:                                             ; preds = %1411, %1407
  %1417 = add i64 %1376, 3
  %1418 = icmp ult i64 %1417, %26
  %1419 = and i1 %1384, %1418
  br i1 %1419, label %1420, label %1425

1420:                                             ; preds = %1416
  %1421 = add i64 %1383, 3
  %1422 = extractelement <8 x bfloat> %1381, i64 3
  %1423 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1424 = getelementptr inbounds nuw bfloat, ptr %1423, i64 %1421
  store bfloat %1422, ptr %1424, align 2
  br label %1425

1425:                                             ; preds = %1420, %1416
  %1426 = add i64 %1376, 4
  %1427 = icmp ult i64 %1426, %26
  %1428 = and i1 %1384, %1427
  br i1 %1428, label %1429, label %1434

1429:                                             ; preds = %1425
  %1430 = add i64 %1383, 4
  %1431 = extractelement <8 x bfloat> %1381, i64 4
  %1432 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1433 = getelementptr inbounds nuw bfloat, ptr %1432, i64 %1430
  store bfloat %1431, ptr %1433, align 2
  br label %1434

1434:                                             ; preds = %1429, %1425
  %1435 = add i64 %1376, 5
  %1436 = icmp ult i64 %1435, %26
  %1437 = and i1 %1384, %1436
  br i1 %1437, label %1438, label %1443

1438:                                             ; preds = %1434
  %1439 = add i64 %1383, 5
  %1440 = extractelement <8 x bfloat> %1381, i64 5
  %1441 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1442 = getelementptr inbounds nuw bfloat, ptr %1441, i64 %1439
  store bfloat %1440, ptr %1442, align 2
  br label %1443

1443:                                             ; preds = %1438, %1434
  %1444 = add i64 %1376, 6
  %1445 = icmp ult i64 %1444, %26
  %1446 = and i1 %1384, %1445
  br i1 %1446, label %1447, label %1452

1447:                                             ; preds = %1443
  %1448 = add i64 %1383, 6
  %1449 = extractelement <8 x bfloat> %1381, i64 6
  %1450 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1451 = getelementptr inbounds nuw bfloat, ptr %1450, i64 %1448
  store bfloat %1449, ptr %1451, align 2
  br label %1452

1452:                                             ; preds = %1447, %1443
  %1453 = add i64 %1376, 7
  %1454 = icmp ult i64 %1453, %26
  %1455 = and i1 %1384, %1454
  br i1 %1455, label %1456, label %1461

1456:                                             ; preds = %1452
  %1457 = add i64 %1383, 7
  %1458 = extractelement <8 x bfloat> %1381, i64 7
  %1459 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1460 = getelementptr inbounds nuw bfloat, ptr %1459, i64 %1457
  store bfloat %1458, ptr %1460, align 2
  br label %1461

1461:                                             ; preds = %1456, %1452
  br label %1462

1462:                                             ; preds = %1388, %1461
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %1463 = mul i64 %58, 8
  %1464 = add i64 %84, %1463
  %1465 = add i64 %89, %57
  %1466 = add i64 %1464, 7
  %1467 = icmp ult i64 %1465, %26
  %1468 = icmp ult i64 %1466, %25
  %1469 = and i1 %1468, %1467
  %1470 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1471 = ptrtoint ptr %1470 to i64
  %1472 = mul i64 %1464, 4
  %1473 = add i64 %1471, %1472
  %1474 = urem i64 %1473, 16
  %1475 = icmp eq i64 %1474, 0
  %1476 = and i1 %1469, %1475
  br i1 %1476, label %1477, label %1486

1477:                                             ; preds = %1462
  %1478 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1479 = getelementptr float, ptr %1478, i64 %1464
  %1480 = load <4 x float>, ptr %1479, align 16
  %1481 = add i64 %1464, 4
  %1482 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1483 = getelementptr float, ptr %1482, i64 %1481
  %1484 = load <4 x float>, ptr %1483, align 16
  %1485 = shufflevector <4 x float> %1480, <4 x float> %1484, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1558

1486:                                             ; preds = %1462
  %1487 = mul i64 %58, 8
  %1488 = add i64 %84, %1487
  %1489 = icmp slt i64 %1488, %25
  %1490 = select i1 %1489, i64 %1488, i64 0
  %1491 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1492 = getelementptr inbounds nuw float, ptr %1491, i64 %1490
  %1493 = load float, ptr %1492, align 4
  %1494 = insertelement <8 x float> zeroinitializer, float %1493, i64 0
  %1495 = mul i64 %58, 8
  %1496 = add i64 %1495, 1
  %1497 = add i64 %84, %1496
  %1498 = icmp slt i64 %1497, %25
  %1499 = select i1 %1498, i64 %1497, i64 0
  %1500 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1501 = getelementptr inbounds nuw float, ptr %1500, i64 %1499
  %1502 = load float, ptr %1501, align 4
  %1503 = insertelement <8 x float> %1494, float %1502, i64 1
  %1504 = mul i64 %58, 8
  %1505 = add i64 %1504, 2
  %1506 = add i64 %84, %1505
  %1507 = icmp slt i64 %1506, %25
  %1508 = select i1 %1507, i64 %1506, i64 0
  %1509 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1510 = getelementptr inbounds nuw float, ptr %1509, i64 %1508
  %1511 = load float, ptr %1510, align 4
  %1512 = insertelement <8 x float> %1503, float %1511, i64 2
  %1513 = mul i64 %58, 8
  %1514 = add i64 %1513, 3
  %1515 = add i64 %84, %1514
  %1516 = icmp slt i64 %1515, %25
  %1517 = select i1 %1516, i64 %1515, i64 0
  %1518 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1519 = getelementptr inbounds nuw float, ptr %1518, i64 %1517
  %1520 = load float, ptr %1519, align 4
  %1521 = insertelement <8 x float> %1512, float %1520, i64 3
  %1522 = mul i64 %58, 8
  %1523 = add i64 %1522, 4
  %1524 = add i64 %84, %1523
  %1525 = icmp slt i64 %1524, %25
  %1526 = select i1 %1525, i64 %1524, i64 0
  %1527 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1528 = getelementptr inbounds nuw float, ptr %1527, i64 %1526
  %1529 = load float, ptr %1528, align 4
  %1530 = insertelement <8 x float> %1521, float %1529, i64 4
  %1531 = mul i64 %58, 8
  %1532 = add i64 %1531, 5
  %1533 = add i64 %84, %1532
  %1534 = icmp slt i64 %1533, %25
  %1535 = select i1 %1534, i64 %1533, i64 0
  %1536 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1537 = getelementptr inbounds nuw float, ptr %1536, i64 %1535
  %1538 = load float, ptr %1537, align 4
  %1539 = insertelement <8 x float> %1530, float %1538, i64 5
  %1540 = mul i64 %58, 8
  %1541 = add i64 %1540, 6
  %1542 = add i64 %84, %1541
  %1543 = icmp slt i64 %1542, %25
  %1544 = select i1 %1543, i64 %1542, i64 0
  %1545 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1546 = getelementptr inbounds nuw float, ptr %1545, i64 %1544
  %1547 = load float, ptr %1546, align 4
  %1548 = insertelement <8 x float> %1539, float %1547, i64 6
  %1549 = mul i64 %58, 8
  %1550 = add i64 %1549, 7
  %1551 = add i64 %84, %1550
  %1552 = icmp slt i64 %1551, %25
  %1553 = select i1 %1552, i64 %1551, i64 0
  %1554 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1555 = getelementptr inbounds nuw float, ptr %1554, i64 %1553
  %1556 = load float, ptr %1555, align 4
  %1557 = insertelement <8 x float> %1548, float %1556, i64 7
  br label %1558

1558:                                             ; preds = %1477, %1486
  %1559 = phi <8 x float> [ %1557, %1486 ], [ %1485, %1477 ]
  br label %1560

1560:                                             ; preds = %1558
  %1561 = add i64 %89, %57
  %1562 = icmp slt i64 %1561, %26
  %1563 = select i1 %1562, i64 %1561, i64 0
  %1564 = extractelement <8 x float> %1559, i64 0
  %1565 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1566 = getelementptr inbounds nuw i8, ptr %1565, i64 %1563
  %1567 = load i8, ptr %1566, align 1
  %1568 = zext i8 %1567 to i32
  %1569 = shl i32 %1568, 23
  %1570 = bitcast i32 %1569 to float
  %1571 = fmul float %1570, %1564
  %1572 = extractelement <8 x float> %162, i64 0
  %1573 = fmul float %1572, %1571
  %1574 = call float @llvm.fabs.f32(float %1571)
  %1575 = fcmp olt float %1574, +inf
  %1576 = fcmp one float %1571, 0.000000e+00
  %1577 = and i1 %1575, %1576
  %1578 = call i1 @llvm.expect.i1(i1 %1577, i1 true)
  br i1 %1578, label %1579, label %1580

1579:                                             ; preds = %1560
  br label %1592

1580:                                             ; preds = %1560
  %1581 = fpext float %1572 to double
  %1582 = fpext float %1570 to double
  %1583 = fpext float %1564 to double
  %1584 = fmul double %1581, %1582
  %1585 = fmul double %1584, %1583
  %1586 = fptrunc double %1585 to float
  %1587 = fcmp oeq float %1572, 0.000000e+00
  %1588 = call float @llvm.fabs.f32(float %1564)
  %1589 = fcmp olt float %1588, +inf
  %1590 = and i1 %1587, %1589
  %1591 = select i1 %1590, float 0.000000e+00, float %1586
  br label %1592

1592:                                             ; preds = %1579, %1580
  %1593 = phi float [ %1591, %1580 ], [ %1573, %1579 ]
  br label %1594

1594:                                             ; preds = %1592
  %1595 = add i64 %89, %57
  %1596 = icmp slt i64 %1595, %26
  %1597 = select i1 %1596, i64 %1595, i64 0
  %1598 = extractelement <8 x float> %1559, i64 1
  %1599 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1600 = getelementptr inbounds nuw i8, ptr %1599, i64 %1597
  %1601 = load i8, ptr %1600, align 1
  %1602 = zext i8 %1601 to i32
  %1603 = shl i32 %1602, 23
  %1604 = bitcast i32 %1603 to float
  %1605 = fmul float %1604, %1598
  %1606 = extractelement <8 x float> %162, i64 1
  %1607 = fmul float %1606, %1605
  %1608 = call float @llvm.fabs.f32(float %1605)
  %1609 = fcmp olt float %1608, +inf
  %1610 = fcmp one float %1605, 0.000000e+00
  %1611 = and i1 %1609, %1610
  %1612 = call i1 @llvm.expect.i1(i1 %1611, i1 true)
  br i1 %1612, label %1613, label %1614

1613:                                             ; preds = %1594
  br label %1626

1614:                                             ; preds = %1594
  %1615 = fpext float %1606 to double
  %1616 = fpext float %1604 to double
  %1617 = fpext float %1598 to double
  %1618 = fmul double %1615, %1616
  %1619 = fmul double %1618, %1617
  %1620 = fptrunc double %1619 to float
  %1621 = fcmp oeq float %1606, 0.000000e+00
  %1622 = call float @llvm.fabs.f32(float %1598)
  %1623 = fcmp olt float %1622, +inf
  %1624 = and i1 %1621, %1623
  %1625 = select i1 %1624, float 0.000000e+00, float %1620
  br label %1626

1626:                                             ; preds = %1613, %1614
  %1627 = phi float [ %1625, %1614 ], [ %1607, %1613 ]
  br label %1628

1628:                                             ; preds = %1626
  %1629 = add i64 %89, %57
  %1630 = icmp slt i64 %1629, %26
  %1631 = select i1 %1630, i64 %1629, i64 0
  %1632 = extractelement <8 x float> %1559, i64 2
  %1633 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1634 = getelementptr inbounds nuw i8, ptr %1633, i64 %1631
  %1635 = load i8, ptr %1634, align 1
  %1636 = zext i8 %1635 to i32
  %1637 = shl i32 %1636, 23
  %1638 = bitcast i32 %1637 to float
  %1639 = fmul float %1638, %1632
  %1640 = extractelement <8 x float> %162, i64 2
  %1641 = fmul float %1640, %1639
  %1642 = call float @llvm.fabs.f32(float %1639)
  %1643 = fcmp olt float %1642, +inf
  %1644 = fcmp one float %1639, 0.000000e+00
  %1645 = and i1 %1643, %1644
  %1646 = call i1 @llvm.expect.i1(i1 %1645, i1 true)
  br i1 %1646, label %1647, label %1648

1647:                                             ; preds = %1628
  br label %1660

1648:                                             ; preds = %1628
  %1649 = fpext float %1640 to double
  %1650 = fpext float %1638 to double
  %1651 = fpext float %1632 to double
  %1652 = fmul double %1649, %1650
  %1653 = fmul double %1652, %1651
  %1654 = fptrunc double %1653 to float
  %1655 = fcmp oeq float %1640, 0.000000e+00
  %1656 = call float @llvm.fabs.f32(float %1632)
  %1657 = fcmp olt float %1656, +inf
  %1658 = and i1 %1655, %1657
  %1659 = select i1 %1658, float 0.000000e+00, float %1654
  br label %1660

1660:                                             ; preds = %1647, %1648
  %1661 = phi float [ %1659, %1648 ], [ %1641, %1647 ]
  br label %1662

1662:                                             ; preds = %1660
  %1663 = add i64 %89, %57
  %1664 = icmp slt i64 %1663, %26
  %1665 = select i1 %1664, i64 %1663, i64 0
  %1666 = extractelement <8 x float> %1559, i64 3
  %1667 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1668 = getelementptr inbounds nuw i8, ptr %1667, i64 %1665
  %1669 = load i8, ptr %1668, align 1
  %1670 = zext i8 %1669 to i32
  %1671 = shl i32 %1670, 23
  %1672 = bitcast i32 %1671 to float
  %1673 = fmul float %1672, %1666
  %1674 = extractelement <8 x float> %162, i64 3
  %1675 = fmul float %1674, %1673
  %1676 = call float @llvm.fabs.f32(float %1673)
  %1677 = fcmp olt float %1676, +inf
  %1678 = fcmp one float %1673, 0.000000e+00
  %1679 = and i1 %1677, %1678
  %1680 = call i1 @llvm.expect.i1(i1 %1679, i1 true)
  br i1 %1680, label %1681, label %1682

1681:                                             ; preds = %1662
  br label %1694

1682:                                             ; preds = %1662
  %1683 = fpext float %1674 to double
  %1684 = fpext float %1672 to double
  %1685 = fpext float %1666 to double
  %1686 = fmul double %1683, %1684
  %1687 = fmul double %1686, %1685
  %1688 = fptrunc double %1687 to float
  %1689 = fcmp oeq float %1674, 0.000000e+00
  %1690 = call float @llvm.fabs.f32(float %1666)
  %1691 = fcmp olt float %1690, +inf
  %1692 = and i1 %1689, %1691
  %1693 = select i1 %1692, float 0.000000e+00, float %1688
  br label %1694

1694:                                             ; preds = %1681, %1682
  %1695 = phi float [ %1693, %1682 ], [ %1675, %1681 ]
  br label %1696

1696:                                             ; preds = %1694
  %1697 = add i64 %89, %57
  %1698 = icmp slt i64 %1697, %26
  %1699 = select i1 %1698, i64 %1697, i64 0
  %1700 = extractelement <8 x float> %1559, i64 4
  %1701 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1702 = getelementptr inbounds nuw i8, ptr %1701, i64 %1699
  %1703 = load i8, ptr %1702, align 1
  %1704 = zext i8 %1703 to i32
  %1705 = shl i32 %1704, 23
  %1706 = bitcast i32 %1705 to float
  %1707 = fmul float %1706, %1700
  %1708 = extractelement <8 x float> %162, i64 4
  %1709 = fmul float %1708, %1707
  %1710 = call float @llvm.fabs.f32(float %1707)
  %1711 = fcmp olt float %1710, +inf
  %1712 = fcmp one float %1707, 0.000000e+00
  %1713 = and i1 %1711, %1712
  %1714 = call i1 @llvm.expect.i1(i1 %1713, i1 true)
  br i1 %1714, label %1715, label %1716

1715:                                             ; preds = %1696
  br label %1728

1716:                                             ; preds = %1696
  %1717 = fpext float %1708 to double
  %1718 = fpext float %1706 to double
  %1719 = fpext float %1700 to double
  %1720 = fmul double %1717, %1718
  %1721 = fmul double %1720, %1719
  %1722 = fptrunc double %1721 to float
  %1723 = fcmp oeq float %1708, 0.000000e+00
  %1724 = call float @llvm.fabs.f32(float %1700)
  %1725 = fcmp olt float %1724, +inf
  %1726 = and i1 %1723, %1725
  %1727 = select i1 %1726, float 0.000000e+00, float %1722
  br label %1728

1728:                                             ; preds = %1715, %1716
  %1729 = phi float [ %1727, %1716 ], [ %1709, %1715 ]
  br label %1730

1730:                                             ; preds = %1728
  %1731 = add i64 %89, %57
  %1732 = icmp slt i64 %1731, %26
  %1733 = select i1 %1732, i64 %1731, i64 0
  %1734 = extractelement <8 x float> %1559, i64 5
  %1735 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1736 = getelementptr inbounds nuw i8, ptr %1735, i64 %1733
  %1737 = load i8, ptr %1736, align 1
  %1738 = zext i8 %1737 to i32
  %1739 = shl i32 %1738, 23
  %1740 = bitcast i32 %1739 to float
  %1741 = fmul float %1740, %1734
  %1742 = extractelement <8 x float> %162, i64 5
  %1743 = fmul float %1742, %1741
  %1744 = call float @llvm.fabs.f32(float %1741)
  %1745 = fcmp olt float %1744, +inf
  %1746 = fcmp one float %1741, 0.000000e+00
  %1747 = and i1 %1745, %1746
  %1748 = call i1 @llvm.expect.i1(i1 %1747, i1 true)
  br i1 %1748, label %1749, label %1750

1749:                                             ; preds = %1730
  br label %1762

1750:                                             ; preds = %1730
  %1751 = fpext float %1742 to double
  %1752 = fpext float %1740 to double
  %1753 = fpext float %1734 to double
  %1754 = fmul double %1751, %1752
  %1755 = fmul double %1754, %1753
  %1756 = fptrunc double %1755 to float
  %1757 = fcmp oeq float %1742, 0.000000e+00
  %1758 = call float @llvm.fabs.f32(float %1734)
  %1759 = fcmp olt float %1758, +inf
  %1760 = and i1 %1757, %1759
  %1761 = select i1 %1760, float 0.000000e+00, float %1756
  br label %1762

1762:                                             ; preds = %1749, %1750
  %1763 = phi float [ %1761, %1750 ], [ %1743, %1749 ]
  br label %1764

1764:                                             ; preds = %1762
  %1765 = add i64 %89, %57
  %1766 = icmp slt i64 %1765, %26
  %1767 = select i1 %1766, i64 %1765, i64 0
  %1768 = extractelement <8 x float> %1559, i64 6
  %1769 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1770 = getelementptr inbounds nuw i8, ptr %1769, i64 %1767
  %1771 = load i8, ptr %1770, align 1
  %1772 = zext i8 %1771 to i32
  %1773 = shl i32 %1772, 23
  %1774 = bitcast i32 %1773 to float
  %1775 = fmul float %1774, %1768
  %1776 = extractelement <8 x float> %162, i64 6
  %1777 = fmul float %1776, %1775
  %1778 = call float @llvm.fabs.f32(float %1775)
  %1779 = fcmp olt float %1778, +inf
  %1780 = fcmp one float %1775, 0.000000e+00
  %1781 = and i1 %1779, %1780
  %1782 = call i1 @llvm.expect.i1(i1 %1781, i1 true)
  br i1 %1782, label %1783, label %1784

1783:                                             ; preds = %1764
  br label %1796

1784:                                             ; preds = %1764
  %1785 = fpext float %1776 to double
  %1786 = fpext float %1774 to double
  %1787 = fpext float %1768 to double
  %1788 = fmul double %1785, %1786
  %1789 = fmul double %1788, %1787
  %1790 = fptrunc double %1789 to float
  %1791 = fcmp oeq float %1776, 0.000000e+00
  %1792 = call float @llvm.fabs.f32(float %1768)
  %1793 = fcmp olt float %1792, +inf
  %1794 = and i1 %1791, %1793
  %1795 = select i1 %1794, float 0.000000e+00, float %1790
  br label %1796

1796:                                             ; preds = %1783, %1784
  %1797 = phi float [ %1795, %1784 ], [ %1777, %1783 ]
  br label %1798

1798:                                             ; preds = %1796
  %1799 = add i64 %89, %57
  %1800 = icmp slt i64 %1799, %26
  %1801 = select i1 %1800, i64 %1799, i64 0
  %1802 = extractelement <8 x float> %1559, i64 7
  %1803 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1804 = getelementptr inbounds nuw i8, ptr %1803, i64 %1801
  %1805 = load i8, ptr %1804, align 1
  %1806 = zext i8 %1805 to i32
  %1807 = shl i32 %1806, 23
  %1808 = bitcast i32 %1807 to float
  %1809 = fmul float %1808, %1802
  %1810 = extractelement <8 x float> %162, i64 7
  %1811 = fmul float %1810, %1809
  %1812 = call float @llvm.fabs.f32(float %1809)
  %1813 = fcmp olt float %1812, +inf
  %1814 = fcmp one float %1809, 0.000000e+00
  %1815 = and i1 %1813, %1814
  %1816 = call i1 @llvm.expect.i1(i1 %1815, i1 true)
  br i1 %1816, label %1817, label %1818

1817:                                             ; preds = %1798
  br label %1830

1818:                                             ; preds = %1798
  %1819 = fpext float %1810 to double
  %1820 = fpext float %1808 to double
  %1821 = fpext float %1802 to double
  %1822 = fmul double %1819, %1820
  %1823 = fmul double %1822, %1821
  %1824 = fptrunc double %1823 to float
  %1825 = fcmp oeq float %1810, 0.000000e+00
  %1826 = call float @llvm.fabs.f32(float %1802)
  %1827 = fcmp olt float %1826, +inf
  %1828 = and i1 %1825, %1827
  %1829 = select i1 %1828, float 0.000000e+00, float %1824
  br label %1830

1830:                                             ; preds = %1817, %1818
  %1831 = phi float [ %1829, %1818 ], [ %1811, %1817 ]
  br label %1832

1832:                                             ; preds = %1830
  %1833 = mul i64 %59, 16
  %1834 = mul i64 %58, 8
  %1835 = add i64 %1833, %1834
  %1836 = mul i64 %1835, 40
  %1837 = add i64 %1836, %57
  %1838 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1837
  store float %1593, ptr addrspace(3) %1838, align 4
  %1839 = mul i64 %58, 8
  %1840 = add i64 %1839, 1
  %1841 = add i64 %1833, %1840
  %1842 = mul i64 %1841, 40
  %1843 = add i64 %1842, %57
  %1844 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1843
  store float %1627, ptr addrspace(3) %1844, align 4
  %1845 = mul i64 %58, 8
  %1846 = add i64 %1845, 2
  %1847 = add i64 %1833, %1846
  %1848 = mul i64 %1847, 40
  %1849 = add i64 %1848, %57
  %1850 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1849
  store float %1661, ptr addrspace(3) %1850, align 4
  %1851 = mul i64 %58, 8
  %1852 = add i64 %1851, 3
  %1853 = add i64 %1833, %1852
  %1854 = mul i64 %1853, 40
  %1855 = add i64 %1854, %57
  %1856 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1855
  store float %1695, ptr addrspace(3) %1856, align 4
  %1857 = mul i64 %58, 8
  %1858 = add i64 %1857, 4
  %1859 = add i64 %1833, %1858
  %1860 = mul i64 %1859, 40
  %1861 = add i64 %1860, %57
  %1862 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1861
  store float %1729, ptr addrspace(3) %1862, align 4
  %1863 = mul i64 %58, 8
  %1864 = add i64 %1863, 5
  %1865 = add i64 %1833, %1864
  %1866 = mul i64 %1865, 40
  %1867 = add i64 %1866, %57
  %1868 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1867
  store float %1763, ptr addrspace(3) %1868, align 4
  %1869 = mul i64 %58, 8
  %1870 = add i64 %1869, 6
  %1871 = add i64 %1833, %1870
  %1872 = mul i64 %1871, 40
  %1873 = add i64 %1872, %57
  %1874 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1873
  store float %1797, ptr addrspace(3) %1874, align 4
  %1875 = mul i64 %58, 8
  %1876 = add i64 %1875, 7
  %1877 = add i64 %1833, %1876
  %1878 = mul i64 %1877, 40
  %1879 = add i64 %1878, %57
  %1880 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %1879
  store float %1831, ptr addrspace(3) %1880, align 4
  %1881 = mul i64 %58, 8
  %1882 = add i64 %84, %1881
  %1883 = add i64 %91, %57
  %1884 = add i64 %1882, 7
  %1885 = icmp ult i64 %1883, %26
  %1886 = icmp ult i64 %1884, %25
  %1887 = and i1 %1886, %1885
  %1888 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1889 = ptrtoint ptr %1888 to i64
  %1890 = mul i64 %1882, 4
  %1891 = add i64 %1889, %1890
  %1892 = urem i64 %1891, 16
  %1893 = icmp eq i64 %1892, 0
  %1894 = and i1 %1887, %1893
  br i1 %1894, label %1895, label %1904

1895:                                             ; preds = %1832
  %1896 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1897 = getelementptr float, ptr %1896, i64 %1882
  %1898 = load <4 x float>, ptr %1897, align 16
  %1899 = add i64 %1882, 4
  %1900 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1901 = getelementptr float, ptr %1900, i64 %1899
  %1902 = load <4 x float>, ptr %1901, align 16
  %1903 = shufflevector <4 x float> %1898, <4 x float> %1902, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1976

1904:                                             ; preds = %1832
  %1905 = mul i64 %58, 8
  %1906 = add i64 %84, %1905
  %1907 = icmp slt i64 %1906, %25
  %1908 = select i1 %1907, i64 %1906, i64 0
  %1909 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1910 = getelementptr inbounds nuw float, ptr %1909, i64 %1908
  %1911 = load float, ptr %1910, align 4
  %1912 = insertelement <8 x float> zeroinitializer, float %1911, i64 0
  %1913 = mul i64 %58, 8
  %1914 = add i64 %1913, 1
  %1915 = add i64 %84, %1914
  %1916 = icmp slt i64 %1915, %25
  %1917 = select i1 %1916, i64 %1915, i64 0
  %1918 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1919 = getelementptr inbounds nuw float, ptr %1918, i64 %1917
  %1920 = load float, ptr %1919, align 4
  %1921 = insertelement <8 x float> %1912, float %1920, i64 1
  %1922 = mul i64 %58, 8
  %1923 = add i64 %1922, 2
  %1924 = add i64 %84, %1923
  %1925 = icmp slt i64 %1924, %25
  %1926 = select i1 %1925, i64 %1924, i64 0
  %1927 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1928 = getelementptr inbounds nuw float, ptr %1927, i64 %1926
  %1929 = load float, ptr %1928, align 4
  %1930 = insertelement <8 x float> %1921, float %1929, i64 2
  %1931 = mul i64 %58, 8
  %1932 = add i64 %1931, 3
  %1933 = add i64 %84, %1932
  %1934 = icmp slt i64 %1933, %25
  %1935 = select i1 %1934, i64 %1933, i64 0
  %1936 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1937 = getelementptr inbounds nuw float, ptr %1936, i64 %1935
  %1938 = load float, ptr %1937, align 4
  %1939 = insertelement <8 x float> %1930, float %1938, i64 3
  %1940 = mul i64 %58, 8
  %1941 = add i64 %1940, 4
  %1942 = add i64 %84, %1941
  %1943 = icmp slt i64 %1942, %25
  %1944 = select i1 %1943, i64 %1942, i64 0
  %1945 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1946 = getelementptr inbounds nuw float, ptr %1945, i64 %1944
  %1947 = load float, ptr %1946, align 4
  %1948 = insertelement <8 x float> %1939, float %1947, i64 4
  %1949 = mul i64 %58, 8
  %1950 = add i64 %1949, 5
  %1951 = add i64 %84, %1950
  %1952 = icmp slt i64 %1951, %25
  %1953 = select i1 %1952, i64 %1951, i64 0
  %1954 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1955 = getelementptr inbounds nuw float, ptr %1954, i64 %1953
  %1956 = load float, ptr %1955, align 4
  %1957 = insertelement <8 x float> %1948, float %1956, i64 5
  %1958 = mul i64 %58, 8
  %1959 = add i64 %1958, 6
  %1960 = add i64 %84, %1959
  %1961 = icmp slt i64 %1960, %25
  %1962 = select i1 %1961, i64 %1960, i64 0
  %1963 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1964 = getelementptr inbounds nuw float, ptr %1963, i64 %1962
  %1965 = load float, ptr %1964, align 4
  %1966 = insertelement <8 x float> %1957, float %1965, i64 6
  %1967 = mul i64 %58, 8
  %1968 = add i64 %1967, 7
  %1969 = add i64 %84, %1968
  %1970 = icmp slt i64 %1969, %25
  %1971 = select i1 %1970, i64 %1969, i64 0
  %1972 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1973 = getelementptr inbounds nuw float, ptr %1972, i64 %1971
  %1974 = load float, ptr %1973, align 4
  %1975 = insertelement <8 x float> %1966, float %1974, i64 7
  br label %1976

1976:                                             ; preds = %1895, %1904
  %1977 = phi <8 x float> [ %1975, %1904 ], [ %1903, %1895 ]
  br label %1978

1978:                                             ; preds = %1976
  %1979 = add i64 %91, %57
  %1980 = icmp slt i64 %1979, %26
  %1981 = select i1 %1980, i64 %1979, i64 0
  %1982 = extractelement <8 x float> %1977, i64 0
  %1983 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1984 = getelementptr inbounds nuw i8, ptr %1983, i64 %1981
  %1985 = load i8, ptr %1984, align 1
  %1986 = zext i8 %1985 to i32
  %1987 = shl i32 %1986, 23
  %1988 = bitcast i32 %1987 to float
  %1989 = fmul float %1988, %1982
  %1990 = extractelement <8 x float> %163, i64 0
  %1991 = fmul float %1990, %1989
  %1992 = call float @llvm.fabs.f32(float %1989)
  %1993 = fcmp olt float %1992, +inf
  %1994 = fcmp one float %1989, 0.000000e+00
  %1995 = and i1 %1993, %1994
  %1996 = call i1 @llvm.expect.i1(i1 %1995, i1 true)
  br i1 %1996, label %1997, label %1998

1997:                                             ; preds = %1978
  br label %2010

1998:                                             ; preds = %1978
  %1999 = fpext float %1990 to double
  %2000 = fpext float %1988 to double
  %2001 = fpext float %1982 to double
  %2002 = fmul double %1999, %2000
  %2003 = fmul double %2002, %2001
  %2004 = fptrunc double %2003 to float
  %2005 = fcmp oeq float %1990, 0.000000e+00
  %2006 = call float @llvm.fabs.f32(float %1982)
  %2007 = fcmp olt float %2006, +inf
  %2008 = and i1 %2005, %2007
  %2009 = select i1 %2008, float 0.000000e+00, float %2004
  br label %2010

2010:                                             ; preds = %1997, %1998
  %2011 = phi float [ %2009, %1998 ], [ %1991, %1997 ]
  br label %2012

2012:                                             ; preds = %2010
  %2013 = add i64 %91, %57
  %2014 = icmp slt i64 %2013, %26
  %2015 = select i1 %2014, i64 %2013, i64 0
  %2016 = extractelement <8 x float> %1977, i64 1
  %2017 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2018 = getelementptr inbounds nuw i8, ptr %2017, i64 %2015
  %2019 = load i8, ptr %2018, align 1
  %2020 = zext i8 %2019 to i32
  %2021 = shl i32 %2020, 23
  %2022 = bitcast i32 %2021 to float
  %2023 = fmul float %2022, %2016
  %2024 = extractelement <8 x float> %163, i64 1
  %2025 = fmul float %2024, %2023
  %2026 = call float @llvm.fabs.f32(float %2023)
  %2027 = fcmp olt float %2026, +inf
  %2028 = fcmp one float %2023, 0.000000e+00
  %2029 = and i1 %2027, %2028
  %2030 = call i1 @llvm.expect.i1(i1 %2029, i1 true)
  br i1 %2030, label %2031, label %2032

2031:                                             ; preds = %2012
  br label %2044

2032:                                             ; preds = %2012
  %2033 = fpext float %2024 to double
  %2034 = fpext float %2022 to double
  %2035 = fpext float %2016 to double
  %2036 = fmul double %2033, %2034
  %2037 = fmul double %2036, %2035
  %2038 = fptrunc double %2037 to float
  %2039 = fcmp oeq float %2024, 0.000000e+00
  %2040 = call float @llvm.fabs.f32(float %2016)
  %2041 = fcmp olt float %2040, +inf
  %2042 = and i1 %2039, %2041
  %2043 = select i1 %2042, float 0.000000e+00, float %2038
  br label %2044

2044:                                             ; preds = %2031, %2032
  %2045 = phi float [ %2043, %2032 ], [ %2025, %2031 ]
  br label %2046

2046:                                             ; preds = %2044
  %2047 = add i64 %91, %57
  %2048 = icmp slt i64 %2047, %26
  %2049 = select i1 %2048, i64 %2047, i64 0
  %2050 = extractelement <8 x float> %1977, i64 2
  %2051 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2052 = getelementptr inbounds nuw i8, ptr %2051, i64 %2049
  %2053 = load i8, ptr %2052, align 1
  %2054 = zext i8 %2053 to i32
  %2055 = shl i32 %2054, 23
  %2056 = bitcast i32 %2055 to float
  %2057 = fmul float %2056, %2050
  %2058 = extractelement <8 x float> %163, i64 2
  %2059 = fmul float %2058, %2057
  %2060 = call float @llvm.fabs.f32(float %2057)
  %2061 = fcmp olt float %2060, +inf
  %2062 = fcmp one float %2057, 0.000000e+00
  %2063 = and i1 %2061, %2062
  %2064 = call i1 @llvm.expect.i1(i1 %2063, i1 true)
  br i1 %2064, label %2065, label %2066

2065:                                             ; preds = %2046
  br label %2078

2066:                                             ; preds = %2046
  %2067 = fpext float %2058 to double
  %2068 = fpext float %2056 to double
  %2069 = fpext float %2050 to double
  %2070 = fmul double %2067, %2068
  %2071 = fmul double %2070, %2069
  %2072 = fptrunc double %2071 to float
  %2073 = fcmp oeq float %2058, 0.000000e+00
  %2074 = call float @llvm.fabs.f32(float %2050)
  %2075 = fcmp olt float %2074, +inf
  %2076 = and i1 %2073, %2075
  %2077 = select i1 %2076, float 0.000000e+00, float %2072
  br label %2078

2078:                                             ; preds = %2065, %2066
  %2079 = phi float [ %2077, %2066 ], [ %2059, %2065 ]
  br label %2080

2080:                                             ; preds = %2078
  %2081 = add i64 %91, %57
  %2082 = icmp slt i64 %2081, %26
  %2083 = select i1 %2082, i64 %2081, i64 0
  %2084 = extractelement <8 x float> %1977, i64 3
  %2085 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2086 = getelementptr inbounds nuw i8, ptr %2085, i64 %2083
  %2087 = load i8, ptr %2086, align 1
  %2088 = zext i8 %2087 to i32
  %2089 = shl i32 %2088, 23
  %2090 = bitcast i32 %2089 to float
  %2091 = fmul float %2090, %2084
  %2092 = extractelement <8 x float> %163, i64 3
  %2093 = fmul float %2092, %2091
  %2094 = call float @llvm.fabs.f32(float %2091)
  %2095 = fcmp olt float %2094, +inf
  %2096 = fcmp one float %2091, 0.000000e+00
  %2097 = and i1 %2095, %2096
  %2098 = call i1 @llvm.expect.i1(i1 %2097, i1 true)
  br i1 %2098, label %2099, label %2100

2099:                                             ; preds = %2080
  br label %2112

2100:                                             ; preds = %2080
  %2101 = fpext float %2092 to double
  %2102 = fpext float %2090 to double
  %2103 = fpext float %2084 to double
  %2104 = fmul double %2101, %2102
  %2105 = fmul double %2104, %2103
  %2106 = fptrunc double %2105 to float
  %2107 = fcmp oeq float %2092, 0.000000e+00
  %2108 = call float @llvm.fabs.f32(float %2084)
  %2109 = fcmp olt float %2108, +inf
  %2110 = and i1 %2107, %2109
  %2111 = select i1 %2110, float 0.000000e+00, float %2106
  br label %2112

2112:                                             ; preds = %2099, %2100
  %2113 = phi float [ %2111, %2100 ], [ %2093, %2099 ]
  br label %2114

2114:                                             ; preds = %2112
  %2115 = add i64 %91, %57
  %2116 = icmp slt i64 %2115, %26
  %2117 = select i1 %2116, i64 %2115, i64 0
  %2118 = extractelement <8 x float> %1977, i64 4
  %2119 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2120 = getelementptr inbounds nuw i8, ptr %2119, i64 %2117
  %2121 = load i8, ptr %2120, align 1
  %2122 = zext i8 %2121 to i32
  %2123 = shl i32 %2122, 23
  %2124 = bitcast i32 %2123 to float
  %2125 = fmul float %2124, %2118
  %2126 = extractelement <8 x float> %163, i64 4
  %2127 = fmul float %2126, %2125
  %2128 = call float @llvm.fabs.f32(float %2125)
  %2129 = fcmp olt float %2128, +inf
  %2130 = fcmp one float %2125, 0.000000e+00
  %2131 = and i1 %2129, %2130
  %2132 = call i1 @llvm.expect.i1(i1 %2131, i1 true)
  br i1 %2132, label %2133, label %2134

2133:                                             ; preds = %2114
  br label %2146

2134:                                             ; preds = %2114
  %2135 = fpext float %2126 to double
  %2136 = fpext float %2124 to double
  %2137 = fpext float %2118 to double
  %2138 = fmul double %2135, %2136
  %2139 = fmul double %2138, %2137
  %2140 = fptrunc double %2139 to float
  %2141 = fcmp oeq float %2126, 0.000000e+00
  %2142 = call float @llvm.fabs.f32(float %2118)
  %2143 = fcmp olt float %2142, +inf
  %2144 = and i1 %2141, %2143
  %2145 = select i1 %2144, float 0.000000e+00, float %2140
  br label %2146

2146:                                             ; preds = %2133, %2134
  %2147 = phi float [ %2145, %2134 ], [ %2127, %2133 ]
  br label %2148

2148:                                             ; preds = %2146
  %2149 = add i64 %91, %57
  %2150 = icmp slt i64 %2149, %26
  %2151 = select i1 %2150, i64 %2149, i64 0
  %2152 = extractelement <8 x float> %1977, i64 5
  %2153 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2154 = getelementptr inbounds nuw i8, ptr %2153, i64 %2151
  %2155 = load i8, ptr %2154, align 1
  %2156 = zext i8 %2155 to i32
  %2157 = shl i32 %2156, 23
  %2158 = bitcast i32 %2157 to float
  %2159 = fmul float %2158, %2152
  %2160 = extractelement <8 x float> %163, i64 5
  %2161 = fmul float %2160, %2159
  %2162 = call float @llvm.fabs.f32(float %2159)
  %2163 = fcmp olt float %2162, +inf
  %2164 = fcmp one float %2159, 0.000000e+00
  %2165 = and i1 %2163, %2164
  %2166 = call i1 @llvm.expect.i1(i1 %2165, i1 true)
  br i1 %2166, label %2167, label %2168

2167:                                             ; preds = %2148
  br label %2180

2168:                                             ; preds = %2148
  %2169 = fpext float %2160 to double
  %2170 = fpext float %2158 to double
  %2171 = fpext float %2152 to double
  %2172 = fmul double %2169, %2170
  %2173 = fmul double %2172, %2171
  %2174 = fptrunc double %2173 to float
  %2175 = fcmp oeq float %2160, 0.000000e+00
  %2176 = call float @llvm.fabs.f32(float %2152)
  %2177 = fcmp olt float %2176, +inf
  %2178 = and i1 %2175, %2177
  %2179 = select i1 %2178, float 0.000000e+00, float %2174
  br label %2180

2180:                                             ; preds = %2167, %2168
  %2181 = phi float [ %2179, %2168 ], [ %2161, %2167 ]
  br label %2182

2182:                                             ; preds = %2180
  %2183 = add i64 %91, %57
  %2184 = icmp slt i64 %2183, %26
  %2185 = select i1 %2184, i64 %2183, i64 0
  %2186 = extractelement <8 x float> %1977, i64 6
  %2187 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2188 = getelementptr inbounds nuw i8, ptr %2187, i64 %2185
  %2189 = load i8, ptr %2188, align 1
  %2190 = zext i8 %2189 to i32
  %2191 = shl i32 %2190, 23
  %2192 = bitcast i32 %2191 to float
  %2193 = fmul float %2192, %2186
  %2194 = extractelement <8 x float> %163, i64 6
  %2195 = fmul float %2194, %2193
  %2196 = call float @llvm.fabs.f32(float %2193)
  %2197 = fcmp olt float %2196, +inf
  %2198 = fcmp one float %2193, 0.000000e+00
  %2199 = and i1 %2197, %2198
  %2200 = call i1 @llvm.expect.i1(i1 %2199, i1 true)
  br i1 %2200, label %2201, label %2202

2201:                                             ; preds = %2182
  br label %2214

2202:                                             ; preds = %2182
  %2203 = fpext float %2194 to double
  %2204 = fpext float %2192 to double
  %2205 = fpext float %2186 to double
  %2206 = fmul double %2203, %2204
  %2207 = fmul double %2206, %2205
  %2208 = fptrunc double %2207 to float
  %2209 = fcmp oeq float %2194, 0.000000e+00
  %2210 = call float @llvm.fabs.f32(float %2186)
  %2211 = fcmp olt float %2210, +inf
  %2212 = and i1 %2209, %2211
  %2213 = select i1 %2212, float 0.000000e+00, float %2208
  br label %2214

2214:                                             ; preds = %2201, %2202
  %2215 = phi float [ %2213, %2202 ], [ %2195, %2201 ]
  br label %2216

2216:                                             ; preds = %2214
  %2217 = add i64 %91, %57
  %2218 = icmp slt i64 %2217, %26
  %2219 = select i1 %2218, i64 %2217, i64 0
  %2220 = extractelement <8 x float> %1977, i64 7
  %2221 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2222 = getelementptr inbounds nuw i8, ptr %2221, i64 %2219
  %2223 = load i8, ptr %2222, align 1
  %2224 = zext i8 %2223 to i32
  %2225 = shl i32 %2224, 23
  %2226 = bitcast i32 %2225 to float
  %2227 = fmul float %2226, %2220
  %2228 = extractelement <8 x float> %163, i64 7
  %2229 = fmul float %2228, %2227
  %2230 = call float @llvm.fabs.f32(float %2227)
  %2231 = fcmp olt float %2230, +inf
  %2232 = fcmp one float %2227, 0.000000e+00
  %2233 = and i1 %2231, %2232
  %2234 = call i1 @llvm.expect.i1(i1 %2233, i1 true)
  br i1 %2234, label %2235, label %2236

2235:                                             ; preds = %2216
  br label %2248

2236:                                             ; preds = %2216
  %2237 = fpext float %2228 to double
  %2238 = fpext float %2226 to double
  %2239 = fpext float %2220 to double
  %2240 = fmul double %2237, %2238
  %2241 = fmul double %2240, %2239
  %2242 = fptrunc double %2241 to float
  %2243 = fcmp oeq float %2228, 0.000000e+00
  %2244 = call float @llvm.fabs.f32(float %2220)
  %2245 = fcmp olt float %2244, +inf
  %2246 = and i1 %2243, %2245
  %2247 = select i1 %2246, float 0.000000e+00, float %2242
  br label %2248

2248:                                             ; preds = %2235, %2236
  %2249 = phi float [ %2247, %2236 ], [ %2229, %2235 ]
  br label %2250

2250:                                             ; preds = %2248
  %2251 = mul i64 %59, 16
  %2252 = mul i64 %58, 8
  %2253 = add i64 %2251, %2252
  %2254 = add i64 %57, 16
  %2255 = mul i64 %2253, 40
  %2256 = add i64 %2255, %2254
  %2257 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2256
  store float %2011, ptr addrspace(3) %2257, align 4
  %2258 = mul i64 %58, 8
  %2259 = add i64 %2258, 1
  %2260 = add i64 %2251, %2259
  %2261 = add i64 %57, 16
  %2262 = mul i64 %2260, 40
  %2263 = add i64 %2262, %2261
  %2264 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2263
  store float %2045, ptr addrspace(3) %2264, align 4
  %2265 = mul i64 %58, 8
  %2266 = add i64 %2265, 2
  %2267 = add i64 %2251, %2266
  %2268 = add i64 %57, 16
  %2269 = mul i64 %2267, 40
  %2270 = add i64 %2269, %2268
  %2271 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2270
  store float %2079, ptr addrspace(3) %2271, align 4
  %2272 = mul i64 %58, 8
  %2273 = add i64 %2272, 3
  %2274 = add i64 %2251, %2273
  %2275 = add i64 %57, 16
  %2276 = mul i64 %2274, 40
  %2277 = add i64 %2276, %2275
  %2278 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2277
  store float %2113, ptr addrspace(3) %2278, align 4
  %2279 = mul i64 %58, 8
  %2280 = add i64 %2279, 4
  %2281 = add i64 %2251, %2280
  %2282 = add i64 %57, 16
  %2283 = mul i64 %2281, 40
  %2284 = add i64 %2283, %2282
  %2285 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2284
  store float %2147, ptr addrspace(3) %2285, align 4
  %2286 = mul i64 %58, 8
  %2287 = add i64 %2286, 5
  %2288 = add i64 %2251, %2287
  %2289 = add i64 %57, 16
  %2290 = mul i64 %2288, 40
  %2291 = add i64 %2290, %2289
  %2292 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2291
  store float %2181, ptr addrspace(3) %2292, align 4
  %2293 = mul i64 %58, 8
  %2294 = add i64 %2293, 6
  %2295 = add i64 %2251, %2294
  %2296 = add i64 %57, 16
  %2297 = mul i64 %2295, 40
  %2298 = add i64 %2297, %2296
  %2299 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2298
  store float %2215, ptr addrspace(3) %2299, align 4
  %2300 = mul i64 %58, 8
  %2301 = add i64 %2300, 7
  %2302 = add i64 %2251, %2301
  %2303 = add i64 %57, 16
  %2304 = mul i64 %2302, 40
  %2305 = add i64 %2304, %2303
  %2306 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2305
  store float %2249, ptr addrspace(3) %2306, align 4
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %2307 = mul i64 %55, 8
  %2308 = udiv i64 %2307, 32
  %2309 = urem i64 %2307, 32
  %2310 = udiv i64 %2308, 16
  %2311 = urem i64 %2308, 16
  %2312 = udiv i64 %2310, 2
  %2313 = mul i64 %2312, 4
  %2314 = add i64 %2313, 1
  %2315 = mul i64 %2314, 16
  %2316 = add i64 %2311, %2315
  %2317 = add i64 %78, %2316
  %2318 = urem i64 %2310, 2
  %2319 = mul i64 %2318, 32
  %2320 = add i64 %2309, %2319
  %2321 = add i64 %79, %2320
  %2322 = mul i64 %2308, 40
  %2323 = add i64 %2322, %2309
  %2324 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2323
  %2325 = load <8 x float>, ptr addrspace(3) %2324, align 16
  %2326 = fptrunc <8 x float> %2325 to <8 x bfloat>
  %2327 = mul i64 %2317, %26
  %2328 = add i64 %2327, %2321
  %2329 = icmp ult i64 %2317, %25
  %2330 = add i64 %2321, 7
  %2331 = icmp ult i64 %2330, %26
  %2332 = and i1 %2329, %2331
  br i1 %2332, label %2333, label %2336

2333:                                             ; preds = %2250
  %2334 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2335 = getelementptr bfloat, ptr %2334, i64 %2328
  store <8 x bfloat> %2326, ptr %2335, align 2
  br label %2407

2336:                                             ; preds = %2250
  %2337 = icmp ult i64 %2321, %26
  %2338 = and i1 %2329, %2337
  br i1 %2338, label %2339, label %2343

2339:                                             ; preds = %2336
  %2340 = extractelement <8 x bfloat> %2326, i64 0
  %2341 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2342 = getelementptr inbounds nuw bfloat, ptr %2341, i64 %2328
  store bfloat %2340, ptr %2342, align 2
  br label %2343

2343:                                             ; preds = %2339, %2336
  %2344 = add i64 %2321, 1
  %2345 = icmp ult i64 %2344, %26
  %2346 = and i1 %2329, %2345
  br i1 %2346, label %2347, label %2352

2347:                                             ; preds = %2343
  %2348 = add i64 %2328, 1
  %2349 = extractelement <8 x bfloat> %2326, i64 1
  %2350 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2351 = getelementptr inbounds nuw bfloat, ptr %2350, i64 %2348
  store bfloat %2349, ptr %2351, align 2
  br label %2352

2352:                                             ; preds = %2347, %2343
  %2353 = add i64 %2321, 2
  %2354 = icmp ult i64 %2353, %26
  %2355 = and i1 %2329, %2354
  br i1 %2355, label %2356, label %2361

2356:                                             ; preds = %2352
  %2357 = add i64 %2328, 2
  %2358 = extractelement <8 x bfloat> %2326, i64 2
  %2359 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2360 = getelementptr inbounds nuw bfloat, ptr %2359, i64 %2357
  store bfloat %2358, ptr %2360, align 2
  br label %2361

2361:                                             ; preds = %2356, %2352
  %2362 = add i64 %2321, 3
  %2363 = icmp ult i64 %2362, %26
  %2364 = and i1 %2329, %2363
  br i1 %2364, label %2365, label %2370

2365:                                             ; preds = %2361
  %2366 = add i64 %2328, 3
  %2367 = extractelement <8 x bfloat> %2326, i64 3
  %2368 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2369 = getelementptr inbounds nuw bfloat, ptr %2368, i64 %2366
  store bfloat %2367, ptr %2369, align 2
  br label %2370

2370:                                             ; preds = %2365, %2361
  %2371 = add i64 %2321, 4
  %2372 = icmp ult i64 %2371, %26
  %2373 = and i1 %2329, %2372
  br i1 %2373, label %2374, label %2379

2374:                                             ; preds = %2370
  %2375 = add i64 %2328, 4
  %2376 = extractelement <8 x bfloat> %2326, i64 4
  %2377 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2378 = getelementptr inbounds nuw bfloat, ptr %2377, i64 %2375
  store bfloat %2376, ptr %2378, align 2
  br label %2379

2379:                                             ; preds = %2374, %2370
  %2380 = add i64 %2321, 5
  %2381 = icmp ult i64 %2380, %26
  %2382 = and i1 %2329, %2381
  br i1 %2382, label %2383, label %2388

2383:                                             ; preds = %2379
  %2384 = add i64 %2328, 5
  %2385 = extractelement <8 x bfloat> %2326, i64 5
  %2386 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2387 = getelementptr inbounds nuw bfloat, ptr %2386, i64 %2384
  store bfloat %2385, ptr %2387, align 2
  br label %2388

2388:                                             ; preds = %2383, %2379
  %2389 = add i64 %2321, 6
  %2390 = icmp ult i64 %2389, %26
  %2391 = and i1 %2329, %2390
  br i1 %2391, label %2392, label %2397

2392:                                             ; preds = %2388
  %2393 = add i64 %2328, 6
  %2394 = extractelement <8 x bfloat> %2326, i64 6
  %2395 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2396 = getelementptr inbounds nuw bfloat, ptr %2395, i64 %2393
  store bfloat %2394, ptr %2396, align 2
  br label %2397

2397:                                             ; preds = %2392, %2388
  %2398 = add i64 %2321, 7
  %2399 = icmp ult i64 %2398, %26
  %2400 = and i1 %2329, %2399
  br i1 %2400, label %2401, label %2406

2401:                                             ; preds = %2397
  %2402 = add i64 %2328, 7
  %2403 = extractelement <8 x bfloat> %2326, i64 7
  %2404 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2405 = getelementptr inbounds nuw bfloat, ptr %2404, i64 %2402
  store bfloat %2403, ptr %2405, align 2
  br label %2406

2406:                                             ; preds = %2401, %2397
  br label %2407

2407:                                             ; preds = %2333, %2406
  %2408 = mul i64 %55, 8
  %2409 = add i64 %2408, 2048
  %2410 = udiv i64 %2409, 32
  %2411 = urem i64 %2409, 32
  %2412 = udiv i64 %2410, 16
  %2413 = urem i64 %2410, 16
  %2414 = udiv i64 %2412, 2
  %2415 = mul i64 %2414, 4
  %2416 = add i64 %2415, 1
  %2417 = mul i64 %2416, 16
  %2418 = add i64 %2413, %2417
  %2419 = add i64 %78, %2418
  %2420 = urem i64 %2412, 2
  %2421 = mul i64 %2420, 32
  %2422 = add i64 %2411, %2421
  %2423 = add i64 %79, %2422
  %2424 = mul i64 %2410, 40
  %2425 = add i64 %2424, %2411
  %2426 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2425
  %2427 = load <8 x float>, ptr addrspace(3) %2426, align 16
  %2428 = fptrunc <8 x float> %2427 to <8 x bfloat>
  %2429 = mul i64 %2419, %26
  %2430 = add i64 %2429, %2423
  %2431 = icmp ult i64 %2419, %25
  %2432 = add i64 %2423, 7
  %2433 = icmp ult i64 %2432, %26
  %2434 = and i1 %2431, %2433
  br i1 %2434, label %2435, label %2438

2435:                                             ; preds = %2407
  %2436 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2437 = getelementptr bfloat, ptr %2436, i64 %2430
  store <8 x bfloat> %2428, ptr %2437, align 2
  br label %2509

2438:                                             ; preds = %2407
  %2439 = icmp ult i64 %2423, %26
  %2440 = and i1 %2431, %2439
  br i1 %2440, label %2441, label %2445

2441:                                             ; preds = %2438
  %2442 = extractelement <8 x bfloat> %2428, i64 0
  %2443 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2444 = getelementptr inbounds nuw bfloat, ptr %2443, i64 %2430
  store bfloat %2442, ptr %2444, align 2
  br label %2445

2445:                                             ; preds = %2441, %2438
  %2446 = add i64 %2423, 1
  %2447 = icmp ult i64 %2446, %26
  %2448 = and i1 %2431, %2447
  br i1 %2448, label %2449, label %2454

2449:                                             ; preds = %2445
  %2450 = add i64 %2430, 1
  %2451 = extractelement <8 x bfloat> %2428, i64 1
  %2452 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2453 = getelementptr inbounds nuw bfloat, ptr %2452, i64 %2450
  store bfloat %2451, ptr %2453, align 2
  br label %2454

2454:                                             ; preds = %2449, %2445
  %2455 = add i64 %2423, 2
  %2456 = icmp ult i64 %2455, %26
  %2457 = and i1 %2431, %2456
  br i1 %2457, label %2458, label %2463

2458:                                             ; preds = %2454
  %2459 = add i64 %2430, 2
  %2460 = extractelement <8 x bfloat> %2428, i64 2
  %2461 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2462 = getelementptr inbounds nuw bfloat, ptr %2461, i64 %2459
  store bfloat %2460, ptr %2462, align 2
  br label %2463

2463:                                             ; preds = %2458, %2454
  %2464 = add i64 %2423, 3
  %2465 = icmp ult i64 %2464, %26
  %2466 = and i1 %2431, %2465
  br i1 %2466, label %2467, label %2472

2467:                                             ; preds = %2463
  %2468 = add i64 %2430, 3
  %2469 = extractelement <8 x bfloat> %2428, i64 3
  %2470 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2471 = getelementptr inbounds nuw bfloat, ptr %2470, i64 %2468
  store bfloat %2469, ptr %2471, align 2
  br label %2472

2472:                                             ; preds = %2467, %2463
  %2473 = add i64 %2423, 4
  %2474 = icmp ult i64 %2473, %26
  %2475 = and i1 %2431, %2474
  br i1 %2475, label %2476, label %2481

2476:                                             ; preds = %2472
  %2477 = add i64 %2430, 4
  %2478 = extractelement <8 x bfloat> %2428, i64 4
  %2479 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2480 = getelementptr inbounds nuw bfloat, ptr %2479, i64 %2477
  store bfloat %2478, ptr %2480, align 2
  br label %2481

2481:                                             ; preds = %2476, %2472
  %2482 = add i64 %2423, 5
  %2483 = icmp ult i64 %2482, %26
  %2484 = and i1 %2431, %2483
  br i1 %2484, label %2485, label %2490

2485:                                             ; preds = %2481
  %2486 = add i64 %2430, 5
  %2487 = extractelement <8 x bfloat> %2428, i64 5
  %2488 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2489 = getelementptr inbounds nuw bfloat, ptr %2488, i64 %2486
  store bfloat %2487, ptr %2489, align 2
  br label %2490

2490:                                             ; preds = %2485, %2481
  %2491 = add i64 %2423, 6
  %2492 = icmp ult i64 %2491, %26
  %2493 = and i1 %2431, %2492
  br i1 %2493, label %2494, label %2499

2494:                                             ; preds = %2490
  %2495 = add i64 %2430, 6
  %2496 = extractelement <8 x bfloat> %2428, i64 6
  %2497 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2498 = getelementptr inbounds nuw bfloat, ptr %2497, i64 %2495
  store bfloat %2496, ptr %2498, align 2
  br label %2499

2499:                                             ; preds = %2494, %2490
  %2500 = add i64 %2423, 7
  %2501 = icmp ult i64 %2500, %26
  %2502 = and i1 %2431, %2501
  br i1 %2502, label %2503, label %2508

2503:                                             ; preds = %2499
  %2504 = add i64 %2430, 7
  %2505 = extractelement <8 x bfloat> %2428, i64 7
  %2506 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2507 = getelementptr inbounds nuw bfloat, ptr %2506, i64 %2504
  store bfloat %2505, ptr %2507, align 2
  br label %2508

2508:                                             ; preds = %2503, %2499
  br label %2509

2509:                                             ; preds = %2435, %2508
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %2510 = mul i64 %58, 8
  %2511 = add i64 %86, %2510
  %2512 = add i64 %89, %57
  %2513 = add i64 %2511, 7
  %2514 = icmp ult i64 %2512, %26
  %2515 = icmp ult i64 %2513, %25
  %2516 = and i1 %2515, %2514
  %2517 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2518 = ptrtoint ptr %2517 to i64
  %2519 = mul i64 %2511, 4
  %2520 = add i64 %2518, %2519
  %2521 = urem i64 %2520, 16
  %2522 = icmp eq i64 %2521, 0
  %2523 = and i1 %2516, %2522
  br i1 %2523, label %2524, label %2533

2524:                                             ; preds = %2509
  %2525 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2526 = getelementptr float, ptr %2525, i64 %2511
  %2527 = load <4 x float>, ptr %2526, align 16
  %2528 = add i64 %2511, 4
  %2529 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2530 = getelementptr float, ptr %2529, i64 %2528
  %2531 = load <4 x float>, ptr %2530, align 16
  %2532 = shufflevector <4 x float> %2527, <4 x float> %2531, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2605

2533:                                             ; preds = %2509
  %2534 = mul i64 %58, 8
  %2535 = add i64 %86, %2534
  %2536 = icmp slt i64 %2535, %25
  %2537 = select i1 %2536, i64 %2535, i64 0
  %2538 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2539 = getelementptr inbounds nuw float, ptr %2538, i64 %2537
  %2540 = load float, ptr %2539, align 4
  %2541 = insertelement <8 x float> zeroinitializer, float %2540, i64 0
  %2542 = mul i64 %58, 8
  %2543 = add i64 %2542, 1
  %2544 = add i64 %86, %2543
  %2545 = icmp slt i64 %2544, %25
  %2546 = select i1 %2545, i64 %2544, i64 0
  %2547 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2548 = getelementptr inbounds nuw float, ptr %2547, i64 %2546
  %2549 = load float, ptr %2548, align 4
  %2550 = insertelement <8 x float> %2541, float %2549, i64 1
  %2551 = mul i64 %58, 8
  %2552 = add i64 %2551, 2
  %2553 = add i64 %86, %2552
  %2554 = icmp slt i64 %2553, %25
  %2555 = select i1 %2554, i64 %2553, i64 0
  %2556 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2557 = getelementptr inbounds nuw float, ptr %2556, i64 %2555
  %2558 = load float, ptr %2557, align 4
  %2559 = insertelement <8 x float> %2550, float %2558, i64 2
  %2560 = mul i64 %58, 8
  %2561 = add i64 %2560, 3
  %2562 = add i64 %86, %2561
  %2563 = icmp slt i64 %2562, %25
  %2564 = select i1 %2563, i64 %2562, i64 0
  %2565 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2566 = getelementptr inbounds nuw float, ptr %2565, i64 %2564
  %2567 = load float, ptr %2566, align 4
  %2568 = insertelement <8 x float> %2559, float %2567, i64 3
  %2569 = mul i64 %58, 8
  %2570 = add i64 %2569, 4
  %2571 = add i64 %86, %2570
  %2572 = icmp slt i64 %2571, %25
  %2573 = select i1 %2572, i64 %2571, i64 0
  %2574 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2575 = getelementptr inbounds nuw float, ptr %2574, i64 %2573
  %2576 = load float, ptr %2575, align 4
  %2577 = insertelement <8 x float> %2568, float %2576, i64 4
  %2578 = mul i64 %58, 8
  %2579 = add i64 %2578, 5
  %2580 = add i64 %86, %2579
  %2581 = icmp slt i64 %2580, %25
  %2582 = select i1 %2581, i64 %2580, i64 0
  %2583 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2584 = getelementptr inbounds nuw float, ptr %2583, i64 %2582
  %2585 = load float, ptr %2584, align 4
  %2586 = insertelement <8 x float> %2577, float %2585, i64 5
  %2587 = mul i64 %58, 8
  %2588 = add i64 %2587, 6
  %2589 = add i64 %86, %2588
  %2590 = icmp slt i64 %2589, %25
  %2591 = select i1 %2590, i64 %2589, i64 0
  %2592 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2593 = getelementptr inbounds nuw float, ptr %2592, i64 %2591
  %2594 = load float, ptr %2593, align 4
  %2595 = insertelement <8 x float> %2586, float %2594, i64 6
  %2596 = mul i64 %58, 8
  %2597 = add i64 %2596, 7
  %2598 = add i64 %86, %2597
  %2599 = icmp slt i64 %2598, %25
  %2600 = select i1 %2599, i64 %2598, i64 0
  %2601 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2602 = getelementptr inbounds nuw float, ptr %2601, i64 %2600
  %2603 = load float, ptr %2602, align 4
  %2604 = insertelement <8 x float> %2595, float %2603, i64 7
  br label %2605

2605:                                             ; preds = %2524, %2533
  %2606 = phi <8 x float> [ %2604, %2533 ], [ %2532, %2524 ]
  br label %2607

2607:                                             ; preds = %2605
  %2608 = add i64 %89, %57
  %2609 = icmp slt i64 %2608, %26
  %2610 = select i1 %2609, i64 %2608, i64 0
  %2611 = extractelement <8 x float> %2606, i64 0
  %2612 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2613 = getelementptr inbounds nuw i8, ptr %2612, i64 %2610
  %2614 = load i8, ptr %2613, align 1
  %2615 = zext i8 %2614 to i32
  %2616 = shl i32 %2615, 23
  %2617 = bitcast i32 %2616 to float
  %2618 = fmul float %2617, %2611
  %2619 = extractelement <8 x float> %164, i64 0
  %2620 = fmul float %2619, %2618
  %2621 = call float @llvm.fabs.f32(float %2618)
  %2622 = fcmp olt float %2621, +inf
  %2623 = fcmp one float %2618, 0.000000e+00
  %2624 = and i1 %2622, %2623
  %2625 = call i1 @llvm.expect.i1(i1 %2624, i1 true)
  br i1 %2625, label %2626, label %2627

2626:                                             ; preds = %2607
  br label %2639

2627:                                             ; preds = %2607
  %2628 = fpext float %2619 to double
  %2629 = fpext float %2617 to double
  %2630 = fpext float %2611 to double
  %2631 = fmul double %2628, %2629
  %2632 = fmul double %2631, %2630
  %2633 = fptrunc double %2632 to float
  %2634 = fcmp oeq float %2619, 0.000000e+00
  %2635 = call float @llvm.fabs.f32(float %2611)
  %2636 = fcmp olt float %2635, +inf
  %2637 = and i1 %2634, %2636
  %2638 = select i1 %2637, float 0.000000e+00, float %2633
  br label %2639

2639:                                             ; preds = %2626, %2627
  %2640 = phi float [ %2638, %2627 ], [ %2620, %2626 ]
  br label %2641

2641:                                             ; preds = %2639
  %2642 = add i64 %89, %57
  %2643 = icmp slt i64 %2642, %26
  %2644 = select i1 %2643, i64 %2642, i64 0
  %2645 = extractelement <8 x float> %2606, i64 1
  %2646 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2647 = getelementptr inbounds nuw i8, ptr %2646, i64 %2644
  %2648 = load i8, ptr %2647, align 1
  %2649 = zext i8 %2648 to i32
  %2650 = shl i32 %2649, 23
  %2651 = bitcast i32 %2650 to float
  %2652 = fmul float %2651, %2645
  %2653 = extractelement <8 x float> %164, i64 1
  %2654 = fmul float %2653, %2652
  %2655 = call float @llvm.fabs.f32(float %2652)
  %2656 = fcmp olt float %2655, +inf
  %2657 = fcmp one float %2652, 0.000000e+00
  %2658 = and i1 %2656, %2657
  %2659 = call i1 @llvm.expect.i1(i1 %2658, i1 true)
  br i1 %2659, label %2660, label %2661

2660:                                             ; preds = %2641
  br label %2673

2661:                                             ; preds = %2641
  %2662 = fpext float %2653 to double
  %2663 = fpext float %2651 to double
  %2664 = fpext float %2645 to double
  %2665 = fmul double %2662, %2663
  %2666 = fmul double %2665, %2664
  %2667 = fptrunc double %2666 to float
  %2668 = fcmp oeq float %2653, 0.000000e+00
  %2669 = call float @llvm.fabs.f32(float %2645)
  %2670 = fcmp olt float %2669, +inf
  %2671 = and i1 %2668, %2670
  %2672 = select i1 %2671, float 0.000000e+00, float %2667
  br label %2673

2673:                                             ; preds = %2660, %2661
  %2674 = phi float [ %2672, %2661 ], [ %2654, %2660 ]
  br label %2675

2675:                                             ; preds = %2673
  %2676 = add i64 %89, %57
  %2677 = icmp slt i64 %2676, %26
  %2678 = select i1 %2677, i64 %2676, i64 0
  %2679 = extractelement <8 x float> %2606, i64 2
  %2680 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2681 = getelementptr inbounds nuw i8, ptr %2680, i64 %2678
  %2682 = load i8, ptr %2681, align 1
  %2683 = zext i8 %2682 to i32
  %2684 = shl i32 %2683, 23
  %2685 = bitcast i32 %2684 to float
  %2686 = fmul float %2685, %2679
  %2687 = extractelement <8 x float> %164, i64 2
  %2688 = fmul float %2687, %2686
  %2689 = call float @llvm.fabs.f32(float %2686)
  %2690 = fcmp olt float %2689, +inf
  %2691 = fcmp one float %2686, 0.000000e+00
  %2692 = and i1 %2690, %2691
  %2693 = call i1 @llvm.expect.i1(i1 %2692, i1 true)
  br i1 %2693, label %2694, label %2695

2694:                                             ; preds = %2675
  br label %2707

2695:                                             ; preds = %2675
  %2696 = fpext float %2687 to double
  %2697 = fpext float %2685 to double
  %2698 = fpext float %2679 to double
  %2699 = fmul double %2696, %2697
  %2700 = fmul double %2699, %2698
  %2701 = fptrunc double %2700 to float
  %2702 = fcmp oeq float %2687, 0.000000e+00
  %2703 = call float @llvm.fabs.f32(float %2679)
  %2704 = fcmp olt float %2703, +inf
  %2705 = and i1 %2702, %2704
  %2706 = select i1 %2705, float 0.000000e+00, float %2701
  br label %2707

2707:                                             ; preds = %2694, %2695
  %2708 = phi float [ %2706, %2695 ], [ %2688, %2694 ]
  br label %2709

2709:                                             ; preds = %2707
  %2710 = add i64 %89, %57
  %2711 = icmp slt i64 %2710, %26
  %2712 = select i1 %2711, i64 %2710, i64 0
  %2713 = extractelement <8 x float> %2606, i64 3
  %2714 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2715 = getelementptr inbounds nuw i8, ptr %2714, i64 %2712
  %2716 = load i8, ptr %2715, align 1
  %2717 = zext i8 %2716 to i32
  %2718 = shl i32 %2717, 23
  %2719 = bitcast i32 %2718 to float
  %2720 = fmul float %2719, %2713
  %2721 = extractelement <8 x float> %164, i64 3
  %2722 = fmul float %2721, %2720
  %2723 = call float @llvm.fabs.f32(float %2720)
  %2724 = fcmp olt float %2723, +inf
  %2725 = fcmp one float %2720, 0.000000e+00
  %2726 = and i1 %2724, %2725
  %2727 = call i1 @llvm.expect.i1(i1 %2726, i1 true)
  br i1 %2727, label %2728, label %2729

2728:                                             ; preds = %2709
  br label %2741

2729:                                             ; preds = %2709
  %2730 = fpext float %2721 to double
  %2731 = fpext float %2719 to double
  %2732 = fpext float %2713 to double
  %2733 = fmul double %2730, %2731
  %2734 = fmul double %2733, %2732
  %2735 = fptrunc double %2734 to float
  %2736 = fcmp oeq float %2721, 0.000000e+00
  %2737 = call float @llvm.fabs.f32(float %2713)
  %2738 = fcmp olt float %2737, +inf
  %2739 = and i1 %2736, %2738
  %2740 = select i1 %2739, float 0.000000e+00, float %2735
  br label %2741

2741:                                             ; preds = %2728, %2729
  %2742 = phi float [ %2740, %2729 ], [ %2722, %2728 ]
  br label %2743

2743:                                             ; preds = %2741
  %2744 = add i64 %89, %57
  %2745 = icmp slt i64 %2744, %26
  %2746 = select i1 %2745, i64 %2744, i64 0
  %2747 = extractelement <8 x float> %2606, i64 4
  %2748 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2749 = getelementptr inbounds nuw i8, ptr %2748, i64 %2746
  %2750 = load i8, ptr %2749, align 1
  %2751 = zext i8 %2750 to i32
  %2752 = shl i32 %2751, 23
  %2753 = bitcast i32 %2752 to float
  %2754 = fmul float %2753, %2747
  %2755 = extractelement <8 x float> %164, i64 4
  %2756 = fmul float %2755, %2754
  %2757 = call float @llvm.fabs.f32(float %2754)
  %2758 = fcmp olt float %2757, +inf
  %2759 = fcmp one float %2754, 0.000000e+00
  %2760 = and i1 %2758, %2759
  %2761 = call i1 @llvm.expect.i1(i1 %2760, i1 true)
  br i1 %2761, label %2762, label %2763

2762:                                             ; preds = %2743
  br label %2775

2763:                                             ; preds = %2743
  %2764 = fpext float %2755 to double
  %2765 = fpext float %2753 to double
  %2766 = fpext float %2747 to double
  %2767 = fmul double %2764, %2765
  %2768 = fmul double %2767, %2766
  %2769 = fptrunc double %2768 to float
  %2770 = fcmp oeq float %2755, 0.000000e+00
  %2771 = call float @llvm.fabs.f32(float %2747)
  %2772 = fcmp olt float %2771, +inf
  %2773 = and i1 %2770, %2772
  %2774 = select i1 %2773, float 0.000000e+00, float %2769
  br label %2775

2775:                                             ; preds = %2762, %2763
  %2776 = phi float [ %2774, %2763 ], [ %2756, %2762 ]
  br label %2777

2777:                                             ; preds = %2775
  %2778 = add i64 %89, %57
  %2779 = icmp slt i64 %2778, %26
  %2780 = select i1 %2779, i64 %2778, i64 0
  %2781 = extractelement <8 x float> %2606, i64 5
  %2782 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2783 = getelementptr inbounds nuw i8, ptr %2782, i64 %2780
  %2784 = load i8, ptr %2783, align 1
  %2785 = zext i8 %2784 to i32
  %2786 = shl i32 %2785, 23
  %2787 = bitcast i32 %2786 to float
  %2788 = fmul float %2787, %2781
  %2789 = extractelement <8 x float> %164, i64 5
  %2790 = fmul float %2789, %2788
  %2791 = call float @llvm.fabs.f32(float %2788)
  %2792 = fcmp olt float %2791, +inf
  %2793 = fcmp one float %2788, 0.000000e+00
  %2794 = and i1 %2792, %2793
  %2795 = call i1 @llvm.expect.i1(i1 %2794, i1 true)
  br i1 %2795, label %2796, label %2797

2796:                                             ; preds = %2777
  br label %2809

2797:                                             ; preds = %2777
  %2798 = fpext float %2789 to double
  %2799 = fpext float %2787 to double
  %2800 = fpext float %2781 to double
  %2801 = fmul double %2798, %2799
  %2802 = fmul double %2801, %2800
  %2803 = fptrunc double %2802 to float
  %2804 = fcmp oeq float %2789, 0.000000e+00
  %2805 = call float @llvm.fabs.f32(float %2781)
  %2806 = fcmp olt float %2805, +inf
  %2807 = and i1 %2804, %2806
  %2808 = select i1 %2807, float 0.000000e+00, float %2803
  br label %2809

2809:                                             ; preds = %2796, %2797
  %2810 = phi float [ %2808, %2797 ], [ %2790, %2796 ]
  br label %2811

2811:                                             ; preds = %2809
  %2812 = add i64 %89, %57
  %2813 = icmp slt i64 %2812, %26
  %2814 = select i1 %2813, i64 %2812, i64 0
  %2815 = extractelement <8 x float> %2606, i64 6
  %2816 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2817 = getelementptr inbounds nuw i8, ptr %2816, i64 %2814
  %2818 = load i8, ptr %2817, align 1
  %2819 = zext i8 %2818 to i32
  %2820 = shl i32 %2819, 23
  %2821 = bitcast i32 %2820 to float
  %2822 = fmul float %2821, %2815
  %2823 = extractelement <8 x float> %164, i64 6
  %2824 = fmul float %2823, %2822
  %2825 = call float @llvm.fabs.f32(float %2822)
  %2826 = fcmp olt float %2825, +inf
  %2827 = fcmp one float %2822, 0.000000e+00
  %2828 = and i1 %2826, %2827
  %2829 = call i1 @llvm.expect.i1(i1 %2828, i1 true)
  br i1 %2829, label %2830, label %2831

2830:                                             ; preds = %2811
  br label %2843

2831:                                             ; preds = %2811
  %2832 = fpext float %2823 to double
  %2833 = fpext float %2821 to double
  %2834 = fpext float %2815 to double
  %2835 = fmul double %2832, %2833
  %2836 = fmul double %2835, %2834
  %2837 = fptrunc double %2836 to float
  %2838 = fcmp oeq float %2823, 0.000000e+00
  %2839 = call float @llvm.fabs.f32(float %2815)
  %2840 = fcmp olt float %2839, +inf
  %2841 = and i1 %2838, %2840
  %2842 = select i1 %2841, float 0.000000e+00, float %2837
  br label %2843

2843:                                             ; preds = %2830, %2831
  %2844 = phi float [ %2842, %2831 ], [ %2824, %2830 ]
  br label %2845

2845:                                             ; preds = %2843
  %2846 = add i64 %89, %57
  %2847 = icmp slt i64 %2846, %26
  %2848 = select i1 %2847, i64 %2846, i64 0
  %2849 = extractelement <8 x float> %2606, i64 7
  %2850 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2851 = getelementptr inbounds nuw i8, ptr %2850, i64 %2848
  %2852 = load i8, ptr %2851, align 1
  %2853 = zext i8 %2852 to i32
  %2854 = shl i32 %2853, 23
  %2855 = bitcast i32 %2854 to float
  %2856 = fmul float %2855, %2849
  %2857 = extractelement <8 x float> %164, i64 7
  %2858 = fmul float %2857, %2856
  %2859 = call float @llvm.fabs.f32(float %2856)
  %2860 = fcmp olt float %2859, +inf
  %2861 = fcmp one float %2856, 0.000000e+00
  %2862 = and i1 %2860, %2861
  %2863 = call i1 @llvm.expect.i1(i1 %2862, i1 true)
  br i1 %2863, label %2864, label %2865

2864:                                             ; preds = %2845
  br label %2877

2865:                                             ; preds = %2845
  %2866 = fpext float %2857 to double
  %2867 = fpext float %2855 to double
  %2868 = fpext float %2849 to double
  %2869 = fmul double %2866, %2867
  %2870 = fmul double %2869, %2868
  %2871 = fptrunc double %2870 to float
  %2872 = fcmp oeq float %2857, 0.000000e+00
  %2873 = call float @llvm.fabs.f32(float %2849)
  %2874 = fcmp olt float %2873, +inf
  %2875 = and i1 %2872, %2874
  %2876 = select i1 %2875, float 0.000000e+00, float %2871
  br label %2877

2877:                                             ; preds = %2864, %2865
  %2878 = phi float [ %2876, %2865 ], [ %2858, %2864 ]
  br label %2879

2879:                                             ; preds = %2877
  %2880 = mul i64 %59, 16
  %2881 = mul i64 %58, 8
  %2882 = add i64 %2880, %2881
  %2883 = mul i64 %2882, 40
  %2884 = add i64 %2883, %57
  %2885 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2884
  store float %2640, ptr addrspace(3) %2885, align 4
  %2886 = mul i64 %58, 8
  %2887 = add i64 %2886, 1
  %2888 = add i64 %2880, %2887
  %2889 = mul i64 %2888, 40
  %2890 = add i64 %2889, %57
  %2891 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2890
  store float %2674, ptr addrspace(3) %2891, align 4
  %2892 = mul i64 %58, 8
  %2893 = add i64 %2892, 2
  %2894 = add i64 %2880, %2893
  %2895 = mul i64 %2894, 40
  %2896 = add i64 %2895, %57
  %2897 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2896
  store float %2708, ptr addrspace(3) %2897, align 4
  %2898 = mul i64 %58, 8
  %2899 = add i64 %2898, 3
  %2900 = add i64 %2880, %2899
  %2901 = mul i64 %2900, 40
  %2902 = add i64 %2901, %57
  %2903 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2902
  store float %2742, ptr addrspace(3) %2903, align 4
  %2904 = mul i64 %58, 8
  %2905 = add i64 %2904, 4
  %2906 = add i64 %2880, %2905
  %2907 = mul i64 %2906, 40
  %2908 = add i64 %2907, %57
  %2909 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2908
  store float %2776, ptr addrspace(3) %2909, align 4
  %2910 = mul i64 %58, 8
  %2911 = add i64 %2910, 5
  %2912 = add i64 %2880, %2911
  %2913 = mul i64 %2912, 40
  %2914 = add i64 %2913, %57
  %2915 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2914
  store float %2810, ptr addrspace(3) %2915, align 4
  %2916 = mul i64 %58, 8
  %2917 = add i64 %2916, 6
  %2918 = add i64 %2880, %2917
  %2919 = mul i64 %2918, 40
  %2920 = add i64 %2919, %57
  %2921 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2920
  store float %2844, ptr addrspace(3) %2921, align 4
  %2922 = mul i64 %58, 8
  %2923 = add i64 %2922, 7
  %2924 = add i64 %2880, %2923
  %2925 = mul i64 %2924, 40
  %2926 = add i64 %2925, %57
  %2927 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %2926
  store float %2878, ptr addrspace(3) %2927, align 4
  %2928 = mul i64 %58, 8
  %2929 = add i64 %86, %2928
  %2930 = add i64 %91, %57
  %2931 = add i64 %2929, 7
  %2932 = icmp ult i64 %2930, %26
  %2933 = icmp ult i64 %2931, %25
  %2934 = and i1 %2933, %2932
  %2935 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2936 = ptrtoint ptr %2935 to i64
  %2937 = mul i64 %2929, 4
  %2938 = add i64 %2936, %2937
  %2939 = urem i64 %2938, 16
  %2940 = icmp eq i64 %2939, 0
  %2941 = and i1 %2934, %2940
  br i1 %2941, label %2942, label %2951

2942:                                             ; preds = %2879
  %2943 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2944 = getelementptr float, ptr %2943, i64 %2929
  %2945 = load <4 x float>, ptr %2944, align 16
  %2946 = add i64 %2929, 4
  %2947 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2948 = getelementptr float, ptr %2947, i64 %2946
  %2949 = load <4 x float>, ptr %2948, align 16
  %2950 = shufflevector <4 x float> %2945, <4 x float> %2949, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3023

2951:                                             ; preds = %2879
  %2952 = mul i64 %58, 8
  %2953 = add i64 %86, %2952
  %2954 = icmp slt i64 %2953, %25
  %2955 = select i1 %2954, i64 %2953, i64 0
  %2956 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2957 = getelementptr inbounds nuw float, ptr %2956, i64 %2955
  %2958 = load float, ptr %2957, align 4
  %2959 = insertelement <8 x float> zeroinitializer, float %2958, i64 0
  %2960 = mul i64 %58, 8
  %2961 = add i64 %2960, 1
  %2962 = add i64 %86, %2961
  %2963 = icmp slt i64 %2962, %25
  %2964 = select i1 %2963, i64 %2962, i64 0
  %2965 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2966 = getelementptr inbounds nuw float, ptr %2965, i64 %2964
  %2967 = load float, ptr %2966, align 4
  %2968 = insertelement <8 x float> %2959, float %2967, i64 1
  %2969 = mul i64 %58, 8
  %2970 = add i64 %2969, 2
  %2971 = add i64 %86, %2970
  %2972 = icmp slt i64 %2971, %25
  %2973 = select i1 %2972, i64 %2971, i64 0
  %2974 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2975 = getelementptr inbounds nuw float, ptr %2974, i64 %2973
  %2976 = load float, ptr %2975, align 4
  %2977 = insertelement <8 x float> %2968, float %2976, i64 2
  %2978 = mul i64 %58, 8
  %2979 = add i64 %2978, 3
  %2980 = add i64 %86, %2979
  %2981 = icmp slt i64 %2980, %25
  %2982 = select i1 %2981, i64 %2980, i64 0
  %2983 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2984 = getelementptr inbounds nuw float, ptr %2983, i64 %2982
  %2985 = load float, ptr %2984, align 4
  %2986 = insertelement <8 x float> %2977, float %2985, i64 3
  %2987 = mul i64 %58, 8
  %2988 = add i64 %2987, 4
  %2989 = add i64 %86, %2988
  %2990 = icmp slt i64 %2989, %25
  %2991 = select i1 %2990, i64 %2989, i64 0
  %2992 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2993 = getelementptr inbounds nuw float, ptr %2992, i64 %2991
  %2994 = load float, ptr %2993, align 4
  %2995 = insertelement <8 x float> %2986, float %2994, i64 4
  %2996 = mul i64 %58, 8
  %2997 = add i64 %2996, 5
  %2998 = add i64 %86, %2997
  %2999 = icmp slt i64 %2998, %25
  %3000 = select i1 %2999, i64 %2998, i64 0
  %3001 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3002 = getelementptr inbounds nuw float, ptr %3001, i64 %3000
  %3003 = load float, ptr %3002, align 4
  %3004 = insertelement <8 x float> %2995, float %3003, i64 5
  %3005 = mul i64 %58, 8
  %3006 = add i64 %3005, 6
  %3007 = add i64 %86, %3006
  %3008 = icmp slt i64 %3007, %25
  %3009 = select i1 %3008, i64 %3007, i64 0
  %3010 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3011 = getelementptr inbounds nuw float, ptr %3010, i64 %3009
  %3012 = load float, ptr %3011, align 4
  %3013 = insertelement <8 x float> %3004, float %3012, i64 6
  %3014 = mul i64 %58, 8
  %3015 = add i64 %3014, 7
  %3016 = add i64 %86, %3015
  %3017 = icmp slt i64 %3016, %25
  %3018 = select i1 %3017, i64 %3016, i64 0
  %3019 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3020 = getelementptr inbounds nuw float, ptr %3019, i64 %3018
  %3021 = load float, ptr %3020, align 4
  %3022 = insertelement <8 x float> %3013, float %3021, i64 7
  br label %3023

3023:                                             ; preds = %2942, %2951
  %3024 = phi <8 x float> [ %3022, %2951 ], [ %2950, %2942 ]
  br label %3025

3025:                                             ; preds = %3023
  %3026 = add i64 %91, %57
  %3027 = icmp slt i64 %3026, %26
  %3028 = select i1 %3027, i64 %3026, i64 0
  %3029 = extractelement <8 x float> %3024, i64 0
  %3030 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3031 = getelementptr inbounds nuw i8, ptr %3030, i64 %3028
  %3032 = load i8, ptr %3031, align 1
  %3033 = zext i8 %3032 to i32
  %3034 = shl i32 %3033, 23
  %3035 = bitcast i32 %3034 to float
  %3036 = fmul float %3035, %3029
  %3037 = extractelement <8 x float> %165, i64 0
  %3038 = fmul float %3037, %3036
  %3039 = call float @llvm.fabs.f32(float %3036)
  %3040 = fcmp olt float %3039, +inf
  %3041 = fcmp one float %3036, 0.000000e+00
  %3042 = and i1 %3040, %3041
  %3043 = call i1 @llvm.expect.i1(i1 %3042, i1 true)
  br i1 %3043, label %3044, label %3045

3044:                                             ; preds = %3025
  br label %3057

3045:                                             ; preds = %3025
  %3046 = fpext float %3037 to double
  %3047 = fpext float %3035 to double
  %3048 = fpext float %3029 to double
  %3049 = fmul double %3046, %3047
  %3050 = fmul double %3049, %3048
  %3051 = fptrunc double %3050 to float
  %3052 = fcmp oeq float %3037, 0.000000e+00
  %3053 = call float @llvm.fabs.f32(float %3029)
  %3054 = fcmp olt float %3053, +inf
  %3055 = and i1 %3052, %3054
  %3056 = select i1 %3055, float 0.000000e+00, float %3051
  br label %3057

3057:                                             ; preds = %3044, %3045
  %3058 = phi float [ %3056, %3045 ], [ %3038, %3044 ]
  br label %3059

3059:                                             ; preds = %3057
  %3060 = add i64 %91, %57
  %3061 = icmp slt i64 %3060, %26
  %3062 = select i1 %3061, i64 %3060, i64 0
  %3063 = extractelement <8 x float> %3024, i64 1
  %3064 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3065 = getelementptr inbounds nuw i8, ptr %3064, i64 %3062
  %3066 = load i8, ptr %3065, align 1
  %3067 = zext i8 %3066 to i32
  %3068 = shl i32 %3067, 23
  %3069 = bitcast i32 %3068 to float
  %3070 = fmul float %3069, %3063
  %3071 = extractelement <8 x float> %165, i64 1
  %3072 = fmul float %3071, %3070
  %3073 = call float @llvm.fabs.f32(float %3070)
  %3074 = fcmp olt float %3073, +inf
  %3075 = fcmp one float %3070, 0.000000e+00
  %3076 = and i1 %3074, %3075
  %3077 = call i1 @llvm.expect.i1(i1 %3076, i1 true)
  br i1 %3077, label %3078, label %3079

3078:                                             ; preds = %3059
  br label %3091

3079:                                             ; preds = %3059
  %3080 = fpext float %3071 to double
  %3081 = fpext float %3069 to double
  %3082 = fpext float %3063 to double
  %3083 = fmul double %3080, %3081
  %3084 = fmul double %3083, %3082
  %3085 = fptrunc double %3084 to float
  %3086 = fcmp oeq float %3071, 0.000000e+00
  %3087 = call float @llvm.fabs.f32(float %3063)
  %3088 = fcmp olt float %3087, +inf
  %3089 = and i1 %3086, %3088
  %3090 = select i1 %3089, float 0.000000e+00, float %3085
  br label %3091

3091:                                             ; preds = %3078, %3079
  %3092 = phi float [ %3090, %3079 ], [ %3072, %3078 ]
  br label %3093

3093:                                             ; preds = %3091
  %3094 = add i64 %91, %57
  %3095 = icmp slt i64 %3094, %26
  %3096 = select i1 %3095, i64 %3094, i64 0
  %3097 = extractelement <8 x float> %3024, i64 2
  %3098 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3099 = getelementptr inbounds nuw i8, ptr %3098, i64 %3096
  %3100 = load i8, ptr %3099, align 1
  %3101 = zext i8 %3100 to i32
  %3102 = shl i32 %3101, 23
  %3103 = bitcast i32 %3102 to float
  %3104 = fmul float %3103, %3097
  %3105 = extractelement <8 x float> %165, i64 2
  %3106 = fmul float %3105, %3104
  %3107 = call float @llvm.fabs.f32(float %3104)
  %3108 = fcmp olt float %3107, +inf
  %3109 = fcmp one float %3104, 0.000000e+00
  %3110 = and i1 %3108, %3109
  %3111 = call i1 @llvm.expect.i1(i1 %3110, i1 true)
  br i1 %3111, label %3112, label %3113

3112:                                             ; preds = %3093
  br label %3125

3113:                                             ; preds = %3093
  %3114 = fpext float %3105 to double
  %3115 = fpext float %3103 to double
  %3116 = fpext float %3097 to double
  %3117 = fmul double %3114, %3115
  %3118 = fmul double %3117, %3116
  %3119 = fptrunc double %3118 to float
  %3120 = fcmp oeq float %3105, 0.000000e+00
  %3121 = call float @llvm.fabs.f32(float %3097)
  %3122 = fcmp olt float %3121, +inf
  %3123 = and i1 %3120, %3122
  %3124 = select i1 %3123, float 0.000000e+00, float %3119
  br label %3125

3125:                                             ; preds = %3112, %3113
  %3126 = phi float [ %3124, %3113 ], [ %3106, %3112 ]
  br label %3127

3127:                                             ; preds = %3125
  %3128 = add i64 %91, %57
  %3129 = icmp slt i64 %3128, %26
  %3130 = select i1 %3129, i64 %3128, i64 0
  %3131 = extractelement <8 x float> %3024, i64 3
  %3132 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3133 = getelementptr inbounds nuw i8, ptr %3132, i64 %3130
  %3134 = load i8, ptr %3133, align 1
  %3135 = zext i8 %3134 to i32
  %3136 = shl i32 %3135, 23
  %3137 = bitcast i32 %3136 to float
  %3138 = fmul float %3137, %3131
  %3139 = extractelement <8 x float> %165, i64 3
  %3140 = fmul float %3139, %3138
  %3141 = call float @llvm.fabs.f32(float %3138)
  %3142 = fcmp olt float %3141, +inf
  %3143 = fcmp one float %3138, 0.000000e+00
  %3144 = and i1 %3142, %3143
  %3145 = call i1 @llvm.expect.i1(i1 %3144, i1 true)
  br i1 %3145, label %3146, label %3147

3146:                                             ; preds = %3127
  br label %3159

3147:                                             ; preds = %3127
  %3148 = fpext float %3139 to double
  %3149 = fpext float %3137 to double
  %3150 = fpext float %3131 to double
  %3151 = fmul double %3148, %3149
  %3152 = fmul double %3151, %3150
  %3153 = fptrunc double %3152 to float
  %3154 = fcmp oeq float %3139, 0.000000e+00
  %3155 = call float @llvm.fabs.f32(float %3131)
  %3156 = fcmp olt float %3155, +inf
  %3157 = and i1 %3154, %3156
  %3158 = select i1 %3157, float 0.000000e+00, float %3153
  br label %3159

3159:                                             ; preds = %3146, %3147
  %3160 = phi float [ %3158, %3147 ], [ %3140, %3146 ]
  br label %3161

3161:                                             ; preds = %3159
  %3162 = add i64 %91, %57
  %3163 = icmp slt i64 %3162, %26
  %3164 = select i1 %3163, i64 %3162, i64 0
  %3165 = extractelement <8 x float> %3024, i64 4
  %3166 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3167 = getelementptr inbounds nuw i8, ptr %3166, i64 %3164
  %3168 = load i8, ptr %3167, align 1
  %3169 = zext i8 %3168 to i32
  %3170 = shl i32 %3169, 23
  %3171 = bitcast i32 %3170 to float
  %3172 = fmul float %3171, %3165
  %3173 = extractelement <8 x float> %165, i64 4
  %3174 = fmul float %3173, %3172
  %3175 = call float @llvm.fabs.f32(float %3172)
  %3176 = fcmp olt float %3175, +inf
  %3177 = fcmp one float %3172, 0.000000e+00
  %3178 = and i1 %3176, %3177
  %3179 = call i1 @llvm.expect.i1(i1 %3178, i1 true)
  br i1 %3179, label %3180, label %3181

3180:                                             ; preds = %3161
  br label %3193

3181:                                             ; preds = %3161
  %3182 = fpext float %3173 to double
  %3183 = fpext float %3171 to double
  %3184 = fpext float %3165 to double
  %3185 = fmul double %3182, %3183
  %3186 = fmul double %3185, %3184
  %3187 = fptrunc double %3186 to float
  %3188 = fcmp oeq float %3173, 0.000000e+00
  %3189 = call float @llvm.fabs.f32(float %3165)
  %3190 = fcmp olt float %3189, +inf
  %3191 = and i1 %3188, %3190
  %3192 = select i1 %3191, float 0.000000e+00, float %3187
  br label %3193

3193:                                             ; preds = %3180, %3181
  %3194 = phi float [ %3192, %3181 ], [ %3174, %3180 ]
  br label %3195

3195:                                             ; preds = %3193
  %3196 = add i64 %91, %57
  %3197 = icmp slt i64 %3196, %26
  %3198 = select i1 %3197, i64 %3196, i64 0
  %3199 = extractelement <8 x float> %3024, i64 5
  %3200 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3201 = getelementptr inbounds nuw i8, ptr %3200, i64 %3198
  %3202 = load i8, ptr %3201, align 1
  %3203 = zext i8 %3202 to i32
  %3204 = shl i32 %3203, 23
  %3205 = bitcast i32 %3204 to float
  %3206 = fmul float %3205, %3199
  %3207 = extractelement <8 x float> %165, i64 5
  %3208 = fmul float %3207, %3206
  %3209 = call float @llvm.fabs.f32(float %3206)
  %3210 = fcmp olt float %3209, +inf
  %3211 = fcmp one float %3206, 0.000000e+00
  %3212 = and i1 %3210, %3211
  %3213 = call i1 @llvm.expect.i1(i1 %3212, i1 true)
  br i1 %3213, label %3214, label %3215

3214:                                             ; preds = %3195
  br label %3227

3215:                                             ; preds = %3195
  %3216 = fpext float %3207 to double
  %3217 = fpext float %3205 to double
  %3218 = fpext float %3199 to double
  %3219 = fmul double %3216, %3217
  %3220 = fmul double %3219, %3218
  %3221 = fptrunc double %3220 to float
  %3222 = fcmp oeq float %3207, 0.000000e+00
  %3223 = call float @llvm.fabs.f32(float %3199)
  %3224 = fcmp olt float %3223, +inf
  %3225 = and i1 %3222, %3224
  %3226 = select i1 %3225, float 0.000000e+00, float %3221
  br label %3227

3227:                                             ; preds = %3214, %3215
  %3228 = phi float [ %3226, %3215 ], [ %3208, %3214 ]
  br label %3229

3229:                                             ; preds = %3227
  %3230 = add i64 %91, %57
  %3231 = icmp slt i64 %3230, %26
  %3232 = select i1 %3231, i64 %3230, i64 0
  %3233 = extractelement <8 x float> %3024, i64 6
  %3234 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3235 = getelementptr inbounds nuw i8, ptr %3234, i64 %3232
  %3236 = load i8, ptr %3235, align 1
  %3237 = zext i8 %3236 to i32
  %3238 = shl i32 %3237, 23
  %3239 = bitcast i32 %3238 to float
  %3240 = fmul float %3239, %3233
  %3241 = extractelement <8 x float> %165, i64 6
  %3242 = fmul float %3241, %3240
  %3243 = call float @llvm.fabs.f32(float %3240)
  %3244 = fcmp olt float %3243, +inf
  %3245 = fcmp one float %3240, 0.000000e+00
  %3246 = and i1 %3244, %3245
  %3247 = call i1 @llvm.expect.i1(i1 %3246, i1 true)
  br i1 %3247, label %3248, label %3249

3248:                                             ; preds = %3229
  br label %3261

3249:                                             ; preds = %3229
  %3250 = fpext float %3241 to double
  %3251 = fpext float %3239 to double
  %3252 = fpext float %3233 to double
  %3253 = fmul double %3250, %3251
  %3254 = fmul double %3253, %3252
  %3255 = fptrunc double %3254 to float
  %3256 = fcmp oeq float %3241, 0.000000e+00
  %3257 = call float @llvm.fabs.f32(float %3233)
  %3258 = fcmp olt float %3257, +inf
  %3259 = and i1 %3256, %3258
  %3260 = select i1 %3259, float 0.000000e+00, float %3255
  br label %3261

3261:                                             ; preds = %3248, %3249
  %3262 = phi float [ %3260, %3249 ], [ %3242, %3248 ]
  br label %3263

3263:                                             ; preds = %3261
  %3264 = add i64 %91, %57
  %3265 = icmp slt i64 %3264, %26
  %3266 = select i1 %3265, i64 %3264, i64 0
  %3267 = extractelement <8 x float> %3024, i64 7
  %3268 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3269 = getelementptr inbounds nuw i8, ptr %3268, i64 %3266
  %3270 = load i8, ptr %3269, align 1
  %3271 = zext i8 %3270 to i32
  %3272 = shl i32 %3271, 23
  %3273 = bitcast i32 %3272 to float
  %3274 = fmul float %3273, %3267
  %3275 = extractelement <8 x float> %165, i64 7
  %3276 = fmul float %3275, %3274
  %3277 = call float @llvm.fabs.f32(float %3274)
  %3278 = fcmp olt float %3277, +inf
  %3279 = fcmp one float %3274, 0.000000e+00
  %3280 = and i1 %3278, %3279
  %3281 = call i1 @llvm.expect.i1(i1 %3280, i1 true)
  br i1 %3281, label %3282, label %3283

3282:                                             ; preds = %3263
  br label %3295

3283:                                             ; preds = %3263
  %3284 = fpext float %3275 to double
  %3285 = fpext float %3273 to double
  %3286 = fpext float %3267 to double
  %3287 = fmul double %3284, %3285
  %3288 = fmul double %3287, %3286
  %3289 = fptrunc double %3288 to float
  %3290 = fcmp oeq float %3275, 0.000000e+00
  %3291 = call float @llvm.fabs.f32(float %3267)
  %3292 = fcmp olt float %3291, +inf
  %3293 = and i1 %3290, %3292
  %3294 = select i1 %3293, float 0.000000e+00, float %3289
  br label %3295

3295:                                             ; preds = %3282, %3283
  %3296 = phi float [ %3294, %3283 ], [ %3276, %3282 ]
  br label %3297

3297:                                             ; preds = %3295
  %3298 = mul i64 %59, 16
  %3299 = mul i64 %58, 8
  %3300 = add i64 %3298, %3299
  %3301 = add i64 %57, 16
  %3302 = mul i64 %3300, 40
  %3303 = add i64 %3302, %3301
  %3304 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3303
  store float %3058, ptr addrspace(3) %3304, align 4
  %3305 = mul i64 %58, 8
  %3306 = add i64 %3305, 1
  %3307 = add i64 %3298, %3306
  %3308 = add i64 %57, 16
  %3309 = mul i64 %3307, 40
  %3310 = add i64 %3309, %3308
  %3311 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3310
  store float %3092, ptr addrspace(3) %3311, align 4
  %3312 = mul i64 %58, 8
  %3313 = add i64 %3312, 2
  %3314 = add i64 %3298, %3313
  %3315 = add i64 %57, 16
  %3316 = mul i64 %3314, 40
  %3317 = add i64 %3316, %3315
  %3318 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3317
  store float %3126, ptr addrspace(3) %3318, align 4
  %3319 = mul i64 %58, 8
  %3320 = add i64 %3319, 3
  %3321 = add i64 %3298, %3320
  %3322 = add i64 %57, 16
  %3323 = mul i64 %3321, 40
  %3324 = add i64 %3323, %3322
  %3325 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3324
  store float %3160, ptr addrspace(3) %3325, align 4
  %3326 = mul i64 %58, 8
  %3327 = add i64 %3326, 4
  %3328 = add i64 %3298, %3327
  %3329 = add i64 %57, 16
  %3330 = mul i64 %3328, 40
  %3331 = add i64 %3330, %3329
  %3332 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3331
  store float %3194, ptr addrspace(3) %3332, align 4
  %3333 = mul i64 %58, 8
  %3334 = add i64 %3333, 5
  %3335 = add i64 %3298, %3334
  %3336 = add i64 %57, 16
  %3337 = mul i64 %3335, 40
  %3338 = add i64 %3337, %3336
  %3339 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3338
  store float %3228, ptr addrspace(3) %3339, align 4
  %3340 = mul i64 %58, 8
  %3341 = add i64 %3340, 6
  %3342 = add i64 %3298, %3341
  %3343 = add i64 %57, 16
  %3344 = mul i64 %3342, 40
  %3345 = add i64 %3344, %3343
  %3346 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3345
  store float %3262, ptr addrspace(3) %3346, align 4
  %3347 = mul i64 %58, 8
  %3348 = add i64 %3347, 7
  %3349 = add i64 %3298, %3348
  %3350 = add i64 %57, 16
  %3351 = mul i64 %3349, 40
  %3352 = add i64 %3351, %3350
  %3353 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3352
  store float %3296, ptr addrspace(3) %3353, align 4
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %3354 = mul i64 %55, 8
  %3355 = udiv i64 %3354, 32
  %3356 = urem i64 %3354, 32
  %3357 = udiv i64 %3355, 16
  %3358 = urem i64 %3355, 16
  %3359 = udiv i64 %3357, 2
  %3360 = mul i64 %3359, 4
  %3361 = add i64 %3360, 2
  %3362 = mul i64 %3361, 16
  %3363 = add i64 %3358, %3362
  %3364 = add i64 %78, %3363
  %3365 = urem i64 %3357, 2
  %3366 = mul i64 %3365, 32
  %3367 = add i64 %3356, %3366
  %3368 = add i64 %79, %3367
  %3369 = mul i64 %3355, 40
  %3370 = add i64 %3369, %3356
  %3371 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3370
  %3372 = load <8 x float>, ptr addrspace(3) %3371, align 16
  %3373 = fptrunc <8 x float> %3372 to <8 x bfloat>
  %3374 = mul i64 %3364, %26
  %3375 = add i64 %3374, %3368
  %3376 = icmp ult i64 %3364, %25
  %3377 = add i64 %3368, 7
  %3378 = icmp ult i64 %3377, %26
  %3379 = and i1 %3376, %3378
  br i1 %3379, label %3380, label %3383

3380:                                             ; preds = %3297
  %3381 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3382 = getelementptr bfloat, ptr %3381, i64 %3375
  store <8 x bfloat> %3373, ptr %3382, align 2
  br label %3454

3383:                                             ; preds = %3297
  %3384 = icmp ult i64 %3368, %26
  %3385 = and i1 %3376, %3384
  br i1 %3385, label %3386, label %3390

3386:                                             ; preds = %3383
  %3387 = extractelement <8 x bfloat> %3373, i64 0
  %3388 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3389 = getelementptr inbounds nuw bfloat, ptr %3388, i64 %3375
  store bfloat %3387, ptr %3389, align 2
  br label %3390

3390:                                             ; preds = %3386, %3383
  %3391 = add i64 %3368, 1
  %3392 = icmp ult i64 %3391, %26
  %3393 = and i1 %3376, %3392
  br i1 %3393, label %3394, label %3399

3394:                                             ; preds = %3390
  %3395 = add i64 %3375, 1
  %3396 = extractelement <8 x bfloat> %3373, i64 1
  %3397 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3398 = getelementptr inbounds nuw bfloat, ptr %3397, i64 %3395
  store bfloat %3396, ptr %3398, align 2
  br label %3399

3399:                                             ; preds = %3394, %3390
  %3400 = add i64 %3368, 2
  %3401 = icmp ult i64 %3400, %26
  %3402 = and i1 %3376, %3401
  br i1 %3402, label %3403, label %3408

3403:                                             ; preds = %3399
  %3404 = add i64 %3375, 2
  %3405 = extractelement <8 x bfloat> %3373, i64 2
  %3406 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3407 = getelementptr inbounds nuw bfloat, ptr %3406, i64 %3404
  store bfloat %3405, ptr %3407, align 2
  br label %3408

3408:                                             ; preds = %3403, %3399
  %3409 = add i64 %3368, 3
  %3410 = icmp ult i64 %3409, %26
  %3411 = and i1 %3376, %3410
  br i1 %3411, label %3412, label %3417

3412:                                             ; preds = %3408
  %3413 = add i64 %3375, 3
  %3414 = extractelement <8 x bfloat> %3373, i64 3
  %3415 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3416 = getelementptr inbounds nuw bfloat, ptr %3415, i64 %3413
  store bfloat %3414, ptr %3416, align 2
  br label %3417

3417:                                             ; preds = %3412, %3408
  %3418 = add i64 %3368, 4
  %3419 = icmp ult i64 %3418, %26
  %3420 = and i1 %3376, %3419
  br i1 %3420, label %3421, label %3426

3421:                                             ; preds = %3417
  %3422 = add i64 %3375, 4
  %3423 = extractelement <8 x bfloat> %3373, i64 4
  %3424 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3425 = getelementptr inbounds nuw bfloat, ptr %3424, i64 %3422
  store bfloat %3423, ptr %3425, align 2
  br label %3426

3426:                                             ; preds = %3421, %3417
  %3427 = add i64 %3368, 5
  %3428 = icmp ult i64 %3427, %26
  %3429 = and i1 %3376, %3428
  br i1 %3429, label %3430, label %3435

3430:                                             ; preds = %3426
  %3431 = add i64 %3375, 5
  %3432 = extractelement <8 x bfloat> %3373, i64 5
  %3433 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3434 = getelementptr inbounds nuw bfloat, ptr %3433, i64 %3431
  store bfloat %3432, ptr %3434, align 2
  br label %3435

3435:                                             ; preds = %3430, %3426
  %3436 = add i64 %3368, 6
  %3437 = icmp ult i64 %3436, %26
  %3438 = and i1 %3376, %3437
  br i1 %3438, label %3439, label %3444

3439:                                             ; preds = %3435
  %3440 = add i64 %3375, 6
  %3441 = extractelement <8 x bfloat> %3373, i64 6
  %3442 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3443 = getelementptr inbounds nuw bfloat, ptr %3442, i64 %3440
  store bfloat %3441, ptr %3443, align 2
  br label %3444

3444:                                             ; preds = %3439, %3435
  %3445 = add i64 %3368, 7
  %3446 = icmp ult i64 %3445, %26
  %3447 = and i1 %3376, %3446
  br i1 %3447, label %3448, label %3453

3448:                                             ; preds = %3444
  %3449 = add i64 %3375, 7
  %3450 = extractelement <8 x bfloat> %3373, i64 7
  %3451 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3452 = getelementptr inbounds nuw bfloat, ptr %3451, i64 %3449
  store bfloat %3450, ptr %3452, align 2
  br label %3453

3453:                                             ; preds = %3448, %3444
  br label %3454

3454:                                             ; preds = %3380, %3453
  %3455 = mul i64 %55, 8
  %3456 = add i64 %3455, 2048
  %3457 = udiv i64 %3456, 32
  %3458 = urem i64 %3456, 32
  %3459 = udiv i64 %3457, 16
  %3460 = urem i64 %3457, 16
  %3461 = udiv i64 %3459, 2
  %3462 = mul i64 %3461, 4
  %3463 = add i64 %3462, 2
  %3464 = mul i64 %3463, 16
  %3465 = add i64 %3460, %3464
  %3466 = add i64 %78, %3465
  %3467 = urem i64 %3459, 2
  %3468 = mul i64 %3467, 32
  %3469 = add i64 %3458, %3468
  %3470 = add i64 %79, %3469
  %3471 = mul i64 %3457, 40
  %3472 = add i64 %3471, %3458
  %3473 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3472
  %3474 = load <8 x float>, ptr addrspace(3) %3473, align 16
  %3475 = fptrunc <8 x float> %3474 to <8 x bfloat>
  %3476 = mul i64 %3466, %26
  %3477 = add i64 %3476, %3470
  %3478 = icmp ult i64 %3466, %25
  %3479 = add i64 %3470, 7
  %3480 = icmp ult i64 %3479, %26
  %3481 = and i1 %3478, %3480
  br i1 %3481, label %3482, label %3485

3482:                                             ; preds = %3454
  %3483 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3484 = getelementptr bfloat, ptr %3483, i64 %3477
  store <8 x bfloat> %3475, ptr %3484, align 2
  br label %3556

3485:                                             ; preds = %3454
  %3486 = icmp ult i64 %3470, %26
  %3487 = and i1 %3478, %3486
  br i1 %3487, label %3488, label %3492

3488:                                             ; preds = %3485
  %3489 = extractelement <8 x bfloat> %3475, i64 0
  %3490 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3491 = getelementptr inbounds nuw bfloat, ptr %3490, i64 %3477
  store bfloat %3489, ptr %3491, align 2
  br label %3492

3492:                                             ; preds = %3488, %3485
  %3493 = add i64 %3470, 1
  %3494 = icmp ult i64 %3493, %26
  %3495 = and i1 %3478, %3494
  br i1 %3495, label %3496, label %3501

3496:                                             ; preds = %3492
  %3497 = add i64 %3477, 1
  %3498 = extractelement <8 x bfloat> %3475, i64 1
  %3499 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3500 = getelementptr inbounds nuw bfloat, ptr %3499, i64 %3497
  store bfloat %3498, ptr %3500, align 2
  br label %3501

3501:                                             ; preds = %3496, %3492
  %3502 = add i64 %3470, 2
  %3503 = icmp ult i64 %3502, %26
  %3504 = and i1 %3478, %3503
  br i1 %3504, label %3505, label %3510

3505:                                             ; preds = %3501
  %3506 = add i64 %3477, 2
  %3507 = extractelement <8 x bfloat> %3475, i64 2
  %3508 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3509 = getelementptr inbounds nuw bfloat, ptr %3508, i64 %3506
  store bfloat %3507, ptr %3509, align 2
  br label %3510

3510:                                             ; preds = %3505, %3501
  %3511 = add i64 %3470, 3
  %3512 = icmp ult i64 %3511, %26
  %3513 = and i1 %3478, %3512
  br i1 %3513, label %3514, label %3519

3514:                                             ; preds = %3510
  %3515 = add i64 %3477, 3
  %3516 = extractelement <8 x bfloat> %3475, i64 3
  %3517 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3518 = getelementptr inbounds nuw bfloat, ptr %3517, i64 %3515
  store bfloat %3516, ptr %3518, align 2
  br label %3519

3519:                                             ; preds = %3514, %3510
  %3520 = add i64 %3470, 4
  %3521 = icmp ult i64 %3520, %26
  %3522 = and i1 %3478, %3521
  br i1 %3522, label %3523, label %3528

3523:                                             ; preds = %3519
  %3524 = add i64 %3477, 4
  %3525 = extractelement <8 x bfloat> %3475, i64 4
  %3526 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3527 = getelementptr inbounds nuw bfloat, ptr %3526, i64 %3524
  store bfloat %3525, ptr %3527, align 2
  br label %3528

3528:                                             ; preds = %3523, %3519
  %3529 = add i64 %3470, 5
  %3530 = icmp ult i64 %3529, %26
  %3531 = and i1 %3478, %3530
  br i1 %3531, label %3532, label %3537

3532:                                             ; preds = %3528
  %3533 = add i64 %3477, 5
  %3534 = extractelement <8 x bfloat> %3475, i64 5
  %3535 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3536 = getelementptr inbounds nuw bfloat, ptr %3535, i64 %3533
  store bfloat %3534, ptr %3536, align 2
  br label %3537

3537:                                             ; preds = %3532, %3528
  %3538 = add i64 %3470, 6
  %3539 = icmp ult i64 %3538, %26
  %3540 = and i1 %3478, %3539
  br i1 %3540, label %3541, label %3546

3541:                                             ; preds = %3537
  %3542 = add i64 %3477, 6
  %3543 = extractelement <8 x bfloat> %3475, i64 6
  %3544 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3545 = getelementptr inbounds nuw bfloat, ptr %3544, i64 %3542
  store bfloat %3543, ptr %3545, align 2
  br label %3546

3546:                                             ; preds = %3541, %3537
  %3547 = add i64 %3470, 7
  %3548 = icmp ult i64 %3547, %26
  %3549 = and i1 %3478, %3548
  br i1 %3549, label %3550, label %3555

3550:                                             ; preds = %3546
  %3551 = add i64 %3477, 7
  %3552 = extractelement <8 x bfloat> %3475, i64 7
  %3553 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3554 = getelementptr inbounds nuw bfloat, ptr %3553, i64 %3551
  store bfloat %3552, ptr %3554, align 2
  br label %3555

3555:                                             ; preds = %3550, %3546
  br label %3556

3556:                                             ; preds = %3482, %3555
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %3557 = mul i64 %58, 8
  %3558 = add i64 %88, %3557
  %3559 = add i64 %89, %57
  %3560 = add i64 %3558, 7
  %3561 = icmp ult i64 %3559, %26
  %3562 = icmp ult i64 %3560, %25
  %3563 = and i1 %3562, %3561
  %3564 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3565 = ptrtoint ptr %3564 to i64
  %3566 = mul i64 %3558, 4
  %3567 = add i64 %3565, %3566
  %3568 = urem i64 %3567, 16
  %3569 = icmp eq i64 %3568, 0
  %3570 = and i1 %3563, %3569
  br i1 %3570, label %3571, label %3580

3571:                                             ; preds = %3556
  %3572 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3573 = getelementptr float, ptr %3572, i64 %3558
  %3574 = load <4 x float>, ptr %3573, align 16
  %3575 = add i64 %3558, 4
  %3576 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3577 = getelementptr float, ptr %3576, i64 %3575
  %3578 = load <4 x float>, ptr %3577, align 16
  %3579 = shufflevector <4 x float> %3574, <4 x float> %3578, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3652

3580:                                             ; preds = %3556
  %3581 = mul i64 %58, 8
  %3582 = add i64 %88, %3581
  %3583 = icmp slt i64 %3582, %25
  %3584 = select i1 %3583, i64 %3582, i64 0
  %3585 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3586 = getelementptr inbounds nuw float, ptr %3585, i64 %3584
  %3587 = load float, ptr %3586, align 4
  %3588 = insertelement <8 x float> zeroinitializer, float %3587, i64 0
  %3589 = mul i64 %58, 8
  %3590 = add i64 %3589, 1
  %3591 = add i64 %88, %3590
  %3592 = icmp slt i64 %3591, %25
  %3593 = select i1 %3592, i64 %3591, i64 0
  %3594 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3595 = getelementptr inbounds nuw float, ptr %3594, i64 %3593
  %3596 = load float, ptr %3595, align 4
  %3597 = insertelement <8 x float> %3588, float %3596, i64 1
  %3598 = mul i64 %58, 8
  %3599 = add i64 %3598, 2
  %3600 = add i64 %88, %3599
  %3601 = icmp slt i64 %3600, %25
  %3602 = select i1 %3601, i64 %3600, i64 0
  %3603 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3604 = getelementptr inbounds nuw float, ptr %3603, i64 %3602
  %3605 = load float, ptr %3604, align 4
  %3606 = insertelement <8 x float> %3597, float %3605, i64 2
  %3607 = mul i64 %58, 8
  %3608 = add i64 %3607, 3
  %3609 = add i64 %88, %3608
  %3610 = icmp slt i64 %3609, %25
  %3611 = select i1 %3610, i64 %3609, i64 0
  %3612 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3613 = getelementptr inbounds nuw float, ptr %3612, i64 %3611
  %3614 = load float, ptr %3613, align 4
  %3615 = insertelement <8 x float> %3606, float %3614, i64 3
  %3616 = mul i64 %58, 8
  %3617 = add i64 %3616, 4
  %3618 = add i64 %88, %3617
  %3619 = icmp slt i64 %3618, %25
  %3620 = select i1 %3619, i64 %3618, i64 0
  %3621 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3622 = getelementptr inbounds nuw float, ptr %3621, i64 %3620
  %3623 = load float, ptr %3622, align 4
  %3624 = insertelement <8 x float> %3615, float %3623, i64 4
  %3625 = mul i64 %58, 8
  %3626 = add i64 %3625, 5
  %3627 = add i64 %88, %3626
  %3628 = icmp slt i64 %3627, %25
  %3629 = select i1 %3628, i64 %3627, i64 0
  %3630 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3631 = getelementptr inbounds nuw float, ptr %3630, i64 %3629
  %3632 = load float, ptr %3631, align 4
  %3633 = insertelement <8 x float> %3624, float %3632, i64 5
  %3634 = mul i64 %58, 8
  %3635 = add i64 %3634, 6
  %3636 = add i64 %88, %3635
  %3637 = icmp slt i64 %3636, %25
  %3638 = select i1 %3637, i64 %3636, i64 0
  %3639 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3640 = getelementptr inbounds nuw float, ptr %3639, i64 %3638
  %3641 = load float, ptr %3640, align 4
  %3642 = insertelement <8 x float> %3633, float %3641, i64 6
  %3643 = mul i64 %58, 8
  %3644 = add i64 %3643, 7
  %3645 = add i64 %88, %3644
  %3646 = icmp slt i64 %3645, %25
  %3647 = select i1 %3646, i64 %3645, i64 0
  %3648 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3649 = getelementptr inbounds nuw float, ptr %3648, i64 %3647
  %3650 = load float, ptr %3649, align 4
  %3651 = insertelement <8 x float> %3642, float %3650, i64 7
  br label %3652

3652:                                             ; preds = %3571, %3580
  %3653 = phi <8 x float> [ %3651, %3580 ], [ %3579, %3571 ]
  br label %3654

3654:                                             ; preds = %3652
  %3655 = add i64 %89, %57
  %3656 = icmp slt i64 %3655, %26
  %3657 = select i1 %3656, i64 %3655, i64 0
  %3658 = extractelement <8 x float> %3653, i64 0
  %3659 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3660 = getelementptr inbounds nuw i8, ptr %3659, i64 %3657
  %3661 = load i8, ptr %3660, align 1
  %3662 = zext i8 %3661 to i32
  %3663 = shl i32 %3662, 23
  %3664 = bitcast i32 %3663 to float
  %3665 = fmul float %3664, %3658
  %3666 = extractelement <8 x float> %166, i64 0
  %3667 = fmul float %3666, %3665
  %3668 = call float @llvm.fabs.f32(float %3665)
  %3669 = fcmp olt float %3668, +inf
  %3670 = fcmp one float %3665, 0.000000e+00
  %3671 = and i1 %3669, %3670
  %3672 = call i1 @llvm.expect.i1(i1 %3671, i1 true)
  br i1 %3672, label %3673, label %3674

3673:                                             ; preds = %3654
  br label %3686

3674:                                             ; preds = %3654
  %3675 = fpext float %3666 to double
  %3676 = fpext float %3664 to double
  %3677 = fpext float %3658 to double
  %3678 = fmul double %3675, %3676
  %3679 = fmul double %3678, %3677
  %3680 = fptrunc double %3679 to float
  %3681 = fcmp oeq float %3666, 0.000000e+00
  %3682 = call float @llvm.fabs.f32(float %3658)
  %3683 = fcmp olt float %3682, +inf
  %3684 = and i1 %3681, %3683
  %3685 = select i1 %3684, float 0.000000e+00, float %3680
  br label %3686

3686:                                             ; preds = %3673, %3674
  %3687 = phi float [ %3685, %3674 ], [ %3667, %3673 ]
  br label %3688

3688:                                             ; preds = %3686
  %3689 = add i64 %89, %57
  %3690 = icmp slt i64 %3689, %26
  %3691 = select i1 %3690, i64 %3689, i64 0
  %3692 = extractelement <8 x float> %3653, i64 1
  %3693 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3694 = getelementptr inbounds nuw i8, ptr %3693, i64 %3691
  %3695 = load i8, ptr %3694, align 1
  %3696 = zext i8 %3695 to i32
  %3697 = shl i32 %3696, 23
  %3698 = bitcast i32 %3697 to float
  %3699 = fmul float %3698, %3692
  %3700 = extractelement <8 x float> %166, i64 1
  %3701 = fmul float %3700, %3699
  %3702 = call float @llvm.fabs.f32(float %3699)
  %3703 = fcmp olt float %3702, +inf
  %3704 = fcmp one float %3699, 0.000000e+00
  %3705 = and i1 %3703, %3704
  %3706 = call i1 @llvm.expect.i1(i1 %3705, i1 true)
  br i1 %3706, label %3707, label %3708

3707:                                             ; preds = %3688
  br label %3720

3708:                                             ; preds = %3688
  %3709 = fpext float %3700 to double
  %3710 = fpext float %3698 to double
  %3711 = fpext float %3692 to double
  %3712 = fmul double %3709, %3710
  %3713 = fmul double %3712, %3711
  %3714 = fptrunc double %3713 to float
  %3715 = fcmp oeq float %3700, 0.000000e+00
  %3716 = call float @llvm.fabs.f32(float %3692)
  %3717 = fcmp olt float %3716, +inf
  %3718 = and i1 %3715, %3717
  %3719 = select i1 %3718, float 0.000000e+00, float %3714
  br label %3720

3720:                                             ; preds = %3707, %3708
  %3721 = phi float [ %3719, %3708 ], [ %3701, %3707 ]
  br label %3722

3722:                                             ; preds = %3720
  %3723 = add i64 %89, %57
  %3724 = icmp slt i64 %3723, %26
  %3725 = select i1 %3724, i64 %3723, i64 0
  %3726 = extractelement <8 x float> %3653, i64 2
  %3727 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3728 = getelementptr inbounds nuw i8, ptr %3727, i64 %3725
  %3729 = load i8, ptr %3728, align 1
  %3730 = zext i8 %3729 to i32
  %3731 = shl i32 %3730, 23
  %3732 = bitcast i32 %3731 to float
  %3733 = fmul float %3732, %3726
  %3734 = extractelement <8 x float> %166, i64 2
  %3735 = fmul float %3734, %3733
  %3736 = call float @llvm.fabs.f32(float %3733)
  %3737 = fcmp olt float %3736, +inf
  %3738 = fcmp one float %3733, 0.000000e+00
  %3739 = and i1 %3737, %3738
  %3740 = call i1 @llvm.expect.i1(i1 %3739, i1 true)
  br i1 %3740, label %3741, label %3742

3741:                                             ; preds = %3722
  br label %3754

3742:                                             ; preds = %3722
  %3743 = fpext float %3734 to double
  %3744 = fpext float %3732 to double
  %3745 = fpext float %3726 to double
  %3746 = fmul double %3743, %3744
  %3747 = fmul double %3746, %3745
  %3748 = fptrunc double %3747 to float
  %3749 = fcmp oeq float %3734, 0.000000e+00
  %3750 = call float @llvm.fabs.f32(float %3726)
  %3751 = fcmp olt float %3750, +inf
  %3752 = and i1 %3749, %3751
  %3753 = select i1 %3752, float 0.000000e+00, float %3748
  br label %3754

3754:                                             ; preds = %3741, %3742
  %3755 = phi float [ %3753, %3742 ], [ %3735, %3741 ]
  br label %3756

3756:                                             ; preds = %3754
  %3757 = add i64 %89, %57
  %3758 = icmp slt i64 %3757, %26
  %3759 = select i1 %3758, i64 %3757, i64 0
  %3760 = extractelement <8 x float> %3653, i64 3
  %3761 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3762 = getelementptr inbounds nuw i8, ptr %3761, i64 %3759
  %3763 = load i8, ptr %3762, align 1
  %3764 = zext i8 %3763 to i32
  %3765 = shl i32 %3764, 23
  %3766 = bitcast i32 %3765 to float
  %3767 = fmul float %3766, %3760
  %3768 = extractelement <8 x float> %166, i64 3
  %3769 = fmul float %3768, %3767
  %3770 = call float @llvm.fabs.f32(float %3767)
  %3771 = fcmp olt float %3770, +inf
  %3772 = fcmp one float %3767, 0.000000e+00
  %3773 = and i1 %3771, %3772
  %3774 = call i1 @llvm.expect.i1(i1 %3773, i1 true)
  br i1 %3774, label %3775, label %3776

3775:                                             ; preds = %3756
  br label %3788

3776:                                             ; preds = %3756
  %3777 = fpext float %3768 to double
  %3778 = fpext float %3766 to double
  %3779 = fpext float %3760 to double
  %3780 = fmul double %3777, %3778
  %3781 = fmul double %3780, %3779
  %3782 = fptrunc double %3781 to float
  %3783 = fcmp oeq float %3768, 0.000000e+00
  %3784 = call float @llvm.fabs.f32(float %3760)
  %3785 = fcmp olt float %3784, +inf
  %3786 = and i1 %3783, %3785
  %3787 = select i1 %3786, float 0.000000e+00, float %3782
  br label %3788

3788:                                             ; preds = %3775, %3776
  %3789 = phi float [ %3787, %3776 ], [ %3769, %3775 ]
  br label %3790

3790:                                             ; preds = %3788
  %3791 = add i64 %89, %57
  %3792 = icmp slt i64 %3791, %26
  %3793 = select i1 %3792, i64 %3791, i64 0
  %3794 = extractelement <8 x float> %3653, i64 4
  %3795 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3796 = getelementptr inbounds nuw i8, ptr %3795, i64 %3793
  %3797 = load i8, ptr %3796, align 1
  %3798 = zext i8 %3797 to i32
  %3799 = shl i32 %3798, 23
  %3800 = bitcast i32 %3799 to float
  %3801 = fmul float %3800, %3794
  %3802 = extractelement <8 x float> %166, i64 4
  %3803 = fmul float %3802, %3801
  %3804 = call float @llvm.fabs.f32(float %3801)
  %3805 = fcmp olt float %3804, +inf
  %3806 = fcmp one float %3801, 0.000000e+00
  %3807 = and i1 %3805, %3806
  %3808 = call i1 @llvm.expect.i1(i1 %3807, i1 true)
  br i1 %3808, label %3809, label %3810

3809:                                             ; preds = %3790
  br label %3822

3810:                                             ; preds = %3790
  %3811 = fpext float %3802 to double
  %3812 = fpext float %3800 to double
  %3813 = fpext float %3794 to double
  %3814 = fmul double %3811, %3812
  %3815 = fmul double %3814, %3813
  %3816 = fptrunc double %3815 to float
  %3817 = fcmp oeq float %3802, 0.000000e+00
  %3818 = call float @llvm.fabs.f32(float %3794)
  %3819 = fcmp olt float %3818, +inf
  %3820 = and i1 %3817, %3819
  %3821 = select i1 %3820, float 0.000000e+00, float %3816
  br label %3822

3822:                                             ; preds = %3809, %3810
  %3823 = phi float [ %3821, %3810 ], [ %3803, %3809 ]
  br label %3824

3824:                                             ; preds = %3822
  %3825 = add i64 %89, %57
  %3826 = icmp slt i64 %3825, %26
  %3827 = select i1 %3826, i64 %3825, i64 0
  %3828 = extractelement <8 x float> %3653, i64 5
  %3829 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3830 = getelementptr inbounds nuw i8, ptr %3829, i64 %3827
  %3831 = load i8, ptr %3830, align 1
  %3832 = zext i8 %3831 to i32
  %3833 = shl i32 %3832, 23
  %3834 = bitcast i32 %3833 to float
  %3835 = fmul float %3834, %3828
  %3836 = extractelement <8 x float> %166, i64 5
  %3837 = fmul float %3836, %3835
  %3838 = call float @llvm.fabs.f32(float %3835)
  %3839 = fcmp olt float %3838, +inf
  %3840 = fcmp one float %3835, 0.000000e+00
  %3841 = and i1 %3839, %3840
  %3842 = call i1 @llvm.expect.i1(i1 %3841, i1 true)
  br i1 %3842, label %3843, label %3844

3843:                                             ; preds = %3824
  br label %3856

3844:                                             ; preds = %3824
  %3845 = fpext float %3836 to double
  %3846 = fpext float %3834 to double
  %3847 = fpext float %3828 to double
  %3848 = fmul double %3845, %3846
  %3849 = fmul double %3848, %3847
  %3850 = fptrunc double %3849 to float
  %3851 = fcmp oeq float %3836, 0.000000e+00
  %3852 = call float @llvm.fabs.f32(float %3828)
  %3853 = fcmp olt float %3852, +inf
  %3854 = and i1 %3851, %3853
  %3855 = select i1 %3854, float 0.000000e+00, float %3850
  br label %3856

3856:                                             ; preds = %3843, %3844
  %3857 = phi float [ %3855, %3844 ], [ %3837, %3843 ]
  br label %3858

3858:                                             ; preds = %3856
  %3859 = add i64 %89, %57
  %3860 = icmp slt i64 %3859, %26
  %3861 = select i1 %3860, i64 %3859, i64 0
  %3862 = extractelement <8 x float> %3653, i64 6
  %3863 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3864 = getelementptr inbounds nuw i8, ptr %3863, i64 %3861
  %3865 = load i8, ptr %3864, align 1
  %3866 = zext i8 %3865 to i32
  %3867 = shl i32 %3866, 23
  %3868 = bitcast i32 %3867 to float
  %3869 = fmul float %3868, %3862
  %3870 = extractelement <8 x float> %166, i64 6
  %3871 = fmul float %3870, %3869
  %3872 = call float @llvm.fabs.f32(float %3869)
  %3873 = fcmp olt float %3872, +inf
  %3874 = fcmp one float %3869, 0.000000e+00
  %3875 = and i1 %3873, %3874
  %3876 = call i1 @llvm.expect.i1(i1 %3875, i1 true)
  br i1 %3876, label %3877, label %3878

3877:                                             ; preds = %3858
  br label %3890

3878:                                             ; preds = %3858
  %3879 = fpext float %3870 to double
  %3880 = fpext float %3868 to double
  %3881 = fpext float %3862 to double
  %3882 = fmul double %3879, %3880
  %3883 = fmul double %3882, %3881
  %3884 = fptrunc double %3883 to float
  %3885 = fcmp oeq float %3870, 0.000000e+00
  %3886 = call float @llvm.fabs.f32(float %3862)
  %3887 = fcmp olt float %3886, +inf
  %3888 = and i1 %3885, %3887
  %3889 = select i1 %3888, float 0.000000e+00, float %3884
  br label %3890

3890:                                             ; preds = %3877, %3878
  %3891 = phi float [ %3889, %3878 ], [ %3871, %3877 ]
  br label %3892

3892:                                             ; preds = %3890
  %3893 = add i64 %89, %57
  %3894 = icmp slt i64 %3893, %26
  %3895 = select i1 %3894, i64 %3893, i64 0
  %3896 = extractelement <8 x float> %3653, i64 7
  %3897 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3898 = getelementptr inbounds nuw i8, ptr %3897, i64 %3895
  %3899 = load i8, ptr %3898, align 1
  %3900 = zext i8 %3899 to i32
  %3901 = shl i32 %3900, 23
  %3902 = bitcast i32 %3901 to float
  %3903 = fmul float %3902, %3896
  %3904 = extractelement <8 x float> %166, i64 7
  %3905 = fmul float %3904, %3903
  %3906 = call float @llvm.fabs.f32(float %3903)
  %3907 = fcmp olt float %3906, +inf
  %3908 = fcmp one float %3903, 0.000000e+00
  %3909 = and i1 %3907, %3908
  %3910 = call i1 @llvm.expect.i1(i1 %3909, i1 true)
  br i1 %3910, label %3911, label %3912

3911:                                             ; preds = %3892
  br label %3924

3912:                                             ; preds = %3892
  %3913 = fpext float %3904 to double
  %3914 = fpext float %3902 to double
  %3915 = fpext float %3896 to double
  %3916 = fmul double %3913, %3914
  %3917 = fmul double %3916, %3915
  %3918 = fptrunc double %3917 to float
  %3919 = fcmp oeq float %3904, 0.000000e+00
  %3920 = call float @llvm.fabs.f32(float %3896)
  %3921 = fcmp olt float %3920, +inf
  %3922 = and i1 %3919, %3921
  %3923 = select i1 %3922, float 0.000000e+00, float %3918
  br label %3924

3924:                                             ; preds = %3911, %3912
  %3925 = phi float [ %3923, %3912 ], [ %3905, %3911 ]
  br label %3926

3926:                                             ; preds = %3924
  %3927 = mul i64 %59, 16
  %3928 = mul i64 %58, 8
  %3929 = add i64 %3927, %3928
  %3930 = mul i64 %3929, 40
  %3931 = add i64 %3930, %57
  %3932 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3931
  store float %3687, ptr addrspace(3) %3932, align 4
  %3933 = mul i64 %58, 8
  %3934 = add i64 %3933, 1
  %3935 = add i64 %3927, %3934
  %3936 = mul i64 %3935, 40
  %3937 = add i64 %3936, %57
  %3938 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3937
  store float %3721, ptr addrspace(3) %3938, align 4
  %3939 = mul i64 %58, 8
  %3940 = add i64 %3939, 2
  %3941 = add i64 %3927, %3940
  %3942 = mul i64 %3941, 40
  %3943 = add i64 %3942, %57
  %3944 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3943
  store float %3755, ptr addrspace(3) %3944, align 4
  %3945 = mul i64 %58, 8
  %3946 = add i64 %3945, 3
  %3947 = add i64 %3927, %3946
  %3948 = mul i64 %3947, 40
  %3949 = add i64 %3948, %57
  %3950 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3949
  store float %3789, ptr addrspace(3) %3950, align 4
  %3951 = mul i64 %58, 8
  %3952 = add i64 %3951, 4
  %3953 = add i64 %3927, %3952
  %3954 = mul i64 %3953, 40
  %3955 = add i64 %3954, %57
  %3956 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3955
  store float %3823, ptr addrspace(3) %3956, align 4
  %3957 = mul i64 %58, 8
  %3958 = add i64 %3957, 5
  %3959 = add i64 %3927, %3958
  %3960 = mul i64 %3959, 40
  %3961 = add i64 %3960, %57
  %3962 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3961
  store float %3857, ptr addrspace(3) %3962, align 4
  %3963 = mul i64 %58, 8
  %3964 = add i64 %3963, 6
  %3965 = add i64 %3927, %3964
  %3966 = mul i64 %3965, 40
  %3967 = add i64 %3966, %57
  %3968 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3967
  store float %3891, ptr addrspace(3) %3968, align 4
  %3969 = mul i64 %58, 8
  %3970 = add i64 %3969, 7
  %3971 = add i64 %3927, %3970
  %3972 = mul i64 %3971, 40
  %3973 = add i64 %3972, %57
  %3974 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %3973
  store float %3925, ptr addrspace(3) %3974, align 4
  %3975 = mul i64 %58, 8
  %3976 = add i64 %88, %3975
  %3977 = add i64 %91, %57
  %3978 = add i64 %3976, 7
  %3979 = icmp ult i64 %3977, %26
  %3980 = icmp ult i64 %3978, %25
  %3981 = and i1 %3980, %3979
  %3982 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3983 = ptrtoint ptr %3982 to i64
  %3984 = mul i64 %3976, 4
  %3985 = add i64 %3983, %3984
  %3986 = urem i64 %3985, 16
  %3987 = icmp eq i64 %3986, 0
  %3988 = and i1 %3981, %3987
  br i1 %3988, label %3989, label %3998

3989:                                             ; preds = %3926
  %3990 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3991 = getelementptr float, ptr %3990, i64 %3976
  %3992 = load <4 x float>, ptr %3991, align 16
  %3993 = add i64 %3976, 4
  %3994 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3995 = getelementptr float, ptr %3994, i64 %3993
  %3996 = load <4 x float>, ptr %3995, align 16
  %3997 = shufflevector <4 x float> %3992, <4 x float> %3996, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %4070

3998:                                             ; preds = %3926
  %3999 = mul i64 %58, 8
  %4000 = add i64 %88, %3999
  %4001 = icmp slt i64 %4000, %25
  %4002 = select i1 %4001, i64 %4000, i64 0
  %4003 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4004 = getelementptr inbounds nuw float, ptr %4003, i64 %4002
  %4005 = load float, ptr %4004, align 4
  %4006 = insertelement <8 x float> zeroinitializer, float %4005, i64 0
  %4007 = mul i64 %58, 8
  %4008 = add i64 %4007, 1
  %4009 = add i64 %88, %4008
  %4010 = icmp slt i64 %4009, %25
  %4011 = select i1 %4010, i64 %4009, i64 0
  %4012 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4013 = getelementptr inbounds nuw float, ptr %4012, i64 %4011
  %4014 = load float, ptr %4013, align 4
  %4015 = insertelement <8 x float> %4006, float %4014, i64 1
  %4016 = mul i64 %58, 8
  %4017 = add i64 %4016, 2
  %4018 = add i64 %88, %4017
  %4019 = icmp slt i64 %4018, %25
  %4020 = select i1 %4019, i64 %4018, i64 0
  %4021 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4022 = getelementptr inbounds nuw float, ptr %4021, i64 %4020
  %4023 = load float, ptr %4022, align 4
  %4024 = insertelement <8 x float> %4015, float %4023, i64 2
  %4025 = mul i64 %58, 8
  %4026 = add i64 %4025, 3
  %4027 = add i64 %88, %4026
  %4028 = icmp slt i64 %4027, %25
  %4029 = select i1 %4028, i64 %4027, i64 0
  %4030 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4031 = getelementptr inbounds nuw float, ptr %4030, i64 %4029
  %4032 = load float, ptr %4031, align 4
  %4033 = insertelement <8 x float> %4024, float %4032, i64 3
  %4034 = mul i64 %58, 8
  %4035 = add i64 %4034, 4
  %4036 = add i64 %88, %4035
  %4037 = icmp slt i64 %4036, %25
  %4038 = select i1 %4037, i64 %4036, i64 0
  %4039 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4040 = getelementptr inbounds nuw float, ptr %4039, i64 %4038
  %4041 = load float, ptr %4040, align 4
  %4042 = insertelement <8 x float> %4033, float %4041, i64 4
  %4043 = mul i64 %58, 8
  %4044 = add i64 %4043, 5
  %4045 = add i64 %88, %4044
  %4046 = icmp slt i64 %4045, %25
  %4047 = select i1 %4046, i64 %4045, i64 0
  %4048 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4049 = getelementptr inbounds nuw float, ptr %4048, i64 %4047
  %4050 = load float, ptr %4049, align 4
  %4051 = insertelement <8 x float> %4042, float %4050, i64 5
  %4052 = mul i64 %58, 8
  %4053 = add i64 %4052, 6
  %4054 = add i64 %88, %4053
  %4055 = icmp slt i64 %4054, %25
  %4056 = select i1 %4055, i64 %4054, i64 0
  %4057 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4058 = getelementptr inbounds nuw float, ptr %4057, i64 %4056
  %4059 = load float, ptr %4058, align 4
  %4060 = insertelement <8 x float> %4051, float %4059, i64 6
  %4061 = mul i64 %58, 8
  %4062 = add i64 %4061, 7
  %4063 = add i64 %88, %4062
  %4064 = icmp slt i64 %4063, %25
  %4065 = select i1 %4064, i64 %4063, i64 0
  %4066 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %4067 = getelementptr inbounds nuw float, ptr %4066, i64 %4065
  %4068 = load float, ptr %4067, align 4
  %4069 = insertelement <8 x float> %4060, float %4068, i64 7
  br label %4070

4070:                                             ; preds = %3989, %3998
  %4071 = phi <8 x float> [ %4069, %3998 ], [ %3997, %3989 ]
  br label %4072

4072:                                             ; preds = %4070
  %4073 = add i64 %91, %57
  %4074 = icmp slt i64 %4073, %26
  %4075 = select i1 %4074, i64 %4073, i64 0
  %4076 = extractelement <8 x float> %4071, i64 0
  %4077 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4078 = getelementptr inbounds nuw i8, ptr %4077, i64 %4075
  %4079 = load i8, ptr %4078, align 1
  %4080 = zext i8 %4079 to i32
  %4081 = shl i32 %4080, 23
  %4082 = bitcast i32 %4081 to float
  %4083 = fmul float %4082, %4076
  %4084 = extractelement <8 x float> %167, i64 0
  %4085 = fmul float %4084, %4083
  %4086 = call float @llvm.fabs.f32(float %4083)
  %4087 = fcmp olt float %4086, +inf
  %4088 = fcmp one float %4083, 0.000000e+00
  %4089 = and i1 %4087, %4088
  %4090 = call i1 @llvm.expect.i1(i1 %4089, i1 true)
  br i1 %4090, label %4091, label %4092

4091:                                             ; preds = %4072
  br label %4104

4092:                                             ; preds = %4072
  %4093 = fpext float %4084 to double
  %4094 = fpext float %4082 to double
  %4095 = fpext float %4076 to double
  %4096 = fmul double %4093, %4094
  %4097 = fmul double %4096, %4095
  %4098 = fptrunc double %4097 to float
  %4099 = fcmp oeq float %4084, 0.000000e+00
  %4100 = call float @llvm.fabs.f32(float %4076)
  %4101 = fcmp olt float %4100, +inf
  %4102 = and i1 %4099, %4101
  %4103 = select i1 %4102, float 0.000000e+00, float %4098
  br label %4104

4104:                                             ; preds = %4091, %4092
  %4105 = phi float [ %4103, %4092 ], [ %4085, %4091 ]
  br label %4106

4106:                                             ; preds = %4104
  %4107 = add i64 %91, %57
  %4108 = icmp slt i64 %4107, %26
  %4109 = select i1 %4108, i64 %4107, i64 0
  %4110 = extractelement <8 x float> %4071, i64 1
  %4111 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4112 = getelementptr inbounds nuw i8, ptr %4111, i64 %4109
  %4113 = load i8, ptr %4112, align 1
  %4114 = zext i8 %4113 to i32
  %4115 = shl i32 %4114, 23
  %4116 = bitcast i32 %4115 to float
  %4117 = fmul float %4116, %4110
  %4118 = extractelement <8 x float> %167, i64 1
  %4119 = fmul float %4118, %4117
  %4120 = call float @llvm.fabs.f32(float %4117)
  %4121 = fcmp olt float %4120, +inf
  %4122 = fcmp one float %4117, 0.000000e+00
  %4123 = and i1 %4121, %4122
  %4124 = call i1 @llvm.expect.i1(i1 %4123, i1 true)
  br i1 %4124, label %4125, label %4126

4125:                                             ; preds = %4106
  br label %4138

4126:                                             ; preds = %4106
  %4127 = fpext float %4118 to double
  %4128 = fpext float %4116 to double
  %4129 = fpext float %4110 to double
  %4130 = fmul double %4127, %4128
  %4131 = fmul double %4130, %4129
  %4132 = fptrunc double %4131 to float
  %4133 = fcmp oeq float %4118, 0.000000e+00
  %4134 = call float @llvm.fabs.f32(float %4110)
  %4135 = fcmp olt float %4134, +inf
  %4136 = and i1 %4133, %4135
  %4137 = select i1 %4136, float 0.000000e+00, float %4132
  br label %4138

4138:                                             ; preds = %4125, %4126
  %4139 = phi float [ %4137, %4126 ], [ %4119, %4125 ]
  br label %4140

4140:                                             ; preds = %4138
  %4141 = add i64 %91, %57
  %4142 = icmp slt i64 %4141, %26
  %4143 = select i1 %4142, i64 %4141, i64 0
  %4144 = extractelement <8 x float> %4071, i64 2
  %4145 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4146 = getelementptr inbounds nuw i8, ptr %4145, i64 %4143
  %4147 = load i8, ptr %4146, align 1
  %4148 = zext i8 %4147 to i32
  %4149 = shl i32 %4148, 23
  %4150 = bitcast i32 %4149 to float
  %4151 = fmul float %4150, %4144
  %4152 = extractelement <8 x float> %167, i64 2
  %4153 = fmul float %4152, %4151
  %4154 = call float @llvm.fabs.f32(float %4151)
  %4155 = fcmp olt float %4154, +inf
  %4156 = fcmp one float %4151, 0.000000e+00
  %4157 = and i1 %4155, %4156
  %4158 = call i1 @llvm.expect.i1(i1 %4157, i1 true)
  br i1 %4158, label %4159, label %4160

4159:                                             ; preds = %4140
  br label %4172

4160:                                             ; preds = %4140
  %4161 = fpext float %4152 to double
  %4162 = fpext float %4150 to double
  %4163 = fpext float %4144 to double
  %4164 = fmul double %4161, %4162
  %4165 = fmul double %4164, %4163
  %4166 = fptrunc double %4165 to float
  %4167 = fcmp oeq float %4152, 0.000000e+00
  %4168 = call float @llvm.fabs.f32(float %4144)
  %4169 = fcmp olt float %4168, +inf
  %4170 = and i1 %4167, %4169
  %4171 = select i1 %4170, float 0.000000e+00, float %4166
  br label %4172

4172:                                             ; preds = %4159, %4160
  %4173 = phi float [ %4171, %4160 ], [ %4153, %4159 ]
  br label %4174

4174:                                             ; preds = %4172
  %4175 = add i64 %91, %57
  %4176 = icmp slt i64 %4175, %26
  %4177 = select i1 %4176, i64 %4175, i64 0
  %4178 = extractelement <8 x float> %4071, i64 3
  %4179 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4180 = getelementptr inbounds nuw i8, ptr %4179, i64 %4177
  %4181 = load i8, ptr %4180, align 1
  %4182 = zext i8 %4181 to i32
  %4183 = shl i32 %4182, 23
  %4184 = bitcast i32 %4183 to float
  %4185 = fmul float %4184, %4178
  %4186 = extractelement <8 x float> %167, i64 3
  %4187 = fmul float %4186, %4185
  %4188 = call float @llvm.fabs.f32(float %4185)
  %4189 = fcmp olt float %4188, +inf
  %4190 = fcmp one float %4185, 0.000000e+00
  %4191 = and i1 %4189, %4190
  %4192 = call i1 @llvm.expect.i1(i1 %4191, i1 true)
  br i1 %4192, label %4193, label %4194

4193:                                             ; preds = %4174
  br label %4206

4194:                                             ; preds = %4174
  %4195 = fpext float %4186 to double
  %4196 = fpext float %4184 to double
  %4197 = fpext float %4178 to double
  %4198 = fmul double %4195, %4196
  %4199 = fmul double %4198, %4197
  %4200 = fptrunc double %4199 to float
  %4201 = fcmp oeq float %4186, 0.000000e+00
  %4202 = call float @llvm.fabs.f32(float %4178)
  %4203 = fcmp olt float %4202, +inf
  %4204 = and i1 %4201, %4203
  %4205 = select i1 %4204, float 0.000000e+00, float %4200
  br label %4206

4206:                                             ; preds = %4193, %4194
  %4207 = phi float [ %4205, %4194 ], [ %4187, %4193 ]
  br label %4208

4208:                                             ; preds = %4206
  %4209 = add i64 %91, %57
  %4210 = icmp slt i64 %4209, %26
  %4211 = select i1 %4210, i64 %4209, i64 0
  %4212 = extractelement <8 x float> %4071, i64 4
  %4213 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4214 = getelementptr inbounds nuw i8, ptr %4213, i64 %4211
  %4215 = load i8, ptr %4214, align 1
  %4216 = zext i8 %4215 to i32
  %4217 = shl i32 %4216, 23
  %4218 = bitcast i32 %4217 to float
  %4219 = fmul float %4218, %4212
  %4220 = extractelement <8 x float> %167, i64 4
  %4221 = fmul float %4220, %4219
  %4222 = call float @llvm.fabs.f32(float %4219)
  %4223 = fcmp olt float %4222, +inf
  %4224 = fcmp one float %4219, 0.000000e+00
  %4225 = and i1 %4223, %4224
  %4226 = call i1 @llvm.expect.i1(i1 %4225, i1 true)
  br i1 %4226, label %4227, label %4228

4227:                                             ; preds = %4208
  br label %4240

4228:                                             ; preds = %4208
  %4229 = fpext float %4220 to double
  %4230 = fpext float %4218 to double
  %4231 = fpext float %4212 to double
  %4232 = fmul double %4229, %4230
  %4233 = fmul double %4232, %4231
  %4234 = fptrunc double %4233 to float
  %4235 = fcmp oeq float %4220, 0.000000e+00
  %4236 = call float @llvm.fabs.f32(float %4212)
  %4237 = fcmp olt float %4236, +inf
  %4238 = and i1 %4235, %4237
  %4239 = select i1 %4238, float 0.000000e+00, float %4234
  br label %4240

4240:                                             ; preds = %4227, %4228
  %4241 = phi float [ %4239, %4228 ], [ %4221, %4227 ]
  br label %4242

4242:                                             ; preds = %4240
  %4243 = add i64 %91, %57
  %4244 = icmp slt i64 %4243, %26
  %4245 = select i1 %4244, i64 %4243, i64 0
  %4246 = extractelement <8 x float> %4071, i64 5
  %4247 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4248 = getelementptr inbounds nuw i8, ptr %4247, i64 %4245
  %4249 = load i8, ptr %4248, align 1
  %4250 = zext i8 %4249 to i32
  %4251 = shl i32 %4250, 23
  %4252 = bitcast i32 %4251 to float
  %4253 = fmul float %4252, %4246
  %4254 = extractelement <8 x float> %167, i64 5
  %4255 = fmul float %4254, %4253
  %4256 = call float @llvm.fabs.f32(float %4253)
  %4257 = fcmp olt float %4256, +inf
  %4258 = fcmp one float %4253, 0.000000e+00
  %4259 = and i1 %4257, %4258
  %4260 = call i1 @llvm.expect.i1(i1 %4259, i1 true)
  br i1 %4260, label %4261, label %4262

4261:                                             ; preds = %4242
  br label %4274

4262:                                             ; preds = %4242
  %4263 = fpext float %4254 to double
  %4264 = fpext float %4252 to double
  %4265 = fpext float %4246 to double
  %4266 = fmul double %4263, %4264
  %4267 = fmul double %4266, %4265
  %4268 = fptrunc double %4267 to float
  %4269 = fcmp oeq float %4254, 0.000000e+00
  %4270 = call float @llvm.fabs.f32(float %4246)
  %4271 = fcmp olt float %4270, +inf
  %4272 = and i1 %4269, %4271
  %4273 = select i1 %4272, float 0.000000e+00, float %4268
  br label %4274

4274:                                             ; preds = %4261, %4262
  %4275 = phi float [ %4273, %4262 ], [ %4255, %4261 ]
  br label %4276

4276:                                             ; preds = %4274
  %4277 = add i64 %91, %57
  %4278 = icmp slt i64 %4277, %26
  %4279 = select i1 %4278, i64 %4277, i64 0
  %4280 = extractelement <8 x float> %4071, i64 6
  %4281 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4282 = getelementptr inbounds nuw i8, ptr %4281, i64 %4279
  %4283 = load i8, ptr %4282, align 1
  %4284 = zext i8 %4283 to i32
  %4285 = shl i32 %4284, 23
  %4286 = bitcast i32 %4285 to float
  %4287 = fmul float %4286, %4280
  %4288 = extractelement <8 x float> %167, i64 6
  %4289 = fmul float %4288, %4287
  %4290 = call float @llvm.fabs.f32(float %4287)
  %4291 = fcmp olt float %4290, +inf
  %4292 = fcmp one float %4287, 0.000000e+00
  %4293 = and i1 %4291, %4292
  %4294 = call i1 @llvm.expect.i1(i1 %4293, i1 true)
  br i1 %4294, label %4295, label %4296

4295:                                             ; preds = %4276
  br label %4308

4296:                                             ; preds = %4276
  %4297 = fpext float %4288 to double
  %4298 = fpext float %4286 to double
  %4299 = fpext float %4280 to double
  %4300 = fmul double %4297, %4298
  %4301 = fmul double %4300, %4299
  %4302 = fptrunc double %4301 to float
  %4303 = fcmp oeq float %4288, 0.000000e+00
  %4304 = call float @llvm.fabs.f32(float %4280)
  %4305 = fcmp olt float %4304, +inf
  %4306 = and i1 %4303, %4305
  %4307 = select i1 %4306, float 0.000000e+00, float %4302
  br label %4308

4308:                                             ; preds = %4295, %4296
  %4309 = phi float [ %4307, %4296 ], [ %4289, %4295 ]
  br label %4310

4310:                                             ; preds = %4308
  %4311 = add i64 %91, %57
  %4312 = icmp slt i64 %4311, %26
  %4313 = select i1 %4312, i64 %4311, i64 0
  %4314 = extractelement <8 x float> %4071, i64 7
  %4315 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4316 = getelementptr inbounds nuw i8, ptr %4315, i64 %4313
  %4317 = load i8, ptr %4316, align 1
  %4318 = zext i8 %4317 to i32
  %4319 = shl i32 %4318, 23
  %4320 = bitcast i32 %4319 to float
  %4321 = fmul float %4320, %4314
  %4322 = extractelement <8 x float> %167, i64 7
  %4323 = fmul float %4322, %4321
  %4324 = call float @llvm.fabs.f32(float %4321)
  %4325 = fcmp olt float %4324, +inf
  %4326 = fcmp one float %4321, 0.000000e+00
  %4327 = and i1 %4325, %4326
  %4328 = call i1 @llvm.expect.i1(i1 %4327, i1 true)
  br i1 %4328, label %4329, label %4330

4329:                                             ; preds = %4310
  br label %4342

4330:                                             ; preds = %4310
  %4331 = fpext float %4322 to double
  %4332 = fpext float %4320 to double
  %4333 = fpext float %4314 to double
  %4334 = fmul double %4331, %4332
  %4335 = fmul double %4334, %4333
  %4336 = fptrunc double %4335 to float
  %4337 = fcmp oeq float %4322, 0.000000e+00
  %4338 = call float @llvm.fabs.f32(float %4314)
  %4339 = fcmp olt float %4338, +inf
  %4340 = and i1 %4337, %4339
  %4341 = select i1 %4340, float 0.000000e+00, float %4336
  br label %4342

4342:                                             ; preds = %4329, %4330
  %4343 = phi float [ %4341, %4330 ], [ %4323, %4329 ]
  br label %4344

4344:                                             ; preds = %4342
  %4345 = mul i64 %59, 16
  %4346 = mul i64 %58, 8
  %4347 = add i64 %4345, %4346
  %4348 = add i64 %57, 16
  %4349 = mul i64 %4347, 40
  %4350 = add i64 %4349, %4348
  %4351 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4350
  store float %4105, ptr addrspace(3) %4351, align 4
  %4352 = mul i64 %58, 8
  %4353 = add i64 %4352, 1
  %4354 = add i64 %4345, %4353
  %4355 = add i64 %57, 16
  %4356 = mul i64 %4354, 40
  %4357 = add i64 %4356, %4355
  %4358 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4357
  store float %4139, ptr addrspace(3) %4358, align 4
  %4359 = mul i64 %58, 8
  %4360 = add i64 %4359, 2
  %4361 = add i64 %4345, %4360
  %4362 = add i64 %57, 16
  %4363 = mul i64 %4361, 40
  %4364 = add i64 %4363, %4362
  %4365 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4364
  store float %4173, ptr addrspace(3) %4365, align 4
  %4366 = mul i64 %58, 8
  %4367 = add i64 %4366, 3
  %4368 = add i64 %4345, %4367
  %4369 = add i64 %57, 16
  %4370 = mul i64 %4368, 40
  %4371 = add i64 %4370, %4369
  %4372 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4371
  store float %4207, ptr addrspace(3) %4372, align 4
  %4373 = mul i64 %58, 8
  %4374 = add i64 %4373, 4
  %4375 = add i64 %4345, %4374
  %4376 = add i64 %57, 16
  %4377 = mul i64 %4375, 40
  %4378 = add i64 %4377, %4376
  %4379 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4378
  store float %4241, ptr addrspace(3) %4379, align 4
  %4380 = mul i64 %58, 8
  %4381 = add i64 %4380, 5
  %4382 = add i64 %4345, %4381
  %4383 = add i64 %57, 16
  %4384 = mul i64 %4382, 40
  %4385 = add i64 %4384, %4383
  %4386 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4385
  store float %4275, ptr addrspace(3) %4386, align 4
  %4387 = mul i64 %58, 8
  %4388 = add i64 %4387, 6
  %4389 = add i64 %4345, %4388
  %4390 = add i64 %57, 16
  %4391 = mul i64 %4389, 40
  %4392 = add i64 %4391, %4390
  %4393 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4392
  store float %4309, ptr addrspace(3) %4393, align 4
  %4394 = mul i64 %58, 8
  %4395 = add i64 %4394, 7
  %4396 = add i64 %4345, %4395
  %4397 = add i64 %57, 16
  %4398 = mul i64 %4396, 40
  %4399 = add i64 %4398, %4397
  %4400 = getelementptr inbounds nuw float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4399
  store float %4343, ptr addrspace(3) %4400, align 4
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %4401 = mul i64 %55, 8
  %4402 = udiv i64 %4401, 32
  %4403 = urem i64 %4401, 32
  %4404 = udiv i64 %4402, 16
  %4405 = urem i64 %4402, 16
  %4406 = udiv i64 %4404, 2
  %4407 = mul i64 %4406, 4
  %4408 = add i64 %4407, 3
  %4409 = mul i64 %4408, 16
  %4410 = add i64 %4405, %4409
  %4411 = add i64 %78, %4410
  %4412 = urem i64 %4404, 2
  %4413 = mul i64 %4412, 32
  %4414 = add i64 %4403, %4413
  %4415 = add i64 %79, %4414
  %4416 = mul i64 %4402, 40
  %4417 = add i64 %4416, %4403
  %4418 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4417
  %4419 = load <8 x float>, ptr addrspace(3) %4418, align 16
  %4420 = fptrunc <8 x float> %4419 to <8 x bfloat>
  %4421 = mul i64 %4411, %26
  %4422 = add i64 %4421, %4415
  %4423 = icmp ult i64 %4411, %25
  %4424 = add i64 %4415, 7
  %4425 = icmp ult i64 %4424, %26
  %4426 = and i1 %4423, %4425
  br i1 %4426, label %4427, label %4430

4427:                                             ; preds = %4344
  %4428 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4429 = getelementptr bfloat, ptr %4428, i64 %4422
  store <8 x bfloat> %4420, ptr %4429, align 2
  br label %4501

4430:                                             ; preds = %4344
  %4431 = icmp ult i64 %4415, %26
  %4432 = and i1 %4423, %4431
  br i1 %4432, label %4433, label %4437

4433:                                             ; preds = %4430
  %4434 = extractelement <8 x bfloat> %4420, i64 0
  %4435 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4436 = getelementptr inbounds nuw bfloat, ptr %4435, i64 %4422
  store bfloat %4434, ptr %4436, align 2
  br label %4437

4437:                                             ; preds = %4433, %4430
  %4438 = add i64 %4415, 1
  %4439 = icmp ult i64 %4438, %26
  %4440 = and i1 %4423, %4439
  br i1 %4440, label %4441, label %4446

4441:                                             ; preds = %4437
  %4442 = add i64 %4422, 1
  %4443 = extractelement <8 x bfloat> %4420, i64 1
  %4444 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4445 = getelementptr inbounds nuw bfloat, ptr %4444, i64 %4442
  store bfloat %4443, ptr %4445, align 2
  br label %4446

4446:                                             ; preds = %4441, %4437
  %4447 = add i64 %4415, 2
  %4448 = icmp ult i64 %4447, %26
  %4449 = and i1 %4423, %4448
  br i1 %4449, label %4450, label %4455

4450:                                             ; preds = %4446
  %4451 = add i64 %4422, 2
  %4452 = extractelement <8 x bfloat> %4420, i64 2
  %4453 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4454 = getelementptr inbounds nuw bfloat, ptr %4453, i64 %4451
  store bfloat %4452, ptr %4454, align 2
  br label %4455

4455:                                             ; preds = %4450, %4446
  %4456 = add i64 %4415, 3
  %4457 = icmp ult i64 %4456, %26
  %4458 = and i1 %4423, %4457
  br i1 %4458, label %4459, label %4464

4459:                                             ; preds = %4455
  %4460 = add i64 %4422, 3
  %4461 = extractelement <8 x bfloat> %4420, i64 3
  %4462 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4463 = getelementptr inbounds nuw bfloat, ptr %4462, i64 %4460
  store bfloat %4461, ptr %4463, align 2
  br label %4464

4464:                                             ; preds = %4459, %4455
  %4465 = add i64 %4415, 4
  %4466 = icmp ult i64 %4465, %26
  %4467 = and i1 %4423, %4466
  br i1 %4467, label %4468, label %4473

4468:                                             ; preds = %4464
  %4469 = add i64 %4422, 4
  %4470 = extractelement <8 x bfloat> %4420, i64 4
  %4471 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4472 = getelementptr inbounds nuw bfloat, ptr %4471, i64 %4469
  store bfloat %4470, ptr %4472, align 2
  br label %4473

4473:                                             ; preds = %4468, %4464
  %4474 = add i64 %4415, 5
  %4475 = icmp ult i64 %4474, %26
  %4476 = and i1 %4423, %4475
  br i1 %4476, label %4477, label %4482

4477:                                             ; preds = %4473
  %4478 = add i64 %4422, 5
  %4479 = extractelement <8 x bfloat> %4420, i64 5
  %4480 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4481 = getelementptr inbounds nuw bfloat, ptr %4480, i64 %4478
  store bfloat %4479, ptr %4481, align 2
  br label %4482

4482:                                             ; preds = %4477, %4473
  %4483 = add i64 %4415, 6
  %4484 = icmp ult i64 %4483, %26
  %4485 = and i1 %4423, %4484
  br i1 %4485, label %4486, label %4491

4486:                                             ; preds = %4482
  %4487 = add i64 %4422, 6
  %4488 = extractelement <8 x bfloat> %4420, i64 6
  %4489 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4490 = getelementptr inbounds nuw bfloat, ptr %4489, i64 %4487
  store bfloat %4488, ptr %4490, align 2
  br label %4491

4491:                                             ; preds = %4486, %4482
  %4492 = add i64 %4415, 7
  %4493 = icmp ult i64 %4492, %26
  %4494 = and i1 %4423, %4493
  br i1 %4494, label %4495, label %4500

4495:                                             ; preds = %4491
  %4496 = add i64 %4422, 7
  %4497 = extractelement <8 x bfloat> %4420, i64 7
  %4498 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4499 = getelementptr inbounds nuw bfloat, ptr %4498, i64 %4496
  store bfloat %4497, ptr %4499, align 2
  br label %4500

4500:                                             ; preds = %4495, %4491
  br label %4501

4501:                                             ; preds = %4427, %4500
  %4502 = mul i64 %55, 8
  %4503 = add i64 %4502, 2048
  %4504 = udiv i64 %4503, 32
  %4505 = urem i64 %4503, 32
  %4506 = udiv i64 %4504, 16
  %4507 = urem i64 %4504, 16
  %4508 = udiv i64 %4506, 2
  %4509 = mul i64 %4508, 4
  %4510 = add i64 %4509, 3
  %4511 = mul i64 %4510, 16
  %4512 = add i64 %4507, %4511
  %4513 = add i64 %78, %4512
  %4514 = urem i64 %4506, 2
  %4515 = mul i64 %4514, 32
  %4516 = add i64 %4505, %4515
  %4517 = add i64 %79, %4516
  %4518 = mul i64 %4504, 40
  %4519 = add i64 %4518, %4505
  %4520 = getelementptr float, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %4519
  %4521 = load <8 x float>, ptr addrspace(3) %4520, align 16
  %4522 = fptrunc <8 x float> %4521 to <8 x bfloat>
  %4523 = mul i64 %4513, %26
  %4524 = add i64 %4523, %4517
  %4525 = icmp ult i64 %4513, %25
  %4526 = add i64 %4517, 7
  %4527 = icmp ult i64 %4526, %26
  %4528 = and i1 %4525, %4527
  br i1 %4528, label %4529, label %4532

4529:                                             ; preds = %4501
  %4530 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4531 = getelementptr bfloat, ptr %4530, i64 %4524
  store <8 x bfloat> %4522, ptr %4531, align 2
  br label %4603

4532:                                             ; preds = %4501
  %4533 = icmp ult i64 %4517, %26
  %4534 = and i1 %4525, %4533
  br i1 %4534, label %4535, label %4539

4535:                                             ; preds = %4532
  %4536 = extractelement <8 x bfloat> %4522, i64 0
  %4537 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4538 = getelementptr inbounds nuw bfloat, ptr %4537, i64 %4524
  store bfloat %4536, ptr %4538, align 2
  br label %4539

4539:                                             ; preds = %4535, %4532
  %4540 = add i64 %4517, 1
  %4541 = icmp ult i64 %4540, %26
  %4542 = and i1 %4525, %4541
  br i1 %4542, label %4543, label %4548

4543:                                             ; preds = %4539
  %4544 = add i64 %4524, 1
  %4545 = extractelement <8 x bfloat> %4522, i64 1
  %4546 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4547 = getelementptr inbounds nuw bfloat, ptr %4546, i64 %4544
  store bfloat %4545, ptr %4547, align 2
  br label %4548

4548:                                             ; preds = %4543, %4539
  %4549 = add i64 %4517, 2
  %4550 = icmp ult i64 %4549, %26
  %4551 = and i1 %4525, %4550
  br i1 %4551, label %4552, label %4557

4552:                                             ; preds = %4548
  %4553 = add i64 %4524, 2
  %4554 = extractelement <8 x bfloat> %4522, i64 2
  %4555 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4556 = getelementptr inbounds nuw bfloat, ptr %4555, i64 %4553
  store bfloat %4554, ptr %4556, align 2
  br label %4557

4557:                                             ; preds = %4552, %4548
  %4558 = add i64 %4517, 3
  %4559 = icmp ult i64 %4558, %26
  %4560 = and i1 %4525, %4559
  br i1 %4560, label %4561, label %4566

4561:                                             ; preds = %4557
  %4562 = add i64 %4524, 3
  %4563 = extractelement <8 x bfloat> %4522, i64 3
  %4564 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4565 = getelementptr inbounds nuw bfloat, ptr %4564, i64 %4562
  store bfloat %4563, ptr %4565, align 2
  br label %4566

4566:                                             ; preds = %4561, %4557
  %4567 = add i64 %4517, 4
  %4568 = icmp ult i64 %4567, %26
  %4569 = and i1 %4525, %4568
  br i1 %4569, label %4570, label %4575

4570:                                             ; preds = %4566
  %4571 = add i64 %4524, 4
  %4572 = extractelement <8 x bfloat> %4522, i64 4
  %4573 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4574 = getelementptr inbounds nuw bfloat, ptr %4573, i64 %4571
  store bfloat %4572, ptr %4574, align 2
  br label %4575

4575:                                             ; preds = %4570, %4566
  %4576 = add i64 %4517, 5
  %4577 = icmp ult i64 %4576, %26
  %4578 = and i1 %4525, %4577
  br i1 %4578, label %4579, label %4584

4579:                                             ; preds = %4575
  %4580 = add i64 %4524, 5
  %4581 = extractelement <8 x bfloat> %4522, i64 5
  %4582 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4583 = getelementptr inbounds nuw bfloat, ptr %4582, i64 %4580
  store bfloat %4581, ptr %4583, align 2
  br label %4584

4584:                                             ; preds = %4579, %4575
  %4585 = add i64 %4517, 6
  %4586 = icmp ult i64 %4585, %26
  %4587 = and i1 %4525, %4586
  br i1 %4587, label %4588, label %4593

4588:                                             ; preds = %4584
  %4589 = add i64 %4524, 6
  %4590 = extractelement <8 x bfloat> %4522, i64 6
  %4591 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4592 = getelementptr inbounds nuw bfloat, ptr %4591, i64 %4589
  store bfloat %4590, ptr %4592, align 2
  br label %4593

4593:                                             ; preds = %4588, %4584
  %4594 = add i64 %4517, 7
  %4595 = icmp ult i64 %4594, %26
  %4596 = and i1 %4525, %4595
  br i1 %4596, label %4597, label %4602

4597:                                             ; preds = %4593
  %4598 = add i64 %4524, 7
  %4599 = extractelement <8 x bfloat> %4522, i64 7
  %4600 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4601 = getelementptr inbounds nuw bfloat, ptr %4600, i64 %4598
  store bfloat %4599, ptr %4601, align 2
  br label %4602

4602:                                             ; preds = %4597, %4593
  br label %4603

4603:                                             ; preds = %4529, %4602
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.expect.i1(i1, i1) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #6

attributes #0 = { "amdgpu-flat-work-group-size"="256,256" "target-features"="-cumode" "uniform-work-group-size" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { convergent nocallback nofree nounwind willreturn }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #6 = { convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
