; ModuleID = 'benchmarks/baselines/rocm_folded_c_lds_transpose_20261002/restored-pressure/kernel.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"
target triple = "amdgcn-amd-amdhsa"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal unnamed_addr addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal unnamed_addr addrspace(3) global [5120 x i8] undef

; Function Attrs: norecurse nounwind
define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr nofree readnone captures(none) %0, ptr nofree readonly captures(none) %1, i64 %2, i64 %3, i64 %4, ptr nofree readnone captures(none) %5, ptr nofree readonly captures(none) %6, i64 %7, i64 %8, i64 %9, ptr nofree readnone captures(none) %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr nofree readnone captures(none) %15, ptr nofree readonly captures(none) %16, i64 %17, i64 %18, i64 %19, ptr nofree readnone captures(none) %20, ptr nofree writeonly %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) local_unnamed_addr #0 !reqd_work_group_size !1 {
.lr.ph:
  %28 = addrspacecast ptr %21 to ptr addrspace(1)
  %29 = addrspacecast ptr %16 to ptr addrspace(1)
  %30 = addrspacecast ptr %11 to ptr addrspace(1)
  %31 = addrspacecast ptr %6 to ptr addrspace(1)
  %32 = addrspacecast ptr %1 to ptr addrspace(1)
  %33 = tail call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %34 = zext nneg i32 %33 to i64
  %35 = and i64 %34, 15
  %36 = and i64 %34, 192
  %37 = and i64 %34, 32
  %38 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %39 = sext i32 %38 to i64
  %40 = add i64 %25, 255
  %41 = lshr i64 %40, 8
  %42 = add i64 %26, 63
  %43 = lshr i64 %42, 4
  %44 = and i64 %43, 1152921504606846972
  %.frozen = freeze i64 %44
  %45 = udiv i64 %39, %.frozen
  %46 = shl i64 %45, 2
  %47 = sub i64 %41, %46
  %48 = tail call i64 @llvm.umin.i64(i64 %47, i64 4)
  %49 = mul i64 %45, %.frozen
  %.decomposed = sub i64 %39, %49
  %.frozen59 = freeze i64 %48
  %50 = udiv i64 %.decomposed, %.frozen59
  %51 = mul i64 %50, %.frozen59
  %.decomposed60 = sub i64 %.decomposed, %51
  %52 = add nuw i64 %.decomposed60, %46
  %53 = shl i64 %52, 8
  %54 = shl i64 %50, 6
  %55 = or disjoint i64 %53, %36
  %56 = or disjoint i64 %36, 16
  %57 = or disjoint i64 %53, %56
  %58 = or disjoint i64 %36, 32
  %59 = or disjoint i64 %53, %58
  %60 = or disjoint i64 %36, 48
  %61 = or disjoint i64 %53, %60
  %62 = or disjoint i64 %37, 16
  %63 = lshr i64 %34, 2
  %64 = shl nuw nsw i64 %34, 4
  %65 = and i64 %64, 48
  %66 = or disjoint i64 %53, %63
  %67 = mul i64 %66, %27
  %68 = mul nuw nsw i64 %63, 80
  %69 = add nuw nsw i64 %68, %65
  %70 = or disjoint i64 %63, 64
  %71 = or disjoint i64 %53, %70
  %72 = mul i64 %71, %27
  %73 = mul nuw nsw i64 %70, 80
  %74 = add nuw nsw i64 %73, %65
  %75 = or disjoint i64 %63, 128
  %76 = or disjoint i64 %53, %75
  %77 = mul i64 %76, %27
  %78 = mul nuw nsw i64 %75, 80
  %79 = add nuw nsw i64 %78, %65
  %80 = or disjoint i64 %63, 192
  %81 = or disjoint i64 %53, %80
  %82 = mul i64 %81, %27
  %83 = mul nuw nsw i64 %80, 80
  %84 = add nuw nsw i64 %83, %65
  %85 = or disjoint i64 %54, %63
  %86 = mul i64 %85, %27
  %87 = icmp ugt i64 %27, 63
  tail call void @llvm.assume(i1 %87)
  %88 = lshr i64 %27, 6
  %89 = add i64 %27, -64
  %90 = getelementptr i8, ptr addrspace(1) %32, i64 %67
  %91 = getelementptr i8, ptr addrspace(1) %90, i64 %65
  %92 = load <16 x i8>, ptr addrspace(1) %91, align 16
  %93 = getelementptr i8, ptr addrspace(1) %32, i64 %72
  %94 = getelementptr i8, ptr addrspace(1) %93, i64 %65
  %95 = load <16 x i8>, ptr addrspace(1) %94, align 16
  %96 = getelementptr i8, ptr addrspace(1) %32, i64 %77
  %97 = getelementptr i8, ptr addrspace(1) %96, i64 %65
  %98 = load <16 x i8>, ptr addrspace(1) %97, align 16
  %99 = getelementptr i8, ptr addrspace(1) %32, i64 %82
  %100 = getelementptr i8, ptr addrspace(1) %99, i64 %65
  %101 = load <16 x i8>, ptr addrspace(1) %100, align 16
  %102 = trunc nuw nsw i64 %69 to i32
  %103 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %102
  store <16 x i8> %92, ptr addrspace(3) %103, align 16
  %104 = trunc nuw nsw i64 %74 to i32
  %105 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %104
  store <16 x i8> %95, ptr addrspace(3) %105, align 16
  %106 = trunc nuw nsw i64 %79 to i32
  %107 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %106
  store <16 x i8> %98, ptr addrspace(3) %107, align 16
  %108 = trunc nuw nsw i64 %84 to i32
  %109 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %108
  store <16 x i8> %101, ptr addrspace(3) %109, align 16
  %110 = getelementptr i8, ptr addrspace(1) %31, i64 %86
  %111 = getelementptr i8, ptr addrspace(1) %110, i64 %65
  %112 = load <16 x i8>, ptr addrspace(1) %111, align 16
  %113 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %102
  store <16 x i8> %112, ptr addrspace(3) %113, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %114 = lshr i64 %34, 1
  %115 = and i64 %114, 8
  %116 = and i64 %34, 207
  %117 = mul nuw nsw i64 %116, 80
  %118 = or disjoint i64 %115, %117
  %119 = trunc nuw nsw i64 %118 to i32
  %120 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %119
  %121 = or disjoint i64 %56, %35
  %122 = mul nuw nsw i64 %121, 80
  %123 = or disjoint i64 %122, %115
  %124 = trunc nuw nsw i64 %123 to i32
  %125 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %124
  %126 = or disjoint i64 %58, %35
  %127 = mul nuw nsw i64 %126, 80
  %128 = or disjoint i64 %127, %115
  %129 = trunc nuw nsw i64 %128 to i32
  %130 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %129
  %131 = or disjoint i64 %60, %35
  %132 = mul nuw nsw i64 %131, 80
  %133 = or disjoint i64 %132, %115
  %134 = trunc nuw nsw i64 %133 to i32
  %135 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %134
  %136 = and i64 %34, 47
  %137 = mul nuw nsw i64 %136, 80
  %138 = or disjoint i64 %115, %137
  %139 = trunc nuw nsw i64 %138 to i32
  %140 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %139
  %141 = or disjoint i64 %62, %35
  %142 = mul nuw nsw i64 %141, 80
  %143 = or disjoint i64 %142, %115
  %144 = trunc nuw nsw i64 %143 to i32
  %145 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %144
  %146 = or disjoint i64 %115, 16
  %147 = add nuw nsw i64 %146, %117
  %148 = trunc nuw nsw i64 %147 to i32
  %149 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %148
  %150 = add nuw nsw i64 %122, %146
  %151 = trunc nuw nsw i64 %150 to i32
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %151
  %153 = add nuw nsw i64 %127, %146
  %154 = trunc nuw nsw i64 %153 to i32
  %155 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %154
  %156 = add nuw nsw i64 %132, %146
  %157 = trunc nuw nsw i64 %156 to i32
  %158 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %157
  %159 = add nuw nsw i64 %146, %137
  %160 = trunc nuw nsw i64 %159 to i32
  %161 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %160
  %162 = add nuw nsw i64 %142, %146
  %163 = trunc nuw nsw i64 %162 to i32
  %164 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %163
  %165 = or disjoint i64 %115, 32
  %166 = add nuw nsw i64 %165, %117
  %167 = trunc nuw nsw i64 %166 to i32
  %168 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %167
  %169 = add nuw nsw i64 %122, %165
  %170 = trunc nuw nsw i64 %169 to i32
  %171 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %170
  %172 = add nuw nsw i64 %127, %165
  %173 = trunc nuw nsw i64 %172 to i32
  %174 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %173
  %175 = add nuw nsw i64 %132, %165
  %176 = trunc nuw nsw i64 %175 to i32
  %177 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %176
  %178 = add nuw nsw i64 %165, %137
  %179 = trunc nuw nsw i64 %178 to i32
  %180 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %179
  %181 = add nuw nsw i64 %142, %165
  %182 = trunc nuw nsw i64 %181 to i32
  %183 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %182
  %184 = or disjoint i64 %115, 48
  %185 = add nuw nsw i64 %184, %117
  %186 = trunc nuw nsw i64 %185 to i32
  %187 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %186
  %188 = add nuw nsw i64 %122, %184
  %189 = trunc nuw nsw i64 %188 to i32
  %190 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %189
  %191 = add nuw nsw i64 %127, %184
  %192 = trunc nuw nsw i64 %191 to i32
  %193 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %192
  %194 = add nuw nsw i64 %132, %184
  %195 = trunc nuw nsw i64 %194 to i32
  %196 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %195
  %197 = add nuw nsw i64 %184, %137
  %198 = trunc nuw nsw i64 %197 to i32
  %199 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %198
  %200 = add nuw nsw i64 %142, %184
  %201 = trunc nuw nsw i64 %200 to i32
  %202 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %201
  br label %203

203:                                              ; preds = %.lr.ph, %203
  %204 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %281, %203 ]
  %205 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %280, %203 ]
  %206 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %279, %203 ]
  %207 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %278, %203 ]
  %208 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %277, %203 ]
  %209 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %276, %203 ]
  %210 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %275, %203 ]
  %211 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %274, %203 ]
  %212 = phi i64 [ 0, %.lr.ph ], [ %282, %203 ]
  %213 = shl i64 %212, 6
  %214 = add nuw i64 %213, 64
  %215 = tail call i64 @llvm.umin.i64(i64 %214, i64 %89)
  %216 = getelementptr i8, ptr addrspace(1) %91, i64 %215
  %217 = load <16 x i8>, ptr addrspace(1) %216, align 16
  %218 = getelementptr i8, ptr addrspace(1) %94, i64 %215
  %219 = load <16 x i8>, ptr addrspace(1) %218, align 16
  %220 = getelementptr i8, ptr addrspace(1) %97, i64 %215
  %221 = load <16 x i8>, ptr addrspace(1) %220, align 16
  %222 = getelementptr i8, ptr addrspace(1) %100, i64 %215
  %223 = load <16 x i8>, ptr addrspace(1) %222, align 16
  %224 = getelementptr i8, ptr addrspace(1) %111, i64 %215
  %225 = load <16 x i8>, ptr addrspace(1) %224, align 16
  %226 = load <2 x i32>, ptr addrspace(3) %120, align 8
  %227 = load <2 x i32>, ptr addrspace(3) %125, align 8
  %228 = load <2 x i32>, ptr addrspace(3) %130, align 8
  %229 = load <2 x i32>, ptr addrspace(3) %135, align 8
  %230 = load <2 x i32>, ptr addrspace(3) %140, align 8
  %231 = load <2 x i32>, ptr addrspace(3) %145, align 8
  %232 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %226, <2 x i32> %230, <8 x float> %211)
  %233 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %226, <2 x i32> %231, <8 x float> %210)
  %234 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %230, <8 x float> %209)
  %235 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %231, <8 x float> %208)
  %236 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %230, <8 x float> %207)
  %237 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %231, <8 x float> %206)
  %238 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %230, <8 x float> %205)
  %239 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %231, <8 x float> %204)
  %240 = load <2 x i32>, ptr addrspace(3) %149, align 8
  %241 = load <2 x i32>, ptr addrspace(3) %152, align 8
  %242 = load <2 x i32>, ptr addrspace(3) %155, align 8
  %243 = load <2 x i32>, ptr addrspace(3) %158, align 8
  %244 = load <2 x i32>, ptr addrspace(3) %161, align 8
  %245 = load <2 x i32>, ptr addrspace(3) %164, align 8
  %246 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %240, <2 x i32> %244, <8 x float> %232)
  %247 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %240, <2 x i32> %245, <8 x float> %233)
  %248 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %244, <8 x float> %234)
  %249 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %245, <8 x float> %235)
  %250 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %244, <8 x float> %236)
  %251 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %245, <8 x float> %237)
  %252 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %244, <8 x float> %238)
  %253 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %245, <8 x float> %239)
  %254 = load <2 x i32>, ptr addrspace(3) %168, align 8
  %255 = load <2 x i32>, ptr addrspace(3) %171, align 8
  %256 = load <2 x i32>, ptr addrspace(3) %174, align 8
  %257 = load <2 x i32>, ptr addrspace(3) %177, align 8
  %258 = load <2 x i32>, ptr addrspace(3) %180, align 8
  %259 = load <2 x i32>, ptr addrspace(3) %183, align 8
  %260 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %254, <2 x i32> %258, <8 x float> %246)
  %261 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %254, <2 x i32> %259, <8 x float> %247)
  %262 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %258, <8 x float> %248)
  %263 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %259, <8 x float> %249)
  %264 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %258, <8 x float> %250)
  %265 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %259, <8 x float> %251)
  %266 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %258, <8 x float> %252)
  %267 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %259, <8 x float> %253)
  %268 = load <2 x i32>, ptr addrspace(3) %187, align 8
  %269 = load <2 x i32>, ptr addrspace(3) %190, align 8
  %270 = load <2 x i32>, ptr addrspace(3) %193, align 8
  %271 = load <2 x i32>, ptr addrspace(3) %196, align 8
  %272 = load <2 x i32>, ptr addrspace(3) %199, align 8
  %273 = load <2 x i32>, ptr addrspace(3) %202, align 8
  %274 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %268, <2 x i32> %272, <8 x float> %260)
  %275 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %268, <2 x i32> %273, <8 x float> %261)
  %276 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %272, <8 x float> %262)
  %277 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %273, <8 x float> %263)
  %278 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %272, <8 x float> %264)
  %279 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %273, <8 x float> %265)
  %280 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %272, <8 x float> %266)
  %281 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %273, <8 x float> %267)
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  store <16 x i8> %217, ptr addrspace(3) %103, align 16
  store <16 x i8> %219, ptr addrspace(3) %105, align 16
  store <16 x i8> %221, ptr addrspace(3) %107, align 16
  store <16 x i8> %223, ptr addrspace(3) %109, align 16
  store <16 x i8> %225, ptr addrspace(3) %113, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %282 = add nuw nsw i64 %212, 1
  %exitcond.not = icmp eq i64 %282, %88
  br i1 %exitcond.not, label %._crit_edge, label %203

._crit_edge:                                      ; preds = %203
  %283 = or disjoint i64 %55, %115
  %284 = or disjoint i64 %54, %35
  %285 = or disjoint i64 %284, %37
  %286 = or disjoint i64 %283, 7
  %287 = icmp ult i64 %285, %26
  %288 = icmp ult i64 %286, %25
  %289 = and i1 %287, %288
  %290 = ptrtoint ptr %11 to i64
  %291 = and i64 %290, 15
  %292 = icmp eq i64 %291, 0
  %293 = and i1 %292, %289
  br i1 %293, label %294, label %300

294:                                              ; preds = %._crit_edge
  %295 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %283
  %296 = load <4 x float>, ptr addrspace(1) %295, align 16
  %297 = getelementptr i8, ptr addrspace(1) %295, i64 16
  %298 = load <4 x float>, ptr addrspace(1) %297, align 16
  %299 = shufflevector <4 x float> %296, <4 x float> %298, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %347

300:                                              ; preds = %._crit_edge
  %301 = icmp slt i64 %283, %25
  %302 = select i1 %301, i64 %283, i64 0
  %303 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %302
  %304 = load float, ptr addrspace(1) %303, align 4, !amdgpu.noclobber !3
  %305 = insertelement <8 x float> poison, float %304, i64 0
  %306 = or disjoint i64 %283, 1
  %307 = icmp slt i64 %306, %25
  %308 = select i1 %307, i64 %306, i64 0
  %309 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %308
  %310 = load float, ptr addrspace(1) %309, align 4, !amdgpu.noclobber !3
  %311 = insertelement <8 x float> %305, float %310, i64 1
  %312 = or disjoint i64 %283, 2
  %313 = icmp slt i64 %312, %25
  %314 = select i1 %313, i64 %312, i64 0
  %315 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %314
  %316 = load float, ptr addrspace(1) %315, align 4, !amdgpu.noclobber !3
  %317 = insertelement <8 x float> %311, float %316, i64 2
  %318 = or disjoint i64 %283, 3
  %319 = icmp slt i64 %318, %25
  %320 = select i1 %319, i64 %318, i64 0
  %321 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %320
  %322 = load float, ptr addrspace(1) %321, align 4, !amdgpu.noclobber !3
  %323 = insertelement <8 x float> %317, float %322, i64 3
  %324 = or disjoint i64 %283, 4
  %325 = icmp slt i64 %324, %25
  %326 = select i1 %325, i64 %324, i64 0
  %327 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %326
  %328 = load float, ptr addrspace(1) %327, align 4, !amdgpu.noclobber !3
  %329 = insertelement <8 x float> %323, float %328, i64 4
  %330 = or disjoint i64 %283, 5
  %331 = icmp slt i64 %330, %25
  %332 = select i1 %331, i64 %330, i64 0
  %333 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %332
  %334 = load float, ptr addrspace(1) %333, align 4, !amdgpu.noclobber !3
  %335 = insertelement <8 x float> %329, float %334, i64 5
  %336 = or disjoint i64 %283, 6
  %337 = icmp slt i64 %336, %25
  %338 = select i1 %337, i64 %336, i64 0
  %339 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %338
  %340 = load float, ptr addrspace(1) %339, align 4, !amdgpu.noclobber !3
  %341 = insertelement <8 x float> %335, float %340, i64 6
  %342 = icmp slt i64 %286, %25
  %343 = select i1 %342, i64 %286, i64 0
  %344 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %343
  %345 = load float, ptr addrspace(1) %344, align 4, !amdgpu.noclobber !3
  %346 = insertelement <8 x float> %341, float %345, i64 7
  br label %347

347:                                              ; preds = %294, %300
  %348 = phi <8 x float> [ %346, %300 ], [ %299, %294 ]
  %349 = icmp slt i64 %285, %26
  %350 = select i1 %349, i64 %285, i64 0
  %351 = extractelement <8 x float> %348, i64 0
  %352 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %350
  %353 = load i8, ptr addrspace(1) %352, align 1
  %354 = zext i8 %353 to i32
  %355 = shl nuw nsw i32 %354, 23
  %356 = bitcast i32 %355 to float
  %357 = fmul float %351, %356
  %358 = extractelement <8 x float> %274, i64 0
  %359 = fmul float %358, %357
  %360 = tail call i1 @llvm.is.fpclass.f32(float %357, /* (sub norm) */ i32 408)
  br i1 %360, label %373, label %361, !prof !4

361:                                              ; preds = %347
  %362 = fpext float %358 to double
  %363 = fpext nnan float %356 to double
  %364 = fpext float %351 to double
  %365 = fmul double %362, %363
  %366 = fmul double %365, %364
  %367 = fptrunc double %366 to float
  %368 = fcmp oeq float %358, 0.000000e+00
  %369 = tail call float @llvm.fabs.f32(float %351)
  %370 = fcmp one float %369, +inf
  %371 = and i1 %368, %370
  %372 = select i1 %371, float 0.000000e+00, float %367
  br label %373

373:                                              ; preds = %361, %347
  %374 = phi float [ %372, %361 ], [ %359, %347 ]
  %375 = extractelement <8 x float> %348, i64 1
  %376 = fmul float %375, %356
  %377 = extractelement <8 x float> %274, i64 1
  %378 = fmul float %377, %376
  %379 = tail call i1 @llvm.is.fpclass.f32(float %376, /* (sub norm) */ i32 408)
  br i1 %379, label %392, label %380, !prof !4

380:                                              ; preds = %373
  %381 = fpext float %377 to double
  %382 = fpext nnan float %356 to double
  %383 = fpext float %375 to double
  %384 = fmul double %381, %382
  %385 = fmul double %384, %383
  %386 = fptrunc double %385 to float
  %387 = fcmp oeq float %377, 0.000000e+00
  %388 = tail call float @llvm.fabs.f32(float %375)
  %389 = fcmp one float %388, +inf
  %390 = and i1 %387, %389
  %391 = select i1 %390, float 0.000000e+00, float %386
  br label %392

392:                                              ; preds = %380, %373
  %393 = phi float [ %391, %380 ], [ %378, %373 ]
  %394 = extractelement <8 x float> %348, i64 2
  %395 = fmul float %394, %356
  %396 = extractelement <8 x float> %274, i64 2
  %397 = fmul float %396, %395
  %398 = tail call i1 @llvm.is.fpclass.f32(float %395, /* (sub norm) */ i32 408)
  br i1 %398, label %411, label %399, !prof !4

399:                                              ; preds = %392
  %400 = fpext float %396 to double
  %401 = fpext nnan float %356 to double
  %402 = fpext float %394 to double
  %403 = fmul double %400, %401
  %404 = fmul double %403, %402
  %405 = fptrunc double %404 to float
  %406 = fcmp oeq float %396, 0.000000e+00
  %407 = tail call float @llvm.fabs.f32(float %394)
  %408 = fcmp one float %407, +inf
  %409 = and i1 %406, %408
  %410 = select i1 %409, float 0.000000e+00, float %405
  br label %411

411:                                              ; preds = %399, %392
  %412 = phi float [ %410, %399 ], [ %397, %392 ]
  %413 = extractelement <8 x float> %348, i64 3
  %414 = fmul float %413, %356
  %415 = extractelement <8 x float> %274, i64 3
  %416 = fmul float %415, %414
  %417 = tail call i1 @llvm.is.fpclass.f32(float %414, /* (sub norm) */ i32 408)
  br i1 %417, label %430, label %418, !prof !4

418:                                              ; preds = %411
  %419 = fpext float %415 to double
  %420 = fpext nnan float %356 to double
  %421 = fpext float %413 to double
  %422 = fmul double %419, %420
  %423 = fmul double %422, %421
  %424 = fptrunc double %423 to float
  %425 = fcmp oeq float %415, 0.000000e+00
  %426 = tail call float @llvm.fabs.f32(float %413)
  %427 = fcmp one float %426, +inf
  %428 = and i1 %425, %427
  %429 = select i1 %428, float 0.000000e+00, float %424
  br label %430

430:                                              ; preds = %418, %411
  %431 = phi float [ %429, %418 ], [ %416, %411 ]
  %432 = extractelement <8 x float> %348, i64 4
  %433 = fmul float %432, %356
  %434 = extractelement <8 x float> %274, i64 4
  %435 = fmul float %434, %433
  %436 = tail call i1 @llvm.is.fpclass.f32(float %433, /* (sub norm) */ i32 408)
  br i1 %436, label %449, label %437, !prof !4

437:                                              ; preds = %430
  %438 = fpext float %434 to double
  %439 = fpext nnan float %356 to double
  %440 = fpext float %432 to double
  %441 = fmul double %438, %439
  %442 = fmul double %441, %440
  %443 = fptrunc double %442 to float
  %444 = fcmp oeq float %434, 0.000000e+00
  %445 = tail call float @llvm.fabs.f32(float %432)
  %446 = fcmp one float %445, +inf
  %447 = and i1 %444, %446
  %448 = select i1 %447, float 0.000000e+00, float %443
  br label %449

449:                                              ; preds = %437, %430
  %450 = phi float [ %448, %437 ], [ %435, %430 ]
  %451 = extractelement <8 x float> %348, i64 5
  %452 = fmul float %451, %356
  %453 = extractelement <8 x float> %274, i64 5
  %454 = fmul float %453, %452
  %455 = tail call i1 @llvm.is.fpclass.f32(float %452, /* (sub norm) */ i32 408)
  br i1 %455, label %468, label %456, !prof !4

456:                                              ; preds = %449
  %457 = fpext float %453 to double
  %458 = fpext nnan float %356 to double
  %459 = fpext float %451 to double
  %460 = fmul double %457, %458
  %461 = fmul double %460, %459
  %462 = fptrunc double %461 to float
  %463 = fcmp oeq float %453, 0.000000e+00
  %464 = tail call float @llvm.fabs.f32(float %451)
  %465 = fcmp one float %464, +inf
  %466 = and i1 %463, %465
  %467 = select i1 %466, float 0.000000e+00, float %462
  br label %468

468:                                              ; preds = %456, %449
  %469 = phi float [ %467, %456 ], [ %454, %449 ]
  %470 = extractelement <8 x float> %348, i64 6
  %471 = fmul float %470, %356
  %472 = extractelement <8 x float> %274, i64 6
  %473 = fmul float %472, %471
  %474 = tail call i1 @llvm.is.fpclass.f32(float %471, /* (sub norm) */ i32 408)
  br i1 %474, label %487, label %475, !prof !4

475:                                              ; preds = %468
  %476 = fpext float %472 to double
  %477 = fpext nnan float %356 to double
  %478 = fpext float %470 to double
  %479 = fmul double %476, %477
  %480 = fmul double %479, %478
  %481 = fptrunc double %480 to float
  %482 = fcmp oeq float %472, 0.000000e+00
  %483 = tail call float @llvm.fabs.f32(float %470)
  %484 = fcmp one float %483, +inf
  %485 = and i1 %482, %484
  %486 = select i1 %485, float 0.000000e+00, float %481
  br label %487

487:                                              ; preds = %475, %468
  %488 = phi float [ %486, %475 ], [ %473, %468 ]
  %489 = extractelement <8 x float> %348, i64 7
  %490 = fmul float %489, %356
  %491 = extractelement <8 x float> %274, i64 7
  %492 = fmul float %491, %490
  %493 = tail call i1 @llvm.is.fpclass.f32(float %490, /* (sub norm) */ i32 408)
  br i1 %493, label %506, label %494, !prof !4

494:                                              ; preds = %487
  %495 = fpext float %491 to double
  %496 = fpext nnan float %356 to double
  %497 = fpext float %489 to double
  %498 = fmul double %495, %496
  %499 = fmul double %498, %497
  %500 = fptrunc double %499 to float
  %501 = fcmp oeq float %491, 0.000000e+00
  %502 = tail call float @llvm.fabs.f32(float %489)
  %503 = fcmp one float %502, +inf
  %504 = and i1 %501, %503
  %505 = select i1 %504, float 0.000000e+00, float %500
  br label %506

506:                                              ; preds = %494, %487
  %507 = phi float [ %505, %494 ], [ %492, %487 ]
  %508 = mul i64 %283, %26
  %509 = fptrunc float %374 to bfloat
  %510 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %508
  %511 = getelementptr [2 x i8], ptr addrspace(1) %510, i64 %285
  store bfloat %509, ptr addrspace(1) %511, align 2
  %512 = or disjoint i64 %115, 1
  %513 = or disjoint i64 %55, %512
  %514 = mul i64 %513, %26
  %515 = fptrunc float %393 to bfloat
  %516 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %514
  %517 = getelementptr [2 x i8], ptr addrspace(1) %516, i64 %285
  store bfloat %515, ptr addrspace(1) %517, align 2
  %518 = or disjoint i64 %115, 2
  %519 = or disjoint i64 %55, %518
  %520 = mul i64 %519, %26
  %521 = fptrunc float %412 to bfloat
  %522 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %520
  %523 = getelementptr [2 x i8], ptr addrspace(1) %522, i64 %285
  store bfloat %521, ptr addrspace(1) %523, align 2
  %524 = or disjoint i64 %115, 3
  %525 = or disjoint i64 %55, %524
  %526 = mul i64 %525, %26
  %527 = fptrunc float %431 to bfloat
  %528 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %526
  %529 = getelementptr [2 x i8], ptr addrspace(1) %528, i64 %285
  store bfloat %527, ptr addrspace(1) %529, align 2
  %530 = or disjoint i64 %115, 4
  %531 = or disjoint i64 %55, %530
  %532 = mul i64 %531, %26
  %533 = fptrunc float %450 to bfloat
  %534 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %532
  %535 = getelementptr [2 x i8], ptr addrspace(1) %534, i64 %285
  store bfloat %533, ptr addrspace(1) %535, align 2
  %536 = or disjoint i64 %115, 5
  %537 = or disjoint i64 %55, %536
  %538 = mul i64 %537, %26
  %539 = fptrunc float %469 to bfloat
  %540 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %538
  %541 = getelementptr [2 x i8], ptr addrspace(1) %540, i64 %285
  store bfloat %539, ptr addrspace(1) %541, align 2
  %542 = or disjoint i64 %115, 6
  %543 = or disjoint i64 %55, %542
  %544 = mul i64 %543, %26
  %545 = fptrunc float %488 to bfloat
  %546 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %544
  %547 = getelementptr [2 x i8], ptr addrspace(1) %546, i64 %285
  store bfloat %545, ptr addrspace(1) %547, align 2
  %548 = or disjoint i64 %115, 7
  %549 = or disjoint i64 %55, %548
  %550 = mul i64 %549, %26
  %551 = fptrunc float %507 to bfloat
  %552 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %550
  %553 = getelementptr [2 x i8], ptr addrspace(1) %552, i64 %285
  store bfloat %551, ptr addrspace(1) %553, align 2
  %554 = or disjoint i64 %57, %115
  %555 = or disjoint i64 %554, 7
  %556 = icmp ult i64 %555, %25
  %557 = and i1 %287, %556
  %558 = and i1 %292, %557
  br i1 %558, label %559, label %565

559:                                              ; preds = %506
  %560 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %554
  %561 = load <4 x float>, ptr addrspace(1) %560, align 16
  %562 = getelementptr i8, ptr addrspace(1) %560, i64 16
  %563 = load <4 x float>, ptr addrspace(1) %562, align 16
  %564 = shufflevector <4 x float> %561, <4 x float> %563, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %613

565:                                              ; preds = %506
  %566 = icmp slt i64 %554, %25
  %567 = select i1 %566, i64 %554, i64 0
  %568 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %567
  %569 = load float, ptr addrspace(1) %568, align 4
  %570 = insertelement <8 x float> poison, float %569, i64 0
  %571 = or disjoint i64 %57, %512
  %572 = icmp slt i64 %571, %25
  %573 = select i1 %572, i64 %571, i64 0
  %574 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %573
  %575 = load float, ptr addrspace(1) %574, align 4
  %576 = insertelement <8 x float> %570, float %575, i64 1
  %577 = or disjoint i64 %57, %518
  %578 = icmp slt i64 %577, %25
  %579 = select i1 %578, i64 %577, i64 0
  %580 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %579
  %581 = load float, ptr addrspace(1) %580, align 4
  %582 = insertelement <8 x float> %576, float %581, i64 2
  %583 = or disjoint i64 %57, %524
  %584 = icmp slt i64 %583, %25
  %585 = select i1 %584, i64 %583, i64 0
  %586 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %585
  %587 = load float, ptr addrspace(1) %586, align 4
  %588 = insertelement <8 x float> %582, float %587, i64 3
  %589 = or disjoint i64 %57, %530
  %590 = icmp slt i64 %589, %25
  %591 = select i1 %590, i64 %589, i64 0
  %592 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %591
  %593 = load float, ptr addrspace(1) %592, align 4
  %594 = insertelement <8 x float> %588, float %593, i64 4
  %595 = or disjoint i64 %57, %536
  %596 = icmp slt i64 %595, %25
  %597 = select i1 %596, i64 %595, i64 0
  %598 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %597
  %599 = load float, ptr addrspace(1) %598, align 4
  %600 = insertelement <8 x float> %594, float %599, i64 5
  %601 = or disjoint i64 %57, %542
  %602 = icmp slt i64 %601, %25
  %603 = select i1 %602, i64 %601, i64 0
  %604 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %603
  %605 = load float, ptr addrspace(1) %604, align 4
  %606 = insertelement <8 x float> %600, float %605, i64 6
  %607 = or disjoint i64 %57, %548
  %608 = icmp slt i64 %607, %25
  %609 = select i1 %608, i64 %607, i64 0
  %610 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %609
  %611 = load float, ptr addrspace(1) %610, align 4
  %612 = insertelement <8 x float> %606, float %611, i64 7
  br label %613

613:                                              ; preds = %559, %565
  %614 = phi <8 x float> [ %612, %565 ], [ %564, %559 ]
  %615 = extractelement <8 x float> %614, i64 0
  %616 = load i8, ptr addrspace(1) %352, align 1
  %617 = zext i8 %616 to i32
  %618 = shl nuw nsw i32 %617, 23
  %619 = bitcast i32 %618 to float
  %620 = fmul float %615, %619
  %621 = extractelement <8 x float> %276, i64 0
  %622 = fmul float %621, %620
  %623 = tail call i1 @llvm.is.fpclass.f32(float %620, /* (sub norm) */ i32 408)
  br i1 %623, label %636, label %624, !prof !4

624:                                              ; preds = %613
  %625 = fpext float %621 to double
  %626 = fpext nnan float %619 to double
  %627 = fpext float %615 to double
  %628 = fmul double %625, %626
  %629 = fmul double %628, %627
  %630 = fptrunc double %629 to float
  %631 = fcmp oeq float %621, 0.000000e+00
  %632 = tail call float @llvm.fabs.f32(float %615)
  %633 = fcmp one float %632, +inf
  %634 = and i1 %631, %633
  %635 = select i1 %634, float 0.000000e+00, float %630
  br label %636

636:                                              ; preds = %624, %613
  %637 = phi float [ %635, %624 ], [ %622, %613 ]
  %638 = extractelement <8 x float> %614, i64 1
  %639 = fmul float %638, %619
  %640 = extractelement <8 x float> %276, i64 1
  %641 = fmul float %640, %639
  %642 = tail call i1 @llvm.is.fpclass.f32(float %639, /* (sub norm) */ i32 408)
  br i1 %642, label %655, label %643, !prof !4

643:                                              ; preds = %636
  %644 = fpext float %640 to double
  %645 = fpext nnan float %619 to double
  %646 = fpext float %638 to double
  %647 = fmul double %644, %645
  %648 = fmul double %647, %646
  %649 = fptrunc double %648 to float
  %650 = fcmp oeq float %640, 0.000000e+00
  %651 = tail call float @llvm.fabs.f32(float %638)
  %652 = fcmp one float %651, +inf
  %653 = and i1 %650, %652
  %654 = select i1 %653, float 0.000000e+00, float %649
  br label %655

655:                                              ; preds = %643, %636
  %656 = phi float [ %654, %643 ], [ %641, %636 ]
  %657 = extractelement <8 x float> %614, i64 2
  %658 = fmul float %657, %619
  %659 = extractelement <8 x float> %276, i64 2
  %660 = fmul float %659, %658
  %661 = tail call i1 @llvm.is.fpclass.f32(float %658, /* (sub norm) */ i32 408)
  br i1 %661, label %674, label %662, !prof !4

662:                                              ; preds = %655
  %663 = fpext float %659 to double
  %664 = fpext nnan float %619 to double
  %665 = fpext float %657 to double
  %666 = fmul double %663, %664
  %667 = fmul double %666, %665
  %668 = fptrunc double %667 to float
  %669 = fcmp oeq float %659, 0.000000e+00
  %670 = tail call float @llvm.fabs.f32(float %657)
  %671 = fcmp one float %670, +inf
  %672 = and i1 %669, %671
  %673 = select i1 %672, float 0.000000e+00, float %668
  br label %674

674:                                              ; preds = %662, %655
  %675 = phi float [ %673, %662 ], [ %660, %655 ]
  %676 = extractelement <8 x float> %614, i64 3
  %677 = fmul float %676, %619
  %678 = extractelement <8 x float> %276, i64 3
  %679 = fmul float %678, %677
  %680 = tail call i1 @llvm.is.fpclass.f32(float %677, /* (sub norm) */ i32 408)
  br i1 %680, label %693, label %681, !prof !4

681:                                              ; preds = %674
  %682 = fpext float %678 to double
  %683 = fpext nnan float %619 to double
  %684 = fpext float %676 to double
  %685 = fmul double %682, %683
  %686 = fmul double %685, %684
  %687 = fptrunc double %686 to float
  %688 = fcmp oeq float %678, 0.000000e+00
  %689 = tail call float @llvm.fabs.f32(float %676)
  %690 = fcmp one float %689, +inf
  %691 = and i1 %688, %690
  %692 = select i1 %691, float 0.000000e+00, float %687
  br label %693

693:                                              ; preds = %681, %674
  %694 = phi float [ %692, %681 ], [ %679, %674 ]
  %695 = extractelement <8 x float> %614, i64 4
  %696 = fmul float %695, %619
  %697 = extractelement <8 x float> %276, i64 4
  %698 = fmul float %697, %696
  %699 = tail call i1 @llvm.is.fpclass.f32(float %696, /* (sub norm) */ i32 408)
  br i1 %699, label %712, label %700, !prof !4

700:                                              ; preds = %693
  %701 = fpext float %697 to double
  %702 = fpext nnan float %619 to double
  %703 = fpext float %695 to double
  %704 = fmul double %701, %702
  %705 = fmul double %704, %703
  %706 = fptrunc double %705 to float
  %707 = fcmp oeq float %697, 0.000000e+00
  %708 = tail call float @llvm.fabs.f32(float %695)
  %709 = fcmp one float %708, +inf
  %710 = and i1 %707, %709
  %711 = select i1 %710, float 0.000000e+00, float %706
  br label %712

712:                                              ; preds = %700, %693
  %713 = phi float [ %711, %700 ], [ %698, %693 ]
  %714 = extractelement <8 x float> %614, i64 5
  %715 = fmul float %714, %619
  %716 = extractelement <8 x float> %276, i64 5
  %717 = fmul float %716, %715
  %718 = tail call i1 @llvm.is.fpclass.f32(float %715, /* (sub norm) */ i32 408)
  br i1 %718, label %731, label %719, !prof !4

719:                                              ; preds = %712
  %720 = fpext float %716 to double
  %721 = fpext nnan float %619 to double
  %722 = fpext float %714 to double
  %723 = fmul double %720, %721
  %724 = fmul double %723, %722
  %725 = fptrunc double %724 to float
  %726 = fcmp oeq float %716, 0.000000e+00
  %727 = tail call float @llvm.fabs.f32(float %714)
  %728 = fcmp one float %727, +inf
  %729 = and i1 %726, %728
  %730 = select i1 %729, float 0.000000e+00, float %725
  br label %731

731:                                              ; preds = %719, %712
  %732 = phi float [ %730, %719 ], [ %717, %712 ]
  %733 = extractelement <8 x float> %614, i64 6
  %734 = fmul float %733, %619
  %735 = extractelement <8 x float> %276, i64 6
  %736 = fmul float %735, %734
  %737 = tail call i1 @llvm.is.fpclass.f32(float %734, /* (sub norm) */ i32 408)
  br i1 %737, label %750, label %738, !prof !4

738:                                              ; preds = %731
  %739 = fpext float %735 to double
  %740 = fpext nnan float %619 to double
  %741 = fpext float %733 to double
  %742 = fmul double %739, %740
  %743 = fmul double %742, %741
  %744 = fptrunc double %743 to float
  %745 = fcmp oeq float %735, 0.000000e+00
  %746 = tail call float @llvm.fabs.f32(float %733)
  %747 = fcmp one float %746, +inf
  %748 = and i1 %745, %747
  %749 = select i1 %748, float 0.000000e+00, float %744
  br label %750

750:                                              ; preds = %738, %731
  %751 = phi float [ %749, %738 ], [ %736, %731 ]
  %752 = extractelement <8 x float> %614, i64 7
  %753 = fmul float %752, %619
  %754 = extractelement <8 x float> %276, i64 7
  %755 = fmul float %754, %753
  %756 = tail call i1 @llvm.is.fpclass.f32(float %753, /* (sub norm) */ i32 408)
  br i1 %756, label %769, label %757, !prof !4

757:                                              ; preds = %750
  %758 = fpext float %754 to double
  %759 = fpext nnan float %619 to double
  %760 = fpext float %752 to double
  %761 = fmul double %758, %759
  %762 = fmul double %761, %760
  %763 = fptrunc double %762 to float
  %764 = fcmp oeq float %754, 0.000000e+00
  %765 = tail call float @llvm.fabs.f32(float %752)
  %766 = fcmp one float %765, +inf
  %767 = and i1 %764, %766
  %768 = select i1 %767, float 0.000000e+00, float %763
  br label %769

769:                                              ; preds = %757, %750
  %770 = phi float [ %768, %757 ], [ %755, %750 ]
  %771 = mul i64 %554, %26
  %772 = fptrunc float %637 to bfloat
  %773 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %771
  %774 = getelementptr [2 x i8], ptr addrspace(1) %773, i64 %285
  store bfloat %772, ptr addrspace(1) %774, align 2
  %775 = or disjoint i64 %57, %512
  %776 = mul i64 %775, %26
  %777 = fptrunc float %656 to bfloat
  %778 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %776
  %779 = getelementptr [2 x i8], ptr addrspace(1) %778, i64 %285
  store bfloat %777, ptr addrspace(1) %779, align 2
  %780 = or disjoint i64 %57, %518
  %781 = mul i64 %780, %26
  %782 = fptrunc float %675 to bfloat
  %783 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %781
  %784 = getelementptr [2 x i8], ptr addrspace(1) %783, i64 %285
  store bfloat %782, ptr addrspace(1) %784, align 2
  %785 = or disjoint i64 %57, %524
  %786 = mul i64 %785, %26
  %787 = fptrunc float %694 to bfloat
  %788 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %786
  %789 = getelementptr [2 x i8], ptr addrspace(1) %788, i64 %285
  store bfloat %787, ptr addrspace(1) %789, align 2
  %790 = or disjoint i64 %57, %530
  %791 = mul i64 %790, %26
  %792 = fptrunc float %713 to bfloat
  %793 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %791
  %794 = getelementptr [2 x i8], ptr addrspace(1) %793, i64 %285
  store bfloat %792, ptr addrspace(1) %794, align 2
  %795 = or disjoint i64 %57, %536
  %796 = mul i64 %795, %26
  %797 = fptrunc float %732 to bfloat
  %798 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %796
  %799 = getelementptr [2 x i8], ptr addrspace(1) %798, i64 %285
  store bfloat %797, ptr addrspace(1) %799, align 2
  %800 = or disjoint i64 %57, %542
  %801 = mul i64 %800, %26
  %802 = fptrunc float %751 to bfloat
  %803 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %801
  %804 = getelementptr [2 x i8], ptr addrspace(1) %803, i64 %285
  store bfloat %802, ptr addrspace(1) %804, align 2
  %805 = or disjoint i64 %57, %548
  %806 = mul i64 %805, %26
  %807 = fptrunc float %770 to bfloat
  %808 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %806
  %809 = getelementptr [2 x i8], ptr addrspace(1) %808, i64 %285
  store bfloat %807, ptr addrspace(1) %809, align 2
  %810 = or disjoint i64 %59, %115
  %811 = or disjoint i64 %810, 7
  %812 = icmp ult i64 %811, %25
  %813 = and i1 %287, %812
  %814 = and i1 %292, %813
  br i1 %814, label %815, label %821

815:                                              ; preds = %769
  %816 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %810
  %817 = load <4 x float>, ptr addrspace(1) %816, align 16
  %818 = getelementptr i8, ptr addrspace(1) %816, i64 16
  %819 = load <4 x float>, ptr addrspace(1) %818, align 16
  %820 = shufflevector <4 x float> %817, <4 x float> %819, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %869

821:                                              ; preds = %769
  %822 = icmp slt i64 %810, %25
  %823 = select i1 %822, i64 %810, i64 0
  %824 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %823
  %825 = load float, ptr addrspace(1) %824, align 4
  %826 = insertelement <8 x float> poison, float %825, i64 0
  %827 = or disjoint i64 %59, %512
  %828 = icmp slt i64 %827, %25
  %829 = select i1 %828, i64 %827, i64 0
  %830 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %829
  %831 = load float, ptr addrspace(1) %830, align 4
  %832 = insertelement <8 x float> %826, float %831, i64 1
  %833 = or disjoint i64 %59, %518
  %834 = icmp slt i64 %833, %25
  %835 = select i1 %834, i64 %833, i64 0
  %836 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %835
  %837 = load float, ptr addrspace(1) %836, align 4
  %838 = insertelement <8 x float> %832, float %837, i64 2
  %839 = or disjoint i64 %59, %524
  %840 = icmp slt i64 %839, %25
  %841 = select i1 %840, i64 %839, i64 0
  %842 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %841
  %843 = load float, ptr addrspace(1) %842, align 4
  %844 = insertelement <8 x float> %838, float %843, i64 3
  %845 = or disjoint i64 %59, %530
  %846 = icmp slt i64 %845, %25
  %847 = select i1 %846, i64 %845, i64 0
  %848 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %847
  %849 = load float, ptr addrspace(1) %848, align 4
  %850 = insertelement <8 x float> %844, float %849, i64 4
  %851 = or disjoint i64 %59, %536
  %852 = icmp slt i64 %851, %25
  %853 = select i1 %852, i64 %851, i64 0
  %854 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %853
  %855 = load float, ptr addrspace(1) %854, align 4
  %856 = insertelement <8 x float> %850, float %855, i64 5
  %857 = or disjoint i64 %59, %542
  %858 = icmp slt i64 %857, %25
  %859 = select i1 %858, i64 %857, i64 0
  %860 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %859
  %861 = load float, ptr addrspace(1) %860, align 4
  %862 = insertelement <8 x float> %856, float %861, i64 6
  %863 = or disjoint i64 %59, %548
  %864 = icmp slt i64 %863, %25
  %865 = select i1 %864, i64 %863, i64 0
  %866 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %865
  %867 = load float, ptr addrspace(1) %866, align 4
  %868 = insertelement <8 x float> %862, float %867, i64 7
  br label %869

869:                                              ; preds = %815, %821
  %870 = phi <8 x float> [ %868, %821 ], [ %820, %815 ]
  %871 = extractelement <8 x float> %870, i64 0
  %872 = load i8, ptr addrspace(1) %352, align 1
  %873 = zext i8 %872 to i32
  %874 = shl nuw nsw i32 %873, 23
  %875 = bitcast i32 %874 to float
  %876 = fmul float %871, %875
  %877 = extractelement <8 x float> %278, i64 0
  %878 = fmul float %877, %876
  %879 = tail call i1 @llvm.is.fpclass.f32(float %876, /* (sub norm) */ i32 408)
  br i1 %879, label %892, label %880, !prof !4

880:                                              ; preds = %869
  %881 = fpext float %877 to double
  %882 = fpext nnan float %875 to double
  %883 = fpext float %871 to double
  %884 = fmul double %881, %882
  %885 = fmul double %884, %883
  %886 = fptrunc double %885 to float
  %887 = fcmp oeq float %877, 0.000000e+00
  %888 = tail call float @llvm.fabs.f32(float %871)
  %889 = fcmp one float %888, +inf
  %890 = and i1 %887, %889
  %891 = select i1 %890, float 0.000000e+00, float %886
  br label %892

892:                                              ; preds = %880, %869
  %893 = phi float [ %891, %880 ], [ %878, %869 ]
  %894 = extractelement <8 x float> %870, i64 1
  %895 = fmul float %894, %875
  %896 = extractelement <8 x float> %278, i64 1
  %897 = fmul float %896, %895
  %898 = tail call i1 @llvm.is.fpclass.f32(float %895, /* (sub norm) */ i32 408)
  br i1 %898, label %911, label %899, !prof !4

899:                                              ; preds = %892
  %900 = fpext float %896 to double
  %901 = fpext nnan float %875 to double
  %902 = fpext float %894 to double
  %903 = fmul double %900, %901
  %904 = fmul double %903, %902
  %905 = fptrunc double %904 to float
  %906 = fcmp oeq float %896, 0.000000e+00
  %907 = tail call float @llvm.fabs.f32(float %894)
  %908 = fcmp one float %907, +inf
  %909 = and i1 %906, %908
  %910 = select i1 %909, float 0.000000e+00, float %905
  br label %911

911:                                              ; preds = %899, %892
  %912 = phi float [ %910, %899 ], [ %897, %892 ]
  %913 = extractelement <8 x float> %870, i64 2
  %914 = fmul float %913, %875
  %915 = extractelement <8 x float> %278, i64 2
  %916 = fmul float %915, %914
  %917 = tail call i1 @llvm.is.fpclass.f32(float %914, /* (sub norm) */ i32 408)
  br i1 %917, label %930, label %918, !prof !4

918:                                              ; preds = %911
  %919 = fpext float %915 to double
  %920 = fpext nnan float %875 to double
  %921 = fpext float %913 to double
  %922 = fmul double %919, %920
  %923 = fmul double %922, %921
  %924 = fptrunc double %923 to float
  %925 = fcmp oeq float %915, 0.000000e+00
  %926 = tail call float @llvm.fabs.f32(float %913)
  %927 = fcmp one float %926, +inf
  %928 = and i1 %925, %927
  %929 = select i1 %928, float 0.000000e+00, float %924
  br label %930

930:                                              ; preds = %918, %911
  %931 = phi float [ %929, %918 ], [ %916, %911 ]
  %932 = extractelement <8 x float> %870, i64 3
  %933 = fmul float %932, %875
  %934 = extractelement <8 x float> %278, i64 3
  %935 = fmul float %934, %933
  %936 = tail call i1 @llvm.is.fpclass.f32(float %933, /* (sub norm) */ i32 408)
  br i1 %936, label %949, label %937, !prof !4

937:                                              ; preds = %930
  %938 = fpext float %934 to double
  %939 = fpext nnan float %875 to double
  %940 = fpext float %932 to double
  %941 = fmul double %938, %939
  %942 = fmul double %941, %940
  %943 = fptrunc double %942 to float
  %944 = fcmp oeq float %934, 0.000000e+00
  %945 = tail call float @llvm.fabs.f32(float %932)
  %946 = fcmp one float %945, +inf
  %947 = and i1 %944, %946
  %948 = select i1 %947, float 0.000000e+00, float %943
  br label %949

949:                                              ; preds = %937, %930
  %950 = phi float [ %948, %937 ], [ %935, %930 ]
  %951 = extractelement <8 x float> %870, i64 4
  %952 = fmul float %951, %875
  %953 = extractelement <8 x float> %278, i64 4
  %954 = fmul float %953, %952
  %955 = tail call i1 @llvm.is.fpclass.f32(float %952, /* (sub norm) */ i32 408)
  br i1 %955, label %968, label %956, !prof !4

956:                                              ; preds = %949
  %957 = fpext float %953 to double
  %958 = fpext nnan float %875 to double
  %959 = fpext float %951 to double
  %960 = fmul double %957, %958
  %961 = fmul double %960, %959
  %962 = fptrunc double %961 to float
  %963 = fcmp oeq float %953, 0.000000e+00
  %964 = tail call float @llvm.fabs.f32(float %951)
  %965 = fcmp one float %964, +inf
  %966 = and i1 %963, %965
  %967 = select i1 %966, float 0.000000e+00, float %962
  br label %968

968:                                              ; preds = %956, %949
  %969 = phi float [ %967, %956 ], [ %954, %949 ]
  %970 = extractelement <8 x float> %870, i64 5
  %971 = fmul float %970, %875
  %972 = extractelement <8 x float> %278, i64 5
  %973 = fmul float %972, %971
  %974 = tail call i1 @llvm.is.fpclass.f32(float %971, /* (sub norm) */ i32 408)
  br i1 %974, label %987, label %975, !prof !4

975:                                              ; preds = %968
  %976 = fpext float %972 to double
  %977 = fpext nnan float %875 to double
  %978 = fpext float %970 to double
  %979 = fmul double %976, %977
  %980 = fmul double %979, %978
  %981 = fptrunc double %980 to float
  %982 = fcmp oeq float %972, 0.000000e+00
  %983 = tail call float @llvm.fabs.f32(float %970)
  %984 = fcmp one float %983, +inf
  %985 = and i1 %982, %984
  %986 = select i1 %985, float 0.000000e+00, float %981
  br label %987

987:                                              ; preds = %975, %968
  %988 = phi float [ %986, %975 ], [ %973, %968 ]
  %989 = extractelement <8 x float> %870, i64 6
  %990 = fmul float %989, %875
  %991 = extractelement <8 x float> %278, i64 6
  %992 = fmul float %991, %990
  %993 = tail call i1 @llvm.is.fpclass.f32(float %990, /* (sub norm) */ i32 408)
  br i1 %993, label %1006, label %994, !prof !4

994:                                              ; preds = %987
  %995 = fpext float %991 to double
  %996 = fpext nnan float %875 to double
  %997 = fpext float %989 to double
  %998 = fmul double %995, %996
  %999 = fmul double %998, %997
  %1000 = fptrunc double %999 to float
  %1001 = fcmp oeq float %991, 0.000000e+00
  %1002 = tail call float @llvm.fabs.f32(float %989)
  %1003 = fcmp one float %1002, +inf
  %1004 = and i1 %1001, %1003
  %1005 = select i1 %1004, float 0.000000e+00, float %1000
  br label %1006

1006:                                             ; preds = %994, %987
  %1007 = phi float [ %1005, %994 ], [ %992, %987 ]
  %1008 = extractelement <8 x float> %870, i64 7
  %1009 = fmul float %1008, %875
  %1010 = extractelement <8 x float> %278, i64 7
  %1011 = fmul float %1010, %1009
  %1012 = tail call i1 @llvm.is.fpclass.f32(float %1009, /* (sub norm) */ i32 408)
  br i1 %1012, label %1025, label %1013, !prof !4

1013:                                             ; preds = %1006
  %1014 = fpext float %1010 to double
  %1015 = fpext nnan float %875 to double
  %1016 = fpext float %1008 to double
  %1017 = fmul double %1014, %1015
  %1018 = fmul double %1017, %1016
  %1019 = fptrunc double %1018 to float
  %1020 = fcmp oeq float %1010, 0.000000e+00
  %1021 = tail call float @llvm.fabs.f32(float %1008)
  %1022 = fcmp one float %1021, +inf
  %1023 = and i1 %1020, %1022
  %1024 = select i1 %1023, float 0.000000e+00, float %1019
  br label %1025

1025:                                             ; preds = %1013, %1006
  %1026 = phi float [ %1024, %1013 ], [ %1011, %1006 ]
  %1027 = mul i64 %810, %26
  %1028 = fptrunc float %893 to bfloat
  %1029 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1027
  %1030 = getelementptr [2 x i8], ptr addrspace(1) %1029, i64 %285
  store bfloat %1028, ptr addrspace(1) %1030, align 2
  %1031 = or disjoint i64 %59, %512
  %1032 = mul i64 %1031, %26
  %1033 = fptrunc float %912 to bfloat
  %1034 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1032
  %1035 = getelementptr [2 x i8], ptr addrspace(1) %1034, i64 %285
  store bfloat %1033, ptr addrspace(1) %1035, align 2
  %1036 = or disjoint i64 %59, %518
  %1037 = mul i64 %1036, %26
  %1038 = fptrunc float %931 to bfloat
  %1039 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1037
  %1040 = getelementptr [2 x i8], ptr addrspace(1) %1039, i64 %285
  store bfloat %1038, ptr addrspace(1) %1040, align 2
  %1041 = or disjoint i64 %59, %524
  %1042 = mul i64 %1041, %26
  %1043 = fptrunc float %950 to bfloat
  %1044 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1042
  %1045 = getelementptr [2 x i8], ptr addrspace(1) %1044, i64 %285
  store bfloat %1043, ptr addrspace(1) %1045, align 2
  %1046 = or disjoint i64 %59, %530
  %1047 = mul i64 %1046, %26
  %1048 = fptrunc float %969 to bfloat
  %1049 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1047
  %1050 = getelementptr [2 x i8], ptr addrspace(1) %1049, i64 %285
  store bfloat %1048, ptr addrspace(1) %1050, align 2
  %1051 = or disjoint i64 %59, %536
  %1052 = mul i64 %1051, %26
  %1053 = fptrunc float %988 to bfloat
  %1054 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1052
  %1055 = getelementptr [2 x i8], ptr addrspace(1) %1054, i64 %285
  store bfloat %1053, ptr addrspace(1) %1055, align 2
  %1056 = or disjoint i64 %59, %542
  %1057 = mul i64 %1056, %26
  %1058 = fptrunc float %1007 to bfloat
  %1059 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1057
  %1060 = getelementptr [2 x i8], ptr addrspace(1) %1059, i64 %285
  store bfloat %1058, ptr addrspace(1) %1060, align 2
  %1061 = or disjoint i64 %59, %548
  %1062 = mul i64 %1061, %26
  %1063 = fptrunc float %1026 to bfloat
  %1064 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1062
  %1065 = getelementptr [2 x i8], ptr addrspace(1) %1064, i64 %285
  store bfloat %1063, ptr addrspace(1) %1065, align 2
  %1066 = or disjoint i64 %61, %115
  %1067 = or disjoint i64 %1066, 7
  %1068 = icmp ult i64 %1067, %25
  %1069 = and i1 %287, %1068
  %1070 = and i1 %292, %1069
  br i1 %1070, label %1071, label %1077

1071:                                             ; preds = %1025
  %1072 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1066
  %1073 = load <4 x float>, ptr addrspace(1) %1072, align 16
  %1074 = getelementptr i8, ptr addrspace(1) %1072, i64 16
  %1075 = load <4 x float>, ptr addrspace(1) %1074, align 16
  %1076 = shufflevector <4 x float> %1073, <4 x float> %1075, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1125

1077:                                             ; preds = %1025
  %1078 = icmp slt i64 %1066, %25
  %1079 = select i1 %1078, i64 %1066, i64 0
  %1080 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1079
  %1081 = load float, ptr addrspace(1) %1080, align 4
  %1082 = insertelement <8 x float> poison, float %1081, i64 0
  %1083 = or disjoint i64 %61, %512
  %1084 = icmp slt i64 %1083, %25
  %1085 = select i1 %1084, i64 %1083, i64 0
  %1086 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1085
  %1087 = load float, ptr addrspace(1) %1086, align 4
  %1088 = insertelement <8 x float> %1082, float %1087, i64 1
  %1089 = or disjoint i64 %61, %518
  %1090 = icmp slt i64 %1089, %25
  %1091 = select i1 %1090, i64 %1089, i64 0
  %1092 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1091
  %1093 = load float, ptr addrspace(1) %1092, align 4
  %1094 = insertelement <8 x float> %1088, float %1093, i64 2
  %1095 = or disjoint i64 %61, %524
  %1096 = icmp slt i64 %1095, %25
  %1097 = select i1 %1096, i64 %1095, i64 0
  %1098 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1097
  %1099 = load float, ptr addrspace(1) %1098, align 4
  %1100 = insertelement <8 x float> %1094, float %1099, i64 3
  %1101 = or disjoint i64 %61, %530
  %1102 = icmp slt i64 %1101, %25
  %1103 = select i1 %1102, i64 %1101, i64 0
  %1104 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1103
  %1105 = load float, ptr addrspace(1) %1104, align 4
  %1106 = insertelement <8 x float> %1100, float %1105, i64 4
  %1107 = or disjoint i64 %61, %536
  %1108 = icmp slt i64 %1107, %25
  %1109 = select i1 %1108, i64 %1107, i64 0
  %1110 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1109
  %1111 = load float, ptr addrspace(1) %1110, align 4
  %1112 = insertelement <8 x float> %1106, float %1111, i64 5
  %1113 = or disjoint i64 %61, %542
  %1114 = icmp slt i64 %1113, %25
  %1115 = select i1 %1114, i64 %1113, i64 0
  %1116 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1115
  %1117 = load float, ptr addrspace(1) %1116, align 4
  %1118 = insertelement <8 x float> %1112, float %1117, i64 6
  %1119 = or disjoint i64 %61, %548
  %1120 = icmp slt i64 %1119, %25
  %1121 = select i1 %1120, i64 %1119, i64 0
  %1122 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1121
  %1123 = load float, ptr addrspace(1) %1122, align 4
  %1124 = insertelement <8 x float> %1118, float %1123, i64 7
  br label %1125

1125:                                             ; preds = %1071, %1077
  %1126 = phi <8 x float> [ %1124, %1077 ], [ %1076, %1071 ]
  %1127 = extractelement <8 x float> %1126, i64 0
  %1128 = load i8, ptr addrspace(1) %352, align 1
  %1129 = zext i8 %1128 to i32
  %1130 = shl nuw nsw i32 %1129, 23
  %1131 = bitcast i32 %1130 to float
  %1132 = fmul float %1127, %1131
  %1133 = extractelement <8 x float> %280, i64 0
  %1134 = fmul float %1133, %1132
  %1135 = tail call i1 @llvm.is.fpclass.f32(float %1132, /* (sub norm) */ i32 408)
  br i1 %1135, label %1148, label %1136, !prof !4

1136:                                             ; preds = %1125
  %1137 = fpext float %1133 to double
  %1138 = fpext nnan float %1131 to double
  %1139 = fpext float %1127 to double
  %1140 = fmul double %1137, %1138
  %1141 = fmul double %1140, %1139
  %1142 = fptrunc double %1141 to float
  %1143 = fcmp oeq float %1133, 0.000000e+00
  %1144 = tail call float @llvm.fabs.f32(float %1127)
  %1145 = fcmp one float %1144, +inf
  %1146 = and i1 %1143, %1145
  %1147 = select i1 %1146, float 0.000000e+00, float %1142
  br label %1148

1148:                                             ; preds = %1136, %1125
  %1149 = phi float [ %1147, %1136 ], [ %1134, %1125 ]
  %1150 = extractelement <8 x float> %1126, i64 1
  %1151 = fmul float %1150, %1131
  %1152 = extractelement <8 x float> %280, i64 1
  %1153 = fmul float %1152, %1151
  %1154 = tail call i1 @llvm.is.fpclass.f32(float %1151, /* (sub norm) */ i32 408)
  br i1 %1154, label %1167, label %1155, !prof !4

1155:                                             ; preds = %1148
  %1156 = fpext float %1152 to double
  %1157 = fpext nnan float %1131 to double
  %1158 = fpext float %1150 to double
  %1159 = fmul double %1156, %1157
  %1160 = fmul double %1159, %1158
  %1161 = fptrunc double %1160 to float
  %1162 = fcmp oeq float %1152, 0.000000e+00
  %1163 = tail call float @llvm.fabs.f32(float %1150)
  %1164 = fcmp one float %1163, +inf
  %1165 = and i1 %1162, %1164
  %1166 = select i1 %1165, float 0.000000e+00, float %1161
  br label %1167

1167:                                             ; preds = %1155, %1148
  %1168 = phi float [ %1166, %1155 ], [ %1153, %1148 ]
  %1169 = extractelement <8 x float> %1126, i64 2
  %1170 = fmul float %1169, %1131
  %1171 = extractelement <8 x float> %280, i64 2
  %1172 = fmul float %1171, %1170
  %1173 = tail call i1 @llvm.is.fpclass.f32(float %1170, /* (sub norm) */ i32 408)
  br i1 %1173, label %1186, label %1174, !prof !4

1174:                                             ; preds = %1167
  %1175 = fpext float %1171 to double
  %1176 = fpext nnan float %1131 to double
  %1177 = fpext float %1169 to double
  %1178 = fmul double %1175, %1176
  %1179 = fmul double %1178, %1177
  %1180 = fptrunc double %1179 to float
  %1181 = fcmp oeq float %1171, 0.000000e+00
  %1182 = tail call float @llvm.fabs.f32(float %1169)
  %1183 = fcmp one float %1182, +inf
  %1184 = and i1 %1181, %1183
  %1185 = select i1 %1184, float 0.000000e+00, float %1180
  br label %1186

1186:                                             ; preds = %1174, %1167
  %1187 = phi float [ %1185, %1174 ], [ %1172, %1167 ]
  %1188 = extractelement <8 x float> %1126, i64 3
  %1189 = fmul float %1188, %1131
  %1190 = extractelement <8 x float> %280, i64 3
  %1191 = fmul float %1190, %1189
  %1192 = tail call i1 @llvm.is.fpclass.f32(float %1189, /* (sub norm) */ i32 408)
  br i1 %1192, label %1205, label %1193, !prof !4

1193:                                             ; preds = %1186
  %1194 = fpext float %1190 to double
  %1195 = fpext nnan float %1131 to double
  %1196 = fpext float %1188 to double
  %1197 = fmul double %1194, %1195
  %1198 = fmul double %1197, %1196
  %1199 = fptrunc double %1198 to float
  %1200 = fcmp oeq float %1190, 0.000000e+00
  %1201 = tail call float @llvm.fabs.f32(float %1188)
  %1202 = fcmp one float %1201, +inf
  %1203 = and i1 %1200, %1202
  %1204 = select i1 %1203, float 0.000000e+00, float %1199
  br label %1205

1205:                                             ; preds = %1193, %1186
  %1206 = phi float [ %1204, %1193 ], [ %1191, %1186 ]
  %1207 = extractelement <8 x float> %1126, i64 4
  %1208 = fmul float %1207, %1131
  %1209 = extractelement <8 x float> %280, i64 4
  %1210 = fmul float %1209, %1208
  %1211 = tail call i1 @llvm.is.fpclass.f32(float %1208, /* (sub norm) */ i32 408)
  br i1 %1211, label %1224, label %1212, !prof !4

1212:                                             ; preds = %1205
  %1213 = fpext float %1209 to double
  %1214 = fpext nnan float %1131 to double
  %1215 = fpext float %1207 to double
  %1216 = fmul double %1213, %1214
  %1217 = fmul double %1216, %1215
  %1218 = fptrunc double %1217 to float
  %1219 = fcmp oeq float %1209, 0.000000e+00
  %1220 = tail call float @llvm.fabs.f32(float %1207)
  %1221 = fcmp one float %1220, +inf
  %1222 = and i1 %1219, %1221
  %1223 = select i1 %1222, float 0.000000e+00, float %1218
  br label %1224

1224:                                             ; preds = %1212, %1205
  %1225 = phi float [ %1223, %1212 ], [ %1210, %1205 ]
  %1226 = extractelement <8 x float> %1126, i64 5
  %1227 = fmul float %1226, %1131
  %1228 = extractelement <8 x float> %280, i64 5
  %1229 = fmul float %1228, %1227
  %1230 = tail call i1 @llvm.is.fpclass.f32(float %1227, /* (sub norm) */ i32 408)
  br i1 %1230, label %1243, label %1231, !prof !4

1231:                                             ; preds = %1224
  %1232 = fpext float %1228 to double
  %1233 = fpext nnan float %1131 to double
  %1234 = fpext float %1226 to double
  %1235 = fmul double %1232, %1233
  %1236 = fmul double %1235, %1234
  %1237 = fptrunc double %1236 to float
  %1238 = fcmp oeq float %1228, 0.000000e+00
  %1239 = tail call float @llvm.fabs.f32(float %1226)
  %1240 = fcmp one float %1239, +inf
  %1241 = and i1 %1238, %1240
  %1242 = select i1 %1241, float 0.000000e+00, float %1237
  br label %1243

1243:                                             ; preds = %1231, %1224
  %1244 = phi float [ %1242, %1231 ], [ %1229, %1224 ]
  %1245 = extractelement <8 x float> %1126, i64 6
  %1246 = fmul float %1245, %1131
  %1247 = extractelement <8 x float> %280, i64 6
  %1248 = fmul float %1247, %1246
  %1249 = tail call i1 @llvm.is.fpclass.f32(float %1246, /* (sub norm) */ i32 408)
  br i1 %1249, label %1262, label %1250, !prof !4

1250:                                             ; preds = %1243
  %1251 = fpext float %1247 to double
  %1252 = fpext nnan float %1131 to double
  %1253 = fpext float %1245 to double
  %1254 = fmul double %1251, %1252
  %1255 = fmul double %1254, %1253
  %1256 = fptrunc double %1255 to float
  %1257 = fcmp oeq float %1247, 0.000000e+00
  %1258 = tail call float @llvm.fabs.f32(float %1245)
  %1259 = fcmp one float %1258, +inf
  %1260 = and i1 %1257, %1259
  %1261 = select i1 %1260, float 0.000000e+00, float %1256
  br label %1262

1262:                                             ; preds = %1250, %1243
  %1263 = phi float [ %1261, %1250 ], [ %1248, %1243 ]
  %1264 = extractelement <8 x float> %1126, i64 7
  %1265 = fmul float %1264, %1131
  %1266 = extractelement <8 x float> %280, i64 7
  %1267 = fmul float %1266, %1265
  %1268 = tail call i1 @llvm.is.fpclass.f32(float %1265, /* (sub norm) */ i32 408)
  br i1 %1268, label %1281, label %1269, !prof !4

1269:                                             ; preds = %1262
  %1270 = fpext float %1266 to double
  %1271 = fpext nnan float %1131 to double
  %1272 = fpext float %1264 to double
  %1273 = fmul double %1270, %1271
  %1274 = fmul double %1273, %1272
  %1275 = fptrunc double %1274 to float
  %1276 = fcmp oeq float %1266, 0.000000e+00
  %1277 = tail call float @llvm.fabs.f32(float %1264)
  %1278 = fcmp one float %1277, +inf
  %1279 = and i1 %1276, %1278
  %1280 = select i1 %1279, float 0.000000e+00, float %1275
  br label %1281

1281:                                             ; preds = %1269, %1262
  %1282 = phi float [ %1280, %1269 ], [ %1267, %1262 ]
  %1283 = mul i64 %1066, %26
  %1284 = fptrunc float %1149 to bfloat
  %1285 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1283
  %1286 = getelementptr [2 x i8], ptr addrspace(1) %1285, i64 %285
  store bfloat %1284, ptr addrspace(1) %1286, align 2
  %1287 = or disjoint i64 %61, %512
  %1288 = mul i64 %1287, %26
  %1289 = fptrunc float %1168 to bfloat
  %1290 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1288
  %1291 = getelementptr [2 x i8], ptr addrspace(1) %1290, i64 %285
  store bfloat %1289, ptr addrspace(1) %1291, align 2
  %1292 = or disjoint i64 %61, %518
  %1293 = mul i64 %1292, %26
  %1294 = fptrunc float %1187 to bfloat
  %1295 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1293
  %1296 = getelementptr [2 x i8], ptr addrspace(1) %1295, i64 %285
  store bfloat %1294, ptr addrspace(1) %1296, align 2
  %1297 = or disjoint i64 %61, %524
  %1298 = mul i64 %1297, %26
  %1299 = fptrunc float %1206 to bfloat
  %1300 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1298
  %1301 = getelementptr [2 x i8], ptr addrspace(1) %1300, i64 %285
  store bfloat %1299, ptr addrspace(1) %1301, align 2
  %1302 = or disjoint i64 %61, %530
  %1303 = mul i64 %1302, %26
  %1304 = fptrunc float %1225 to bfloat
  %1305 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1303
  %1306 = getelementptr [2 x i8], ptr addrspace(1) %1305, i64 %285
  store bfloat %1304, ptr addrspace(1) %1306, align 2
  %1307 = or disjoint i64 %61, %536
  %1308 = mul i64 %1307, %26
  %1309 = fptrunc float %1244 to bfloat
  %1310 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1308
  %1311 = getelementptr [2 x i8], ptr addrspace(1) %1310, i64 %285
  store bfloat %1309, ptr addrspace(1) %1311, align 2
  %1312 = or disjoint i64 %61, %542
  %1313 = mul i64 %1312, %26
  %1314 = fptrunc float %1263 to bfloat
  %1315 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1313
  %1316 = getelementptr [2 x i8], ptr addrspace(1) %1315, i64 %285
  store bfloat %1314, ptr addrspace(1) %1316, align 2
  %1317 = or disjoint i64 %61, %548
  %1318 = mul i64 %1317, %26
  %1319 = fptrunc float %1282 to bfloat
  %1320 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1318
  %1321 = getelementptr [2 x i8], ptr addrspace(1) %1320, i64 %285
  store bfloat %1319, ptr addrspace(1) %1321, align 2
  %1322 = or disjoint i64 %62, %35
  %1323 = or disjoint i64 %1322, %54
  %1324 = icmp ult i64 %1323, %26
  %1325 = and i1 %1324, %288
  %1326 = and i1 %292, %1325
  br i1 %1326, label %1327, label %1333

1327:                                             ; preds = %1281
  %1328 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %283
  %1329 = load <4 x float>, ptr addrspace(1) %1328, align 16
  %1330 = getelementptr i8, ptr addrspace(1) %1328, i64 16
  %1331 = load <4 x float>, ptr addrspace(1) %1330, align 16
  %1332 = shufflevector <4 x float> %1329, <4 x float> %1331, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1374

1333:                                             ; preds = %1281
  %1334 = icmp slt i64 %283, %25
  %1335 = select i1 %1334, i64 %283, i64 0
  %1336 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1335
  %1337 = load float, ptr addrspace(1) %1336, align 4
  %1338 = insertelement <8 x float> poison, float %1337, i64 0
  %1339 = icmp slt i64 %513, %25
  %1340 = select i1 %1339, i64 %513, i64 0
  %1341 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1340
  %1342 = load float, ptr addrspace(1) %1341, align 4
  %1343 = insertelement <8 x float> %1338, float %1342, i64 1
  %1344 = icmp slt i64 %519, %25
  %1345 = select i1 %1344, i64 %519, i64 0
  %1346 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1345
  %1347 = load float, ptr addrspace(1) %1346, align 4
  %1348 = insertelement <8 x float> %1343, float %1347, i64 2
  %1349 = icmp slt i64 %525, %25
  %1350 = select i1 %1349, i64 %525, i64 0
  %1351 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1350
  %1352 = load float, ptr addrspace(1) %1351, align 4
  %1353 = insertelement <8 x float> %1348, float %1352, i64 3
  %1354 = icmp slt i64 %531, %25
  %1355 = select i1 %1354, i64 %531, i64 0
  %1356 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1355
  %1357 = load float, ptr addrspace(1) %1356, align 4
  %1358 = insertelement <8 x float> %1353, float %1357, i64 4
  %1359 = icmp slt i64 %537, %25
  %1360 = select i1 %1359, i64 %537, i64 0
  %1361 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1360
  %1362 = load float, ptr addrspace(1) %1361, align 4
  %1363 = insertelement <8 x float> %1358, float %1362, i64 5
  %1364 = icmp slt i64 %543, %25
  %1365 = select i1 %1364, i64 %543, i64 0
  %1366 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1365
  %1367 = load float, ptr addrspace(1) %1366, align 4
  %1368 = insertelement <8 x float> %1363, float %1367, i64 6
  %1369 = icmp slt i64 %549, %25
  %1370 = select i1 %1369, i64 %549, i64 0
  %1371 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1370
  %1372 = load float, ptr addrspace(1) %1371, align 4
  %1373 = insertelement <8 x float> %1368, float %1372, i64 7
  br label %1374

1374:                                             ; preds = %1327, %1333
  %1375 = phi <8 x float> [ %1373, %1333 ], [ %1332, %1327 ]
  %1376 = icmp slt i64 %1323, %26
  %1377 = select i1 %1376, i64 %1323, i64 0
  %1378 = extractelement <8 x float> %1375, i64 0
  %1379 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %1377
  %1380 = load i8, ptr addrspace(1) %1379, align 1
  %1381 = zext i8 %1380 to i32
  %1382 = shl nuw nsw i32 %1381, 23
  %1383 = bitcast i32 %1382 to float
  %1384 = fmul float %1378, %1383
  %1385 = extractelement <8 x float> %275, i64 0
  %1386 = fmul float %1385, %1384
  %1387 = tail call i1 @llvm.is.fpclass.f32(float %1384, /* (sub norm) */ i32 408)
  br i1 %1387, label %1400, label %1388, !prof !4

1388:                                             ; preds = %1374
  %1389 = fpext float %1385 to double
  %1390 = fpext nnan float %1383 to double
  %1391 = fpext float %1378 to double
  %1392 = fmul double %1389, %1390
  %1393 = fmul double %1392, %1391
  %1394 = fptrunc double %1393 to float
  %1395 = fcmp oeq float %1385, 0.000000e+00
  %1396 = tail call float @llvm.fabs.f32(float %1378)
  %1397 = fcmp one float %1396, +inf
  %1398 = and i1 %1395, %1397
  %1399 = select i1 %1398, float 0.000000e+00, float %1394
  br label %1400

1400:                                             ; preds = %1388, %1374
  %1401 = phi float [ %1399, %1388 ], [ %1386, %1374 ]
  %1402 = extractelement <8 x float> %1375, i64 1
  %1403 = fmul float %1402, %1383
  %1404 = extractelement <8 x float> %275, i64 1
  %1405 = fmul float %1404, %1403
  %1406 = tail call i1 @llvm.is.fpclass.f32(float %1403, /* (sub norm) */ i32 408)
  br i1 %1406, label %1419, label %1407, !prof !4

1407:                                             ; preds = %1400
  %1408 = fpext float %1404 to double
  %1409 = fpext nnan float %1383 to double
  %1410 = fpext float %1402 to double
  %1411 = fmul double %1408, %1409
  %1412 = fmul double %1411, %1410
  %1413 = fptrunc double %1412 to float
  %1414 = fcmp oeq float %1404, 0.000000e+00
  %1415 = tail call float @llvm.fabs.f32(float %1402)
  %1416 = fcmp one float %1415, +inf
  %1417 = and i1 %1414, %1416
  %1418 = select i1 %1417, float 0.000000e+00, float %1413
  br label %1419

1419:                                             ; preds = %1407, %1400
  %1420 = phi float [ %1418, %1407 ], [ %1405, %1400 ]
  %1421 = extractelement <8 x float> %1375, i64 2
  %1422 = fmul float %1421, %1383
  %1423 = extractelement <8 x float> %275, i64 2
  %1424 = fmul float %1423, %1422
  %1425 = tail call i1 @llvm.is.fpclass.f32(float %1422, /* (sub norm) */ i32 408)
  br i1 %1425, label %1438, label %1426, !prof !4

1426:                                             ; preds = %1419
  %1427 = fpext float %1423 to double
  %1428 = fpext nnan float %1383 to double
  %1429 = fpext float %1421 to double
  %1430 = fmul double %1427, %1428
  %1431 = fmul double %1430, %1429
  %1432 = fptrunc double %1431 to float
  %1433 = fcmp oeq float %1423, 0.000000e+00
  %1434 = tail call float @llvm.fabs.f32(float %1421)
  %1435 = fcmp one float %1434, +inf
  %1436 = and i1 %1433, %1435
  %1437 = select i1 %1436, float 0.000000e+00, float %1432
  br label %1438

1438:                                             ; preds = %1426, %1419
  %1439 = phi float [ %1437, %1426 ], [ %1424, %1419 ]
  %1440 = extractelement <8 x float> %1375, i64 3
  %1441 = fmul float %1440, %1383
  %1442 = extractelement <8 x float> %275, i64 3
  %1443 = fmul float %1442, %1441
  %1444 = tail call i1 @llvm.is.fpclass.f32(float %1441, /* (sub norm) */ i32 408)
  br i1 %1444, label %1457, label %1445, !prof !4

1445:                                             ; preds = %1438
  %1446 = fpext float %1442 to double
  %1447 = fpext nnan float %1383 to double
  %1448 = fpext float %1440 to double
  %1449 = fmul double %1446, %1447
  %1450 = fmul double %1449, %1448
  %1451 = fptrunc double %1450 to float
  %1452 = fcmp oeq float %1442, 0.000000e+00
  %1453 = tail call float @llvm.fabs.f32(float %1440)
  %1454 = fcmp one float %1453, +inf
  %1455 = and i1 %1452, %1454
  %1456 = select i1 %1455, float 0.000000e+00, float %1451
  br label %1457

1457:                                             ; preds = %1445, %1438
  %1458 = phi float [ %1456, %1445 ], [ %1443, %1438 ]
  %1459 = extractelement <8 x float> %1375, i64 4
  %1460 = fmul float %1459, %1383
  %1461 = extractelement <8 x float> %275, i64 4
  %1462 = fmul float %1461, %1460
  %1463 = tail call i1 @llvm.is.fpclass.f32(float %1460, /* (sub norm) */ i32 408)
  br i1 %1463, label %1476, label %1464, !prof !4

1464:                                             ; preds = %1457
  %1465 = fpext float %1461 to double
  %1466 = fpext nnan float %1383 to double
  %1467 = fpext float %1459 to double
  %1468 = fmul double %1465, %1466
  %1469 = fmul double %1468, %1467
  %1470 = fptrunc double %1469 to float
  %1471 = fcmp oeq float %1461, 0.000000e+00
  %1472 = tail call float @llvm.fabs.f32(float %1459)
  %1473 = fcmp one float %1472, +inf
  %1474 = and i1 %1471, %1473
  %1475 = select i1 %1474, float 0.000000e+00, float %1470
  br label %1476

1476:                                             ; preds = %1464, %1457
  %1477 = phi float [ %1475, %1464 ], [ %1462, %1457 ]
  %1478 = extractelement <8 x float> %1375, i64 5
  %1479 = fmul float %1478, %1383
  %1480 = extractelement <8 x float> %275, i64 5
  %1481 = fmul float %1480, %1479
  %1482 = tail call i1 @llvm.is.fpclass.f32(float %1479, /* (sub norm) */ i32 408)
  br i1 %1482, label %1495, label %1483, !prof !4

1483:                                             ; preds = %1476
  %1484 = fpext float %1480 to double
  %1485 = fpext nnan float %1383 to double
  %1486 = fpext float %1478 to double
  %1487 = fmul double %1484, %1485
  %1488 = fmul double %1487, %1486
  %1489 = fptrunc double %1488 to float
  %1490 = fcmp oeq float %1480, 0.000000e+00
  %1491 = tail call float @llvm.fabs.f32(float %1478)
  %1492 = fcmp one float %1491, +inf
  %1493 = and i1 %1490, %1492
  %1494 = select i1 %1493, float 0.000000e+00, float %1489
  br label %1495

1495:                                             ; preds = %1483, %1476
  %1496 = phi float [ %1494, %1483 ], [ %1481, %1476 ]
  %1497 = extractelement <8 x float> %1375, i64 6
  %1498 = fmul float %1497, %1383
  %1499 = extractelement <8 x float> %275, i64 6
  %1500 = fmul float %1499, %1498
  %1501 = tail call i1 @llvm.is.fpclass.f32(float %1498, /* (sub norm) */ i32 408)
  br i1 %1501, label %1514, label %1502, !prof !4

1502:                                             ; preds = %1495
  %1503 = fpext float %1499 to double
  %1504 = fpext nnan float %1383 to double
  %1505 = fpext float %1497 to double
  %1506 = fmul double %1503, %1504
  %1507 = fmul double %1506, %1505
  %1508 = fptrunc double %1507 to float
  %1509 = fcmp oeq float %1499, 0.000000e+00
  %1510 = tail call float @llvm.fabs.f32(float %1497)
  %1511 = fcmp one float %1510, +inf
  %1512 = and i1 %1509, %1511
  %1513 = select i1 %1512, float 0.000000e+00, float %1508
  br label %1514

1514:                                             ; preds = %1502, %1495
  %1515 = phi float [ %1513, %1502 ], [ %1500, %1495 ]
  %1516 = extractelement <8 x float> %1375, i64 7
  %1517 = fmul float %1516, %1383
  %1518 = extractelement <8 x float> %275, i64 7
  %1519 = fmul float %1518, %1517
  %1520 = tail call i1 @llvm.is.fpclass.f32(float %1517, /* (sub norm) */ i32 408)
  br i1 %1520, label %1533, label %1521, !prof !4

1521:                                             ; preds = %1514
  %1522 = fpext float %1518 to double
  %1523 = fpext nnan float %1383 to double
  %1524 = fpext float %1516 to double
  %1525 = fmul double %1522, %1523
  %1526 = fmul double %1525, %1524
  %1527 = fptrunc double %1526 to float
  %1528 = fcmp oeq float %1518, 0.000000e+00
  %1529 = tail call float @llvm.fabs.f32(float %1516)
  %1530 = fcmp one float %1529, +inf
  %1531 = and i1 %1528, %1530
  %1532 = select i1 %1531, float 0.000000e+00, float %1527
  br label %1533

1533:                                             ; preds = %1521, %1514
  %1534 = phi float [ %1532, %1521 ], [ %1519, %1514 ]
  %1535 = fptrunc float %1401 to bfloat
  %1536 = getelementptr [2 x i8], ptr addrspace(1) %510, i64 %1323
  store bfloat %1535, ptr addrspace(1) %1536, align 2
  %1537 = fptrunc float %1420 to bfloat
  %1538 = getelementptr [2 x i8], ptr addrspace(1) %516, i64 %1323
  store bfloat %1537, ptr addrspace(1) %1538, align 2
  %1539 = fptrunc float %1439 to bfloat
  %1540 = getelementptr [2 x i8], ptr addrspace(1) %522, i64 %1323
  store bfloat %1539, ptr addrspace(1) %1540, align 2
  %1541 = fptrunc float %1458 to bfloat
  %1542 = getelementptr [2 x i8], ptr addrspace(1) %528, i64 %1323
  store bfloat %1541, ptr addrspace(1) %1542, align 2
  %1543 = fptrunc float %1477 to bfloat
  %1544 = getelementptr [2 x i8], ptr addrspace(1) %534, i64 %1323
  store bfloat %1543, ptr addrspace(1) %1544, align 2
  %1545 = fptrunc float %1496 to bfloat
  %1546 = getelementptr [2 x i8], ptr addrspace(1) %540, i64 %1323
  store bfloat %1545, ptr addrspace(1) %1546, align 2
  %1547 = fptrunc float %1515 to bfloat
  %1548 = getelementptr [2 x i8], ptr addrspace(1) %546, i64 %1323
  store bfloat %1547, ptr addrspace(1) %1548, align 2
  %1549 = fptrunc float %1534 to bfloat
  %1550 = getelementptr [2 x i8], ptr addrspace(1) %552, i64 %1323
  store bfloat %1549, ptr addrspace(1) %1550, align 2
  %1551 = and i1 %1324, %556
  %1552 = and i1 %292, %1551
  br i1 %1552, label %1553, label %1559

1553:                                             ; preds = %1533
  %1554 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %554
  %1555 = load <4 x float>, ptr addrspace(1) %1554, align 16
  %1556 = getelementptr i8, ptr addrspace(1) %1554, i64 16
  %1557 = load <4 x float>, ptr addrspace(1) %1556, align 16
  %1558 = shufflevector <4 x float> %1555, <4 x float> %1557, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1600

1559:                                             ; preds = %1533
  %1560 = icmp slt i64 %554, %25
  %1561 = select i1 %1560, i64 %554, i64 0
  %1562 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1561
  %1563 = load float, ptr addrspace(1) %1562, align 4
  %1564 = insertelement <8 x float> poison, float %1563, i64 0
  %1565 = icmp slt i64 %775, %25
  %1566 = select i1 %1565, i64 %775, i64 0
  %1567 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1566
  %1568 = load float, ptr addrspace(1) %1567, align 4
  %1569 = insertelement <8 x float> %1564, float %1568, i64 1
  %1570 = icmp slt i64 %780, %25
  %1571 = select i1 %1570, i64 %780, i64 0
  %1572 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1571
  %1573 = load float, ptr addrspace(1) %1572, align 4
  %1574 = insertelement <8 x float> %1569, float %1573, i64 2
  %1575 = icmp slt i64 %785, %25
  %1576 = select i1 %1575, i64 %785, i64 0
  %1577 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1576
  %1578 = load float, ptr addrspace(1) %1577, align 4
  %1579 = insertelement <8 x float> %1574, float %1578, i64 3
  %1580 = icmp slt i64 %790, %25
  %1581 = select i1 %1580, i64 %790, i64 0
  %1582 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1581
  %1583 = load float, ptr addrspace(1) %1582, align 4
  %1584 = insertelement <8 x float> %1579, float %1583, i64 4
  %1585 = icmp slt i64 %795, %25
  %1586 = select i1 %1585, i64 %795, i64 0
  %1587 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1586
  %1588 = load float, ptr addrspace(1) %1587, align 4
  %1589 = insertelement <8 x float> %1584, float %1588, i64 5
  %1590 = icmp slt i64 %800, %25
  %1591 = select i1 %1590, i64 %800, i64 0
  %1592 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1591
  %1593 = load float, ptr addrspace(1) %1592, align 4
  %1594 = insertelement <8 x float> %1589, float %1593, i64 6
  %1595 = icmp slt i64 %805, %25
  %1596 = select i1 %1595, i64 %805, i64 0
  %1597 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1596
  %1598 = load float, ptr addrspace(1) %1597, align 4
  %1599 = insertelement <8 x float> %1594, float %1598, i64 7
  br label %1600

1600:                                             ; preds = %1553, %1559
  %1601 = phi <8 x float> [ %1599, %1559 ], [ %1558, %1553 ]
  %1602 = extractelement <8 x float> %1601, i64 0
  %1603 = load i8, ptr addrspace(1) %1379, align 1
  %1604 = zext i8 %1603 to i32
  %1605 = shl nuw nsw i32 %1604, 23
  %1606 = bitcast i32 %1605 to float
  %1607 = fmul float %1602, %1606
  %1608 = extractelement <8 x float> %277, i64 0
  %1609 = fmul float %1608, %1607
  %1610 = tail call i1 @llvm.is.fpclass.f32(float %1607, /* (sub norm) */ i32 408)
  br i1 %1610, label %1623, label %1611, !prof !4

1611:                                             ; preds = %1600
  %1612 = fpext float %1608 to double
  %1613 = fpext nnan float %1606 to double
  %1614 = fpext float %1602 to double
  %1615 = fmul double %1612, %1613
  %1616 = fmul double %1615, %1614
  %1617 = fptrunc double %1616 to float
  %1618 = fcmp oeq float %1608, 0.000000e+00
  %1619 = tail call float @llvm.fabs.f32(float %1602)
  %1620 = fcmp one float %1619, +inf
  %1621 = and i1 %1618, %1620
  %1622 = select i1 %1621, float 0.000000e+00, float %1617
  br label %1623

1623:                                             ; preds = %1611, %1600
  %1624 = phi float [ %1622, %1611 ], [ %1609, %1600 ]
  %1625 = extractelement <8 x float> %1601, i64 1
  %1626 = fmul float %1625, %1606
  %1627 = extractelement <8 x float> %277, i64 1
  %1628 = fmul float %1627, %1626
  %1629 = tail call i1 @llvm.is.fpclass.f32(float %1626, /* (sub norm) */ i32 408)
  br i1 %1629, label %1642, label %1630, !prof !4

1630:                                             ; preds = %1623
  %1631 = fpext float %1627 to double
  %1632 = fpext nnan float %1606 to double
  %1633 = fpext float %1625 to double
  %1634 = fmul double %1631, %1632
  %1635 = fmul double %1634, %1633
  %1636 = fptrunc double %1635 to float
  %1637 = fcmp oeq float %1627, 0.000000e+00
  %1638 = tail call float @llvm.fabs.f32(float %1625)
  %1639 = fcmp one float %1638, +inf
  %1640 = and i1 %1637, %1639
  %1641 = select i1 %1640, float 0.000000e+00, float %1636
  br label %1642

1642:                                             ; preds = %1630, %1623
  %1643 = phi float [ %1641, %1630 ], [ %1628, %1623 ]
  %1644 = extractelement <8 x float> %1601, i64 2
  %1645 = fmul float %1644, %1606
  %1646 = extractelement <8 x float> %277, i64 2
  %1647 = fmul float %1646, %1645
  %1648 = tail call i1 @llvm.is.fpclass.f32(float %1645, /* (sub norm) */ i32 408)
  br i1 %1648, label %1661, label %1649, !prof !4

1649:                                             ; preds = %1642
  %1650 = fpext float %1646 to double
  %1651 = fpext nnan float %1606 to double
  %1652 = fpext float %1644 to double
  %1653 = fmul double %1650, %1651
  %1654 = fmul double %1653, %1652
  %1655 = fptrunc double %1654 to float
  %1656 = fcmp oeq float %1646, 0.000000e+00
  %1657 = tail call float @llvm.fabs.f32(float %1644)
  %1658 = fcmp one float %1657, +inf
  %1659 = and i1 %1656, %1658
  %1660 = select i1 %1659, float 0.000000e+00, float %1655
  br label %1661

1661:                                             ; preds = %1649, %1642
  %1662 = phi float [ %1660, %1649 ], [ %1647, %1642 ]
  %1663 = extractelement <8 x float> %1601, i64 3
  %1664 = fmul float %1663, %1606
  %1665 = extractelement <8 x float> %277, i64 3
  %1666 = fmul float %1665, %1664
  %1667 = tail call i1 @llvm.is.fpclass.f32(float %1664, /* (sub norm) */ i32 408)
  br i1 %1667, label %1680, label %1668, !prof !4

1668:                                             ; preds = %1661
  %1669 = fpext float %1665 to double
  %1670 = fpext nnan float %1606 to double
  %1671 = fpext float %1663 to double
  %1672 = fmul double %1669, %1670
  %1673 = fmul double %1672, %1671
  %1674 = fptrunc double %1673 to float
  %1675 = fcmp oeq float %1665, 0.000000e+00
  %1676 = tail call float @llvm.fabs.f32(float %1663)
  %1677 = fcmp one float %1676, +inf
  %1678 = and i1 %1675, %1677
  %1679 = select i1 %1678, float 0.000000e+00, float %1674
  br label %1680

1680:                                             ; preds = %1668, %1661
  %1681 = phi float [ %1679, %1668 ], [ %1666, %1661 ]
  %1682 = extractelement <8 x float> %1601, i64 4
  %1683 = fmul float %1682, %1606
  %1684 = extractelement <8 x float> %277, i64 4
  %1685 = fmul float %1684, %1683
  %1686 = tail call i1 @llvm.is.fpclass.f32(float %1683, /* (sub norm) */ i32 408)
  br i1 %1686, label %1699, label %1687, !prof !4

1687:                                             ; preds = %1680
  %1688 = fpext float %1684 to double
  %1689 = fpext nnan float %1606 to double
  %1690 = fpext float %1682 to double
  %1691 = fmul double %1688, %1689
  %1692 = fmul double %1691, %1690
  %1693 = fptrunc double %1692 to float
  %1694 = fcmp oeq float %1684, 0.000000e+00
  %1695 = tail call float @llvm.fabs.f32(float %1682)
  %1696 = fcmp one float %1695, +inf
  %1697 = and i1 %1694, %1696
  %1698 = select i1 %1697, float 0.000000e+00, float %1693
  br label %1699

1699:                                             ; preds = %1687, %1680
  %1700 = phi float [ %1698, %1687 ], [ %1685, %1680 ]
  %1701 = extractelement <8 x float> %1601, i64 5
  %1702 = fmul float %1701, %1606
  %1703 = extractelement <8 x float> %277, i64 5
  %1704 = fmul float %1703, %1702
  %1705 = tail call i1 @llvm.is.fpclass.f32(float %1702, /* (sub norm) */ i32 408)
  br i1 %1705, label %1718, label %1706, !prof !4

1706:                                             ; preds = %1699
  %1707 = fpext float %1703 to double
  %1708 = fpext nnan float %1606 to double
  %1709 = fpext float %1701 to double
  %1710 = fmul double %1707, %1708
  %1711 = fmul double %1710, %1709
  %1712 = fptrunc double %1711 to float
  %1713 = fcmp oeq float %1703, 0.000000e+00
  %1714 = tail call float @llvm.fabs.f32(float %1701)
  %1715 = fcmp one float %1714, +inf
  %1716 = and i1 %1713, %1715
  %1717 = select i1 %1716, float 0.000000e+00, float %1712
  br label %1718

1718:                                             ; preds = %1706, %1699
  %1719 = phi float [ %1717, %1706 ], [ %1704, %1699 ]
  %1720 = extractelement <8 x float> %1601, i64 6
  %1721 = fmul float %1720, %1606
  %1722 = extractelement <8 x float> %277, i64 6
  %1723 = fmul float %1722, %1721
  %1724 = tail call i1 @llvm.is.fpclass.f32(float %1721, /* (sub norm) */ i32 408)
  br i1 %1724, label %1737, label %1725, !prof !4

1725:                                             ; preds = %1718
  %1726 = fpext float %1722 to double
  %1727 = fpext nnan float %1606 to double
  %1728 = fpext float %1720 to double
  %1729 = fmul double %1726, %1727
  %1730 = fmul double %1729, %1728
  %1731 = fptrunc double %1730 to float
  %1732 = fcmp oeq float %1722, 0.000000e+00
  %1733 = tail call float @llvm.fabs.f32(float %1720)
  %1734 = fcmp one float %1733, +inf
  %1735 = and i1 %1732, %1734
  %1736 = select i1 %1735, float 0.000000e+00, float %1731
  br label %1737

1737:                                             ; preds = %1725, %1718
  %1738 = phi float [ %1736, %1725 ], [ %1723, %1718 ]
  %1739 = extractelement <8 x float> %1601, i64 7
  %1740 = fmul float %1739, %1606
  %1741 = extractelement <8 x float> %277, i64 7
  %1742 = fmul float %1741, %1740
  %1743 = tail call i1 @llvm.is.fpclass.f32(float %1740, /* (sub norm) */ i32 408)
  br i1 %1743, label %1756, label %1744, !prof !4

1744:                                             ; preds = %1737
  %1745 = fpext float %1741 to double
  %1746 = fpext nnan float %1606 to double
  %1747 = fpext float %1739 to double
  %1748 = fmul double %1745, %1746
  %1749 = fmul double %1748, %1747
  %1750 = fptrunc double %1749 to float
  %1751 = fcmp oeq float %1741, 0.000000e+00
  %1752 = tail call float @llvm.fabs.f32(float %1739)
  %1753 = fcmp one float %1752, +inf
  %1754 = and i1 %1751, %1753
  %1755 = select i1 %1754, float 0.000000e+00, float %1750
  br label %1756

1756:                                             ; preds = %1744, %1737
  %1757 = phi float [ %1755, %1744 ], [ %1742, %1737 ]
  %1758 = fptrunc float %1624 to bfloat
  %1759 = getelementptr [2 x i8], ptr addrspace(1) %773, i64 %1323
  store bfloat %1758, ptr addrspace(1) %1759, align 2
  %1760 = fptrunc float %1643 to bfloat
  %1761 = getelementptr [2 x i8], ptr addrspace(1) %778, i64 %1323
  store bfloat %1760, ptr addrspace(1) %1761, align 2
  %1762 = fptrunc float %1662 to bfloat
  %1763 = getelementptr [2 x i8], ptr addrspace(1) %783, i64 %1323
  store bfloat %1762, ptr addrspace(1) %1763, align 2
  %1764 = fptrunc float %1681 to bfloat
  %1765 = getelementptr [2 x i8], ptr addrspace(1) %788, i64 %1323
  store bfloat %1764, ptr addrspace(1) %1765, align 2
  %1766 = fptrunc float %1700 to bfloat
  %1767 = getelementptr [2 x i8], ptr addrspace(1) %793, i64 %1323
  store bfloat %1766, ptr addrspace(1) %1767, align 2
  %1768 = fptrunc float %1719 to bfloat
  %1769 = getelementptr [2 x i8], ptr addrspace(1) %798, i64 %1323
  store bfloat %1768, ptr addrspace(1) %1769, align 2
  %1770 = fptrunc float %1738 to bfloat
  %1771 = getelementptr [2 x i8], ptr addrspace(1) %803, i64 %1323
  store bfloat %1770, ptr addrspace(1) %1771, align 2
  %1772 = fptrunc float %1757 to bfloat
  %1773 = getelementptr [2 x i8], ptr addrspace(1) %808, i64 %1323
  store bfloat %1772, ptr addrspace(1) %1773, align 2
  %1774 = and i1 %1324, %812
  %1775 = and i1 %292, %1774
  br i1 %1775, label %1776, label %1782

1776:                                             ; preds = %1756
  %1777 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %810
  %1778 = load <4 x float>, ptr addrspace(1) %1777, align 16
  %1779 = getelementptr i8, ptr addrspace(1) %1777, i64 16
  %1780 = load <4 x float>, ptr addrspace(1) %1779, align 16
  %1781 = shufflevector <4 x float> %1778, <4 x float> %1780, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1823

1782:                                             ; preds = %1756
  %1783 = icmp slt i64 %810, %25
  %1784 = select i1 %1783, i64 %810, i64 0
  %1785 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1784
  %1786 = load float, ptr addrspace(1) %1785, align 4
  %1787 = insertelement <8 x float> poison, float %1786, i64 0
  %1788 = icmp slt i64 %1031, %25
  %1789 = select i1 %1788, i64 %1031, i64 0
  %1790 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1789
  %1791 = load float, ptr addrspace(1) %1790, align 4
  %1792 = insertelement <8 x float> %1787, float %1791, i64 1
  %1793 = icmp slt i64 %1036, %25
  %1794 = select i1 %1793, i64 %1036, i64 0
  %1795 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1794
  %1796 = load float, ptr addrspace(1) %1795, align 4
  %1797 = insertelement <8 x float> %1792, float %1796, i64 2
  %1798 = icmp slt i64 %1041, %25
  %1799 = select i1 %1798, i64 %1041, i64 0
  %1800 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1799
  %1801 = load float, ptr addrspace(1) %1800, align 4
  %1802 = insertelement <8 x float> %1797, float %1801, i64 3
  %1803 = icmp slt i64 %1046, %25
  %1804 = select i1 %1803, i64 %1046, i64 0
  %1805 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1804
  %1806 = load float, ptr addrspace(1) %1805, align 4
  %1807 = insertelement <8 x float> %1802, float %1806, i64 4
  %1808 = icmp slt i64 %1051, %25
  %1809 = select i1 %1808, i64 %1051, i64 0
  %1810 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1809
  %1811 = load float, ptr addrspace(1) %1810, align 4
  %1812 = insertelement <8 x float> %1807, float %1811, i64 5
  %1813 = icmp slt i64 %1056, %25
  %1814 = select i1 %1813, i64 %1056, i64 0
  %1815 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1814
  %1816 = load float, ptr addrspace(1) %1815, align 4
  %1817 = insertelement <8 x float> %1812, float %1816, i64 6
  %1818 = icmp slt i64 %1061, %25
  %1819 = select i1 %1818, i64 %1061, i64 0
  %1820 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1819
  %1821 = load float, ptr addrspace(1) %1820, align 4
  %1822 = insertelement <8 x float> %1817, float %1821, i64 7
  br label %1823

1823:                                             ; preds = %1776, %1782
  %1824 = phi <8 x float> [ %1822, %1782 ], [ %1781, %1776 ]
  %1825 = extractelement <8 x float> %1824, i64 0
  %1826 = load i8, ptr addrspace(1) %1379, align 1
  %1827 = zext i8 %1826 to i32
  %1828 = shl nuw nsw i32 %1827, 23
  %1829 = bitcast i32 %1828 to float
  %1830 = fmul float %1825, %1829
  %1831 = extractelement <8 x float> %279, i64 0
  %1832 = fmul float %1831, %1830
  %1833 = tail call i1 @llvm.is.fpclass.f32(float %1830, /* (sub norm) */ i32 408)
  br i1 %1833, label %1846, label %1834, !prof !4

1834:                                             ; preds = %1823
  %1835 = fpext float %1831 to double
  %1836 = fpext nnan float %1829 to double
  %1837 = fpext float %1825 to double
  %1838 = fmul double %1835, %1836
  %1839 = fmul double %1838, %1837
  %1840 = fptrunc double %1839 to float
  %1841 = fcmp oeq float %1831, 0.000000e+00
  %1842 = tail call float @llvm.fabs.f32(float %1825)
  %1843 = fcmp one float %1842, +inf
  %1844 = and i1 %1841, %1843
  %1845 = select i1 %1844, float 0.000000e+00, float %1840
  br label %1846

1846:                                             ; preds = %1834, %1823
  %1847 = phi float [ %1845, %1834 ], [ %1832, %1823 ]
  %1848 = extractelement <8 x float> %1824, i64 1
  %1849 = fmul float %1848, %1829
  %1850 = extractelement <8 x float> %279, i64 1
  %1851 = fmul float %1850, %1849
  %1852 = tail call i1 @llvm.is.fpclass.f32(float %1849, /* (sub norm) */ i32 408)
  br i1 %1852, label %1865, label %1853, !prof !4

1853:                                             ; preds = %1846
  %1854 = fpext float %1850 to double
  %1855 = fpext nnan float %1829 to double
  %1856 = fpext float %1848 to double
  %1857 = fmul double %1854, %1855
  %1858 = fmul double %1857, %1856
  %1859 = fptrunc double %1858 to float
  %1860 = fcmp oeq float %1850, 0.000000e+00
  %1861 = tail call float @llvm.fabs.f32(float %1848)
  %1862 = fcmp one float %1861, +inf
  %1863 = and i1 %1860, %1862
  %1864 = select i1 %1863, float 0.000000e+00, float %1859
  br label %1865

1865:                                             ; preds = %1853, %1846
  %1866 = phi float [ %1864, %1853 ], [ %1851, %1846 ]
  %1867 = extractelement <8 x float> %1824, i64 2
  %1868 = fmul float %1867, %1829
  %1869 = extractelement <8 x float> %279, i64 2
  %1870 = fmul float %1869, %1868
  %1871 = tail call i1 @llvm.is.fpclass.f32(float %1868, /* (sub norm) */ i32 408)
  br i1 %1871, label %1884, label %1872, !prof !4

1872:                                             ; preds = %1865
  %1873 = fpext float %1869 to double
  %1874 = fpext nnan float %1829 to double
  %1875 = fpext float %1867 to double
  %1876 = fmul double %1873, %1874
  %1877 = fmul double %1876, %1875
  %1878 = fptrunc double %1877 to float
  %1879 = fcmp oeq float %1869, 0.000000e+00
  %1880 = tail call float @llvm.fabs.f32(float %1867)
  %1881 = fcmp one float %1880, +inf
  %1882 = and i1 %1879, %1881
  %1883 = select i1 %1882, float 0.000000e+00, float %1878
  br label %1884

1884:                                             ; preds = %1872, %1865
  %1885 = phi float [ %1883, %1872 ], [ %1870, %1865 ]
  %1886 = extractelement <8 x float> %1824, i64 3
  %1887 = fmul float %1886, %1829
  %1888 = extractelement <8 x float> %279, i64 3
  %1889 = fmul float %1888, %1887
  %1890 = tail call i1 @llvm.is.fpclass.f32(float %1887, /* (sub norm) */ i32 408)
  br i1 %1890, label %1903, label %1891, !prof !4

1891:                                             ; preds = %1884
  %1892 = fpext float %1888 to double
  %1893 = fpext nnan float %1829 to double
  %1894 = fpext float %1886 to double
  %1895 = fmul double %1892, %1893
  %1896 = fmul double %1895, %1894
  %1897 = fptrunc double %1896 to float
  %1898 = fcmp oeq float %1888, 0.000000e+00
  %1899 = tail call float @llvm.fabs.f32(float %1886)
  %1900 = fcmp one float %1899, +inf
  %1901 = and i1 %1898, %1900
  %1902 = select i1 %1901, float 0.000000e+00, float %1897
  br label %1903

1903:                                             ; preds = %1891, %1884
  %1904 = phi float [ %1902, %1891 ], [ %1889, %1884 ]
  %1905 = extractelement <8 x float> %1824, i64 4
  %1906 = fmul float %1905, %1829
  %1907 = extractelement <8 x float> %279, i64 4
  %1908 = fmul float %1907, %1906
  %1909 = tail call i1 @llvm.is.fpclass.f32(float %1906, /* (sub norm) */ i32 408)
  br i1 %1909, label %1922, label %1910, !prof !4

1910:                                             ; preds = %1903
  %1911 = fpext float %1907 to double
  %1912 = fpext nnan float %1829 to double
  %1913 = fpext float %1905 to double
  %1914 = fmul double %1911, %1912
  %1915 = fmul double %1914, %1913
  %1916 = fptrunc double %1915 to float
  %1917 = fcmp oeq float %1907, 0.000000e+00
  %1918 = tail call float @llvm.fabs.f32(float %1905)
  %1919 = fcmp one float %1918, +inf
  %1920 = and i1 %1917, %1919
  %1921 = select i1 %1920, float 0.000000e+00, float %1916
  br label %1922

1922:                                             ; preds = %1910, %1903
  %1923 = phi float [ %1921, %1910 ], [ %1908, %1903 ]
  %1924 = extractelement <8 x float> %1824, i64 5
  %1925 = fmul float %1924, %1829
  %1926 = extractelement <8 x float> %279, i64 5
  %1927 = fmul float %1926, %1925
  %1928 = tail call i1 @llvm.is.fpclass.f32(float %1925, /* (sub norm) */ i32 408)
  br i1 %1928, label %1941, label %1929, !prof !4

1929:                                             ; preds = %1922
  %1930 = fpext float %1926 to double
  %1931 = fpext nnan float %1829 to double
  %1932 = fpext float %1924 to double
  %1933 = fmul double %1930, %1931
  %1934 = fmul double %1933, %1932
  %1935 = fptrunc double %1934 to float
  %1936 = fcmp oeq float %1926, 0.000000e+00
  %1937 = tail call float @llvm.fabs.f32(float %1924)
  %1938 = fcmp one float %1937, +inf
  %1939 = and i1 %1936, %1938
  %1940 = select i1 %1939, float 0.000000e+00, float %1935
  br label %1941

1941:                                             ; preds = %1929, %1922
  %1942 = phi float [ %1940, %1929 ], [ %1927, %1922 ]
  %1943 = extractelement <8 x float> %1824, i64 6
  %1944 = fmul float %1943, %1829
  %1945 = extractelement <8 x float> %279, i64 6
  %1946 = fmul float %1945, %1944
  %1947 = tail call i1 @llvm.is.fpclass.f32(float %1944, /* (sub norm) */ i32 408)
  br i1 %1947, label %1960, label %1948, !prof !4

1948:                                             ; preds = %1941
  %1949 = fpext float %1945 to double
  %1950 = fpext nnan float %1829 to double
  %1951 = fpext float %1943 to double
  %1952 = fmul double %1949, %1950
  %1953 = fmul double %1952, %1951
  %1954 = fptrunc double %1953 to float
  %1955 = fcmp oeq float %1945, 0.000000e+00
  %1956 = tail call float @llvm.fabs.f32(float %1943)
  %1957 = fcmp one float %1956, +inf
  %1958 = and i1 %1955, %1957
  %1959 = select i1 %1958, float 0.000000e+00, float %1954
  br label %1960

1960:                                             ; preds = %1948, %1941
  %1961 = phi float [ %1959, %1948 ], [ %1946, %1941 ]
  %1962 = extractelement <8 x float> %1824, i64 7
  %1963 = fmul float %1962, %1829
  %1964 = extractelement <8 x float> %279, i64 7
  %1965 = fmul float %1964, %1963
  %1966 = tail call i1 @llvm.is.fpclass.f32(float %1963, /* (sub norm) */ i32 408)
  br i1 %1966, label %1979, label %1967, !prof !4

1967:                                             ; preds = %1960
  %1968 = fpext float %1964 to double
  %1969 = fpext nnan float %1829 to double
  %1970 = fpext float %1962 to double
  %1971 = fmul double %1968, %1969
  %1972 = fmul double %1971, %1970
  %1973 = fptrunc double %1972 to float
  %1974 = fcmp oeq float %1964, 0.000000e+00
  %1975 = tail call float @llvm.fabs.f32(float %1962)
  %1976 = fcmp one float %1975, +inf
  %1977 = and i1 %1974, %1976
  %1978 = select i1 %1977, float 0.000000e+00, float %1973
  br label %1979

1979:                                             ; preds = %1967, %1960
  %1980 = phi float [ %1978, %1967 ], [ %1965, %1960 ]
  %1981 = fptrunc float %1847 to bfloat
  %1982 = getelementptr [2 x i8], ptr addrspace(1) %1029, i64 %1323
  store bfloat %1981, ptr addrspace(1) %1982, align 2
  %1983 = fptrunc float %1866 to bfloat
  %1984 = getelementptr [2 x i8], ptr addrspace(1) %1034, i64 %1323
  store bfloat %1983, ptr addrspace(1) %1984, align 2
  %1985 = fptrunc float %1885 to bfloat
  %1986 = getelementptr [2 x i8], ptr addrspace(1) %1039, i64 %1323
  store bfloat %1985, ptr addrspace(1) %1986, align 2
  %1987 = fptrunc float %1904 to bfloat
  %1988 = getelementptr [2 x i8], ptr addrspace(1) %1044, i64 %1323
  store bfloat %1987, ptr addrspace(1) %1988, align 2
  %1989 = fptrunc float %1923 to bfloat
  %1990 = getelementptr [2 x i8], ptr addrspace(1) %1049, i64 %1323
  store bfloat %1989, ptr addrspace(1) %1990, align 2
  %1991 = fptrunc float %1942 to bfloat
  %1992 = getelementptr [2 x i8], ptr addrspace(1) %1054, i64 %1323
  store bfloat %1991, ptr addrspace(1) %1992, align 2
  %1993 = fptrunc float %1961 to bfloat
  %1994 = getelementptr [2 x i8], ptr addrspace(1) %1059, i64 %1323
  store bfloat %1993, ptr addrspace(1) %1994, align 2
  %1995 = fptrunc float %1980 to bfloat
  %1996 = getelementptr [2 x i8], ptr addrspace(1) %1064, i64 %1323
  store bfloat %1995, ptr addrspace(1) %1996, align 2
  %1997 = and i1 %1324, %1068
  %1998 = and i1 %292, %1997
  br i1 %1998, label %1999, label %2005

1999:                                             ; preds = %1979
  %2000 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1066
  %2001 = load <4 x float>, ptr addrspace(1) %2000, align 16
  %2002 = getelementptr i8, ptr addrspace(1) %2000, i64 16
  %2003 = load <4 x float>, ptr addrspace(1) %2002, align 16
  %2004 = shufflevector <4 x float> %2001, <4 x float> %2003, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2046

2005:                                             ; preds = %1979
  %2006 = icmp slt i64 %1066, %25
  %2007 = select i1 %2006, i64 %1066, i64 0
  %2008 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2007
  %2009 = load float, ptr addrspace(1) %2008, align 4
  %2010 = insertelement <8 x float> poison, float %2009, i64 0
  %2011 = icmp slt i64 %1287, %25
  %2012 = select i1 %2011, i64 %1287, i64 0
  %2013 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2012
  %2014 = load float, ptr addrspace(1) %2013, align 4
  %2015 = insertelement <8 x float> %2010, float %2014, i64 1
  %2016 = icmp slt i64 %1292, %25
  %2017 = select i1 %2016, i64 %1292, i64 0
  %2018 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2017
  %2019 = load float, ptr addrspace(1) %2018, align 4
  %2020 = insertelement <8 x float> %2015, float %2019, i64 2
  %2021 = icmp slt i64 %1297, %25
  %2022 = select i1 %2021, i64 %1297, i64 0
  %2023 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2022
  %2024 = load float, ptr addrspace(1) %2023, align 4
  %2025 = insertelement <8 x float> %2020, float %2024, i64 3
  %2026 = icmp slt i64 %1302, %25
  %2027 = select i1 %2026, i64 %1302, i64 0
  %2028 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2027
  %2029 = load float, ptr addrspace(1) %2028, align 4
  %2030 = insertelement <8 x float> %2025, float %2029, i64 4
  %2031 = icmp slt i64 %1307, %25
  %2032 = select i1 %2031, i64 %1307, i64 0
  %2033 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2032
  %2034 = load float, ptr addrspace(1) %2033, align 4
  %2035 = insertelement <8 x float> %2030, float %2034, i64 5
  %2036 = icmp slt i64 %1312, %25
  %2037 = select i1 %2036, i64 %1312, i64 0
  %2038 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2037
  %2039 = load float, ptr addrspace(1) %2038, align 4
  %2040 = insertelement <8 x float> %2035, float %2039, i64 6
  %2041 = icmp slt i64 %1317, %25
  %2042 = select i1 %2041, i64 %1317, i64 0
  %2043 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2042
  %2044 = load float, ptr addrspace(1) %2043, align 4
  %2045 = insertelement <8 x float> %2040, float %2044, i64 7
  br label %2046

2046:                                             ; preds = %1999, %2005
  %2047 = phi <8 x float> [ %2045, %2005 ], [ %2004, %1999 ]
  %2048 = extractelement <8 x float> %2047, i64 0
  %2049 = load i8, ptr addrspace(1) %1379, align 1
  %2050 = zext i8 %2049 to i32
  %2051 = shl nuw nsw i32 %2050, 23
  %2052 = bitcast i32 %2051 to float
  %2053 = fmul float %2048, %2052
  %2054 = extractelement <8 x float> %281, i64 0
  %2055 = fmul float %2054, %2053
  %2056 = tail call i1 @llvm.is.fpclass.f32(float %2053, /* (sub norm) */ i32 408)
  br i1 %2056, label %2069, label %2057, !prof !4

2057:                                             ; preds = %2046
  %2058 = fpext float %2054 to double
  %2059 = fpext nnan float %2052 to double
  %2060 = fpext float %2048 to double
  %2061 = fmul double %2058, %2059
  %2062 = fmul double %2061, %2060
  %2063 = fptrunc double %2062 to float
  %2064 = fcmp oeq float %2054, 0.000000e+00
  %2065 = tail call float @llvm.fabs.f32(float %2048)
  %2066 = fcmp one float %2065, +inf
  %2067 = and i1 %2064, %2066
  %2068 = select i1 %2067, float 0.000000e+00, float %2063
  br label %2069

2069:                                             ; preds = %2057, %2046
  %2070 = phi float [ %2068, %2057 ], [ %2055, %2046 ]
  %2071 = extractelement <8 x float> %2047, i64 1
  %2072 = fmul float %2071, %2052
  %2073 = extractelement <8 x float> %281, i64 1
  %2074 = fmul float %2073, %2072
  %2075 = tail call i1 @llvm.is.fpclass.f32(float %2072, /* (sub norm) */ i32 408)
  br i1 %2075, label %2088, label %2076, !prof !4

2076:                                             ; preds = %2069
  %2077 = fpext float %2073 to double
  %2078 = fpext nnan float %2052 to double
  %2079 = fpext float %2071 to double
  %2080 = fmul double %2077, %2078
  %2081 = fmul double %2080, %2079
  %2082 = fptrunc double %2081 to float
  %2083 = fcmp oeq float %2073, 0.000000e+00
  %2084 = tail call float @llvm.fabs.f32(float %2071)
  %2085 = fcmp one float %2084, +inf
  %2086 = and i1 %2083, %2085
  %2087 = select i1 %2086, float 0.000000e+00, float %2082
  br label %2088

2088:                                             ; preds = %2076, %2069
  %2089 = phi float [ %2087, %2076 ], [ %2074, %2069 ]
  %2090 = extractelement <8 x float> %2047, i64 2
  %2091 = fmul float %2090, %2052
  %2092 = extractelement <8 x float> %281, i64 2
  %2093 = fmul float %2092, %2091
  %2094 = tail call i1 @llvm.is.fpclass.f32(float %2091, /* (sub norm) */ i32 408)
  br i1 %2094, label %2107, label %2095, !prof !4

2095:                                             ; preds = %2088
  %2096 = fpext float %2092 to double
  %2097 = fpext nnan float %2052 to double
  %2098 = fpext float %2090 to double
  %2099 = fmul double %2096, %2097
  %2100 = fmul double %2099, %2098
  %2101 = fptrunc double %2100 to float
  %2102 = fcmp oeq float %2092, 0.000000e+00
  %2103 = tail call float @llvm.fabs.f32(float %2090)
  %2104 = fcmp one float %2103, +inf
  %2105 = and i1 %2102, %2104
  %2106 = select i1 %2105, float 0.000000e+00, float %2101
  br label %2107

2107:                                             ; preds = %2095, %2088
  %2108 = phi float [ %2106, %2095 ], [ %2093, %2088 ]
  %2109 = extractelement <8 x float> %2047, i64 3
  %2110 = fmul float %2109, %2052
  %2111 = extractelement <8 x float> %281, i64 3
  %2112 = fmul float %2111, %2110
  %2113 = tail call i1 @llvm.is.fpclass.f32(float %2110, /* (sub norm) */ i32 408)
  br i1 %2113, label %2126, label %2114, !prof !4

2114:                                             ; preds = %2107
  %2115 = fpext float %2111 to double
  %2116 = fpext nnan float %2052 to double
  %2117 = fpext float %2109 to double
  %2118 = fmul double %2115, %2116
  %2119 = fmul double %2118, %2117
  %2120 = fptrunc double %2119 to float
  %2121 = fcmp oeq float %2111, 0.000000e+00
  %2122 = tail call float @llvm.fabs.f32(float %2109)
  %2123 = fcmp one float %2122, +inf
  %2124 = and i1 %2121, %2123
  %2125 = select i1 %2124, float 0.000000e+00, float %2120
  br label %2126

2126:                                             ; preds = %2114, %2107
  %2127 = phi float [ %2125, %2114 ], [ %2112, %2107 ]
  %2128 = extractelement <8 x float> %2047, i64 4
  %2129 = fmul float %2128, %2052
  %2130 = extractelement <8 x float> %281, i64 4
  %2131 = fmul float %2130, %2129
  %2132 = tail call i1 @llvm.is.fpclass.f32(float %2129, /* (sub norm) */ i32 408)
  br i1 %2132, label %2145, label %2133, !prof !4

2133:                                             ; preds = %2126
  %2134 = fpext float %2130 to double
  %2135 = fpext nnan float %2052 to double
  %2136 = fpext float %2128 to double
  %2137 = fmul double %2134, %2135
  %2138 = fmul double %2137, %2136
  %2139 = fptrunc double %2138 to float
  %2140 = fcmp oeq float %2130, 0.000000e+00
  %2141 = tail call float @llvm.fabs.f32(float %2128)
  %2142 = fcmp one float %2141, +inf
  %2143 = and i1 %2140, %2142
  %2144 = select i1 %2143, float 0.000000e+00, float %2139
  br label %2145

2145:                                             ; preds = %2133, %2126
  %2146 = phi float [ %2144, %2133 ], [ %2131, %2126 ]
  %2147 = extractelement <8 x float> %2047, i64 5
  %2148 = fmul float %2147, %2052
  %2149 = extractelement <8 x float> %281, i64 5
  %2150 = fmul float %2149, %2148
  %2151 = tail call i1 @llvm.is.fpclass.f32(float %2148, /* (sub norm) */ i32 408)
  br i1 %2151, label %2164, label %2152, !prof !4

2152:                                             ; preds = %2145
  %2153 = fpext float %2149 to double
  %2154 = fpext nnan float %2052 to double
  %2155 = fpext float %2147 to double
  %2156 = fmul double %2153, %2154
  %2157 = fmul double %2156, %2155
  %2158 = fptrunc double %2157 to float
  %2159 = fcmp oeq float %2149, 0.000000e+00
  %2160 = tail call float @llvm.fabs.f32(float %2147)
  %2161 = fcmp one float %2160, +inf
  %2162 = and i1 %2159, %2161
  %2163 = select i1 %2162, float 0.000000e+00, float %2158
  br label %2164

2164:                                             ; preds = %2152, %2145
  %2165 = phi float [ %2163, %2152 ], [ %2150, %2145 ]
  %2166 = extractelement <8 x float> %2047, i64 6
  %2167 = fmul float %2166, %2052
  %2168 = extractelement <8 x float> %281, i64 6
  %2169 = fmul float %2168, %2167
  %2170 = tail call i1 @llvm.is.fpclass.f32(float %2167, /* (sub norm) */ i32 408)
  br i1 %2170, label %2183, label %2171, !prof !4

2171:                                             ; preds = %2164
  %2172 = fpext float %2168 to double
  %2173 = fpext nnan float %2052 to double
  %2174 = fpext float %2166 to double
  %2175 = fmul double %2172, %2173
  %2176 = fmul double %2175, %2174
  %2177 = fptrunc double %2176 to float
  %2178 = fcmp oeq float %2168, 0.000000e+00
  %2179 = tail call float @llvm.fabs.f32(float %2166)
  %2180 = fcmp one float %2179, +inf
  %2181 = and i1 %2178, %2180
  %2182 = select i1 %2181, float 0.000000e+00, float %2177
  br label %2183

2183:                                             ; preds = %2171, %2164
  %2184 = phi float [ %2182, %2171 ], [ %2169, %2164 ]
  %2185 = extractelement <8 x float> %2047, i64 7
  %2186 = fmul float %2185, %2052
  %2187 = extractelement <8 x float> %281, i64 7
  %2188 = fmul float %2187, %2186
  %2189 = tail call i1 @llvm.is.fpclass.f32(float %2186, /* (sub norm) */ i32 408)
  br i1 %2189, label %2202, label %2190, !prof !4

2190:                                             ; preds = %2183
  %2191 = fpext float %2187 to double
  %2192 = fpext nnan float %2052 to double
  %2193 = fpext float %2185 to double
  %2194 = fmul double %2191, %2192
  %2195 = fmul double %2194, %2193
  %2196 = fptrunc double %2195 to float
  %2197 = fcmp oeq float %2187, 0.000000e+00
  %2198 = tail call float @llvm.fabs.f32(float %2185)
  %2199 = fcmp one float %2198, +inf
  %2200 = and i1 %2197, %2199
  %2201 = select i1 %2200, float 0.000000e+00, float %2196
  br label %2202

2202:                                             ; preds = %2190, %2183
  %2203 = phi float [ %2201, %2190 ], [ %2188, %2183 ]
  %2204 = fptrunc float %2070 to bfloat
  %2205 = getelementptr [2 x i8], ptr addrspace(1) %1285, i64 %1323
  store bfloat %2204, ptr addrspace(1) %2205, align 2
  %2206 = fptrunc float %2089 to bfloat
  %2207 = getelementptr [2 x i8], ptr addrspace(1) %1290, i64 %1323
  store bfloat %2206, ptr addrspace(1) %2207, align 2
  %2208 = fptrunc float %2108 to bfloat
  %2209 = getelementptr [2 x i8], ptr addrspace(1) %1295, i64 %1323
  store bfloat %2208, ptr addrspace(1) %2209, align 2
  %2210 = fptrunc float %2127 to bfloat
  %2211 = getelementptr [2 x i8], ptr addrspace(1) %1300, i64 %1323
  store bfloat %2210, ptr addrspace(1) %2211, align 2
  %2212 = fptrunc float %2146 to bfloat
  %2213 = getelementptr [2 x i8], ptr addrspace(1) %1305, i64 %1323
  store bfloat %2212, ptr addrspace(1) %2213, align 2
  %2214 = fptrunc float %2165 to bfloat
  %2215 = getelementptr [2 x i8], ptr addrspace(1) %1310, i64 %1323
  store bfloat %2214, ptr addrspace(1) %2215, align 2
  %2216 = fptrunc float %2184 to bfloat
  %2217 = getelementptr [2 x i8], ptr addrspace(1) %1315, i64 %1323
  store bfloat %2216, ptr addrspace(1) %2217, align 2
  %2218 = fptrunc float %2203 to bfloat
  %2219 = getelementptr [2 x i8], ptr addrspace(1) %1320, i64 %1323
  store bfloat %2218, ptr addrspace(1) %2219, align 2
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.is.fpclass.f32(float, i32 immarg) #6

attributes #0 = { norecurse nounwind "amdgpu-flat-work-group-size"="256,256" "amdgpu-no-cluster-id-x" "amdgpu-no-cluster-id-y" "amdgpu-no-cluster-id-z" "amdgpu-no-completion-action" "amdgpu-no-default-queue" "amdgpu-no-dispatch-id" "amdgpu-no-dispatch-ptr" "amdgpu-no-flat-scratch-init" "amdgpu-no-heap-ptr" "amdgpu-no-hostcall-ptr" "amdgpu-no-implicitarg-ptr" "amdgpu-no-lds-kernel-id" "amdgpu-no-multigrid-sync-arg" "amdgpu-no-queue-ptr" "amdgpu-no-workgroup-id-x" "amdgpu-no-workgroup-id-y" "amdgpu-no-workgroup-id-z" "amdgpu-no-workitem-id-x" "amdgpu-no-workitem-id-y" "amdgpu-no-workitem-id-z" "amdgpu-no-wwm" "target-cpu"="gfx1201" "target-features"="-cumode,+wavefrontsize32,-wavefrontsize64" "uniform-work-group-size" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #3 = { convergent mustprogress nocallback nofree nounwind willreturn "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #4 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #5 = { convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
!3 = !{}
!4 = !{!"branch_weights", !"expected", i32 2000, i32 1}
