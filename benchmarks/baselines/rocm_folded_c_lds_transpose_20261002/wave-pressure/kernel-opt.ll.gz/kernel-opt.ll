; ModuleID = 'benchmarks/baselines/rocm_folded_c_lds_transpose_20261002/wave-pressure/kernel.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"
target triple = "amdgcn-amd-amdhsa"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal unnamed_addr addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal unnamed_addr addrspace(3) global [5120 x i8] undef

; Function Attrs: norecurse nounwind
define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr nofree readnone captures(none) %0, ptr nofree readonly captures(none) %1, i64 %2, i64 %3, i64 %4, ptr nofree readnone captures(none) %5, ptr nofree readonly captures(none) %6, i64 %7, i64 %8, i64 %9, ptr nofree readnone captures(none) %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr nofree readnone captures(none) %15, ptr nofree readonly captures(none) %16, i64 %17, i64 %18, i64 %19, ptr nofree readnone captures(none) %20, ptr nofree writeonly %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) local_unnamed_addr #0 !reqd_work_group_size !1 {
.lr.ph:
  %28 = addrspacecast ptr %21 to ptr addrspace(1)
  %29 = addrspacecast ptr %16 to ptr addrspace(1)
  %30 = addrspacecast ptr %11 to ptr addrspace(1)
  %31 = addrspacecast ptr %6 to ptr addrspace(1)
  %32 = addrspacecast ptr %1 to ptr addrspace(1)
  %33 = tail call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %34 = zext nneg i32 %33 to i64
  %35 = and i64 %34, 15
  %36 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %37 = sext i32 %36 to i64
  %38 = add i64 %25, 255
  %39 = lshr i64 %38, 8
  %40 = add i64 %26, 63
  %41 = lshr i64 %40, 4
  %42 = and i64 %41, 1152921504606846972
  %.frozen = freeze i64 %42
  %43 = udiv i64 %37, %.frozen
  %44 = shl i64 %43, 2
  %45 = sub i64 %39, %44
  %46 = tail call i64 @llvm.umin.i64(i64 %45, i64 4)
  %47 = mul i64 %43, %.frozen
  %.decomposed = sub i64 %37, %47
  %.frozen59 = freeze i64 %46
  %48 = udiv i64 %.decomposed, %.frozen59
  %49 = mul i64 %48, %.frozen59
  %.decomposed60 = sub i64 %.decomposed, %49
  %50 = add nuw i64 %.decomposed60, %44
  %51 = shl i64 %50, 8
  %52 = shl i64 %48, 6
  %53 = and i64 %34, 192
  %54 = and i64 %34, 32
  %55 = or disjoint i64 %51, %53
  %56 = or disjoint i64 %53, 16
  %57 = or disjoint i64 %51, %56
  %58 = or disjoint i64 %53, 32
  %59 = or disjoint i64 %51, %58
  %60 = or disjoint i64 %53, 48
  %61 = or disjoint i64 %51, %60
  %62 = or disjoint i64 %52, %54
  %63 = or disjoint i64 %54, 16
  %64 = lshr i64 %34, 2
  %65 = shl nuw nsw i64 %34, 4
  %66 = and i64 %65, 48
  %67 = or disjoint i64 %51, %64
  %68 = mul i64 %67, %27
  %69 = mul nuw nsw i64 %64, 80
  %70 = add nuw nsw i64 %69, %66
  %71 = or disjoint i64 %64, 64
  %72 = or disjoint i64 %51, %71
  %73 = mul i64 %72, %27
  %74 = mul nuw nsw i64 %71, 80
  %75 = add nuw nsw i64 %74, %66
  %76 = or disjoint i64 %64, 128
  %77 = or disjoint i64 %51, %76
  %78 = mul i64 %77, %27
  %79 = mul nuw nsw i64 %76, 80
  %80 = add nuw nsw i64 %79, %66
  %81 = or disjoint i64 %64, 192
  %82 = or disjoint i64 %51, %81
  %83 = mul i64 %82, %27
  %84 = mul nuw nsw i64 %81, 80
  %85 = add nuw nsw i64 %84, %66
  %86 = or disjoint i64 %52, %64
  %87 = mul i64 %86, %27
  %88 = icmp ugt i64 %27, 63
  tail call void @llvm.assume(i1 %88)
  %89 = lshr i64 %27, 6
  %90 = add i64 %27, -64
  %91 = getelementptr i8, ptr addrspace(1) %32, i64 %68
  %92 = getelementptr i8, ptr addrspace(1) %91, i64 %66
  %93 = load <16 x i8>, ptr addrspace(1) %92, align 16
  %94 = getelementptr i8, ptr addrspace(1) %32, i64 %73
  %95 = getelementptr i8, ptr addrspace(1) %94, i64 %66
  %96 = load <16 x i8>, ptr addrspace(1) %95, align 16
  %97 = getelementptr i8, ptr addrspace(1) %32, i64 %78
  %98 = getelementptr i8, ptr addrspace(1) %97, i64 %66
  %99 = load <16 x i8>, ptr addrspace(1) %98, align 16
  %100 = getelementptr i8, ptr addrspace(1) %32, i64 %83
  %101 = getelementptr i8, ptr addrspace(1) %100, i64 %66
  %102 = load <16 x i8>, ptr addrspace(1) %101, align 16
  %103 = trunc nuw nsw i64 %70 to i32
  %104 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %103
  store <16 x i8> %93, ptr addrspace(3) %104, align 16
  %105 = trunc nuw nsw i64 %75 to i32
  %106 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %105
  store <16 x i8> %96, ptr addrspace(3) %106, align 16
  %107 = trunc nuw nsw i64 %80 to i32
  %108 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %107
  store <16 x i8> %99, ptr addrspace(3) %108, align 16
  %109 = trunc nuw nsw i64 %85 to i32
  %110 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %109
  store <16 x i8> %102, ptr addrspace(3) %110, align 16
  %111 = getelementptr i8, ptr addrspace(1) %31, i64 %87
  %112 = getelementptr i8, ptr addrspace(1) %111, i64 %66
  %113 = load <16 x i8>, ptr addrspace(1) %112, align 16
  %114 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %103
  store <16 x i8> %113, ptr addrspace(3) %114, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %115 = lshr i64 %34, 1
  %116 = and i64 %115, 8
  %117 = and i64 %34, 207
  %118 = mul nuw nsw i64 %117, 80
  %119 = or disjoint i64 %116, %118
  %120 = trunc nuw nsw i64 %119 to i32
  %121 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %120
  %122 = or disjoint i64 %56, %35
  %123 = mul nuw nsw i64 %122, 80
  %124 = or disjoint i64 %123, %116
  %125 = trunc nuw nsw i64 %124 to i32
  %126 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %125
  %127 = or disjoint i64 %58, %35
  %128 = mul nuw nsw i64 %127, 80
  %129 = or disjoint i64 %128, %116
  %130 = trunc nuw nsw i64 %129 to i32
  %131 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %130
  %132 = or disjoint i64 %60, %35
  %133 = mul nuw nsw i64 %132, 80
  %134 = or disjoint i64 %133, %116
  %135 = trunc nuw nsw i64 %134 to i32
  %136 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %135
  %137 = and i64 %34, 47
  %138 = mul nuw nsw i64 %137, 80
  %139 = or disjoint i64 %116, %138
  %140 = trunc nuw nsw i64 %139 to i32
  %141 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %140
  %142 = or disjoint i64 %63, %35
  %143 = mul nuw nsw i64 %142, 80
  %144 = or disjoint i64 %143, %116
  %145 = trunc nuw nsw i64 %144 to i32
  %146 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %145
  %147 = or disjoint i64 %116, 16
  %148 = add nuw nsw i64 %147, %118
  %149 = trunc nuw nsw i64 %148 to i32
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %149
  %151 = add nuw nsw i64 %123, %147
  %152 = trunc nuw nsw i64 %151 to i32
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %152
  %154 = add nuw nsw i64 %128, %147
  %155 = trunc nuw nsw i64 %154 to i32
  %156 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %155
  %157 = add nuw nsw i64 %133, %147
  %158 = trunc nuw nsw i64 %157 to i32
  %159 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %158
  %160 = add nuw nsw i64 %147, %138
  %161 = trunc nuw nsw i64 %160 to i32
  %162 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %161
  %163 = add nuw nsw i64 %143, %147
  %164 = trunc nuw nsw i64 %163 to i32
  %165 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %164
  %166 = or disjoint i64 %116, 32
  %167 = add nuw nsw i64 %166, %118
  %168 = trunc nuw nsw i64 %167 to i32
  %169 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %168
  %170 = add nuw nsw i64 %123, %166
  %171 = trunc nuw nsw i64 %170 to i32
  %172 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %171
  %173 = add nuw nsw i64 %128, %166
  %174 = trunc nuw nsw i64 %173 to i32
  %175 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %174
  %176 = add nuw nsw i64 %133, %166
  %177 = trunc nuw nsw i64 %176 to i32
  %178 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %177
  %179 = add nuw nsw i64 %166, %138
  %180 = trunc nuw nsw i64 %179 to i32
  %181 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %180
  %182 = add nuw nsw i64 %143, %166
  %183 = trunc nuw nsw i64 %182 to i32
  %184 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %183
  %185 = or disjoint i64 %116, 48
  %186 = add nuw nsw i64 %185, %118
  %187 = trunc nuw nsw i64 %186 to i32
  %188 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %187
  %189 = add nuw nsw i64 %123, %185
  %190 = trunc nuw nsw i64 %189 to i32
  %191 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %190
  %192 = add nuw nsw i64 %128, %185
  %193 = trunc nuw nsw i64 %192 to i32
  %194 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %193
  %195 = add nuw nsw i64 %133, %185
  %196 = trunc nuw nsw i64 %195 to i32
  %197 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %196
  %198 = add nuw nsw i64 %185, %138
  %199 = trunc nuw nsw i64 %198 to i32
  %200 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %199
  %201 = add nuw nsw i64 %143, %185
  %202 = trunc nuw nsw i64 %201 to i32
  %203 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %202
  br label %204

204:                                              ; preds = %.lr.ph, %204
  %205 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %282, %204 ]
  %206 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %281, %204 ]
  %207 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %280, %204 ]
  %208 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %279, %204 ]
  %209 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %278, %204 ]
  %210 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %277, %204 ]
  %211 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %276, %204 ]
  %212 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %275, %204 ]
  %213 = phi i64 [ 0, %.lr.ph ], [ %283, %204 ]
  %214 = shl i64 %213, 6
  %215 = add nuw i64 %214, 64
  %216 = tail call i64 @llvm.umin.i64(i64 %215, i64 %90)
  %217 = getelementptr i8, ptr addrspace(1) %92, i64 %216
  %218 = load <16 x i8>, ptr addrspace(1) %217, align 16
  %219 = getelementptr i8, ptr addrspace(1) %95, i64 %216
  %220 = load <16 x i8>, ptr addrspace(1) %219, align 16
  %221 = getelementptr i8, ptr addrspace(1) %98, i64 %216
  %222 = load <16 x i8>, ptr addrspace(1) %221, align 16
  %223 = getelementptr i8, ptr addrspace(1) %101, i64 %216
  %224 = load <16 x i8>, ptr addrspace(1) %223, align 16
  %225 = getelementptr i8, ptr addrspace(1) %112, i64 %216
  %226 = load <16 x i8>, ptr addrspace(1) %225, align 16
  %227 = load <2 x i32>, ptr addrspace(3) %121, align 8
  %228 = load <2 x i32>, ptr addrspace(3) %126, align 8
  %229 = load <2 x i32>, ptr addrspace(3) %131, align 8
  %230 = load <2 x i32>, ptr addrspace(3) %136, align 8
  %231 = load <2 x i32>, ptr addrspace(3) %141, align 8
  %232 = load <2 x i32>, ptr addrspace(3) %146, align 8
  %233 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %231, <8 x float> %212)
  %234 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %227, <2 x i32> %232, <8 x float> %211)
  %235 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %231, <8 x float> %210)
  %236 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %228, <2 x i32> %232, <8 x float> %209)
  %237 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %231, <8 x float> %208)
  %238 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %232, <8 x float> %207)
  %239 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %230, <2 x i32> %231, <8 x float> %206)
  %240 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %230, <2 x i32> %232, <8 x float> %205)
  %241 = load <2 x i32>, ptr addrspace(3) %150, align 8
  %242 = load <2 x i32>, ptr addrspace(3) %153, align 8
  %243 = load <2 x i32>, ptr addrspace(3) %156, align 8
  %244 = load <2 x i32>, ptr addrspace(3) %159, align 8
  %245 = load <2 x i32>, ptr addrspace(3) %162, align 8
  %246 = load <2 x i32>, ptr addrspace(3) %165, align 8
  %247 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %245, <8 x float> %233)
  %248 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %241, <2 x i32> %246, <8 x float> %234)
  %249 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %245, <8 x float> %235)
  %250 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %246, <8 x float> %236)
  %251 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %245, <8 x float> %237)
  %252 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %246, <8 x float> %238)
  %253 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %244, <2 x i32> %245, <8 x float> %239)
  %254 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %244, <2 x i32> %246, <8 x float> %240)
  %255 = load <2 x i32>, ptr addrspace(3) %169, align 8
  %256 = load <2 x i32>, ptr addrspace(3) %172, align 8
  %257 = load <2 x i32>, ptr addrspace(3) %175, align 8
  %258 = load <2 x i32>, ptr addrspace(3) %178, align 8
  %259 = load <2 x i32>, ptr addrspace(3) %181, align 8
  %260 = load <2 x i32>, ptr addrspace(3) %184, align 8
  %261 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %259, <8 x float> %247)
  %262 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %255, <2 x i32> %260, <8 x float> %248)
  %263 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %259, <8 x float> %249)
  %264 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %256, <2 x i32> %260, <8 x float> %250)
  %265 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %259, <8 x float> %251)
  %266 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %260, <8 x float> %252)
  %267 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %259, <8 x float> %253)
  %268 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %260, <8 x float> %254)
  %269 = load <2 x i32>, ptr addrspace(3) %188, align 8
  %270 = load <2 x i32>, ptr addrspace(3) %191, align 8
  %271 = load <2 x i32>, ptr addrspace(3) %194, align 8
  %272 = load <2 x i32>, ptr addrspace(3) %197, align 8
  %273 = load <2 x i32>, ptr addrspace(3) %200, align 8
  %274 = load <2 x i32>, ptr addrspace(3) %203, align 8
  %275 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %273, <8 x float> %261)
  %276 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %269, <2 x i32> %274, <8 x float> %262)
  %277 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %273, <8 x float> %263)
  %278 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %270, <2 x i32> %274, <8 x float> %264)
  %279 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %273, <8 x float> %265)
  %280 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %274, <8 x float> %266)
  %281 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %272, <2 x i32> %273, <8 x float> %267)
  %282 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %272, <2 x i32> %274, <8 x float> %268)
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  store <16 x i8> %218, ptr addrspace(3) %104, align 16
  store <16 x i8> %220, ptr addrspace(3) %106, align 16
  store <16 x i8> %222, ptr addrspace(3) %108, align 16
  store <16 x i8> %224, ptr addrspace(3) %110, align 16
  store <16 x i8> %226, ptr addrspace(3) %114, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %283 = add nuw nsw i64 %213, 1
  %exitcond.not = icmp eq i64 %283, %89
  br i1 %exitcond.not, label %._crit_edge, label %204

._crit_edge:                                      ; preds = %204
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %284 = or disjoint i64 %55, %116
  %285 = or disjoint i64 %62, %35
  %286 = or disjoint i64 %284, 7
  %287 = icmp ult i64 %285, %26
  %288 = icmp ult i64 %286, %25
  %289 = and i1 %287, %288
  %290 = ptrtoint ptr %11 to i64
  %291 = and i64 %290, 15
  %292 = icmp eq i64 %291, 0
  %293 = and i1 %292, %289
  br i1 %293, label %294, label %300

294:                                              ; preds = %._crit_edge
  %295 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %284
  %296 = load <4 x float>, ptr addrspace(1) %295, align 16
  %297 = getelementptr i8, ptr addrspace(1) %295, i64 16
  %298 = load <4 x float>, ptr addrspace(1) %297, align 16
  %299 = shufflevector <4 x float> %296, <4 x float> %298, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %347

300:                                              ; preds = %._crit_edge
  %301 = icmp slt i64 %284, %25
  %302 = select i1 %301, i64 %284, i64 0
  %303 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %302
  %304 = load float, ptr addrspace(1) %303, align 4, !amdgpu.noclobber !3
  %305 = insertelement <8 x float> poison, float %304, i64 0
  %306 = or disjoint i64 %284, 1
  %307 = icmp slt i64 %306, %25
  %308 = select i1 %307, i64 %306, i64 0
  %309 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %308
  %310 = load float, ptr addrspace(1) %309, align 4, !amdgpu.noclobber !3
  %311 = insertelement <8 x float> %305, float %310, i64 1
  %312 = or disjoint i64 %284, 2
  %313 = icmp slt i64 %312, %25
  %314 = select i1 %313, i64 %312, i64 0
  %315 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %314
  %316 = load float, ptr addrspace(1) %315, align 4, !amdgpu.noclobber !3
  %317 = insertelement <8 x float> %311, float %316, i64 2
  %318 = or disjoint i64 %284, 3
  %319 = icmp slt i64 %318, %25
  %320 = select i1 %319, i64 %318, i64 0
  %321 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %320
  %322 = load float, ptr addrspace(1) %321, align 4, !amdgpu.noclobber !3
  %323 = insertelement <8 x float> %317, float %322, i64 3
  %324 = or disjoint i64 %284, 4
  %325 = icmp slt i64 %324, %25
  %326 = select i1 %325, i64 %324, i64 0
  %327 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %326
  %328 = load float, ptr addrspace(1) %327, align 4, !amdgpu.noclobber !3
  %329 = insertelement <8 x float> %323, float %328, i64 4
  %330 = or disjoint i64 %284, 5
  %331 = icmp slt i64 %330, %25
  %332 = select i1 %331, i64 %330, i64 0
  %333 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %332
  %334 = load float, ptr addrspace(1) %333, align 4, !amdgpu.noclobber !3
  %335 = insertelement <8 x float> %329, float %334, i64 5
  %336 = or disjoint i64 %284, 6
  %337 = icmp slt i64 %336, %25
  %338 = select i1 %337, i64 %336, i64 0
  %339 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %338
  %340 = load float, ptr addrspace(1) %339, align 4, !amdgpu.noclobber !3
  %341 = insertelement <8 x float> %335, float %340, i64 6
  %342 = icmp slt i64 %286, %25
  %343 = select i1 %342, i64 %286, i64 0
  %344 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %343
  %345 = load float, ptr addrspace(1) %344, align 4, !amdgpu.noclobber !3
  %346 = insertelement <8 x float> %341, float %345, i64 7
  br label %347

347:                                              ; preds = %294, %300
  %348 = phi <8 x float> [ %346, %300 ], [ %299, %294 ]
  %349 = icmp slt i64 %285, %26
  %350 = select i1 %349, i64 %285, i64 0
  %351 = extractelement <8 x float> %348, i64 0
  %352 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %350
  %353 = load i8, ptr addrspace(1) %352, align 1
  %354 = zext i8 %353 to i32
  %355 = shl nuw nsw i32 %354, 23
  %356 = bitcast i32 %355 to float
  %357 = fmul float %351, %356
  %358 = extractelement <8 x float> %275, i64 0
  %359 = fmul float %358, %357
  %360 = tail call i1 @llvm.is.fpclass.f32(float %357, /* (sub norm) */ i32 408)
  br i1 %360, label %373, label %361, !prof !4

361:                                              ; preds = %347
  %362 = fpext float %358 to double
  %363 = fpext nnan float %356 to double
  %364 = fpext float %351 to double
  %365 = fmul double %362, %363
  %366 = fmul double %365, %364
  %367 = fptrunc double %366 to float
  %368 = fcmp oeq float %358, 0.000000e+00
  %369 = tail call float @llvm.fabs.f32(float %351)
  %370 = fcmp one float %369, +inf
  %371 = and i1 %368, %370
  %372 = select i1 %371, float 0.000000e+00, float %367
  br label %373

373:                                              ; preds = %361, %347
  %374 = phi float [ %372, %361 ], [ %359, %347 ]
  %375 = extractelement <8 x float> %348, i64 1
  %376 = fmul float %375, %356
  %377 = extractelement <8 x float> %275, i64 1
  %378 = fmul float %377, %376
  %379 = tail call i1 @llvm.is.fpclass.f32(float %376, /* (sub norm) */ i32 408)
  br i1 %379, label %392, label %380, !prof !4

380:                                              ; preds = %373
  %381 = fpext float %377 to double
  %382 = fpext nnan float %356 to double
  %383 = fpext float %375 to double
  %384 = fmul double %381, %382
  %385 = fmul double %384, %383
  %386 = fptrunc double %385 to float
  %387 = fcmp oeq float %377, 0.000000e+00
  %388 = tail call float @llvm.fabs.f32(float %375)
  %389 = fcmp one float %388, +inf
  %390 = and i1 %387, %389
  %391 = select i1 %390, float 0.000000e+00, float %386
  br label %392

392:                                              ; preds = %380, %373
  %393 = phi float [ %391, %380 ], [ %378, %373 ]
  %394 = extractelement <8 x float> %348, i64 2
  %395 = fmul float %394, %356
  %396 = extractelement <8 x float> %275, i64 2
  %397 = fmul float %396, %395
  %398 = tail call i1 @llvm.is.fpclass.f32(float %395, /* (sub norm) */ i32 408)
  br i1 %398, label %411, label %399, !prof !4

399:                                              ; preds = %392
  %400 = fpext float %396 to double
  %401 = fpext nnan float %356 to double
  %402 = fpext float %394 to double
  %403 = fmul double %400, %401
  %404 = fmul double %403, %402
  %405 = fptrunc double %404 to float
  %406 = fcmp oeq float %396, 0.000000e+00
  %407 = tail call float @llvm.fabs.f32(float %394)
  %408 = fcmp one float %407, +inf
  %409 = and i1 %406, %408
  %410 = select i1 %409, float 0.000000e+00, float %405
  br label %411

411:                                              ; preds = %399, %392
  %412 = phi float [ %410, %399 ], [ %397, %392 ]
  %413 = extractelement <8 x float> %348, i64 3
  %414 = fmul float %413, %356
  %415 = extractelement <8 x float> %275, i64 3
  %416 = fmul float %415, %414
  %417 = tail call i1 @llvm.is.fpclass.f32(float %414, /* (sub norm) */ i32 408)
  br i1 %417, label %430, label %418, !prof !4

418:                                              ; preds = %411
  %419 = fpext float %415 to double
  %420 = fpext nnan float %356 to double
  %421 = fpext float %413 to double
  %422 = fmul double %419, %420
  %423 = fmul double %422, %421
  %424 = fptrunc double %423 to float
  %425 = fcmp oeq float %415, 0.000000e+00
  %426 = tail call float @llvm.fabs.f32(float %413)
  %427 = fcmp one float %426, +inf
  %428 = and i1 %425, %427
  %429 = select i1 %428, float 0.000000e+00, float %424
  br label %430

430:                                              ; preds = %418, %411
  %431 = phi float [ %429, %418 ], [ %416, %411 ]
  %432 = extractelement <8 x float> %348, i64 4
  %433 = fmul float %432, %356
  %434 = extractelement <8 x float> %275, i64 4
  %435 = fmul float %434, %433
  %436 = tail call i1 @llvm.is.fpclass.f32(float %433, /* (sub norm) */ i32 408)
  br i1 %436, label %449, label %437, !prof !4

437:                                              ; preds = %430
  %438 = fpext float %434 to double
  %439 = fpext nnan float %356 to double
  %440 = fpext float %432 to double
  %441 = fmul double %438, %439
  %442 = fmul double %441, %440
  %443 = fptrunc double %442 to float
  %444 = fcmp oeq float %434, 0.000000e+00
  %445 = tail call float @llvm.fabs.f32(float %432)
  %446 = fcmp one float %445, +inf
  %447 = and i1 %444, %446
  %448 = select i1 %447, float 0.000000e+00, float %443
  br label %449

449:                                              ; preds = %437, %430
  %450 = phi float [ %448, %437 ], [ %435, %430 ]
  %451 = extractelement <8 x float> %348, i64 5
  %452 = fmul float %451, %356
  %453 = extractelement <8 x float> %275, i64 5
  %454 = fmul float %453, %452
  %455 = tail call i1 @llvm.is.fpclass.f32(float %452, /* (sub norm) */ i32 408)
  br i1 %455, label %468, label %456, !prof !4

456:                                              ; preds = %449
  %457 = fpext float %453 to double
  %458 = fpext nnan float %356 to double
  %459 = fpext float %451 to double
  %460 = fmul double %457, %458
  %461 = fmul double %460, %459
  %462 = fptrunc double %461 to float
  %463 = fcmp oeq float %453, 0.000000e+00
  %464 = tail call float @llvm.fabs.f32(float %451)
  %465 = fcmp one float %464, +inf
  %466 = and i1 %463, %465
  %467 = select i1 %466, float 0.000000e+00, float %462
  br label %468

468:                                              ; preds = %456, %449
  %469 = phi float [ %467, %456 ], [ %454, %449 ]
  %470 = extractelement <8 x float> %348, i64 6
  %471 = fmul float %470, %356
  %472 = extractelement <8 x float> %275, i64 6
  %473 = fmul float %472, %471
  %474 = tail call i1 @llvm.is.fpclass.f32(float %471, /* (sub norm) */ i32 408)
  br i1 %474, label %487, label %475, !prof !4

475:                                              ; preds = %468
  %476 = fpext float %472 to double
  %477 = fpext nnan float %356 to double
  %478 = fpext float %470 to double
  %479 = fmul double %476, %477
  %480 = fmul double %479, %478
  %481 = fptrunc double %480 to float
  %482 = fcmp oeq float %472, 0.000000e+00
  %483 = tail call float @llvm.fabs.f32(float %470)
  %484 = fcmp one float %483, +inf
  %485 = and i1 %482, %484
  %486 = select i1 %485, float 0.000000e+00, float %481
  br label %487

487:                                              ; preds = %475, %468
  %488 = phi float [ %486, %475 ], [ %473, %468 ]
  %489 = extractelement <8 x float> %348, i64 7
  %490 = fmul float %489, %356
  %491 = extractelement <8 x float> %275, i64 7
  %492 = fmul float %491, %490
  %493 = tail call i1 @llvm.is.fpclass.f32(float %490, /* (sub norm) */ i32 408)
  br i1 %493, label %506, label %494, !prof !4

494:                                              ; preds = %487
  %495 = fpext float %491 to double
  %496 = fpext nnan float %356 to double
  %497 = fpext float %489 to double
  %498 = fmul double %495, %496
  %499 = fmul double %498, %497
  %500 = fptrunc double %499 to float
  %501 = fcmp oeq float %491, 0.000000e+00
  %502 = tail call float @llvm.fabs.f32(float %489)
  %503 = fcmp one float %502, +inf
  %504 = and i1 %501, %503
  %505 = select i1 %504, float 0.000000e+00, float %500
  br label %506

506:                                              ; preds = %494, %487
  %507 = phi float [ %505, %494 ], [ %492, %487 ]
  %508 = lshr i64 %34, 1
  %509 = and i64 %508, 112
  %510 = or disjoint i64 %116, %509
  %511 = mul nuw nsw i64 %510, 40
  %512 = or disjoint i64 %511, %35
  %513 = trunc nuw nsw i64 %512 to i32
  %514 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %513
  store float %374, ptr addrspace(3) %514, align 4
  %515 = or disjoint i64 %116, 1
  %516 = or disjoint i64 %515, %509
  %517 = mul nuw nsw i64 %516, 40
  %518 = add nuw nsw i64 %517, %35
  %519 = trunc nuw nsw i64 %518 to i32
  %520 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %519
  store float %393, ptr addrspace(3) %520, align 4
  %521 = or disjoint i64 %116, 2
  %522 = or disjoint i64 %521, %509
  %523 = mul nuw nsw i64 %522, 40
  %524 = or disjoint i64 %523, %35
  %525 = trunc nuw nsw i64 %524 to i32
  %526 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %525
  store float %412, ptr addrspace(3) %526, align 4
  %527 = or disjoint i64 %116, 3
  %528 = or disjoint i64 %527, %509
  %529 = mul nuw nsw i64 %528, 40
  %530 = add nuw nsw i64 %529, %35
  %531 = trunc nuw nsw i64 %530 to i32
  %532 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %531
  store float %431, ptr addrspace(3) %532, align 4
  %533 = or disjoint i64 %116, 4
  %534 = or disjoint i64 %533, %509
  %535 = mul nuw nsw i64 %534, 40
  %536 = or disjoint i64 %535, %35
  %537 = trunc nuw nsw i64 %536 to i32
  %538 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %537
  store float %450, ptr addrspace(3) %538, align 4
  %539 = or disjoint i64 %116, 5
  %540 = or disjoint i64 %539, %509
  %541 = mul nuw nsw i64 %540, 40
  %542 = add nuw nsw i64 %541, %35
  %543 = trunc nuw nsw i64 %542 to i32
  %544 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %543
  store float %469, ptr addrspace(3) %544, align 4
  %545 = or disjoint i64 %116, 6
  %546 = or disjoint i64 %545, %509
  %547 = mul nuw nsw i64 %546, 40
  %548 = or disjoint i64 %547, %35
  %549 = trunc nuw nsw i64 %548 to i32
  %550 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %549
  store float %488, ptr addrspace(3) %550, align 4
  %551 = or disjoint i64 %116, 7
  %552 = or disjoint i64 %551, %509
  %553 = mul nuw nsw i64 %552, 40
  %554 = add nuw nsw i64 %553, %35
  %555 = trunc nuw nsw i64 %554 to i32
  %556 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %555
  store float %507, ptr addrspace(3) %556, align 4
  %557 = or disjoint i64 %63, %35
  %558 = or disjoint i64 %557, %52
  %559 = icmp ult i64 %558, %26
  %560 = and i1 %559, %288
  %561 = and i1 %292, %560
  br i1 %561, label %562, label %568

562:                                              ; preds = %506
  %563 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %284
  %564 = load <4 x float>, ptr addrspace(1) %563, align 16
  %565 = getelementptr i8, ptr addrspace(1) %563, i64 16
  %566 = load <4 x float>, ptr addrspace(1) %565, align 16
  %567 = shufflevector <4 x float> %564, <4 x float> %566, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %616

568:                                              ; preds = %506
  %569 = icmp slt i64 %284, %25
  %570 = select i1 %569, i64 %284, i64 0
  %571 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %570
  %572 = load float, ptr addrspace(1) %571, align 4, !amdgpu.noclobber !3
  %573 = insertelement <8 x float> poison, float %572, i64 0
  %574 = or disjoint i64 %55, %515
  %575 = icmp slt i64 %574, %25
  %576 = select i1 %575, i64 %574, i64 0
  %577 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %576
  %578 = load float, ptr addrspace(1) %577, align 4, !amdgpu.noclobber !3
  %579 = insertelement <8 x float> %573, float %578, i64 1
  %580 = or disjoint i64 %55, %521
  %581 = icmp slt i64 %580, %25
  %582 = select i1 %581, i64 %580, i64 0
  %583 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %582
  %584 = load float, ptr addrspace(1) %583, align 4, !amdgpu.noclobber !3
  %585 = insertelement <8 x float> %579, float %584, i64 2
  %586 = or disjoint i64 %55, %527
  %587 = icmp slt i64 %586, %25
  %588 = select i1 %587, i64 %586, i64 0
  %589 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %588
  %590 = load float, ptr addrspace(1) %589, align 4, !amdgpu.noclobber !3
  %591 = insertelement <8 x float> %585, float %590, i64 3
  %592 = or disjoint i64 %55, %533
  %593 = icmp slt i64 %592, %25
  %594 = select i1 %593, i64 %592, i64 0
  %595 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %594
  %596 = load float, ptr addrspace(1) %595, align 4, !amdgpu.noclobber !3
  %597 = insertelement <8 x float> %591, float %596, i64 4
  %598 = or disjoint i64 %55, %539
  %599 = icmp slt i64 %598, %25
  %600 = select i1 %599, i64 %598, i64 0
  %601 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %600
  %602 = load float, ptr addrspace(1) %601, align 4, !amdgpu.noclobber !3
  %603 = insertelement <8 x float> %597, float %602, i64 5
  %604 = or disjoint i64 %55, %545
  %605 = icmp slt i64 %604, %25
  %606 = select i1 %605, i64 %604, i64 0
  %607 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %606
  %608 = load float, ptr addrspace(1) %607, align 4, !amdgpu.noclobber !3
  %609 = insertelement <8 x float> %603, float %608, i64 6
  %610 = or disjoint i64 %55, %551
  %611 = icmp slt i64 %610, %25
  %612 = select i1 %611, i64 %610, i64 0
  %613 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %612
  %614 = load float, ptr addrspace(1) %613, align 4, !amdgpu.noclobber !3
  %615 = insertelement <8 x float> %609, float %614, i64 7
  br label %616

616:                                              ; preds = %562, %568
  %617 = phi <8 x float> [ %615, %568 ], [ %567, %562 ]
  %618 = icmp slt i64 %558, %26
  %619 = select i1 %618, i64 %558, i64 0
  %620 = extractelement <8 x float> %617, i64 0
  %621 = getelementptr inbounds i8, ptr addrspace(1) %29, i64 %619
  %622 = load i8, ptr addrspace(1) %621, align 1
  %623 = zext i8 %622 to i32
  %624 = shl nuw nsw i32 %623, 23
  %625 = bitcast i32 %624 to float
  %626 = fmul float %620, %625
  %627 = extractelement <8 x float> %276, i64 0
  %628 = fmul float %627, %626
  %629 = tail call i1 @llvm.is.fpclass.f32(float %626, /* (sub norm) */ i32 408)
  br i1 %629, label %642, label %630, !prof !4

630:                                              ; preds = %616
  %631 = fpext float %627 to double
  %632 = fpext nnan float %625 to double
  %633 = fpext float %620 to double
  %634 = fmul double %631, %632
  %635 = fmul double %634, %633
  %636 = fptrunc double %635 to float
  %637 = fcmp oeq float %627, 0.000000e+00
  %638 = tail call float @llvm.fabs.f32(float %620)
  %639 = fcmp one float %638, +inf
  %640 = and i1 %637, %639
  %641 = select i1 %640, float 0.000000e+00, float %636
  br label %642

642:                                              ; preds = %630, %616
  %643 = phi float [ %641, %630 ], [ %628, %616 ]
  %644 = extractelement <8 x float> %617, i64 1
  %645 = fmul float %644, %625
  %646 = extractelement <8 x float> %276, i64 1
  %647 = fmul float %646, %645
  %648 = tail call i1 @llvm.is.fpclass.f32(float %645, /* (sub norm) */ i32 408)
  br i1 %648, label %661, label %649, !prof !4

649:                                              ; preds = %642
  %650 = fpext float %646 to double
  %651 = fpext nnan float %625 to double
  %652 = fpext float %644 to double
  %653 = fmul double %650, %651
  %654 = fmul double %653, %652
  %655 = fptrunc double %654 to float
  %656 = fcmp oeq float %646, 0.000000e+00
  %657 = tail call float @llvm.fabs.f32(float %644)
  %658 = fcmp one float %657, +inf
  %659 = and i1 %656, %658
  %660 = select i1 %659, float 0.000000e+00, float %655
  br label %661

661:                                              ; preds = %649, %642
  %662 = phi float [ %660, %649 ], [ %647, %642 ]
  %663 = extractelement <8 x float> %617, i64 2
  %664 = fmul float %663, %625
  %665 = extractelement <8 x float> %276, i64 2
  %666 = fmul float %665, %664
  %667 = tail call i1 @llvm.is.fpclass.f32(float %664, /* (sub norm) */ i32 408)
  br i1 %667, label %680, label %668, !prof !4

668:                                              ; preds = %661
  %669 = fpext float %665 to double
  %670 = fpext nnan float %625 to double
  %671 = fpext float %663 to double
  %672 = fmul double %669, %670
  %673 = fmul double %672, %671
  %674 = fptrunc double %673 to float
  %675 = fcmp oeq float %665, 0.000000e+00
  %676 = tail call float @llvm.fabs.f32(float %663)
  %677 = fcmp one float %676, +inf
  %678 = and i1 %675, %677
  %679 = select i1 %678, float 0.000000e+00, float %674
  br label %680

680:                                              ; preds = %668, %661
  %681 = phi float [ %679, %668 ], [ %666, %661 ]
  %682 = extractelement <8 x float> %617, i64 3
  %683 = fmul float %682, %625
  %684 = extractelement <8 x float> %276, i64 3
  %685 = fmul float %684, %683
  %686 = tail call i1 @llvm.is.fpclass.f32(float %683, /* (sub norm) */ i32 408)
  br i1 %686, label %699, label %687, !prof !4

687:                                              ; preds = %680
  %688 = fpext float %684 to double
  %689 = fpext nnan float %625 to double
  %690 = fpext float %682 to double
  %691 = fmul double %688, %689
  %692 = fmul double %691, %690
  %693 = fptrunc double %692 to float
  %694 = fcmp oeq float %684, 0.000000e+00
  %695 = tail call float @llvm.fabs.f32(float %682)
  %696 = fcmp one float %695, +inf
  %697 = and i1 %694, %696
  %698 = select i1 %697, float 0.000000e+00, float %693
  br label %699

699:                                              ; preds = %687, %680
  %700 = phi float [ %698, %687 ], [ %685, %680 ]
  %701 = extractelement <8 x float> %617, i64 4
  %702 = fmul float %701, %625
  %703 = extractelement <8 x float> %276, i64 4
  %704 = fmul float %703, %702
  %705 = tail call i1 @llvm.is.fpclass.f32(float %702, /* (sub norm) */ i32 408)
  br i1 %705, label %718, label %706, !prof !4

706:                                              ; preds = %699
  %707 = fpext float %703 to double
  %708 = fpext nnan float %625 to double
  %709 = fpext float %701 to double
  %710 = fmul double %707, %708
  %711 = fmul double %710, %709
  %712 = fptrunc double %711 to float
  %713 = fcmp oeq float %703, 0.000000e+00
  %714 = tail call float @llvm.fabs.f32(float %701)
  %715 = fcmp one float %714, +inf
  %716 = and i1 %713, %715
  %717 = select i1 %716, float 0.000000e+00, float %712
  br label %718

718:                                              ; preds = %706, %699
  %719 = phi float [ %717, %706 ], [ %704, %699 ]
  %720 = extractelement <8 x float> %617, i64 5
  %721 = fmul float %720, %625
  %722 = extractelement <8 x float> %276, i64 5
  %723 = fmul float %722, %721
  %724 = tail call i1 @llvm.is.fpclass.f32(float %721, /* (sub norm) */ i32 408)
  br i1 %724, label %737, label %725, !prof !4

725:                                              ; preds = %718
  %726 = fpext float %722 to double
  %727 = fpext nnan float %625 to double
  %728 = fpext float %720 to double
  %729 = fmul double %726, %727
  %730 = fmul double %729, %728
  %731 = fptrunc double %730 to float
  %732 = fcmp oeq float %722, 0.000000e+00
  %733 = tail call float @llvm.fabs.f32(float %720)
  %734 = fcmp one float %733, +inf
  %735 = and i1 %732, %734
  %736 = select i1 %735, float 0.000000e+00, float %731
  br label %737

737:                                              ; preds = %725, %718
  %738 = phi float [ %736, %725 ], [ %723, %718 ]
  %739 = extractelement <8 x float> %617, i64 6
  %740 = fmul float %739, %625
  %741 = extractelement <8 x float> %276, i64 6
  %742 = fmul float %741, %740
  %743 = tail call i1 @llvm.is.fpclass.f32(float %740, /* (sub norm) */ i32 408)
  br i1 %743, label %756, label %744, !prof !4

744:                                              ; preds = %737
  %745 = fpext float %741 to double
  %746 = fpext nnan float %625 to double
  %747 = fpext float %739 to double
  %748 = fmul double %745, %746
  %749 = fmul double %748, %747
  %750 = fptrunc double %749 to float
  %751 = fcmp oeq float %741, 0.000000e+00
  %752 = tail call float @llvm.fabs.f32(float %739)
  %753 = fcmp one float %752, +inf
  %754 = and i1 %751, %753
  %755 = select i1 %754, float 0.000000e+00, float %750
  br label %756

756:                                              ; preds = %744, %737
  %757 = phi float [ %755, %744 ], [ %742, %737 ]
  %758 = extractelement <8 x float> %617, i64 7
  %759 = fmul float %758, %625
  %760 = extractelement <8 x float> %276, i64 7
  %761 = fmul float %760, %759
  %762 = tail call i1 @llvm.is.fpclass.f32(float %759, /* (sub norm) */ i32 408)
  br i1 %762, label %775, label %763, !prof !4

763:                                              ; preds = %756
  %764 = fpext float %760 to double
  %765 = fpext nnan float %625 to double
  %766 = fpext float %758 to double
  %767 = fmul double %764, %765
  %768 = fmul double %767, %766
  %769 = fptrunc double %768 to float
  %770 = fcmp oeq float %760, 0.000000e+00
  %771 = tail call float @llvm.fabs.f32(float %758)
  %772 = fcmp one float %771, +inf
  %773 = and i1 %770, %772
  %774 = select i1 %773, float 0.000000e+00, float %769
  br label %775

775:                                              ; preds = %763, %756
  %776 = phi float [ %774, %763 ], [ %761, %756 ]
  %777 = or disjoint i64 %35, 16
  %778 = or disjoint i64 %511, %777
  %779 = trunc nuw nsw i64 %778 to i32
  %780 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %779
  store float %643, ptr addrspace(3) %780, align 4
  %781 = add nuw nsw i64 %517, %777
  %782 = trunc nuw nsw i64 %781 to i32
  %783 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %782
  store float %662, ptr addrspace(3) %783, align 4
  %784 = add nuw nsw i64 %523, %777
  %785 = trunc nuw nsw i64 %784 to i32
  %786 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %785
  store float %681, ptr addrspace(3) %786, align 4
  %787 = add nuw nsw i64 %529, %777
  %788 = trunc nuw nsw i64 %787 to i32
  %789 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %788
  store float %700, ptr addrspace(3) %789, align 4
  %790 = or disjoint i64 %535, %777
  %791 = trunc nuw nsw i64 %790 to i32
  %792 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %791
  store float %719, ptr addrspace(3) %792, align 4
  %793 = add nuw nsw i64 %541, %777
  %794 = trunc nuw nsw i64 %793 to i32
  %795 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %794
  store float %738, ptr addrspace(3) %795, align 4
  %796 = add nuw nsw i64 %547, %777
  %797 = trunc nuw nsw i64 %796 to i32
  %798 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %797
  store float %757, ptr addrspace(3) %798, align 4
  %799 = add nuw nsw i64 %553, %777
  %800 = trunc nuw nsw i64 %799 to i32
  %801 = getelementptr inbounds nuw [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %800
  store float %776, ptr addrspace(3) %801, align 4
  tail call void @llvm.amdgcn.wave.barrier()
  %802 = shl nuw nsw i64 %34, 3
  %803 = lshr i64 %34, 2
  %804 = and i64 %803, 7
  %805 = and i64 %802, 24
  %806 = or disjoint i64 %509, %804
  %807 = or disjoint i64 %804, %53
  %808 = or disjoint i64 %807, %51
  %809 = or disjoint i64 %805, %54
  %810 = or disjoint i64 %809, %52
  %811 = mul nuw nsw i64 %806, 40
  %812 = add nuw nsw i64 %811, %805
  %813 = trunc nuw nsw i64 %812 to i32
  %814 = getelementptr [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %813
  %815 = load <8 x float>, ptr addrspace(3) %814, align 16
  %816 = fptrunc <8 x float> %815 to <8 x bfloat>
  %817 = mul i64 %808, %26
  %818 = add i64 %817, %810
  %819 = icmp ult i64 %808, %25
  %820 = or disjoint i64 %810, 7
  %821 = icmp ult i64 %820, %26
  %822 = and i1 %819, %821
  br i1 %822, label %823, label %825

823:                                              ; preds = %775
  %824 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %818
  store <8 x bfloat> %816, ptr addrspace(1) %824, align 2
  br label %879

825:                                              ; preds = %775
  %826 = icmp ult i64 %810, %26
  %827 = and i1 %819, %826
  br i1 %827, label %828, label %831

828:                                              ; preds = %825
  %829 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %818
  %830 = extractelement <8 x bfloat> %816, i64 0
  store bfloat %830, ptr addrspace(1) %829, align 2
  br label %831

831:                                              ; preds = %828, %825
  %832 = or disjoint i64 %810, 1
  %833 = icmp ult i64 %832, %26
  %834 = and i1 %819, %833
  br i1 %834, label %835, label %839

835:                                              ; preds = %831
  %836 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %818
  %837 = getelementptr i8, ptr addrspace(1) %836, i64 2
  %838 = extractelement <8 x bfloat> %816, i64 1
  store bfloat %838, ptr addrspace(1) %837, align 2
  br label %839

839:                                              ; preds = %835, %831
  %840 = or disjoint i64 %810, 2
  %841 = icmp ult i64 %840, %26
  %842 = and i1 %819, %841
  br i1 %842, label %843, label %847

843:                                              ; preds = %839
  %844 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %818
  %845 = getelementptr i8, ptr addrspace(1) %844, i64 4
  %846 = extractelement <8 x bfloat> %816, i64 2
  store bfloat %846, ptr addrspace(1) %845, align 2
  br label %847

847:                                              ; preds = %843, %839
  %848 = or disjoint i64 %810, 3
  %849 = icmp ult i64 %848, %26
  %850 = and i1 %819, %849
  br i1 %850, label %851, label %855

851:                                              ; preds = %847
  %852 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %818
  %853 = getelementptr i8, ptr addrspace(1) %852, i64 6
  %854 = extractelement <8 x bfloat> %816, i64 3
  store bfloat %854, ptr addrspace(1) %853, align 2
  br label %855

855:                                              ; preds = %851, %847
  %856 = or disjoint i64 %810, 4
  %857 = icmp ult i64 %856, %26
  %858 = and i1 %819, %857
  br i1 %858, label %859, label %863

859:                                              ; preds = %855
  %860 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %818
  %861 = getelementptr i8, ptr addrspace(1) %860, i64 8
  %862 = extractelement <8 x bfloat> %816, i64 4
  store bfloat %862, ptr addrspace(1) %861, align 2
  br label %863

863:                                              ; preds = %859, %855
  %864 = or disjoint i64 %810, 5
  %865 = icmp ult i64 %864, %26
  %866 = and i1 %819, %865
  br i1 %866, label %867, label %871

867:                                              ; preds = %863
  %868 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %818
  %869 = getelementptr i8, ptr addrspace(1) %868, i64 10
  %870 = extractelement <8 x bfloat> %816, i64 5
  store bfloat %870, ptr addrspace(1) %869, align 2
  br label %871

871:                                              ; preds = %867, %863
  %872 = or disjoint i64 %810, 6
  %873 = icmp ult i64 %872, %26
  %874 = and i1 %819, %873
  br i1 %874, label %875, label %879

875:                                              ; preds = %871
  %876 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %818
  %877 = getelementptr i8, ptr addrspace(1) %876, i64 12
  %878 = extractelement <8 x bfloat> %816, i64 6
  store bfloat %878, ptr addrspace(1) %877, align 2
  br label %879

879:                                              ; preds = %871, %875, %823
  %880 = or disjoint i64 %804, 8
  %881 = or disjoint i64 %880, %509
  %882 = or disjoint i64 %880, %53
  %883 = or disjoint i64 %882, %51
  %884 = mul nuw nsw i64 %881, 40
  %885 = add nuw nsw i64 %884, %805
  %886 = trunc nuw nsw i64 %885 to i32
  %887 = getelementptr [4 x i8], ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %886
  %888 = load <8 x float>, ptr addrspace(3) %887, align 16
  %889 = fptrunc <8 x float> %888 to <8 x bfloat>
  %890 = mul i64 %883, %26
  %891 = add i64 %890, %810
  %892 = icmp ult i64 %883, %25
  %893 = and i1 %892, %821
  br i1 %893, label %894, label %896

894:                                              ; preds = %879
  %895 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %891
  store <8 x bfloat> %889, ptr addrspace(1) %895, align 2
  br label %950

896:                                              ; preds = %879
  %897 = icmp ult i64 %810, %26
  %898 = and i1 %892, %897
  br i1 %898, label %899, label %902

899:                                              ; preds = %896
  %900 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %891
  %901 = extractelement <8 x bfloat> %889, i64 0
  store bfloat %901, ptr addrspace(1) %900, align 2
  br label %902

902:                                              ; preds = %899, %896
  %903 = or disjoint i64 %810, 1
  %904 = icmp ult i64 %903, %26
  %905 = and i1 %892, %904
  br i1 %905, label %906, label %910

906:                                              ; preds = %902
  %907 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %891
  %908 = getelementptr i8, ptr addrspace(1) %907, i64 2
  %909 = extractelement <8 x bfloat> %889, i64 1
  store bfloat %909, ptr addrspace(1) %908, align 2
  br label %910

910:                                              ; preds = %906, %902
  %911 = or disjoint i64 %810, 2
  %912 = icmp ult i64 %911, %26
  %913 = and i1 %892, %912
  br i1 %913, label %914, label %918

914:                                              ; preds = %910
  %915 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %891
  %916 = getelementptr i8, ptr addrspace(1) %915, i64 4
  %917 = extractelement <8 x bfloat> %889, i64 2
  store bfloat %917, ptr addrspace(1) %916, align 2
  br label %918

918:                                              ; preds = %914, %910
  %919 = or disjoint i64 %810, 3
  %920 = icmp ult i64 %919, %26
  %921 = and i1 %892, %920
  br i1 %921, label %922, label %926

922:                                              ; preds = %918
  %923 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %891
  %924 = getelementptr i8, ptr addrspace(1) %923, i64 6
  %925 = extractelement <8 x bfloat> %889, i64 3
  store bfloat %925, ptr addrspace(1) %924, align 2
  br label %926

926:                                              ; preds = %922, %918
  %927 = or disjoint i64 %810, 4
  %928 = icmp ult i64 %927, %26
  %929 = and i1 %892, %928
  br i1 %929, label %930, label %934

930:                                              ; preds = %926
  %931 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %891
  %932 = getelementptr i8, ptr addrspace(1) %931, i64 8
  %933 = extractelement <8 x bfloat> %889, i64 4
  store bfloat %933, ptr addrspace(1) %932, align 2
  br label %934

934:                                              ; preds = %930, %926
  %935 = or disjoint i64 %810, 5
  %936 = icmp ult i64 %935, %26
  %937 = and i1 %892, %936
  br i1 %937, label %938, label %942

938:                                              ; preds = %934
  %939 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %891
  %940 = getelementptr i8, ptr addrspace(1) %939, i64 10
  %941 = extractelement <8 x bfloat> %889, i64 5
  store bfloat %941, ptr addrspace(1) %940, align 2
  br label %942

942:                                              ; preds = %938, %934
  %943 = or disjoint i64 %810, 6
  %944 = icmp ult i64 %943, %26
  %945 = and i1 %892, %944
  br i1 %945, label %946, label %950

946:                                              ; preds = %942
  %947 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %891
  %948 = getelementptr i8, ptr addrspace(1) %947, i64 12
  %949 = extractelement <8 x bfloat> %889, i64 6
  store bfloat %949, ptr addrspace(1) %948, align 2
  br label %950

950:                                              ; preds = %942, %946, %894
  tail call void @llvm.amdgcn.wave.barrier()
  %951 = or disjoint i64 %57, %116
  %952 = or disjoint i64 %951, 7
  %953 = icmp ult i64 %952, %25
  %954 = and i1 %287, %953
  %955 = and i1 %292, %954
  br i1 %955, label %956, label %962

956:                                              ; preds = %950
  %957 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %951
  %958 = load <4 x float>, ptr addrspace(1) %957, align 16
  %959 = getelementptr i8, ptr addrspace(1) %957, i64 16
  %960 = load <4 x float>, ptr addrspace(1) %959, align 16
  %961 = shufflevector <4 x float> %958, <4 x float> %960, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1010

962:                                              ; preds = %950
  %963 = icmp slt i64 %951, %25
  %964 = select i1 %963, i64 %951, i64 0
  %965 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %964
  %966 = load float, ptr addrspace(1) %965, align 4
  %967 = insertelement <8 x float> poison, float %966, i64 0
  %968 = or disjoint i64 %57, %515
  %969 = icmp slt i64 %968, %25
  %970 = select i1 %969, i64 %968, i64 0
  %971 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %970
  %972 = load float, ptr addrspace(1) %971, align 4
  %973 = insertelement <8 x float> %967, float %972, i64 1
  %974 = or disjoint i64 %57, %521
  %975 = icmp slt i64 %974, %25
  %976 = select i1 %975, i64 %974, i64 0
  %977 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %976
  %978 = load float, ptr addrspace(1) %977, align 4
  %979 = insertelement <8 x float> %973, float %978, i64 2
  %980 = or disjoint i64 %57, %527
  %981 = icmp slt i64 %980, %25
  %982 = select i1 %981, i64 %980, i64 0
  %983 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %982
  %984 = load float, ptr addrspace(1) %983, align 4
  %985 = insertelement <8 x float> %979, float %984, i64 3
  %986 = or disjoint i64 %57, %533
  %987 = icmp slt i64 %986, %25
  %988 = select i1 %987, i64 %986, i64 0
  %989 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %988
  %990 = load float, ptr addrspace(1) %989, align 4
  %991 = insertelement <8 x float> %985, float %990, i64 4
  %992 = or disjoint i64 %57, %539
  %993 = icmp slt i64 %992, %25
  %994 = select i1 %993, i64 %992, i64 0
  %995 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %994
  %996 = load float, ptr addrspace(1) %995, align 4
  %997 = insertelement <8 x float> %991, float %996, i64 5
  %998 = or disjoint i64 %57, %545
  %999 = icmp slt i64 %998, %25
  %1000 = select i1 %999, i64 %998, i64 0
  %1001 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1000
  %1002 = load float, ptr addrspace(1) %1001, align 4
  %1003 = insertelement <8 x float> %997, float %1002, i64 6
  %1004 = or disjoint i64 %57, %551
  %1005 = icmp slt i64 %1004, %25
  %1006 = select i1 %1005, i64 %1004, i64 0
  %1007 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1006
  %1008 = load float, ptr addrspace(1) %1007, align 4
  %1009 = insertelement <8 x float> %1003, float %1008, i64 7
  br label %1010

1010:                                             ; preds = %956, %962
  %1011 = phi <8 x float> [ %1009, %962 ], [ %961, %956 ]
  %1012 = extractelement <8 x float> %1011, i64 0
  %1013 = load i8, ptr addrspace(1) %352, align 1
  %1014 = zext i8 %1013 to i32
  %1015 = shl nuw nsw i32 %1014, 23
  %1016 = bitcast i32 %1015 to float
  %1017 = fmul float %1012, %1016
  %1018 = extractelement <8 x float> %277, i64 0
  %1019 = fmul float %1018, %1017
  %1020 = tail call i1 @llvm.is.fpclass.f32(float %1017, /* (sub norm) */ i32 408)
  br i1 %1020, label %1033, label %1021, !prof !4

1021:                                             ; preds = %1010
  %1022 = fpext float %1018 to double
  %1023 = fpext nnan float %1016 to double
  %1024 = fpext float %1012 to double
  %1025 = fmul double %1022, %1023
  %1026 = fmul double %1025, %1024
  %1027 = fptrunc double %1026 to float
  %1028 = fcmp oeq float %1018, 0.000000e+00
  %1029 = tail call float @llvm.fabs.f32(float %1012)
  %1030 = fcmp one float %1029, +inf
  %1031 = and i1 %1028, %1030
  %1032 = select i1 %1031, float 0.000000e+00, float %1027
  br label %1033

1033:                                             ; preds = %1021, %1010
  %1034 = phi float [ %1032, %1021 ], [ %1019, %1010 ]
  %1035 = extractelement <8 x float> %1011, i64 1
  %1036 = fmul float %1035, %1016
  %1037 = extractelement <8 x float> %277, i64 1
  %1038 = fmul float %1037, %1036
  %1039 = tail call i1 @llvm.is.fpclass.f32(float %1036, /* (sub norm) */ i32 408)
  br i1 %1039, label %1052, label %1040, !prof !4

1040:                                             ; preds = %1033
  %1041 = fpext float %1037 to double
  %1042 = fpext nnan float %1016 to double
  %1043 = fpext float %1035 to double
  %1044 = fmul double %1041, %1042
  %1045 = fmul double %1044, %1043
  %1046 = fptrunc double %1045 to float
  %1047 = fcmp oeq float %1037, 0.000000e+00
  %1048 = tail call float @llvm.fabs.f32(float %1035)
  %1049 = fcmp one float %1048, +inf
  %1050 = and i1 %1047, %1049
  %1051 = select i1 %1050, float 0.000000e+00, float %1046
  br label %1052

1052:                                             ; preds = %1040, %1033
  %1053 = phi float [ %1051, %1040 ], [ %1038, %1033 ]
  %1054 = extractelement <8 x float> %1011, i64 2
  %1055 = fmul float %1054, %1016
  %1056 = extractelement <8 x float> %277, i64 2
  %1057 = fmul float %1056, %1055
  %1058 = tail call i1 @llvm.is.fpclass.f32(float %1055, /* (sub norm) */ i32 408)
  br i1 %1058, label %1071, label %1059, !prof !4

1059:                                             ; preds = %1052
  %1060 = fpext float %1056 to double
  %1061 = fpext nnan float %1016 to double
  %1062 = fpext float %1054 to double
  %1063 = fmul double %1060, %1061
  %1064 = fmul double %1063, %1062
  %1065 = fptrunc double %1064 to float
  %1066 = fcmp oeq float %1056, 0.000000e+00
  %1067 = tail call float @llvm.fabs.f32(float %1054)
  %1068 = fcmp one float %1067, +inf
  %1069 = and i1 %1066, %1068
  %1070 = select i1 %1069, float 0.000000e+00, float %1065
  br label %1071

1071:                                             ; preds = %1059, %1052
  %1072 = phi float [ %1070, %1059 ], [ %1057, %1052 ]
  %1073 = extractelement <8 x float> %1011, i64 3
  %1074 = fmul float %1073, %1016
  %1075 = extractelement <8 x float> %277, i64 3
  %1076 = fmul float %1075, %1074
  %1077 = tail call i1 @llvm.is.fpclass.f32(float %1074, /* (sub norm) */ i32 408)
  br i1 %1077, label %1090, label %1078, !prof !4

1078:                                             ; preds = %1071
  %1079 = fpext float %1075 to double
  %1080 = fpext nnan float %1016 to double
  %1081 = fpext float %1073 to double
  %1082 = fmul double %1079, %1080
  %1083 = fmul double %1082, %1081
  %1084 = fptrunc double %1083 to float
  %1085 = fcmp oeq float %1075, 0.000000e+00
  %1086 = tail call float @llvm.fabs.f32(float %1073)
  %1087 = fcmp one float %1086, +inf
  %1088 = and i1 %1085, %1087
  %1089 = select i1 %1088, float 0.000000e+00, float %1084
  br label %1090

1090:                                             ; preds = %1078, %1071
  %1091 = phi float [ %1089, %1078 ], [ %1076, %1071 ]
  %1092 = extractelement <8 x float> %1011, i64 4
  %1093 = fmul float %1092, %1016
  %1094 = extractelement <8 x float> %277, i64 4
  %1095 = fmul float %1094, %1093
  %1096 = tail call i1 @llvm.is.fpclass.f32(float %1093, /* (sub norm) */ i32 408)
  br i1 %1096, label %1109, label %1097, !prof !4

1097:                                             ; preds = %1090
  %1098 = fpext float %1094 to double
  %1099 = fpext nnan float %1016 to double
  %1100 = fpext float %1092 to double
  %1101 = fmul double %1098, %1099
  %1102 = fmul double %1101, %1100
  %1103 = fptrunc double %1102 to float
  %1104 = fcmp oeq float %1094, 0.000000e+00
  %1105 = tail call float @llvm.fabs.f32(float %1092)
  %1106 = fcmp one float %1105, +inf
  %1107 = and i1 %1104, %1106
  %1108 = select i1 %1107, float 0.000000e+00, float %1103
  br label %1109

1109:                                             ; preds = %1097, %1090
  %1110 = phi float [ %1108, %1097 ], [ %1095, %1090 ]
  %1111 = extractelement <8 x float> %1011, i64 5
  %1112 = fmul float %1111, %1016
  %1113 = extractelement <8 x float> %277, i64 5
  %1114 = fmul float %1113, %1112
  %1115 = tail call i1 @llvm.is.fpclass.f32(float %1112, /* (sub norm) */ i32 408)
  br i1 %1115, label %1128, label %1116, !prof !4

1116:                                             ; preds = %1109
  %1117 = fpext float %1113 to double
  %1118 = fpext nnan float %1016 to double
  %1119 = fpext float %1111 to double
  %1120 = fmul double %1117, %1118
  %1121 = fmul double %1120, %1119
  %1122 = fptrunc double %1121 to float
  %1123 = fcmp oeq float %1113, 0.000000e+00
  %1124 = tail call float @llvm.fabs.f32(float %1111)
  %1125 = fcmp one float %1124, +inf
  %1126 = and i1 %1123, %1125
  %1127 = select i1 %1126, float 0.000000e+00, float %1122
  br label %1128

1128:                                             ; preds = %1116, %1109
  %1129 = phi float [ %1127, %1116 ], [ %1114, %1109 ]
  %1130 = extractelement <8 x float> %1011, i64 6
  %1131 = fmul float %1130, %1016
  %1132 = extractelement <8 x float> %277, i64 6
  %1133 = fmul float %1132, %1131
  %1134 = tail call i1 @llvm.is.fpclass.f32(float %1131, /* (sub norm) */ i32 408)
  br i1 %1134, label %1147, label %1135, !prof !4

1135:                                             ; preds = %1128
  %1136 = fpext float %1132 to double
  %1137 = fpext nnan float %1016 to double
  %1138 = fpext float %1130 to double
  %1139 = fmul double %1136, %1137
  %1140 = fmul double %1139, %1138
  %1141 = fptrunc double %1140 to float
  %1142 = fcmp oeq float %1132, 0.000000e+00
  %1143 = tail call float @llvm.fabs.f32(float %1130)
  %1144 = fcmp one float %1143, +inf
  %1145 = and i1 %1142, %1144
  %1146 = select i1 %1145, float 0.000000e+00, float %1141
  br label %1147

1147:                                             ; preds = %1135, %1128
  %1148 = phi float [ %1146, %1135 ], [ %1133, %1128 ]
  %1149 = extractelement <8 x float> %1011, i64 7
  %1150 = fmul float %1149, %1016
  %1151 = extractelement <8 x float> %277, i64 7
  %1152 = fmul float %1151, %1150
  %1153 = tail call i1 @llvm.is.fpclass.f32(float %1150, /* (sub norm) */ i32 408)
  br i1 %1153, label %1166, label %1154, !prof !4

1154:                                             ; preds = %1147
  %1155 = fpext float %1151 to double
  %1156 = fpext nnan float %1016 to double
  %1157 = fpext float %1149 to double
  %1158 = fmul double %1155, %1156
  %1159 = fmul double %1158, %1157
  %1160 = fptrunc double %1159 to float
  %1161 = fcmp oeq float %1151, 0.000000e+00
  %1162 = tail call float @llvm.fabs.f32(float %1149)
  %1163 = fcmp one float %1162, +inf
  %1164 = and i1 %1161, %1163
  %1165 = select i1 %1164, float 0.000000e+00, float %1160
  br label %1166

1166:                                             ; preds = %1154, %1147
  %1167 = phi float [ %1165, %1154 ], [ %1152, %1147 ]
  store float %1034, ptr addrspace(3) %514, align 4
  store float %1053, ptr addrspace(3) %520, align 4
  store float %1072, ptr addrspace(3) %526, align 4
  store float %1091, ptr addrspace(3) %532, align 4
  store float %1110, ptr addrspace(3) %538, align 4
  store float %1129, ptr addrspace(3) %544, align 4
  store float %1148, ptr addrspace(3) %550, align 4
  store float %1167, ptr addrspace(3) %556, align 4
  %1168 = and i1 %559, %953
  %1169 = and i1 %292, %1168
  br i1 %1169, label %1170, label %1176

1170:                                             ; preds = %1166
  %1171 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %951
  %1172 = load <4 x float>, ptr addrspace(1) %1171, align 16
  %1173 = getelementptr i8, ptr addrspace(1) %1171, i64 16
  %1174 = load <4 x float>, ptr addrspace(1) %1173, align 16
  %1175 = shufflevector <4 x float> %1172, <4 x float> %1174, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1224

1176:                                             ; preds = %1166
  %1177 = icmp slt i64 %951, %25
  %1178 = select i1 %1177, i64 %951, i64 0
  %1179 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1178
  %1180 = load float, ptr addrspace(1) %1179, align 4
  %1181 = insertelement <8 x float> poison, float %1180, i64 0
  %1182 = or disjoint i64 %57, %515
  %1183 = icmp slt i64 %1182, %25
  %1184 = select i1 %1183, i64 %1182, i64 0
  %1185 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1184
  %1186 = load float, ptr addrspace(1) %1185, align 4
  %1187 = insertelement <8 x float> %1181, float %1186, i64 1
  %1188 = or disjoint i64 %57, %521
  %1189 = icmp slt i64 %1188, %25
  %1190 = select i1 %1189, i64 %1188, i64 0
  %1191 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1190
  %1192 = load float, ptr addrspace(1) %1191, align 4
  %1193 = insertelement <8 x float> %1187, float %1192, i64 2
  %1194 = or disjoint i64 %57, %527
  %1195 = icmp slt i64 %1194, %25
  %1196 = select i1 %1195, i64 %1194, i64 0
  %1197 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1196
  %1198 = load float, ptr addrspace(1) %1197, align 4
  %1199 = insertelement <8 x float> %1193, float %1198, i64 3
  %1200 = or disjoint i64 %57, %533
  %1201 = icmp slt i64 %1200, %25
  %1202 = select i1 %1201, i64 %1200, i64 0
  %1203 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1202
  %1204 = load float, ptr addrspace(1) %1203, align 4
  %1205 = insertelement <8 x float> %1199, float %1204, i64 4
  %1206 = or disjoint i64 %57, %539
  %1207 = icmp slt i64 %1206, %25
  %1208 = select i1 %1207, i64 %1206, i64 0
  %1209 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1208
  %1210 = load float, ptr addrspace(1) %1209, align 4
  %1211 = insertelement <8 x float> %1205, float %1210, i64 5
  %1212 = or disjoint i64 %57, %545
  %1213 = icmp slt i64 %1212, %25
  %1214 = select i1 %1213, i64 %1212, i64 0
  %1215 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1214
  %1216 = load float, ptr addrspace(1) %1215, align 4
  %1217 = insertelement <8 x float> %1211, float %1216, i64 6
  %1218 = or disjoint i64 %57, %551
  %1219 = icmp slt i64 %1218, %25
  %1220 = select i1 %1219, i64 %1218, i64 0
  %1221 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1220
  %1222 = load float, ptr addrspace(1) %1221, align 4
  %1223 = insertelement <8 x float> %1217, float %1222, i64 7
  br label %1224

1224:                                             ; preds = %1170, %1176
  %1225 = phi <8 x float> [ %1223, %1176 ], [ %1175, %1170 ]
  %1226 = extractelement <8 x float> %1225, i64 0
  %1227 = load i8, ptr addrspace(1) %621, align 1
  %1228 = zext i8 %1227 to i32
  %1229 = shl nuw nsw i32 %1228, 23
  %1230 = bitcast i32 %1229 to float
  %1231 = fmul float %1226, %1230
  %1232 = extractelement <8 x float> %278, i64 0
  %1233 = fmul float %1232, %1231
  %1234 = tail call i1 @llvm.is.fpclass.f32(float %1231, /* (sub norm) */ i32 408)
  br i1 %1234, label %1247, label %1235, !prof !4

1235:                                             ; preds = %1224
  %1236 = fpext float %1232 to double
  %1237 = fpext nnan float %1230 to double
  %1238 = fpext float %1226 to double
  %1239 = fmul double %1236, %1237
  %1240 = fmul double %1239, %1238
  %1241 = fptrunc double %1240 to float
  %1242 = fcmp oeq float %1232, 0.000000e+00
  %1243 = tail call float @llvm.fabs.f32(float %1226)
  %1244 = fcmp one float %1243, +inf
  %1245 = and i1 %1242, %1244
  %1246 = select i1 %1245, float 0.000000e+00, float %1241
  br label %1247

1247:                                             ; preds = %1235, %1224
  %1248 = phi float [ %1246, %1235 ], [ %1233, %1224 ]
  %1249 = extractelement <8 x float> %1225, i64 1
  %1250 = fmul float %1249, %1230
  %1251 = extractelement <8 x float> %278, i64 1
  %1252 = fmul float %1251, %1250
  %1253 = tail call i1 @llvm.is.fpclass.f32(float %1250, /* (sub norm) */ i32 408)
  br i1 %1253, label %1266, label %1254, !prof !4

1254:                                             ; preds = %1247
  %1255 = fpext float %1251 to double
  %1256 = fpext nnan float %1230 to double
  %1257 = fpext float %1249 to double
  %1258 = fmul double %1255, %1256
  %1259 = fmul double %1258, %1257
  %1260 = fptrunc double %1259 to float
  %1261 = fcmp oeq float %1251, 0.000000e+00
  %1262 = tail call float @llvm.fabs.f32(float %1249)
  %1263 = fcmp one float %1262, +inf
  %1264 = and i1 %1261, %1263
  %1265 = select i1 %1264, float 0.000000e+00, float %1260
  br label %1266

1266:                                             ; preds = %1254, %1247
  %1267 = phi float [ %1265, %1254 ], [ %1252, %1247 ]
  %1268 = extractelement <8 x float> %1225, i64 2
  %1269 = fmul float %1268, %1230
  %1270 = extractelement <8 x float> %278, i64 2
  %1271 = fmul float %1270, %1269
  %1272 = tail call i1 @llvm.is.fpclass.f32(float %1269, /* (sub norm) */ i32 408)
  br i1 %1272, label %1285, label %1273, !prof !4

1273:                                             ; preds = %1266
  %1274 = fpext float %1270 to double
  %1275 = fpext nnan float %1230 to double
  %1276 = fpext float %1268 to double
  %1277 = fmul double %1274, %1275
  %1278 = fmul double %1277, %1276
  %1279 = fptrunc double %1278 to float
  %1280 = fcmp oeq float %1270, 0.000000e+00
  %1281 = tail call float @llvm.fabs.f32(float %1268)
  %1282 = fcmp one float %1281, +inf
  %1283 = and i1 %1280, %1282
  %1284 = select i1 %1283, float 0.000000e+00, float %1279
  br label %1285

1285:                                             ; preds = %1273, %1266
  %1286 = phi float [ %1284, %1273 ], [ %1271, %1266 ]
  %1287 = extractelement <8 x float> %1225, i64 3
  %1288 = fmul float %1287, %1230
  %1289 = extractelement <8 x float> %278, i64 3
  %1290 = fmul float %1289, %1288
  %1291 = tail call i1 @llvm.is.fpclass.f32(float %1288, /* (sub norm) */ i32 408)
  br i1 %1291, label %1304, label %1292, !prof !4

1292:                                             ; preds = %1285
  %1293 = fpext float %1289 to double
  %1294 = fpext nnan float %1230 to double
  %1295 = fpext float %1287 to double
  %1296 = fmul double %1293, %1294
  %1297 = fmul double %1296, %1295
  %1298 = fptrunc double %1297 to float
  %1299 = fcmp oeq float %1289, 0.000000e+00
  %1300 = tail call float @llvm.fabs.f32(float %1287)
  %1301 = fcmp one float %1300, +inf
  %1302 = and i1 %1299, %1301
  %1303 = select i1 %1302, float 0.000000e+00, float %1298
  br label %1304

1304:                                             ; preds = %1292, %1285
  %1305 = phi float [ %1303, %1292 ], [ %1290, %1285 ]
  %1306 = extractelement <8 x float> %1225, i64 4
  %1307 = fmul float %1306, %1230
  %1308 = extractelement <8 x float> %278, i64 4
  %1309 = fmul float %1308, %1307
  %1310 = tail call i1 @llvm.is.fpclass.f32(float %1307, /* (sub norm) */ i32 408)
  br i1 %1310, label %1323, label %1311, !prof !4

1311:                                             ; preds = %1304
  %1312 = fpext float %1308 to double
  %1313 = fpext nnan float %1230 to double
  %1314 = fpext float %1306 to double
  %1315 = fmul double %1312, %1313
  %1316 = fmul double %1315, %1314
  %1317 = fptrunc double %1316 to float
  %1318 = fcmp oeq float %1308, 0.000000e+00
  %1319 = tail call float @llvm.fabs.f32(float %1306)
  %1320 = fcmp one float %1319, +inf
  %1321 = and i1 %1318, %1320
  %1322 = select i1 %1321, float 0.000000e+00, float %1317
  br label %1323

1323:                                             ; preds = %1311, %1304
  %1324 = phi float [ %1322, %1311 ], [ %1309, %1304 ]
  %1325 = extractelement <8 x float> %1225, i64 5
  %1326 = fmul float %1325, %1230
  %1327 = extractelement <8 x float> %278, i64 5
  %1328 = fmul float %1327, %1326
  %1329 = tail call i1 @llvm.is.fpclass.f32(float %1326, /* (sub norm) */ i32 408)
  br i1 %1329, label %1342, label %1330, !prof !4

1330:                                             ; preds = %1323
  %1331 = fpext float %1327 to double
  %1332 = fpext nnan float %1230 to double
  %1333 = fpext float %1325 to double
  %1334 = fmul double %1331, %1332
  %1335 = fmul double %1334, %1333
  %1336 = fptrunc double %1335 to float
  %1337 = fcmp oeq float %1327, 0.000000e+00
  %1338 = tail call float @llvm.fabs.f32(float %1325)
  %1339 = fcmp one float %1338, +inf
  %1340 = and i1 %1337, %1339
  %1341 = select i1 %1340, float 0.000000e+00, float %1336
  br label %1342

1342:                                             ; preds = %1330, %1323
  %1343 = phi float [ %1341, %1330 ], [ %1328, %1323 ]
  %1344 = extractelement <8 x float> %1225, i64 6
  %1345 = fmul float %1344, %1230
  %1346 = extractelement <8 x float> %278, i64 6
  %1347 = fmul float %1346, %1345
  %1348 = tail call i1 @llvm.is.fpclass.f32(float %1345, /* (sub norm) */ i32 408)
  br i1 %1348, label %1361, label %1349, !prof !4

1349:                                             ; preds = %1342
  %1350 = fpext float %1346 to double
  %1351 = fpext nnan float %1230 to double
  %1352 = fpext float %1344 to double
  %1353 = fmul double %1350, %1351
  %1354 = fmul double %1353, %1352
  %1355 = fptrunc double %1354 to float
  %1356 = fcmp oeq float %1346, 0.000000e+00
  %1357 = tail call float @llvm.fabs.f32(float %1344)
  %1358 = fcmp one float %1357, +inf
  %1359 = and i1 %1356, %1358
  %1360 = select i1 %1359, float 0.000000e+00, float %1355
  br label %1361

1361:                                             ; preds = %1349, %1342
  %1362 = phi float [ %1360, %1349 ], [ %1347, %1342 ]
  %1363 = extractelement <8 x float> %1225, i64 7
  %1364 = fmul float %1363, %1230
  %1365 = extractelement <8 x float> %278, i64 7
  %1366 = fmul float %1365, %1364
  %1367 = tail call i1 @llvm.is.fpclass.f32(float %1364, /* (sub norm) */ i32 408)
  br i1 %1367, label %1380, label %1368, !prof !4

1368:                                             ; preds = %1361
  %1369 = fpext float %1365 to double
  %1370 = fpext nnan float %1230 to double
  %1371 = fpext float %1363 to double
  %1372 = fmul double %1369, %1370
  %1373 = fmul double %1372, %1371
  %1374 = fptrunc double %1373 to float
  %1375 = fcmp oeq float %1365, 0.000000e+00
  %1376 = tail call float @llvm.fabs.f32(float %1363)
  %1377 = fcmp one float %1376, +inf
  %1378 = and i1 %1375, %1377
  %1379 = select i1 %1378, float 0.000000e+00, float %1374
  br label %1380

1380:                                             ; preds = %1368, %1361
  %1381 = phi float [ %1379, %1368 ], [ %1366, %1361 ]
  store float %1248, ptr addrspace(3) %780, align 4
  store float %1267, ptr addrspace(3) %783, align 4
  store float %1286, ptr addrspace(3) %786, align 4
  store float %1305, ptr addrspace(3) %789, align 4
  store float %1324, ptr addrspace(3) %792, align 4
  store float %1343, ptr addrspace(3) %795, align 4
  store float %1362, ptr addrspace(3) %798, align 4
  store float %1381, ptr addrspace(3) %801, align 4
  tail call void @llvm.amdgcn.wave.barrier()
  %1382 = or disjoint i64 %804, %56
  %1383 = or disjoint i64 %1382, %51
  %1384 = load <8 x float>, ptr addrspace(3) %814, align 16
  %1385 = fptrunc <8 x float> %1384 to <8 x bfloat>
  %1386 = mul i64 %1383, %26
  %1387 = add i64 %1386, %810
  %1388 = icmp ult i64 %1383, %25
  %1389 = and i1 %1388, %821
  br i1 %1389, label %1390, label %1392

1390:                                             ; preds = %1380
  %1391 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1387
  store <8 x bfloat> %1385, ptr addrspace(1) %1391, align 2
  br label %1446

1392:                                             ; preds = %1380
  %1393 = icmp ult i64 %810, %26
  %1394 = and i1 %1388, %1393
  br i1 %1394, label %1395, label %1398

1395:                                             ; preds = %1392
  %1396 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1387
  %1397 = extractelement <8 x bfloat> %1385, i64 0
  store bfloat %1397, ptr addrspace(1) %1396, align 2
  br label %1398

1398:                                             ; preds = %1395, %1392
  %1399 = or disjoint i64 %810, 1
  %1400 = icmp ult i64 %1399, %26
  %1401 = and i1 %1388, %1400
  br i1 %1401, label %1402, label %1406

1402:                                             ; preds = %1398
  %1403 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1387
  %1404 = getelementptr i8, ptr addrspace(1) %1403, i64 2
  %1405 = extractelement <8 x bfloat> %1385, i64 1
  store bfloat %1405, ptr addrspace(1) %1404, align 2
  br label %1406

1406:                                             ; preds = %1402, %1398
  %1407 = or disjoint i64 %810, 2
  %1408 = icmp ult i64 %1407, %26
  %1409 = and i1 %1388, %1408
  br i1 %1409, label %1410, label %1414

1410:                                             ; preds = %1406
  %1411 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1387
  %1412 = getelementptr i8, ptr addrspace(1) %1411, i64 4
  %1413 = extractelement <8 x bfloat> %1385, i64 2
  store bfloat %1413, ptr addrspace(1) %1412, align 2
  br label %1414

1414:                                             ; preds = %1410, %1406
  %1415 = or disjoint i64 %810, 3
  %1416 = icmp ult i64 %1415, %26
  %1417 = and i1 %1388, %1416
  br i1 %1417, label %1418, label %1422

1418:                                             ; preds = %1414
  %1419 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1387
  %1420 = getelementptr i8, ptr addrspace(1) %1419, i64 6
  %1421 = extractelement <8 x bfloat> %1385, i64 3
  store bfloat %1421, ptr addrspace(1) %1420, align 2
  br label %1422

1422:                                             ; preds = %1418, %1414
  %1423 = or disjoint i64 %810, 4
  %1424 = icmp ult i64 %1423, %26
  %1425 = and i1 %1388, %1424
  br i1 %1425, label %1426, label %1430

1426:                                             ; preds = %1422
  %1427 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1387
  %1428 = getelementptr i8, ptr addrspace(1) %1427, i64 8
  %1429 = extractelement <8 x bfloat> %1385, i64 4
  store bfloat %1429, ptr addrspace(1) %1428, align 2
  br label %1430

1430:                                             ; preds = %1426, %1422
  %1431 = or disjoint i64 %810, 5
  %1432 = icmp ult i64 %1431, %26
  %1433 = and i1 %1388, %1432
  br i1 %1433, label %1434, label %1438

1434:                                             ; preds = %1430
  %1435 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1387
  %1436 = getelementptr i8, ptr addrspace(1) %1435, i64 10
  %1437 = extractelement <8 x bfloat> %1385, i64 5
  store bfloat %1437, ptr addrspace(1) %1436, align 2
  br label %1438

1438:                                             ; preds = %1434, %1430
  %1439 = or disjoint i64 %810, 6
  %1440 = icmp ult i64 %1439, %26
  %1441 = and i1 %1388, %1440
  br i1 %1441, label %1442, label %1446

1442:                                             ; preds = %1438
  %1443 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1387
  %1444 = getelementptr i8, ptr addrspace(1) %1443, i64 12
  %1445 = extractelement <8 x bfloat> %1385, i64 6
  store bfloat %1445, ptr addrspace(1) %1444, align 2
  br label %1446

1446:                                             ; preds = %1438, %1442, %1390
  %1447 = or disjoint i64 %880, %56
  %1448 = or disjoint i64 %1447, %51
  %1449 = load <8 x float>, ptr addrspace(3) %887, align 16
  %1450 = fptrunc <8 x float> %1449 to <8 x bfloat>
  %1451 = mul i64 %1448, %26
  %1452 = add i64 %1451, %810
  %1453 = icmp ult i64 %1448, %25
  %1454 = and i1 %1453, %821
  br i1 %1454, label %1455, label %1457

1455:                                             ; preds = %1446
  %1456 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  store <8 x bfloat> %1450, ptr addrspace(1) %1456, align 2
  br label %1511

1457:                                             ; preds = %1446
  %1458 = icmp ult i64 %810, %26
  %1459 = and i1 %1453, %1458
  br i1 %1459, label %1460, label %1463

1460:                                             ; preds = %1457
  %1461 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1462 = extractelement <8 x bfloat> %1450, i64 0
  store bfloat %1462, ptr addrspace(1) %1461, align 2
  br label %1463

1463:                                             ; preds = %1460, %1457
  %1464 = or disjoint i64 %810, 1
  %1465 = icmp ult i64 %1464, %26
  %1466 = and i1 %1453, %1465
  br i1 %1466, label %1467, label %1471

1467:                                             ; preds = %1463
  %1468 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1469 = getelementptr i8, ptr addrspace(1) %1468, i64 2
  %1470 = extractelement <8 x bfloat> %1450, i64 1
  store bfloat %1470, ptr addrspace(1) %1469, align 2
  br label %1471

1471:                                             ; preds = %1467, %1463
  %1472 = or disjoint i64 %810, 2
  %1473 = icmp ult i64 %1472, %26
  %1474 = and i1 %1453, %1473
  br i1 %1474, label %1475, label %1479

1475:                                             ; preds = %1471
  %1476 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1477 = getelementptr i8, ptr addrspace(1) %1476, i64 4
  %1478 = extractelement <8 x bfloat> %1450, i64 2
  store bfloat %1478, ptr addrspace(1) %1477, align 2
  br label %1479

1479:                                             ; preds = %1475, %1471
  %1480 = or disjoint i64 %810, 3
  %1481 = icmp ult i64 %1480, %26
  %1482 = and i1 %1453, %1481
  br i1 %1482, label %1483, label %1487

1483:                                             ; preds = %1479
  %1484 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1485 = getelementptr i8, ptr addrspace(1) %1484, i64 6
  %1486 = extractelement <8 x bfloat> %1450, i64 3
  store bfloat %1486, ptr addrspace(1) %1485, align 2
  br label %1487

1487:                                             ; preds = %1483, %1479
  %1488 = or disjoint i64 %810, 4
  %1489 = icmp ult i64 %1488, %26
  %1490 = and i1 %1453, %1489
  br i1 %1490, label %1491, label %1495

1491:                                             ; preds = %1487
  %1492 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1493 = getelementptr i8, ptr addrspace(1) %1492, i64 8
  %1494 = extractelement <8 x bfloat> %1450, i64 4
  store bfloat %1494, ptr addrspace(1) %1493, align 2
  br label %1495

1495:                                             ; preds = %1491, %1487
  %1496 = or disjoint i64 %810, 5
  %1497 = icmp ult i64 %1496, %26
  %1498 = and i1 %1453, %1497
  br i1 %1498, label %1499, label %1503

1499:                                             ; preds = %1495
  %1500 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1501 = getelementptr i8, ptr addrspace(1) %1500, i64 10
  %1502 = extractelement <8 x bfloat> %1450, i64 5
  store bfloat %1502, ptr addrspace(1) %1501, align 2
  br label %1503

1503:                                             ; preds = %1499, %1495
  %1504 = or disjoint i64 %810, 6
  %1505 = icmp ult i64 %1504, %26
  %1506 = and i1 %1453, %1505
  br i1 %1506, label %1507, label %1511

1507:                                             ; preds = %1503
  %1508 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1452
  %1509 = getelementptr i8, ptr addrspace(1) %1508, i64 12
  %1510 = extractelement <8 x bfloat> %1450, i64 6
  store bfloat %1510, ptr addrspace(1) %1509, align 2
  br label %1511

1511:                                             ; preds = %1503, %1507, %1455
  tail call void @llvm.amdgcn.wave.barrier()
  %1512 = or disjoint i64 %59, %116
  %1513 = or disjoint i64 %1512, 7
  %1514 = icmp ult i64 %1513, %25
  %1515 = and i1 %287, %1514
  %1516 = and i1 %292, %1515
  br i1 %1516, label %1517, label %1523

1517:                                             ; preds = %1511
  %1518 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1512
  %1519 = load <4 x float>, ptr addrspace(1) %1518, align 16
  %1520 = getelementptr i8, ptr addrspace(1) %1518, i64 16
  %1521 = load <4 x float>, ptr addrspace(1) %1520, align 16
  %1522 = shufflevector <4 x float> %1519, <4 x float> %1521, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1571

1523:                                             ; preds = %1511
  %1524 = icmp slt i64 %1512, %25
  %1525 = select i1 %1524, i64 %1512, i64 0
  %1526 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1525
  %1527 = load float, ptr addrspace(1) %1526, align 4
  %1528 = insertelement <8 x float> poison, float %1527, i64 0
  %1529 = or disjoint i64 %59, %515
  %1530 = icmp slt i64 %1529, %25
  %1531 = select i1 %1530, i64 %1529, i64 0
  %1532 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1531
  %1533 = load float, ptr addrspace(1) %1532, align 4
  %1534 = insertelement <8 x float> %1528, float %1533, i64 1
  %1535 = or disjoint i64 %59, %521
  %1536 = icmp slt i64 %1535, %25
  %1537 = select i1 %1536, i64 %1535, i64 0
  %1538 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1537
  %1539 = load float, ptr addrspace(1) %1538, align 4
  %1540 = insertelement <8 x float> %1534, float %1539, i64 2
  %1541 = or disjoint i64 %59, %527
  %1542 = icmp slt i64 %1541, %25
  %1543 = select i1 %1542, i64 %1541, i64 0
  %1544 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1543
  %1545 = load float, ptr addrspace(1) %1544, align 4
  %1546 = insertelement <8 x float> %1540, float %1545, i64 3
  %1547 = or disjoint i64 %59, %533
  %1548 = icmp slt i64 %1547, %25
  %1549 = select i1 %1548, i64 %1547, i64 0
  %1550 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1549
  %1551 = load float, ptr addrspace(1) %1550, align 4
  %1552 = insertelement <8 x float> %1546, float %1551, i64 4
  %1553 = or disjoint i64 %59, %539
  %1554 = icmp slt i64 %1553, %25
  %1555 = select i1 %1554, i64 %1553, i64 0
  %1556 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1555
  %1557 = load float, ptr addrspace(1) %1556, align 4
  %1558 = insertelement <8 x float> %1552, float %1557, i64 5
  %1559 = or disjoint i64 %59, %545
  %1560 = icmp slt i64 %1559, %25
  %1561 = select i1 %1560, i64 %1559, i64 0
  %1562 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1561
  %1563 = load float, ptr addrspace(1) %1562, align 4
  %1564 = insertelement <8 x float> %1558, float %1563, i64 6
  %1565 = or disjoint i64 %59, %551
  %1566 = icmp slt i64 %1565, %25
  %1567 = select i1 %1566, i64 %1565, i64 0
  %1568 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1567
  %1569 = load float, ptr addrspace(1) %1568, align 4
  %1570 = insertelement <8 x float> %1564, float %1569, i64 7
  br label %1571

1571:                                             ; preds = %1517, %1523
  %1572 = phi <8 x float> [ %1570, %1523 ], [ %1522, %1517 ]
  %1573 = extractelement <8 x float> %1572, i64 0
  %1574 = load i8, ptr addrspace(1) %352, align 1
  %1575 = zext i8 %1574 to i32
  %1576 = shl nuw nsw i32 %1575, 23
  %1577 = bitcast i32 %1576 to float
  %1578 = fmul float %1573, %1577
  %1579 = extractelement <8 x float> %279, i64 0
  %1580 = fmul float %1579, %1578
  %1581 = tail call i1 @llvm.is.fpclass.f32(float %1578, /* (sub norm) */ i32 408)
  br i1 %1581, label %1594, label %1582, !prof !4

1582:                                             ; preds = %1571
  %1583 = fpext float %1579 to double
  %1584 = fpext nnan float %1577 to double
  %1585 = fpext float %1573 to double
  %1586 = fmul double %1583, %1584
  %1587 = fmul double %1586, %1585
  %1588 = fptrunc double %1587 to float
  %1589 = fcmp oeq float %1579, 0.000000e+00
  %1590 = tail call float @llvm.fabs.f32(float %1573)
  %1591 = fcmp one float %1590, +inf
  %1592 = and i1 %1589, %1591
  %1593 = select i1 %1592, float 0.000000e+00, float %1588
  br label %1594

1594:                                             ; preds = %1582, %1571
  %1595 = phi float [ %1593, %1582 ], [ %1580, %1571 ]
  %1596 = extractelement <8 x float> %1572, i64 1
  %1597 = fmul float %1596, %1577
  %1598 = extractelement <8 x float> %279, i64 1
  %1599 = fmul float %1598, %1597
  %1600 = tail call i1 @llvm.is.fpclass.f32(float %1597, /* (sub norm) */ i32 408)
  br i1 %1600, label %1613, label %1601, !prof !4

1601:                                             ; preds = %1594
  %1602 = fpext float %1598 to double
  %1603 = fpext nnan float %1577 to double
  %1604 = fpext float %1596 to double
  %1605 = fmul double %1602, %1603
  %1606 = fmul double %1605, %1604
  %1607 = fptrunc double %1606 to float
  %1608 = fcmp oeq float %1598, 0.000000e+00
  %1609 = tail call float @llvm.fabs.f32(float %1596)
  %1610 = fcmp one float %1609, +inf
  %1611 = and i1 %1608, %1610
  %1612 = select i1 %1611, float 0.000000e+00, float %1607
  br label %1613

1613:                                             ; preds = %1601, %1594
  %1614 = phi float [ %1612, %1601 ], [ %1599, %1594 ]
  %1615 = extractelement <8 x float> %1572, i64 2
  %1616 = fmul float %1615, %1577
  %1617 = extractelement <8 x float> %279, i64 2
  %1618 = fmul float %1617, %1616
  %1619 = tail call i1 @llvm.is.fpclass.f32(float %1616, /* (sub norm) */ i32 408)
  br i1 %1619, label %1632, label %1620, !prof !4

1620:                                             ; preds = %1613
  %1621 = fpext float %1617 to double
  %1622 = fpext nnan float %1577 to double
  %1623 = fpext float %1615 to double
  %1624 = fmul double %1621, %1622
  %1625 = fmul double %1624, %1623
  %1626 = fptrunc double %1625 to float
  %1627 = fcmp oeq float %1617, 0.000000e+00
  %1628 = tail call float @llvm.fabs.f32(float %1615)
  %1629 = fcmp one float %1628, +inf
  %1630 = and i1 %1627, %1629
  %1631 = select i1 %1630, float 0.000000e+00, float %1626
  br label %1632

1632:                                             ; preds = %1620, %1613
  %1633 = phi float [ %1631, %1620 ], [ %1618, %1613 ]
  %1634 = extractelement <8 x float> %1572, i64 3
  %1635 = fmul float %1634, %1577
  %1636 = extractelement <8 x float> %279, i64 3
  %1637 = fmul float %1636, %1635
  %1638 = tail call i1 @llvm.is.fpclass.f32(float %1635, /* (sub norm) */ i32 408)
  br i1 %1638, label %1651, label %1639, !prof !4

1639:                                             ; preds = %1632
  %1640 = fpext float %1636 to double
  %1641 = fpext nnan float %1577 to double
  %1642 = fpext float %1634 to double
  %1643 = fmul double %1640, %1641
  %1644 = fmul double %1643, %1642
  %1645 = fptrunc double %1644 to float
  %1646 = fcmp oeq float %1636, 0.000000e+00
  %1647 = tail call float @llvm.fabs.f32(float %1634)
  %1648 = fcmp one float %1647, +inf
  %1649 = and i1 %1646, %1648
  %1650 = select i1 %1649, float 0.000000e+00, float %1645
  br label %1651

1651:                                             ; preds = %1639, %1632
  %1652 = phi float [ %1650, %1639 ], [ %1637, %1632 ]
  %1653 = extractelement <8 x float> %1572, i64 4
  %1654 = fmul float %1653, %1577
  %1655 = extractelement <8 x float> %279, i64 4
  %1656 = fmul float %1655, %1654
  %1657 = tail call i1 @llvm.is.fpclass.f32(float %1654, /* (sub norm) */ i32 408)
  br i1 %1657, label %1670, label %1658, !prof !4

1658:                                             ; preds = %1651
  %1659 = fpext float %1655 to double
  %1660 = fpext nnan float %1577 to double
  %1661 = fpext float %1653 to double
  %1662 = fmul double %1659, %1660
  %1663 = fmul double %1662, %1661
  %1664 = fptrunc double %1663 to float
  %1665 = fcmp oeq float %1655, 0.000000e+00
  %1666 = tail call float @llvm.fabs.f32(float %1653)
  %1667 = fcmp one float %1666, +inf
  %1668 = and i1 %1665, %1667
  %1669 = select i1 %1668, float 0.000000e+00, float %1664
  br label %1670

1670:                                             ; preds = %1658, %1651
  %1671 = phi float [ %1669, %1658 ], [ %1656, %1651 ]
  %1672 = extractelement <8 x float> %1572, i64 5
  %1673 = fmul float %1672, %1577
  %1674 = extractelement <8 x float> %279, i64 5
  %1675 = fmul float %1674, %1673
  %1676 = tail call i1 @llvm.is.fpclass.f32(float %1673, /* (sub norm) */ i32 408)
  br i1 %1676, label %1689, label %1677, !prof !4

1677:                                             ; preds = %1670
  %1678 = fpext float %1674 to double
  %1679 = fpext nnan float %1577 to double
  %1680 = fpext float %1672 to double
  %1681 = fmul double %1678, %1679
  %1682 = fmul double %1681, %1680
  %1683 = fptrunc double %1682 to float
  %1684 = fcmp oeq float %1674, 0.000000e+00
  %1685 = tail call float @llvm.fabs.f32(float %1672)
  %1686 = fcmp one float %1685, +inf
  %1687 = and i1 %1684, %1686
  %1688 = select i1 %1687, float 0.000000e+00, float %1683
  br label %1689

1689:                                             ; preds = %1677, %1670
  %1690 = phi float [ %1688, %1677 ], [ %1675, %1670 ]
  %1691 = extractelement <8 x float> %1572, i64 6
  %1692 = fmul float %1691, %1577
  %1693 = extractelement <8 x float> %279, i64 6
  %1694 = fmul float %1693, %1692
  %1695 = tail call i1 @llvm.is.fpclass.f32(float %1692, /* (sub norm) */ i32 408)
  br i1 %1695, label %1708, label %1696, !prof !4

1696:                                             ; preds = %1689
  %1697 = fpext float %1693 to double
  %1698 = fpext nnan float %1577 to double
  %1699 = fpext float %1691 to double
  %1700 = fmul double %1697, %1698
  %1701 = fmul double %1700, %1699
  %1702 = fptrunc double %1701 to float
  %1703 = fcmp oeq float %1693, 0.000000e+00
  %1704 = tail call float @llvm.fabs.f32(float %1691)
  %1705 = fcmp one float %1704, +inf
  %1706 = and i1 %1703, %1705
  %1707 = select i1 %1706, float 0.000000e+00, float %1702
  br label %1708

1708:                                             ; preds = %1696, %1689
  %1709 = phi float [ %1707, %1696 ], [ %1694, %1689 ]
  %1710 = extractelement <8 x float> %1572, i64 7
  %1711 = fmul float %1710, %1577
  %1712 = extractelement <8 x float> %279, i64 7
  %1713 = fmul float %1712, %1711
  %1714 = tail call i1 @llvm.is.fpclass.f32(float %1711, /* (sub norm) */ i32 408)
  br i1 %1714, label %1727, label %1715, !prof !4

1715:                                             ; preds = %1708
  %1716 = fpext float %1712 to double
  %1717 = fpext nnan float %1577 to double
  %1718 = fpext float %1710 to double
  %1719 = fmul double %1716, %1717
  %1720 = fmul double %1719, %1718
  %1721 = fptrunc double %1720 to float
  %1722 = fcmp oeq float %1712, 0.000000e+00
  %1723 = tail call float @llvm.fabs.f32(float %1710)
  %1724 = fcmp one float %1723, +inf
  %1725 = and i1 %1722, %1724
  %1726 = select i1 %1725, float 0.000000e+00, float %1721
  br label %1727

1727:                                             ; preds = %1715, %1708
  %1728 = phi float [ %1726, %1715 ], [ %1713, %1708 ]
  store float %1595, ptr addrspace(3) %514, align 4
  store float %1614, ptr addrspace(3) %520, align 4
  store float %1633, ptr addrspace(3) %526, align 4
  store float %1652, ptr addrspace(3) %532, align 4
  store float %1671, ptr addrspace(3) %538, align 4
  store float %1690, ptr addrspace(3) %544, align 4
  store float %1709, ptr addrspace(3) %550, align 4
  store float %1728, ptr addrspace(3) %556, align 4
  %1729 = and i1 %559, %1514
  %1730 = and i1 %292, %1729
  br i1 %1730, label %1731, label %1737

1731:                                             ; preds = %1727
  %1732 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %1512
  %1733 = load <4 x float>, ptr addrspace(1) %1732, align 16
  %1734 = getelementptr i8, ptr addrspace(1) %1732, i64 16
  %1735 = load <4 x float>, ptr addrspace(1) %1734, align 16
  %1736 = shufflevector <4 x float> %1733, <4 x float> %1735, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1785

1737:                                             ; preds = %1727
  %1738 = icmp slt i64 %1512, %25
  %1739 = select i1 %1738, i64 %1512, i64 0
  %1740 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1739
  %1741 = load float, ptr addrspace(1) %1740, align 4
  %1742 = insertelement <8 x float> poison, float %1741, i64 0
  %1743 = or disjoint i64 %59, %515
  %1744 = icmp slt i64 %1743, %25
  %1745 = select i1 %1744, i64 %1743, i64 0
  %1746 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1745
  %1747 = load float, ptr addrspace(1) %1746, align 4
  %1748 = insertelement <8 x float> %1742, float %1747, i64 1
  %1749 = or disjoint i64 %59, %521
  %1750 = icmp slt i64 %1749, %25
  %1751 = select i1 %1750, i64 %1749, i64 0
  %1752 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1751
  %1753 = load float, ptr addrspace(1) %1752, align 4
  %1754 = insertelement <8 x float> %1748, float %1753, i64 2
  %1755 = or disjoint i64 %59, %527
  %1756 = icmp slt i64 %1755, %25
  %1757 = select i1 %1756, i64 %1755, i64 0
  %1758 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1757
  %1759 = load float, ptr addrspace(1) %1758, align 4
  %1760 = insertelement <8 x float> %1754, float %1759, i64 3
  %1761 = or disjoint i64 %59, %533
  %1762 = icmp slt i64 %1761, %25
  %1763 = select i1 %1762, i64 %1761, i64 0
  %1764 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1763
  %1765 = load float, ptr addrspace(1) %1764, align 4
  %1766 = insertelement <8 x float> %1760, float %1765, i64 4
  %1767 = or disjoint i64 %59, %539
  %1768 = icmp slt i64 %1767, %25
  %1769 = select i1 %1768, i64 %1767, i64 0
  %1770 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1769
  %1771 = load float, ptr addrspace(1) %1770, align 4
  %1772 = insertelement <8 x float> %1766, float %1771, i64 5
  %1773 = or disjoint i64 %59, %545
  %1774 = icmp slt i64 %1773, %25
  %1775 = select i1 %1774, i64 %1773, i64 0
  %1776 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1775
  %1777 = load float, ptr addrspace(1) %1776, align 4
  %1778 = insertelement <8 x float> %1772, float %1777, i64 6
  %1779 = or disjoint i64 %59, %551
  %1780 = icmp slt i64 %1779, %25
  %1781 = select i1 %1780, i64 %1779, i64 0
  %1782 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %1781
  %1783 = load float, ptr addrspace(1) %1782, align 4
  %1784 = insertelement <8 x float> %1778, float %1783, i64 7
  br label %1785

1785:                                             ; preds = %1731, %1737
  %1786 = phi <8 x float> [ %1784, %1737 ], [ %1736, %1731 ]
  %1787 = extractelement <8 x float> %1786, i64 0
  %1788 = load i8, ptr addrspace(1) %621, align 1
  %1789 = zext i8 %1788 to i32
  %1790 = shl nuw nsw i32 %1789, 23
  %1791 = bitcast i32 %1790 to float
  %1792 = fmul float %1787, %1791
  %1793 = extractelement <8 x float> %280, i64 0
  %1794 = fmul float %1793, %1792
  %1795 = tail call i1 @llvm.is.fpclass.f32(float %1792, /* (sub norm) */ i32 408)
  br i1 %1795, label %1808, label %1796, !prof !4

1796:                                             ; preds = %1785
  %1797 = fpext float %1793 to double
  %1798 = fpext nnan float %1791 to double
  %1799 = fpext float %1787 to double
  %1800 = fmul double %1797, %1798
  %1801 = fmul double %1800, %1799
  %1802 = fptrunc double %1801 to float
  %1803 = fcmp oeq float %1793, 0.000000e+00
  %1804 = tail call float @llvm.fabs.f32(float %1787)
  %1805 = fcmp one float %1804, +inf
  %1806 = and i1 %1803, %1805
  %1807 = select i1 %1806, float 0.000000e+00, float %1802
  br label %1808

1808:                                             ; preds = %1796, %1785
  %1809 = phi float [ %1807, %1796 ], [ %1794, %1785 ]
  %1810 = extractelement <8 x float> %1786, i64 1
  %1811 = fmul float %1810, %1791
  %1812 = extractelement <8 x float> %280, i64 1
  %1813 = fmul float %1812, %1811
  %1814 = tail call i1 @llvm.is.fpclass.f32(float %1811, /* (sub norm) */ i32 408)
  br i1 %1814, label %1827, label %1815, !prof !4

1815:                                             ; preds = %1808
  %1816 = fpext float %1812 to double
  %1817 = fpext nnan float %1791 to double
  %1818 = fpext float %1810 to double
  %1819 = fmul double %1816, %1817
  %1820 = fmul double %1819, %1818
  %1821 = fptrunc double %1820 to float
  %1822 = fcmp oeq float %1812, 0.000000e+00
  %1823 = tail call float @llvm.fabs.f32(float %1810)
  %1824 = fcmp one float %1823, +inf
  %1825 = and i1 %1822, %1824
  %1826 = select i1 %1825, float 0.000000e+00, float %1821
  br label %1827

1827:                                             ; preds = %1815, %1808
  %1828 = phi float [ %1826, %1815 ], [ %1813, %1808 ]
  %1829 = extractelement <8 x float> %1786, i64 2
  %1830 = fmul float %1829, %1791
  %1831 = extractelement <8 x float> %280, i64 2
  %1832 = fmul float %1831, %1830
  %1833 = tail call i1 @llvm.is.fpclass.f32(float %1830, /* (sub norm) */ i32 408)
  br i1 %1833, label %1846, label %1834, !prof !4

1834:                                             ; preds = %1827
  %1835 = fpext float %1831 to double
  %1836 = fpext nnan float %1791 to double
  %1837 = fpext float %1829 to double
  %1838 = fmul double %1835, %1836
  %1839 = fmul double %1838, %1837
  %1840 = fptrunc double %1839 to float
  %1841 = fcmp oeq float %1831, 0.000000e+00
  %1842 = tail call float @llvm.fabs.f32(float %1829)
  %1843 = fcmp one float %1842, +inf
  %1844 = and i1 %1841, %1843
  %1845 = select i1 %1844, float 0.000000e+00, float %1840
  br label %1846

1846:                                             ; preds = %1834, %1827
  %1847 = phi float [ %1845, %1834 ], [ %1832, %1827 ]
  %1848 = extractelement <8 x float> %1786, i64 3
  %1849 = fmul float %1848, %1791
  %1850 = extractelement <8 x float> %280, i64 3
  %1851 = fmul float %1850, %1849
  %1852 = tail call i1 @llvm.is.fpclass.f32(float %1849, /* (sub norm) */ i32 408)
  br i1 %1852, label %1865, label %1853, !prof !4

1853:                                             ; preds = %1846
  %1854 = fpext float %1850 to double
  %1855 = fpext nnan float %1791 to double
  %1856 = fpext float %1848 to double
  %1857 = fmul double %1854, %1855
  %1858 = fmul double %1857, %1856
  %1859 = fptrunc double %1858 to float
  %1860 = fcmp oeq float %1850, 0.000000e+00
  %1861 = tail call float @llvm.fabs.f32(float %1848)
  %1862 = fcmp one float %1861, +inf
  %1863 = and i1 %1860, %1862
  %1864 = select i1 %1863, float 0.000000e+00, float %1859
  br label %1865

1865:                                             ; preds = %1853, %1846
  %1866 = phi float [ %1864, %1853 ], [ %1851, %1846 ]
  %1867 = extractelement <8 x float> %1786, i64 4
  %1868 = fmul float %1867, %1791
  %1869 = extractelement <8 x float> %280, i64 4
  %1870 = fmul float %1869, %1868
  %1871 = tail call i1 @llvm.is.fpclass.f32(float %1868, /* (sub norm) */ i32 408)
  br i1 %1871, label %1884, label %1872, !prof !4

1872:                                             ; preds = %1865
  %1873 = fpext float %1869 to double
  %1874 = fpext nnan float %1791 to double
  %1875 = fpext float %1867 to double
  %1876 = fmul double %1873, %1874
  %1877 = fmul double %1876, %1875
  %1878 = fptrunc double %1877 to float
  %1879 = fcmp oeq float %1869, 0.000000e+00
  %1880 = tail call float @llvm.fabs.f32(float %1867)
  %1881 = fcmp one float %1880, +inf
  %1882 = and i1 %1879, %1881
  %1883 = select i1 %1882, float 0.000000e+00, float %1878
  br label %1884

1884:                                             ; preds = %1872, %1865
  %1885 = phi float [ %1883, %1872 ], [ %1870, %1865 ]
  %1886 = extractelement <8 x float> %1786, i64 5
  %1887 = fmul float %1886, %1791
  %1888 = extractelement <8 x float> %280, i64 5
  %1889 = fmul float %1888, %1887
  %1890 = tail call i1 @llvm.is.fpclass.f32(float %1887, /* (sub norm) */ i32 408)
  br i1 %1890, label %1903, label %1891, !prof !4

1891:                                             ; preds = %1884
  %1892 = fpext float %1888 to double
  %1893 = fpext nnan float %1791 to double
  %1894 = fpext float %1886 to double
  %1895 = fmul double %1892, %1893
  %1896 = fmul double %1895, %1894
  %1897 = fptrunc double %1896 to float
  %1898 = fcmp oeq float %1888, 0.000000e+00
  %1899 = tail call float @llvm.fabs.f32(float %1886)
  %1900 = fcmp one float %1899, +inf
  %1901 = and i1 %1898, %1900
  %1902 = select i1 %1901, float 0.000000e+00, float %1897
  br label %1903

1903:                                             ; preds = %1891, %1884
  %1904 = phi float [ %1902, %1891 ], [ %1889, %1884 ]
  %1905 = extractelement <8 x float> %1786, i64 6
  %1906 = fmul float %1905, %1791
  %1907 = extractelement <8 x float> %280, i64 6
  %1908 = fmul float %1907, %1906
  %1909 = tail call i1 @llvm.is.fpclass.f32(float %1906, /* (sub norm) */ i32 408)
  br i1 %1909, label %1922, label %1910, !prof !4

1910:                                             ; preds = %1903
  %1911 = fpext float %1907 to double
  %1912 = fpext nnan float %1791 to double
  %1913 = fpext float %1905 to double
  %1914 = fmul double %1911, %1912
  %1915 = fmul double %1914, %1913
  %1916 = fptrunc double %1915 to float
  %1917 = fcmp oeq float %1907, 0.000000e+00
  %1918 = tail call float @llvm.fabs.f32(float %1905)
  %1919 = fcmp one float %1918, +inf
  %1920 = and i1 %1917, %1919
  %1921 = select i1 %1920, float 0.000000e+00, float %1916
  br label %1922

1922:                                             ; preds = %1910, %1903
  %1923 = phi float [ %1921, %1910 ], [ %1908, %1903 ]
  %1924 = extractelement <8 x float> %1786, i64 7
  %1925 = fmul float %1924, %1791
  %1926 = extractelement <8 x float> %280, i64 7
  %1927 = fmul float %1926, %1925
  %1928 = tail call i1 @llvm.is.fpclass.f32(float %1925, /* (sub norm) */ i32 408)
  br i1 %1928, label %1941, label %1929, !prof !4

1929:                                             ; preds = %1922
  %1930 = fpext float %1926 to double
  %1931 = fpext nnan float %1791 to double
  %1932 = fpext float %1924 to double
  %1933 = fmul double %1930, %1931
  %1934 = fmul double %1933, %1932
  %1935 = fptrunc double %1934 to float
  %1936 = fcmp oeq float %1926, 0.000000e+00
  %1937 = tail call float @llvm.fabs.f32(float %1924)
  %1938 = fcmp one float %1937, +inf
  %1939 = and i1 %1936, %1938
  %1940 = select i1 %1939, float 0.000000e+00, float %1935
  br label %1941

1941:                                             ; preds = %1929, %1922
  %1942 = phi float [ %1940, %1929 ], [ %1927, %1922 ]
  store float %1809, ptr addrspace(3) %780, align 4
  store float %1828, ptr addrspace(3) %783, align 4
  store float %1847, ptr addrspace(3) %786, align 4
  store float %1866, ptr addrspace(3) %789, align 4
  store float %1885, ptr addrspace(3) %792, align 4
  store float %1904, ptr addrspace(3) %795, align 4
  store float %1923, ptr addrspace(3) %798, align 4
  store float %1942, ptr addrspace(3) %801, align 4
  tail call void @llvm.amdgcn.wave.barrier()
  %1943 = or disjoint i64 %804, %58
  %1944 = or disjoint i64 %1943, %51
  %1945 = load <8 x float>, ptr addrspace(3) %814, align 16
  %1946 = fptrunc <8 x float> %1945 to <8 x bfloat>
  %1947 = mul i64 %1944, %26
  %1948 = add i64 %1947, %810
  %1949 = icmp ult i64 %1944, %25
  %1950 = and i1 %1949, %821
  br i1 %1950, label %1951, label %1953

1951:                                             ; preds = %1941
  %1952 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1948
  store <8 x bfloat> %1946, ptr addrspace(1) %1952, align 2
  br label %2007

1953:                                             ; preds = %1941
  %1954 = icmp ult i64 %810, %26
  %1955 = and i1 %1949, %1954
  br i1 %1955, label %1956, label %1959

1956:                                             ; preds = %1953
  %1957 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %1948
  %1958 = extractelement <8 x bfloat> %1946, i64 0
  store bfloat %1958, ptr addrspace(1) %1957, align 2
  br label %1959

1959:                                             ; preds = %1956, %1953
  %1960 = or disjoint i64 %810, 1
  %1961 = icmp ult i64 %1960, %26
  %1962 = and i1 %1949, %1961
  br i1 %1962, label %1963, label %1967

1963:                                             ; preds = %1959
  %1964 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1948
  %1965 = getelementptr i8, ptr addrspace(1) %1964, i64 2
  %1966 = extractelement <8 x bfloat> %1946, i64 1
  store bfloat %1966, ptr addrspace(1) %1965, align 2
  br label %1967

1967:                                             ; preds = %1963, %1959
  %1968 = or disjoint i64 %810, 2
  %1969 = icmp ult i64 %1968, %26
  %1970 = and i1 %1949, %1969
  br i1 %1970, label %1971, label %1975

1971:                                             ; preds = %1967
  %1972 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1948
  %1973 = getelementptr i8, ptr addrspace(1) %1972, i64 4
  %1974 = extractelement <8 x bfloat> %1946, i64 2
  store bfloat %1974, ptr addrspace(1) %1973, align 2
  br label %1975

1975:                                             ; preds = %1971, %1967
  %1976 = or disjoint i64 %810, 3
  %1977 = icmp ult i64 %1976, %26
  %1978 = and i1 %1949, %1977
  br i1 %1978, label %1979, label %1983

1979:                                             ; preds = %1975
  %1980 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1948
  %1981 = getelementptr i8, ptr addrspace(1) %1980, i64 6
  %1982 = extractelement <8 x bfloat> %1946, i64 3
  store bfloat %1982, ptr addrspace(1) %1981, align 2
  br label %1983

1983:                                             ; preds = %1979, %1975
  %1984 = or disjoint i64 %810, 4
  %1985 = icmp ult i64 %1984, %26
  %1986 = and i1 %1949, %1985
  br i1 %1986, label %1987, label %1991

1987:                                             ; preds = %1983
  %1988 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1948
  %1989 = getelementptr i8, ptr addrspace(1) %1988, i64 8
  %1990 = extractelement <8 x bfloat> %1946, i64 4
  store bfloat %1990, ptr addrspace(1) %1989, align 2
  br label %1991

1991:                                             ; preds = %1987, %1983
  %1992 = or disjoint i64 %810, 5
  %1993 = icmp ult i64 %1992, %26
  %1994 = and i1 %1949, %1993
  br i1 %1994, label %1995, label %1999

1995:                                             ; preds = %1991
  %1996 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1948
  %1997 = getelementptr i8, ptr addrspace(1) %1996, i64 10
  %1998 = extractelement <8 x bfloat> %1946, i64 5
  store bfloat %1998, ptr addrspace(1) %1997, align 2
  br label %1999

1999:                                             ; preds = %1995, %1991
  %2000 = or disjoint i64 %810, 6
  %2001 = icmp ult i64 %2000, %26
  %2002 = and i1 %1949, %2001
  br i1 %2002, label %2003, label %2007

2003:                                             ; preds = %1999
  %2004 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %1948
  %2005 = getelementptr i8, ptr addrspace(1) %2004, i64 12
  %2006 = extractelement <8 x bfloat> %1946, i64 6
  store bfloat %2006, ptr addrspace(1) %2005, align 2
  br label %2007

2007:                                             ; preds = %1999, %2003, %1951
  %2008 = or disjoint i64 %880, %58
  %2009 = or disjoint i64 %2008, %51
  %2010 = load <8 x float>, ptr addrspace(3) %887, align 16
  %2011 = fptrunc <8 x float> %2010 to <8 x bfloat>
  %2012 = mul i64 %2009, %26
  %2013 = add i64 %2012, %810
  %2014 = icmp ult i64 %2009, %25
  %2015 = and i1 %2014, %821
  br i1 %2015, label %2016, label %2018

2016:                                             ; preds = %2007
  %2017 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2013
  store <8 x bfloat> %2011, ptr addrspace(1) %2017, align 2
  br label %2072

2018:                                             ; preds = %2007
  %2019 = icmp ult i64 %810, %26
  %2020 = and i1 %2014, %2019
  br i1 %2020, label %2021, label %2024

2021:                                             ; preds = %2018
  %2022 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2013
  %2023 = extractelement <8 x bfloat> %2011, i64 0
  store bfloat %2023, ptr addrspace(1) %2022, align 2
  br label %2024

2024:                                             ; preds = %2021, %2018
  %2025 = or disjoint i64 %810, 1
  %2026 = icmp ult i64 %2025, %26
  %2027 = and i1 %2014, %2026
  br i1 %2027, label %2028, label %2032

2028:                                             ; preds = %2024
  %2029 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2013
  %2030 = getelementptr i8, ptr addrspace(1) %2029, i64 2
  %2031 = extractelement <8 x bfloat> %2011, i64 1
  store bfloat %2031, ptr addrspace(1) %2030, align 2
  br label %2032

2032:                                             ; preds = %2028, %2024
  %2033 = or disjoint i64 %810, 2
  %2034 = icmp ult i64 %2033, %26
  %2035 = and i1 %2014, %2034
  br i1 %2035, label %2036, label %2040

2036:                                             ; preds = %2032
  %2037 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2013
  %2038 = getelementptr i8, ptr addrspace(1) %2037, i64 4
  %2039 = extractelement <8 x bfloat> %2011, i64 2
  store bfloat %2039, ptr addrspace(1) %2038, align 2
  br label %2040

2040:                                             ; preds = %2036, %2032
  %2041 = or disjoint i64 %810, 3
  %2042 = icmp ult i64 %2041, %26
  %2043 = and i1 %2014, %2042
  br i1 %2043, label %2044, label %2048

2044:                                             ; preds = %2040
  %2045 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2013
  %2046 = getelementptr i8, ptr addrspace(1) %2045, i64 6
  %2047 = extractelement <8 x bfloat> %2011, i64 3
  store bfloat %2047, ptr addrspace(1) %2046, align 2
  br label %2048

2048:                                             ; preds = %2044, %2040
  %2049 = or disjoint i64 %810, 4
  %2050 = icmp ult i64 %2049, %26
  %2051 = and i1 %2014, %2050
  br i1 %2051, label %2052, label %2056

2052:                                             ; preds = %2048
  %2053 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2013
  %2054 = getelementptr i8, ptr addrspace(1) %2053, i64 8
  %2055 = extractelement <8 x bfloat> %2011, i64 4
  store bfloat %2055, ptr addrspace(1) %2054, align 2
  br label %2056

2056:                                             ; preds = %2052, %2048
  %2057 = or disjoint i64 %810, 5
  %2058 = icmp ult i64 %2057, %26
  %2059 = and i1 %2014, %2058
  br i1 %2059, label %2060, label %2064

2060:                                             ; preds = %2056
  %2061 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2013
  %2062 = getelementptr i8, ptr addrspace(1) %2061, i64 10
  %2063 = extractelement <8 x bfloat> %2011, i64 5
  store bfloat %2063, ptr addrspace(1) %2062, align 2
  br label %2064

2064:                                             ; preds = %2060, %2056
  %2065 = or disjoint i64 %810, 6
  %2066 = icmp ult i64 %2065, %26
  %2067 = and i1 %2014, %2066
  br i1 %2067, label %2068, label %2072

2068:                                             ; preds = %2064
  %2069 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2013
  %2070 = getelementptr i8, ptr addrspace(1) %2069, i64 12
  %2071 = extractelement <8 x bfloat> %2011, i64 6
  store bfloat %2071, ptr addrspace(1) %2070, align 2
  br label %2072

2072:                                             ; preds = %2064, %2068, %2016
  tail call void @llvm.amdgcn.wave.barrier()
  %2073 = or disjoint i64 %61, %116
  %2074 = or disjoint i64 %2073, 7
  %2075 = icmp ult i64 %2074, %25
  %2076 = and i1 %287, %2075
  %2077 = and i1 %292, %2076
  br i1 %2077, label %2078, label %2084

2078:                                             ; preds = %2072
  %2079 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %2073
  %2080 = load <4 x float>, ptr addrspace(1) %2079, align 16
  %2081 = getelementptr i8, ptr addrspace(1) %2079, i64 16
  %2082 = load <4 x float>, ptr addrspace(1) %2081, align 16
  %2083 = shufflevector <4 x float> %2080, <4 x float> %2082, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2132

2084:                                             ; preds = %2072
  %2085 = icmp slt i64 %2073, %25
  %2086 = select i1 %2085, i64 %2073, i64 0
  %2087 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2086
  %2088 = load float, ptr addrspace(1) %2087, align 4
  %2089 = insertelement <8 x float> poison, float %2088, i64 0
  %2090 = or disjoint i64 %61, %515
  %2091 = icmp slt i64 %2090, %25
  %2092 = select i1 %2091, i64 %2090, i64 0
  %2093 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2092
  %2094 = load float, ptr addrspace(1) %2093, align 4
  %2095 = insertelement <8 x float> %2089, float %2094, i64 1
  %2096 = or disjoint i64 %61, %521
  %2097 = icmp slt i64 %2096, %25
  %2098 = select i1 %2097, i64 %2096, i64 0
  %2099 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2098
  %2100 = load float, ptr addrspace(1) %2099, align 4
  %2101 = insertelement <8 x float> %2095, float %2100, i64 2
  %2102 = or disjoint i64 %61, %527
  %2103 = icmp slt i64 %2102, %25
  %2104 = select i1 %2103, i64 %2102, i64 0
  %2105 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2104
  %2106 = load float, ptr addrspace(1) %2105, align 4
  %2107 = insertelement <8 x float> %2101, float %2106, i64 3
  %2108 = or disjoint i64 %61, %533
  %2109 = icmp slt i64 %2108, %25
  %2110 = select i1 %2109, i64 %2108, i64 0
  %2111 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2110
  %2112 = load float, ptr addrspace(1) %2111, align 4
  %2113 = insertelement <8 x float> %2107, float %2112, i64 4
  %2114 = or disjoint i64 %61, %539
  %2115 = icmp slt i64 %2114, %25
  %2116 = select i1 %2115, i64 %2114, i64 0
  %2117 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2116
  %2118 = load float, ptr addrspace(1) %2117, align 4
  %2119 = insertelement <8 x float> %2113, float %2118, i64 5
  %2120 = or disjoint i64 %61, %545
  %2121 = icmp slt i64 %2120, %25
  %2122 = select i1 %2121, i64 %2120, i64 0
  %2123 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2122
  %2124 = load float, ptr addrspace(1) %2123, align 4
  %2125 = insertelement <8 x float> %2119, float %2124, i64 6
  %2126 = or disjoint i64 %61, %551
  %2127 = icmp slt i64 %2126, %25
  %2128 = select i1 %2127, i64 %2126, i64 0
  %2129 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2128
  %2130 = load float, ptr addrspace(1) %2129, align 4
  %2131 = insertelement <8 x float> %2125, float %2130, i64 7
  br label %2132

2132:                                             ; preds = %2078, %2084
  %2133 = phi <8 x float> [ %2131, %2084 ], [ %2083, %2078 ]
  %2134 = extractelement <8 x float> %2133, i64 0
  %2135 = load i8, ptr addrspace(1) %352, align 1
  %2136 = zext i8 %2135 to i32
  %2137 = shl nuw nsw i32 %2136, 23
  %2138 = bitcast i32 %2137 to float
  %2139 = fmul float %2134, %2138
  %2140 = extractelement <8 x float> %281, i64 0
  %2141 = fmul float %2140, %2139
  %2142 = tail call i1 @llvm.is.fpclass.f32(float %2139, /* (sub norm) */ i32 408)
  br i1 %2142, label %2155, label %2143, !prof !4

2143:                                             ; preds = %2132
  %2144 = fpext float %2140 to double
  %2145 = fpext nnan float %2138 to double
  %2146 = fpext float %2134 to double
  %2147 = fmul double %2144, %2145
  %2148 = fmul double %2147, %2146
  %2149 = fptrunc double %2148 to float
  %2150 = fcmp oeq float %2140, 0.000000e+00
  %2151 = tail call float @llvm.fabs.f32(float %2134)
  %2152 = fcmp one float %2151, +inf
  %2153 = and i1 %2150, %2152
  %2154 = select i1 %2153, float 0.000000e+00, float %2149
  br label %2155

2155:                                             ; preds = %2143, %2132
  %2156 = phi float [ %2154, %2143 ], [ %2141, %2132 ]
  %2157 = extractelement <8 x float> %2133, i64 1
  %2158 = fmul float %2157, %2138
  %2159 = extractelement <8 x float> %281, i64 1
  %2160 = fmul float %2159, %2158
  %2161 = tail call i1 @llvm.is.fpclass.f32(float %2158, /* (sub norm) */ i32 408)
  br i1 %2161, label %2174, label %2162, !prof !4

2162:                                             ; preds = %2155
  %2163 = fpext float %2159 to double
  %2164 = fpext nnan float %2138 to double
  %2165 = fpext float %2157 to double
  %2166 = fmul double %2163, %2164
  %2167 = fmul double %2166, %2165
  %2168 = fptrunc double %2167 to float
  %2169 = fcmp oeq float %2159, 0.000000e+00
  %2170 = tail call float @llvm.fabs.f32(float %2157)
  %2171 = fcmp one float %2170, +inf
  %2172 = and i1 %2169, %2171
  %2173 = select i1 %2172, float 0.000000e+00, float %2168
  br label %2174

2174:                                             ; preds = %2162, %2155
  %2175 = phi float [ %2173, %2162 ], [ %2160, %2155 ]
  %2176 = extractelement <8 x float> %2133, i64 2
  %2177 = fmul float %2176, %2138
  %2178 = extractelement <8 x float> %281, i64 2
  %2179 = fmul float %2178, %2177
  %2180 = tail call i1 @llvm.is.fpclass.f32(float %2177, /* (sub norm) */ i32 408)
  br i1 %2180, label %2193, label %2181, !prof !4

2181:                                             ; preds = %2174
  %2182 = fpext float %2178 to double
  %2183 = fpext nnan float %2138 to double
  %2184 = fpext float %2176 to double
  %2185 = fmul double %2182, %2183
  %2186 = fmul double %2185, %2184
  %2187 = fptrunc double %2186 to float
  %2188 = fcmp oeq float %2178, 0.000000e+00
  %2189 = tail call float @llvm.fabs.f32(float %2176)
  %2190 = fcmp one float %2189, +inf
  %2191 = and i1 %2188, %2190
  %2192 = select i1 %2191, float 0.000000e+00, float %2187
  br label %2193

2193:                                             ; preds = %2181, %2174
  %2194 = phi float [ %2192, %2181 ], [ %2179, %2174 ]
  %2195 = extractelement <8 x float> %2133, i64 3
  %2196 = fmul float %2195, %2138
  %2197 = extractelement <8 x float> %281, i64 3
  %2198 = fmul float %2197, %2196
  %2199 = tail call i1 @llvm.is.fpclass.f32(float %2196, /* (sub norm) */ i32 408)
  br i1 %2199, label %2212, label %2200, !prof !4

2200:                                             ; preds = %2193
  %2201 = fpext float %2197 to double
  %2202 = fpext nnan float %2138 to double
  %2203 = fpext float %2195 to double
  %2204 = fmul double %2201, %2202
  %2205 = fmul double %2204, %2203
  %2206 = fptrunc double %2205 to float
  %2207 = fcmp oeq float %2197, 0.000000e+00
  %2208 = tail call float @llvm.fabs.f32(float %2195)
  %2209 = fcmp one float %2208, +inf
  %2210 = and i1 %2207, %2209
  %2211 = select i1 %2210, float 0.000000e+00, float %2206
  br label %2212

2212:                                             ; preds = %2200, %2193
  %2213 = phi float [ %2211, %2200 ], [ %2198, %2193 ]
  %2214 = extractelement <8 x float> %2133, i64 4
  %2215 = fmul float %2214, %2138
  %2216 = extractelement <8 x float> %281, i64 4
  %2217 = fmul float %2216, %2215
  %2218 = tail call i1 @llvm.is.fpclass.f32(float %2215, /* (sub norm) */ i32 408)
  br i1 %2218, label %2231, label %2219, !prof !4

2219:                                             ; preds = %2212
  %2220 = fpext float %2216 to double
  %2221 = fpext nnan float %2138 to double
  %2222 = fpext float %2214 to double
  %2223 = fmul double %2220, %2221
  %2224 = fmul double %2223, %2222
  %2225 = fptrunc double %2224 to float
  %2226 = fcmp oeq float %2216, 0.000000e+00
  %2227 = tail call float @llvm.fabs.f32(float %2214)
  %2228 = fcmp one float %2227, +inf
  %2229 = and i1 %2226, %2228
  %2230 = select i1 %2229, float 0.000000e+00, float %2225
  br label %2231

2231:                                             ; preds = %2219, %2212
  %2232 = phi float [ %2230, %2219 ], [ %2217, %2212 ]
  %2233 = extractelement <8 x float> %2133, i64 5
  %2234 = fmul float %2233, %2138
  %2235 = extractelement <8 x float> %281, i64 5
  %2236 = fmul float %2235, %2234
  %2237 = tail call i1 @llvm.is.fpclass.f32(float %2234, /* (sub norm) */ i32 408)
  br i1 %2237, label %2250, label %2238, !prof !4

2238:                                             ; preds = %2231
  %2239 = fpext float %2235 to double
  %2240 = fpext nnan float %2138 to double
  %2241 = fpext float %2233 to double
  %2242 = fmul double %2239, %2240
  %2243 = fmul double %2242, %2241
  %2244 = fptrunc double %2243 to float
  %2245 = fcmp oeq float %2235, 0.000000e+00
  %2246 = tail call float @llvm.fabs.f32(float %2233)
  %2247 = fcmp one float %2246, +inf
  %2248 = and i1 %2245, %2247
  %2249 = select i1 %2248, float 0.000000e+00, float %2244
  br label %2250

2250:                                             ; preds = %2238, %2231
  %2251 = phi float [ %2249, %2238 ], [ %2236, %2231 ]
  %2252 = extractelement <8 x float> %2133, i64 6
  %2253 = fmul float %2252, %2138
  %2254 = extractelement <8 x float> %281, i64 6
  %2255 = fmul float %2254, %2253
  %2256 = tail call i1 @llvm.is.fpclass.f32(float %2253, /* (sub norm) */ i32 408)
  br i1 %2256, label %2269, label %2257, !prof !4

2257:                                             ; preds = %2250
  %2258 = fpext float %2254 to double
  %2259 = fpext nnan float %2138 to double
  %2260 = fpext float %2252 to double
  %2261 = fmul double %2258, %2259
  %2262 = fmul double %2261, %2260
  %2263 = fptrunc double %2262 to float
  %2264 = fcmp oeq float %2254, 0.000000e+00
  %2265 = tail call float @llvm.fabs.f32(float %2252)
  %2266 = fcmp one float %2265, +inf
  %2267 = and i1 %2264, %2266
  %2268 = select i1 %2267, float 0.000000e+00, float %2263
  br label %2269

2269:                                             ; preds = %2257, %2250
  %2270 = phi float [ %2268, %2257 ], [ %2255, %2250 ]
  %2271 = extractelement <8 x float> %2133, i64 7
  %2272 = fmul float %2271, %2138
  %2273 = extractelement <8 x float> %281, i64 7
  %2274 = fmul float %2273, %2272
  %2275 = tail call i1 @llvm.is.fpclass.f32(float %2272, /* (sub norm) */ i32 408)
  br i1 %2275, label %2288, label %2276, !prof !4

2276:                                             ; preds = %2269
  %2277 = fpext float %2273 to double
  %2278 = fpext nnan float %2138 to double
  %2279 = fpext float %2271 to double
  %2280 = fmul double %2277, %2278
  %2281 = fmul double %2280, %2279
  %2282 = fptrunc double %2281 to float
  %2283 = fcmp oeq float %2273, 0.000000e+00
  %2284 = tail call float @llvm.fabs.f32(float %2271)
  %2285 = fcmp one float %2284, +inf
  %2286 = and i1 %2283, %2285
  %2287 = select i1 %2286, float 0.000000e+00, float %2282
  br label %2288

2288:                                             ; preds = %2276, %2269
  %2289 = phi float [ %2287, %2276 ], [ %2274, %2269 ]
  store float %2156, ptr addrspace(3) %514, align 4
  store float %2175, ptr addrspace(3) %520, align 4
  store float %2194, ptr addrspace(3) %526, align 4
  store float %2213, ptr addrspace(3) %532, align 4
  store float %2232, ptr addrspace(3) %538, align 4
  store float %2251, ptr addrspace(3) %544, align 4
  store float %2270, ptr addrspace(3) %550, align 4
  store float %2289, ptr addrspace(3) %556, align 4
  %2290 = and i1 %559, %2075
  %2291 = and i1 %292, %2290
  br i1 %2291, label %2292, label %2298

2292:                                             ; preds = %2288
  %2293 = getelementptr [4 x i8], ptr addrspace(1) %30, i64 %2073
  %2294 = load <4 x float>, ptr addrspace(1) %2293, align 16
  %2295 = getelementptr i8, ptr addrspace(1) %2293, i64 16
  %2296 = load <4 x float>, ptr addrspace(1) %2295, align 16
  %2297 = shufflevector <4 x float> %2294, <4 x float> %2296, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2346

2298:                                             ; preds = %2288
  %2299 = icmp slt i64 %2073, %25
  %2300 = select i1 %2299, i64 %2073, i64 0
  %2301 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2300
  %2302 = load float, ptr addrspace(1) %2301, align 4
  %2303 = insertelement <8 x float> poison, float %2302, i64 0
  %2304 = or disjoint i64 %61, %515
  %2305 = icmp slt i64 %2304, %25
  %2306 = select i1 %2305, i64 %2304, i64 0
  %2307 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2306
  %2308 = load float, ptr addrspace(1) %2307, align 4
  %2309 = insertelement <8 x float> %2303, float %2308, i64 1
  %2310 = or disjoint i64 %61, %521
  %2311 = icmp slt i64 %2310, %25
  %2312 = select i1 %2311, i64 %2310, i64 0
  %2313 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2312
  %2314 = load float, ptr addrspace(1) %2313, align 4
  %2315 = insertelement <8 x float> %2309, float %2314, i64 2
  %2316 = or disjoint i64 %61, %527
  %2317 = icmp slt i64 %2316, %25
  %2318 = select i1 %2317, i64 %2316, i64 0
  %2319 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2318
  %2320 = load float, ptr addrspace(1) %2319, align 4
  %2321 = insertelement <8 x float> %2315, float %2320, i64 3
  %2322 = or disjoint i64 %61, %533
  %2323 = icmp slt i64 %2322, %25
  %2324 = select i1 %2323, i64 %2322, i64 0
  %2325 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2324
  %2326 = load float, ptr addrspace(1) %2325, align 4
  %2327 = insertelement <8 x float> %2321, float %2326, i64 4
  %2328 = or disjoint i64 %61, %539
  %2329 = icmp slt i64 %2328, %25
  %2330 = select i1 %2329, i64 %2328, i64 0
  %2331 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2330
  %2332 = load float, ptr addrspace(1) %2331, align 4
  %2333 = insertelement <8 x float> %2327, float %2332, i64 5
  %2334 = or disjoint i64 %61, %545
  %2335 = icmp slt i64 %2334, %25
  %2336 = select i1 %2335, i64 %2334, i64 0
  %2337 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2336
  %2338 = load float, ptr addrspace(1) %2337, align 4
  %2339 = insertelement <8 x float> %2333, float %2338, i64 6
  %2340 = or disjoint i64 %61, %551
  %2341 = icmp slt i64 %2340, %25
  %2342 = select i1 %2341, i64 %2340, i64 0
  %2343 = getelementptr inbounds [4 x i8], ptr addrspace(1) %30, i64 %2342
  %2344 = load float, ptr addrspace(1) %2343, align 4
  %2345 = insertelement <8 x float> %2339, float %2344, i64 7
  br label %2346

2346:                                             ; preds = %2292, %2298
  %2347 = phi <8 x float> [ %2345, %2298 ], [ %2297, %2292 ]
  %2348 = extractelement <8 x float> %2347, i64 0
  %2349 = load i8, ptr addrspace(1) %621, align 1
  %2350 = zext i8 %2349 to i32
  %2351 = shl nuw nsw i32 %2350, 23
  %2352 = bitcast i32 %2351 to float
  %2353 = fmul float %2348, %2352
  %2354 = extractelement <8 x float> %282, i64 0
  %2355 = fmul float %2354, %2353
  %2356 = tail call i1 @llvm.is.fpclass.f32(float %2353, /* (sub norm) */ i32 408)
  br i1 %2356, label %2369, label %2357, !prof !4

2357:                                             ; preds = %2346
  %2358 = fpext float %2354 to double
  %2359 = fpext nnan float %2352 to double
  %2360 = fpext float %2348 to double
  %2361 = fmul double %2358, %2359
  %2362 = fmul double %2361, %2360
  %2363 = fptrunc double %2362 to float
  %2364 = fcmp oeq float %2354, 0.000000e+00
  %2365 = tail call float @llvm.fabs.f32(float %2348)
  %2366 = fcmp one float %2365, +inf
  %2367 = and i1 %2364, %2366
  %2368 = select i1 %2367, float 0.000000e+00, float %2363
  br label %2369

2369:                                             ; preds = %2357, %2346
  %2370 = phi float [ %2368, %2357 ], [ %2355, %2346 ]
  %2371 = extractelement <8 x float> %2347, i64 1
  %2372 = fmul float %2371, %2352
  %2373 = extractelement <8 x float> %282, i64 1
  %2374 = fmul float %2373, %2372
  %2375 = tail call i1 @llvm.is.fpclass.f32(float %2372, /* (sub norm) */ i32 408)
  br i1 %2375, label %2388, label %2376, !prof !4

2376:                                             ; preds = %2369
  %2377 = fpext float %2373 to double
  %2378 = fpext nnan float %2352 to double
  %2379 = fpext float %2371 to double
  %2380 = fmul double %2377, %2378
  %2381 = fmul double %2380, %2379
  %2382 = fptrunc double %2381 to float
  %2383 = fcmp oeq float %2373, 0.000000e+00
  %2384 = tail call float @llvm.fabs.f32(float %2371)
  %2385 = fcmp one float %2384, +inf
  %2386 = and i1 %2383, %2385
  %2387 = select i1 %2386, float 0.000000e+00, float %2382
  br label %2388

2388:                                             ; preds = %2376, %2369
  %2389 = phi float [ %2387, %2376 ], [ %2374, %2369 ]
  %2390 = extractelement <8 x float> %2347, i64 2
  %2391 = fmul float %2390, %2352
  %2392 = extractelement <8 x float> %282, i64 2
  %2393 = fmul float %2392, %2391
  %2394 = tail call i1 @llvm.is.fpclass.f32(float %2391, /* (sub norm) */ i32 408)
  br i1 %2394, label %2407, label %2395, !prof !4

2395:                                             ; preds = %2388
  %2396 = fpext float %2392 to double
  %2397 = fpext nnan float %2352 to double
  %2398 = fpext float %2390 to double
  %2399 = fmul double %2396, %2397
  %2400 = fmul double %2399, %2398
  %2401 = fptrunc double %2400 to float
  %2402 = fcmp oeq float %2392, 0.000000e+00
  %2403 = tail call float @llvm.fabs.f32(float %2390)
  %2404 = fcmp one float %2403, +inf
  %2405 = and i1 %2402, %2404
  %2406 = select i1 %2405, float 0.000000e+00, float %2401
  br label %2407

2407:                                             ; preds = %2395, %2388
  %2408 = phi float [ %2406, %2395 ], [ %2393, %2388 ]
  %2409 = extractelement <8 x float> %2347, i64 3
  %2410 = fmul float %2409, %2352
  %2411 = extractelement <8 x float> %282, i64 3
  %2412 = fmul float %2411, %2410
  %2413 = tail call i1 @llvm.is.fpclass.f32(float %2410, /* (sub norm) */ i32 408)
  br i1 %2413, label %2426, label %2414, !prof !4

2414:                                             ; preds = %2407
  %2415 = fpext float %2411 to double
  %2416 = fpext nnan float %2352 to double
  %2417 = fpext float %2409 to double
  %2418 = fmul double %2415, %2416
  %2419 = fmul double %2418, %2417
  %2420 = fptrunc double %2419 to float
  %2421 = fcmp oeq float %2411, 0.000000e+00
  %2422 = tail call float @llvm.fabs.f32(float %2409)
  %2423 = fcmp one float %2422, +inf
  %2424 = and i1 %2421, %2423
  %2425 = select i1 %2424, float 0.000000e+00, float %2420
  br label %2426

2426:                                             ; preds = %2414, %2407
  %2427 = phi float [ %2425, %2414 ], [ %2412, %2407 ]
  %2428 = extractelement <8 x float> %2347, i64 4
  %2429 = fmul float %2428, %2352
  %2430 = extractelement <8 x float> %282, i64 4
  %2431 = fmul float %2430, %2429
  %2432 = tail call i1 @llvm.is.fpclass.f32(float %2429, /* (sub norm) */ i32 408)
  br i1 %2432, label %2445, label %2433, !prof !4

2433:                                             ; preds = %2426
  %2434 = fpext float %2430 to double
  %2435 = fpext nnan float %2352 to double
  %2436 = fpext float %2428 to double
  %2437 = fmul double %2434, %2435
  %2438 = fmul double %2437, %2436
  %2439 = fptrunc double %2438 to float
  %2440 = fcmp oeq float %2430, 0.000000e+00
  %2441 = tail call float @llvm.fabs.f32(float %2428)
  %2442 = fcmp one float %2441, +inf
  %2443 = and i1 %2440, %2442
  %2444 = select i1 %2443, float 0.000000e+00, float %2439
  br label %2445

2445:                                             ; preds = %2433, %2426
  %2446 = phi float [ %2444, %2433 ], [ %2431, %2426 ]
  %2447 = extractelement <8 x float> %2347, i64 5
  %2448 = fmul float %2447, %2352
  %2449 = extractelement <8 x float> %282, i64 5
  %2450 = fmul float %2449, %2448
  %2451 = tail call i1 @llvm.is.fpclass.f32(float %2448, /* (sub norm) */ i32 408)
  br i1 %2451, label %2464, label %2452, !prof !4

2452:                                             ; preds = %2445
  %2453 = fpext float %2449 to double
  %2454 = fpext nnan float %2352 to double
  %2455 = fpext float %2447 to double
  %2456 = fmul double %2453, %2454
  %2457 = fmul double %2456, %2455
  %2458 = fptrunc double %2457 to float
  %2459 = fcmp oeq float %2449, 0.000000e+00
  %2460 = tail call float @llvm.fabs.f32(float %2447)
  %2461 = fcmp one float %2460, +inf
  %2462 = and i1 %2459, %2461
  %2463 = select i1 %2462, float 0.000000e+00, float %2458
  br label %2464

2464:                                             ; preds = %2452, %2445
  %2465 = phi float [ %2463, %2452 ], [ %2450, %2445 ]
  %2466 = extractelement <8 x float> %2347, i64 6
  %2467 = fmul float %2466, %2352
  %2468 = extractelement <8 x float> %282, i64 6
  %2469 = fmul float %2468, %2467
  %2470 = tail call i1 @llvm.is.fpclass.f32(float %2467, /* (sub norm) */ i32 408)
  br i1 %2470, label %2483, label %2471, !prof !4

2471:                                             ; preds = %2464
  %2472 = fpext float %2468 to double
  %2473 = fpext nnan float %2352 to double
  %2474 = fpext float %2466 to double
  %2475 = fmul double %2472, %2473
  %2476 = fmul double %2475, %2474
  %2477 = fptrunc double %2476 to float
  %2478 = fcmp oeq float %2468, 0.000000e+00
  %2479 = tail call float @llvm.fabs.f32(float %2466)
  %2480 = fcmp one float %2479, +inf
  %2481 = and i1 %2478, %2480
  %2482 = select i1 %2481, float 0.000000e+00, float %2477
  br label %2483

2483:                                             ; preds = %2471, %2464
  %2484 = phi float [ %2482, %2471 ], [ %2469, %2464 ]
  %2485 = extractelement <8 x float> %2347, i64 7
  %2486 = fmul float %2485, %2352
  %2487 = extractelement <8 x float> %282, i64 7
  %2488 = fmul float %2487, %2486
  %2489 = tail call i1 @llvm.is.fpclass.f32(float %2486, /* (sub norm) */ i32 408)
  br i1 %2489, label %2502, label %2490, !prof !4

2490:                                             ; preds = %2483
  %2491 = fpext float %2487 to double
  %2492 = fpext nnan float %2352 to double
  %2493 = fpext float %2485 to double
  %2494 = fmul double %2491, %2492
  %2495 = fmul double %2494, %2493
  %2496 = fptrunc double %2495 to float
  %2497 = fcmp oeq float %2487, 0.000000e+00
  %2498 = tail call float @llvm.fabs.f32(float %2485)
  %2499 = fcmp one float %2498, +inf
  %2500 = and i1 %2497, %2499
  %2501 = select i1 %2500, float 0.000000e+00, float %2496
  br label %2502

2502:                                             ; preds = %2490, %2483
  %2503 = phi float [ %2501, %2490 ], [ %2488, %2483 ]
  store float %2370, ptr addrspace(3) %780, align 4
  store float %2389, ptr addrspace(3) %783, align 4
  store float %2408, ptr addrspace(3) %786, align 4
  store float %2427, ptr addrspace(3) %789, align 4
  store float %2446, ptr addrspace(3) %792, align 4
  store float %2465, ptr addrspace(3) %795, align 4
  store float %2484, ptr addrspace(3) %798, align 4
  store float %2503, ptr addrspace(3) %801, align 4
  tail call void @llvm.amdgcn.wave.barrier()
  %2504 = or disjoint i64 %804, %60
  %2505 = or disjoint i64 %2504, %51
  %2506 = load <8 x float>, ptr addrspace(3) %814, align 16
  %2507 = fptrunc <8 x float> %2506 to <8 x bfloat>
  %2508 = mul i64 %2505, %26
  %2509 = add i64 %2508, %810
  %2510 = icmp ult i64 %2505, %25
  %2511 = and i1 %2510, %821
  br i1 %2511, label %2512, label %2514

2512:                                             ; preds = %2502
  %2513 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2509
  store <8 x bfloat> %2507, ptr addrspace(1) %2513, align 2
  br label %2568

2514:                                             ; preds = %2502
  %2515 = icmp ult i64 %810, %26
  %2516 = and i1 %2510, %2515
  br i1 %2516, label %2517, label %2520

2517:                                             ; preds = %2514
  %2518 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2509
  %2519 = extractelement <8 x bfloat> %2507, i64 0
  store bfloat %2519, ptr addrspace(1) %2518, align 2
  br label %2520

2520:                                             ; preds = %2517, %2514
  %2521 = or disjoint i64 %810, 1
  %2522 = icmp ult i64 %2521, %26
  %2523 = and i1 %2510, %2522
  br i1 %2523, label %2524, label %2528

2524:                                             ; preds = %2520
  %2525 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2509
  %2526 = getelementptr i8, ptr addrspace(1) %2525, i64 2
  %2527 = extractelement <8 x bfloat> %2507, i64 1
  store bfloat %2527, ptr addrspace(1) %2526, align 2
  br label %2528

2528:                                             ; preds = %2524, %2520
  %2529 = or disjoint i64 %810, 2
  %2530 = icmp ult i64 %2529, %26
  %2531 = and i1 %2510, %2530
  br i1 %2531, label %2532, label %2536

2532:                                             ; preds = %2528
  %2533 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2509
  %2534 = getelementptr i8, ptr addrspace(1) %2533, i64 4
  %2535 = extractelement <8 x bfloat> %2507, i64 2
  store bfloat %2535, ptr addrspace(1) %2534, align 2
  br label %2536

2536:                                             ; preds = %2532, %2528
  %2537 = or disjoint i64 %810, 3
  %2538 = icmp ult i64 %2537, %26
  %2539 = and i1 %2510, %2538
  br i1 %2539, label %2540, label %2544

2540:                                             ; preds = %2536
  %2541 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2509
  %2542 = getelementptr i8, ptr addrspace(1) %2541, i64 6
  %2543 = extractelement <8 x bfloat> %2507, i64 3
  store bfloat %2543, ptr addrspace(1) %2542, align 2
  br label %2544

2544:                                             ; preds = %2540, %2536
  %2545 = or disjoint i64 %810, 4
  %2546 = icmp ult i64 %2545, %26
  %2547 = and i1 %2510, %2546
  br i1 %2547, label %2548, label %2552

2548:                                             ; preds = %2544
  %2549 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2509
  %2550 = getelementptr i8, ptr addrspace(1) %2549, i64 8
  %2551 = extractelement <8 x bfloat> %2507, i64 4
  store bfloat %2551, ptr addrspace(1) %2550, align 2
  br label %2552

2552:                                             ; preds = %2548, %2544
  %2553 = or disjoint i64 %810, 5
  %2554 = icmp ult i64 %2553, %26
  %2555 = and i1 %2510, %2554
  br i1 %2555, label %2556, label %2560

2556:                                             ; preds = %2552
  %2557 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2509
  %2558 = getelementptr i8, ptr addrspace(1) %2557, i64 10
  %2559 = extractelement <8 x bfloat> %2507, i64 5
  store bfloat %2559, ptr addrspace(1) %2558, align 2
  br label %2560

2560:                                             ; preds = %2556, %2552
  %2561 = or disjoint i64 %810, 6
  %2562 = icmp ult i64 %2561, %26
  %2563 = and i1 %2510, %2562
  br i1 %2563, label %2564, label %2568

2564:                                             ; preds = %2560
  %2565 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2509
  %2566 = getelementptr i8, ptr addrspace(1) %2565, i64 12
  %2567 = extractelement <8 x bfloat> %2507, i64 6
  store bfloat %2567, ptr addrspace(1) %2566, align 2
  br label %2568

2568:                                             ; preds = %2560, %2564, %2512
  %2569 = or disjoint i64 %880, %60
  %2570 = or disjoint i64 %2569, %51
  %2571 = load <8 x float>, ptr addrspace(3) %887, align 16
  %2572 = fptrunc <8 x float> %2571 to <8 x bfloat>
  %2573 = mul i64 %2570, %26
  %2574 = add i64 %2573, %810
  %2575 = icmp ult i64 %2570, %25
  %2576 = and i1 %2575, %821
  br i1 %2576, label %2577, label %2579

2577:                                             ; preds = %2568
  %2578 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  store <8 x bfloat> %2572, ptr addrspace(1) %2578, align 2
  br label %2633

2579:                                             ; preds = %2568
  %2580 = icmp ult i64 %810, %26
  %2581 = and i1 %2575, %2580
  br i1 %2581, label %2582, label %2585

2582:                                             ; preds = %2579
  %2583 = getelementptr inbounds [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2584 = extractelement <8 x bfloat> %2572, i64 0
  store bfloat %2584, ptr addrspace(1) %2583, align 2
  br label %2585

2585:                                             ; preds = %2582, %2579
  %2586 = or disjoint i64 %810, 1
  %2587 = icmp ult i64 %2586, %26
  %2588 = and i1 %2575, %2587
  br i1 %2588, label %2589, label %2593

2589:                                             ; preds = %2585
  %2590 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2591 = getelementptr i8, ptr addrspace(1) %2590, i64 2
  %2592 = extractelement <8 x bfloat> %2572, i64 1
  store bfloat %2592, ptr addrspace(1) %2591, align 2
  br label %2593

2593:                                             ; preds = %2589, %2585
  %2594 = or disjoint i64 %810, 2
  %2595 = icmp ult i64 %2594, %26
  %2596 = and i1 %2575, %2595
  br i1 %2596, label %2597, label %2601

2597:                                             ; preds = %2593
  %2598 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2599 = getelementptr i8, ptr addrspace(1) %2598, i64 4
  %2600 = extractelement <8 x bfloat> %2572, i64 2
  store bfloat %2600, ptr addrspace(1) %2599, align 2
  br label %2601

2601:                                             ; preds = %2597, %2593
  %2602 = or disjoint i64 %810, 3
  %2603 = icmp ult i64 %2602, %26
  %2604 = and i1 %2575, %2603
  br i1 %2604, label %2605, label %2609

2605:                                             ; preds = %2601
  %2606 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2607 = getelementptr i8, ptr addrspace(1) %2606, i64 6
  %2608 = extractelement <8 x bfloat> %2572, i64 3
  store bfloat %2608, ptr addrspace(1) %2607, align 2
  br label %2609

2609:                                             ; preds = %2605, %2601
  %2610 = or disjoint i64 %810, 4
  %2611 = icmp ult i64 %2610, %26
  %2612 = and i1 %2575, %2611
  br i1 %2612, label %2613, label %2617

2613:                                             ; preds = %2609
  %2614 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2615 = getelementptr i8, ptr addrspace(1) %2614, i64 8
  %2616 = extractelement <8 x bfloat> %2572, i64 4
  store bfloat %2616, ptr addrspace(1) %2615, align 2
  br label %2617

2617:                                             ; preds = %2613, %2609
  %2618 = or disjoint i64 %810, 5
  %2619 = icmp ult i64 %2618, %26
  %2620 = and i1 %2575, %2619
  br i1 %2620, label %2621, label %2625

2621:                                             ; preds = %2617
  %2622 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2623 = getelementptr i8, ptr addrspace(1) %2622, i64 10
  %2624 = extractelement <8 x bfloat> %2572, i64 5
  store bfloat %2624, ptr addrspace(1) %2623, align 2
  br label %2625

2625:                                             ; preds = %2621, %2617
  %2626 = or disjoint i64 %810, 6
  %2627 = icmp ult i64 %2626, %26
  %2628 = and i1 %2575, %2627
  br i1 %2628, label %2629, label %2633

2629:                                             ; preds = %2625
  %2630 = getelementptr [2 x i8], ptr addrspace(1) %28, i64 %2574
  %2631 = getelementptr i8, ptr addrspace(1) %2630, i64 12
  %2632 = extractelement <8 x bfloat> %2572, i64 6
  store bfloat %2632, ptr addrspace(1) %2631, align 2
  br label %2633

2633:                                             ; preds = %2625, %2629, %2577
  tail call void @llvm.amdgcn.wave.barrier()
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.wave.barrier() #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.is.fpclass.f32(float, i32 immarg) #6

attributes #0 = { norecurse nounwind "amdgpu-flat-work-group-size"="256,256" "amdgpu-no-cluster-id-x" "amdgpu-no-cluster-id-y" "amdgpu-no-cluster-id-z" "amdgpu-no-completion-action" "amdgpu-no-default-queue" "amdgpu-no-dispatch-id" "amdgpu-no-dispatch-ptr" "amdgpu-no-flat-scratch-init" "amdgpu-no-heap-ptr" "amdgpu-no-hostcall-ptr" "amdgpu-no-implicitarg-ptr" "amdgpu-no-lds-kernel-id" "amdgpu-no-multigrid-sync-arg" "amdgpu-no-queue-ptr" "amdgpu-no-workgroup-id-x" "amdgpu-no-workgroup-id-y" "amdgpu-no-workgroup-id-z" "amdgpu-no-workitem-id-x" "amdgpu-no-workitem-id-y" "amdgpu-no-workitem-id-z" "amdgpu-no-wwm" "target-cpu"="gfx1201" "target-features"="-cumode,+wavefrontsize32,-wavefrontsize64" "uniform-work-group-size" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #3 = { convergent mustprogress nocallback nofree nounwind willreturn "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #4 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #5 = { convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
!3 = !{}
!4 = !{!"branch_weights", !"expected", i32 2000, i32 1}
