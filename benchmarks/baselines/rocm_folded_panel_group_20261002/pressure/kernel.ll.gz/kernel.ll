; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal addrspace(3) global [5120 x i8] undef

define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) #0 !reqd_work_group_size !1 {
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %20, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, ptr %21, 1
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, i64 %22, 2
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %23, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %24, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, ptr %16, 1
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 %17, 2
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 %18, 3, 0
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %19, 4, 0
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %10, 0
  %40 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, ptr %11, 1
  %41 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, i64 %12, 2
  %42 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %41, i64 %13, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %42, i64 %14, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %45 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %44, ptr %6, 1
  %46 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %45, i64 %7, 2
  %47 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, i64 %8, 3, 0
  %48 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, i64 %9, 4, 0
  %49 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %50 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %49, ptr %1, 1
  %51 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %50, i64 %2, 2
  %52 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %51, i64 %3, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %52, i64 %4, 4, 0
  %54 = call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %55 = sext i32 %54 to i64
  %56 = urem i64 %55, 32
  %57 = urem i64 %56, 16
  %58 = udiv i64 %56, 16
  %59 = udiv i64 %55, 32
  %60 = udiv i64 %59, 2
  %61 = urem i64 %59, 2
  %62 = call i32 @llvm.amdgcn.workgroup.id.x()
  %63 = sext i32 %62 to i64
  %64 = add i64 %25, 255
  %65 = udiv i64 %64, 256
  %66 = add i64 %26, 63
  %67 = udiv i64 %66, 64
  %68 = mul i64 %67, 4
  %69 = udiv i64 %63, %68
  %70 = mul i64 %69, 4
  %71 = sub i64 %65, %70
  %72 = icmp ult i64 %71, 4
  %73 = select i1 %72, i64 %71, i64 4
  %74 = urem i64 %63, %68
  %75 = urem i64 %74, %73
  %76 = add i64 %70, %75
  %77 = udiv i64 %74, %73
  %78 = mul i64 %76, 256
  %79 = mul i64 %77, 64
  %80 = mul i64 %60, 64
  %81 = mul i64 %61, 32
  %82 = add i64 %78, %80
  %83 = add i64 %80, 16
  %84 = add i64 %78, %83
  %85 = add i64 %80, 32
  %86 = add i64 %78, %85
  %87 = add i64 %80, 48
  %88 = add i64 %78, %87
  %89 = add i64 %79, %81
  %90 = add i64 %81, 16
  %91 = add i64 %79, %90
  %92 = udiv i64 %55, 4
  %93 = urem i64 %55, 4
  %94 = mul i64 %93, 16
  %95 = add i64 %78, %92
  %96 = mul i64 %95, %27
  %97 = add i64 %96, %94
  %98 = mul i64 %92, 80
  %99 = add i64 %98, %94
  %100 = add i64 %55, 256
  %101 = udiv i64 %100, 4
  %102 = urem i64 %100, 4
  %103 = mul i64 %102, 16
  %104 = add i64 %78, %101
  %105 = mul i64 %104, %27
  %106 = add i64 %105, %103
  %107 = mul i64 %101, 80
  %108 = add i64 %107, %103
  %109 = add i64 %55, 512
  %110 = udiv i64 %109, 4
  %111 = urem i64 %109, 4
  %112 = mul i64 %111, 16
  %113 = add i64 %78, %110
  %114 = mul i64 %113, %27
  %115 = add i64 %114, %112
  %116 = mul i64 %110, 80
  %117 = add i64 %116, %112
  %118 = add i64 %55, 768
  %119 = udiv i64 %118, 4
  %120 = urem i64 %118, 4
  %121 = mul i64 %120, 16
  %122 = add i64 %78, %119
  %123 = mul i64 %122, %27
  %124 = add i64 %123, %121
  %125 = mul i64 %119, 80
  %126 = add i64 %125, %121
  %127 = udiv i64 %55, 4
  %128 = urem i64 %55, 4
  %129 = mul i64 %128, 16
  %130 = add i64 %79, %127
  %131 = mul i64 %130, %27
  %132 = add i64 %131, %129
  %133 = mul i64 %127, 80
  %134 = add i64 %133, %129
  %135 = icmp uge i64 %27, 64
  call void @llvm.assume(i1 %135)
  %136 = udiv i64 %27, 64
  %137 = sub i64 %27, 64
  %138 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %139 = getelementptr i8, ptr %138, i64 %97
  %140 = load <16 x i8>, ptr %139, align 16
  %141 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %142 = getelementptr i8, ptr %141, i64 %106
  %143 = load <16 x i8>, ptr %142, align 16
  %144 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %145 = getelementptr i8, ptr %144, i64 %115
  %146 = load <16 x i8>, ptr %145, align 16
  %147 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %148 = getelementptr i8, ptr %147, i64 %124
  %149 = load <16 x i8>, ptr %148, align 16
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %140, ptr addrspace(3) %150, align 16
  %151 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %143, ptr addrspace(3) %151, align 16
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %146, ptr addrspace(3) %152, align 16
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %149, ptr addrspace(3) %153, align 16
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %155 = getelementptr i8, ptr %154, i64 %132
  %156 = load <16 x i8>, ptr %155, align 16
  %157 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %156, ptr addrspace(3) %157, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  br label %158

158:                                              ; preds = %169, %28
  %159 = phi i64 [ %416, %169 ], [ 0, %28 ]
  %160 = phi <8 x float> [ %403, %169 ], [ zeroinitializer, %28 ]
  %161 = phi <8 x float> [ %404, %169 ], [ zeroinitializer, %28 ]
  %162 = phi <8 x float> [ %405, %169 ], [ zeroinitializer, %28 ]
  %163 = phi <8 x float> [ %406, %169 ], [ zeroinitializer, %28 ]
  %164 = phi <8 x float> [ %407, %169 ], [ zeroinitializer, %28 ]
  %165 = phi <8 x float> [ %408, %169 ], [ zeroinitializer, %28 ]
  %166 = phi <8 x float> [ %409, %169 ], [ zeroinitializer, %28 ]
  %167 = phi <8 x float> [ %410, %169 ], [ zeroinitializer, %28 ]
  %168 = icmp slt i64 %159, %136
  br i1 %168, label %169, label %417

169:                                              ; preds = %158
  %170 = mul i64 %159, 64
  %171 = add i64 %170, 64
  %172 = call i64 @llvm.umin.i64(i64 %171, i64 %137)
  %173 = add i64 %97, %172
  %174 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %175 = getelementptr i8, ptr %174, i64 %173
  %176 = load <16 x i8>, ptr %175, align 16
  %177 = add i64 %106, %172
  %178 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %179 = getelementptr i8, ptr %178, i64 %177
  %180 = load <16 x i8>, ptr %179, align 16
  %181 = add i64 %115, %172
  %182 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %183 = getelementptr i8, ptr %182, i64 %181
  %184 = load <16 x i8>, ptr %183, align 16
  %185 = add i64 %124, %172
  %186 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %187 = getelementptr i8, ptr %186, i64 %185
  %188 = load <16 x i8>, ptr %187, align 16
  %189 = add i64 %132, %172
  %190 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %191 = getelementptr i8, ptr %190, i64 %189
  %192 = load <16 x i8>, ptr %191, align 16
  %193 = mul i64 %58, 8
  %194 = add i64 %80, %57
  %195 = mul i64 %194, 80
  %196 = add i64 %195, %193
  %197 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %196
  %198 = load <8 x i8>, ptr addrspace(3) %197, align 1
  %199 = bitcast <8 x i8> %198 to <2 x i32>
  %200 = mul i64 %58, 8
  %201 = add i64 %83, %57
  %202 = mul i64 %201, 80
  %203 = add i64 %202, %200
  %204 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %203
  %205 = load <8 x i8>, ptr addrspace(3) %204, align 1
  %206 = bitcast <8 x i8> %205 to <2 x i32>
  %207 = mul i64 %58, 8
  %208 = add i64 %85, %57
  %209 = mul i64 %208, 80
  %210 = add i64 %209, %207
  %211 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %210
  %212 = load <8 x i8>, ptr addrspace(3) %211, align 1
  %213 = bitcast <8 x i8> %212 to <2 x i32>
  %214 = mul i64 %58, 8
  %215 = add i64 %87, %57
  %216 = mul i64 %215, 80
  %217 = add i64 %216, %214
  %218 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %217
  %219 = load <8 x i8>, ptr addrspace(3) %218, align 1
  %220 = bitcast <8 x i8> %219 to <2 x i32>
  %221 = mul i64 %58, 8
  %222 = add i64 %81, %57
  %223 = mul i64 %222, 80
  %224 = add i64 %223, %221
  %225 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %224
  %226 = load <8 x i8>, ptr addrspace(3) %225, align 1
  %227 = bitcast <8 x i8> %226 to <2 x i32>
  %228 = mul i64 %58, 8
  %229 = add i64 %90, %57
  %230 = mul i64 %229, 80
  %231 = add i64 %230, %228
  %232 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %231
  %233 = load <8 x i8>, ptr addrspace(3) %232, align 1
  %234 = bitcast <8 x i8> %233 to <2 x i32>
  %235 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %227, <8 x float> %160)
  %236 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %199, <2 x i32> %234, <8 x float> %161)
  %237 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %227, <8 x float> %162)
  %238 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %206, <2 x i32> %234, <8 x float> %163)
  %239 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %227, <8 x float> %164)
  %240 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %213, <2 x i32> %234, <8 x float> %165)
  %241 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %227, <8 x float> %166)
  %242 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %220, <2 x i32> %234, <8 x float> %167)
  call void @llvm.amdgcn.sched.group.barrier(i32 256, i32 6, i32 0)
  call void @llvm.amdgcn.sched.group.barrier(i32 8, i32 8, i32 0)
  %243 = mul i64 %58, 8
  %244 = add i64 %80, %57
  %245 = add i64 %243, 16
  %246 = mul i64 %244, 80
  %247 = add i64 %246, %245
  %248 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %247
  %249 = load <8 x i8>, ptr addrspace(3) %248, align 1
  %250 = bitcast <8 x i8> %249 to <2 x i32>
  %251 = mul i64 %58, 8
  %252 = add i64 %83, %57
  %253 = add i64 %251, 16
  %254 = mul i64 %252, 80
  %255 = add i64 %254, %253
  %256 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %255
  %257 = load <8 x i8>, ptr addrspace(3) %256, align 1
  %258 = bitcast <8 x i8> %257 to <2 x i32>
  %259 = mul i64 %58, 8
  %260 = add i64 %85, %57
  %261 = add i64 %259, 16
  %262 = mul i64 %260, 80
  %263 = add i64 %262, %261
  %264 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %263
  %265 = load <8 x i8>, ptr addrspace(3) %264, align 1
  %266 = bitcast <8 x i8> %265 to <2 x i32>
  %267 = mul i64 %58, 8
  %268 = add i64 %87, %57
  %269 = add i64 %267, 16
  %270 = mul i64 %268, 80
  %271 = add i64 %270, %269
  %272 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %271
  %273 = load <8 x i8>, ptr addrspace(3) %272, align 1
  %274 = bitcast <8 x i8> %273 to <2 x i32>
  %275 = mul i64 %58, 8
  %276 = add i64 %275, 16
  %277 = add i64 %81, %57
  %278 = mul i64 %277, 80
  %279 = add i64 %278, %276
  %280 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %279
  %281 = load <8 x i8>, ptr addrspace(3) %280, align 1
  %282 = bitcast <8 x i8> %281 to <2 x i32>
  %283 = mul i64 %58, 8
  %284 = add i64 %283, 16
  %285 = add i64 %90, %57
  %286 = mul i64 %285, 80
  %287 = add i64 %286, %284
  %288 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %287
  %289 = load <8 x i8>, ptr addrspace(3) %288, align 1
  %290 = bitcast <8 x i8> %289 to <2 x i32>
  %291 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %282, <8 x float> %235)
  %292 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %290, <8 x float> %236)
  %293 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %282, <8 x float> %237)
  %294 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %290, <8 x float> %238)
  %295 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %282, <8 x float> %239)
  %296 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %266, <2 x i32> %290, <8 x float> %240)
  %297 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %282, <8 x float> %241)
  %298 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %290, <8 x float> %242)
  call void @llvm.amdgcn.sched.group.barrier(i32 256, i32 6, i32 0)
  call void @llvm.amdgcn.sched.group.barrier(i32 8, i32 8, i32 0)
  %299 = mul i64 %58, 8
  %300 = add i64 %80, %57
  %301 = add i64 %299, 32
  %302 = mul i64 %300, 80
  %303 = add i64 %302, %301
  %304 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %303
  %305 = load <8 x i8>, ptr addrspace(3) %304, align 1
  %306 = bitcast <8 x i8> %305 to <2 x i32>
  %307 = mul i64 %58, 8
  %308 = add i64 %83, %57
  %309 = add i64 %307, 32
  %310 = mul i64 %308, 80
  %311 = add i64 %310, %309
  %312 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %311
  %313 = load <8 x i8>, ptr addrspace(3) %312, align 1
  %314 = bitcast <8 x i8> %313 to <2 x i32>
  %315 = mul i64 %58, 8
  %316 = add i64 %85, %57
  %317 = add i64 %315, 32
  %318 = mul i64 %316, 80
  %319 = add i64 %318, %317
  %320 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %319
  %321 = load <8 x i8>, ptr addrspace(3) %320, align 1
  %322 = bitcast <8 x i8> %321 to <2 x i32>
  %323 = mul i64 %58, 8
  %324 = add i64 %87, %57
  %325 = add i64 %323, 32
  %326 = mul i64 %324, 80
  %327 = add i64 %326, %325
  %328 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %327
  %329 = load <8 x i8>, ptr addrspace(3) %328, align 1
  %330 = bitcast <8 x i8> %329 to <2 x i32>
  %331 = mul i64 %58, 8
  %332 = add i64 %331, 32
  %333 = add i64 %81, %57
  %334 = mul i64 %333, 80
  %335 = add i64 %334, %332
  %336 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %335
  %337 = load <8 x i8>, ptr addrspace(3) %336, align 1
  %338 = bitcast <8 x i8> %337 to <2 x i32>
  %339 = mul i64 %58, 8
  %340 = add i64 %339, 32
  %341 = add i64 %90, %57
  %342 = mul i64 %341, 80
  %343 = add i64 %342, %340
  %344 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %343
  %345 = load <8 x i8>, ptr addrspace(3) %344, align 1
  %346 = bitcast <8 x i8> %345 to <2 x i32>
  %347 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %338, <8 x float> %291)
  %348 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %346, <8 x float> %292)
  %349 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %338, <8 x float> %293)
  %350 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %346, <8 x float> %294)
  %351 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %338, <8 x float> %295)
  %352 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %322, <2 x i32> %346, <8 x float> %296)
  %353 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %338, <8 x float> %297)
  %354 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %330, <2 x i32> %346, <8 x float> %298)
  call void @llvm.amdgcn.sched.group.barrier(i32 256, i32 6, i32 0)
  call void @llvm.amdgcn.sched.group.barrier(i32 8, i32 8, i32 0)
  %355 = mul i64 %58, 8
  %356 = add i64 %80, %57
  %357 = add i64 %355, 48
  %358 = mul i64 %356, 80
  %359 = add i64 %358, %357
  %360 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %359
  %361 = load <8 x i8>, ptr addrspace(3) %360, align 1
  %362 = bitcast <8 x i8> %361 to <2 x i32>
  %363 = mul i64 %58, 8
  %364 = add i64 %83, %57
  %365 = add i64 %363, 48
  %366 = mul i64 %364, 80
  %367 = add i64 %366, %365
  %368 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %367
  %369 = load <8 x i8>, ptr addrspace(3) %368, align 1
  %370 = bitcast <8 x i8> %369 to <2 x i32>
  %371 = mul i64 %58, 8
  %372 = add i64 %85, %57
  %373 = add i64 %371, 48
  %374 = mul i64 %372, 80
  %375 = add i64 %374, %373
  %376 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %375
  %377 = load <8 x i8>, ptr addrspace(3) %376, align 1
  %378 = bitcast <8 x i8> %377 to <2 x i32>
  %379 = mul i64 %58, 8
  %380 = add i64 %87, %57
  %381 = add i64 %379, 48
  %382 = mul i64 %380, 80
  %383 = add i64 %382, %381
  %384 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %383
  %385 = load <8 x i8>, ptr addrspace(3) %384, align 1
  %386 = bitcast <8 x i8> %385 to <2 x i32>
  %387 = mul i64 %58, 8
  %388 = add i64 %387, 48
  %389 = add i64 %81, %57
  %390 = mul i64 %389, 80
  %391 = add i64 %390, %388
  %392 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %391
  %393 = load <8 x i8>, ptr addrspace(3) %392, align 1
  %394 = bitcast <8 x i8> %393 to <2 x i32>
  %395 = mul i64 %58, 8
  %396 = add i64 %395, 48
  %397 = add i64 %90, %57
  %398 = mul i64 %397, 80
  %399 = add i64 %398, %396
  %400 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %399
  %401 = load <8 x i8>, ptr addrspace(3) %400, align 1
  %402 = bitcast <8 x i8> %401 to <2 x i32>
  %403 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %394, <8 x float> %347)
  %404 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %402, <8 x float> %348)
  %405 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %394, <8 x float> %349)
  %406 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %402, <8 x float> %350)
  %407 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %394, <8 x float> %351)
  %408 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %378, <2 x i32> %402, <8 x float> %352)
  %409 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %394, <8 x float> %353)
  %410 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %386, <2 x i32> %402, <8 x float> %354)
  call void @llvm.amdgcn.sched.group.barrier(i32 256, i32 6, i32 0)
  call void @llvm.amdgcn.sched.group.barrier(i32 8, i32 8, i32 0)
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %411 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %176, ptr addrspace(3) %411, align 16
  %412 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %180, ptr addrspace(3) %412, align 16
  %413 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %184, ptr addrspace(3) %413, align 16
  %414 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %188, ptr addrspace(3) %414, align 16
  %415 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %192, ptr addrspace(3) %415, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %416 = add i64 %159, 1
  br label %158

417:                                              ; preds = %158
  %418 = mul i64 %58, 8
  %419 = add i64 %82, %418
  %420 = add i64 %89, %57
  %421 = add i64 %419, 7
  %422 = icmp ult i64 %420, %26
  %423 = icmp ult i64 %421, %25
  %424 = and i1 %423, %422
  %425 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %426 = ptrtoint ptr %425 to i64
  %427 = mul i64 %419, 4
  %428 = add i64 %426, %427
  %429 = urem i64 %428, 16
  %430 = icmp eq i64 %429, 0
  %431 = and i1 %424, %430
  br i1 %431, label %432, label %441

432:                                              ; preds = %417
  %433 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %434 = getelementptr float, ptr %433, i64 %419
  %435 = load <4 x float>, ptr %434, align 16
  %436 = add i64 %419, 4
  %437 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %438 = getelementptr float, ptr %437, i64 %436
  %439 = load <4 x float>, ptr %438, align 16
  %440 = shufflevector <4 x float> %435, <4 x float> %439, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %513

441:                                              ; preds = %417
  %442 = mul i64 %58, 8
  %443 = add i64 %82, %442
  %444 = icmp slt i64 %443, %25
  %445 = select i1 %444, i64 %443, i64 0
  %446 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %447 = getelementptr inbounds nuw float, ptr %446, i64 %445
  %448 = load float, ptr %447, align 4
  %449 = insertelement <8 x float> zeroinitializer, float %448, i64 0
  %450 = mul i64 %58, 8
  %451 = add i64 %450, 1
  %452 = add i64 %82, %451
  %453 = icmp slt i64 %452, %25
  %454 = select i1 %453, i64 %452, i64 0
  %455 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %456 = getelementptr inbounds nuw float, ptr %455, i64 %454
  %457 = load float, ptr %456, align 4
  %458 = insertelement <8 x float> %449, float %457, i64 1
  %459 = mul i64 %58, 8
  %460 = add i64 %459, 2
  %461 = add i64 %82, %460
  %462 = icmp slt i64 %461, %25
  %463 = select i1 %462, i64 %461, i64 0
  %464 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %465 = getelementptr inbounds nuw float, ptr %464, i64 %463
  %466 = load float, ptr %465, align 4
  %467 = insertelement <8 x float> %458, float %466, i64 2
  %468 = mul i64 %58, 8
  %469 = add i64 %468, 3
  %470 = add i64 %82, %469
  %471 = icmp slt i64 %470, %25
  %472 = select i1 %471, i64 %470, i64 0
  %473 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %474 = getelementptr inbounds nuw float, ptr %473, i64 %472
  %475 = load float, ptr %474, align 4
  %476 = insertelement <8 x float> %467, float %475, i64 3
  %477 = mul i64 %58, 8
  %478 = add i64 %477, 4
  %479 = add i64 %82, %478
  %480 = icmp slt i64 %479, %25
  %481 = select i1 %480, i64 %479, i64 0
  %482 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %483 = getelementptr inbounds nuw float, ptr %482, i64 %481
  %484 = load float, ptr %483, align 4
  %485 = insertelement <8 x float> %476, float %484, i64 4
  %486 = mul i64 %58, 8
  %487 = add i64 %486, 5
  %488 = add i64 %82, %487
  %489 = icmp slt i64 %488, %25
  %490 = select i1 %489, i64 %488, i64 0
  %491 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %492 = getelementptr inbounds nuw float, ptr %491, i64 %490
  %493 = load float, ptr %492, align 4
  %494 = insertelement <8 x float> %485, float %493, i64 5
  %495 = mul i64 %58, 8
  %496 = add i64 %495, 6
  %497 = add i64 %82, %496
  %498 = icmp slt i64 %497, %25
  %499 = select i1 %498, i64 %497, i64 0
  %500 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %501 = getelementptr inbounds nuw float, ptr %500, i64 %499
  %502 = load float, ptr %501, align 4
  %503 = insertelement <8 x float> %494, float %502, i64 6
  %504 = mul i64 %58, 8
  %505 = add i64 %504, 7
  %506 = add i64 %82, %505
  %507 = icmp slt i64 %506, %25
  %508 = select i1 %507, i64 %506, i64 0
  %509 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %510 = getelementptr inbounds nuw float, ptr %509, i64 %508
  %511 = load float, ptr %510, align 4
  %512 = insertelement <8 x float> %503, float %511, i64 7
  br label %513

513:                                              ; preds = %432, %441
  %514 = phi <8 x float> [ %512, %441 ], [ %440, %432 ]
  br label %515

515:                                              ; preds = %513
  %516 = add i64 %89, %57
  %517 = icmp slt i64 %516, %26
  %518 = select i1 %517, i64 %516, i64 0
  %519 = extractelement <8 x float> %514, i64 0
  %520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %521 = getelementptr inbounds nuw i8, ptr %520, i64 %518
  %522 = load i8, ptr %521, align 1
  %523 = zext i8 %522 to i32
  %524 = shl i32 %523, 23
  %525 = bitcast i32 %524 to float
  %526 = fmul float %525, %519
  %527 = extractelement <8 x float> %160, i64 0
  %528 = fmul float %527, %526
  %529 = call float @llvm.fabs.f32(float %526)
  %530 = fcmp olt float %529, +inf
  %531 = fcmp one float %526, 0.000000e+00
  %532 = and i1 %530, %531
  br i1 %532, label %533, label %534

533:                                              ; preds = %515
  br label %546

534:                                              ; preds = %515
  %535 = fpext float %527 to double
  %536 = fpext float %525 to double
  %537 = fpext float %519 to double
  %538 = fmul double %535, %536
  %539 = fmul double %538, %537
  %540 = fptrunc double %539 to float
  %541 = fcmp oeq float %527, 0.000000e+00
  %542 = call float @llvm.fabs.f32(float %519)
  %543 = fcmp olt float %542, +inf
  %544 = and i1 %541, %543
  %545 = select i1 %544, float 0.000000e+00, float %540
  br label %546

546:                                              ; preds = %533, %534
  %547 = phi float [ %545, %534 ], [ %528, %533 ]
  br label %548

548:                                              ; preds = %546
  %549 = add i64 %89, %57
  %550 = icmp slt i64 %549, %26
  %551 = select i1 %550, i64 %549, i64 0
  %552 = extractelement <8 x float> %514, i64 1
  %553 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %554 = getelementptr inbounds nuw i8, ptr %553, i64 %551
  %555 = load i8, ptr %554, align 1
  %556 = zext i8 %555 to i32
  %557 = shl i32 %556, 23
  %558 = bitcast i32 %557 to float
  %559 = fmul float %558, %552
  %560 = extractelement <8 x float> %160, i64 1
  %561 = fmul float %560, %559
  %562 = call float @llvm.fabs.f32(float %559)
  %563 = fcmp olt float %562, +inf
  %564 = fcmp one float %559, 0.000000e+00
  %565 = and i1 %563, %564
  br i1 %565, label %566, label %567

566:                                              ; preds = %548
  br label %579

567:                                              ; preds = %548
  %568 = fpext float %560 to double
  %569 = fpext float %558 to double
  %570 = fpext float %552 to double
  %571 = fmul double %568, %569
  %572 = fmul double %571, %570
  %573 = fptrunc double %572 to float
  %574 = fcmp oeq float %560, 0.000000e+00
  %575 = call float @llvm.fabs.f32(float %552)
  %576 = fcmp olt float %575, +inf
  %577 = and i1 %574, %576
  %578 = select i1 %577, float 0.000000e+00, float %573
  br label %579

579:                                              ; preds = %566, %567
  %580 = phi float [ %578, %567 ], [ %561, %566 ]
  br label %581

581:                                              ; preds = %579
  %582 = add i64 %89, %57
  %583 = icmp slt i64 %582, %26
  %584 = select i1 %583, i64 %582, i64 0
  %585 = extractelement <8 x float> %514, i64 2
  %586 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %587 = getelementptr inbounds nuw i8, ptr %586, i64 %584
  %588 = load i8, ptr %587, align 1
  %589 = zext i8 %588 to i32
  %590 = shl i32 %589, 23
  %591 = bitcast i32 %590 to float
  %592 = fmul float %591, %585
  %593 = extractelement <8 x float> %160, i64 2
  %594 = fmul float %593, %592
  %595 = call float @llvm.fabs.f32(float %592)
  %596 = fcmp olt float %595, +inf
  %597 = fcmp one float %592, 0.000000e+00
  %598 = and i1 %596, %597
  br i1 %598, label %599, label %600

599:                                              ; preds = %581
  br label %612

600:                                              ; preds = %581
  %601 = fpext float %593 to double
  %602 = fpext float %591 to double
  %603 = fpext float %585 to double
  %604 = fmul double %601, %602
  %605 = fmul double %604, %603
  %606 = fptrunc double %605 to float
  %607 = fcmp oeq float %593, 0.000000e+00
  %608 = call float @llvm.fabs.f32(float %585)
  %609 = fcmp olt float %608, +inf
  %610 = and i1 %607, %609
  %611 = select i1 %610, float 0.000000e+00, float %606
  br label %612

612:                                              ; preds = %599, %600
  %613 = phi float [ %611, %600 ], [ %594, %599 ]
  br label %614

614:                                              ; preds = %612
  %615 = add i64 %89, %57
  %616 = icmp slt i64 %615, %26
  %617 = select i1 %616, i64 %615, i64 0
  %618 = extractelement <8 x float> %514, i64 3
  %619 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %620 = getelementptr inbounds nuw i8, ptr %619, i64 %617
  %621 = load i8, ptr %620, align 1
  %622 = zext i8 %621 to i32
  %623 = shl i32 %622, 23
  %624 = bitcast i32 %623 to float
  %625 = fmul float %624, %618
  %626 = extractelement <8 x float> %160, i64 3
  %627 = fmul float %626, %625
  %628 = call float @llvm.fabs.f32(float %625)
  %629 = fcmp olt float %628, +inf
  %630 = fcmp one float %625, 0.000000e+00
  %631 = and i1 %629, %630
  br i1 %631, label %632, label %633

632:                                              ; preds = %614
  br label %645

633:                                              ; preds = %614
  %634 = fpext float %626 to double
  %635 = fpext float %624 to double
  %636 = fpext float %618 to double
  %637 = fmul double %634, %635
  %638 = fmul double %637, %636
  %639 = fptrunc double %638 to float
  %640 = fcmp oeq float %626, 0.000000e+00
  %641 = call float @llvm.fabs.f32(float %618)
  %642 = fcmp olt float %641, +inf
  %643 = and i1 %640, %642
  %644 = select i1 %643, float 0.000000e+00, float %639
  br label %645

645:                                              ; preds = %632, %633
  %646 = phi float [ %644, %633 ], [ %627, %632 ]
  br label %647

647:                                              ; preds = %645
  %648 = add i64 %89, %57
  %649 = icmp slt i64 %648, %26
  %650 = select i1 %649, i64 %648, i64 0
  %651 = extractelement <8 x float> %514, i64 4
  %652 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %653 = getelementptr inbounds nuw i8, ptr %652, i64 %650
  %654 = load i8, ptr %653, align 1
  %655 = zext i8 %654 to i32
  %656 = shl i32 %655, 23
  %657 = bitcast i32 %656 to float
  %658 = fmul float %657, %651
  %659 = extractelement <8 x float> %160, i64 4
  %660 = fmul float %659, %658
  %661 = call float @llvm.fabs.f32(float %658)
  %662 = fcmp olt float %661, +inf
  %663 = fcmp one float %658, 0.000000e+00
  %664 = and i1 %662, %663
  br i1 %664, label %665, label %666

665:                                              ; preds = %647
  br label %678

666:                                              ; preds = %647
  %667 = fpext float %659 to double
  %668 = fpext float %657 to double
  %669 = fpext float %651 to double
  %670 = fmul double %667, %668
  %671 = fmul double %670, %669
  %672 = fptrunc double %671 to float
  %673 = fcmp oeq float %659, 0.000000e+00
  %674 = call float @llvm.fabs.f32(float %651)
  %675 = fcmp olt float %674, +inf
  %676 = and i1 %673, %675
  %677 = select i1 %676, float 0.000000e+00, float %672
  br label %678

678:                                              ; preds = %665, %666
  %679 = phi float [ %677, %666 ], [ %660, %665 ]
  br label %680

680:                                              ; preds = %678
  %681 = add i64 %89, %57
  %682 = icmp slt i64 %681, %26
  %683 = select i1 %682, i64 %681, i64 0
  %684 = extractelement <8 x float> %514, i64 5
  %685 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %686 = getelementptr inbounds nuw i8, ptr %685, i64 %683
  %687 = load i8, ptr %686, align 1
  %688 = zext i8 %687 to i32
  %689 = shl i32 %688, 23
  %690 = bitcast i32 %689 to float
  %691 = fmul float %690, %684
  %692 = extractelement <8 x float> %160, i64 5
  %693 = fmul float %692, %691
  %694 = call float @llvm.fabs.f32(float %691)
  %695 = fcmp olt float %694, +inf
  %696 = fcmp one float %691, 0.000000e+00
  %697 = and i1 %695, %696
  br i1 %697, label %698, label %699

698:                                              ; preds = %680
  br label %711

699:                                              ; preds = %680
  %700 = fpext float %692 to double
  %701 = fpext float %690 to double
  %702 = fpext float %684 to double
  %703 = fmul double %700, %701
  %704 = fmul double %703, %702
  %705 = fptrunc double %704 to float
  %706 = fcmp oeq float %692, 0.000000e+00
  %707 = call float @llvm.fabs.f32(float %684)
  %708 = fcmp olt float %707, +inf
  %709 = and i1 %706, %708
  %710 = select i1 %709, float 0.000000e+00, float %705
  br label %711

711:                                              ; preds = %698, %699
  %712 = phi float [ %710, %699 ], [ %693, %698 ]
  br label %713

713:                                              ; preds = %711
  %714 = add i64 %89, %57
  %715 = icmp slt i64 %714, %26
  %716 = select i1 %715, i64 %714, i64 0
  %717 = extractelement <8 x float> %514, i64 6
  %718 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %719 = getelementptr inbounds nuw i8, ptr %718, i64 %716
  %720 = load i8, ptr %719, align 1
  %721 = zext i8 %720 to i32
  %722 = shl i32 %721, 23
  %723 = bitcast i32 %722 to float
  %724 = fmul float %723, %717
  %725 = extractelement <8 x float> %160, i64 6
  %726 = fmul float %725, %724
  %727 = call float @llvm.fabs.f32(float %724)
  %728 = fcmp olt float %727, +inf
  %729 = fcmp one float %724, 0.000000e+00
  %730 = and i1 %728, %729
  br i1 %730, label %731, label %732

731:                                              ; preds = %713
  br label %744

732:                                              ; preds = %713
  %733 = fpext float %725 to double
  %734 = fpext float %723 to double
  %735 = fpext float %717 to double
  %736 = fmul double %733, %734
  %737 = fmul double %736, %735
  %738 = fptrunc double %737 to float
  %739 = fcmp oeq float %725, 0.000000e+00
  %740 = call float @llvm.fabs.f32(float %717)
  %741 = fcmp olt float %740, +inf
  %742 = and i1 %739, %741
  %743 = select i1 %742, float 0.000000e+00, float %738
  br label %744

744:                                              ; preds = %731, %732
  %745 = phi float [ %743, %732 ], [ %726, %731 ]
  br label %746

746:                                              ; preds = %744
  %747 = add i64 %89, %57
  %748 = icmp slt i64 %747, %26
  %749 = select i1 %748, i64 %747, i64 0
  %750 = extractelement <8 x float> %514, i64 7
  %751 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %752 = getelementptr inbounds nuw i8, ptr %751, i64 %749
  %753 = load i8, ptr %752, align 1
  %754 = zext i8 %753 to i32
  %755 = shl i32 %754, 23
  %756 = bitcast i32 %755 to float
  %757 = fmul float %756, %750
  %758 = extractelement <8 x float> %160, i64 7
  %759 = fmul float %758, %757
  %760 = call float @llvm.fabs.f32(float %757)
  %761 = fcmp olt float %760, +inf
  %762 = fcmp one float %757, 0.000000e+00
  %763 = and i1 %761, %762
  br i1 %763, label %764, label %765

764:                                              ; preds = %746
  br label %777

765:                                              ; preds = %746
  %766 = fpext float %758 to double
  %767 = fpext float %756 to double
  %768 = fpext float %750 to double
  %769 = fmul double %766, %767
  %770 = fmul double %769, %768
  %771 = fptrunc double %770 to float
  %772 = fcmp oeq float %758, 0.000000e+00
  %773 = call float @llvm.fabs.f32(float %750)
  %774 = fcmp olt float %773, +inf
  %775 = and i1 %772, %774
  %776 = select i1 %775, float 0.000000e+00, float %771
  br label %777

777:                                              ; preds = %764, %765
  %778 = phi float [ %776, %765 ], [ %759, %764 ]
  br label %779

779:                                              ; preds = %777
  %780 = mul i64 %58, 8
  %781 = add i64 %82, %780
  %782 = add i64 %89, %57
  %783 = mul i64 %781, %26
  %784 = add i64 %783, %782
  %785 = fptrunc float %547 to bfloat
  %786 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %787 = getelementptr inbounds nuw bfloat, ptr %786, i64 %784
  store bfloat %785, ptr %787, align 2
  %788 = mul i64 %58, 8
  %789 = add i64 %788, 1
  %790 = add i64 %82, %789
  %791 = add i64 %89, %57
  %792 = mul i64 %790, %26
  %793 = add i64 %792, %791
  %794 = fptrunc float %580 to bfloat
  %795 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %796 = getelementptr inbounds nuw bfloat, ptr %795, i64 %793
  store bfloat %794, ptr %796, align 2
  %797 = mul i64 %58, 8
  %798 = add i64 %797, 2
  %799 = add i64 %82, %798
  %800 = add i64 %89, %57
  %801 = mul i64 %799, %26
  %802 = add i64 %801, %800
  %803 = fptrunc float %613 to bfloat
  %804 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %805 = getelementptr inbounds nuw bfloat, ptr %804, i64 %802
  store bfloat %803, ptr %805, align 2
  %806 = mul i64 %58, 8
  %807 = add i64 %806, 3
  %808 = add i64 %82, %807
  %809 = add i64 %89, %57
  %810 = mul i64 %808, %26
  %811 = add i64 %810, %809
  %812 = fptrunc float %646 to bfloat
  %813 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %814 = getelementptr inbounds nuw bfloat, ptr %813, i64 %811
  store bfloat %812, ptr %814, align 2
  %815 = mul i64 %58, 8
  %816 = add i64 %815, 4
  %817 = add i64 %82, %816
  %818 = add i64 %89, %57
  %819 = mul i64 %817, %26
  %820 = add i64 %819, %818
  %821 = fptrunc float %679 to bfloat
  %822 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %823 = getelementptr inbounds nuw bfloat, ptr %822, i64 %820
  store bfloat %821, ptr %823, align 2
  %824 = mul i64 %58, 8
  %825 = add i64 %824, 5
  %826 = add i64 %82, %825
  %827 = add i64 %89, %57
  %828 = mul i64 %826, %26
  %829 = add i64 %828, %827
  %830 = fptrunc float %712 to bfloat
  %831 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %832 = getelementptr inbounds nuw bfloat, ptr %831, i64 %829
  store bfloat %830, ptr %832, align 2
  %833 = mul i64 %58, 8
  %834 = add i64 %833, 6
  %835 = add i64 %82, %834
  %836 = add i64 %89, %57
  %837 = mul i64 %835, %26
  %838 = add i64 %837, %836
  %839 = fptrunc float %745 to bfloat
  %840 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %841 = getelementptr inbounds nuw bfloat, ptr %840, i64 %838
  store bfloat %839, ptr %841, align 2
  %842 = mul i64 %58, 8
  %843 = add i64 %842, 7
  %844 = add i64 %82, %843
  %845 = add i64 %89, %57
  %846 = mul i64 %844, %26
  %847 = add i64 %846, %845
  %848 = fptrunc float %778 to bfloat
  %849 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %850 = getelementptr inbounds nuw bfloat, ptr %849, i64 %847
  store bfloat %848, ptr %850, align 2
  %851 = mul i64 %58, 8
  %852 = add i64 %84, %851
  %853 = add i64 %89, %57
  %854 = add i64 %852, 7
  %855 = icmp ult i64 %853, %26
  %856 = icmp ult i64 %854, %25
  %857 = and i1 %856, %855
  %858 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %859 = ptrtoint ptr %858 to i64
  %860 = mul i64 %852, 4
  %861 = add i64 %859, %860
  %862 = urem i64 %861, 16
  %863 = icmp eq i64 %862, 0
  %864 = and i1 %857, %863
  br i1 %864, label %865, label %874

865:                                              ; preds = %779
  %866 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %867 = getelementptr float, ptr %866, i64 %852
  %868 = load <4 x float>, ptr %867, align 16
  %869 = add i64 %852, 4
  %870 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %871 = getelementptr float, ptr %870, i64 %869
  %872 = load <4 x float>, ptr %871, align 16
  %873 = shufflevector <4 x float> %868, <4 x float> %872, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %946

874:                                              ; preds = %779
  %875 = mul i64 %58, 8
  %876 = add i64 %84, %875
  %877 = icmp slt i64 %876, %25
  %878 = select i1 %877, i64 %876, i64 0
  %879 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %880 = getelementptr inbounds nuw float, ptr %879, i64 %878
  %881 = load float, ptr %880, align 4
  %882 = insertelement <8 x float> zeroinitializer, float %881, i64 0
  %883 = mul i64 %58, 8
  %884 = add i64 %883, 1
  %885 = add i64 %84, %884
  %886 = icmp slt i64 %885, %25
  %887 = select i1 %886, i64 %885, i64 0
  %888 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %889 = getelementptr inbounds nuw float, ptr %888, i64 %887
  %890 = load float, ptr %889, align 4
  %891 = insertelement <8 x float> %882, float %890, i64 1
  %892 = mul i64 %58, 8
  %893 = add i64 %892, 2
  %894 = add i64 %84, %893
  %895 = icmp slt i64 %894, %25
  %896 = select i1 %895, i64 %894, i64 0
  %897 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %898 = getelementptr inbounds nuw float, ptr %897, i64 %896
  %899 = load float, ptr %898, align 4
  %900 = insertelement <8 x float> %891, float %899, i64 2
  %901 = mul i64 %58, 8
  %902 = add i64 %901, 3
  %903 = add i64 %84, %902
  %904 = icmp slt i64 %903, %25
  %905 = select i1 %904, i64 %903, i64 0
  %906 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %907 = getelementptr inbounds nuw float, ptr %906, i64 %905
  %908 = load float, ptr %907, align 4
  %909 = insertelement <8 x float> %900, float %908, i64 3
  %910 = mul i64 %58, 8
  %911 = add i64 %910, 4
  %912 = add i64 %84, %911
  %913 = icmp slt i64 %912, %25
  %914 = select i1 %913, i64 %912, i64 0
  %915 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %916 = getelementptr inbounds nuw float, ptr %915, i64 %914
  %917 = load float, ptr %916, align 4
  %918 = insertelement <8 x float> %909, float %917, i64 4
  %919 = mul i64 %58, 8
  %920 = add i64 %919, 5
  %921 = add i64 %84, %920
  %922 = icmp slt i64 %921, %25
  %923 = select i1 %922, i64 %921, i64 0
  %924 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %925 = getelementptr inbounds nuw float, ptr %924, i64 %923
  %926 = load float, ptr %925, align 4
  %927 = insertelement <8 x float> %918, float %926, i64 5
  %928 = mul i64 %58, 8
  %929 = add i64 %928, 6
  %930 = add i64 %84, %929
  %931 = icmp slt i64 %930, %25
  %932 = select i1 %931, i64 %930, i64 0
  %933 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %934 = getelementptr inbounds nuw float, ptr %933, i64 %932
  %935 = load float, ptr %934, align 4
  %936 = insertelement <8 x float> %927, float %935, i64 6
  %937 = mul i64 %58, 8
  %938 = add i64 %937, 7
  %939 = add i64 %84, %938
  %940 = icmp slt i64 %939, %25
  %941 = select i1 %940, i64 %939, i64 0
  %942 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %943 = getelementptr inbounds nuw float, ptr %942, i64 %941
  %944 = load float, ptr %943, align 4
  %945 = insertelement <8 x float> %936, float %944, i64 7
  br label %946

946:                                              ; preds = %865, %874
  %947 = phi <8 x float> [ %945, %874 ], [ %873, %865 ]
  br label %948

948:                                              ; preds = %946
  %949 = add i64 %89, %57
  %950 = icmp slt i64 %949, %26
  %951 = select i1 %950, i64 %949, i64 0
  %952 = extractelement <8 x float> %947, i64 0
  %953 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %954 = getelementptr inbounds nuw i8, ptr %953, i64 %951
  %955 = load i8, ptr %954, align 1
  %956 = zext i8 %955 to i32
  %957 = shl i32 %956, 23
  %958 = bitcast i32 %957 to float
  %959 = fmul float %958, %952
  %960 = extractelement <8 x float> %162, i64 0
  %961 = fmul float %960, %959
  %962 = call float @llvm.fabs.f32(float %959)
  %963 = fcmp olt float %962, +inf
  %964 = fcmp one float %959, 0.000000e+00
  %965 = and i1 %963, %964
  br i1 %965, label %966, label %967

966:                                              ; preds = %948
  br label %979

967:                                              ; preds = %948
  %968 = fpext float %960 to double
  %969 = fpext float %958 to double
  %970 = fpext float %952 to double
  %971 = fmul double %968, %969
  %972 = fmul double %971, %970
  %973 = fptrunc double %972 to float
  %974 = fcmp oeq float %960, 0.000000e+00
  %975 = call float @llvm.fabs.f32(float %952)
  %976 = fcmp olt float %975, +inf
  %977 = and i1 %974, %976
  %978 = select i1 %977, float 0.000000e+00, float %973
  br label %979

979:                                              ; preds = %966, %967
  %980 = phi float [ %978, %967 ], [ %961, %966 ]
  br label %981

981:                                              ; preds = %979
  %982 = add i64 %89, %57
  %983 = icmp slt i64 %982, %26
  %984 = select i1 %983, i64 %982, i64 0
  %985 = extractelement <8 x float> %947, i64 1
  %986 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %987 = getelementptr inbounds nuw i8, ptr %986, i64 %984
  %988 = load i8, ptr %987, align 1
  %989 = zext i8 %988 to i32
  %990 = shl i32 %989, 23
  %991 = bitcast i32 %990 to float
  %992 = fmul float %991, %985
  %993 = extractelement <8 x float> %162, i64 1
  %994 = fmul float %993, %992
  %995 = call float @llvm.fabs.f32(float %992)
  %996 = fcmp olt float %995, +inf
  %997 = fcmp one float %992, 0.000000e+00
  %998 = and i1 %996, %997
  br i1 %998, label %999, label %1000

999:                                              ; preds = %981
  br label %1012

1000:                                             ; preds = %981
  %1001 = fpext float %993 to double
  %1002 = fpext float %991 to double
  %1003 = fpext float %985 to double
  %1004 = fmul double %1001, %1002
  %1005 = fmul double %1004, %1003
  %1006 = fptrunc double %1005 to float
  %1007 = fcmp oeq float %993, 0.000000e+00
  %1008 = call float @llvm.fabs.f32(float %985)
  %1009 = fcmp olt float %1008, +inf
  %1010 = and i1 %1007, %1009
  %1011 = select i1 %1010, float 0.000000e+00, float %1006
  br label %1012

1012:                                             ; preds = %999, %1000
  %1013 = phi float [ %1011, %1000 ], [ %994, %999 ]
  br label %1014

1014:                                             ; preds = %1012
  %1015 = add i64 %89, %57
  %1016 = icmp slt i64 %1015, %26
  %1017 = select i1 %1016, i64 %1015, i64 0
  %1018 = extractelement <8 x float> %947, i64 2
  %1019 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1020 = getelementptr inbounds nuw i8, ptr %1019, i64 %1017
  %1021 = load i8, ptr %1020, align 1
  %1022 = zext i8 %1021 to i32
  %1023 = shl i32 %1022, 23
  %1024 = bitcast i32 %1023 to float
  %1025 = fmul float %1024, %1018
  %1026 = extractelement <8 x float> %162, i64 2
  %1027 = fmul float %1026, %1025
  %1028 = call float @llvm.fabs.f32(float %1025)
  %1029 = fcmp olt float %1028, +inf
  %1030 = fcmp one float %1025, 0.000000e+00
  %1031 = and i1 %1029, %1030
  br i1 %1031, label %1032, label %1033

1032:                                             ; preds = %1014
  br label %1045

1033:                                             ; preds = %1014
  %1034 = fpext float %1026 to double
  %1035 = fpext float %1024 to double
  %1036 = fpext float %1018 to double
  %1037 = fmul double %1034, %1035
  %1038 = fmul double %1037, %1036
  %1039 = fptrunc double %1038 to float
  %1040 = fcmp oeq float %1026, 0.000000e+00
  %1041 = call float @llvm.fabs.f32(float %1018)
  %1042 = fcmp olt float %1041, +inf
  %1043 = and i1 %1040, %1042
  %1044 = select i1 %1043, float 0.000000e+00, float %1039
  br label %1045

1045:                                             ; preds = %1032, %1033
  %1046 = phi float [ %1044, %1033 ], [ %1027, %1032 ]
  br label %1047

1047:                                             ; preds = %1045
  %1048 = add i64 %89, %57
  %1049 = icmp slt i64 %1048, %26
  %1050 = select i1 %1049, i64 %1048, i64 0
  %1051 = extractelement <8 x float> %947, i64 3
  %1052 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1053 = getelementptr inbounds nuw i8, ptr %1052, i64 %1050
  %1054 = load i8, ptr %1053, align 1
  %1055 = zext i8 %1054 to i32
  %1056 = shl i32 %1055, 23
  %1057 = bitcast i32 %1056 to float
  %1058 = fmul float %1057, %1051
  %1059 = extractelement <8 x float> %162, i64 3
  %1060 = fmul float %1059, %1058
  %1061 = call float @llvm.fabs.f32(float %1058)
  %1062 = fcmp olt float %1061, +inf
  %1063 = fcmp one float %1058, 0.000000e+00
  %1064 = and i1 %1062, %1063
  br i1 %1064, label %1065, label %1066

1065:                                             ; preds = %1047
  br label %1078

1066:                                             ; preds = %1047
  %1067 = fpext float %1059 to double
  %1068 = fpext float %1057 to double
  %1069 = fpext float %1051 to double
  %1070 = fmul double %1067, %1068
  %1071 = fmul double %1070, %1069
  %1072 = fptrunc double %1071 to float
  %1073 = fcmp oeq float %1059, 0.000000e+00
  %1074 = call float @llvm.fabs.f32(float %1051)
  %1075 = fcmp olt float %1074, +inf
  %1076 = and i1 %1073, %1075
  %1077 = select i1 %1076, float 0.000000e+00, float %1072
  br label %1078

1078:                                             ; preds = %1065, %1066
  %1079 = phi float [ %1077, %1066 ], [ %1060, %1065 ]
  br label %1080

1080:                                             ; preds = %1078
  %1081 = add i64 %89, %57
  %1082 = icmp slt i64 %1081, %26
  %1083 = select i1 %1082, i64 %1081, i64 0
  %1084 = extractelement <8 x float> %947, i64 4
  %1085 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1086 = getelementptr inbounds nuw i8, ptr %1085, i64 %1083
  %1087 = load i8, ptr %1086, align 1
  %1088 = zext i8 %1087 to i32
  %1089 = shl i32 %1088, 23
  %1090 = bitcast i32 %1089 to float
  %1091 = fmul float %1090, %1084
  %1092 = extractelement <8 x float> %162, i64 4
  %1093 = fmul float %1092, %1091
  %1094 = call float @llvm.fabs.f32(float %1091)
  %1095 = fcmp olt float %1094, +inf
  %1096 = fcmp one float %1091, 0.000000e+00
  %1097 = and i1 %1095, %1096
  br i1 %1097, label %1098, label %1099

1098:                                             ; preds = %1080
  br label %1111

1099:                                             ; preds = %1080
  %1100 = fpext float %1092 to double
  %1101 = fpext float %1090 to double
  %1102 = fpext float %1084 to double
  %1103 = fmul double %1100, %1101
  %1104 = fmul double %1103, %1102
  %1105 = fptrunc double %1104 to float
  %1106 = fcmp oeq float %1092, 0.000000e+00
  %1107 = call float @llvm.fabs.f32(float %1084)
  %1108 = fcmp olt float %1107, +inf
  %1109 = and i1 %1106, %1108
  %1110 = select i1 %1109, float 0.000000e+00, float %1105
  br label %1111

1111:                                             ; preds = %1098, %1099
  %1112 = phi float [ %1110, %1099 ], [ %1093, %1098 ]
  br label %1113

1113:                                             ; preds = %1111
  %1114 = add i64 %89, %57
  %1115 = icmp slt i64 %1114, %26
  %1116 = select i1 %1115, i64 %1114, i64 0
  %1117 = extractelement <8 x float> %947, i64 5
  %1118 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1119 = getelementptr inbounds nuw i8, ptr %1118, i64 %1116
  %1120 = load i8, ptr %1119, align 1
  %1121 = zext i8 %1120 to i32
  %1122 = shl i32 %1121, 23
  %1123 = bitcast i32 %1122 to float
  %1124 = fmul float %1123, %1117
  %1125 = extractelement <8 x float> %162, i64 5
  %1126 = fmul float %1125, %1124
  %1127 = call float @llvm.fabs.f32(float %1124)
  %1128 = fcmp olt float %1127, +inf
  %1129 = fcmp one float %1124, 0.000000e+00
  %1130 = and i1 %1128, %1129
  br i1 %1130, label %1131, label %1132

1131:                                             ; preds = %1113
  br label %1144

1132:                                             ; preds = %1113
  %1133 = fpext float %1125 to double
  %1134 = fpext float %1123 to double
  %1135 = fpext float %1117 to double
  %1136 = fmul double %1133, %1134
  %1137 = fmul double %1136, %1135
  %1138 = fptrunc double %1137 to float
  %1139 = fcmp oeq float %1125, 0.000000e+00
  %1140 = call float @llvm.fabs.f32(float %1117)
  %1141 = fcmp olt float %1140, +inf
  %1142 = and i1 %1139, %1141
  %1143 = select i1 %1142, float 0.000000e+00, float %1138
  br label %1144

1144:                                             ; preds = %1131, %1132
  %1145 = phi float [ %1143, %1132 ], [ %1126, %1131 ]
  br label %1146

1146:                                             ; preds = %1144
  %1147 = add i64 %89, %57
  %1148 = icmp slt i64 %1147, %26
  %1149 = select i1 %1148, i64 %1147, i64 0
  %1150 = extractelement <8 x float> %947, i64 6
  %1151 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1152 = getelementptr inbounds nuw i8, ptr %1151, i64 %1149
  %1153 = load i8, ptr %1152, align 1
  %1154 = zext i8 %1153 to i32
  %1155 = shl i32 %1154, 23
  %1156 = bitcast i32 %1155 to float
  %1157 = fmul float %1156, %1150
  %1158 = extractelement <8 x float> %162, i64 6
  %1159 = fmul float %1158, %1157
  %1160 = call float @llvm.fabs.f32(float %1157)
  %1161 = fcmp olt float %1160, +inf
  %1162 = fcmp one float %1157, 0.000000e+00
  %1163 = and i1 %1161, %1162
  br i1 %1163, label %1164, label %1165

1164:                                             ; preds = %1146
  br label %1177

1165:                                             ; preds = %1146
  %1166 = fpext float %1158 to double
  %1167 = fpext float %1156 to double
  %1168 = fpext float %1150 to double
  %1169 = fmul double %1166, %1167
  %1170 = fmul double %1169, %1168
  %1171 = fptrunc double %1170 to float
  %1172 = fcmp oeq float %1158, 0.000000e+00
  %1173 = call float @llvm.fabs.f32(float %1150)
  %1174 = fcmp olt float %1173, +inf
  %1175 = and i1 %1172, %1174
  %1176 = select i1 %1175, float 0.000000e+00, float %1171
  br label %1177

1177:                                             ; preds = %1164, %1165
  %1178 = phi float [ %1176, %1165 ], [ %1159, %1164 ]
  br label %1179

1179:                                             ; preds = %1177
  %1180 = add i64 %89, %57
  %1181 = icmp slt i64 %1180, %26
  %1182 = select i1 %1181, i64 %1180, i64 0
  %1183 = extractelement <8 x float> %947, i64 7
  %1184 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1185 = getelementptr inbounds nuw i8, ptr %1184, i64 %1182
  %1186 = load i8, ptr %1185, align 1
  %1187 = zext i8 %1186 to i32
  %1188 = shl i32 %1187, 23
  %1189 = bitcast i32 %1188 to float
  %1190 = fmul float %1189, %1183
  %1191 = extractelement <8 x float> %162, i64 7
  %1192 = fmul float %1191, %1190
  %1193 = call float @llvm.fabs.f32(float %1190)
  %1194 = fcmp olt float %1193, +inf
  %1195 = fcmp one float %1190, 0.000000e+00
  %1196 = and i1 %1194, %1195
  br i1 %1196, label %1197, label %1198

1197:                                             ; preds = %1179
  br label %1210

1198:                                             ; preds = %1179
  %1199 = fpext float %1191 to double
  %1200 = fpext float %1189 to double
  %1201 = fpext float %1183 to double
  %1202 = fmul double %1199, %1200
  %1203 = fmul double %1202, %1201
  %1204 = fptrunc double %1203 to float
  %1205 = fcmp oeq float %1191, 0.000000e+00
  %1206 = call float @llvm.fabs.f32(float %1183)
  %1207 = fcmp olt float %1206, +inf
  %1208 = and i1 %1205, %1207
  %1209 = select i1 %1208, float 0.000000e+00, float %1204
  br label %1210

1210:                                             ; preds = %1197, %1198
  %1211 = phi float [ %1209, %1198 ], [ %1192, %1197 ]
  br label %1212

1212:                                             ; preds = %1210
  %1213 = mul i64 %58, 8
  %1214 = add i64 %84, %1213
  %1215 = add i64 %89, %57
  %1216 = mul i64 %1214, %26
  %1217 = add i64 %1216, %1215
  %1218 = fptrunc float %980 to bfloat
  %1219 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1220 = getelementptr inbounds nuw bfloat, ptr %1219, i64 %1217
  store bfloat %1218, ptr %1220, align 2
  %1221 = mul i64 %58, 8
  %1222 = add i64 %1221, 1
  %1223 = add i64 %84, %1222
  %1224 = add i64 %89, %57
  %1225 = mul i64 %1223, %26
  %1226 = add i64 %1225, %1224
  %1227 = fptrunc float %1013 to bfloat
  %1228 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1229 = getelementptr inbounds nuw bfloat, ptr %1228, i64 %1226
  store bfloat %1227, ptr %1229, align 2
  %1230 = mul i64 %58, 8
  %1231 = add i64 %1230, 2
  %1232 = add i64 %84, %1231
  %1233 = add i64 %89, %57
  %1234 = mul i64 %1232, %26
  %1235 = add i64 %1234, %1233
  %1236 = fptrunc float %1046 to bfloat
  %1237 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1238 = getelementptr inbounds nuw bfloat, ptr %1237, i64 %1235
  store bfloat %1236, ptr %1238, align 2
  %1239 = mul i64 %58, 8
  %1240 = add i64 %1239, 3
  %1241 = add i64 %84, %1240
  %1242 = add i64 %89, %57
  %1243 = mul i64 %1241, %26
  %1244 = add i64 %1243, %1242
  %1245 = fptrunc float %1079 to bfloat
  %1246 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1247 = getelementptr inbounds nuw bfloat, ptr %1246, i64 %1244
  store bfloat %1245, ptr %1247, align 2
  %1248 = mul i64 %58, 8
  %1249 = add i64 %1248, 4
  %1250 = add i64 %84, %1249
  %1251 = add i64 %89, %57
  %1252 = mul i64 %1250, %26
  %1253 = add i64 %1252, %1251
  %1254 = fptrunc float %1112 to bfloat
  %1255 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1256 = getelementptr inbounds nuw bfloat, ptr %1255, i64 %1253
  store bfloat %1254, ptr %1256, align 2
  %1257 = mul i64 %58, 8
  %1258 = add i64 %1257, 5
  %1259 = add i64 %84, %1258
  %1260 = add i64 %89, %57
  %1261 = mul i64 %1259, %26
  %1262 = add i64 %1261, %1260
  %1263 = fptrunc float %1145 to bfloat
  %1264 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1265 = getelementptr inbounds nuw bfloat, ptr %1264, i64 %1262
  store bfloat %1263, ptr %1265, align 2
  %1266 = mul i64 %58, 8
  %1267 = add i64 %1266, 6
  %1268 = add i64 %84, %1267
  %1269 = add i64 %89, %57
  %1270 = mul i64 %1268, %26
  %1271 = add i64 %1270, %1269
  %1272 = fptrunc float %1178 to bfloat
  %1273 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1274 = getelementptr inbounds nuw bfloat, ptr %1273, i64 %1271
  store bfloat %1272, ptr %1274, align 2
  %1275 = mul i64 %58, 8
  %1276 = add i64 %1275, 7
  %1277 = add i64 %84, %1276
  %1278 = add i64 %89, %57
  %1279 = mul i64 %1277, %26
  %1280 = add i64 %1279, %1278
  %1281 = fptrunc float %1211 to bfloat
  %1282 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1283 = getelementptr inbounds nuw bfloat, ptr %1282, i64 %1280
  store bfloat %1281, ptr %1283, align 2
  %1284 = mul i64 %58, 8
  %1285 = add i64 %86, %1284
  %1286 = add i64 %89, %57
  %1287 = add i64 %1285, 7
  %1288 = icmp ult i64 %1286, %26
  %1289 = icmp ult i64 %1287, %25
  %1290 = and i1 %1289, %1288
  %1291 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1292 = ptrtoint ptr %1291 to i64
  %1293 = mul i64 %1285, 4
  %1294 = add i64 %1292, %1293
  %1295 = urem i64 %1294, 16
  %1296 = icmp eq i64 %1295, 0
  %1297 = and i1 %1290, %1296
  br i1 %1297, label %1298, label %1307

1298:                                             ; preds = %1212
  %1299 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1300 = getelementptr float, ptr %1299, i64 %1285
  %1301 = load <4 x float>, ptr %1300, align 16
  %1302 = add i64 %1285, 4
  %1303 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1304 = getelementptr float, ptr %1303, i64 %1302
  %1305 = load <4 x float>, ptr %1304, align 16
  %1306 = shufflevector <4 x float> %1301, <4 x float> %1305, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1379

1307:                                             ; preds = %1212
  %1308 = mul i64 %58, 8
  %1309 = add i64 %86, %1308
  %1310 = icmp slt i64 %1309, %25
  %1311 = select i1 %1310, i64 %1309, i64 0
  %1312 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1313 = getelementptr inbounds nuw float, ptr %1312, i64 %1311
  %1314 = load float, ptr %1313, align 4
  %1315 = insertelement <8 x float> zeroinitializer, float %1314, i64 0
  %1316 = mul i64 %58, 8
  %1317 = add i64 %1316, 1
  %1318 = add i64 %86, %1317
  %1319 = icmp slt i64 %1318, %25
  %1320 = select i1 %1319, i64 %1318, i64 0
  %1321 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1322 = getelementptr inbounds nuw float, ptr %1321, i64 %1320
  %1323 = load float, ptr %1322, align 4
  %1324 = insertelement <8 x float> %1315, float %1323, i64 1
  %1325 = mul i64 %58, 8
  %1326 = add i64 %1325, 2
  %1327 = add i64 %86, %1326
  %1328 = icmp slt i64 %1327, %25
  %1329 = select i1 %1328, i64 %1327, i64 0
  %1330 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1331 = getelementptr inbounds nuw float, ptr %1330, i64 %1329
  %1332 = load float, ptr %1331, align 4
  %1333 = insertelement <8 x float> %1324, float %1332, i64 2
  %1334 = mul i64 %58, 8
  %1335 = add i64 %1334, 3
  %1336 = add i64 %86, %1335
  %1337 = icmp slt i64 %1336, %25
  %1338 = select i1 %1337, i64 %1336, i64 0
  %1339 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1340 = getelementptr inbounds nuw float, ptr %1339, i64 %1338
  %1341 = load float, ptr %1340, align 4
  %1342 = insertelement <8 x float> %1333, float %1341, i64 3
  %1343 = mul i64 %58, 8
  %1344 = add i64 %1343, 4
  %1345 = add i64 %86, %1344
  %1346 = icmp slt i64 %1345, %25
  %1347 = select i1 %1346, i64 %1345, i64 0
  %1348 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1349 = getelementptr inbounds nuw float, ptr %1348, i64 %1347
  %1350 = load float, ptr %1349, align 4
  %1351 = insertelement <8 x float> %1342, float %1350, i64 4
  %1352 = mul i64 %58, 8
  %1353 = add i64 %1352, 5
  %1354 = add i64 %86, %1353
  %1355 = icmp slt i64 %1354, %25
  %1356 = select i1 %1355, i64 %1354, i64 0
  %1357 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1358 = getelementptr inbounds nuw float, ptr %1357, i64 %1356
  %1359 = load float, ptr %1358, align 4
  %1360 = insertelement <8 x float> %1351, float %1359, i64 5
  %1361 = mul i64 %58, 8
  %1362 = add i64 %1361, 6
  %1363 = add i64 %86, %1362
  %1364 = icmp slt i64 %1363, %25
  %1365 = select i1 %1364, i64 %1363, i64 0
  %1366 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1367 = getelementptr inbounds nuw float, ptr %1366, i64 %1365
  %1368 = load float, ptr %1367, align 4
  %1369 = insertelement <8 x float> %1360, float %1368, i64 6
  %1370 = mul i64 %58, 8
  %1371 = add i64 %1370, 7
  %1372 = add i64 %86, %1371
  %1373 = icmp slt i64 %1372, %25
  %1374 = select i1 %1373, i64 %1372, i64 0
  %1375 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1376 = getelementptr inbounds nuw float, ptr %1375, i64 %1374
  %1377 = load float, ptr %1376, align 4
  %1378 = insertelement <8 x float> %1369, float %1377, i64 7
  br label %1379

1379:                                             ; preds = %1298, %1307
  %1380 = phi <8 x float> [ %1378, %1307 ], [ %1306, %1298 ]
  br label %1381

1381:                                             ; preds = %1379
  %1382 = add i64 %89, %57
  %1383 = icmp slt i64 %1382, %26
  %1384 = select i1 %1383, i64 %1382, i64 0
  %1385 = extractelement <8 x float> %1380, i64 0
  %1386 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1387 = getelementptr inbounds nuw i8, ptr %1386, i64 %1384
  %1388 = load i8, ptr %1387, align 1
  %1389 = zext i8 %1388 to i32
  %1390 = shl i32 %1389, 23
  %1391 = bitcast i32 %1390 to float
  %1392 = fmul float %1391, %1385
  %1393 = extractelement <8 x float> %164, i64 0
  %1394 = fmul float %1393, %1392
  %1395 = call float @llvm.fabs.f32(float %1392)
  %1396 = fcmp olt float %1395, +inf
  %1397 = fcmp one float %1392, 0.000000e+00
  %1398 = and i1 %1396, %1397
  br i1 %1398, label %1399, label %1400

1399:                                             ; preds = %1381
  br label %1412

1400:                                             ; preds = %1381
  %1401 = fpext float %1393 to double
  %1402 = fpext float %1391 to double
  %1403 = fpext float %1385 to double
  %1404 = fmul double %1401, %1402
  %1405 = fmul double %1404, %1403
  %1406 = fptrunc double %1405 to float
  %1407 = fcmp oeq float %1393, 0.000000e+00
  %1408 = call float @llvm.fabs.f32(float %1385)
  %1409 = fcmp olt float %1408, +inf
  %1410 = and i1 %1407, %1409
  %1411 = select i1 %1410, float 0.000000e+00, float %1406
  br label %1412

1412:                                             ; preds = %1399, %1400
  %1413 = phi float [ %1411, %1400 ], [ %1394, %1399 ]
  br label %1414

1414:                                             ; preds = %1412
  %1415 = add i64 %89, %57
  %1416 = icmp slt i64 %1415, %26
  %1417 = select i1 %1416, i64 %1415, i64 0
  %1418 = extractelement <8 x float> %1380, i64 1
  %1419 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1420 = getelementptr inbounds nuw i8, ptr %1419, i64 %1417
  %1421 = load i8, ptr %1420, align 1
  %1422 = zext i8 %1421 to i32
  %1423 = shl i32 %1422, 23
  %1424 = bitcast i32 %1423 to float
  %1425 = fmul float %1424, %1418
  %1426 = extractelement <8 x float> %164, i64 1
  %1427 = fmul float %1426, %1425
  %1428 = call float @llvm.fabs.f32(float %1425)
  %1429 = fcmp olt float %1428, +inf
  %1430 = fcmp one float %1425, 0.000000e+00
  %1431 = and i1 %1429, %1430
  br i1 %1431, label %1432, label %1433

1432:                                             ; preds = %1414
  br label %1445

1433:                                             ; preds = %1414
  %1434 = fpext float %1426 to double
  %1435 = fpext float %1424 to double
  %1436 = fpext float %1418 to double
  %1437 = fmul double %1434, %1435
  %1438 = fmul double %1437, %1436
  %1439 = fptrunc double %1438 to float
  %1440 = fcmp oeq float %1426, 0.000000e+00
  %1441 = call float @llvm.fabs.f32(float %1418)
  %1442 = fcmp olt float %1441, +inf
  %1443 = and i1 %1440, %1442
  %1444 = select i1 %1443, float 0.000000e+00, float %1439
  br label %1445

1445:                                             ; preds = %1432, %1433
  %1446 = phi float [ %1444, %1433 ], [ %1427, %1432 ]
  br label %1447

1447:                                             ; preds = %1445
  %1448 = add i64 %89, %57
  %1449 = icmp slt i64 %1448, %26
  %1450 = select i1 %1449, i64 %1448, i64 0
  %1451 = extractelement <8 x float> %1380, i64 2
  %1452 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1453 = getelementptr inbounds nuw i8, ptr %1452, i64 %1450
  %1454 = load i8, ptr %1453, align 1
  %1455 = zext i8 %1454 to i32
  %1456 = shl i32 %1455, 23
  %1457 = bitcast i32 %1456 to float
  %1458 = fmul float %1457, %1451
  %1459 = extractelement <8 x float> %164, i64 2
  %1460 = fmul float %1459, %1458
  %1461 = call float @llvm.fabs.f32(float %1458)
  %1462 = fcmp olt float %1461, +inf
  %1463 = fcmp one float %1458, 0.000000e+00
  %1464 = and i1 %1462, %1463
  br i1 %1464, label %1465, label %1466

1465:                                             ; preds = %1447
  br label %1478

1466:                                             ; preds = %1447
  %1467 = fpext float %1459 to double
  %1468 = fpext float %1457 to double
  %1469 = fpext float %1451 to double
  %1470 = fmul double %1467, %1468
  %1471 = fmul double %1470, %1469
  %1472 = fptrunc double %1471 to float
  %1473 = fcmp oeq float %1459, 0.000000e+00
  %1474 = call float @llvm.fabs.f32(float %1451)
  %1475 = fcmp olt float %1474, +inf
  %1476 = and i1 %1473, %1475
  %1477 = select i1 %1476, float 0.000000e+00, float %1472
  br label %1478

1478:                                             ; preds = %1465, %1466
  %1479 = phi float [ %1477, %1466 ], [ %1460, %1465 ]
  br label %1480

1480:                                             ; preds = %1478
  %1481 = add i64 %89, %57
  %1482 = icmp slt i64 %1481, %26
  %1483 = select i1 %1482, i64 %1481, i64 0
  %1484 = extractelement <8 x float> %1380, i64 3
  %1485 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1486 = getelementptr inbounds nuw i8, ptr %1485, i64 %1483
  %1487 = load i8, ptr %1486, align 1
  %1488 = zext i8 %1487 to i32
  %1489 = shl i32 %1488, 23
  %1490 = bitcast i32 %1489 to float
  %1491 = fmul float %1490, %1484
  %1492 = extractelement <8 x float> %164, i64 3
  %1493 = fmul float %1492, %1491
  %1494 = call float @llvm.fabs.f32(float %1491)
  %1495 = fcmp olt float %1494, +inf
  %1496 = fcmp one float %1491, 0.000000e+00
  %1497 = and i1 %1495, %1496
  br i1 %1497, label %1498, label %1499

1498:                                             ; preds = %1480
  br label %1511

1499:                                             ; preds = %1480
  %1500 = fpext float %1492 to double
  %1501 = fpext float %1490 to double
  %1502 = fpext float %1484 to double
  %1503 = fmul double %1500, %1501
  %1504 = fmul double %1503, %1502
  %1505 = fptrunc double %1504 to float
  %1506 = fcmp oeq float %1492, 0.000000e+00
  %1507 = call float @llvm.fabs.f32(float %1484)
  %1508 = fcmp olt float %1507, +inf
  %1509 = and i1 %1506, %1508
  %1510 = select i1 %1509, float 0.000000e+00, float %1505
  br label %1511

1511:                                             ; preds = %1498, %1499
  %1512 = phi float [ %1510, %1499 ], [ %1493, %1498 ]
  br label %1513

1513:                                             ; preds = %1511
  %1514 = add i64 %89, %57
  %1515 = icmp slt i64 %1514, %26
  %1516 = select i1 %1515, i64 %1514, i64 0
  %1517 = extractelement <8 x float> %1380, i64 4
  %1518 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1519 = getelementptr inbounds nuw i8, ptr %1518, i64 %1516
  %1520 = load i8, ptr %1519, align 1
  %1521 = zext i8 %1520 to i32
  %1522 = shl i32 %1521, 23
  %1523 = bitcast i32 %1522 to float
  %1524 = fmul float %1523, %1517
  %1525 = extractelement <8 x float> %164, i64 4
  %1526 = fmul float %1525, %1524
  %1527 = call float @llvm.fabs.f32(float %1524)
  %1528 = fcmp olt float %1527, +inf
  %1529 = fcmp one float %1524, 0.000000e+00
  %1530 = and i1 %1528, %1529
  br i1 %1530, label %1531, label %1532

1531:                                             ; preds = %1513
  br label %1544

1532:                                             ; preds = %1513
  %1533 = fpext float %1525 to double
  %1534 = fpext float %1523 to double
  %1535 = fpext float %1517 to double
  %1536 = fmul double %1533, %1534
  %1537 = fmul double %1536, %1535
  %1538 = fptrunc double %1537 to float
  %1539 = fcmp oeq float %1525, 0.000000e+00
  %1540 = call float @llvm.fabs.f32(float %1517)
  %1541 = fcmp olt float %1540, +inf
  %1542 = and i1 %1539, %1541
  %1543 = select i1 %1542, float 0.000000e+00, float %1538
  br label %1544

1544:                                             ; preds = %1531, %1532
  %1545 = phi float [ %1543, %1532 ], [ %1526, %1531 ]
  br label %1546

1546:                                             ; preds = %1544
  %1547 = add i64 %89, %57
  %1548 = icmp slt i64 %1547, %26
  %1549 = select i1 %1548, i64 %1547, i64 0
  %1550 = extractelement <8 x float> %1380, i64 5
  %1551 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1552 = getelementptr inbounds nuw i8, ptr %1551, i64 %1549
  %1553 = load i8, ptr %1552, align 1
  %1554 = zext i8 %1553 to i32
  %1555 = shl i32 %1554, 23
  %1556 = bitcast i32 %1555 to float
  %1557 = fmul float %1556, %1550
  %1558 = extractelement <8 x float> %164, i64 5
  %1559 = fmul float %1558, %1557
  %1560 = call float @llvm.fabs.f32(float %1557)
  %1561 = fcmp olt float %1560, +inf
  %1562 = fcmp one float %1557, 0.000000e+00
  %1563 = and i1 %1561, %1562
  br i1 %1563, label %1564, label %1565

1564:                                             ; preds = %1546
  br label %1577

1565:                                             ; preds = %1546
  %1566 = fpext float %1558 to double
  %1567 = fpext float %1556 to double
  %1568 = fpext float %1550 to double
  %1569 = fmul double %1566, %1567
  %1570 = fmul double %1569, %1568
  %1571 = fptrunc double %1570 to float
  %1572 = fcmp oeq float %1558, 0.000000e+00
  %1573 = call float @llvm.fabs.f32(float %1550)
  %1574 = fcmp olt float %1573, +inf
  %1575 = and i1 %1572, %1574
  %1576 = select i1 %1575, float 0.000000e+00, float %1571
  br label %1577

1577:                                             ; preds = %1564, %1565
  %1578 = phi float [ %1576, %1565 ], [ %1559, %1564 ]
  br label %1579

1579:                                             ; preds = %1577
  %1580 = add i64 %89, %57
  %1581 = icmp slt i64 %1580, %26
  %1582 = select i1 %1581, i64 %1580, i64 0
  %1583 = extractelement <8 x float> %1380, i64 6
  %1584 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1585 = getelementptr inbounds nuw i8, ptr %1584, i64 %1582
  %1586 = load i8, ptr %1585, align 1
  %1587 = zext i8 %1586 to i32
  %1588 = shl i32 %1587, 23
  %1589 = bitcast i32 %1588 to float
  %1590 = fmul float %1589, %1583
  %1591 = extractelement <8 x float> %164, i64 6
  %1592 = fmul float %1591, %1590
  %1593 = call float @llvm.fabs.f32(float %1590)
  %1594 = fcmp olt float %1593, +inf
  %1595 = fcmp one float %1590, 0.000000e+00
  %1596 = and i1 %1594, %1595
  br i1 %1596, label %1597, label %1598

1597:                                             ; preds = %1579
  br label %1610

1598:                                             ; preds = %1579
  %1599 = fpext float %1591 to double
  %1600 = fpext float %1589 to double
  %1601 = fpext float %1583 to double
  %1602 = fmul double %1599, %1600
  %1603 = fmul double %1602, %1601
  %1604 = fptrunc double %1603 to float
  %1605 = fcmp oeq float %1591, 0.000000e+00
  %1606 = call float @llvm.fabs.f32(float %1583)
  %1607 = fcmp olt float %1606, +inf
  %1608 = and i1 %1605, %1607
  %1609 = select i1 %1608, float 0.000000e+00, float %1604
  br label %1610

1610:                                             ; preds = %1597, %1598
  %1611 = phi float [ %1609, %1598 ], [ %1592, %1597 ]
  br label %1612

1612:                                             ; preds = %1610
  %1613 = add i64 %89, %57
  %1614 = icmp slt i64 %1613, %26
  %1615 = select i1 %1614, i64 %1613, i64 0
  %1616 = extractelement <8 x float> %1380, i64 7
  %1617 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1618 = getelementptr inbounds nuw i8, ptr %1617, i64 %1615
  %1619 = load i8, ptr %1618, align 1
  %1620 = zext i8 %1619 to i32
  %1621 = shl i32 %1620, 23
  %1622 = bitcast i32 %1621 to float
  %1623 = fmul float %1622, %1616
  %1624 = extractelement <8 x float> %164, i64 7
  %1625 = fmul float %1624, %1623
  %1626 = call float @llvm.fabs.f32(float %1623)
  %1627 = fcmp olt float %1626, +inf
  %1628 = fcmp one float %1623, 0.000000e+00
  %1629 = and i1 %1627, %1628
  br i1 %1629, label %1630, label %1631

1630:                                             ; preds = %1612
  br label %1643

1631:                                             ; preds = %1612
  %1632 = fpext float %1624 to double
  %1633 = fpext float %1622 to double
  %1634 = fpext float %1616 to double
  %1635 = fmul double %1632, %1633
  %1636 = fmul double %1635, %1634
  %1637 = fptrunc double %1636 to float
  %1638 = fcmp oeq float %1624, 0.000000e+00
  %1639 = call float @llvm.fabs.f32(float %1616)
  %1640 = fcmp olt float %1639, +inf
  %1641 = and i1 %1638, %1640
  %1642 = select i1 %1641, float 0.000000e+00, float %1637
  br label %1643

1643:                                             ; preds = %1630, %1631
  %1644 = phi float [ %1642, %1631 ], [ %1625, %1630 ]
  br label %1645

1645:                                             ; preds = %1643
  %1646 = mul i64 %58, 8
  %1647 = add i64 %86, %1646
  %1648 = add i64 %89, %57
  %1649 = mul i64 %1647, %26
  %1650 = add i64 %1649, %1648
  %1651 = fptrunc float %1413 to bfloat
  %1652 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1653 = getelementptr inbounds nuw bfloat, ptr %1652, i64 %1650
  store bfloat %1651, ptr %1653, align 2
  %1654 = mul i64 %58, 8
  %1655 = add i64 %1654, 1
  %1656 = add i64 %86, %1655
  %1657 = add i64 %89, %57
  %1658 = mul i64 %1656, %26
  %1659 = add i64 %1658, %1657
  %1660 = fptrunc float %1446 to bfloat
  %1661 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1662 = getelementptr inbounds nuw bfloat, ptr %1661, i64 %1659
  store bfloat %1660, ptr %1662, align 2
  %1663 = mul i64 %58, 8
  %1664 = add i64 %1663, 2
  %1665 = add i64 %86, %1664
  %1666 = add i64 %89, %57
  %1667 = mul i64 %1665, %26
  %1668 = add i64 %1667, %1666
  %1669 = fptrunc float %1479 to bfloat
  %1670 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1671 = getelementptr inbounds nuw bfloat, ptr %1670, i64 %1668
  store bfloat %1669, ptr %1671, align 2
  %1672 = mul i64 %58, 8
  %1673 = add i64 %1672, 3
  %1674 = add i64 %86, %1673
  %1675 = add i64 %89, %57
  %1676 = mul i64 %1674, %26
  %1677 = add i64 %1676, %1675
  %1678 = fptrunc float %1512 to bfloat
  %1679 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1680 = getelementptr inbounds nuw bfloat, ptr %1679, i64 %1677
  store bfloat %1678, ptr %1680, align 2
  %1681 = mul i64 %58, 8
  %1682 = add i64 %1681, 4
  %1683 = add i64 %86, %1682
  %1684 = add i64 %89, %57
  %1685 = mul i64 %1683, %26
  %1686 = add i64 %1685, %1684
  %1687 = fptrunc float %1545 to bfloat
  %1688 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1689 = getelementptr inbounds nuw bfloat, ptr %1688, i64 %1686
  store bfloat %1687, ptr %1689, align 2
  %1690 = mul i64 %58, 8
  %1691 = add i64 %1690, 5
  %1692 = add i64 %86, %1691
  %1693 = add i64 %89, %57
  %1694 = mul i64 %1692, %26
  %1695 = add i64 %1694, %1693
  %1696 = fptrunc float %1578 to bfloat
  %1697 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1698 = getelementptr inbounds nuw bfloat, ptr %1697, i64 %1695
  store bfloat %1696, ptr %1698, align 2
  %1699 = mul i64 %58, 8
  %1700 = add i64 %1699, 6
  %1701 = add i64 %86, %1700
  %1702 = add i64 %89, %57
  %1703 = mul i64 %1701, %26
  %1704 = add i64 %1703, %1702
  %1705 = fptrunc float %1611 to bfloat
  %1706 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1707 = getelementptr inbounds nuw bfloat, ptr %1706, i64 %1704
  store bfloat %1705, ptr %1707, align 2
  %1708 = mul i64 %58, 8
  %1709 = add i64 %1708, 7
  %1710 = add i64 %86, %1709
  %1711 = add i64 %89, %57
  %1712 = mul i64 %1710, %26
  %1713 = add i64 %1712, %1711
  %1714 = fptrunc float %1644 to bfloat
  %1715 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1716 = getelementptr inbounds nuw bfloat, ptr %1715, i64 %1713
  store bfloat %1714, ptr %1716, align 2
  %1717 = mul i64 %58, 8
  %1718 = add i64 %88, %1717
  %1719 = add i64 %89, %57
  %1720 = add i64 %1718, 7
  %1721 = icmp ult i64 %1719, %26
  %1722 = icmp ult i64 %1720, %25
  %1723 = and i1 %1722, %1721
  %1724 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1725 = ptrtoint ptr %1724 to i64
  %1726 = mul i64 %1718, 4
  %1727 = add i64 %1725, %1726
  %1728 = urem i64 %1727, 16
  %1729 = icmp eq i64 %1728, 0
  %1730 = and i1 %1723, %1729
  br i1 %1730, label %1731, label %1740

1731:                                             ; preds = %1645
  %1732 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1733 = getelementptr float, ptr %1732, i64 %1718
  %1734 = load <4 x float>, ptr %1733, align 16
  %1735 = add i64 %1718, 4
  %1736 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1737 = getelementptr float, ptr %1736, i64 %1735
  %1738 = load <4 x float>, ptr %1737, align 16
  %1739 = shufflevector <4 x float> %1734, <4 x float> %1738, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1812

1740:                                             ; preds = %1645
  %1741 = mul i64 %58, 8
  %1742 = add i64 %88, %1741
  %1743 = icmp slt i64 %1742, %25
  %1744 = select i1 %1743, i64 %1742, i64 0
  %1745 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1746 = getelementptr inbounds nuw float, ptr %1745, i64 %1744
  %1747 = load float, ptr %1746, align 4
  %1748 = insertelement <8 x float> zeroinitializer, float %1747, i64 0
  %1749 = mul i64 %58, 8
  %1750 = add i64 %1749, 1
  %1751 = add i64 %88, %1750
  %1752 = icmp slt i64 %1751, %25
  %1753 = select i1 %1752, i64 %1751, i64 0
  %1754 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1755 = getelementptr inbounds nuw float, ptr %1754, i64 %1753
  %1756 = load float, ptr %1755, align 4
  %1757 = insertelement <8 x float> %1748, float %1756, i64 1
  %1758 = mul i64 %58, 8
  %1759 = add i64 %1758, 2
  %1760 = add i64 %88, %1759
  %1761 = icmp slt i64 %1760, %25
  %1762 = select i1 %1761, i64 %1760, i64 0
  %1763 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1764 = getelementptr inbounds nuw float, ptr %1763, i64 %1762
  %1765 = load float, ptr %1764, align 4
  %1766 = insertelement <8 x float> %1757, float %1765, i64 2
  %1767 = mul i64 %58, 8
  %1768 = add i64 %1767, 3
  %1769 = add i64 %88, %1768
  %1770 = icmp slt i64 %1769, %25
  %1771 = select i1 %1770, i64 %1769, i64 0
  %1772 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1773 = getelementptr inbounds nuw float, ptr %1772, i64 %1771
  %1774 = load float, ptr %1773, align 4
  %1775 = insertelement <8 x float> %1766, float %1774, i64 3
  %1776 = mul i64 %58, 8
  %1777 = add i64 %1776, 4
  %1778 = add i64 %88, %1777
  %1779 = icmp slt i64 %1778, %25
  %1780 = select i1 %1779, i64 %1778, i64 0
  %1781 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1782 = getelementptr inbounds nuw float, ptr %1781, i64 %1780
  %1783 = load float, ptr %1782, align 4
  %1784 = insertelement <8 x float> %1775, float %1783, i64 4
  %1785 = mul i64 %58, 8
  %1786 = add i64 %1785, 5
  %1787 = add i64 %88, %1786
  %1788 = icmp slt i64 %1787, %25
  %1789 = select i1 %1788, i64 %1787, i64 0
  %1790 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1791 = getelementptr inbounds nuw float, ptr %1790, i64 %1789
  %1792 = load float, ptr %1791, align 4
  %1793 = insertelement <8 x float> %1784, float %1792, i64 5
  %1794 = mul i64 %58, 8
  %1795 = add i64 %1794, 6
  %1796 = add i64 %88, %1795
  %1797 = icmp slt i64 %1796, %25
  %1798 = select i1 %1797, i64 %1796, i64 0
  %1799 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1800 = getelementptr inbounds nuw float, ptr %1799, i64 %1798
  %1801 = load float, ptr %1800, align 4
  %1802 = insertelement <8 x float> %1793, float %1801, i64 6
  %1803 = mul i64 %58, 8
  %1804 = add i64 %1803, 7
  %1805 = add i64 %88, %1804
  %1806 = icmp slt i64 %1805, %25
  %1807 = select i1 %1806, i64 %1805, i64 0
  %1808 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1809 = getelementptr inbounds nuw float, ptr %1808, i64 %1807
  %1810 = load float, ptr %1809, align 4
  %1811 = insertelement <8 x float> %1802, float %1810, i64 7
  br label %1812

1812:                                             ; preds = %1731, %1740
  %1813 = phi <8 x float> [ %1811, %1740 ], [ %1739, %1731 ]
  br label %1814

1814:                                             ; preds = %1812
  %1815 = add i64 %89, %57
  %1816 = icmp slt i64 %1815, %26
  %1817 = select i1 %1816, i64 %1815, i64 0
  %1818 = extractelement <8 x float> %1813, i64 0
  %1819 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1820 = getelementptr inbounds nuw i8, ptr %1819, i64 %1817
  %1821 = load i8, ptr %1820, align 1
  %1822 = zext i8 %1821 to i32
  %1823 = shl i32 %1822, 23
  %1824 = bitcast i32 %1823 to float
  %1825 = fmul float %1824, %1818
  %1826 = extractelement <8 x float> %166, i64 0
  %1827 = fmul float %1826, %1825
  %1828 = call float @llvm.fabs.f32(float %1825)
  %1829 = fcmp olt float %1828, +inf
  %1830 = fcmp one float %1825, 0.000000e+00
  %1831 = and i1 %1829, %1830
  br i1 %1831, label %1832, label %1833

1832:                                             ; preds = %1814
  br label %1845

1833:                                             ; preds = %1814
  %1834 = fpext float %1826 to double
  %1835 = fpext float %1824 to double
  %1836 = fpext float %1818 to double
  %1837 = fmul double %1834, %1835
  %1838 = fmul double %1837, %1836
  %1839 = fptrunc double %1838 to float
  %1840 = fcmp oeq float %1826, 0.000000e+00
  %1841 = call float @llvm.fabs.f32(float %1818)
  %1842 = fcmp olt float %1841, +inf
  %1843 = and i1 %1840, %1842
  %1844 = select i1 %1843, float 0.000000e+00, float %1839
  br label %1845

1845:                                             ; preds = %1832, %1833
  %1846 = phi float [ %1844, %1833 ], [ %1827, %1832 ]
  br label %1847

1847:                                             ; preds = %1845
  %1848 = add i64 %89, %57
  %1849 = icmp slt i64 %1848, %26
  %1850 = select i1 %1849, i64 %1848, i64 0
  %1851 = extractelement <8 x float> %1813, i64 1
  %1852 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1853 = getelementptr inbounds nuw i8, ptr %1852, i64 %1850
  %1854 = load i8, ptr %1853, align 1
  %1855 = zext i8 %1854 to i32
  %1856 = shl i32 %1855, 23
  %1857 = bitcast i32 %1856 to float
  %1858 = fmul float %1857, %1851
  %1859 = extractelement <8 x float> %166, i64 1
  %1860 = fmul float %1859, %1858
  %1861 = call float @llvm.fabs.f32(float %1858)
  %1862 = fcmp olt float %1861, +inf
  %1863 = fcmp one float %1858, 0.000000e+00
  %1864 = and i1 %1862, %1863
  br i1 %1864, label %1865, label %1866

1865:                                             ; preds = %1847
  br label %1878

1866:                                             ; preds = %1847
  %1867 = fpext float %1859 to double
  %1868 = fpext float %1857 to double
  %1869 = fpext float %1851 to double
  %1870 = fmul double %1867, %1868
  %1871 = fmul double %1870, %1869
  %1872 = fptrunc double %1871 to float
  %1873 = fcmp oeq float %1859, 0.000000e+00
  %1874 = call float @llvm.fabs.f32(float %1851)
  %1875 = fcmp olt float %1874, +inf
  %1876 = and i1 %1873, %1875
  %1877 = select i1 %1876, float 0.000000e+00, float %1872
  br label %1878

1878:                                             ; preds = %1865, %1866
  %1879 = phi float [ %1877, %1866 ], [ %1860, %1865 ]
  br label %1880

1880:                                             ; preds = %1878
  %1881 = add i64 %89, %57
  %1882 = icmp slt i64 %1881, %26
  %1883 = select i1 %1882, i64 %1881, i64 0
  %1884 = extractelement <8 x float> %1813, i64 2
  %1885 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1886 = getelementptr inbounds nuw i8, ptr %1885, i64 %1883
  %1887 = load i8, ptr %1886, align 1
  %1888 = zext i8 %1887 to i32
  %1889 = shl i32 %1888, 23
  %1890 = bitcast i32 %1889 to float
  %1891 = fmul float %1890, %1884
  %1892 = extractelement <8 x float> %166, i64 2
  %1893 = fmul float %1892, %1891
  %1894 = call float @llvm.fabs.f32(float %1891)
  %1895 = fcmp olt float %1894, +inf
  %1896 = fcmp one float %1891, 0.000000e+00
  %1897 = and i1 %1895, %1896
  br i1 %1897, label %1898, label %1899

1898:                                             ; preds = %1880
  br label %1911

1899:                                             ; preds = %1880
  %1900 = fpext float %1892 to double
  %1901 = fpext float %1890 to double
  %1902 = fpext float %1884 to double
  %1903 = fmul double %1900, %1901
  %1904 = fmul double %1903, %1902
  %1905 = fptrunc double %1904 to float
  %1906 = fcmp oeq float %1892, 0.000000e+00
  %1907 = call float @llvm.fabs.f32(float %1884)
  %1908 = fcmp olt float %1907, +inf
  %1909 = and i1 %1906, %1908
  %1910 = select i1 %1909, float 0.000000e+00, float %1905
  br label %1911

1911:                                             ; preds = %1898, %1899
  %1912 = phi float [ %1910, %1899 ], [ %1893, %1898 ]
  br label %1913

1913:                                             ; preds = %1911
  %1914 = add i64 %89, %57
  %1915 = icmp slt i64 %1914, %26
  %1916 = select i1 %1915, i64 %1914, i64 0
  %1917 = extractelement <8 x float> %1813, i64 3
  %1918 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1919 = getelementptr inbounds nuw i8, ptr %1918, i64 %1916
  %1920 = load i8, ptr %1919, align 1
  %1921 = zext i8 %1920 to i32
  %1922 = shl i32 %1921, 23
  %1923 = bitcast i32 %1922 to float
  %1924 = fmul float %1923, %1917
  %1925 = extractelement <8 x float> %166, i64 3
  %1926 = fmul float %1925, %1924
  %1927 = call float @llvm.fabs.f32(float %1924)
  %1928 = fcmp olt float %1927, +inf
  %1929 = fcmp one float %1924, 0.000000e+00
  %1930 = and i1 %1928, %1929
  br i1 %1930, label %1931, label %1932

1931:                                             ; preds = %1913
  br label %1944

1932:                                             ; preds = %1913
  %1933 = fpext float %1925 to double
  %1934 = fpext float %1923 to double
  %1935 = fpext float %1917 to double
  %1936 = fmul double %1933, %1934
  %1937 = fmul double %1936, %1935
  %1938 = fptrunc double %1937 to float
  %1939 = fcmp oeq float %1925, 0.000000e+00
  %1940 = call float @llvm.fabs.f32(float %1917)
  %1941 = fcmp olt float %1940, +inf
  %1942 = and i1 %1939, %1941
  %1943 = select i1 %1942, float 0.000000e+00, float %1938
  br label %1944

1944:                                             ; preds = %1931, %1932
  %1945 = phi float [ %1943, %1932 ], [ %1926, %1931 ]
  br label %1946

1946:                                             ; preds = %1944
  %1947 = add i64 %89, %57
  %1948 = icmp slt i64 %1947, %26
  %1949 = select i1 %1948, i64 %1947, i64 0
  %1950 = extractelement <8 x float> %1813, i64 4
  %1951 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1952 = getelementptr inbounds nuw i8, ptr %1951, i64 %1949
  %1953 = load i8, ptr %1952, align 1
  %1954 = zext i8 %1953 to i32
  %1955 = shl i32 %1954, 23
  %1956 = bitcast i32 %1955 to float
  %1957 = fmul float %1956, %1950
  %1958 = extractelement <8 x float> %166, i64 4
  %1959 = fmul float %1958, %1957
  %1960 = call float @llvm.fabs.f32(float %1957)
  %1961 = fcmp olt float %1960, +inf
  %1962 = fcmp one float %1957, 0.000000e+00
  %1963 = and i1 %1961, %1962
  br i1 %1963, label %1964, label %1965

1964:                                             ; preds = %1946
  br label %1977

1965:                                             ; preds = %1946
  %1966 = fpext float %1958 to double
  %1967 = fpext float %1956 to double
  %1968 = fpext float %1950 to double
  %1969 = fmul double %1966, %1967
  %1970 = fmul double %1969, %1968
  %1971 = fptrunc double %1970 to float
  %1972 = fcmp oeq float %1958, 0.000000e+00
  %1973 = call float @llvm.fabs.f32(float %1950)
  %1974 = fcmp olt float %1973, +inf
  %1975 = and i1 %1972, %1974
  %1976 = select i1 %1975, float 0.000000e+00, float %1971
  br label %1977

1977:                                             ; preds = %1964, %1965
  %1978 = phi float [ %1976, %1965 ], [ %1959, %1964 ]
  br label %1979

1979:                                             ; preds = %1977
  %1980 = add i64 %89, %57
  %1981 = icmp slt i64 %1980, %26
  %1982 = select i1 %1981, i64 %1980, i64 0
  %1983 = extractelement <8 x float> %1813, i64 5
  %1984 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1985 = getelementptr inbounds nuw i8, ptr %1984, i64 %1982
  %1986 = load i8, ptr %1985, align 1
  %1987 = zext i8 %1986 to i32
  %1988 = shl i32 %1987, 23
  %1989 = bitcast i32 %1988 to float
  %1990 = fmul float %1989, %1983
  %1991 = extractelement <8 x float> %166, i64 5
  %1992 = fmul float %1991, %1990
  %1993 = call float @llvm.fabs.f32(float %1990)
  %1994 = fcmp olt float %1993, +inf
  %1995 = fcmp one float %1990, 0.000000e+00
  %1996 = and i1 %1994, %1995
  br i1 %1996, label %1997, label %1998

1997:                                             ; preds = %1979
  br label %2010

1998:                                             ; preds = %1979
  %1999 = fpext float %1991 to double
  %2000 = fpext float %1989 to double
  %2001 = fpext float %1983 to double
  %2002 = fmul double %1999, %2000
  %2003 = fmul double %2002, %2001
  %2004 = fptrunc double %2003 to float
  %2005 = fcmp oeq float %1991, 0.000000e+00
  %2006 = call float @llvm.fabs.f32(float %1983)
  %2007 = fcmp olt float %2006, +inf
  %2008 = and i1 %2005, %2007
  %2009 = select i1 %2008, float 0.000000e+00, float %2004
  br label %2010

2010:                                             ; preds = %1997, %1998
  %2011 = phi float [ %2009, %1998 ], [ %1992, %1997 ]
  br label %2012

2012:                                             ; preds = %2010
  %2013 = add i64 %89, %57
  %2014 = icmp slt i64 %2013, %26
  %2015 = select i1 %2014, i64 %2013, i64 0
  %2016 = extractelement <8 x float> %1813, i64 6
  %2017 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2018 = getelementptr inbounds nuw i8, ptr %2017, i64 %2015
  %2019 = load i8, ptr %2018, align 1
  %2020 = zext i8 %2019 to i32
  %2021 = shl i32 %2020, 23
  %2022 = bitcast i32 %2021 to float
  %2023 = fmul float %2022, %2016
  %2024 = extractelement <8 x float> %166, i64 6
  %2025 = fmul float %2024, %2023
  %2026 = call float @llvm.fabs.f32(float %2023)
  %2027 = fcmp olt float %2026, +inf
  %2028 = fcmp one float %2023, 0.000000e+00
  %2029 = and i1 %2027, %2028
  br i1 %2029, label %2030, label %2031

2030:                                             ; preds = %2012
  br label %2043

2031:                                             ; preds = %2012
  %2032 = fpext float %2024 to double
  %2033 = fpext float %2022 to double
  %2034 = fpext float %2016 to double
  %2035 = fmul double %2032, %2033
  %2036 = fmul double %2035, %2034
  %2037 = fptrunc double %2036 to float
  %2038 = fcmp oeq float %2024, 0.000000e+00
  %2039 = call float @llvm.fabs.f32(float %2016)
  %2040 = fcmp olt float %2039, +inf
  %2041 = and i1 %2038, %2040
  %2042 = select i1 %2041, float 0.000000e+00, float %2037
  br label %2043

2043:                                             ; preds = %2030, %2031
  %2044 = phi float [ %2042, %2031 ], [ %2025, %2030 ]
  br label %2045

2045:                                             ; preds = %2043
  %2046 = add i64 %89, %57
  %2047 = icmp slt i64 %2046, %26
  %2048 = select i1 %2047, i64 %2046, i64 0
  %2049 = extractelement <8 x float> %1813, i64 7
  %2050 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2051 = getelementptr inbounds nuw i8, ptr %2050, i64 %2048
  %2052 = load i8, ptr %2051, align 1
  %2053 = zext i8 %2052 to i32
  %2054 = shl i32 %2053, 23
  %2055 = bitcast i32 %2054 to float
  %2056 = fmul float %2055, %2049
  %2057 = extractelement <8 x float> %166, i64 7
  %2058 = fmul float %2057, %2056
  %2059 = call float @llvm.fabs.f32(float %2056)
  %2060 = fcmp olt float %2059, +inf
  %2061 = fcmp one float %2056, 0.000000e+00
  %2062 = and i1 %2060, %2061
  br i1 %2062, label %2063, label %2064

2063:                                             ; preds = %2045
  br label %2076

2064:                                             ; preds = %2045
  %2065 = fpext float %2057 to double
  %2066 = fpext float %2055 to double
  %2067 = fpext float %2049 to double
  %2068 = fmul double %2065, %2066
  %2069 = fmul double %2068, %2067
  %2070 = fptrunc double %2069 to float
  %2071 = fcmp oeq float %2057, 0.000000e+00
  %2072 = call float @llvm.fabs.f32(float %2049)
  %2073 = fcmp olt float %2072, +inf
  %2074 = and i1 %2071, %2073
  %2075 = select i1 %2074, float 0.000000e+00, float %2070
  br label %2076

2076:                                             ; preds = %2063, %2064
  %2077 = phi float [ %2075, %2064 ], [ %2058, %2063 ]
  br label %2078

2078:                                             ; preds = %2076
  %2079 = mul i64 %58, 8
  %2080 = add i64 %88, %2079
  %2081 = add i64 %89, %57
  %2082 = mul i64 %2080, %26
  %2083 = add i64 %2082, %2081
  %2084 = fptrunc float %1846 to bfloat
  %2085 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2086 = getelementptr inbounds nuw bfloat, ptr %2085, i64 %2083
  store bfloat %2084, ptr %2086, align 2
  %2087 = mul i64 %58, 8
  %2088 = add i64 %2087, 1
  %2089 = add i64 %88, %2088
  %2090 = add i64 %89, %57
  %2091 = mul i64 %2089, %26
  %2092 = add i64 %2091, %2090
  %2093 = fptrunc float %1879 to bfloat
  %2094 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2095 = getelementptr inbounds nuw bfloat, ptr %2094, i64 %2092
  store bfloat %2093, ptr %2095, align 2
  %2096 = mul i64 %58, 8
  %2097 = add i64 %2096, 2
  %2098 = add i64 %88, %2097
  %2099 = add i64 %89, %57
  %2100 = mul i64 %2098, %26
  %2101 = add i64 %2100, %2099
  %2102 = fptrunc float %1912 to bfloat
  %2103 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2104 = getelementptr inbounds nuw bfloat, ptr %2103, i64 %2101
  store bfloat %2102, ptr %2104, align 2
  %2105 = mul i64 %58, 8
  %2106 = add i64 %2105, 3
  %2107 = add i64 %88, %2106
  %2108 = add i64 %89, %57
  %2109 = mul i64 %2107, %26
  %2110 = add i64 %2109, %2108
  %2111 = fptrunc float %1945 to bfloat
  %2112 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2113 = getelementptr inbounds nuw bfloat, ptr %2112, i64 %2110
  store bfloat %2111, ptr %2113, align 2
  %2114 = mul i64 %58, 8
  %2115 = add i64 %2114, 4
  %2116 = add i64 %88, %2115
  %2117 = add i64 %89, %57
  %2118 = mul i64 %2116, %26
  %2119 = add i64 %2118, %2117
  %2120 = fptrunc float %1978 to bfloat
  %2121 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2122 = getelementptr inbounds nuw bfloat, ptr %2121, i64 %2119
  store bfloat %2120, ptr %2122, align 2
  %2123 = mul i64 %58, 8
  %2124 = add i64 %2123, 5
  %2125 = add i64 %88, %2124
  %2126 = add i64 %89, %57
  %2127 = mul i64 %2125, %26
  %2128 = add i64 %2127, %2126
  %2129 = fptrunc float %2011 to bfloat
  %2130 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2131 = getelementptr inbounds nuw bfloat, ptr %2130, i64 %2128
  store bfloat %2129, ptr %2131, align 2
  %2132 = mul i64 %58, 8
  %2133 = add i64 %2132, 6
  %2134 = add i64 %88, %2133
  %2135 = add i64 %89, %57
  %2136 = mul i64 %2134, %26
  %2137 = add i64 %2136, %2135
  %2138 = fptrunc float %2044 to bfloat
  %2139 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2140 = getelementptr inbounds nuw bfloat, ptr %2139, i64 %2137
  store bfloat %2138, ptr %2140, align 2
  %2141 = mul i64 %58, 8
  %2142 = add i64 %2141, 7
  %2143 = add i64 %88, %2142
  %2144 = add i64 %89, %57
  %2145 = mul i64 %2143, %26
  %2146 = add i64 %2145, %2144
  %2147 = fptrunc float %2077 to bfloat
  %2148 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2149 = getelementptr inbounds nuw bfloat, ptr %2148, i64 %2146
  store bfloat %2147, ptr %2149, align 2
  %2150 = mul i64 %58, 8
  %2151 = add i64 %82, %2150
  %2152 = add i64 %91, %57
  %2153 = add i64 %2151, 7
  %2154 = icmp ult i64 %2152, %26
  %2155 = icmp ult i64 %2153, %25
  %2156 = and i1 %2155, %2154
  %2157 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2158 = ptrtoint ptr %2157 to i64
  %2159 = mul i64 %2151, 4
  %2160 = add i64 %2158, %2159
  %2161 = urem i64 %2160, 16
  %2162 = icmp eq i64 %2161, 0
  %2163 = and i1 %2156, %2162
  br i1 %2163, label %2164, label %2173

2164:                                             ; preds = %2078
  %2165 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2166 = getelementptr float, ptr %2165, i64 %2151
  %2167 = load <4 x float>, ptr %2166, align 16
  %2168 = add i64 %2151, 4
  %2169 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2170 = getelementptr float, ptr %2169, i64 %2168
  %2171 = load <4 x float>, ptr %2170, align 16
  %2172 = shufflevector <4 x float> %2167, <4 x float> %2171, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2245

2173:                                             ; preds = %2078
  %2174 = mul i64 %58, 8
  %2175 = add i64 %82, %2174
  %2176 = icmp slt i64 %2175, %25
  %2177 = select i1 %2176, i64 %2175, i64 0
  %2178 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2179 = getelementptr inbounds nuw float, ptr %2178, i64 %2177
  %2180 = load float, ptr %2179, align 4
  %2181 = insertelement <8 x float> zeroinitializer, float %2180, i64 0
  %2182 = mul i64 %58, 8
  %2183 = add i64 %2182, 1
  %2184 = add i64 %82, %2183
  %2185 = icmp slt i64 %2184, %25
  %2186 = select i1 %2185, i64 %2184, i64 0
  %2187 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2188 = getelementptr inbounds nuw float, ptr %2187, i64 %2186
  %2189 = load float, ptr %2188, align 4
  %2190 = insertelement <8 x float> %2181, float %2189, i64 1
  %2191 = mul i64 %58, 8
  %2192 = add i64 %2191, 2
  %2193 = add i64 %82, %2192
  %2194 = icmp slt i64 %2193, %25
  %2195 = select i1 %2194, i64 %2193, i64 0
  %2196 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2197 = getelementptr inbounds nuw float, ptr %2196, i64 %2195
  %2198 = load float, ptr %2197, align 4
  %2199 = insertelement <8 x float> %2190, float %2198, i64 2
  %2200 = mul i64 %58, 8
  %2201 = add i64 %2200, 3
  %2202 = add i64 %82, %2201
  %2203 = icmp slt i64 %2202, %25
  %2204 = select i1 %2203, i64 %2202, i64 0
  %2205 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2206 = getelementptr inbounds nuw float, ptr %2205, i64 %2204
  %2207 = load float, ptr %2206, align 4
  %2208 = insertelement <8 x float> %2199, float %2207, i64 3
  %2209 = mul i64 %58, 8
  %2210 = add i64 %2209, 4
  %2211 = add i64 %82, %2210
  %2212 = icmp slt i64 %2211, %25
  %2213 = select i1 %2212, i64 %2211, i64 0
  %2214 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2215 = getelementptr inbounds nuw float, ptr %2214, i64 %2213
  %2216 = load float, ptr %2215, align 4
  %2217 = insertelement <8 x float> %2208, float %2216, i64 4
  %2218 = mul i64 %58, 8
  %2219 = add i64 %2218, 5
  %2220 = add i64 %82, %2219
  %2221 = icmp slt i64 %2220, %25
  %2222 = select i1 %2221, i64 %2220, i64 0
  %2223 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2224 = getelementptr inbounds nuw float, ptr %2223, i64 %2222
  %2225 = load float, ptr %2224, align 4
  %2226 = insertelement <8 x float> %2217, float %2225, i64 5
  %2227 = mul i64 %58, 8
  %2228 = add i64 %2227, 6
  %2229 = add i64 %82, %2228
  %2230 = icmp slt i64 %2229, %25
  %2231 = select i1 %2230, i64 %2229, i64 0
  %2232 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2233 = getelementptr inbounds nuw float, ptr %2232, i64 %2231
  %2234 = load float, ptr %2233, align 4
  %2235 = insertelement <8 x float> %2226, float %2234, i64 6
  %2236 = mul i64 %58, 8
  %2237 = add i64 %2236, 7
  %2238 = add i64 %82, %2237
  %2239 = icmp slt i64 %2238, %25
  %2240 = select i1 %2239, i64 %2238, i64 0
  %2241 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2242 = getelementptr inbounds nuw float, ptr %2241, i64 %2240
  %2243 = load float, ptr %2242, align 4
  %2244 = insertelement <8 x float> %2235, float %2243, i64 7
  br label %2245

2245:                                             ; preds = %2164, %2173
  %2246 = phi <8 x float> [ %2244, %2173 ], [ %2172, %2164 ]
  br label %2247

2247:                                             ; preds = %2245
  %2248 = add i64 %91, %57
  %2249 = icmp slt i64 %2248, %26
  %2250 = select i1 %2249, i64 %2248, i64 0
  %2251 = extractelement <8 x float> %2246, i64 0
  %2252 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2253 = getelementptr inbounds nuw i8, ptr %2252, i64 %2250
  %2254 = load i8, ptr %2253, align 1
  %2255 = zext i8 %2254 to i32
  %2256 = shl i32 %2255, 23
  %2257 = bitcast i32 %2256 to float
  %2258 = fmul float %2257, %2251
  %2259 = extractelement <8 x float> %161, i64 0
  %2260 = fmul float %2259, %2258
  %2261 = call float @llvm.fabs.f32(float %2258)
  %2262 = fcmp olt float %2261, +inf
  %2263 = fcmp one float %2258, 0.000000e+00
  %2264 = and i1 %2262, %2263
  br i1 %2264, label %2265, label %2266

2265:                                             ; preds = %2247
  br label %2278

2266:                                             ; preds = %2247
  %2267 = fpext float %2259 to double
  %2268 = fpext float %2257 to double
  %2269 = fpext float %2251 to double
  %2270 = fmul double %2267, %2268
  %2271 = fmul double %2270, %2269
  %2272 = fptrunc double %2271 to float
  %2273 = fcmp oeq float %2259, 0.000000e+00
  %2274 = call float @llvm.fabs.f32(float %2251)
  %2275 = fcmp olt float %2274, +inf
  %2276 = and i1 %2273, %2275
  %2277 = select i1 %2276, float 0.000000e+00, float %2272
  br label %2278

2278:                                             ; preds = %2265, %2266
  %2279 = phi float [ %2277, %2266 ], [ %2260, %2265 ]
  br label %2280

2280:                                             ; preds = %2278
  %2281 = add i64 %91, %57
  %2282 = icmp slt i64 %2281, %26
  %2283 = select i1 %2282, i64 %2281, i64 0
  %2284 = extractelement <8 x float> %2246, i64 1
  %2285 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2286 = getelementptr inbounds nuw i8, ptr %2285, i64 %2283
  %2287 = load i8, ptr %2286, align 1
  %2288 = zext i8 %2287 to i32
  %2289 = shl i32 %2288, 23
  %2290 = bitcast i32 %2289 to float
  %2291 = fmul float %2290, %2284
  %2292 = extractelement <8 x float> %161, i64 1
  %2293 = fmul float %2292, %2291
  %2294 = call float @llvm.fabs.f32(float %2291)
  %2295 = fcmp olt float %2294, +inf
  %2296 = fcmp one float %2291, 0.000000e+00
  %2297 = and i1 %2295, %2296
  br i1 %2297, label %2298, label %2299

2298:                                             ; preds = %2280
  br label %2311

2299:                                             ; preds = %2280
  %2300 = fpext float %2292 to double
  %2301 = fpext float %2290 to double
  %2302 = fpext float %2284 to double
  %2303 = fmul double %2300, %2301
  %2304 = fmul double %2303, %2302
  %2305 = fptrunc double %2304 to float
  %2306 = fcmp oeq float %2292, 0.000000e+00
  %2307 = call float @llvm.fabs.f32(float %2284)
  %2308 = fcmp olt float %2307, +inf
  %2309 = and i1 %2306, %2308
  %2310 = select i1 %2309, float 0.000000e+00, float %2305
  br label %2311

2311:                                             ; preds = %2298, %2299
  %2312 = phi float [ %2310, %2299 ], [ %2293, %2298 ]
  br label %2313

2313:                                             ; preds = %2311
  %2314 = add i64 %91, %57
  %2315 = icmp slt i64 %2314, %26
  %2316 = select i1 %2315, i64 %2314, i64 0
  %2317 = extractelement <8 x float> %2246, i64 2
  %2318 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2319 = getelementptr inbounds nuw i8, ptr %2318, i64 %2316
  %2320 = load i8, ptr %2319, align 1
  %2321 = zext i8 %2320 to i32
  %2322 = shl i32 %2321, 23
  %2323 = bitcast i32 %2322 to float
  %2324 = fmul float %2323, %2317
  %2325 = extractelement <8 x float> %161, i64 2
  %2326 = fmul float %2325, %2324
  %2327 = call float @llvm.fabs.f32(float %2324)
  %2328 = fcmp olt float %2327, +inf
  %2329 = fcmp one float %2324, 0.000000e+00
  %2330 = and i1 %2328, %2329
  br i1 %2330, label %2331, label %2332

2331:                                             ; preds = %2313
  br label %2344

2332:                                             ; preds = %2313
  %2333 = fpext float %2325 to double
  %2334 = fpext float %2323 to double
  %2335 = fpext float %2317 to double
  %2336 = fmul double %2333, %2334
  %2337 = fmul double %2336, %2335
  %2338 = fptrunc double %2337 to float
  %2339 = fcmp oeq float %2325, 0.000000e+00
  %2340 = call float @llvm.fabs.f32(float %2317)
  %2341 = fcmp olt float %2340, +inf
  %2342 = and i1 %2339, %2341
  %2343 = select i1 %2342, float 0.000000e+00, float %2338
  br label %2344

2344:                                             ; preds = %2331, %2332
  %2345 = phi float [ %2343, %2332 ], [ %2326, %2331 ]
  br label %2346

2346:                                             ; preds = %2344
  %2347 = add i64 %91, %57
  %2348 = icmp slt i64 %2347, %26
  %2349 = select i1 %2348, i64 %2347, i64 0
  %2350 = extractelement <8 x float> %2246, i64 3
  %2351 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2352 = getelementptr inbounds nuw i8, ptr %2351, i64 %2349
  %2353 = load i8, ptr %2352, align 1
  %2354 = zext i8 %2353 to i32
  %2355 = shl i32 %2354, 23
  %2356 = bitcast i32 %2355 to float
  %2357 = fmul float %2356, %2350
  %2358 = extractelement <8 x float> %161, i64 3
  %2359 = fmul float %2358, %2357
  %2360 = call float @llvm.fabs.f32(float %2357)
  %2361 = fcmp olt float %2360, +inf
  %2362 = fcmp one float %2357, 0.000000e+00
  %2363 = and i1 %2361, %2362
  br i1 %2363, label %2364, label %2365

2364:                                             ; preds = %2346
  br label %2377

2365:                                             ; preds = %2346
  %2366 = fpext float %2358 to double
  %2367 = fpext float %2356 to double
  %2368 = fpext float %2350 to double
  %2369 = fmul double %2366, %2367
  %2370 = fmul double %2369, %2368
  %2371 = fptrunc double %2370 to float
  %2372 = fcmp oeq float %2358, 0.000000e+00
  %2373 = call float @llvm.fabs.f32(float %2350)
  %2374 = fcmp olt float %2373, +inf
  %2375 = and i1 %2372, %2374
  %2376 = select i1 %2375, float 0.000000e+00, float %2371
  br label %2377

2377:                                             ; preds = %2364, %2365
  %2378 = phi float [ %2376, %2365 ], [ %2359, %2364 ]
  br label %2379

2379:                                             ; preds = %2377
  %2380 = add i64 %91, %57
  %2381 = icmp slt i64 %2380, %26
  %2382 = select i1 %2381, i64 %2380, i64 0
  %2383 = extractelement <8 x float> %2246, i64 4
  %2384 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2385 = getelementptr inbounds nuw i8, ptr %2384, i64 %2382
  %2386 = load i8, ptr %2385, align 1
  %2387 = zext i8 %2386 to i32
  %2388 = shl i32 %2387, 23
  %2389 = bitcast i32 %2388 to float
  %2390 = fmul float %2389, %2383
  %2391 = extractelement <8 x float> %161, i64 4
  %2392 = fmul float %2391, %2390
  %2393 = call float @llvm.fabs.f32(float %2390)
  %2394 = fcmp olt float %2393, +inf
  %2395 = fcmp one float %2390, 0.000000e+00
  %2396 = and i1 %2394, %2395
  br i1 %2396, label %2397, label %2398

2397:                                             ; preds = %2379
  br label %2410

2398:                                             ; preds = %2379
  %2399 = fpext float %2391 to double
  %2400 = fpext float %2389 to double
  %2401 = fpext float %2383 to double
  %2402 = fmul double %2399, %2400
  %2403 = fmul double %2402, %2401
  %2404 = fptrunc double %2403 to float
  %2405 = fcmp oeq float %2391, 0.000000e+00
  %2406 = call float @llvm.fabs.f32(float %2383)
  %2407 = fcmp olt float %2406, +inf
  %2408 = and i1 %2405, %2407
  %2409 = select i1 %2408, float 0.000000e+00, float %2404
  br label %2410

2410:                                             ; preds = %2397, %2398
  %2411 = phi float [ %2409, %2398 ], [ %2392, %2397 ]
  br label %2412

2412:                                             ; preds = %2410
  %2413 = add i64 %91, %57
  %2414 = icmp slt i64 %2413, %26
  %2415 = select i1 %2414, i64 %2413, i64 0
  %2416 = extractelement <8 x float> %2246, i64 5
  %2417 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2418 = getelementptr inbounds nuw i8, ptr %2417, i64 %2415
  %2419 = load i8, ptr %2418, align 1
  %2420 = zext i8 %2419 to i32
  %2421 = shl i32 %2420, 23
  %2422 = bitcast i32 %2421 to float
  %2423 = fmul float %2422, %2416
  %2424 = extractelement <8 x float> %161, i64 5
  %2425 = fmul float %2424, %2423
  %2426 = call float @llvm.fabs.f32(float %2423)
  %2427 = fcmp olt float %2426, +inf
  %2428 = fcmp one float %2423, 0.000000e+00
  %2429 = and i1 %2427, %2428
  br i1 %2429, label %2430, label %2431

2430:                                             ; preds = %2412
  br label %2443

2431:                                             ; preds = %2412
  %2432 = fpext float %2424 to double
  %2433 = fpext float %2422 to double
  %2434 = fpext float %2416 to double
  %2435 = fmul double %2432, %2433
  %2436 = fmul double %2435, %2434
  %2437 = fptrunc double %2436 to float
  %2438 = fcmp oeq float %2424, 0.000000e+00
  %2439 = call float @llvm.fabs.f32(float %2416)
  %2440 = fcmp olt float %2439, +inf
  %2441 = and i1 %2438, %2440
  %2442 = select i1 %2441, float 0.000000e+00, float %2437
  br label %2443

2443:                                             ; preds = %2430, %2431
  %2444 = phi float [ %2442, %2431 ], [ %2425, %2430 ]
  br label %2445

2445:                                             ; preds = %2443
  %2446 = add i64 %91, %57
  %2447 = icmp slt i64 %2446, %26
  %2448 = select i1 %2447, i64 %2446, i64 0
  %2449 = extractelement <8 x float> %2246, i64 6
  %2450 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2451 = getelementptr inbounds nuw i8, ptr %2450, i64 %2448
  %2452 = load i8, ptr %2451, align 1
  %2453 = zext i8 %2452 to i32
  %2454 = shl i32 %2453, 23
  %2455 = bitcast i32 %2454 to float
  %2456 = fmul float %2455, %2449
  %2457 = extractelement <8 x float> %161, i64 6
  %2458 = fmul float %2457, %2456
  %2459 = call float @llvm.fabs.f32(float %2456)
  %2460 = fcmp olt float %2459, +inf
  %2461 = fcmp one float %2456, 0.000000e+00
  %2462 = and i1 %2460, %2461
  br i1 %2462, label %2463, label %2464

2463:                                             ; preds = %2445
  br label %2476

2464:                                             ; preds = %2445
  %2465 = fpext float %2457 to double
  %2466 = fpext float %2455 to double
  %2467 = fpext float %2449 to double
  %2468 = fmul double %2465, %2466
  %2469 = fmul double %2468, %2467
  %2470 = fptrunc double %2469 to float
  %2471 = fcmp oeq float %2457, 0.000000e+00
  %2472 = call float @llvm.fabs.f32(float %2449)
  %2473 = fcmp olt float %2472, +inf
  %2474 = and i1 %2471, %2473
  %2475 = select i1 %2474, float 0.000000e+00, float %2470
  br label %2476

2476:                                             ; preds = %2463, %2464
  %2477 = phi float [ %2475, %2464 ], [ %2458, %2463 ]
  br label %2478

2478:                                             ; preds = %2476
  %2479 = add i64 %91, %57
  %2480 = icmp slt i64 %2479, %26
  %2481 = select i1 %2480, i64 %2479, i64 0
  %2482 = extractelement <8 x float> %2246, i64 7
  %2483 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2484 = getelementptr inbounds nuw i8, ptr %2483, i64 %2481
  %2485 = load i8, ptr %2484, align 1
  %2486 = zext i8 %2485 to i32
  %2487 = shl i32 %2486, 23
  %2488 = bitcast i32 %2487 to float
  %2489 = fmul float %2488, %2482
  %2490 = extractelement <8 x float> %161, i64 7
  %2491 = fmul float %2490, %2489
  %2492 = call float @llvm.fabs.f32(float %2489)
  %2493 = fcmp olt float %2492, +inf
  %2494 = fcmp one float %2489, 0.000000e+00
  %2495 = and i1 %2493, %2494
  br i1 %2495, label %2496, label %2497

2496:                                             ; preds = %2478
  br label %2509

2497:                                             ; preds = %2478
  %2498 = fpext float %2490 to double
  %2499 = fpext float %2488 to double
  %2500 = fpext float %2482 to double
  %2501 = fmul double %2498, %2499
  %2502 = fmul double %2501, %2500
  %2503 = fptrunc double %2502 to float
  %2504 = fcmp oeq float %2490, 0.000000e+00
  %2505 = call float @llvm.fabs.f32(float %2482)
  %2506 = fcmp olt float %2505, +inf
  %2507 = and i1 %2504, %2506
  %2508 = select i1 %2507, float 0.000000e+00, float %2503
  br label %2509

2509:                                             ; preds = %2496, %2497
  %2510 = phi float [ %2508, %2497 ], [ %2491, %2496 ]
  br label %2511

2511:                                             ; preds = %2509
  %2512 = mul i64 %58, 8
  %2513 = add i64 %82, %2512
  %2514 = add i64 %91, %57
  %2515 = mul i64 %2513, %26
  %2516 = add i64 %2515, %2514
  %2517 = fptrunc float %2279 to bfloat
  %2518 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2519 = getelementptr inbounds nuw bfloat, ptr %2518, i64 %2516
  store bfloat %2517, ptr %2519, align 2
  %2520 = mul i64 %58, 8
  %2521 = add i64 %2520, 1
  %2522 = add i64 %82, %2521
  %2523 = add i64 %91, %57
  %2524 = mul i64 %2522, %26
  %2525 = add i64 %2524, %2523
  %2526 = fptrunc float %2312 to bfloat
  %2527 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2528 = getelementptr inbounds nuw bfloat, ptr %2527, i64 %2525
  store bfloat %2526, ptr %2528, align 2
  %2529 = mul i64 %58, 8
  %2530 = add i64 %2529, 2
  %2531 = add i64 %82, %2530
  %2532 = add i64 %91, %57
  %2533 = mul i64 %2531, %26
  %2534 = add i64 %2533, %2532
  %2535 = fptrunc float %2345 to bfloat
  %2536 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2537 = getelementptr inbounds nuw bfloat, ptr %2536, i64 %2534
  store bfloat %2535, ptr %2537, align 2
  %2538 = mul i64 %58, 8
  %2539 = add i64 %2538, 3
  %2540 = add i64 %82, %2539
  %2541 = add i64 %91, %57
  %2542 = mul i64 %2540, %26
  %2543 = add i64 %2542, %2541
  %2544 = fptrunc float %2378 to bfloat
  %2545 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2546 = getelementptr inbounds nuw bfloat, ptr %2545, i64 %2543
  store bfloat %2544, ptr %2546, align 2
  %2547 = mul i64 %58, 8
  %2548 = add i64 %2547, 4
  %2549 = add i64 %82, %2548
  %2550 = add i64 %91, %57
  %2551 = mul i64 %2549, %26
  %2552 = add i64 %2551, %2550
  %2553 = fptrunc float %2411 to bfloat
  %2554 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2555 = getelementptr inbounds nuw bfloat, ptr %2554, i64 %2552
  store bfloat %2553, ptr %2555, align 2
  %2556 = mul i64 %58, 8
  %2557 = add i64 %2556, 5
  %2558 = add i64 %82, %2557
  %2559 = add i64 %91, %57
  %2560 = mul i64 %2558, %26
  %2561 = add i64 %2560, %2559
  %2562 = fptrunc float %2444 to bfloat
  %2563 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2564 = getelementptr inbounds nuw bfloat, ptr %2563, i64 %2561
  store bfloat %2562, ptr %2564, align 2
  %2565 = mul i64 %58, 8
  %2566 = add i64 %2565, 6
  %2567 = add i64 %82, %2566
  %2568 = add i64 %91, %57
  %2569 = mul i64 %2567, %26
  %2570 = add i64 %2569, %2568
  %2571 = fptrunc float %2477 to bfloat
  %2572 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2573 = getelementptr inbounds nuw bfloat, ptr %2572, i64 %2570
  store bfloat %2571, ptr %2573, align 2
  %2574 = mul i64 %58, 8
  %2575 = add i64 %2574, 7
  %2576 = add i64 %82, %2575
  %2577 = add i64 %91, %57
  %2578 = mul i64 %2576, %26
  %2579 = add i64 %2578, %2577
  %2580 = fptrunc float %2510 to bfloat
  %2581 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2582 = getelementptr inbounds nuw bfloat, ptr %2581, i64 %2579
  store bfloat %2580, ptr %2582, align 2
  %2583 = mul i64 %58, 8
  %2584 = add i64 %84, %2583
  %2585 = add i64 %91, %57
  %2586 = add i64 %2584, 7
  %2587 = icmp ult i64 %2585, %26
  %2588 = icmp ult i64 %2586, %25
  %2589 = and i1 %2588, %2587
  %2590 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2591 = ptrtoint ptr %2590 to i64
  %2592 = mul i64 %2584, 4
  %2593 = add i64 %2591, %2592
  %2594 = urem i64 %2593, 16
  %2595 = icmp eq i64 %2594, 0
  %2596 = and i1 %2589, %2595
  br i1 %2596, label %2597, label %2606

2597:                                             ; preds = %2511
  %2598 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2599 = getelementptr float, ptr %2598, i64 %2584
  %2600 = load <4 x float>, ptr %2599, align 16
  %2601 = add i64 %2584, 4
  %2602 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2603 = getelementptr float, ptr %2602, i64 %2601
  %2604 = load <4 x float>, ptr %2603, align 16
  %2605 = shufflevector <4 x float> %2600, <4 x float> %2604, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2678

2606:                                             ; preds = %2511
  %2607 = mul i64 %58, 8
  %2608 = add i64 %84, %2607
  %2609 = icmp slt i64 %2608, %25
  %2610 = select i1 %2609, i64 %2608, i64 0
  %2611 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2612 = getelementptr inbounds nuw float, ptr %2611, i64 %2610
  %2613 = load float, ptr %2612, align 4
  %2614 = insertelement <8 x float> zeroinitializer, float %2613, i64 0
  %2615 = mul i64 %58, 8
  %2616 = add i64 %2615, 1
  %2617 = add i64 %84, %2616
  %2618 = icmp slt i64 %2617, %25
  %2619 = select i1 %2618, i64 %2617, i64 0
  %2620 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2621 = getelementptr inbounds nuw float, ptr %2620, i64 %2619
  %2622 = load float, ptr %2621, align 4
  %2623 = insertelement <8 x float> %2614, float %2622, i64 1
  %2624 = mul i64 %58, 8
  %2625 = add i64 %2624, 2
  %2626 = add i64 %84, %2625
  %2627 = icmp slt i64 %2626, %25
  %2628 = select i1 %2627, i64 %2626, i64 0
  %2629 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2630 = getelementptr inbounds nuw float, ptr %2629, i64 %2628
  %2631 = load float, ptr %2630, align 4
  %2632 = insertelement <8 x float> %2623, float %2631, i64 2
  %2633 = mul i64 %58, 8
  %2634 = add i64 %2633, 3
  %2635 = add i64 %84, %2634
  %2636 = icmp slt i64 %2635, %25
  %2637 = select i1 %2636, i64 %2635, i64 0
  %2638 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2639 = getelementptr inbounds nuw float, ptr %2638, i64 %2637
  %2640 = load float, ptr %2639, align 4
  %2641 = insertelement <8 x float> %2632, float %2640, i64 3
  %2642 = mul i64 %58, 8
  %2643 = add i64 %2642, 4
  %2644 = add i64 %84, %2643
  %2645 = icmp slt i64 %2644, %25
  %2646 = select i1 %2645, i64 %2644, i64 0
  %2647 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2648 = getelementptr inbounds nuw float, ptr %2647, i64 %2646
  %2649 = load float, ptr %2648, align 4
  %2650 = insertelement <8 x float> %2641, float %2649, i64 4
  %2651 = mul i64 %58, 8
  %2652 = add i64 %2651, 5
  %2653 = add i64 %84, %2652
  %2654 = icmp slt i64 %2653, %25
  %2655 = select i1 %2654, i64 %2653, i64 0
  %2656 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2657 = getelementptr inbounds nuw float, ptr %2656, i64 %2655
  %2658 = load float, ptr %2657, align 4
  %2659 = insertelement <8 x float> %2650, float %2658, i64 5
  %2660 = mul i64 %58, 8
  %2661 = add i64 %2660, 6
  %2662 = add i64 %84, %2661
  %2663 = icmp slt i64 %2662, %25
  %2664 = select i1 %2663, i64 %2662, i64 0
  %2665 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2666 = getelementptr inbounds nuw float, ptr %2665, i64 %2664
  %2667 = load float, ptr %2666, align 4
  %2668 = insertelement <8 x float> %2659, float %2667, i64 6
  %2669 = mul i64 %58, 8
  %2670 = add i64 %2669, 7
  %2671 = add i64 %84, %2670
  %2672 = icmp slt i64 %2671, %25
  %2673 = select i1 %2672, i64 %2671, i64 0
  %2674 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2675 = getelementptr inbounds nuw float, ptr %2674, i64 %2673
  %2676 = load float, ptr %2675, align 4
  %2677 = insertelement <8 x float> %2668, float %2676, i64 7
  br label %2678

2678:                                             ; preds = %2597, %2606
  %2679 = phi <8 x float> [ %2677, %2606 ], [ %2605, %2597 ]
  br label %2680

2680:                                             ; preds = %2678
  %2681 = add i64 %91, %57
  %2682 = icmp slt i64 %2681, %26
  %2683 = select i1 %2682, i64 %2681, i64 0
  %2684 = extractelement <8 x float> %2679, i64 0
  %2685 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2686 = getelementptr inbounds nuw i8, ptr %2685, i64 %2683
  %2687 = load i8, ptr %2686, align 1
  %2688 = zext i8 %2687 to i32
  %2689 = shl i32 %2688, 23
  %2690 = bitcast i32 %2689 to float
  %2691 = fmul float %2690, %2684
  %2692 = extractelement <8 x float> %163, i64 0
  %2693 = fmul float %2692, %2691
  %2694 = call float @llvm.fabs.f32(float %2691)
  %2695 = fcmp olt float %2694, +inf
  %2696 = fcmp one float %2691, 0.000000e+00
  %2697 = and i1 %2695, %2696
  br i1 %2697, label %2698, label %2699

2698:                                             ; preds = %2680
  br label %2711

2699:                                             ; preds = %2680
  %2700 = fpext float %2692 to double
  %2701 = fpext float %2690 to double
  %2702 = fpext float %2684 to double
  %2703 = fmul double %2700, %2701
  %2704 = fmul double %2703, %2702
  %2705 = fptrunc double %2704 to float
  %2706 = fcmp oeq float %2692, 0.000000e+00
  %2707 = call float @llvm.fabs.f32(float %2684)
  %2708 = fcmp olt float %2707, +inf
  %2709 = and i1 %2706, %2708
  %2710 = select i1 %2709, float 0.000000e+00, float %2705
  br label %2711

2711:                                             ; preds = %2698, %2699
  %2712 = phi float [ %2710, %2699 ], [ %2693, %2698 ]
  br label %2713

2713:                                             ; preds = %2711
  %2714 = add i64 %91, %57
  %2715 = icmp slt i64 %2714, %26
  %2716 = select i1 %2715, i64 %2714, i64 0
  %2717 = extractelement <8 x float> %2679, i64 1
  %2718 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2719 = getelementptr inbounds nuw i8, ptr %2718, i64 %2716
  %2720 = load i8, ptr %2719, align 1
  %2721 = zext i8 %2720 to i32
  %2722 = shl i32 %2721, 23
  %2723 = bitcast i32 %2722 to float
  %2724 = fmul float %2723, %2717
  %2725 = extractelement <8 x float> %163, i64 1
  %2726 = fmul float %2725, %2724
  %2727 = call float @llvm.fabs.f32(float %2724)
  %2728 = fcmp olt float %2727, +inf
  %2729 = fcmp one float %2724, 0.000000e+00
  %2730 = and i1 %2728, %2729
  br i1 %2730, label %2731, label %2732

2731:                                             ; preds = %2713
  br label %2744

2732:                                             ; preds = %2713
  %2733 = fpext float %2725 to double
  %2734 = fpext float %2723 to double
  %2735 = fpext float %2717 to double
  %2736 = fmul double %2733, %2734
  %2737 = fmul double %2736, %2735
  %2738 = fptrunc double %2737 to float
  %2739 = fcmp oeq float %2725, 0.000000e+00
  %2740 = call float @llvm.fabs.f32(float %2717)
  %2741 = fcmp olt float %2740, +inf
  %2742 = and i1 %2739, %2741
  %2743 = select i1 %2742, float 0.000000e+00, float %2738
  br label %2744

2744:                                             ; preds = %2731, %2732
  %2745 = phi float [ %2743, %2732 ], [ %2726, %2731 ]
  br label %2746

2746:                                             ; preds = %2744
  %2747 = add i64 %91, %57
  %2748 = icmp slt i64 %2747, %26
  %2749 = select i1 %2748, i64 %2747, i64 0
  %2750 = extractelement <8 x float> %2679, i64 2
  %2751 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2752 = getelementptr inbounds nuw i8, ptr %2751, i64 %2749
  %2753 = load i8, ptr %2752, align 1
  %2754 = zext i8 %2753 to i32
  %2755 = shl i32 %2754, 23
  %2756 = bitcast i32 %2755 to float
  %2757 = fmul float %2756, %2750
  %2758 = extractelement <8 x float> %163, i64 2
  %2759 = fmul float %2758, %2757
  %2760 = call float @llvm.fabs.f32(float %2757)
  %2761 = fcmp olt float %2760, +inf
  %2762 = fcmp one float %2757, 0.000000e+00
  %2763 = and i1 %2761, %2762
  br i1 %2763, label %2764, label %2765

2764:                                             ; preds = %2746
  br label %2777

2765:                                             ; preds = %2746
  %2766 = fpext float %2758 to double
  %2767 = fpext float %2756 to double
  %2768 = fpext float %2750 to double
  %2769 = fmul double %2766, %2767
  %2770 = fmul double %2769, %2768
  %2771 = fptrunc double %2770 to float
  %2772 = fcmp oeq float %2758, 0.000000e+00
  %2773 = call float @llvm.fabs.f32(float %2750)
  %2774 = fcmp olt float %2773, +inf
  %2775 = and i1 %2772, %2774
  %2776 = select i1 %2775, float 0.000000e+00, float %2771
  br label %2777

2777:                                             ; preds = %2764, %2765
  %2778 = phi float [ %2776, %2765 ], [ %2759, %2764 ]
  br label %2779

2779:                                             ; preds = %2777
  %2780 = add i64 %91, %57
  %2781 = icmp slt i64 %2780, %26
  %2782 = select i1 %2781, i64 %2780, i64 0
  %2783 = extractelement <8 x float> %2679, i64 3
  %2784 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2785 = getelementptr inbounds nuw i8, ptr %2784, i64 %2782
  %2786 = load i8, ptr %2785, align 1
  %2787 = zext i8 %2786 to i32
  %2788 = shl i32 %2787, 23
  %2789 = bitcast i32 %2788 to float
  %2790 = fmul float %2789, %2783
  %2791 = extractelement <8 x float> %163, i64 3
  %2792 = fmul float %2791, %2790
  %2793 = call float @llvm.fabs.f32(float %2790)
  %2794 = fcmp olt float %2793, +inf
  %2795 = fcmp one float %2790, 0.000000e+00
  %2796 = and i1 %2794, %2795
  br i1 %2796, label %2797, label %2798

2797:                                             ; preds = %2779
  br label %2810

2798:                                             ; preds = %2779
  %2799 = fpext float %2791 to double
  %2800 = fpext float %2789 to double
  %2801 = fpext float %2783 to double
  %2802 = fmul double %2799, %2800
  %2803 = fmul double %2802, %2801
  %2804 = fptrunc double %2803 to float
  %2805 = fcmp oeq float %2791, 0.000000e+00
  %2806 = call float @llvm.fabs.f32(float %2783)
  %2807 = fcmp olt float %2806, +inf
  %2808 = and i1 %2805, %2807
  %2809 = select i1 %2808, float 0.000000e+00, float %2804
  br label %2810

2810:                                             ; preds = %2797, %2798
  %2811 = phi float [ %2809, %2798 ], [ %2792, %2797 ]
  br label %2812

2812:                                             ; preds = %2810
  %2813 = add i64 %91, %57
  %2814 = icmp slt i64 %2813, %26
  %2815 = select i1 %2814, i64 %2813, i64 0
  %2816 = extractelement <8 x float> %2679, i64 4
  %2817 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2818 = getelementptr inbounds nuw i8, ptr %2817, i64 %2815
  %2819 = load i8, ptr %2818, align 1
  %2820 = zext i8 %2819 to i32
  %2821 = shl i32 %2820, 23
  %2822 = bitcast i32 %2821 to float
  %2823 = fmul float %2822, %2816
  %2824 = extractelement <8 x float> %163, i64 4
  %2825 = fmul float %2824, %2823
  %2826 = call float @llvm.fabs.f32(float %2823)
  %2827 = fcmp olt float %2826, +inf
  %2828 = fcmp one float %2823, 0.000000e+00
  %2829 = and i1 %2827, %2828
  br i1 %2829, label %2830, label %2831

2830:                                             ; preds = %2812
  br label %2843

2831:                                             ; preds = %2812
  %2832 = fpext float %2824 to double
  %2833 = fpext float %2822 to double
  %2834 = fpext float %2816 to double
  %2835 = fmul double %2832, %2833
  %2836 = fmul double %2835, %2834
  %2837 = fptrunc double %2836 to float
  %2838 = fcmp oeq float %2824, 0.000000e+00
  %2839 = call float @llvm.fabs.f32(float %2816)
  %2840 = fcmp olt float %2839, +inf
  %2841 = and i1 %2838, %2840
  %2842 = select i1 %2841, float 0.000000e+00, float %2837
  br label %2843

2843:                                             ; preds = %2830, %2831
  %2844 = phi float [ %2842, %2831 ], [ %2825, %2830 ]
  br label %2845

2845:                                             ; preds = %2843
  %2846 = add i64 %91, %57
  %2847 = icmp slt i64 %2846, %26
  %2848 = select i1 %2847, i64 %2846, i64 0
  %2849 = extractelement <8 x float> %2679, i64 5
  %2850 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2851 = getelementptr inbounds nuw i8, ptr %2850, i64 %2848
  %2852 = load i8, ptr %2851, align 1
  %2853 = zext i8 %2852 to i32
  %2854 = shl i32 %2853, 23
  %2855 = bitcast i32 %2854 to float
  %2856 = fmul float %2855, %2849
  %2857 = extractelement <8 x float> %163, i64 5
  %2858 = fmul float %2857, %2856
  %2859 = call float @llvm.fabs.f32(float %2856)
  %2860 = fcmp olt float %2859, +inf
  %2861 = fcmp one float %2856, 0.000000e+00
  %2862 = and i1 %2860, %2861
  br i1 %2862, label %2863, label %2864

2863:                                             ; preds = %2845
  br label %2876

2864:                                             ; preds = %2845
  %2865 = fpext float %2857 to double
  %2866 = fpext float %2855 to double
  %2867 = fpext float %2849 to double
  %2868 = fmul double %2865, %2866
  %2869 = fmul double %2868, %2867
  %2870 = fptrunc double %2869 to float
  %2871 = fcmp oeq float %2857, 0.000000e+00
  %2872 = call float @llvm.fabs.f32(float %2849)
  %2873 = fcmp olt float %2872, +inf
  %2874 = and i1 %2871, %2873
  %2875 = select i1 %2874, float 0.000000e+00, float %2870
  br label %2876

2876:                                             ; preds = %2863, %2864
  %2877 = phi float [ %2875, %2864 ], [ %2858, %2863 ]
  br label %2878

2878:                                             ; preds = %2876
  %2879 = add i64 %91, %57
  %2880 = icmp slt i64 %2879, %26
  %2881 = select i1 %2880, i64 %2879, i64 0
  %2882 = extractelement <8 x float> %2679, i64 6
  %2883 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2884 = getelementptr inbounds nuw i8, ptr %2883, i64 %2881
  %2885 = load i8, ptr %2884, align 1
  %2886 = zext i8 %2885 to i32
  %2887 = shl i32 %2886, 23
  %2888 = bitcast i32 %2887 to float
  %2889 = fmul float %2888, %2882
  %2890 = extractelement <8 x float> %163, i64 6
  %2891 = fmul float %2890, %2889
  %2892 = call float @llvm.fabs.f32(float %2889)
  %2893 = fcmp olt float %2892, +inf
  %2894 = fcmp one float %2889, 0.000000e+00
  %2895 = and i1 %2893, %2894
  br i1 %2895, label %2896, label %2897

2896:                                             ; preds = %2878
  br label %2909

2897:                                             ; preds = %2878
  %2898 = fpext float %2890 to double
  %2899 = fpext float %2888 to double
  %2900 = fpext float %2882 to double
  %2901 = fmul double %2898, %2899
  %2902 = fmul double %2901, %2900
  %2903 = fptrunc double %2902 to float
  %2904 = fcmp oeq float %2890, 0.000000e+00
  %2905 = call float @llvm.fabs.f32(float %2882)
  %2906 = fcmp olt float %2905, +inf
  %2907 = and i1 %2904, %2906
  %2908 = select i1 %2907, float 0.000000e+00, float %2903
  br label %2909

2909:                                             ; preds = %2896, %2897
  %2910 = phi float [ %2908, %2897 ], [ %2891, %2896 ]
  br label %2911

2911:                                             ; preds = %2909
  %2912 = add i64 %91, %57
  %2913 = icmp slt i64 %2912, %26
  %2914 = select i1 %2913, i64 %2912, i64 0
  %2915 = extractelement <8 x float> %2679, i64 7
  %2916 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2917 = getelementptr inbounds nuw i8, ptr %2916, i64 %2914
  %2918 = load i8, ptr %2917, align 1
  %2919 = zext i8 %2918 to i32
  %2920 = shl i32 %2919, 23
  %2921 = bitcast i32 %2920 to float
  %2922 = fmul float %2921, %2915
  %2923 = extractelement <8 x float> %163, i64 7
  %2924 = fmul float %2923, %2922
  %2925 = call float @llvm.fabs.f32(float %2922)
  %2926 = fcmp olt float %2925, +inf
  %2927 = fcmp one float %2922, 0.000000e+00
  %2928 = and i1 %2926, %2927
  br i1 %2928, label %2929, label %2930

2929:                                             ; preds = %2911
  br label %2942

2930:                                             ; preds = %2911
  %2931 = fpext float %2923 to double
  %2932 = fpext float %2921 to double
  %2933 = fpext float %2915 to double
  %2934 = fmul double %2931, %2932
  %2935 = fmul double %2934, %2933
  %2936 = fptrunc double %2935 to float
  %2937 = fcmp oeq float %2923, 0.000000e+00
  %2938 = call float @llvm.fabs.f32(float %2915)
  %2939 = fcmp olt float %2938, +inf
  %2940 = and i1 %2937, %2939
  %2941 = select i1 %2940, float 0.000000e+00, float %2936
  br label %2942

2942:                                             ; preds = %2929, %2930
  %2943 = phi float [ %2941, %2930 ], [ %2924, %2929 ]
  br label %2944

2944:                                             ; preds = %2942
  %2945 = mul i64 %58, 8
  %2946 = add i64 %84, %2945
  %2947 = add i64 %91, %57
  %2948 = mul i64 %2946, %26
  %2949 = add i64 %2948, %2947
  %2950 = fptrunc float %2712 to bfloat
  %2951 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2952 = getelementptr inbounds nuw bfloat, ptr %2951, i64 %2949
  store bfloat %2950, ptr %2952, align 2
  %2953 = mul i64 %58, 8
  %2954 = add i64 %2953, 1
  %2955 = add i64 %84, %2954
  %2956 = add i64 %91, %57
  %2957 = mul i64 %2955, %26
  %2958 = add i64 %2957, %2956
  %2959 = fptrunc float %2745 to bfloat
  %2960 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2961 = getelementptr inbounds nuw bfloat, ptr %2960, i64 %2958
  store bfloat %2959, ptr %2961, align 2
  %2962 = mul i64 %58, 8
  %2963 = add i64 %2962, 2
  %2964 = add i64 %84, %2963
  %2965 = add i64 %91, %57
  %2966 = mul i64 %2964, %26
  %2967 = add i64 %2966, %2965
  %2968 = fptrunc float %2778 to bfloat
  %2969 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2970 = getelementptr inbounds nuw bfloat, ptr %2969, i64 %2967
  store bfloat %2968, ptr %2970, align 2
  %2971 = mul i64 %58, 8
  %2972 = add i64 %2971, 3
  %2973 = add i64 %84, %2972
  %2974 = add i64 %91, %57
  %2975 = mul i64 %2973, %26
  %2976 = add i64 %2975, %2974
  %2977 = fptrunc float %2811 to bfloat
  %2978 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2979 = getelementptr inbounds nuw bfloat, ptr %2978, i64 %2976
  store bfloat %2977, ptr %2979, align 2
  %2980 = mul i64 %58, 8
  %2981 = add i64 %2980, 4
  %2982 = add i64 %84, %2981
  %2983 = add i64 %91, %57
  %2984 = mul i64 %2982, %26
  %2985 = add i64 %2984, %2983
  %2986 = fptrunc float %2844 to bfloat
  %2987 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2988 = getelementptr inbounds nuw bfloat, ptr %2987, i64 %2985
  store bfloat %2986, ptr %2988, align 2
  %2989 = mul i64 %58, 8
  %2990 = add i64 %2989, 5
  %2991 = add i64 %84, %2990
  %2992 = add i64 %91, %57
  %2993 = mul i64 %2991, %26
  %2994 = add i64 %2993, %2992
  %2995 = fptrunc float %2877 to bfloat
  %2996 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2997 = getelementptr inbounds nuw bfloat, ptr %2996, i64 %2994
  store bfloat %2995, ptr %2997, align 2
  %2998 = mul i64 %58, 8
  %2999 = add i64 %2998, 6
  %3000 = add i64 %84, %2999
  %3001 = add i64 %91, %57
  %3002 = mul i64 %3000, %26
  %3003 = add i64 %3002, %3001
  %3004 = fptrunc float %2910 to bfloat
  %3005 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3006 = getelementptr inbounds nuw bfloat, ptr %3005, i64 %3003
  store bfloat %3004, ptr %3006, align 2
  %3007 = mul i64 %58, 8
  %3008 = add i64 %3007, 7
  %3009 = add i64 %84, %3008
  %3010 = add i64 %91, %57
  %3011 = mul i64 %3009, %26
  %3012 = add i64 %3011, %3010
  %3013 = fptrunc float %2943 to bfloat
  %3014 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3015 = getelementptr inbounds nuw bfloat, ptr %3014, i64 %3012
  store bfloat %3013, ptr %3015, align 2
  %3016 = mul i64 %58, 8
  %3017 = add i64 %86, %3016
  %3018 = add i64 %91, %57
  %3019 = add i64 %3017, 7
  %3020 = icmp ult i64 %3018, %26
  %3021 = icmp ult i64 %3019, %25
  %3022 = and i1 %3021, %3020
  %3023 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3024 = ptrtoint ptr %3023 to i64
  %3025 = mul i64 %3017, 4
  %3026 = add i64 %3024, %3025
  %3027 = urem i64 %3026, 16
  %3028 = icmp eq i64 %3027, 0
  %3029 = and i1 %3022, %3028
  br i1 %3029, label %3030, label %3039

3030:                                             ; preds = %2944
  %3031 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3032 = getelementptr float, ptr %3031, i64 %3017
  %3033 = load <4 x float>, ptr %3032, align 16
  %3034 = add i64 %3017, 4
  %3035 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3036 = getelementptr float, ptr %3035, i64 %3034
  %3037 = load <4 x float>, ptr %3036, align 16
  %3038 = shufflevector <4 x float> %3033, <4 x float> %3037, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3111

3039:                                             ; preds = %2944
  %3040 = mul i64 %58, 8
  %3041 = add i64 %86, %3040
  %3042 = icmp slt i64 %3041, %25
  %3043 = select i1 %3042, i64 %3041, i64 0
  %3044 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3045 = getelementptr inbounds nuw float, ptr %3044, i64 %3043
  %3046 = load float, ptr %3045, align 4
  %3047 = insertelement <8 x float> zeroinitializer, float %3046, i64 0
  %3048 = mul i64 %58, 8
  %3049 = add i64 %3048, 1
  %3050 = add i64 %86, %3049
  %3051 = icmp slt i64 %3050, %25
  %3052 = select i1 %3051, i64 %3050, i64 0
  %3053 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3054 = getelementptr inbounds nuw float, ptr %3053, i64 %3052
  %3055 = load float, ptr %3054, align 4
  %3056 = insertelement <8 x float> %3047, float %3055, i64 1
  %3057 = mul i64 %58, 8
  %3058 = add i64 %3057, 2
  %3059 = add i64 %86, %3058
  %3060 = icmp slt i64 %3059, %25
  %3061 = select i1 %3060, i64 %3059, i64 0
  %3062 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3063 = getelementptr inbounds nuw float, ptr %3062, i64 %3061
  %3064 = load float, ptr %3063, align 4
  %3065 = insertelement <8 x float> %3056, float %3064, i64 2
  %3066 = mul i64 %58, 8
  %3067 = add i64 %3066, 3
  %3068 = add i64 %86, %3067
  %3069 = icmp slt i64 %3068, %25
  %3070 = select i1 %3069, i64 %3068, i64 0
  %3071 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3072 = getelementptr inbounds nuw float, ptr %3071, i64 %3070
  %3073 = load float, ptr %3072, align 4
  %3074 = insertelement <8 x float> %3065, float %3073, i64 3
  %3075 = mul i64 %58, 8
  %3076 = add i64 %3075, 4
  %3077 = add i64 %86, %3076
  %3078 = icmp slt i64 %3077, %25
  %3079 = select i1 %3078, i64 %3077, i64 0
  %3080 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3081 = getelementptr inbounds nuw float, ptr %3080, i64 %3079
  %3082 = load float, ptr %3081, align 4
  %3083 = insertelement <8 x float> %3074, float %3082, i64 4
  %3084 = mul i64 %58, 8
  %3085 = add i64 %3084, 5
  %3086 = add i64 %86, %3085
  %3087 = icmp slt i64 %3086, %25
  %3088 = select i1 %3087, i64 %3086, i64 0
  %3089 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3090 = getelementptr inbounds nuw float, ptr %3089, i64 %3088
  %3091 = load float, ptr %3090, align 4
  %3092 = insertelement <8 x float> %3083, float %3091, i64 5
  %3093 = mul i64 %58, 8
  %3094 = add i64 %3093, 6
  %3095 = add i64 %86, %3094
  %3096 = icmp slt i64 %3095, %25
  %3097 = select i1 %3096, i64 %3095, i64 0
  %3098 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3099 = getelementptr inbounds nuw float, ptr %3098, i64 %3097
  %3100 = load float, ptr %3099, align 4
  %3101 = insertelement <8 x float> %3092, float %3100, i64 6
  %3102 = mul i64 %58, 8
  %3103 = add i64 %3102, 7
  %3104 = add i64 %86, %3103
  %3105 = icmp slt i64 %3104, %25
  %3106 = select i1 %3105, i64 %3104, i64 0
  %3107 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3108 = getelementptr inbounds nuw float, ptr %3107, i64 %3106
  %3109 = load float, ptr %3108, align 4
  %3110 = insertelement <8 x float> %3101, float %3109, i64 7
  br label %3111

3111:                                             ; preds = %3030, %3039
  %3112 = phi <8 x float> [ %3110, %3039 ], [ %3038, %3030 ]
  br label %3113

3113:                                             ; preds = %3111
  %3114 = add i64 %91, %57
  %3115 = icmp slt i64 %3114, %26
  %3116 = select i1 %3115, i64 %3114, i64 0
  %3117 = extractelement <8 x float> %3112, i64 0
  %3118 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3119 = getelementptr inbounds nuw i8, ptr %3118, i64 %3116
  %3120 = load i8, ptr %3119, align 1
  %3121 = zext i8 %3120 to i32
  %3122 = shl i32 %3121, 23
  %3123 = bitcast i32 %3122 to float
  %3124 = fmul float %3123, %3117
  %3125 = extractelement <8 x float> %165, i64 0
  %3126 = fmul float %3125, %3124
  %3127 = call float @llvm.fabs.f32(float %3124)
  %3128 = fcmp olt float %3127, +inf
  %3129 = fcmp one float %3124, 0.000000e+00
  %3130 = and i1 %3128, %3129
  br i1 %3130, label %3131, label %3132

3131:                                             ; preds = %3113
  br label %3144

3132:                                             ; preds = %3113
  %3133 = fpext float %3125 to double
  %3134 = fpext float %3123 to double
  %3135 = fpext float %3117 to double
  %3136 = fmul double %3133, %3134
  %3137 = fmul double %3136, %3135
  %3138 = fptrunc double %3137 to float
  %3139 = fcmp oeq float %3125, 0.000000e+00
  %3140 = call float @llvm.fabs.f32(float %3117)
  %3141 = fcmp olt float %3140, +inf
  %3142 = and i1 %3139, %3141
  %3143 = select i1 %3142, float 0.000000e+00, float %3138
  br label %3144

3144:                                             ; preds = %3131, %3132
  %3145 = phi float [ %3143, %3132 ], [ %3126, %3131 ]
  br label %3146

3146:                                             ; preds = %3144
  %3147 = add i64 %91, %57
  %3148 = icmp slt i64 %3147, %26
  %3149 = select i1 %3148, i64 %3147, i64 0
  %3150 = extractelement <8 x float> %3112, i64 1
  %3151 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3152 = getelementptr inbounds nuw i8, ptr %3151, i64 %3149
  %3153 = load i8, ptr %3152, align 1
  %3154 = zext i8 %3153 to i32
  %3155 = shl i32 %3154, 23
  %3156 = bitcast i32 %3155 to float
  %3157 = fmul float %3156, %3150
  %3158 = extractelement <8 x float> %165, i64 1
  %3159 = fmul float %3158, %3157
  %3160 = call float @llvm.fabs.f32(float %3157)
  %3161 = fcmp olt float %3160, +inf
  %3162 = fcmp one float %3157, 0.000000e+00
  %3163 = and i1 %3161, %3162
  br i1 %3163, label %3164, label %3165

3164:                                             ; preds = %3146
  br label %3177

3165:                                             ; preds = %3146
  %3166 = fpext float %3158 to double
  %3167 = fpext float %3156 to double
  %3168 = fpext float %3150 to double
  %3169 = fmul double %3166, %3167
  %3170 = fmul double %3169, %3168
  %3171 = fptrunc double %3170 to float
  %3172 = fcmp oeq float %3158, 0.000000e+00
  %3173 = call float @llvm.fabs.f32(float %3150)
  %3174 = fcmp olt float %3173, +inf
  %3175 = and i1 %3172, %3174
  %3176 = select i1 %3175, float 0.000000e+00, float %3171
  br label %3177

3177:                                             ; preds = %3164, %3165
  %3178 = phi float [ %3176, %3165 ], [ %3159, %3164 ]
  br label %3179

3179:                                             ; preds = %3177
  %3180 = add i64 %91, %57
  %3181 = icmp slt i64 %3180, %26
  %3182 = select i1 %3181, i64 %3180, i64 0
  %3183 = extractelement <8 x float> %3112, i64 2
  %3184 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3185 = getelementptr inbounds nuw i8, ptr %3184, i64 %3182
  %3186 = load i8, ptr %3185, align 1
  %3187 = zext i8 %3186 to i32
  %3188 = shl i32 %3187, 23
  %3189 = bitcast i32 %3188 to float
  %3190 = fmul float %3189, %3183
  %3191 = extractelement <8 x float> %165, i64 2
  %3192 = fmul float %3191, %3190
  %3193 = call float @llvm.fabs.f32(float %3190)
  %3194 = fcmp olt float %3193, +inf
  %3195 = fcmp one float %3190, 0.000000e+00
  %3196 = and i1 %3194, %3195
  br i1 %3196, label %3197, label %3198

3197:                                             ; preds = %3179
  br label %3210

3198:                                             ; preds = %3179
  %3199 = fpext float %3191 to double
  %3200 = fpext float %3189 to double
  %3201 = fpext float %3183 to double
  %3202 = fmul double %3199, %3200
  %3203 = fmul double %3202, %3201
  %3204 = fptrunc double %3203 to float
  %3205 = fcmp oeq float %3191, 0.000000e+00
  %3206 = call float @llvm.fabs.f32(float %3183)
  %3207 = fcmp olt float %3206, +inf
  %3208 = and i1 %3205, %3207
  %3209 = select i1 %3208, float 0.000000e+00, float %3204
  br label %3210

3210:                                             ; preds = %3197, %3198
  %3211 = phi float [ %3209, %3198 ], [ %3192, %3197 ]
  br label %3212

3212:                                             ; preds = %3210
  %3213 = add i64 %91, %57
  %3214 = icmp slt i64 %3213, %26
  %3215 = select i1 %3214, i64 %3213, i64 0
  %3216 = extractelement <8 x float> %3112, i64 3
  %3217 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3218 = getelementptr inbounds nuw i8, ptr %3217, i64 %3215
  %3219 = load i8, ptr %3218, align 1
  %3220 = zext i8 %3219 to i32
  %3221 = shl i32 %3220, 23
  %3222 = bitcast i32 %3221 to float
  %3223 = fmul float %3222, %3216
  %3224 = extractelement <8 x float> %165, i64 3
  %3225 = fmul float %3224, %3223
  %3226 = call float @llvm.fabs.f32(float %3223)
  %3227 = fcmp olt float %3226, +inf
  %3228 = fcmp one float %3223, 0.000000e+00
  %3229 = and i1 %3227, %3228
  br i1 %3229, label %3230, label %3231

3230:                                             ; preds = %3212
  br label %3243

3231:                                             ; preds = %3212
  %3232 = fpext float %3224 to double
  %3233 = fpext float %3222 to double
  %3234 = fpext float %3216 to double
  %3235 = fmul double %3232, %3233
  %3236 = fmul double %3235, %3234
  %3237 = fptrunc double %3236 to float
  %3238 = fcmp oeq float %3224, 0.000000e+00
  %3239 = call float @llvm.fabs.f32(float %3216)
  %3240 = fcmp olt float %3239, +inf
  %3241 = and i1 %3238, %3240
  %3242 = select i1 %3241, float 0.000000e+00, float %3237
  br label %3243

3243:                                             ; preds = %3230, %3231
  %3244 = phi float [ %3242, %3231 ], [ %3225, %3230 ]
  br label %3245

3245:                                             ; preds = %3243
  %3246 = add i64 %91, %57
  %3247 = icmp slt i64 %3246, %26
  %3248 = select i1 %3247, i64 %3246, i64 0
  %3249 = extractelement <8 x float> %3112, i64 4
  %3250 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3251 = getelementptr inbounds nuw i8, ptr %3250, i64 %3248
  %3252 = load i8, ptr %3251, align 1
  %3253 = zext i8 %3252 to i32
  %3254 = shl i32 %3253, 23
  %3255 = bitcast i32 %3254 to float
  %3256 = fmul float %3255, %3249
  %3257 = extractelement <8 x float> %165, i64 4
  %3258 = fmul float %3257, %3256
  %3259 = call float @llvm.fabs.f32(float %3256)
  %3260 = fcmp olt float %3259, +inf
  %3261 = fcmp one float %3256, 0.000000e+00
  %3262 = and i1 %3260, %3261
  br i1 %3262, label %3263, label %3264

3263:                                             ; preds = %3245
  br label %3276

3264:                                             ; preds = %3245
  %3265 = fpext float %3257 to double
  %3266 = fpext float %3255 to double
  %3267 = fpext float %3249 to double
  %3268 = fmul double %3265, %3266
  %3269 = fmul double %3268, %3267
  %3270 = fptrunc double %3269 to float
  %3271 = fcmp oeq float %3257, 0.000000e+00
  %3272 = call float @llvm.fabs.f32(float %3249)
  %3273 = fcmp olt float %3272, +inf
  %3274 = and i1 %3271, %3273
  %3275 = select i1 %3274, float 0.000000e+00, float %3270
  br label %3276

3276:                                             ; preds = %3263, %3264
  %3277 = phi float [ %3275, %3264 ], [ %3258, %3263 ]
  br label %3278

3278:                                             ; preds = %3276
  %3279 = add i64 %91, %57
  %3280 = icmp slt i64 %3279, %26
  %3281 = select i1 %3280, i64 %3279, i64 0
  %3282 = extractelement <8 x float> %3112, i64 5
  %3283 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3284 = getelementptr inbounds nuw i8, ptr %3283, i64 %3281
  %3285 = load i8, ptr %3284, align 1
  %3286 = zext i8 %3285 to i32
  %3287 = shl i32 %3286, 23
  %3288 = bitcast i32 %3287 to float
  %3289 = fmul float %3288, %3282
  %3290 = extractelement <8 x float> %165, i64 5
  %3291 = fmul float %3290, %3289
  %3292 = call float @llvm.fabs.f32(float %3289)
  %3293 = fcmp olt float %3292, +inf
  %3294 = fcmp one float %3289, 0.000000e+00
  %3295 = and i1 %3293, %3294
  br i1 %3295, label %3296, label %3297

3296:                                             ; preds = %3278
  br label %3309

3297:                                             ; preds = %3278
  %3298 = fpext float %3290 to double
  %3299 = fpext float %3288 to double
  %3300 = fpext float %3282 to double
  %3301 = fmul double %3298, %3299
  %3302 = fmul double %3301, %3300
  %3303 = fptrunc double %3302 to float
  %3304 = fcmp oeq float %3290, 0.000000e+00
  %3305 = call float @llvm.fabs.f32(float %3282)
  %3306 = fcmp olt float %3305, +inf
  %3307 = and i1 %3304, %3306
  %3308 = select i1 %3307, float 0.000000e+00, float %3303
  br label %3309

3309:                                             ; preds = %3296, %3297
  %3310 = phi float [ %3308, %3297 ], [ %3291, %3296 ]
  br label %3311

3311:                                             ; preds = %3309
  %3312 = add i64 %91, %57
  %3313 = icmp slt i64 %3312, %26
  %3314 = select i1 %3313, i64 %3312, i64 0
  %3315 = extractelement <8 x float> %3112, i64 6
  %3316 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3317 = getelementptr inbounds nuw i8, ptr %3316, i64 %3314
  %3318 = load i8, ptr %3317, align 1
  %3319 = zext i8 %3318 to i32
  %3320 = shl i32 %3319, 23
  %3321 = bitcast i32 %3320 to float
  %3322 = fmul float %3321, %3315
  %3323 = extractelement <8 x float> %165, i64 6
  %3324 = fmul float %3323, %3322
  %3325 = call float @llvm.fabs.f32(float %3322)
  %3326 = fcmp olt float %3325, +inf
  %3327 = fcmp one float %3322, 0.000000e+00
  %3328 = and i1 %3326, %3327
  br i1 %3328, label %3329, label %3330

3329:                                             ; preds = %3311
  br label %3342

3330:                                             ; preds = %3311
  %3331 = fpext float %3323 to double
  %3332 = fpext float %3321 to double
  %3333 = fpext float %3315 to double
  %3334 = fmul double %3331, %3332
  %3335 = fmul double %3334, %3333
  %3336 = fptrunc double %3335 to float
  %3337 = fcmp oeq float %3323, 0.000000e+00
  %3338 = call float @llvm.fabs.f32(float %3315)
  %3339 = fcmp olt float %3338, +inf
  %3340 = and i1 %3337, %3339
  %3341 = select i1 %3340, float 0.000000e+00, float %3336
  br label %3342

3342:                                             ; preds = %3329, %3330
  %3343 = phi float [ %3341, %3330 ], [ %3324, %3329 ]
  br label %3344

3344:                                             ; preds = %3342
  %3345 = add i64 %91, %57
  %3346 = icmp slt i64 %3345, %26
  %3347 = select i1 %3346, i64 %3345, i64 0
  %3348 = extractelement <8 x float> %3112, i64 7
  %3349 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3350 = getelementptr inbounds nuw i8, ptr %3349, i64 %3347
  %3351 = load i8, ptr %3350, align 1
  %3352 = zext i8 %3351 to i32
  %3353 = shl i32 %3352, 23
  %3354 = bitcast i32 %3353 to float
  %3355 = fmul float %3354, %3348
  %3356 = extractelement <8 x float> %165, i64 7
  %3357 = fmul float %3356, %3355
  %3358 = call float @llvm.fabs.f32(float %3355)
  %3359 = fcmp olt float %3358, +inf
  %3360 = fcmp one float %3355, 0.000000e+00
  %3361 = and i1 %3359, %3360
  br i1 %3361, label %3362, label %3363

3362:                                             ; preds = %3344
  br label %3375

3363:                                             ; preds = %3344
  %3364 = fpext float %3356 to double
  %3365 = fpext float %3354 to double
  %3366 = fpext float %3348 to double
  %3367 = fmul double %3364, %3365
  %3368 = fmul double %3367, %3366
  %3369 = fptrunc double %3368 to float
  %3370 = fcmp oeq float %3356, 0.000000e+00
  %3371 = call float @llvm.fabs.f32(float %3348)
  %3372 = fcmp olt float %3371, +inf
  %3373 = and i1 %3370, %3372
  %3374 = select i1 %3373, float 0.000000e+00, float %3369
  br label %3375

3375:                                             ; preds = %3362, %3363
  %3376 = phi float [ %3374, %3363 ], [ %3357, %3362 ]
  br label %3377

3377:                                             ; preds = %3375
  %3378 = mul i64 %58, 8
  %3379 = add i64 %86, %3378
  %3380 = add i64 %91, %57
  %3381 = mul i64 %3379, %26
  %3382 = add i64 %3381, %3380
  %3383 = fptrunc float %3145 to bfloat
  %3384 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3385 = getelementptr inbounds nuw bfloat, ptr %3384, i64 %3382
  store bfloat %3383, ptr %3385, align 2
  %3386 = mul i64 %58, 8
  %3387 = add i64 %3386, 1
  %3388 = add i64 %86, %3387
  %3389 = add i64 %91, %57
  %3390 = mul i64 %3388, %26
  %3391 = add i64 %3390, %3389
  %3392 = fptrunc float %3178 to bfloat
  %3393 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3394 = getelementptr inbounds nuw bfloat, ptr %3393, i64 %3391
  store bfloat %3392, ptr %3394, align 2
  %3395 = mul i64 %58, 8
  %3396 = add i64 %3395, 2
  %3397 = add i64 %86, %3396
  %3398 = add i64 %91, %57
  %3399 = mul i64 %3397, %26
  %3400 = add i64 %3399, %3398
  %3401 = fptrunc float %3211 to bfloat
  %3402 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3403 = getelementptr inbounds nuw bfloat, ptr %3402, i64 %3400
  store bfloat %3401, ptr %3403, align 2
  %3404 = mul i64 %58, 8
  %3405 = add i64 %3404, 3
  %3406 = add i64 %86, %3405
  %3407 = add i64 %91, %57
  %3408 = mul i64 %3406, %26
  %3409 = add i64 %3408, %3407
  %3410 = fptrunc float %3244 to bfloat
  %3411 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3412 = getelementptr inbounds nuw bfloat, ptr %3411, i64 %3409
  store bfloat %3410, ptr %3412, align 2
  %3413 = mul i64 %58, 8
  %3414 = add i64 %3413, 4
  %3415 = add i64 %86, %3414
  %3416 = add i64 %91, %57
  %3417 = mul i64 %3415, %26
  %3418 = add i64 %3417, %3416
  %3419 = fptrunc float %3277 to bfloat
  %3420 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3421 = getelementptr inbounds nuw bfloat, ptr %3420, i64 %3418
  store bfloat %3419, ptr %3421, align 2
  %3422 = mul i64 %58, 8
  %3423 = add i64 %3422, 5
  %3424 = add i64 %86, %3423
  %3425 = add i64 %91, %57
  %3426 = mul i64 %3424, %26
  %3427 = add i64 %3426, %3425
  %3428 = fptrunc float %3310 to bfloat
  %3429 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3430 = getelementptr inbounds nuw bfloat, ptr %3429, i64 %3427
  store bfloat %3428, ptr %3430, align 2
  %3431 = mul i64 %58, 8
  %3432 = add i64 %3431, 6
  %3433 = add i64 %86, %3432
  %3434 = add i64 %91, %57
  %3435 = mul i64 %3433, %26
  %3436 = add i64 %3435, %3434
  %3437 = fptrunc float %3343 to bfloat
  %3438 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3439 = getelementptr inbounds nuw bfloat, ptr %3438, i64 %3436
  store bfloat %3437, ptr %3439, align 2
  %3440 = mul i64 %58, 8
  %3441 = add i64 %3440, 7
  %3442 = add i64 %86, %3441
  %3443 = add i64 %91, %57
  %3444 = mul i64 %3442, %26
  %3445 = add i64 %3444, %3443
  %3446 = fptrunc float %3376 to bfloat
  %3447 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3448 = getelementptr inbounds nuw bfloat, ptr %3447, i64 %3445
  store bfloat %3446, ptr %3448, align 2
  %3449 = mul i64 %58, 8
  %3450 = add i64 %88, %3449
  %3451 = add i64 %91, %57
  %3452 = add i64 %3450, 7
  %3453 = icmp ult i64 %3451, %26
  %3454 = icmp ult i64 %3452, %25
  %3455 = and i1 %3454, %3453
  %3456 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3457 = ptrtoint ptr %3456 to i64
  %3458 = mul i64 %3450, 4
  %3459 = add i64 %3457, %3458
  %3460 = urem i64 %3459, 16
  %3461 = icmp eq i64 %3460, 0
  %3462 = and i1 %3455, %3461
  br i1 %3462, label %3463, label %3472

3463:                                             ; preds = %3377
  %3464 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3465 = getelementptr float, ptr %3464, i64 %3450
  %3466 = load <4 x float>, ptr %3465, align 16
  %3467 = add i64 %3450, 4
  %3468 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3469 = getelementptr float, ptr %3468, i64 %3467
  %3470 = load <4 x float>, ptr %3469, align 16
  %3471 = shufflevector <4 x float> %3466, <4 x float> %3470, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3544

3472:                                             ; preds = %3377
  %3473 = mul i64 %58, 8
  %3474 = add i64 %88, %3473
  %3475 = icmp slt i64 %3474, %25
  %3476 = select i1 %3475, i64 %3474, i64 0
  %3477 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3478 = getelementptr inbounds nuw float, ptr %3477, i64 %3476
  %3479 = load float, ptr %3478, align 4
  %3480 = insertelement <8 x float> zeroinitializer, float %3479, i64 0
  %3481 = mul i64 %58, 8
  %3482 = add i64 %3481, 1
  %3483 = add i64 %88, %3482
  %3484 = icmp slt i64 %3483, %25
  %3485 = select i1 %3484, i64 %3483, i64 0
  %3486 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3487 = getelementptr inbounds nuw float, ptr %3486, i64 %3485
  %3488 = load float, ptr %3487, align 4
  %3489 = insertelement <8 x float> %3480, float %3488, i64 1
  %3490 = mul i64 %58, 8
  %3491 = add i64 %3490, 2
  %3492 = add i64 %88, %3491
  %3493 = icmp slt i64 %3492, %25
  %3494 = select i1 %3493, i64 %3492, i64 0
  %3495 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3496 = getelementptr inbounds nuw float, ptr %3495, i64 %3494
  %3497 = load float, ptr %3496, align 4
  %3498 = insertelement <8 x float> %3489, float %3497, i64 2
  %3499 = mul i64 %58, 8
  %3500 = add i64 %3499, 3
  %3501 = add i64 %88, %3500
  %3502 = icmp slt i64 %3501, %25
  %3503 = select i1 %3502, i64 %3501, i64 0
  %3504 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3505 = getelementptr inbounds nuw float, ptr %3504, i64 %3503
  %3506 = load float, ptr %3505, align 4
  %3507 = insertelement <8 x float> %3498, float %3506, i64 3
  %3508 = mul i64 %58, 8
  %3509 = add i64 %3508, 4
  %3510 = add i64 %88, %3509
  %3511 = icmp slt i64 %3510, %25
  %3512 = select i1 %3511, i64 %3510, i64 0
  %3513 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3514 = getelementptr inbounds nuw float, ptr %3513, i64 %3512
  %3515 = load float, ptr %3514, align 4
  %3516 = insertelement <8 x float> %3507, float %3515, i64 4
  %3517 = mul i64 %58, 8
  %3518 = add i64 %3517, 5
  %3519 = add i64 %88, %3518
  %3520 = icmp slt i64 %3519, %25
  %3521 = select i1 %3520, i64 %3519, i64 0
  %3522 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3523 = getelementptr inbounds nuw float, ptr %3522, i64 %3521
  %3524 = load float, ptr %3523, align 4
  %3525 = insertelement <8 x float> %3516, float %3524, i64 5
  %3526 = mul i64 %58, 8
  %3527 = add i64 %3526, 6
  %3528 = add i64 %88, %3527
  %3529 = icmp slt i64 %3528, %25
  %3530 = select i1 %3529, i64 %3528, i64 0
  %3531 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3532 = getelementptr inbounds nuw float, ptr %3531, i64 %3530
  %3533 = load float, ptr %3532, align 4
  %3534 = insertelement <8 x float> %3525, float %3533, i64 6
  %3535 = mul i64 %58, 8
  %3536 = add i64 %3535, 7
  %3537 = add i64 %88, %3536
  %3538 = icmp slt i64 %3537, %25
  %3539 = select i1 %3538, i64 %3537, i64 0
  %3540 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3541 = getelementptr inbounds nuw float, ptr %3540, i64 %3539
  %3542 = load float, ptr %3541, align 4
  %3543 = insertelement <8 x float> %3534, float %3542, i64 7
  br label %3544

3544:                                             ; preds = %3463, %3472
  %3545 = phi <8 x float> [ %3543, %3472 ], [ %3471, %3463 ]
  br label %3546

3546:                                             ; preds = %3544
  %3547 = add i64 %91, %57
  %3548 = icmp slt i64 %3547, %26
  %3549 = select i1 %3548, i64 %3547, i64 0
  %3550 = extractelement <8 x float> %3545, i64 0
  %3551 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3552 = getelementptr inbounds nuw i8, ptr %3551, i64 %3549
  %3553 = load i8, ptr %3552, align 1
  %3554 = zext i8 %3553 to i32
  %3555 = shl i32 %3554, 23
  %3556 = bitcast i32 %3555 to float
  %3557 = fmul float %3556, %3550
  %3558 = extractelement <8 x float> %167, i64 0
  %3559 = fmul float %3558, %3557
  %3560 = call float @llvm.fabs.f32(float %3557)
  %3561 = fcmp olt float %3560, +inf
  %3562 = fcmp one float %3557, 0.000000e+00
  %3563 = and i1 %3561, %3562
  br i1 %3563, label %3564, label %3565

3564:                                             ; preds = %3546
  br label %3577

3565:                                             ; preds = %3546
  %3566 = fpext float %3558 to double
  %3567 = fpext float %3556 to double
  %3568 = fpext float %3550 to double
  %3569 = fmul double %3566, %3567
  %3570 = fmul double %3569, %3568
  %3571 = fptrunc double %3570 to float
  %3572 = fcmp oeq float %3558, 0.000000e+00
  %3573 = call float @llvm.fabs.f32(float %3550)
  %3574 = fcmp olt float %3573, +inf
  %3575 = and i1 %3572, %3574
  %3576 = select i1 %3575, float 0.000000e+00, float %3571
  br label %3577

3577:                                             ; preds = %3564, %3565
  %3578 = phi float [ %3576, %3565 ], [ %3559, %3564 ]
  br label %3579

3579:                                             ; preds = %3577
  %3580 = add i64 %91, %57
  %3581 = icmp slt i64 %3580, %26
  %3582 = select i1 %3581, i64 %3580, i64 0
  %3583 = extractelement <8 x float> %3545, i64 1
  %3584 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3585 = getelementptr inbounds nuw i8, ptr %3584, i64 %3582
  %3586 = load i8, ptr %3585, align 1
  %3587 = zext i8 %3586 to i32
  %3588 = shl i32 %3587, 23
  %3589 = bitcast i32 %3588 to float
  %3590 = fmul float %3589, %3583
  %3591 = extractelement <8 x float> %167, i64 1
  %3592 = fmul float %3591, %3590
  %3593 = call float @llvm.fabs.f32(float %3590)
  %3594 = fcmp olt float %3593, +inf
  %3595 = fcmp one float %3590, 0.000000e+00
  %3596 = and i1 %3594, %3595
  br i1 %3596, label %3597, label %3598

3597:                                             ; preds = %3579
  br label %3610

3598:                                             ; preds = %3579
  %3599 = fpext float %3591 to double
  %3600 = fpext float %3589 to double
  %3601 = fpext float %3583 to double
  %3602 = fmul double %3599, %3600
  %3603 = fmul double %3602, %3601
  %3604 = fptrunc double %3603 to float
  %3605 = fcmp oeq float %3591, 0.000000e+00
  %3606 = call float @llvm.fabs.f32(float %3583)
  %3607 = fcmp olt float %3606, +inf
  %3608 = and i1 %3605, %3607
  %3609 = select i1 %3608, float 0.000000e+00, float %3604
  br label %3610

3610:                                             ; preds = %3597, %3598
  %3611 = phi float [ %3609, %3598 ], [ %3592, %3597 ]
  br label %3612

3612:                                             ; preds = %3610
  %3613 = add i64 %91, %57
  %3614 = icmp slt i64 %3613, %26
  %3615 = select i1 %3614, i64 %3613, i64 0
  %3616 = extractelement <8 x float> %3545, i64 2
  %3617 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3618 = getelementptr inbounds nuw i8, ptr %3617, i64 %3615
  %3619 = load i8, ptr %3618, align 1
  %3620 = zext i8 %3619 to i32
  %3621 = shl i32 %3620, 23
  %3622 = bitcast i32 %3621 to float
  %3623 = fmul float %3622, %3616
  %3624 = extractelement <8 x float> %167, i64 2
  %3625 = fmul float %3624, %3623
  %3626 = call float @llvm.fabs.f32(float %3623)
  %3627 = fcmp olt float %3626, +inf
  %3628 = fcmp one float %3623, 0.000000e+00
  %3629 = and i1 %3627, %3628
  br i1 %3629, label %3630, label %3631

3630:                                             ; preds = %3612
  br label %3643

3631:                                             ; preds = %3612
  %3632 = fpext float %3624 to double
  %3633 = fpext float %3622 to double
  %3634 = fpext float %3616 to double
  %3635 = fmul double %3632, %3633
  %3636 = fmul double %3635, %3634
  %3637 = fptrunc double %3636 to float
  %3638 = fcmp oeq float %3624, 0.000000e+00
  %3639 = call float @llvm.fabs.f32(float %3616)
  %3640 = fcmp olt float %3639, +inf
  %3641 = and i1 %3638, %3640
  %3642 = select i1 %3641, float 0.000000e+00, float %3637
  br label %3643

3643:                                             ; preds = %3630, %3631
  %3644 = phi float [ %3642, %3631 ], [ %3625, %3630 ]
  br label %3645

3645:                                             ; preds = %3643
  %3646 = add i64 %91, %57
  %3647 = icmp slt i64 %3646, %26
  %3648 = select i1 %3647, i64 %3646, i64 0
  %3649 = extractelement <8 x float> %3545, i64 3
  %3650 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3651 = getelementptr inbounds nuw i8, ptr %3650, i64 %3648
  %3652 = load i8, ptr %3651, align 1
  %3653 = zext i8 %3652 to i32
  %3654 = shl i32 %3653, 23
  %3655 = bitcast i32 %3654 to float
  %3656 = fmul float %3655, %3649
  %3657 = extractelement <8 x float> %167, i64 3
  %3658 = fmul float %3657, %3656
  %3659 = call float @llvm.fabs.f32(float %3656)
  %3660 = fcmp olt float %3659, +inf
  %3661 = fcmp one float %3656, 0.000000e+00
  %3662 = and i1 %3660, %3661
  br i1 %3662, label %3663, label %3664

3663:                                             ; preds = %3645
  br label %3676

3664:                                             ; preds = %3645
  %3665 = fpext float %3657 to double
  %3666 = fpext float %3655 to double
  %3667 = fpext float %3649 to double
  %3668 = fmul double %3665, %3666
  %3669 = fmul double %3668, %3667
  %3670 = fptrunc double %3669 to float
  %3671 = fcmp oeq float %3657, 0.000000e+00
  %3672 = call float @llvm.fabs.f32(float %3649)
  %3673 = fcmp olt float %3672, +inf
  %3674 = and i1 %3671, %3673
  %3675 = select i1 %3674, float 0.000000e+00, float %3670
  br label %3676

3676:                                             ; preds = %3663, %3664
  %3677 = phi float [ %3675, %3664 ], [ %3658, %3663 ]
  br label %3678

3678:                                             ; preds = %3676
  %3679 = add i64 %91, %57
  %3680 = icmp slt i64 %3679, %26
  %3681 = select i1 %3680, i64 %3679, i64 0
  %3682 = extractelement <8 x float> %3545, i64 4
  %3683 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3684 = getelementptr inbounds nuw i8, ptr %3683, i64 %3681
  %3685 = load i8, ptr %3684, align 1
  %3686 = zext i8 %3685 to i32
  %3687 = shl i32 %3686, 23
  %3688 = bitcast i32 %3687 to float
  %3689 = fmul float %3688, %3682
  %3690 = extractelement <8 x float> %167, i64 4
  %3691 = fmul float %3690, %3689
  %3692 = call float @llvm.fabs.f32(float %3689)
  %3693 = fcmp olt float %3692, +inf
  %3694 = fcmp one float %3689, 0.000000e+00
  %3695 = and i1 %3693, %3694
  br i1 %3695, label %3696, label %3697

3696:                                             ; preds = %3678
  br label %3709

3697:                                             ; preds = %3678
  %3698 = fpext float %3690 to double
  %3699 = fpext float %3688 to double
  %3700 = fpext float %3682 to double
  %3701 = fmul double %3698, %3699
  %3702 = fmul double %3701, %3700
  %3703 = fptrunc double %3702 to float
  %3704 = fcmp oeq float %3690, 0.000000e+00
  %3705 = call float @llvm.fabs.f32(float %3682)
  %3706 = fcmp olt float %3705, +inf
  %3707 = and i1 %3704, %3706
  %3708 = select i1 %3707, float 0.000000e+00, float %3703
  br label %3709

3709:                                             ; preds = %3696, %3697
  %3710 = phi float [ %3708, %3697 ], [ %3691, %3696 ]
  br label %3711

3711:                                             ; preds = %3709
  %3712 = add i64 %91, %57
  %3713 = icmp slt i64 %3712, %26
  %3714 = select i1 %3713, i64 %3712, i64 0
  %3715 = extractelement <8 x float> %3545, i64 5
  %3716 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3717 = getelementptr inbounds nuw i8, ptr %3716, i64 %3714
  %3718 = load i8, ptr %3717, align 1
  %3719 = zext i8 %3718 to i32
  %3720 = shl i32 %3719, 23
  %3721 = bitcast i32 %3720 to float
  %3722 = fmul float %3721, %3715
  %3723 = extractelement <8 x float> %167, i64 5
  %3724 = fmul float %3723, %3722
  %3725 = call float @llvm.fabs.f32(float %3722)
  %3726 = fcmp olt float %3725, +inf
  %3727 = fcmp one float %3722, 0.000000e+00
  %3728 = and i1 %3726, %3727
  br i1 %3728, label %3729, label %3730

3729:                                             ; preds = %3711
  br label %3742

3730:                                             ; preds = %3711
  %3731 = fpext float %3723 to double
  %3732 = fpext float %3721 to double
  %3733 = fpext float %3715 to double
  %3734 = fmul double %3731, %3732
  %3735 = fmul double %3734, %3733
  %3736 = fptrunc double %3735 to float
  %3737 = fcmp oeq float %3723, 0.000000e+00
  %3738 = call float @llvm.fabs.f32(float %3715)
  %3739 = fcmp olt float %3738, +inf
  %3740 = and i1 %3737, %3739
  %3741 = select i1 %3740, float 0.000000e+00, float %3736
  br label %3742

3742:                                             ; preds = %3729, %3730
  %3743 = phi float [ %3741, %3730 ], [ %3724, %3729 ]
  br label %3744

3744:                                             ; preds = %3742
  %3745 = add i64 %91, %57
  %3746 = icmp slt i64 %3745, %26
  %3747 = select i1 %3746, i64 %3745, i64 0
  %3748 = extractelement <8 x float> %3545, i64 6
  %3749 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3750 = getelementptr inbounds nuw i8, ptr %3749, i64 %3747
  %3751 = load i8, ptr %3750, align 1
  %3752 = zext i8 %3751 to i32
  %3753 = shl i32 %3752, 23
  %3754 = bitcast i32 %3753 to float
  %3755 = fmul float %3754, %3748
  %3756 = extractelement <8 x float> %167, i64 6
  %3757 = fmul float %3756, %3755
  %3758 = call float @llvm.fabs.f32(float %3755)
  %3759 = fcmp olt float %3758, +inf
  %3760 = fcmp one float %3755, 0.000000e+00
  %3761 = and i1 %3759, %3760
  br i1 %3761, label %3762, label %3763

3762:                                             ; preds = %3744
  br label %3775

3763:                                             ; preds = %3744
  %3764 = fpext float %3756 to double
  %3765 = fpext float %3754 to double
  %3766 = fpext float %3748 to double
  %3767 = fmul double %3764, %3765
  %3768 = fmul double %3767, %3766
  %3769 = fptrunc double %3768 to float
  %3770 = fcmp oeq float %3756, 0.000000e+00
  %3771 = call float @llvm.fabs.f32(float %3748)
  %3772 = fcmp olt float %3771, +inf
  %3773 = and i1 %3770, %3772
  %3774 = select i1 %3773, float 0.000000e+00, float %3769
  br label %3775

3775:                                             ; preds = %3762, %3763
  %3776 = phi float [ %3774, %3763 ], [ %3757, %3762 ]
  br label %3777

3777:                                             ; preds = %3775
  %3778 = add i64 %91, %57
  %3779 = icmp slt i64 %3778, %26
  %3780 = select i1 %3779, i64 %3778, i64 0
  %3781 = extractelement <8 x float> %3545, i64 7
  %3782 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3783 = getelementptr inbounds nuw i8, ptr %3782, i64 %3780
  %3784 = load i8, ptr %3783, align 1
  %3785 = zext i8 %3784 to i32
  %3786 = shl i32 %3785, 23
  %3787 = bitcast i32 %3786 to float
  %3788 = fmul float %3787, %3781
  %3789 = extractelement <8 x float> %167, i64 7
  %3790 = fmul float %3789, %3788
  %3791 = call float @llvm.fabs.f32(float %3788)
  %3792 = fcmp olt float %3791, +inf
  %3793 = fcmp one float %3788, 0.000000e+00
  %3794 = and i1 %3792, %3793
  br i1 %3794, label %3795, label %3796

3795:                                             ; preds = %3777
  br label %3808

3796:                                             ; preds = %3777
  %3797 = fpext float %3789 to double
  %3798 = fpext float %3787 to double
  %3799 = fpext float %3781 to double
  %3800 = fmul double %3797, %3798
  %3801 = fmul double %3800, %3799
  %3802 = fptrunc double %3801 to float
  %3803 = fcmp oeq float %3789, 0.000000e+00
  %3804 = call float @llvm.fabs.f32(float %3781)
  %3805 = fcmp olt float %3804, +inf
  %3806 = and i1 %3803, %3805
  %3807 = select i1 %3806, float 0.000000e+00, float %3802
  br label %3808

3808:                                             ; preds = %3795, %3796
  %3809 = phi float [ %3807, %3796 ], [ %3790, %3795 ]
  br label %3810

3810:                                             ; preds = %3808
  %3811 = mul i64 %58, 8
  %3812 = add i64 %88, %3811
  %3813 = add i64 %91, %57
  %3814 = mul i64 %3812, %26
  %3815 = add i64 %3814, %3813
  %3816 = fptrunc float %3578 to bfloat
  %3817 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3818 = getelementptr inbounds nuw bfloat, ptr %3817, i64 %3815
  store bfloat %3816, ptr %3818, align 2
  %3819 = mul i64 %58, 8
  %3820 = add i64 %3819, 1
  %3821 = add i64 %88, %3820
  %3822 = add i64 %91, %57
  %3823 = mul i64 %3821, %26
  %3824 = add i64 %3823, %3822
  %3825 = fptrunc float %3611 to bfloat
  %3826 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3827 = getelementptr inbounds nuw bfloat, ptr %3826, i64 %3824
  store bfloat %3825, ptr %3827, align 2
  %3828 = mul i64 %58, 8
  %3829 = add i64 %3828, 2
  %3830 = add i64 %88, %3829
  %3831 = add i64 %91, %57
  %3832 = mul i64 %3830, %26
  %3833 = add i64 %3832, %3831
  %3834 = fptrunc float %3644 to bfloat
  %3835 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3836 = getelementptr inbounds nuw bfloat, ptr %3835, i64 %3833
  store bfloat %3834, ptr %3836, align 2
  %3837 = mul i64 %58, 8
  %3838 = add i64 %3837, 3
  %3839 = add i64 %88, %3838
  %3840 = add i64 %91, %57
  %3841 = mul i64 %3839, %26
  %3842 = add i64 %3841, %3840
  %3843 = fptrunc float %3677 to bfloat
  %3844 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3845 = getelementptr inbounds nuw bfloat, ptr %3844, i64 %3842
  store bfloat %3843, ptr %3845, align 2
  %3846 = mul i64 %58, 8
  %3847 = add i64 %3846, 4
  %3848 = add i64 %88, %3847
  %3849 = add i64 %91, %57
  %3850 = mul i64 %3848, %26
  %3851 = add i64 %3850, %3849
  %3852 = fptrunc float %3710 to bfloat
  %3853 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3854 = getelementptr inbounds nuw bfloat, ptr %3853, i64 %3851
  store bfloat %3852, ptr %3854, align 2
  %3855 = mul i64 %58, 8
  %3856 = add i64 %3855, 5
  %3857 = add i64 %88, %3856
  %3858 = add i64 %91, %57
  %3859 = mul i64 %3857, %26
  %3860 = add i64 %3859, %3858
  %3861 = fptrunc float %3743 to bfloat
  %3862 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3863 = getelementptr inbounds nuw bfloat, ptr %3862, i64 %3860
  store bfloat %3861, ptr %3863, align 2
  %3864 = mul i64 %58, 8
  %3865 = add i64 %3864, 6
  %3866 = add i64 %88, %3865
  %3867 = add i64 %91, %57
  %3868 = mul i64 %3866, %26
  %3869 = add i64 %3868, %3867
  %3870 = fptrunc float %3776 to bfloat
  %3871 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3872 = getelementptr inbounds nuw bfloat, ptr %3871, i64 %3869
  store bfloat %3870, ptr %3872, align 2
  %3873 = mul i64 %58, 8
  %3874 = add i64 %3873, 7
  %3875 = add i64 %88, %3874
  %3876 = add i64 %91, %57
  %3877 = mul i64 %3875, %26
  %3878 = add i64 %3877, %3876
  %3879 = fptrunc float %3809 to bfloat
  %3880 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3881 = getelementptr inbounds nuw bfloat, ptr %3880, i64 %3878
  store bfloat %3879, ptr %3881, align 2
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #5

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.sched.group.barrier(i32 immarg, i32 immarg, i32 immarg) #3

attributes #0 = { "amdgpu-flat-work-group-size"="256,256" "target-features"="-cumode" "uniform-work-group-size" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { convergent nocallback nofree nounwind willreturn }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
