; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal addrspace(3) global [5120 x i8] undef

define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) #0 !reqd_work_group_size !1 {
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %20, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, ptr %21, 1
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, i64 %22, 2
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %23, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %24, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, ptr %16, 1
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 %17, 2
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 %18, 3, 0
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %19, 4, 0
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %10, 0
  %40 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, ptr %11, 1
  %41 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, i64 %12, 2
  %42 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %41, i64 %13, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %42, i64 %14, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %45 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %44, ptr %6, 1
  %46 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %45, i64 %7, 2
  %47 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, i64 %8, 3, 0
  %48 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, i64 %9, 4, 0
  %49 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %50 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %49, ptr %1, 1
  %51 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %50, i64 %2, 2
  %52 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %51, i64 %3, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %52, i64 %4, 4, 0
  %54 = call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %55 = sext i32 %54 to i64
  %56 = urem i64 %55, 32
  %57 = urem i64 %56, 16
  %58 = udiv i64 %56, 16
  %59 = udiv i64 %55, 32
  %60 = udiv i64 %59, 2
  %61 = urem i64 %59, 2
  %62 = call i32 @llvm.amdgcn.workgroup.id.x()
  %63 = sext i32 %62 to i64
  %64 = add i64 %25, 255
  %65 = udiv i64 %64, 256
  %66 = add i64 %26, 63
  %67 = udiv i64 %66, 64
  %68 = mul i64 %67, 4
  %69 = udiv i64 %63, %68
  %70 = mul i64 %69, 4
  %71 = sub i64 %65, %70
  %72 = icmp ult i64 %71, 4
  %73 = select i1 %72, i64 %71, i64 4
  %74 = urem i64 %63, %68
  %75 = urem i64 %74, %73
  %76 = add i64 %70, %75
  %77 = udiv i64 %74, %73
  %78 = mul i64 %76, 256
  %79 = mul i64 %77, 64
  %80 = mul i64 %60, 64
  %81 = mul i64 %61, 32
  %82 = add i64 %78, %80
  %83 = add i64 %80, 16
  %84 = add i64 %78, %83
  %85 = add i64 %80, 32
  %86 = add i64 %78, %85
  %87 = add i64 %80, 48
  %88 = add i64 %78, %87
  %89 = add i64 %79, %81
  %90 = add i64 %81, 16
  %91 = add i64 %79, %90
  %92 = udiv i64 %55, 4
  %93 = urem i64 %55, 4
  %94 = mul i64 %93, 16
  %95 = add i64 %78, %92
  %96 = mul i64 %95, %27
  %97 = add i64 %96, %94
  %98 = mul i64 %92, 80
  %99 = add i64 %98, %94
  %100 = add i64 %55, 256
  %101 = udiv i64 %100, 4
  %102 = urem i64 %100, 4
  %103 = mul i64 %102, 16
  %104 = add i64 %78, %101
  %105 = mul i64 %104, %27
  %106 = add i64 %105, %103
  %107 = mul i64 %101, 80
  %108 = add i64 %107, %103
  %109 = add i64 %55, 512
  %110 = udiv i64 %109, 4
  %111 = urem i64 %109, 4
  %112 = mul i64 %111, 16
  %113 = add i64 %78, %110
  %114 = mul i64 %113, %27
  %115 = add i64 %114, %112
  %116 = mul i64 %110, 80
  %117 = add i64 %116, %112
  %118 = add i64 %55, 768
  %119 = udiv i64 %118, 4
  %120 = urem i64 %118, 4
  %121 = mul i64 %120, 16
  %122 = add i64 %78, %119
  %123 = mul i64 %122, %27
  %124 = add i64 %123, %121
  %125 = mul i64 %119, 80
  %126 = add i64 %125, %121
  %127 = udiv i64 %55, 4
  %128 = urem i64 %55, 4
  %129 = mul i64 %128, 16
  %130 = add i64 %79, %127
  %131 = mul i64 %130, %27
  %132 = add i64 %131, %129
  %133 = mul i64 %127, 80
  %134 = add i64 %133, %129
  %135 = icmp uge i64 %27, 64
  call void @llvm.assume(i1 %135)
  %136 = udiv i64 %27, 64
  %137 = sub i64 %27, 64
  %138 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %139 = getelementptr i8, ptr %138, i64 %97
  %140 = load <16 x i8>, ptr %139, align 16
  %141 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %142 = getelementptr i8, ptr %141, i64 %106
  %143 = load <16 x i8>, ptr %142, align 16
  %144 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %145 = getelementptr i8, ptr %144, i64 %115
  %146 = load <16 x i8>, ptr %145, align 16
  %147 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %148 = getelementptr i8, ptr %147, i64 %124
  %149 = load <16 x i8>, ptr %148, align 16
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %140, ptr addrspace(3) %150, align 16
  %151 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %143, ptr addrspace(3) %151, align 16
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %146, ptr addrspace(3) %152, align 16
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %149, ptr addrspace(3) %153, align 16
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %155 = getelementptr i8, ptr %154, i64 %132
  %156 = load <16 x i8>, ptr %155, align 16
  %157 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %156, ptr addrspace(3) %157, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  br label %158

158:                                              ; preds = %169, %28
  %159 = phi i64 [ %416, %169 ], [ 0, %28 ]
  %160 = phi <8 x float> [ %387, %169 ], [ zeroinitializer, %28 ]
  %161 = phi <8 x float> [ %388, %169 ], [ zeroinitializer, %28 ]
  %162 = phi <8 x float> [ %389, %169 ], [ zeroinitializer, %28 ]
  %163 = phi <8 x float> [ %390, %169 ], [ zeroinitializer, %28 ]
  %164 = phi <8 x float> [ %391, %169 ], [ zeroinitializer, %28 ]
  %165 = phi <8 x float> [ %392, %169 ], [ zeroinitializer, %28 ]
  %166 = phi <8 x float> [ %393, %169 ], [ zeroinitializer, %28 ]
  %167 = phi <8 x float> [ %394, %169 ], [ zeroinitializer, %28 ]
  %168 = icmp slt i64 %159, %136
  br i1 %168, label %169, label %417

169:                                              ; preds = %158
  %170 = mul i64 %159, 64
  %171 = add i64 %170, 64
  %172 = call i64 @llvm.umin.i64(i64 %171, i64 %137)
  %173 = add i64 %132, %172
  %174 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %175 = getelementptr i8, ptr %174, i64 %173
  %176 = load <16 x i8>, ptr %175, align 16
  %177 = mul i64 %58, 8
  %178 = add i64 %80, %57
  %179 = mul i64 %178, 80
  %180 = add i64 %179, %177
  %181 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %180
  %182 = load <8 x i8>, ptr addrspace(3) %181, align 1
  %183 = bitcast <8 x i8> %182 to <2 x i32>
  %184 = mul i64 %58, 8
  %185 = add i64 %83, %57
  %186 = mul i64 %185, 80
  %187 = add i64 %186, %184
  %188 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %187
  %189 = load <8 x i8>, ptr addrspace(3) %188, align 1
  %190 = bitcast <8 x i8> %189 to <2 x i32>
  %191 = mul i64 %58, 8
  %192 = add i64 %85, %57
  %193 = mul i64 %192, 80
  %194 = add i64 %193, %191
  %195 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %194
  %196 = load <8 x i8>, ptr addrspace(3) %195, align 1
  %197 = bitcast <8 x i8> %196 to <2 x i32>
  %198 = mul i64 %58, 8
  %199 = add i64 %87, %57
  %200 = mul i64 %199, 80
  %201 = add i64 %200, %198
  %202 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %201
  %203 = load <8 x i8>, ptr addrspace(3) %202, align 1
  %204 = bitcast <8 x i8> %203 to <2 x i32>
  %205 = mul i64 %58, 8
  %206 = add i64 %81, %57
  %207 = mul i64 %206, 80
  %208 = add i64 %207, %205
  %209 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %208
  %210 = load <8 x i8>, ptr addrspace(3) %209, align 1
  %211 = bitcast <8 x i8> %210 to <2 x i32>
  %212 = mul i64 %58, 8
  %213 = add i64 %90, %57
  %214 = mul i64 %213, 80
  %215 = add i64 %214, %212
  %216 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %215
  %217 = load <8 x i8>, ptr addrspace(3) %216, align 1
  %218 = bitcast <8 x i8> %217 to <2 x i32>
  %219 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %183, <2 x i32> %211, <8 x float> %160)
  %220 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %183, <2 x i32> %218, <8 x float> %161)
  %221 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %190, <2 x i32> %211, <8 x float> %162)
  %222 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %190, <2 x i32> %218, <8 x float> %163)
  %223 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %197, <2 x i32> %211, <8 x float> %164)
  %224 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %197, <2 x i32> %218, <8 x float> %165)
  %225 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %204, <2 x i32> %211, <8 x float> %166)
  %226 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %204, <2 x i32> %218, <8 x float> %167)
  %227 = mul i64 %58, 8
  %228 = add i64 %80, %57
  %229 = add i64 %227, 16
  %230 = mul i64 %228, 80
  %231 = add i64 %230, %229
  %232 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %231
  %233 = load <8 x i8>, ptr addrspace(3) %232, align 1
  %234 = bitcast <8 x i8> %233 to <2 x i32>
  %235 = mul i64 %58, 8
  %236 = add i64 %83, %57
  %237 = add i64 %235, 16
  %238 = mul i64 %236, 80
  %239 = add i64 %238, %237
  %240 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %239
  %241 = load <8 x i8>, ptr addrspace(3) %240, align 1
  %242 = bitcast <8 x i8> %241 to <2 x i32>
  %243 = mul i64 %58, 8
  %244 = add i64 %85, %57
  %245 = add i64 %243, 16
  %246 = mul i64 %244, 80
  %247 = add i64 %246, %245
  %248 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %247
  %249 = load <8 x i8>, ptr addrspace(3) %248, align 1
  %250 = bitcast <8 x i8> %249 to <2 x i32>
  %251 = mul i64 %58, 8
  %252 = add i64 %87, %57
  %253 = add i64 %251, 16
  %254 = mul i64 %252, 80
  %255 = add i64 %254, %253
  %256 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %255
  %257 = load <8 x i8>, ptr addrspace(3) %256, align 1
  %258 = bitcast <8 x i8> %257 to <2 x i32>
  %259 = mul i64 %58, 8
  %260 = add i64 %259, 16
  %261 = add i64 %81, %57
  %262 = mul i64 %261, 80
  %263 = add i64 %262, %260
  %264 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %263
  %265 = load <8 x i8>, ptr addrspace(3) %264, align 1
  %266 = bitcast <8 x i8> %265 to <2 x i32>
  %267 = mul i64 %58, 8
  %268 = add i64 %267, 16
  %269 = add i64 %90, %57
  %270 = mul i64 %269, 80
  %271 = add i64 %270, %268
  %272 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %271
  %273 = load <8 x i8>, ptr addrspace(3) %272, align 1
  %274 = bitcast <8 x i8> %273 to <2 x i32>
  %275 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %234, <2 x i32> %266, <8 x float> %219)
  %276 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %234, <2 x i32> %274, <8 x float> %220)
  %277 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %266, <8 x float> %221)
  %278 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %242, <2 x i32> %274, <8 x float> %222)
  %279 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %266, <8 x float> %223)
  %280 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %250, <2 x i32> %274, <8 x float> %224)
  %281 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %266, <8 x float> %225)
  %282 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %274, <8 x float> %226)
  %283 = mul i64 %58, 8
  %284 = add i64 %80, %57
  %285 = add i64 %283, 32
  %286 = mul i64 %284, 80
  %287 = add i64 %286, %285
  %288 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %287
  %289 = load <8 x i8>, ptr addrspace(3) %288, align 1
  %290 = bitcast <8 x i8> %289 to <2 x i32>
  %291 = mul i64 %58, 8
  %292 = add i64 %83, %57
  %293 = add i64 %291, 32
  %294 = mul i64 %292, 80
  %295 = add i64 %294, %293
  %296 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %295
  %297 = load <8 x i8>, ptr addrspace(3) %296, align 1
  %298 = bitcast <8 x i8> %297 to <2 x i32>
  %299 = mul i64 %58, 8
  %300 = add i64 %85, %57
  %301 = add i64 %299, 32
  %302 = mul i64 %300, 80
  %303 = add i64 %302, %301
  %304 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %303
  %305 = load <8 x i8>, ptr addrspace(3) %304, align 1
  %306 = bitcast <8 x i8> %305 to <2 x i32>
  %307 = mul i64 %58, 8
  %308 = add i64 %87, %57
  %309 = add i64 %307, 32
  %310 = mul i64 %308, 80
  %311 = add i64 %310, %309
  %312 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %311
  %313 = load <8 x i8>, ptr addrspace(3) %312, align 1
  %314 = bitcast <8 x i8> %313 to <2 x i32>
  %315 = mul i64 %58, 8
  %316 = add i64 %315, 32
  %317 = add i64 %81, %57
  %318 = mul i64 %317, 80
  %319 = add i64 %318, %316
  %320 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %319
  %321 = load <8 x i8>, ptr addrspace(3) %320, align 1
  %322 = bitcast <8 x i8> %321 to <2 x i32>
  %323 = mul i64 %58, 8
  %324 = add i64 %323, 32
  %325 = add i64 %90, %57
  %326 = mul i64 %325, 80
  %327 = add i64 %326, %324
  %328 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %327
  %329 = load <8 x i8>, ptr addrspace(3) %328, align 1
  %330 = bitcast <8 x i8> %329 to <2 x i32>
  %331 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %290, <2 x i32> %322, <8 x float> %275)
  %332 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %290, <2 x i32> %330, <8 x float> %276)
  %333 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %298, <2 x i32> %322, <8 x float> %277)
  %334 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %298, <2 x i32> %330, <8 x float> %278)
  %335 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %322, <8 x float> %279)
  %336 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %306, <2 x i32> %330, <8 x float> %280)
  %337 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %322, <8 x float> %281)
  %338 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %314, <2 x i32> %330, <8 x float> %282)
  %339 = mul i64 %58, 8
  %340 = add i64 %80, %57
  %341 = add i64 %339, 48
  %342 = mul i64 %340, 80
  %343 = add i64 %342, %341
  %344 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %343
  %345 = load <8 x i8>, ptr addrspace(3) %344, align 1
  %346 = bitcast <8 x i8> %345 to <2 x i32>
  %347 = mul i64 %58, 8
  %348 = add i64 %83, %57
  %349 = add i64 %347, 48
  %350 = mul i64 %348, 80
  %351 = add i64 %350, %349
  %352 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %351
  %353 = load <8 x i8>, ptr addrspace(3) %352, align 1
  %354 = bitcast <8 x i8> %353 to <2 x i32>
  %355 = mul i64 %58, 8
  %356 = add i64 %85, %57
  %357 = add i64 %355, 48
  %358 = mul i64 %356, 80
  %359 = add i64 %358, %357
  %360 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %359
  %361 = load <8 x i8>, ptr addrspace(3) %360, align 1
  %362 = bitcast <8 x i8> %361 to <2 x i32>
  %363 = mul i64 %58, 8
  %364 = add i64 %87, %57
  %365 = add i64 %363, 48
  %366 = mul i64 %364, 80
  %367 = add i64 %366, %365
  %368 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %367
  %369 = load <8 x i8>, ptr addrspace(3) %368, align 1
  %370 = bitcast <8 x i8> %369 to <2 x i32>
  %371 = mul i64 %58, 8
  %372 = add i64 %371, 48
  %373 = add i64 %81, %57
  %374 = mul i64 %373, 80
  %375 = add i64 %374, %372
  %376 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %375
  %377 = load <8 x i8>, ptr addrspace(3) %376, align 1
  %378 = bitcast <8 x i8> %377 to <2 x i32>
  %379 = mul i64 %58, 8
  %380 = add i64 %379, 48
  %381 = add i64 %90, %57
  %382 = mul i64 %381, 80
  %383 = add i64 %382, %380
  %384 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %383
  %385 = load <8 x i8>, ptr addrspace(3) %384, align 1
  %386 = bitcast <8 x i8> %385 to <2 x i32>
  %387 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %346, <2 x i32> %378, <8 x float> %331)
  %388 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %346, <2 x i32> %386, <8 x float> %332)
  %389 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %354, <2 x i32> %378, <8 x float> %333)
  %390 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %354, <2 x i32> %386, <8 x float> %334)
  %391 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %378, <8 x float> %335)
  %392 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %362, <2 x i32> %386, <8 x float> %336)
  %393 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %378, <8 x float> %337)
  %394 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %370, <2 x i32> %386, <8 x float> %338)
  call void @llvm.amdgcn.sched.barrier(i32 0)
  %395 = add i64 %97, %172
  %396 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %397 = getelementptr i8, ptr %396, i64 %395
  %398 = load <16 x i8>, ptr %397, align 16
  %399 = add i64 %106, %172
  %400 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %401 = getelementptr i8, ptr %400, i64 %399
  %402 = load <16 x i8>, ptr %401, align 16
  %403 = add i64 %115, %172
  %404 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %405 = getelementptr i8, ptr %404, i64 %403
  %406 = load <16 x i8>, ptr %405, align 16
  %407 = add i64 %124, %172
  %408 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %409 = getelementptr i8, ptr %408, i64 %407
  %410 = load <16 x i8>, ptr %409, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %411 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %398, ptr addrspace(3) %411, align 16
  %412 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %402, ptr addrspace(3) %412, align 16
  %413 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %406, ptr addrspace(3) %413, align 16
  %414 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %410, ptr addrspace(3) %414, align 16
  %415 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %176, ptr addrspace(3) %415, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %416 = add i64 %159, 1
  br label %158

417:                                              ; preds = %158
  %418 = mul i64 %58, 8
  %419 = add i64 %82, %418
  %420 = add i64 %89, %57
  %421 = add i64 %419, 7
  %422 = icmp ult i64 %420, %26
  %423 = icmp ult i64 %421, %25
  %424 = and i1 %423, %422
  %425 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %426 = ptrtoint ptr %425 to i64
  %427 = mul i64 %419, 4
  %428 = add i64 %426, %427
  %429 = urem i64 %428, 16
  %430 = icmp eq i64 %429, 0
  %431 = and i1 %424, %430
  br i1 %431, label %432, label %441

432:                                              ; preds = %417
  %433 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %434 = getelementptr float, ptr %433, i64 %419
  %435 = load <4 x float>, ptr %434, align 16
  %436 = add i64 %419, 4
  %437 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %438 = getelementptr float, ptr %437, i64 %436
  %439 = load <4 x float>, ptr %438, align 16
  %440 = shufflevector <4 x float> %435, <4 x float> %439, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %513

441:                                              ; preds = %417
  %442 = mul i64 %58, 8
  %443 = add i64 %82, %442
  %444 = icmp slt i64 %443, %25
  %445 = select i1 %444, i64 %443, i64 0
  %446 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %447 = getelementptr inbounds nuw float, ptr %446, i64 %445
  %448 = load float, ptr %447, align 4
  %449 = insertelement <8 x float> zeroinitializer, float %448, i64 0
  %450 = mul i64 %58, 8
  %451 = add i64 %450, 1
  %452 = add i64 %82, %451
  %453 = icmp slt i64 %452, %25
  %454 = select i1 %453, i64 %452, i64 0
  %455 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %456 = getelementptr inbounds nuw float, ptr %455, i64 %454
  %457 = load float, ptr %456, align 4
  %458 = insertelement <8 x float> %449, float %457, i64 1
  %459 = mul i64 %58, 8
  %460 = add i64 %459, 2
  %461 = add i64 %82, %460
  %462 = icmp slt i64 %461, %25
  %463 = select i1 %462, i64 %461, i64 0
  %464 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %465 = getelementptr inbounds nuw float, ptr %464, i64 %463
  %466 = load float, ptr %465, align 4
  %467 = insertelement <8 x float> %458, float %466, i64 2
  %468 = mul i64 %58, 8
  %469 = add i64 %468, 3
  %470 = add i64 %82, %469
  %471 = icmp slt i64 %470, %25
  %472 = select i1 %471, i64 %470, i64 0
  %473 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %474 = getelementptr inbounds nuw float, ptr %473, i64 %472
  %475 = load float, ptr %474, align 4
  %476 = insertelement <8 x float> %467, float %475, i64 3
  %477 = mul i64 %58, 8
  %478 = add i64 %477, 4
  %479 = add i64 %82, %478
  %480 = icmp slt i64 %479, %25
  %481 = select i1 %480, i64 %479, i64 0
  %482 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %483 = getelementptr inbounds nuw float, ptr %482, i64 %481
  %484 = load float, ptr %483, align 4
  %485 = insertelement <8 x float> %476, float %484, i64 4
  %486 = mul i64 %58, 8
  %487 = add i64 %486, 5
  %488 = add i64 %82, %487
  %489 = icmp slt i64 %488, %25
  %490 = select i1 %489, i64 %488, i64 0
  %491 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %492 = getelementptr inbounds nuw float, ptr %491, i64 %490
  %493 = load float, ptr %492, align 4
  %494 = insertelement <8 x float> %485, float %493, i64 5
  %495 = mul i64 %58, 8
  %496 = add i64 %495, 6
  %497 = add i64 %82, %496
  %498 = icmp slt i64 %497, %25
  %499 = select i1 %498, i64 %497, i64 0
  %500 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %501 = getelementptr inbounds nuw float, ptr %500, i64 %499
  %502 = load float, ptr %501, align 4
  %503 = insertelement <8 x float> %494, float %502, i64 6
  %504 = mul i64 %58, 8
  %505 = add i64 %504, 7
  %506 = add i64 %82, %505
  %507 = icmp slt i64 %506, %25
  %508 = select i1 %507, i64 %506, i64 0
  %509 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %510 = getelementptr inbounds nuw float, ptr %509, i64 %508
  %511 = load float, ptr %510, align 4
  %512 = insertelement <8 x float> %503, float %511, i64 7
  br label %513

513:                                              ; preds = %432, %441
  %514 = phi <8 x float> [ %512, %441 ], [ %440, %432 ]
  br label %515

515:                                              ; preds = %513
  %516 = add i64 %89, %57
  %517 = icmp slt i64 %516, %26
  %518 = select i1 %517, i64 %516, i64 0
  %519 = extractelement <8 x float> %514, i64 0
  %520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %521 = getelementptr inbounds nuw i8, ptr %520, i64 %518
  %522 = load i8, ptr %521, align 1
  %523 = zext i8 %522 to i32
  %524 = shl i32 %523, 23
  %525 = bitcast i32 %524 to float
  %526 = fmul float %525, %519
  %527 = extractelement <8 x float> %160, i64 0
  %528 = fmul float %527, %526
  %529 = call float @llvm.fabs.f32(float %526)
  %530 = fcmp olt float %529, +inf
  %531 = fcmp one float %526, 0.000000e+00
  %532 = and i1 %530, %531
  %533 = call i1 @llvm.expect.i1(i1 %532, i1 true)
  br i1 %533, label %534, label %535

534:                                              ; preds = %515
  br label %547

535:                                              ; preds = %515
  %536 = fpext float %527 to double
  %537 = fpext float %525 to double
  %538 = fpext float %519 to double
  %539 = fmul double %536, %537
  %540 = fmul double %539, %538
  %541 = fptrunc double %540 to float
  %542 = fcmp oeq float %527, 0.000000e+00
  %543 = call float @llvm.fabs.f32(float %519)
  %544 = fcmp olt float %543, +inf
  %545 = and i1 %542, %544
  %546 = select i1 %545, float 0.000000e+00, float %541
  br label %547

547:                                              ; preds = %534, %535
  %548 = phi float [ %546, %535 ], [ %528, %534 ]
  br label %549

549:                                              ; preds = %547
  %550 = add i64 %89, %57
  %551 = icmp slt i64 %550, %26
  %552 = select i1 %551, i64 %550, i64 0
  %553 = extractelement <8 x float> %514, i64 1
  %554 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %555 = getelementptr inbounds nuw i8, ptr %554, i64 %552
  %556 = load i8, ptr %555, align 1
  %557 = zext i8 %556 to i32
  %558 = shl i32 %557, 23
  %559 = bitcast i32 %558 to float
  %560 = fmul float %559, %553
  %561 = extractelement <8 x float> %160, i64 1
  %562 = fmul float %561, %560
  %563 = call float @llvm.fabs.f32(float %560)
  %564 = fcmp olt float %563, +inf
  %565 = fcmp one float %560, 0.000000e+00
  %566 = and i1 %564, %565
  %567 = call i1 @llvm.expect.i1(i1 %566, i1 true)
  br i1 %567, label %568, label %569

568:                                              ; preds = %549
  br label %581

569:                                              ; preds = %549
  %570 = fpext float %561 to double
  %571 = fpext float %559 to double
  %572 = fpext float %553 to double
  %573 = fmul double %570, %571
  %574 = fmul double %573, %572
  %575 = fptrunc double %574 to float
  %576 = fcmp oeq float %561, 0.000000e+00
  %577 = call float @llvm.fabs.f32(float %553)
  %578 = fcmp olt float %577, +inf
  %579 = and i1 %576, %578
  %580 = select i1 %579, float 0.000000e+00, float %575
  br label %581

581:                                              ; preds = %568, %569
  %582 = phi float [ %580, %569 ], [ %562, %568 ]
  br label %583

583:                                              ; preds = %581
  %584 = add i64 %89, %57
  %585 = icmp slt i64 %584, %26
  %586 = select i1 %585, i64 %584, i64 0
  %587 = extractelement <8 x float> %514, i64 2
  %588 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %589 = getelementptr inbounds nuw i8, ptr %588, i64 %586
  %590 = load i8, ptr %589, align 1
  %591 = zext i8 %590 to i32
  %592 = shl i32 %591, 23
  %593 = bitcast i32 %592 to float
  %594 = fmul float %593, %587
  %595 = extractelement <8 x float> %160, i64 2
  %596 = fmul float %595, %594
  %597 = call float @llvm.fabs.f32(float %594)
  %598 = fcmp olt float %597, +inf
  %599 = fcmp one float %594, 0.000000e+00
  %600 = and i1 %598, %599
  %601 = call i1 @llvm.expect.i1(i1 %600, i1 true)
  br i1 %601, label %602, label %603

602:                                              ; preds = %583
  br label %615

603:                                              ; preds = %583
  %604 = fpext float %595 to double
  %605 = fpext float %593 to double
  %606 = fpext float %587 to double
  %607 = fmul double %604, %605
  %608 = fmul double %607, %606
  %609 = fptrunc double %608 to float
  %610 = fcmp oeq float %595, 0.000000e+00
  %611 = call float @llvm.fabs.f32(float %587)
  %612 = fcmp olt float %611, +inf
  %613 = and i1 %610, %612
  %614 = select i1 %613, float 0.000000e+00, float %609
  br label %615

615:                                              ; preds = %602, %603
  %616 = phi float [ %614, %603 ], [ %596, %602 ]
  br label %617

617:                                              ; preds = %615
  %618 = add i64 %89, %57
  %619 = icmp slt i64 %618, %26
  %620 = select i1 %619, i64 %618, i64 0
  %621 = extractelement <8 x float> %514, i64 3
  %622 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %623 = getelementptr inbounds nuw i8, ptr %622, i64 %620
  %624 = load i8, ptr %623, align 1
  %625 = zext i8 %624 to i32
  %626 = shl i32 %625, 23
  %627 = bitcast i32 %626 to float
  %628 = fmul float %627, %621
  %629 = extractelement <8 x float> %160, i64 3
  %630 = fmul float %629, %628
  %631 = call float @llvm.fabs.f32(float %628)
  %632 = fcmp olt float %631, +inf
  %633 = fcmp one float %628, 0.000000e+00
  %634 = and i1 %632, %633
  %635 = call i1 @llvm.expect.i1(i1 %634, i1 true)
  br i1 %635, label %636, label %637

636:                                              ; preds = %617
  br label %649

637:                                              ; preds = %617
  %638 = fpext float %629 to double
  %639 = fpext float %627 to double
  %640 = fpext float %621 to double
  %641 = fmul double %638, %639
  %642 = fmul double %641, %640
  %643 = fptrunc double %642 to float
  %644 = fcmp oeq float %629, 0.000000e+00
  %645 = call float @llvm.fabs.f32(float %621)
  %646 = fcmp olt float %645, +inf
  %647 = and i1 %644, %646
  %648 = select i1 %647, float 0.000000e+00, float %643
  br label %649

649:                                              ; preds = %636, %637
  %650 = phi float [ %648, %637 ], [ %630, %636 ]
  br label %651

651:                                              ; preds = %649
  %652 = add i64 %89, %57
  %653 = icmp slt i64 %652, %26
  %654 = select i1 %653, i64 %652, i64 0
  %655 = extractelement <8 x float> %514, i64 4
  %656 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %657 = getelementptr inbounds nuw i8, ptr %656, i64 %654
  %658 = load i8, ptr %657, align 1
  %659 = zext i8 %658 to i32
  %660 = shl i32 %659, 23
  %661 = bitcast i32 %660 to float
  %662 = fmul float %661, %655
  %663 = extractelement <8 x float> %160, i64 4
  %664 = fmul float %663, %662
  %665 = call float @llvm.fabs.f32(float %662)
  %666 = fcmp olt float %665, +inf
  %667 = fcmp one float %662, 0.000000e+00
  %668 = and i1 %666, %667
  %669 = call i1 @llvm.expect.i1(i1 %668, i1 true)
  br i1 %669, label %670, label %671

670:                                              ; preds = %651
  br label %683

671:                                              ; preds = %651
  %672 = fpext float %663 to double
  %673 = fpext float %661 to double
  %674 = fpext float %655 to double
  %675 = fmul double %672, %673
  %676 = fmul double %675, %674
  %677 = fptrunc double %676 to float
  %678 = fcmp oeq float %663, 0.000000e+00
  %679 = call float @llvm.fabs.f32(float %655)
  %680 = fcmp olt float %679, +inf
  %681 = and i1 %678, %680
  %682 = select i1 %681, float 0.000000e+00, float %677
  br label %683

683:                                              ; preds = %670, %671
  %684 = phi float [ %682, %671 ], [ %664, %670 ]
  br label %685

685:                                              ; preds = %683
  %686 = add i64 %89, %57
  %687 = icmp slt i64 %686, %26
  %688 = select i1 %687, i64 %686, i64 0
  %689 = extractelement <8 x float> %514, i64 5
  %690 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %691 = getelementptr inbounds nuw i8, ptr %690, i64 %688
  %692 = load i8, ptr %691, align 1
  %693 = zext i8 %692 to i32
  %694 = shl i32 %693, 23
  %695 = bitcast i32 %694 to float
  %696 = fmul float %695, %689
  %697 = extractelement <8 x float> %160, i64 5
  %698 = fmul float %697, %696
  %699 = call float @llvm.fabs.f32(float %696)
  %700 = fcmp olt float %699, +inf
  %701 = fcmp one float %696, 0.000000e+00
  %702 = and i1 %700, %701
  %703 = call i1 @llvm.expect.i1(i1 %702, i1 true)
  br i1 %703, label %704, label %705

704:                                              ; preds = %685
  br label %717

705:                                              ; preds = %685
  %706 = fpext float %697 to double
  %707 = fpext float %695 to double
  %708 = fpext float %689 to double
  %709 = fmul double %706, %707
  %710 = fmul double %709, %708
  %711 = fptrunc double %710 to float
  %712 = fcmp oeq float %697, 0.000000e+00
  %713 = call float @llvm.fabs.f32(float %689)
  %714 = fcmp olt float %713, +inf
  %715 = and i1 %712, %714
  %716 = select i1 %715, float 0.000000e+00, float %711
  br label %717

717:                                              ; preds = %704, %705
  %718 = phi float [ %716, %705 ], [ %698, %704 ]
  br label %719

719:                                              ; preds = %717
  %720 = add i64 %89, %57
  %721 = icmp slt i64 %720, %26
  %722 = select i1 %721, i64 %720, i64 0
  %723 = extractelement <8 x float> %514, i64 6
  %724 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %725 = getelementptr inbounds nuw i8, ptr %724, i64 %722
  %726 = load i8, ptr %725, align 1
  %727 = zext i8 %726 to i32
  %728 = shl i32 %727, 23
  %729 = bitcast i32 %728 to float
  %730 = fmul float %729, %723
  %731 = extractelement <8 x float> %160, i64 6
  %732 = fmul float %731, %730
  %733 = call float @llvm.fabs.f32(float %730)
  %734 = fcmp olt float %733, +inf
  %735 = fcmp one float %730, 0.000000e+00
  %736 = and i1 %734, %735
  %737 = call i1 @llvm.expect.i1(i1 %736, i1 true)
  br i1 %737, label %738, label %739

738:                                              ; preds = %719
  br label %751

739:                                              ; preds = %719
  %740 = fpext float %731 to double
  %741 = fpext float %729 to double
  %742 = fpext float %723 to double
  %743 = fmul double %740, %741
  %744 = fmul double %743, %742
  %745 = fptrunc double %744 to float
  %746 = fcmp oeq float %731, 0.000000e+00
  %747 = call float @llvm.fabs.f32(float %723)
  %748 = fcmp olt float %747, +inf
  %749 = and i1 %746, %748
  %750 = select i1 %749, float 0.000000e+00, float %745
  br label %751

751:                                              ; preds = %738, %739
  %752 = phi float [ %750, %739 ], [ %732, %738 ]
  br label %753

753:                                              ; preds = %751
  %754 = add i64 %89, %57
  %755 = icmp slt i64 %754, %26
  %756 = select i1 %755, i64 %754, i64 0
  %757 = extractelement <8 x float> %514, i64 7
  %758 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %759 = getelementptr inbounds nuw i8, ptr %758, i64 %756
  %760 = load i8, ptr %759, align 1
  %761 = zext i8 %760 to i32
  %762 = shl i32 %761, 23
  %763 = bitcast i32 %762 to float
  %764 = fmul float %763, %757
  %765 = extractelement <8 x float> %160, i64 7
  %766 = fmul float %765, %764
  %767 = call float @llvm.fabs.f32(float %764)
  %768 = fcmp olt float %767, +inf
  %769 = fcmp one float %764, 0.000000e+00
  %770 = and i1 %768, %769
  %771 = call i1 @llvm.expect.i1(i1 %770, i1 true)
  br i1 %771, label %772, label %773

772:                                              ; preds = %753
  br label %785

773:                                              ; preds = %753
  %774 = fpext float %765 to double
  %775 = fpext float %763 to double
  %776 = fpext float %757 to double
  %777 = fmul double %774, %775
  %778 = fmul double %777, %776
  %779 = fptrunc double %778 to float
  %780 = fcmp oeq float %765, 0.000000e+00
  %781 = call float @llvm.fabs.f32(float %757)
  %782 = fcmp olt float %781, +inf
  %783 = and i1 %780, %782
  %784 = select i1 %783, float 0.000000e+00, float %779
  br label %785

785:                                              ; preds = %772, %773
  %786 = phi float [ %784, %773 ], [ %766, %772 ]
  br label %787

787:                                              ; preds = %785
  %788 = mul i64 %58, 8
  %789 = add i64 %82, %788
  %790 = add i64 %89, %57
  %791 = mul i64 %789, %26
  %792 = add i64 %791, %790
  %793 = fptrunc float %548 to bfloat
  %794 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %795 = getelementptr inbounds nuw bfloat, ptr %794, i64 %792
  store bfloat %793, ptr %795, align 2
  %796 = mul i64 %58, 8
  %797 = add i64 %796, 1
  %798 = add i64 %82, %797
  %799 = add i64 %89, %57
  %800 = mul i64 %798, %26
  %801 = add i64 %800, %799
  %802 = fptrunc float %582 to bfloat
  %803 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %804 = getelementptr inbounds nuw bfloat, ptr %803, i64 %801
  store bfloat %802, ptr %804, align 2
  %805 = mul i64 %58, 8
  %806 = add i64 %805, 2
  %807 = add i64 %82, %806
  %808 = add i64 %89, %57
  %809 = mul i64 %807, %26
  %810 = add i64 %809, %808
  %811 = fptrunc float %616 to bfloat
  %812 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %813 = getelementptr inbounds nuw bfloat, ptr %812, i64 %810
  store bfloat %811, ptr %813, align 2
  %814 = mul i64 %58, 8
  %815 = add i64 %814, 3
  %816 = add i64 %82, %815
  %817 = add i64 %89, %57
  %818 = mul i64 %816, %26
  %819 = add i64 %818, %817
  %820 = fptrunc float %650 to bfloat
  %821 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %822 = getelementptr inbounds nuw bfloat, ptr %821, i64 %819
  store bfloat %820, ptr %822, align 2
  %823 = mul i64 %58, 8
  %824 = add i64 %823, 4
  %825 = add i64 %82, %824
  %826 = add i64 %89, %57
  %827 = mul i64 %825, %26
  %828 = add i64 %827, %826
  %829 = fptrunc float %684 to bfloat
  %830 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %831 = getelementptr inbounds nuw bfloat, ptr %830, i64 %828
  store bfloat %829, ptr %831, align 2
  %832 = mul i64 %58, 8
  %833 = add i64 %832, 5
  %834 = add i64 %82, %833
  %835 = add i64 %89, %57
  %836 = mul i64 %834, %26
  %837 = add i64 %836, %835
  %838 = fptrunc float %718 to bfloat
  %839 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %840 = getelementptr inbounds nuw bfloat, ptr %839, i64 %837
  store bfloat %838, ptr %840, align 2
  %841 = mul i64 %58, 8
  %842 = add i64 %841, 6
  %843 = add i64 %82, %842
  %844 = add i64 %89, %57
  %845 = mul i64 %843, %26
  %846 = add i64 %845, %844
  %847 = fptrunc float %752 to bfloat
  %848 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %849 = getelementptr inbounds nuw bfloat, ptr %848, i64 %846
  store bfloat %847, ptr %849, align 2
  %850 = mul i64 %58, 8
  %851 = add i64 %850, 7
  %852 = add i64 %82, %851
  %853 = add i64 %89, %57
  %854 = mul i64 %852, %26
  %855 = add i64 %854, %853
  %856 = fptrunc float %786 to bfloat
  %857 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %858 = getelementptr inbounds nuw bfloat, ptr %857, i64 %855
  store bfloat %856, ptr %858, align 2
  %859 = mul i64 %58, 8
  %860 = add i64 %84, %859
  %861 = add i64 %89, %57
  %862 = add i64 %860, 7
  %863 = icmp ult i64 %861, %26
  %864 = icmp ult i64 %862, %25
  %865 = and i1 %864, %863
  %866 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %867 = ptrtoint ptr %866 to i64
  %868 = mul i64 %860, 4
  %869 = add i64 %867, %868
  %870 = urem i64 %869, 16
  %871 = icmp eq i64 %870, 0
  %872 = and i1 %865, %871
  br i1 %872, label %873, label %882

873:                                              ; preds = %787
  %874 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %875 = getelementptr float, ptr %874, i64 %860
  %876 = load <4 x float>, ptr %875, align 16
  %877 = add i64 %860, 4
  %878 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %879 = getelementptr float, ptr %878, i64 %877
  %880 = load <4 x float>, ptr %879, align 16
  %881 = shufflevector <4 x float> %876, <4 x float> %880, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %954

882:                                              ; preds = %787
  %883 = mul i64 %58, 8
  %884 = add i64 %84, %883
  %885 = icmp slt i64 %884, %25
  %886 = select i1 %885, i64 %884, i64 0
  %887 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %888 = getelementptr inbounds nuw float, ptr %887, i64 %886
  %889 = load float, ptr %888, align 4
  %890 = insertelement <8 x float> zeroinitializer, float %889, i64 0
  %891 = mul i64 %58, 8
  %892 = add i64 %891, 1
  %893 = add i64 %84, %892
  %894 = icmp slt i64 %893, %25
  %895 = select i1 %894, i64 %893, i64 0
  %896 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %897 = getelementptr inbounds nuw float, ptr %896, i64 %895
  %898 = load float, ptr %897, align 4
  %899 = insertelement <8 x float> %890, float %898, i64 1
  %900 = mul i64 %58, 8
  %901 = add i64 %900, 2
  %902 = add i64 %84, %901
  %903 = icmp slt i64 %902, %25
  %904 = select i1 %903, i64 %902, i64 0
  %905 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %906 = getelementptr inbounds nuw float, ptr %905, i64 %904
  %907 = load float, ptr %906, align 4
  %908 = insertelement <8 x float> %899, float %907, i64 2
  %909 = mul i64 %58, 8
  %910 = add i64 %909, 3
  %911 = add i64 %84, %910
  %912 = icmp slt i64 %911, %25
  %913 = select i1 %912, i64 %911, i64 0
  %914 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %915 = getelementptr inbounds nuw float, ptr %914, i64 %913
  %916 = load float, ptr %915, align 4
  %917 = insertelement <8 x float> %908, float %916, i64 3
  %918 = mul i64 %58, 8
  %919 = add i64 %918, 4
  %920 = add i64 %84, %919
  %921 = icmp slt i64 %920, %25
  %922 = select i1 %921, i64 %920, i64 0
  %923 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %924 = getelementptr inbounds nuw float, ptr %923, i64 %922
  %925 = load float, ptr %924, align 4
  %926 = insertelement <8 x float> %917, float %925, i64 4
  %927 = mul i64 %58, 8
  %928 = add i64 %927, 5
  %929 = add i64 %84, %928
  %930 = icmp slt i64 %929, %25
  %931 = select i1 %930, i64 %929, i64 0
  %932 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %933 = getelementptr inbounds nuw float, ptr %932, i64 %931
  %934 = load float, ptr %933, align 4
  %935 = insertelement <8 x float> %926, float %934, i64 5
  %936 = mul i64 %58, 8
  %937 = add i64 %936, 6
  %938 = add i64 %84, %937
  %939 = icmp slt i64 %938, %25
  %940 = select i1 %939, i64 %938, i64 0
  %941 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %942 = getelementptr inbounds nuw float, ptr %941, i64 %940
  %943 = load float, ptr %942, align 4
  %944 = insertelement <8 x float> %935, float %943, i64 6
  %945 = mul i64 %58, 8
  %946 = add i64 %945, 7
  %947 = add i64 %84, %946
  %948 = icmp slt i64 %947, %25
  %949 = select i1 %948, i64 %947, i64 0
  %950 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %951 = getelementptr inbounds nuw float, ptr %950, i64 %949
  %952 = load float, ptr %951, align 4
  %953 = insertelement <8 x float> %944, float %952, i64 7
  br label %954

954:                                              ; preds = %873, %882
  %955 = phi <8 x float> [ %953, %882 ], [ %881, %873 ]
  br label %956

956:                                              ; preds = %954
  %957 = add i64 %89, %57
  %958 = icmp slt i64 %957, %26
  %959 = select i1 %958, i64 %957, i64 0
  %960 = extractelement <8 x float> %955, i64 0
  %961 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %962 = getelementptr inbounds nuw i8, ptr %961, i64 %959
  %963 = load i8, ptr %962, align 1
  %964 = zext i8 %963 to i32
  %965 = shl i32 %964, 23
  %966 = bitcast i32 %965 to float
  %967 = fmul float %966, %960
  %968 = extractelement <8 x float> %162, i64 0
  %969 = fmul float %968, %967
  %970 = call float @llvm.fabs.f32(float %967)
  %971 = fcmp olt float %970, +inf
  %972 = fcmp one float %967, 0.000000e+00
  %973 = and i1 %971, %972
  %974 = call i1 @llvm.expect.i1(i1 %973, i1 true)
  br i1 %974, label %975, label %976

975:                                              ; preds = %956
  br label %988

976:                                              ; preds = %956
  %977 = fpext float %968 to double
  %978 = fpext float %966 to double
  %979 = fpext float %960 to double
  %980 = fmul double %977, %978
  %981 = fmul double %980, %979
  %982 = fptrunc double %981 to float
  %983 = fcmp oeq float %968, 0.000000e+00
  %984 = call float @llvm.fabs.f32(float %960)
  %985 = fcmp olt float %984, +inf
  %986 = and i1 %983, %985
  %987 = select i1 %986, float 0.000000e+00, float %982
  br label %988

988:                                              ; preds = %975, %976
  %989 = phi float [ %987, %976 ], [ %969, %975 ]
  br label %990

990:                                              ; preds = %988
  %991 = add i64 %89, %57
  %992 = icmp slt i64 %991, %26
  %993 = select i1 %992, i64 %991, i64 0
  %994 = extractelement <8 x float> %955, i64 1
  %995 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %996 = getelementptr inbounds nuw i8, ptr %995, i64 %993
  %997 = load i8, ptr %996, align 1
  %998 = zext i8 %997 to i32
  %999 = shl i32 %998, 23
  %1000 = bitcast i32 %999 to float
  %1001 = fmul float %1000, %994
  %1002 = extractelement <8 x float> %162, i64 1
  %1003 = fmul float %1002, %1001
  %1004 = call float @llvm.fabs.f32(float %1001)
  %1005 = fcmp olt float %1004, +inf
  %1006 = fcmp one float %1001, 0.000000e+00
  %1007 = and i1 %1005, %1006
  %1008 = call i1 @llvm.expect.i1(i1 %1007, i1 true)
  br i1 %1008, label %1009, label %1010

1009:                                             ; preds = %990
  br label %1022

1010:                                             ; preds = %990
  %1011 = fpext float %1002 to double
  %1012 = fpext float %1000 to double
  %1013 = fpext float %994 to double
  %1014 = fmul double %1011, %1012
  %1015 = fmul double %1014, %1013
  %1016 = fptrunc double %1015 to float
  %1017 = fcmp oeq float %1002, 0.000000e+00
  %1018 = call float @llvm.fabs.f32(float %994)
  %1019 = fcmp olt float %1018, +inf
  %1020 = and i1 %1017, %1019
  %1021 = select i1 %1020, float 0.000000e+00, float %1016
  br label %1022

1022:                                             ; preds = %1009, %1010
  %1023 = phi float [ %1021, %1010 ], [ %1003, %1009 ]
  br label %1024

1024:                                             ; preds = %1022
  %1025 = add i64 %89, %57
  %1026 = icmp slt i64 %1025, %26
  %1027 = select i1 %1026, i64 %1025, i64 0
  %1028 = extractelement <8 x float> %955, i64 2
  %1029 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1030 = getelementptr inbounds nuw i8, ptr %1029, i64 %1027
  %1031 = load i8, ptr %1030, align 1
  %1032 = zext i8 %1031 to i32
  %1033 = shl i32 %1032, 23
  %1034 = bitcast i32 %1033 to float
  %1035 = fmul float %1034, %1028
  %1036 = extractelement <8 x float> %162, i64 2
  %1037 = fmul float %1036, %1035
  %1038 = call float @llvm.fabs.f32(float %1035)
  %1039 = fcmp olt float %1038, +inf
  %1040 = fcmp one float %1035, 0.000000e+00
  %1041 = and i1 %1039, %1040
  %1042 = call i1 @llvm.expect.i1(i1 %1041, i1 true)
  br i1 %1042, label %1043, label %1044

1043:                                             ; preds = %1024
  br label %1056

1044:                                             ; preds = %1024
  %1045 = fpext float %1036 to double
  %1046 = fpext float %1034 to double
  %1047 = fpext float %1028 to double
  %1048 = fmul double %1045, %1046
  %1049 = fmul double %1048, %1047
  %1050 = fptrunc double %1049 to float
  %1051 = fcmp oeq float %1036, 0.000000e+00
  %1052 = call float @llvm.fabs.f32(float %1028)
  %1053 = fcmp olt float %1052, +inf
  %1054 = and i1 %1051, %1053
  %1055 = select i1 %1054, float 0.000000e+00, float %1050
  br label %1056

1056:                                             ; preds = %1043, %1044
  %1057 = phi float [ %1055, %1044 ], [ %1037, %1043 ]
  br label %1058

1058:                                             ; preds = %1056
  %1059 = add i64 %89, %57
  %1060 = icmp slt i64 %1059, %26
  %1061 = select i1 %1060, i64 %1059, i64 0
  %1062 = extractelement <8 x float> %955, i64 3
  %1063 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1064 = getelementptr inbounds nuw i8, ptr %1063, i64 %1061
  %1065 = load i8, ptr %1064, align 1
  %1066 = zext i8 %1065 to i32
  %1067 = shl i32 %1066, 23
  %1068 = bitcast i32 %1067 to float
  %1069 = fmul float %1068, %1062
  %1070 = extractelement <8 x float> %162, i64 3
  %1071 = fmul float %1070, %1069
  %1072 = call float @llvm.fabs.f32(float %1069)
  %1073 = fcmp olt float %1072, +inf
  %1074 = fcmp one float %1069, 0.000000e+00
  %1075 = and i1 %1073, %1074
  %1076 = call i1 @llvm.expect.i1(i1 %1075, i1 true)
  br i1 %1076, label %1077, label %1078

1077:                                             ; preds = %1058
  br label %1090

1078:                                             ; preds = %1058
  %1079 = fpext float %1070 to double
  %1080 = fpext float %1068 to double
  %1081 = fpext float %1062 to double
  %1082 = fmul double %1079, %1080
  %1083 = fmul double %1082, %1081
  %1084 = fptrunc double %1083 to float
  %1085 = fcmp oeq float %1070, 0.000000e+00
  %1086 = call float @llvm.fabs.f32(float %1062)
  %1087 = fcmp olt float %1086, +inf
  %1088 = and i1 %1085, %1087
  %1089 = select i1 %1088, float 0.000000e+00, float %1084
  br label %1090

1090:                                             ; preds = %1077, %1078
  %1091 = phi float [ %1089, %1078 ], [ %1071, %1077 ]
  br label %1092

1092:                                             ; preds = %1090
  %1093 = add i64 %89, %57
  %1094 = icmp slt i64 %1093, %26
  %1095 = select i1 %1094, i64 %1093, i64 0
  %1096 = extractelement <8 x float> %955, i64 4
  %1097 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1098 = getelementptr inbounds nuw i8, ptr %1097, i64 %1095
  %1099 = load i8, ptr %1098, align 1
  %1100 = zext i8 %1099 to i32
  %1101 = shl i32 %1100, 23
  %1102 = bitcast i32 %1101 to float
  %1103 = fmul float %1102, %1096
  %1104 = extractelement <8 x float> %162, i64 4
  %1105 = fmul float %1104, %1103
  %1106 = call float @llvm.fabs.f32(float %1103)
  %1107 = fcmp olt float %1106, +inf
  %1108 = fcmp one float %1103, 0.000000e+00
  %1109 = and i1 %1107, %1108
  %1110 = call i1 @llvm.expect.i1(i1 %1109, i1 true)
  br i1 %1110, label %1111, label %1112

1111:                                             ; preds = %1092
  br label %1124

1112:                                             ; preds = %1092
  %1113 = fpext float %1104 to double
  %1114 = fpext float %1102 to double
  %1115 = fpext float %1096 to double
  %1116 = fmul double %1113, %1114
  %1117 = fmul double %1116, %1115
  %1118 = fptrunc double %1117 to float
  %1119 = fcmp oeq float %1104, 0.000000e+00
  %1120 = call float @llvm.fabs.f32(float %1096)
  %1121 = fcmp olt float %1120, +inf
  %1122 = and i1 %1119, %1121
  %1123 = select i1 %1122, float 0.000000e+00, float %1118
  br label %1124

1124:                                             ; preds = %1111, %1112
  %1125 = phi float [ %1123, %1112 ], [ %1105, %1111 ]
  br label %1126

1126:                                             ; preds = %1124
  %1127 = add i64 %89, %57
  %1128 = icmp slt i64 %1127, %26
  %1129 = select i1 %1128, i64 %1127, i64 0
  %1130 = extractelement <8 x float> %955, i64 5
  %1131 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1132 = getelementptr inbounds nuw i8, ptr %1131, i64 %1129
  %1133 = load i8, ptr %1132, align 1
  %1134 = zext i8 %1133 to i32
  %1135 = shl i32 %1134, 23
  %1136 = bitcast i32 %1135 to float
  %1137 = fmul float %1136, %1130
  %1138 = extractelement <8 x float> %162, i64 5
  %1139 = fmul float %1138, %1137
  %1140 = call float @llvm.fabs.f32(float %1137)
  %1141 = fcmp olt float %1140, +inf
  %1142 = fcmp one float %1137, 0.000000e+00
  %1143 = and i1 %1141, %1142
  %1144 = call i1 @llvm.expect.i1(i1 %1143, i1 true)
  br i1 %1144, label %1145, label %1146

1145:                                             ; preds = %1126
  br label %1158

1146:                                             ; preds = %1126
  %1147 = fpext float %1138 to double
  %1148 = fpext float %1136 to double
  %1149 = fpext float %1130 to double
  %1150 = fmul double %1147, %1148
  %1151 = fmul double %1150, %1149
  %1152 = fptrunc double %1151 to float
  %1153 = fcmp oeq float %1138, 0.000000e+00
  %1154 = call float @llvm.fabs.f32(float %1130)
  %1155 = fcmp olt float %1154, +inf
  %1156 = and i1 %1153, %1155
  %1157 = select i1 %1156, float 0.000000e+00, float %1152
  br label %1158

1158:                                             ; preds = %1145, %1146
  %1159 = phi float [ %1157, %1146 ], [ %1139, %1145 ]
  br label %1160

1160:                                             ; preds = %1158
  %1161 = add i64 %89, %57
  %1162 = icmp slt i64 %1161, %26
  %1163 = select i1 %1162, i64 %1161, i64 0
  %1164 = extractelement <8 x float> %955, i64 6
  %1165 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1166 = getelementptr inbounds nuw i8, ptr %1165, i64 %1163
  %1167 = load i8, ptr %1166, align 1
  %1168 = zext i8 %1167 to i32
  %1169 = shl i32 %1168, 23
  %1170 = bitcast i32 %1169 to float
  %1171 = fmul float %1170, %1164
  %1172 = extractelement <8 x float> %162, i64 6
  %1173 = fmul float %1172, %1171
  %1174 = call float @llvm.fabs.f32(float %1171)
  %1175 = fcmp olt float %1174, +inf
  %1176 = fcmp one float %1171, 0.000000e+00
  %1177 = and i1 %1175, %1176
  %1178 = call i1 @llvm.expect.i1(i1 %1177, i1 true)
  br i1 %1178, label %1179, label %1180

1179:                                             ; preds = %1160
  br label %1192

1180:                                             ; preds = %1160
  %1181 = fpext float %1172 to double
  %1182 = fpext float %1170 to double
  %1183 = fpext float %1164 to double
  %1184 = fmul double %1181, %1182
  %1185 = fmul double %1184, %1183
  %1186 = fptrunc double %1185 to float
  %1187 = fcmp oeq float %1172, 0.000000e+00
  %1188 = call float @llvm.fabs.f32(float %1164)
  %1189 = fcmp olt float %1188, +inf
  %1190 = and i1 %1187, %1189
  %1191 = select i1 %1190, float 0.000000e+00, float %1186
  br label %1192

1192:                                             ; preds = %1179, %1180
  %1193 = phi float [ %1191, %1180 ], [ %1173, %1179 ]
  br label %1194

1194:                                             ; preds = %1192
  %1195 = add i64 %89, %57
  %1196 = icmp slt i64 %1195, %26
  %1197 = select i1 %1196, i64 %1195, i64 0
  %1198 = extractelement <8 x float> %955, i64 7
  %1199 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1200 = getelementptr inbounds nuw i8, ptr %1199, i64 %1197
  %1201 = load i8, ptr %1200, align 1
  %1202 = zext i8 %1201 to i32
  %1203 = shl i32 %1202, 23
  %1204 = bitcast i32 %1203 to float
  %1205 = fmul float %1204, %1198
  %1206 = extractelement <8 x float> %162, i64 7
  %1207 = fmul float %1206, %1205
  %1208 = call float @llvm.fabs.f32(float %1205)
  %1209 = fcmp olt float %1208, +inf
  %1210 = fcmp one float %1205, 0.000000e+00
  %1211 = and i1 %1209, %1210
  %1212 = call i1 @llvm.expect.i1(i1 %1211, i1 true)
  br i1 %1212, label %1213, label %1214

1213:                                             ; preds = %1194
  br label %1226

1214:                                             ; preds = %1194
  %1215 = fpext float %1206 to double
  %1216 = fpext float %1204 to double
  %1217 = fpext float %1198 to double
  %1218 = fmul double %1215, %1216
  %1219 = fmul double %1218, %1217
  %1220 = fptrunc double %1219 to float
  %1221 = fcmp oeq float %1206, 0.000000e+00
  %1222 = call float @llvm.fabs.f32(float %1198)
  %1223 = fcmp olt float %1222, +inf
  %1224 = and i1 %1221, %1223
  %1225 = select i1 %1224, float 0.000000e+00, float %1220
  br label %1226

1226:                                             ; preds = %1213, %1214
  %1227 = phi float [ %1225, %1214 ], [ %1207, %1213 ]
  br label %1228

1228:                                             ; preds = %1226
  %1229 = mul i64 %58, 8
  %1230 = add i64 %84, %1229
  %1231 = add i64 %89, %57
  %1232 = mul i64 %1230, %26
  %1233 = add i64 %1232, %1231
  %1234 = fptrunc float %989 to bfloat
  %1235 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1236 = getelementptr inbounds nuw bfloat, ptr %1235, i64 %1233
  store bfloat %1234, ptr %1236, align 2
  %1237 = mul i64 %58, 8
  %1238 = add i64 %1237, 1
  %1239 = add i64 %84, %1238
  %1240 = add i64 %89, %57
  %1241 = mul i64 %1239, %26
  %1242 = add i64 %1241, %1240
  %1243 = fptrunc float %1023 to bfloat
  %1244 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1245 = getelementptr inbounds nuw bfloat, ptr %1244, i64 %1242
  store bfloat %1243, ptr %1245, align 2
  %1246 = mul i64 %58, 8
  %1247 = add i64 %1246, 2
  %1248 = add i64 %84, %1247
  %1249 = add i64 %89, %57
  %1250 = mul i64 %1248, %26
  %1251 = add i64 %1250, %1249
  %1252 = fptrunc float %1057 to bfloat
  %1253 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1254 = getelementptr inbounds nuw bfloat, ptr %1253, i64 %1251
  store bfloat %1252, ptr %1254, align 2
  %1255 = mul i64 %58, 8
  %1256 = add i64 %1255, 3
  %1257 = add i64 %84, %1256
  %1258 = add i64 %89, %57
  %1259 = mul i64 %1257, %26
  %1260 = add i64 %1259, %1258
  %1261 = fptrunc float %1091 to bfloat
  %1262 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1263 = getelementptr inbounds nuw bfloat, ptr %1262, i64 %1260
  store bfloat %1261, ptr %1263, align 2
  %1264 = mul i64 %58, 8
  %1265 = add i64 %1264, 4
  %1266 = add i64 %84, %1265
  %1267 = add i64 %89, %57
  %1268 = mul i64 %1266, %26
  %1269 = add i64 %1268, %1267
  %1270 = fptrunc float %1125 to bfloat
  %1271 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1272 = getelementptr inbounds nuw bfloat, ptr %1271, i64 %1269
  store bfloat %1270, ptr %1272, align 2
  %1273 = mul i64 %58, 8
  %1274 = add i64 %1273, 5
  %1275 = add i64 %84, %1274
  %1276 = add i64 %89, %57
  %1277 = mul i64 %1275, %26
  %1278 = add i64 %1277, %1276
  %1279 = fptrunc float %1159 to bfloat
  %1280 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1281 = getelementptr inbounds nuw bfloat, ptr %1280, i64 %1278
  store bfloat %1279, ptr %1281, align 2
  %1282 = mul i64 %58, 8
  %1283 = add i64 %1282, 6
  %1284 = add i64 %84, %1283
  %1285 = add i64 %89, %57
  %1286 = mul i64 %1284, %26
  %1287 = add i64 %1286, %1285
  %1288 = fptrunc float %1193 to bfloat
  %1289 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1290 = getelementptr inbounds nuw bfloat, ptr %1289, i64 %1287
  store bfloat %1288, ptr %1290, align 2
  %1291 = mul i64 %58, 8
  %1292 = add i64 %1291, 7
  %1293 = add i64 %84, %1292
  %1294 = add i64 %89, %57
  %1295 = mul i64 %1293, %26
  %1296 = add i64 %1295, %1294
  %1297 = fptrunc float %1227 to bfloat
  %1298 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1299 = getelementptr inbounds nuw bfloat, ptr %1298, i64 %1296
  store bfloat %1297, ptr %1299, align 2
  %1300 = mul i64 %58, 8
  %1301 = add i64 %86, %1300
  %1302 = add i64 %89, %57
  %1303 = add i64 %1301, 7
  %1304 = icmp ult i64 %1302, %26
  %1305 = icmp ult i64 %1303, %25
  %1306 = and i1 %1305, %1304
  %1307 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1308 = ptrtoint ptr %1307 to i64
  %1309 = mul i64 %1301, 4
  %1310 = add i64 %1308, %1309
  %1311 = urem i64 %1310, 16
  %1312 = icmp eq i64 %1311, 0
  %1313 = and i1 %1306, %1312
  br i1 %1313, label %1314, label %1323

1314:                                             ; preds = %1228
  %1315 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1316 = getelementptr float, ptr %1315, i64 %1301
  %1317 = load <4 x float>, ptr %1316, align 16
  %1318 = add i64 %1301, 4
  %1319 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1320 = getelementptr float, ptr %1319, i64 %1318
  %1321 = load <4 x float>, ptr %1320, align 16
  %1322 = shufflevector <4 x float> %1317, <4 x float> %1321, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1395

1323:                                             ; preds = %1228
  %1324 = mul i64 %58, 8
  %1325 = add i64 %86, %1324
  %1326 = icmp slt i64 %1325, %25
  %1327 = select i1 %1326, i64 %1325, i64 0
  %1328 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1329 = getelementptr inbounds nuw float, ptr %1328, i64 %1327
  %1330 = load float, ptr %1329, align 4
  %1331 = insertelement <8 x float> zeroinitializer, float %1330, i64 0
  %1332 = mul i64 %58, 8
  %1333 = add i64 %1332, 1
  %1334 = add i64 %86, %1333
  %1335 = icmp slt i64 %1334, %25
  %1336 = select i1 %1335, i64 %1334, i64 0
  %1337 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1338 = getelementptr inbounds nuw float, ptr %1337, i64 %1336
  %1339 = load float, ptr %1338, align 4
  %1340 = insertelement <8 x float> %1331, float %1339, i64 1
  %1341 = mul i64 %58, 8
  %1342 = add i64 %1341, 2
  %1343 = add i64 %86, %1342
  %1344 = icmp slt i64 %1343, %25
  %1345 = select i1 %1344, i64 %1343, i64 0
  %1346 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1347 = getelementptr inbounds nuw float, ptr %1346, i64 %1345
  %1348 = load float, ptr %1347, align 4
  %1349 = insertelement <8 x float> %1340, float %1348, i64 2
  %1350 = mul i64 %58, 8
  %1351 = add i64 %1350, 3
  %1352 = add i64 %86, %1351
  %1353 = icmp slt i64 %1352, %25
  %1354 = select i1 %1353, i64 %1352, i64 0
  %1355 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1356 = getelementptr inbounds nuw float, ptr %1355, i64 %1354
  %1357 = load float, ptr %1356, align 4
  %1358 = insertelement <8 x float> %1349, float %1357, i64 3
  %1359 = mul i64 %58, 8
  %1360 = add i64 %1359, 4
  %1361 = add i64 %86, %1360
  %1362 = icmp slt i64 %1361, %25
  %1363 = select i1 %1362, i64 %1361, i64 0
  %1364 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1365 = getelementptr inbounds nuw float, ptr %1364, i64 %1363
  %1366 = load float, ptr %1365, align 4
  %1367 = insertelement <8 x float> %1358, float %1366, i64 4
  %1368 = mul i64 %58, 8
  %1369 = add i64 %1368, 5
  %1370 = add i64 %86, %1369
  %1371 = icmp slt i64 %1370, %25
  %1372 = select i1 %1371, i64 %1370, i64 0
  %1373 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1374 = getelementptr inbounds nuw float, ptr %1373, i64 %1372
  %1375 = load float, ptr %1374, align 4
  %1376 = insertelement <8 x float> %1367, float %1375, i64 5
  %1377 = mul i64 %58, 8
  %1378 = add i64 %1377, 6
  %1379 = add i64 %86, %1378
  %1380 = icmp slt i64 %1379, %25
  %1381 = select i1 %1380, i64 %1379, i64 0
  %1382 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1383 = getelementptr inbounds nuw float, ptr %1382, i64 %1381
  %1384 = load float, ptr %1383, align 4
  %1385 = insertelement <8 x float> %1376, float %1384, i64 6
  %1386 = mul i64 %58, 8
  %1387 = add i64 %1386, 7
  %1388 = add i64 %86, %1387
  %1389 = icmp slt i64 %1388, %25
  %1390 = select i1 %1389, i64 %1388, i64 0
  %1391 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1392 = getelementptr inbounds nuw float, ptr %1391, i64 %1390
  %1393 = load float, ptr %1392, align 4
  %1394 = insertelement <8 x float> %1385, float %1393, i64 7
  br label %1395

1395:                                             ; preds = %1314, %1323
  %1396 = phi <8 x float> [ %1394, %1323 ], [ %1322, %1314 ]
  br label %1397

1397:                                             ; preds = %1395
  %1398 = add i64 %89, %57
  %1399 = icmp slt i64 %1398, %26
  %1400 = select i1 %1399, i64 %1398, i64 0
  %1401 = extractelement <8 x float> %1396, i64 0
  %1402 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1403 = getelementptr inbounds nuw i8, ptr %1402, i64 %1400
  %1404 = load i8, ptr %1403, align 1
  %1405 = zext i8 %1404 to i32
  %1406 = shl i32 %1405, 23
  %1407 = bitcast i32 %1406 to float
  %1408 = fmul float %1407, %1401
  %1409 = extractelement <8 x float> %164, i64 0
  %1410 = fmul float %1409, %1408
  %1411 = call float @llvm.fabs.f32(float %1408)
  %1412 = fcmp olt float %1411, +inf
  %1413 = fcmp one float %1408, 0.000000e+00
  %1414 = and i1 %1412, %1413
  %1415 = call i1 @llvm.expect.i1(i1 %1414, i1 true)
  br i1 %1415, label %1416, label %1417

1416:                                             ; preds = %1397
  br label %1429

1417:                                             ; preds = %1397
  %1418 = fpext float %1409 to double
  %1419 = fpext float %1407 to double
  %1420 = fpext float %1401 to double
  %1421 = fmul double %1418, %1419
  %1422 = fmul double %1421, %1420
  %1423 = fptrunc double %1422 to float
  %1424 = fcmp oeq float %1409, 0.000000e+00
  %1425 = call float @llvm.fabs.f32(float %1401)
  %1426 = fcmp olt float %1425, +inf
  %1427 = and i1 %1424, %1426
  %1428 = select i1 %1427, float 0.000000e+00, float %1423
  br label %1429

1429:                                             ; preds = %1416, %1417
  %1430 = phi float [ %1428, %1417 ], [ %1410, %1416 ]
  br label %1431

1431:                                             ; preds = %1429
  %1432 = add i64 %89, %57
  %1433 = icmp slt i64 %1432, %26
  %1434 = select i1 %1433, i64 %1432, i64 0
  %1435 = extractelement <8 x float> %1396, i64 1
  %1436 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1437 = getelementptr inbounds nuw i8, ptr %1436, i64 %1434
  %1438 = load i8, ptr %1437, align 1
  %1439 = zext i8 %1438 to i32
  %1440 = shl i32 %1439, 23
  %1441 = bitcast i32 %1440 to float
  %1442 = fmul float %1441, %1435
  %1443 = extractelement <8 x float> %164, i64 1
  %1444 = fmul float %1443, %1442
  %1445 = call float @llvm.fabs.f32(float %1442)
  %1446 = fcmp olt float %1445, +inf
  %1447 = fcmp one float %1442, 0.000000e+00
  %1448 = and i1 %1446, %1447
  %1449 = call i1 @llvm.expect.i1(i1 %1448, i1 true)
  br i1 %1449, label %1450, label %1451

1450:                                             ; preds = %1431
  br label %1463

1451:                                             ; preds = %1431
  %1452 = fpext float %1443 to double
  %1453 = fpext float %1441 to double
  %1454 = fpext float %1435 to double
  %1455 = fmul double %1452, %1453
  %1456 = fmul double %1455, %1454
  %1457 = fptrunc double %1456 to float
  %1458 = fcmp oeq float %1443, 0.000000e+00
  %1459 = call float @llvm.fabs.f32(float %1435)
  %1460 = fcmp olt float %1459, +inf
  %1461 = and i1 %1458, %1460
  %1462 = select i1 %1461, float 0.000000e+00, float %1457
  br label %1463

1463:                                             ; preds = %1450, %1451
  %1464 = phi float [ %1462, %1451 ], [ %1444, %1450 ]
  br label %1465

1465:                                             ; preds = %1463
  %1466 = add i64 %89, %57
  %1467 = icmp slt i64 %1466, %26
  %1468 = select i1 %1467, i64 %1466, i64 0
  %1469 = extractelement <8 x float> %1396, i64 2
  %1470 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1471 = getelementptr inbounds nuw i8, ptr %1470, i64 %1468
  %1472 = load i8, ptr %1471, align 1
  %1473 = zext i8 %1472 to i32
  %1474 = shl i32 %1473, 23
  %1475 = bitcast i32 %1474 to float
  %1476 = fmul float %1475, %1469
  %1477 = extractelement <8 x float> %164, i64 2
  %1478 = fmul float %1477, %1476
  %1479 = call float @llvm.fabs.f32(float %1476)
  %1480 = fcmp olt float %1479, +inf
  %1481 = fcmp one float %1476, 0.000000e+00
  %1482 = and i1 %1480, %1481
  %1483 = call i1 @llvm.expect.i1(i1 %1482, i1 true)
  br i1 %1483, label %1484, label %1485

1484:                                             ; preds = %1465
  br label %1497

1485:                                             ; preds = %1465
  %1486 = fpext float %1477 to double
  %1487 = fpext float %1475 to double
  %1488 = fpext float %1469 to double
  %1489 = fmul double %1486, %1487
  %1490 = fmul double %1489, %1488
  %1491 = fptrunc double %1490 to float
  %1492 = fcmp oeq float %1477, 0.000000e+00
  %1493 = call float @llvm.fabs.f32(float %1469)
  %1494 = fcmp olt float %1493, +inf
  %1495 = and i1 %1492, %1494
  %1496 = select i1 %1495, float 0.000000e+00, float %1491
  br label %1497

1497:                                             ; preds = %1484, %1485
  %1498 = phi float [ %1496, %1485 ], [ %1478, %1484 ]
  br label %1499

1499:                                             ; preds = %1497
  %1500 = add i64 %89, %57
  %1501 = icmp slt i64 %1500, %26
  %1502 = select i1 %1501, i64 %1500, i64 0
  %1503 = extractelement <8 x float> %1396, i64 3
  %1504 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1505 = getelementptr inbounds nuw i8, ptr %1504, i64 %1502
  %1506 = load i8, ptr %1505, align 1
  %1507 = zext i8 %1506 to i32
  %1508 = shl i32 %1507, 23
  %1509 = bitcast i32 %1508 to float
  %1510 = fmul float %1509, %1503
  %1511 = extractelement <8 x float> %164, i64 3
  %1512 = fmul float %1511, %1510
  %1513 = call float @llvm.fabs.f32(float %1510)
  %1514 = fcmp olt float %1513, +inf
  %1515 = fcmp one float %1510, 0.000000e+00
  %1516 = and i1 %1514, %1515
  %1517 = call i1 @llvm.expect.i1(i1 %1516, i1 true)
  br i1 %1517, label %1518, label %1519

1518:                                             ; preds = %1499
  br label %1531

1519:                                             ; preds = %1499
  %1520 = fpext float %1511 to double
  %1521 = fpext float %1509 to double
  %1522 = fpext float %1503 to double
  %1523 = fmul double %1520, %1521
  %1524 = fmul double %1523, %1522
  %1525 = fptrunc double %1524 to float
  %1526 = fcmp oeq float %1511, 0.000000e+00
  %1527 = call float @llvm.fabs.f32(float %1503)
  %1528 = fcmp olt float %1527, +inf
  %1529 = and i1 %1526, %1528
  %1530 = select i1 %1529, float 0.000000e+00, float %1525
  br label %1531

1531:                                             ; preds = %1518, %1519
  %1532 = phi float [ %1530, %1519 ], [ %1512, %1518 ]
  br label %1533

1533:                                             ; preds = %1531
  %1534 = add i64 %89, %57
  %1535 = icmp slt i64 %1534, %26
  %1536 = select i1 %1535, i64 %1534, i64 0
  %1537 = extractelement <8 x float> %1396, i64 4
  %1538 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1539 = getelementptr inbounds nuw i8, ptr %1538, i64 %1536
  %1540 = load i8, ptr %1539, align 1
  %1541 = zext i8 %1540 to i32
  %1542 = shl i32 %1541, 23
  %1543 = bitcast i32 %1542 to float
  %1544 = fmul float %1543, %1537
  %1545 = extractelement <8 x float> %164, i64 4
  %1546 = fmul float %1545, %1544
  %1547 = call float @llvm.fabs.f32(float %1544)
  %1548 = fcmp olt float %1547, +inf
  %1549 = fcmp one float %1544, 0.000000e+00
  %1550 = and i1 %1548, %1549
  %1551 = call i1 @llvm.expect.i1(i1 %1550, i1 true)
  br i1 %1551, label %1552, label %1553

1552:                                             ; preds = %1533
  br label %1565

1553:                                             ; preds = %1533
  %1554 = fpext float %1545 to double
  %1555 = fpext float %1543 to double
  %1556 = fpext float %1537 to double
  %1557 = fmul double %1554, %1555
  %1558 = fmul double %1557, %1556
  %1559 = fptrunc double %1558 to float
  %1560 = fcmp oeq float %1545, 0.000000e+00
  %1561 = call float @llvm.fabs.f32(float %1537)
  %1562 = fcmp olt float %1561, +inf
  %1563 = and i1 %1560, %1562
  %1564 = select i1 %1563, float 0.000000e+00, float %1559
  br label %1565

1565:                                             ; preds = %1552, %1553
  %1566 = phi float [ %1564, %1553 ], [ %1546, %1552 ]
  br label %1567

1567:                                             ; preds = %1565
  %1568 = add i64 %89, %57
  %1569 = icmp slt i64 %1568, %26
  %1570 = select i1 %1569, i64 %1568, i64 0
  %1571 = extractelement <8 x float> %1396, i64 5
  %1572 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1573 = getelementptr inbounds nuw i8, ptr %1572, i64 %1570
  %1574 = load i8, ptr %1573, align 1
  %1575 = zext i8 %1574 to i32
  %1576 = shl i32 %1575, 23
  %1577 = bitcast i32 %1576 to float
  %1578 = fmul float %1577, %1571
  %1579 = extractelement <8 x float> %164, i64 5
  %1580 = fmul float %1579, %1578
  %1581 = call float @llvm.fabs.f32(float %1578)
  %1582 = fcmp olt float %1581, +inf
  %1583 = fcmp one float %1578, 0.000000e+00
  %1584 = and i1 %1582, %1583
  %1585 = call i1 @llvm.expect.i1(i1 %1584, i1 true)
  br i1 %1585, label %1586, label %1587

1586:                                             ; preds = %1567
  br label %1599

1587:                                             ; preds = %1567
  %1588 = fpext float %1579 to double
  %1589 = fpext float %1577 to double
  %1590 = fpext float %1571 to double
  %1591 = fmul double %1588, %1589
  %1592 = fmul double %1591, %1590
  %1593 = fptrunc double %1592 to float
  %1594 = fcmp oeq float %1579, 0.000000e+00
  %1595 = call float @llvm.fabs.f32(float %1571)
  %1596 = fcmp olt float %1595, +inf
  %1597 = and i1 %1594, %1596
  %1598 = select i1 %1597, float 0.000000e+00, float %1593
  br label %1599

1599:                                             ; preds = %1586, %1587
  %1600 = phi float [ %1598, %1587 ], [ %1580, %1586 ]
  br label %1601

1601:                                             ; preds = %1599
  %1602 = add i64 %89, %57
  %1603 = icmp slt i64 %1602, %26
  %1604 = select i1 %1603, i64 %1602, i64 0
  %1605 = extractelement <8 x float> %1396, i64 6
  %1606 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1607 = getelementptr inbounds nuw i8, ptr %1606, i64 %1604
  %1608 = load i8, ptr %1607, align 1
  %1609 = zext i8 %1608 to i32
  %1610 = shl i32 %1609, 23
  %1611 = bitcast i32 %1610 to float
  %1612 = fmul float %1611, %1605
  %1613 = extractelement <8 x float> %164, i64 6
  %1614 = fmul float %1613, %1612
  %1615 = call float @llvm.fabs.f32(float %1612)
  %1616 = fcmp olt float %1615, +inf
  %1617 = fcmp one float %1612, 0.000000e+00
  %1618 = and i1 %1616, %1617
  %1619 = call i1 @llvm.expect.i1(i1 %1618, i1 true)
  br i1 %1619, label %1620, label %1621

1620:                                             ; preds = %1601
  br label %1633

1621:                                             ; preds = %1601
  %1622 = fpext float %1613 to double
  %1623 = fpext float %1611 to double
  %1624 = fpext float %1605 to double
  %1625 = fmul double %1622, %1623
  %1626 = fmul double %1625, %1624
  %1627 = fptrunc double %1626 to float
  %1628 = fcmp oeq float %1613, 0.000000e+00
  %1629 = call float @llvm.fabs.f32(float %1605)
  %1630 = fcmp olt float %1629, +inf
  %1631 = and i1 %1628, %1630
  %1632 = select i1 %1631, float 0.000000e+00, float %1627
  br label %1633

1633:                                             ; preds = %1620, %1621
  %1634 = phi float [ %1632, %1621 ], [ %1614, %1620 ]
  br label %1635

1635:                                             ; preds = %1633
  %1636 = add i64 %89, %57
  %1637 = icmp slt i64 %1636, %26
  %1638 = select i1 %1637, i64 %1636, i64 0
  %1639 = extractelement <8 x float> %1396, i64 7
  %1640 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1641 = getelementptr inbounds nuw i8, ptr %1640, i64 %1638
  %1642 = load i8, ptr %1641, align 1
  %1643 = zext i8 %1642 to i32
  %1644 = shl i32 %1643, 23
  %1645 = bitcast i32 %1644 to float
  %1646 = fmul float %1645, %1639
  %1647 = extractelement <8 x float> %164, i64 7
  %1648 = fmul float %1647, %1646
  %1649 = call float @llvm.fabs.f32(float %1646)
  %1650 = fcmp olt float %1649, +inf
  %1651 = fcmp one float %1646, 0.000000e+00
  %1652 = and i1 %1650, %1651
  %1653 = call i1 @llvm.expect.i1(i1 %1652, i1 true)
  br i1 %1653, label %1654, label %1655

1654:                                             ; preds = %1635
  br label %1667

1655:                                             ; preds = %1635
  %1656 = fpext float %1647 to double
  %1657 = fpext float %1645 to double
  %1658 = fpext float %1639 to double
  %1659 = fmul double %1656, %1657
  %1660 = fmul double %1659, %1658
  %1661 = fptrunc double %1660 to float
  %1662 = fcmp oeq float %1647, 0.000000e+00
  %1663 = call float @llvm.fabs.f32(float %1639)
  %1664 = fcmp olt float %1663, +inf
  %1665 = and i1 %1662, %1664
  %1666 = select i1 %1665, float 0.000000e+00, float %1661
  br label %1667

1667:                                             ; preds = %1654, %1655
  %1668 = phi float [ %1666, %1655 ], [ %1648, %1654 ]
  br label %1669

1669:                                             ; preds = %1667
  %1670 = mul i64 %58, 8
  %1671 = add i64 %86, %1670
  %1672 = add i64 %89, %57
  %1673 = mul i64 %1671, %26
  %1674 = add i64 %1673, %1672
  %1675 = fptrunc float %1430 to bfloat
  %1676 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1677 = getelementptr inbounds nuw bfloat, ptr %1676, i64 %1674
  store bfloat %1675, ptr %1677, align 2
  %1678 = mul i64 %58, 8
  %1679 = add i64 %1678, 1
  %1680 = add i64 %86, %1679
  %1681 = add i64 %89, %57
  %1682 = mul i64 %1680, %26
  %1683 = add i64 %1682, %1681
  %1684 = fptrunc float %1464 to bfloat
  %1685 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1686 = getelementptr inbounds nuw bfloat, ptr %1685, i64 %1683
  store bfloat %1684, ptr %1686, align 2
  %1687 = mul i64 %58, 8
  %1688 = add i64 %1687, 2
  %1689 = add i64 %86, %1688
  %1690 = add i64 %89, %57
  %1691 = mul i64 %1689, %26
  %1692 = add i64 %1691, %1690
  %1693 = fptrunc float %1498 to bfloat
  %1694 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1695 = getelementptr inbounds nuw bfloat, ptr %1694, i64 %1692
  store bfloat %1693, ptr %1695, align 2
  %1696 = mul i64 %58, 8
  %1697 = add i64 %1696, 3
  %1698 = add i64 %86, %1697
  %1699 = add i64 %89, %57
  %1700 = mul i64 %1698, %26
  %1701 = add i64 %1700, %1699
  %1702 = fptrunc float %1532 to bfloat
  %1703 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1704 = getelementptr inbounds nuw bfloat, ptr %1703, i64 %1701
  store bfloat %1702, ptr %1704, align 2
  %1705 = mul i64 %58, 8
  %1706 = add i64 %1705, 4
  %1707 = add i64 %86, %1706
  %1708 = add i64 %89, %57
  %1709 = mul i64 %1707, %26
  %1710 = add i64 %1709, %1708
  %1711 = fptrunc float %1566 to bfloat
  %1712 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1713 = getelementptr inbounds nuw bfloat, ptr %1712, i64 %1710
  store bfloat %1711, ptr %1713, align 2
  %1714 = mul i64 %58, 8
  %1715 = add i64 %1714, 5
  %1716 = add i64 %86, %1715
  %1717 = add i64 %89, %57
  %1718 = mul i64 %1716, %26
  %1719 = add i64 %1718, %1717
  %1720 = fptrunc float %1600 to bfloat
  %1721 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1722 = getelementptr inbounds nuw bfloat, ptr %1721, i64 %1719
  store bfloat %1720, ptr %1722, align 2
  %1723 = mul i64 %58, 8
  %1724 = add i64 %1723, 6
  %1725 = add i64 %86, %1724
  %1726 = add i64 %89, %57
  %1727 = mul i64 %1725, %26
  %1728 = add i64 %1727, %1726
  %1729 = fptrunc float %1634 to bfloat
  %1730 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1731 = getelementptr inbounds nuw bfloat, ptr %1730, i64 %1728
  store bfloat %1729, ptr %1731, align 2
  %1732 = mul i64 %58, 8
  %1733 = add i64 %1732, 7
  %1734 = add i64 %86, %1733
  %1735 = add i64 %89, %57
  %1736 = mul i64 %1734, %26
  %1737 = add i64 %1736, %1735
  %1738 = fptrunc float %1668 to bfloat
  %1739 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1740 = getelementptr inbounds nuw bfloat, ptr %1739, i64 %1737
  store bfloat %1738, ptr %1740, align 2
  %1741 = mul i64 %58, 8
  %1742 = add i64 %88, %1741
  %1743 = add i64 %89, %57
  %1744 = add i64 %1742, 7
  %1745 = icmp ult i64 %1743, %26
  %1746 = icmp ult i64 %1744, %25
  %1747 = and i1 %1746, %1745
  %1748 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1749 = ptrtoint ptr %1748 to i64
  %1750 = mul i64 %1742, 4
  %1751 = add i64 %1749, %1750
  %1752 = urem i64 %1751, 16
  %1753 = icmp eq i64 %1752, 0
  %1754 = and i1 %1747, %1753
  br i1 %1754, label %1755, label %1764

1755:                                             ; preds = %1669
  %1756 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1757 = getelementptr float, ptr %1756, i64 %1742
  %1758 = load <4 x float>, ptr %1757, align 16
  %1759 = add i64 %1742, 4
  %1760 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1761 = getelementptr float, ptr %1760, i64 %1759
  %1762 = load <4 x float>, ptr %1761, align 16
  %1763 = shufflevector <4 x float> %1758, <4 x float> %1762, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1836

1764:                                             ; preds = %1669
  %1765 = mul i64 %58, 8
  %1766 = add i64 %88, %1765
  %1767 = icmp slt i64 %1766, %25
  %1768 = select i1 %1767, i64 %1766, i64 0
  %1769 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1770 = getelementptr inbounds nuw float, ptr %1769, i64 %1768
  %1771 = load float, ptr %1770, align 4
  %1772 = insertelement <8 x float> zeroinitializer, float %1771, i64 0
  %1773 = mul i64 %58, 8
  %1774 = add i64 %1773, 1
  %1775 = add i64 %88, %1774
  %1776 = icmp slt i64 %1775, %25
  %1777 = select i1 %1776, i64 %1775, i64 0
  %1778 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1779 = getelementptr inbounds nuw float, ptr %1778, i64 %1777
  %1780 = load float, ptr %1779, align 4
  %1781 = insertelement <8 x float> %1772, float %1780, i64 1
  %1782 = mul i64 %58, 8
  %1783 = add i64 %1782, 2
  %1784 = add i64 %88, %1783
  %1785 = icmp slt i64 %1784, %25
  %1786 = select i1 %1785, i64 %1784, i64 0
  %1787 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1788 = getelementptr inbounds nuw float, ptr %1787, i64 %1786
  %1789 = load float, ptr %1788, align 4
  %1790 = insertelement <8 x float> %1781, float %1789, i64 2
  %1791 = mul i64 %58, 8
  %1792 = add i64 %1791, 3
  %1793 = add i64 %88, %1792
  %1794 = icmp slt i64 %1793, %25
  %1795 = select i1 %1794, i64 %1793, i64 0
  %1796 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1797 = getelementptr inbounds nuw float, ptr %1796, i64 %1795
  %1798 = load float, ptr %1797, align 4
  %1799 = insertelement <8 x float> %1790, float %1798, i64 3
  %1800 = mul i64 %58, 8
  %1801 = add i64 %1800, 4
  %1802 = add i64 %88, %1801
  %1803 = icmp slt i64 %1802, %25
  %1804 = select i1 %1803, i64 %1802, i64 0
  %1805 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1806 = getelementptr inbounds nuw float, ptr %1805, i64 %1804
  %1807 = load float, ptr %1806, align 4
  %1808 = insertelement <8 x float> %1799, float %1807, i64 4
  %1809 = mul i64 %58, 8
  %1810 = add i64 %1809, 5
  %1811 = add i64 %88, %1810
  %1812 = icmp slt i64 %1811, %25
  %1813 = select i1 %1812, i64 %1811, i64 0
  %1814 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1815 = getelementptr inbounds nuw float, ptr %1814, i64 %1813
  %1816 = load float, ptr %1815, align 4
  %1817 = insertelement <8 x float> %1808, float %1816, i64 5
  %1818 = mul i64 %58, 8
  %1819 = add i64 %1818, 6
  %1820 = add i64 %88, %1819
  %1821 = icmp slt i64 %1820, %25
  %1822 = select i1 %1821, i64 %1820, i64 0
  %1823 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1824 = getelementptr inbounds nuw float, ptr %1823, i64 %1822
  %1825 = load float, ptr %1824, align 4
  %1826 = insertelement <8 x float> %1817, float %1825, i64 6
  %1827 = mul i64 %58, 8
  %1828 = add i64 %1827, 7
  %1829 = add i64 %88, %1828
  %1830 = icmp slt i64 %1829, %25
  %1831 = select i1 %1830, i64 %1829, i64 0
  %1832 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1833 = getelementptr inbounds nuw float, ptr %1832, i64 %1831
  %1834 = load float, ptr %1833, align 4
  %1835 = insertelement <8 x float> %1826, float %1834, i64 7
  br label %1836

1836:                                             ; preds = %1755, %1764
  %1837 = phi <8 x float> [ %1835, %1764 ], [ %1763, %1755 ]
  br label %1838

1838:                                             ; preds = %1836
  %1839 = add i64 %89, %57
  %1840 = icmp slt i64 %1839, %26
  %1841 = select i1 %1840, i64 %1839, i64 0
  %1842 = extractelement <8 x float> %1837, i64 0
  %1843 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1844 = getelementptr inbounds nuw i8, ptr %1843, i64 %1841
  %1845 = load i8, ptr %1844, align 1
  %1846 = zext i8 %1845 to i32
  %1847 = shl i32 %1846, 23
  %1848 = bitcast i32 %1847 to float
  %1849 = fmul float %1848, %1842
  %1850 = extractelement <8 x float> %166, i64 0
  %1851 = fmul float %1850, %1849
  %1852 = call float @llvm.fabs.f32(float %1849)
  %1853 = fcmp olt float %1852, +inf
  %1854 = fcmp one float %1849, 0.000000e+00
  %1855 = and i1 %1853, %1854
  %1856 = call i1 @llvm.expect.i1(i1 %1855, i1 true)
  br i1 %1856, label %1857, label %1858

1857:                                             ; preds = %1838
  br label %1870

1858:                                             ; preds = %1838
  %1859 = fpext float %1850 to double
  %1860 = fpext float %1848 to double
  %1861 = fpext float %1842 to double
  %1862 = fmul double %1859, %1860
  %1863 = fmul double %1862, %1861
  %1864 = fptrunc double %1863 to float
  %1865 = fcmp oeq float %1850, 0.000000e+00
  %1866 = call float @llvm.fabs.f32(float %1842)
  %1867 = fcmp olt float %1866, +inf
  %1868 = and i1 %1865, %1867
  %1869 = select i1 %1868, float 0.000000e+00, float %1864
  br label %1870

1870:                                             ; preds = %1857, %1858
  %1871 = phi float [ %1869, %1858 ], [ %1851, %1857 ]
  br label %1872

1872:                                             ; preds = %1870
  %1873 = add i64 %89, %57
  %1874 = icmp slt i64 %1873, %26
  %1875 = select i1 %1874, i64 %1873, i64 0
  %1876 = extractelement <8 x float> %1837, i64 1
  %1877 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1878 = getelementptr inbounds nuw i8, ptr %1877, i64 %1875
  %1879 = load i8, ptr %1878, align 1
  %1880 = zext i8 %1879 to i32
  %1881 = shl i32 %1880, 23
  %1882 = bitcast i32 %1881 to float
  %1883 = fmul float %1882, %1876
  %1884 = extractelement <8 x float> %166, i64 1
  %1885 = fmul float %1884, %1883
  %1886 = call float @llvm.fabs.f32(float %1883)
  %1887 = fcmp olt float %1886, +inf
  %1888 = fcmp one float %1883, 0.000000e+00
  %1889 = and i1 %1887, %1888
  %1890 = call i1 @llvm.expect.i1(i1 %1889, i1 true)
  br i1 %1890, label %1891, label %1892

1891:                                             ; preds = %1872
  br label %1904

1892:                                             ; preds = %1872
  %1893 = fpext float %1884 to double
  %1894 = fpext float %1882 to double
  %1895 = fpext float %1876 to double
  %1896 = fmul double %1893, %1894
  %1897 = fmul double %1896, %1895
  %1898 = fptrunc double %1897 to float
  %1899 = fcmp oeq float %1884, 0.000000e+00
  %1900 = call float @llvm.fabs.f32(float %1876)
  %1901 = fcmp olt float %1900, +inf
  %1902 = and i1 %1899, %1901
  %1903 = select i1 %1902, float 0.000000e+00, float %1898
  br label %1904

1904:                                             ; preds = %1891, %1892
  %1905 = phi float [ %1903, %1892 ], [ %1885, %1891 ]
  br label %1906

1906:                                             ; preds = %1904
  %1907 = add i64 %89, %57
  %1908 = icmp slt i64 %1907, %26
  %1909 = select i1 %1908, i64 %1907, i64 0
  %1910 = extractelement <8 x float> %1837, i64 2
  %1911 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1912 = getelementptr inbounds nuw i8, ptr %1911, i64 %1909
  %1913 = load i8, ptr %1912, align 1
  %1914 = zext i8 %1913 to i32
  %1915 = shl i32 %1914, 23
  %1916 = bitcast i32 %1915 to float
  %1917 = fmul float %1916, %1910
  %1918 = extractelement <8 x float> %166, i64 2
  %1919 = fmul float %1918, %1917
  %1920 = call float @llvm.fabs.f32(float %1917)
  %1921 = fcmp olt float %1920, +inf
  %1922 = fcmp one float %1917, 0.000000e+00
  %1923 = and i1 %1921, %1922
  %1924 = call i1 @llvm.expect.i1(i1 %1923, i1 true)
  br i1 %1924, label %1925, label %1926

1925:                                             ; preds = %1906
  br label %1938

1926:                                             ; preds = %1906
  %1927 = fpext float %1918 to double
  %1928 = fpext float %1916 to double
  %1929 = fpext float %1910 to double
  %1930 = fmul double %1927, %1928
  %1931 = fmul double %1930, %1929
  %1932 = fptrunc double %1931 to float
  %1933 = fcmp oeq float %1918, 0.000000e+00
  %1934 = call float @llvm.fabs.f32(float %1910)
  %1935 = fcmp olt float %1934, +inf
  %1936 = and i1 %1933, %1935
  %1937 = select i1 %1936, float 0.000000e+00, float %1932
  br label %1938

1938:                                             ; preds = %1925, %1926
  %1939 = phi float [ %1937, %1926 ], [ %1919, %1925 ]
  br label %1940

1940:                                             ; preds = %1938
  %1941 = add i64 %89, %57
  %1942 = icmp slt i64 %1941, %26
  %1943 = select i1 %1942, i64 %1941, i64 0
  %1944 = extractelement <8 x float> %1837, i64 3
  %1945 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1946 = getelementptr inbounds nuw i8, ptr %1945, i64 %1943
  %1947 = load i8, ptr %1946, align 1
  %1948 = zext i8 %1947 to i32
  %1949 = shl i32 %1948, 23
  %1950 = bitcast i32 %1949 to float
  %1951 = fmul float %1950, %1944
  %1952 = extractelement <8 x float> %166, i64 3
  %1953 = fmul float %1952, %1951
  %1954 = call float @llvm.fabs.f32(float %1951)
  %1955 = fcmp olt float %1954, +inf
  %1956 = fcmp one float %1951, 0.000000e+00
  %1957 = and i1 %1955, %1956
  %1958 = call i1 @llvm.expect.i1(i1 %1957, i1 true)
  br i1 %1958, label %1959, label %1960

1959:                                             ; preds = %1940
  br label %1972

1960:                                             ; preds = %1940
  %1961 = fpext float %1952 to double
  %1962 = fpext float %1950 to double
  %1963 = fpext float %1944 to double
  %1964 = fmul double %1961, %1962
  %1965 = fmul double %1964, %1963
  %1966 = fptrunc double %1965 to float
  %1967 = fcmp oeq float %1952, 0.000000e+00
  %1968 = call float @llvm.fabs.f32(float %1944)
  %1969 = fcmp olt float %1968, +inf
  %1970 = and i1 %1967, %1969
  %1971 = select i1 %1970, float 0.000000e+00, float %1966
  br label %1972

1972:                                             ; preds = %1959, %1960
  %1973 = phi float [ %1971, %1960 ], [ %1953, %1959 ]
  br label %1974

1974:                                             ; preds = %1972
  %1975 = add i64 %89, %57
  %1976 = icmp slt i64 %1975, %26
  %1977 = select i1 %1976, i64 %1975, i64 0
  %1978 = extractelement <8 x float> %1837, i64 4
  %1979 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1980 = getelementptr inbounds nuw i8, ptr %1979, i64 %1977
  %1981 = load i8, ptr %1980, align 1
  %1982 = zext i8 %1981 to i32
  %1983 = shl i32 %1982, 23
  %1984 = bitcast i32 %1983 to float
  %1985 = fmul float %1984, %1978
  %1986 = extractelement <8 x float> %166, i64 4
  %1987 = fmul float %1986, %1985
  %1988 = call float @llvm.fabs.f32(float %1985)
  %1989 = fcmp olt float %1988, +inf
  %1990 = fcmp one float %1985, 0.000000e+00
  %1991 = and i1 %1989, %1990
  %1992 = call i1 @llvm.expect.i1(i1 %1991, i1 true)
  br i1 %1992, label %1993, label %1994

1993:                                             ; preds = %1974
  br label %2006

1994:                                             ; preds = %1974
  %1995 = fpext float %1986 to double
  %1996 = fpext float %1984 to double
  %1997 = fpext float %1978 to double
  %1998 = fmul double %1995, %1996
  %1999 = fmul double %1998, %1997
  %2000 = fptrunc double %1999 to float
  %2001 = fcmp oeq float %1986, 0.000000e+00
  %2002 = call float @llvm.fabs.f32(float %1978)
  %2003 = fcmp olt float %2002, +inf
  %2004 = and i1 %2001, %2003
  %2005 = select i1 %2004, float 0.000000e+00, float %2000
  br label %2006

2006:                                             ; preds = %1993, %1994
  %2007 = phi float [ %2005, %1994 ], [ %1987, %1993 ]
  br label %2008

2008:                                             ; preds = %2006
  %2009 = add i64 %89, %57
  %2010 = icmp slt i64 %2009, %26
  %2011 = select i1 %2010, i64 %2009, i64 0
  %2012 = extractelement <8 x float> %1837, i64 5
  %2013 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2014 = getelementptr inbounds nuw i8, ptr %2013, i64 %2011
  %2015 = load i8, ptr %2014, align 1
  %2016 = zext i8 %2015 to i32
  %2017 = shl i32 %2016, 23
  %2018 = bitcast i32 %2017 to float
  %2019 = fmul float %2018, %2012
  %2020 = extractelement <8 x float> %166, i64 5
  %2021 = fmul float %2020, %2019
  %2022 = call float @llvm.fabs.f32(float %2019)
  %2023 = fcmp olt float %2022, +inf
  %2024 = fcmp one float %2019, 0.000000e+00
  %2025 = and i1 %2023, %2024
  %2026 = call i1 @llvm.expect.i1(i1 %2025, i1 true)
  br i1 %2026, label %2027, label %2028

2027:                                             ; preds = %2008
  br label %2040

2028:                                             ; preds = %2008
  %2029 = fpext float %2020 to double
  %2030 = fpext float %2018 to double
  %2031 = fpext float %2012 to double
  %2032 = fmul double %2029, %2030
  %2033 = fmul double %2032, %2031
  %2034 = fptrunc double %2033 to float
  %2035 = fcmp oeq float %2020, 0.000000e+00
  %2036 = call float @llvm.fabs.f32(float %2012)
  %2037 = fcmp olt float %2036, +inf
  %2038 = and i1 %2035, %2037
  %2039 = select i1 %2038, float 0.000000e+00, float %2034
  br label %2040

2040:                                             ; preds = %2027, %2028
  %2041 = phi float [ %2039, %2028 ], [ %2021, %2027 ]
  br label %2042

2042:                                             ; preds = %2040
  %2043 = add i64 %89, %57
  %2044 = icmp slt i64 %2043, %26
  %2045 = select i1 %2044, i64 %2043, i64 0
  %2046 = extractelement <8 x float> %1837, i64 6
  %2047 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2048 = getelementptr inbounds nuw i8, ptr %2047, i64 %2045
  %2049 = load i8, ptr %2048, align 1
  %2050 = zext i8 %2049 to i32
  %2051 = shl i32 %2050, 23
  %2052 = bitcast i32 %2051 to float
  %2053 = fmul float %2052, %2046
  %2054 = extractelement <8 x float> %166, i64 6
  %2055 = fmul float %2054, %2053
  %2056 = call float @llvm.fabs.f32(float %2053)
  %2057 = fcmp olt float %2056, +inf
  %2058 = fcmp one float %2053, 0.000000e+00
  %2059 = and i1 %2057, %2058
  %2060 = call i1 @llvm.expect.i1(i1 %2059, i1 true)
  br i1 %2060, label %2061, label %2062

2061:                                             ; preds = %2042
  br label %2074

2062:                                             ; preds = %2042
  %2063 = fpext float %2054 to double
  %2064 = fpext float %2052 to double
  %2065 = fpext float %2046 to double
  %2066 = fmul double %2063, %2064
  %2067 = fmul double %2066, %2065
  %2068 = fptrunc double %2067 to float
  %2069 = fcmp oeq float %2054, 0.000000e+00
  %2070 = call float @llvm.fabs.f32(float %2046)
  %2071 = fcmp olt float %2070, +inf
  %2072 = and i1 %2069, %2071
  %2073 = select i1 %2072, float 0.000000e+00, float %2068
  br label %2074

2074:                                             ; preds = %2061, %2062
  %2075 = phi float [ %2073, %2062 ], [ %2055, %2061 ]
  br label %2076

2076:                                             ; preds = %2074
  %2077 = add i64 %89, %57
  %2078 = icmp slt i64 %2077, %26
  %2079 = select i1 %2078, i64 %2077, i64 0
  %2080 = extractelement <8 x float> %1837, i64 7
  %2081 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2082 = getelementptr inbounds nuw i8, ptr %2081, i64 %2079
  %2083 = load i8, ptr %2082, align 1
  %2084 = zext i8 %2083 to i32
  %2085 = shl i32 %2084, 23
  %2086 = bitcast i32 %2085 to float
  %2087 = fmul float %2086, %2080
  %2088 = extractelement <8 x float> %166, i64 7
  %2089 = fmul float %2088, %2087
  %2090 = call float @llvm.fabs.f32(float %2087)
  %2091 = fcmp olt float %2090, +inf
  %2092 = fcmp one float %2087, 0.000000e+00
  %2093 = and i1 %2091, %2092
  %2094 = call i1 @llvm.expect.i1(i1 %2093, i1 true)
  br i1 %2094, label %2095, label %2096

2095:                                             ; preds = %2076
  br label %2108

2096:                                             ; preds = %2076
  %2097 = fpext float %2088 to double
  %2098 = fpext float %2086 to double
  %2099 = fpext float %2080 to double
  %2100 = fmul double %2097, %2098
  %2101 = fmul double %2100, %2099
  %2102 = fptrunc double %2101 to float
  %2103 = fcmp oeq float %2088, 0.000000e+00
  %2104 = call float @llvm.fabs.f32(float %2080)
  %2105 = fcmp olt float %2104, +inf
  %2106 = and i1 %2103, %2105
  %2107 = select i1 %2106, float 0.000000e+00, float %2102
  br label %2108

2108:                                             ; preds = %2095, %2096
  %2109 = phi float [ %2107, %2096 ], [ %2089, %2095 ]
  br label %2110

2110:                                             ; preds = %2108
  %2111 = mul i64 %58, 8
  %2112 = add i64 %88, %2111
  %2113 = add i64 %89, %57
  %2114 = mul i64 %2112, %26
  %2115 = add i64 %2114, %2113
  %2116 = fptrunc float %1871 to bfloat
  %2117 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2118 = getelementptr inbounds nuw bfloat, ptr %2117, i64 %2115
  store bfloat %2116, ptr %2118, align 2
  %2119 = mul i64 %58, 8
  %2120 = add i64 %2119, 1
  %2121 = add i64 %88, %2120
  %2122 = add i64 %89, %57
  %2123 = mul i64 %2121, %26
  %2124 = add i64 %2123, %2122
  %2125 = fptrunc float %1905 to bfloat
  %2126 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2127 = getelementptr inbounds nuw bfloat, ptr %2126, i64 %2124
  store bfloat %2125, ptr %2127, align 2
  %2128 = mul i64 %58, 8
  %2129 = add i64 %2128, 2
  %2130 = add i64 %88, %2129
  %2131 = add i64 %89, %57
  %2132 = mul i64 %2130, %26
  %2133 = add i64 %2132, %2131
  %2134 = fptrunc float %1939 to bfloat
  %2135 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2136 = getelementptr inbounds nuw bfloat, ptr %2135, i64 %2133
  store bfloat %2134, ptr %2136, align 2
  %2137 = mul i64 %58, 8
  %2138 = add i64 %2137, 3
  %2139 = add i64 %88, %2138
  %2140 = add i64 %89, %57
  %2141 = mul i64 %2139, %26
  %2142 = add i64 %2141, %2140
  %2143 = fptrunc float %1973 to bfloat
  %2144 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2145 = getelementptr inbounds nuw bfloat, ptr %2144, i64 %2142
  store bfloat %2143, ptr %2145, align 2
  %2146 = mul i64 %58, 8
  %2147 = add i64 %2146, 4
  %2148 = add i64 %88, %2147
  %2149 = add i64 %89, %57
  %2150 = mul i64 %2148, %26
  %2151 = add i64 %2150, %2149
  %2152 = fptrunc float %2007 to bfloat
  %2153 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2154 = getelementptr inbounds nuw bfloat, ptr %2153, i64 %2151
  store bfloat %2152, ptr %2154, align 2
  %2155 = mul i64 %58, 8
  %2156 = add i64 %2155, 5
  %2157 = add i64 %88, %2156
  %2158 = add i64 %89, %57
  %2159 = mul i64 %2157, %26
  %2160 = add i64 %2159, %2158
  %2161 = fptrunc float %2041 to bfloat
  %2162 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2163 = getelementptr inbounds nuw bfloat, ptr %2162, i64 %2160
  store bfloat %2161, ptr %2163, align 2
  %2164 = mul i64 %58, 8
  %2165 = add i64 %2164, 6
  %2166 = add i64 %88, %2165
  %2167 = add i64 %89, %57
  %2168 = mul i64 %2166, %26
  %2169 = add i64 %2168, %2167
  %2170 = fptrunc float %2075 to bfloat
  %2171 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2172 = getelementptr inbounds nuw bfloat, ptr %2171, i64 %2169
  store bfloat %2170, ptr %2172, align 2
  %2173 = mul i64 %58, 8
  %2174 = add i64 %2173, 7
  %2175 = add i64 %88, %2174
  %2176 = add i64 %89, %57
  %2177 = mul i64 %2175, %26
  %2178 = add i64 %2177, %2176
  %2179 = fptrunc float %2109 to bfloat
  %2180 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2181 = getelementptr inbounds nuw bfloat, ptr %2180, i64 %2178
  store bfloat %2179, ptr %2181, align 2
  %2182 = mul i64 %58, 8
  %2183 = add i64 %82, %2182
  %2184 = add i64 %91, %57
  %2185 = add i64 %2183, 7
  %2186 = icmp ult i64 %2184, %26
  %2187 = icmp ult i64 %2185, %25
  %2188 = and i1 %2187, %2186
  %2189 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2190 = ptrtoint ptr %2189 to i64
  %2191 = mul i64 %2183, 4
  %2192 = add i64 %2190, %2191
  %2193 = urem i64 %2192, 16
  %2194 = icmp eq i64 %2193, 0
  %2195 = and i1 %2188, %2194
  br i1 %2195, label %2196, label %2205

2196:                                             ; preds = %2110
  %2197 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2198 = getelementptr float, ptr %2197, i64 %2183
  %2199 = load <4 x float>, ptr %2198, align 16
  %2200 = add i64 %2183, 4
  %2201 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2202 = getelementptr float, ptr %2201, i64 %2200
  %2203 = load <4 x float>, ptr %2202, align 16
  %2204 = shufflevector <4 x float> %2199, <4 x float> %2203, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2277

2205:                                             ; preds = %2110
  %2206 = mul i64 %58, 8
  %2207 = add i64 %82, %2206
  %2208 = icmp slt i64 %2207, %25
  %2209 = select i1 %2208, i64 %2207, i64 0
  %2210 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2211 = getelementptr inbounds nuw float, ptr %2210, i64 %2209
  %2212 = load float, ptr %2211, align 4
  %2213 = insertelement <8 x float> zeroinitializer, float %2212, i64 0
  %2214 = mul i64 %58, 8
  %2215 = add i64 %2214, 1
  %2216 = add i64 %82, %2215
  %2217 = icmp slt i64 %2216, %25
  %2218 = select i1 %2217, i64 %2216, i64 0
  %2219 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2220 = getelementptr inbounds nuw float, ptr %2219, i64 %2218
  %2221 = load float, ptr %2220, align 4
  %2222 = insertelement <8 x float> %2213, float %2221, i64 1
  %2223 = mul i64 %58, 8
  %2224 = add i64 %2223, 2
  %2225 = add i64 %82, %2224
  %2226 = icmp slt i64 %2225, %25
  %2227 = select i1 %2226, i64 %2225, i64 0
  %2228 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2229 = getelementptr inbounds nuw float, ptr %2228, i64 %2227
  %2230 = load float, ptr %2229, align 4
  %2231 = insertelement <8 x float> %2222, float %2230, i64 2
  %2232 = mul i64 %58, 8
  %2233 = add i64 %2232, 3
  %2234 = add i64 %82, %2233
  %2235 = icmp slt i64 %2234, %25
  %2236 = select i1 %2235, i64 %2234, i64 0
  %2237 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2238 = getelementptr inbounds nuw float, ptr %2237, i64 %2236
  %2239 = load float, ptr %2238, align 4
  %2240 = insertelement <8 x float> %2231, float %2239, i64 3
  %2241 = mul i64 %58, 8
  %2242 = add i64 %2241, 4
  %2243 = add i64 %82, %2242
  %2244 = icmp slt i64 %2243, %25
  %2245 = select i1 %2244, i64 %2243, i64 0
  %2246 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2247 = getelementptr inbounds nuw float, ptr %2246, i64 %2245
  %2248 = load float, ptr %2247, align 4
  %2249 = insertelement <8 x float> %2240, float %2248, i64 4
  %2250 = mul i64 %58, 8
  %2251 = add i64 %2250, 5
  %2252 = add i64 %82, %2251
  %2253 = icmp slt i64 %2252, %25
  %2254 = select i1 %2253, i64 %2252, i64 0
  %2255 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2256 = getelementptr inbounds nuw float, ptr %2255, i64 %2254
  %2257 = load float, ptr %2256, align 4
  %2258 = insertelement <8 x float> %2249, float %2257, i64 5
  %2259 = mul i64 %58, 8
  %2260 = add i64 %2259, 6
  %2261 = add i64 %82, %2260
  %2262 = icmp slt i64 %2261, %25
  %2263 = select i1 %2262, i64 %2261, i64 0
  %2264 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2265 = getelementptr inbounds nuw float, ptr %2264, i64 %2263
  %2266 = load float, ptr %2265, align 4
  %2267 = insertelement <8 x float> %2258, float %2266, i64 6
  %2268 = mul i64 %58, 8
  %2269 = add i64 %2268, 7
  %2270 = add i64 %82, %2269
  %2271 = icmp slt i64 %2270, %25
  %2272 = select i1 %2271, i64 %2270, i64 0
  %2273 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2274 = getelementptr inbounds nuw float, ptr %2273, i64 %2272
  %2275 = load float, ptr %2274, align 4
  %2276 = insertelement <8 x float> %2267, float %2275, i64 7
  br label %2277

2277:                                             ; preds = %2196, %2205
  %2278 = phi <8 x float> [ %2276, %2205 ], [ %2204, %2196 ]
  br label %2279

2279:                                             ; preds = %2277
  %2280 = add i64 %91, %57
  %2281 = icmp slt i64 %2280, %26
  %2282 = select i1 %2281, i64 %2280, i64 0
  %2283 = extractelement <8 x float> %2278, i64 0
  %2284 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2285 = getelementptr inbounds nuw i8, ptr %2284, i64 %2282
  %2286 = load i8, ptr %2285, align 1
  %2287 = zext i8 %2286 to i32
  %2288 = shl i32 %2287, 23
  %2289 = bitcast i32 %2288 to float
  %2290 = fmul float %2289, %2283
  %2291 = extractelement <8 x float> %161, i64 0
  %2292 = fmul float %2291, %2290
  %2293 = call float @llvm.fabs.f32(float %2290)
  %2294 = fcmp olt float %2293, +inf
  %2295 = fcmp one float %2290, 0.000000e+00
  %2296 = and i1 %2294, %2295
  %2297 = call i1 @llvm.expect.i1(i1 %2296, i1 true)
  br i1 %2297, label %2298, label %2299

2298:                                             ; preds = %2279
  br label %2311

2299:                                             ; preds = %2279
  %2300 = fpext float %2291 to double
  %2301 = fpext float %2289 to double
  %2302 = fpext float %2283 to double
  %2303 = fmul double %2300, %2301
  %2304 = fmul double %2303, %2302
  %2305 = fptrunc double %2304 to float
  %2306 = fcmp oeq float %2291, 0.000000e+00
  %2307 = call float @llvm.fabs.f32(float %2283)
  %2308 = fcmp olt float %2307, +inf
  %2309 = and i1 %2306, %2308
  %2310 = select i1 %2309, float 0.000000e+00, float %2305
  br label %2311

2311:                                             ; preds = %2298, %2299
  %2312 = phi float [ %2310, %2299 ], [ %2292, %2298 ]
  br label %2313

2313:                                             ; preds = %2311
  %2314 = add i64 %91, %57
  %2315 = icmp slt i64 %2314, %26
  %2316 = select i1 %2315, i64 %2314, i64 0
  %2317 = extractelement <8 x float> %2278, i64 1
  %2318 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2319 = getelementptr inbounds nuw i8, ptr %2318, i64 %2316
  %2320 = load i8, ptr %2319, align 1
  %2321 = zext i8 %2320 to i32
  %2322 = shl i32 %2321, 23
  %2323 = bitcast i32 %2322 to float
  %2324 = fmul float %2323, %2317
  %2325 = extractelement <8 x float> %161, i64 1
  %2326 = fmul float %2325, %2324
  %2327 = call float @llvm.fabs.f32(float %2324)
  %2328 = fcmp olt float %2327, +inf
  %2329 = fcmp one float %2324, 0.000000e+00
  %2330 = and i1 %2328, %2329
  %2331 = call i1 @llvm.expect.i1(i1 %2330, i1 true)
  br i1 %2331, label %2332, label %2333

2332:                                             ; preds = %2313
  br label %2345

2333:                                             ; preds = %2313
  %2334 = fpext float %2325 to double
  %2335 = fpext float %2323 to double
  %2336 = fpext float %2317 to double
  %2337 = fmul double %2334, %2335
  %2338 = fmul double %2337, %2336
  %2339 = fptrunc double %2338 to float
  %2340 = fcmp oeq float %2325, 0.000000e+00
  %2341 = call float @llvm.fabs.f32(float %2317)
  %2342 = fcmp olt float %2341, +inf
  %2343 = and i1 %2340, %2342
  %2344 = select i1 %2343, float 0.000000e+00, float %2339
  br label %2345

2345:                                             ; preds = %2332, %2333
  %2346 = phi float [ %2344, %2333 ], [ %2326, %2332 ]
  br label %2347

2347:                                             ; preds = %2345
  %2348 = add i64 %91, %57
  %2349 = icmp slt i64 %2348, %26
  %2350 = select i1 %2349, i64 %2348, i64 0
  %2351 = extractelement <8 x float> %2278, i64 2
  %2352 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2353 = getelementptr inbounds nuw i8, ptr %2352, i64 %2350
  %2354 = load i8, ptr %2353, align 1
  %2355 = zext i8 %2354 to i32
  %2356 = shl i32 %2355, 23
  %2357 = bitcast i32 %2356 to float
  %2358 = fmul float %2357, %2351
  %2359 = extractelement <8 x float> %161, i64 2
  %2360 = fmul float %2359, %2358
  %2361 = call float @llvm.fabs.f32(float %2358)
  %2362 = fcmp olt float %2361, +inf
  %2363 = fcmp one float %2358, 0.000000e+00
  %2364 = and i1 %2362, %2363
  %2365 = call i1 @llvm.expect.i1(i1 %2364, i1 true)
  br i1 %2365, label %2366, label %2367

2366:                                             ; preds = %2347
  br label %2379

2367:                                             ; preds = %2347
  %2368 = fpext float %2359 to double
  %2369 = fpext float %2357 to double
  %2370 = fpext float %2351 to double
  %2371 = fmul double %2368, %2369
  %2372 = fmul double %2371, %2370
  %2373 = fptrunc double %2372 to float
  %2374 = fcmp oeq float %2359, 0.000000e+00
  %2375 = call float @llvm.fabs.f32(float %2351)
  %2376 = fcmp olt float %2375, +inf
  %2377 = and i1 %2374, %2376
  %2378 = select i1 %2377, float 0.000000e+00, float %2373
  br label %2379

2379:                                             ; preds = %2366, %2367
  %2380 = phi float [ %2378, %2367 ], [ %2360, %2366 ]
  br label %2381

2381:                                             ; preds = %2379
  %2382 = add i64 %91, %57
  %2383 = icmp slt i64 %2382, %26
  %2384 = select i1 %2383, i64 %2382, i64 0
  %2385 = extractelement <8 x float> %2278, i64 3
  %2386 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2387 = getelementptr inbounds nuw i8, ptr %2386, i64 %2384
  %2388 = load i8, ptr %2387, align 1
  %2389 = zext i8 %2388 to i32
  %2390 = shl i32 %2389, 23
  %2391 = bitcast i32 %2390 to float
  %2392 = fmul float %2391, %2385
  %2393 = extractelement <8 x float> %161, i64 3
  %2394 = fmul float %2393, %2392
  %2395 = call float @llvm.fabs.f32(float %2392)
  %2396 = fcmp olt float %2395, +inf
  %2397 = fcmp one float %2392, 0.000000e+00
  %2398 = and i1 %2396, %2397
  %2399 = call i1 @llvm.expect.i1(i1 %2398, i1 true)
  br i1 %2399, label %2400, label %2401

2400:                                             ; preds = %2381
  br label %2413

2401:                                             ; preds = %2381
  %2402 = fpext float %2393 to double
  %2403 = fpext float %2391 to double
  %2404 = fpext float %2385 to double
  %2405 = fmul double %2402, %2403
  %2406 = fmul double %2405, %2404
  %2407 = fptrunc double %2406 to float
  %2408 = fcmp oeq float %2393, 0.000000e+00
  %2409 = call float @llvm.fabs.f32(float %2385)
  %2410 = fcmp olt float %2409, +inf
  %2411 = and i1 %2408, %2410
  %2412 = select i1 %2411, float 0.000000e+00, float %2407
  br label %2413

2413:                                             ; preds = %2400, %2401
  %2414 = phi float [ %2412, %2401 ], [ %2394, %2400 ]
  br label %2415

2415:                                             ; preds = %2413
  %2416 = add i64 %91, %57
  %2417 = icmp slt i64 %2416, %26
  %2418 = select i1 %2417, i64 %2416, i64 0
  %2419 = extractelement <8 x float> %2278, i64 4
  %2420 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2421 = getelementptr inbounds nuw i8, ptr %2420, i64 %2418
  %2422 = load i8, ptr %2421, align 1
  %2423 = zext i8 %2422 to i32
  %2424 = shl i32 %2423, 23
  %2425 = bitcast i32 %2424 to float
  %2426 = fmul float %2425, %2419
  %2427 = extractelement <8 x float> %161, i64 4
  %2428 = fmul float %2427, %2426
  %2429 = call float @llvm.fabs.f32(float %2426)
  %2430 = fcmp olt float %2429, +inf
  %2431 = fcmp one float %2426, 0.000000e+00
  %2432 = and i1 %2430, %2431
  %2433 = call i1 @llvm.expect.i1(i1 %2432, i1 true)
  br i1 %2433, label %2434, label %2435

2434:                                             ; preds = %2415
  br label %2447

2435:                                             ; preds = %2415
  %2436 = fpext float %2427 to double
  %2437 = fpext float %2425 to double
  %2438 = fpext float %2419 to double
  %2439 = fmul double %2436, %2437
  %2440 = fmul double %2439, %2438
  %2441 = fptrunc double %2440 to float
  %2442 = fcmp oeq float %2427, 0.000000e+00
  %2443 = call float @llvm.fabs.f32(float %2419)
  %2444 = fcmp olt float %2443, +inf
  %2445 = and i1 %2442, %2444
  %2446 = select i1 %2445, float 0.000000e+00, float %2441
  br label %2447

2447:                                             ; preds = %2434, %2435
  %2448 = phi float [ %2446, %2435 ], [ %2428, %2434 ]
  br label %2449

2449:                                             ; preds = %2447
  %2450 = add i64 %91, %57
  %2451 = icmp slt i64 %2450, %26
  %2452 = select i1 %2451, i64 %2450, i64 0
  %2453 = extractelement <8 x float> %2278, i64 5
  %2454 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2455 = getelementptr inbounds nuw i8, ptr %2454, i64 %2452
  %2456 = load i8, ptr %2455, align 1
  %2457 = zext i8 %2456 to i32
  %2458 = shl i32 %2457, 23
  %2459 = bitcast i32 %2458 to float
  %2460 = fmul float %2459, %2453
  %2461 = extractelement <8 x float> %161, i64 5
  %2462 = fmul float %2461, %2460
  %2463 = call float @llvm.fabs.f32(float %2460)
  %2464 = fcmp olt float %2463, +inf
  %2465 = fcmp one float %2460, 0.000000e+00
  %2466 = and i1 %2464, %2465
  %2467 = call i1 @llvm.expect.i1(i1 %2466, i1 true)
  br i1 %2467, label %2468, label %2469

2468:                                             ; preds = %2449
  br label %2481

2469:                                             ; preds = %2449
  %2470 = fpext float %2461 to double
  %2471 = fpext float %2459 to double
  %2472 = fpext float %2453 to double
  %2473 = fmul double %2470, %2471
  %2474 = fmul double %2473, %2472
  %2475 = fptrunc double %2474 to float
  %2476 = fcmp oeq float %2461, 0.000000e+00
  %2477 = call float @llvm.fabs.f32(float %2453)
  %2478 = fcmp olt float %2477, +inf
  %2479 = and i1 %2476, %2478
  %2480 = select i1 %2479, float 0.000000e+00, float %2475
  br label %2481

2481:                                             ; preds = %2468, %2469
  %2482 = phi float [ %2480, %2469 ], [ %2462, %2468 ]
  br label %2483

2483:                                             ; preds = %2481
  %2484 = add i64 %91, %57
  %2485 = icmp slt i64 %2484, %26
  %2486 = select i1 %2485, i64 %2484, i64 0
  %2487 = extractelement <8 x float> %2278, i64 6
  %2488 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2489 = getelementptr inbounds nuw i8, ptr %2488, i64 %2486
  %2490 = load i8, ptr %2489, align 1
  %2491 = zext i8 %2490 to i32
  %2492 = shl i32 %2491, 23
  %2493 = bitcast i32 %2492 to float
  %2494 = fmul float %2493, %2487
  %2495 = extractelement <8 x float> %161, i64 6
  %2496 = fmul float %2495, %2494
  %2497 = call float @llvm.fabs.f32(float %2494)
  %2498 = fcmp olt float %2497, +inf
  %2499 = fcmp one float %2494, 0.000000e+00
  %2500 = and i1 %2498, %2499
  %2501 = call i1 @llvm.expect.i1(i1 %2500, i1 true)
  br i1 %2501, label %2502, label %2503

2502:                                             ; preds = %2483
  br label %2515

2503:                                             ; preds = %2483
  %2504 = fpext float %2495 to double
  %2505 = fpext float %2493 to double
  %2506 = fpext float %2487 to double
  %2507 = fmul double %2504, %2505
  %2508 = fmul double %2507, %2506
  %2509 = fptrunc double %2508 to float
  %2510 = fcmp oeq float %2495, 0.000000e+00
  %2511 = call float @llvm.fabs.f32(float %2487)
  %2512 = fcmp olt float %2511, +inf
  %2513 = and i1 %2510, %2512
  %2514 = select i1 %2513, float 0.000000e+00, float %2509
  br label %2515

2515:                                             ; preds = %2502, %2503
  %2516 = phi float [ %2514, %2503 ], [ %2496, %2502 ]
  br label %2517

2517:                                             ; preds = %2515
  %2518 = add i64 %91, %57
  %2519 = icmp slt i64 %2518, %26
  %2520 = select i1 %2519, i64 %2518, i64 0
  %2521 = extractelement <8 x float> %2278, i64 7
  %2522 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2523 = getelementptr inbounds nuw i8, ptr %2522, i64 %2520
  %2524 = load i8, ptr %2523, align 1
  %2525 = zext i8 %2524 to i32
  %2526 = shl i32 %2525, 23
  %2527 = bitcast i32 %2526 to float
  %2528 = fmul float %2527, %2521
  %2529 = extractelement <8 x float> %161, i64 7
  %2530 = fmul float %2529, %2528
  %2531 = call float @llvm.fabs.f32(float %2528)
  %2532 = fcmp olt float %2531, +inf
  %2533 = fcmp one float %2528, 0.000000e+00
  %2534 = and i1 %2532, %2533
  %2535 = call i1 @llvm.expect.i1(i1 %2534, i1 true)
  br i1 %2535, label %2536, label %2537

2536:                                             ; preds = %2517
  br label %2549

2537:                                             ; preds = %2517
  %2538 = fpext float %2529 to double
  %2539 = fpext float %2527 to double
  %2540 = fpext float %2521 to double
  %2541 = fmul double %2538, %2539
  %2542 = fmul double %2541, %2540
  %2543 = fptrunc double %2542 to float
  %2544 = fcmp oeq float %2529, 0.000000e+00
  %2545 = call float @llvm.fabs.f32(float %2521)
  %2546 = fcmp olt float %2545, +inf
  %2547 = and i1 %2544, %2546
  %2548 = select i1 %2547, float 0.000000e+00, float %2543
  br label %2549

2549:                                             ; preds = %2536, %2537
  %2550 = phi float [ %2548, %2537 ], [ %2530, %2536 ]
  br label %2551

2551:                                             ; preds = %2549
  %2552 = mul i64 %58, 8
  %2553 = add i64 %82, %2552
  %2554 = add i64 %91, %57
  %2555 = mul i64 %2553, %26
  %2556 = add i64 %2555, %2554
  %2557 = fptrunc float %2312 to bfloat
  %2558 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2559 = getelementptr inbounds nuw bfloat, ptr %2558, i64 %2556
  store bfloat %2557, ptr %2559, align 2
  %2560 = mul i64 %58, 8
  %2561 = add i64 %2560, 1
  %2562 = add i64 %82, %2561
  %2563 = add i64 %91, %57
  %2564 = mul i64 %2562, %26
  %2565 = add i64 %2564, %2563
  %2566 = fptrunc float %2346 to bfloat
  %2567 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2568 = getelementptr inbounds nuw bfloat, ptr %2567, i64 %2565
  store bfloat %2566, ptr %2568, align 2
  %2569 = mul i64 %58, 8
  %2570 = add i64 %2569, 2
  %2571 = add i64 %82, %2570
  %2572 = add i64 %91, %57
  %2573 = mul i64 %2571, %26
  %2574 = add i64 %2573, %2572
  %2575 = fptrunc float %2380 to bfloat
  %2576 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2577 = getelementptr inbounds nuw bfloat, ptr %2576, i64 %2574
  store bfloat %2575, ptr %2577, align 2
  %2578 = mul i64 %58, 8
  %2579 = add i64 %2578, 3
  %2580 = add i64 %82, %2579
  %2581 = add i64 %91, %57
  %2582 = mul i64 %2580, %26
  %2583 = add i64 %2582, %2581
  %2584 = fptrunc float %2414 to bfloat
  %2585 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2586 = getelementptr inbounds nuw bfloat, ptr %2585, i64 %2583
  store bfloat %2584, ptr %2586, align 2
  %2587 = mul i64 %58, 8
  %2588 = add i64 %2587, 4
  %2589 = add i64 %82, %2588
  %2590 = add i64 %91, %57
  %2591 = mul i64 %2589, %26
  %2592 = add i64 %2591, %2590
  %2593 = fptrunc float %2448 to bfloat
  %2594 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2595 = getelementptr inbounds nuw bfloat, ptr %2594, i64 %2592
  store bfloat %2593, ptr %2595, align 2
  %2596 = mul i64 %58, 8
  %2597 = add i64 %2596, 5
  %2598 = add i64 %82, %2597
  %2599 = add i64 %91, %57
  %2600 = mul i64 %2598, %26
  %2601 = add i64 %2600, %2599
  %2602 = fptrunc float %2482 to bfloat
  %2603 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2604 = getelementptr inbounds nuw bfloat, ptr %2603, i64 %2601
  store bfloat %2602, ptr %2604, align 2
  %2605 = mul i64 %58, 8
  %2606 = add i64 %2605, 6
  %2607 = add i64 %82, %2606
  %2608 = add i64 %91, %57
  %2609 = mul i64 %2607, %26
  %2610 = add i64 %2609, %2608
  %2611 = fptrunc float %2516 to bfloat
  %2612 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2613 = getelementptr inbounds nuw bfloat, ptr %2612, i64 %2610
  store bfloat %2611, ptr %2613, align 2
  %2614 = mul i64 %58, 8
  %2615 = add i64 %2614, 7
  %2616 = add i64 %82, %2615
  %2617 = add i64 %91, %57
  %2618 = mul i64 %2616, %26
  %2619 = add i64 %2618, %2617
  %2620 = fptrunc float %2550 to bfloat
  %2621 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2622 = getelementptr inbounds nuw bfloat, ptr %2621, i64 %2619
  store bfloat %2620, ptr %2622, align 2
  %2623 = mul i64 %58, 8
  %2624 = add i64 %84, %2623
  %2625 = add i64 %91, %57
  %2626 = add i64 %2624, 7
  %2627 = icmp ult i64 %2625, %26
  %2628 = icmp ult i64 %2626, %25
  %2629 = and i1 %2628, %2627
  %2630 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2631 = ptrtoint ptr %2630 to i64
  %2632 = mul i64 %2624, 4
  %2633 = add i64 %2631, %2632
  %2634 = urem i64 %2633, 16
  %2635 = icmp eq i64 %2634, 0
  %2636 = and i1 %2629, %2635
  br i1 %2636, label %2637, label %2646

2637:                                             ; preds = %2551
  %2638 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2639 = getelementptr float, ptr %2638, i64 %2624
  %2640 = load <4 x float>, ptr %2639, align 16
  %2641 = add i64 %2624, 4
  %2642 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2643 = getelementptr float, ptr %2642, i64 %2641
  %2644 = load <4 x float>, ptr %2643, align 16
  %2645 = shufflevector <4 x float> %2640, <4 x float> %2644, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2718

2646:                                             ; preds = %2551
  %2647 = mul i64 %58, 8
  %2648 = add i64 %84, %2647
  %2649 = icmp slt i64 %2648, %25
  %2650 = select i1 %2649, i64 %2648, i64 0
  %2651 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2652 = getelementptr inbounds nuw float, ptr %2651, i64 %2650
  %2653 = load float, ptr %2652, align 4
  %2654 = insertelement <8 x float> zeroinitializer, float %2653, i64 0
  %2655 = mul i64 %58, 8
  %2656 = add i64 %2655, 1
  %2657 = add i64 %84, %2656
  %2658 = icmp slt i64 %2657, %25
  %2659 = select i1 %2658, i64 %2657, i64 0
  %2660 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2661 = getelementptr inbounds nuw float, ptr %2660, i64 %2659
  %2662 = load float, ptr %2661, align 4
  %2663 = insertelement <8 x float> %2654, float %2662, i64 1
  %2664 = mul i64 %58, 8
  %2665 = add i64 %2664, 2
  %2666 = add i64 %84, %2665
  %2667 = icmp slt i64 %2666, %25
  %2668 = select i1 %2667, i64 %2666, i64 0
  %2669 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2670 = getelementptr inbounds nuw float, ptr %2669, i64 %2668
  %2671 = load float, ptr %2670, align 4
  %2672 = insertelement <8 x float> %2663, float %2671, i64 2
  %2673 = mul i64 %58, 8
  %2674 = add i64 %2673, 3
  %2675 = add i64 %84, %2674
  %2676 = icmp slt i64 %2675, %25
  %2677 = select i1 %2676, i64 %2675, i64 0
  %2678 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2679 = getelementptr inbounds nuw float, ptr %2678, i64 %2677
  %2680 = load float, ptr %2679, align 4
  %2681 = insertelement <8 x float> %2672, float %2680, i64 3
  %2682 = mul i64 %58, 8
  %2683 = add i64 %2682, 4
  %2684 = add i64 %84, %2683
  %2685 = icmp slt i64 %2684, %25
  %2686 = select i1 %2685, i64 %2684, i64 0
  %2687 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2688 = getelementptr inbounds nuw float, ptr %2687, i64 %2686
  %2689 = load float, ptr %2688, align 4
  %2690 = insertelement <8 x float> %2681, float %2689, i64 4
  %2691 = mul i64 %58, 8
  %2692 = add i64 %2691, 5
  %2693 = add i64 %84, %2692
  %2694 = icmp slt i64 %2693, %25
  %2695 = select i1 %2694, i64 %2693, i64 0
  %2696 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2697 = getelementptr inbounds nuw float, ptr %2696, i64 %2695
  %2698 = load float, ptr %2697, align 4
  %2699 = insertelement <8 x float> %2690, float %2698, i64 5
  %2700 = mul i64 %58, 8
  %2701 = add i64 %2700, 6
  %2702 = add i64 %84, %2701
  %2703 = icmp slt i64 %2702, %25
  %2704 = select i1 %2703, i64 %2702, i64 0
  %2705 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2706 = getelementptr inbounds nuw float, ptr %2705, i64 %2704
  %2707 = load float, ptr %2706, align 4
  %2708 = insertelement <8 x float> %2699, float %2707, i64 6
  %2709 = mul i64 %58, 8
  %2710 = add i64 %2709, 7
  %2711 = add i64 %84, %2710
  %2712 = icmp slt i64 %2711, %25
  %2713 = select i1 %2712, i64 %2711, i64 0
  %2714 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2715 = getelementptr inbounds nuw float, ptr %2714, i64 %2713
  %2716 = load float, ptr %2715, align 4
  %2717 = insertelement <8 x float> %2708, float %2716, i64 7
  br label %2718

2718:                                             ; preds = %2637, %2646
  %2719 = phi <8 x float> [ %2717, %2646 ], [ %2645, %2637 ]
  br label %2720

2720:                                             ; preds = %2718
  %2721 = add i64 %91, %57
  %2722 = icmp slt i64 %2721, %26
  %2723 = select i1 %2722, i64 %2721, i64 0
  %2724 = extractelement <8 x float> %2719, i64 0
  %2725 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2726 = getelementptr inbounds nuw i8, ptr %2725, i64 %2723
  %2727 = load i8, ptr %2726, align 1
  %2728 = zext i8 %2727 to i32
  %2729 = shl i32 %2728, 23
  %2730 = bitcast i32 %2729 to float
  %2731 = fmul float %2730, %2724
  %2732 = extractelement <8 x float> %163, i64 0
  %2733 = fmul float %2732, %2731
  %2734 = call float @llvm.fabs.f32(float %2731)
  %2735 = fcmp olt float %2734, +inf
  %2736 = fcmp one float %2731, 0.000000e+00
  %2737 = and i1 %2735, %2736
  %2738 = call i1 @llvm.expect.i1(i1 %2737, i1 true)
  br i1 %2738, label %2739, label %2740

2739:                                             ; preds = %2720
  br label %2752

2740:                                             ; preds = %2720
  %2741 = fpext float %2732 to double
  %2742 = fpext float %2730 to double
  %2743 = fpext float %2724 to double
  %2744 = fmul double %2741, %2742
  %2745 = fmul double %2744, %2743
  %2746 = fptrunc double %2745 to float
  %2747 = fcmp oeq float %2732, 0.000000e+00
  %2748 = call float @llvm.fabs.f32(float %2724)
  %2749 = fcmp olt float %2748, +inf
  %2750 = and i1 %2747, %2749
  %2751 = select i1 %2750, float 0.000000e+00, float %2746
  br label %2752

2752:                                             ; preds = %2739, %2740
  %2753 = phi float [ %2751, %2740 ], [ %2733, %2739 ]
  br label %2754

2754:                                             ; preds = %2752
  %2755 = add i64 %91, %57
  %2756 = icmp slt i64 %2755, %26
  %2757 = select i1 %2756, i64 %2755, i64 0
  %2758 = extractelement <8 x float> %2719, i64 1
  %2759 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2760 = getelementptr inbounds nuw i8, ptr %2759, i64 %2757
  %2761 = load i8, ptr %2760, align 1
  %2762 = zext i8 %2761 to i32
  %2763 = shl i32 %2762, 23
  %2764 = bitcast i32 %2763 to float
  %2765 = fmul float %2764, %2758
  %2766 = extractelement <8 x float> %163, i64 1
  %2767 = fmul float %2766, %2765
  %2768 = call float @llvm.fabs.f32(float %2765)
  %2769 = fcmp olt float %2768, +inf
  %2770 = fcmp one float %2765, 0.000000e+00
  %2771 = and i1 %2769, %2770
  %2772 = call i1 @llvm.expect.i1(i1 %2771, i1 true)
  br i1 %2772, label %2773, label %2774

2773:                                             ; preds = %2754
  br label %2786

2774:                                             ; preds = %2754
  %2775 = fpext float %2766 to double
  %2776 = fpext float %2764 to double
  %2777 = fpext float %2758 to double
  %2778 = fmul double %2775, %2776
  %2779 = fmul double %2778, %2777
  %2780 = fptrunc double %2779 to float
  %2781 = fcmp oeq float %2766, 0.000000e+00
  %2782 = call float @llvm.fabs.f32(float %2758)
  %2783 = fcmp olt float %2782, +inf
  %2784 = and i1 %2781, %2783
  %2785 = select i1 %2784, float 0.000000e+00, float %2780
  br label %2786

2786:                                             ; preds = %2773, %2774
  %2787 = phi float [ %2785, %2774 ], [ %2767, %2773 ]
  br label %2788

2788:                                             ; preds = %2786
  %2789 = add i64 %91, %57
  %2790 = icmp slt i64 %2789, %26
  %2791 = select i1 %2790, i64 %2789, i64 0
  %2792 = extractelement <8 x float> %2719, i64 2
  %2793 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2794 = getelementptr inbounds nuw i8, ptr %2793, i64 %2791
  %2795 = load i8, ptr %2794, align 1
  %2796 = zext i8 %2795 to i32
  %2797 = shl i32 %2796, 23
  %2798 = bitcast i32 %2797 to float
  %2799 = fmul float %2798, %2792
  %2800 = extractelement <8 x float> %163, i64 2
  %2801 = fmul float %2800, %2799
  %2802 = call float @llvm.fabs.f32(float %2799)
  %2803 = fcmp olt float %2802, +inf
  %2804 = fcmp one float %2799, 0.000000e+00
  %2805 = and i1 %2803, %2804
  %2806 = call i1 @llvm.expect.i1(i1 %2805, i1 true)
  br i1 %2806, label %2807, label %2808

2807:                                             ; preds = %2788
  br label %2820

2808:                                             ; preds = %2788
  %2809 = fpext float %2800 to double
  %2810 = fpext float %2798 to double
  %2811 = fpext float %2792 to double
  %2812 = fmul double %2809, %2810
  %2813 = fmul double %2812, %2811
  %2814 = fptrunc double %2813 to float
  %2815 = fcmp oeq float %2800, 0.000000e+00
  %2816 = call float @llvm.fabs.f32(float %2792)
  %2817 = fcmp olt float %2816, +inf
  %2818 = and i1 %2815, %2817
  %2819 = select i1 %2818, float 0.000000e+00, float %2814
  br label %2820

2820:                                             ; preds = %2807, %2808
  %2821 = phi float [ %2819, %2808 ], [ %2801, %2807 ]
  br label %2822

2822:                                             ; preds = %2820
  %2823 = add i64 %91, %57
  %2824 = icmp slt i64 %2823, %26
  %2825 = select i1 %2824, i64 %2823, i64 0
  %2826 = extractelement <8 x float> %2719, i64 3
  %2827 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2828 = getelementptr inbounds nuw i8, ptr %2827, i64 %2825
  %2829 = load i8, ptr %2828, align 1
  %2830 = zext i8 %2829 to i32
  %2831 = shl i32 %2830, 23
  %2832 = bitcast i32 %2831 to float
  %2833 = fmul float %2832, %2826
  %2834 = extractelement <8 x float> %163, i64 3
  %2835 = fmul float %2834, %2833
  %2836 = call float @llvm.fabs.f32(float %2833)
  %2837 = fcmp olt float %2836, +inf
  %2838 = fcmp one float %2833, 0.000000e+00
  %2839 = and i1 %2837, %2838
  %2840 = call i1 @llvm.expect.i1(i1 %2839, i1 true)
  br i1 %2840, label %2841, label %2842

2841:                                             ; preds = %2822
  br label %2854

2842:                                             ; preds = %2822
  %2843 = fpext float %2834 to double
  %2844 = fpext float %2832 to double
  %2845 = fpext float %2826 to double
  %2846 = fmul double %2843, %2844
  %2847 = fmul double %2846, %2845
  %2848 = fptrunc double %2847 to float
  %2849 = fcmp oeq float %2834, 0.000000e+00
  %2850 = call float @llvm.fabs.f32(float %2826)
  %2851 = fcmp olt float %2850, +inf
  %2852 = and i1 %2849, %2851
  %2853 = select i1 %2852, float 0.000000e+00, float %2848
  br label %2854

2854:                                             ; preds = %2841, %2842
  %2855 = phi float [ %2853, %2842 ], [ %2835, %2841 ]
  br label %2856

2856:                                             ; preds = %2854
  %2857 = add i64 %91, %57
  %2858 = icmp slt i64 %2857, %26
  %2859 = select i1 %2858, i64 %2857, i64 0
  %2860 = extractelement <8 x float> %2719, i64 4
  %2861 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2862 = getelementptr inbounds nuw i8, ptr %2861, i64 %2859
  %2863 = load i8, ptr %2862, align 1
  %2864 = zext i8 %2863 to i32
  %2865 = shl i32 %2864, 23
  %2866 = bitcast i32 %2865 to float
  %2867 = fmul float %2866, %2860
  %2868 = extractelement <8 x float> %163, i64 4
  %2869 = fmul float %2868, %2867
  %2870 = call float @llvm.fabs.f32(float %2867)
  %2871 = fcmp olt float %2870, +inf
  %2872 = fcmp one float %2867, 0.000000e+00
  %2873 = and i1 %2871, %2872
  %2874 = call i1 @llvm.expect.i1(i1 %2873, i1 true)
  br i1 %2874, label %2875, label %2876

2875:                                             ; preds = %2856
  br label %2888

2876:                                             ; preds = %2856
  %2877 = fpext float %2868 to double
  %2878 = fpext float %2866 to double
  %2879 = fpext float %2860 to double
  %2880 = fmul double %2877, %2878
  %2881 = fmul double %2880, %2879
  %2882 = fptrunc double %2881 to float
  %2883 = fcmp oeq float %2868, 0.000000e+00
  %2884 = call float @llvm.fabs.f32(float %2860)
  %2885 = fcmp olt float %2884, +inf
  %2886 = and i1 %2883, %2885
  %2887 = select i1 %2886, float 0.000000e+00, float %2882
  br label %2888

2888:                                             ; preds = %2875, %2876
  %2889 = phi float [ %2887, %2876 ], [ %2869, %2875 ]
  br label %2890

2890:                                             ; preds = %2888
  %2891 = add i64 %91, %57
  %2892 = icmp slt i64 %2891, %26
  %2893 = select i1 %2892, i64 %2891, i64 0
  %2894 = extractelement <8 x float> %2719, i64 5
  %2895 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2896 = getelementptr inbounds nuw i8, ptr %2895, i64 %2893
  %2897 = load i8, ptr %2896, align 1
  %2898 = zext i8 %2897 to i32
  %2899 = shl i32 %2898, 23
  %2900 = bitcast i32 %2899 to float
  %2901 = fmul float %2900, %2894
  %2902 = extractelement <8 x float> %163, i64 5
  %2903 = fmul float %2902, %2901
  %2904 = call float @llvm.fabs.f32(float %2901)
  %2905 = fcmp olt float %2904, +inf
  %2906 = fcmp one float %2901, 0.000000e+00
  %2907 = and i1 %2905, %2906
  %2908 = call i1 @llvm.expect.i1(i1 %2907, i1 true)
  br i1 %2908, label %2909, label %2910

2909:                                             ; preds = %2890
  br label %2922

2910:                                             ; preds = %2890
  %2911 = fpext float %2902 to double
  %2912 = fpext float %2900 to double
  %2913 = fpext float %2894 to double
  %2914 = fmul double %2911, %2912
  %2915 = fmul double %2914, %2913
  %2916 = fptrunc double %2915 to float
  %2917 = fcmp oeq float %2902, 0.000000e+00
  %2918 = call float @llvm.fabs.f32(float %2894)
  %2919 = fcmp olt float %2918, +inf
  %2920 = and i1 %2917, %2919
  %2921 = select i1 %2920, float 0.000000e+00, float %2916
  br label %2922

2922:                                             ; preds = %2909, %2910
  %2923 = phi float [ %2921, %2910 ], [ %2903, %2909 ]
  br label %2924

2924:                                             ; preds = %2922
  %2925 = add i64 %91, %57
  %2926 = icmp slt i64 %2925, %26
  %2927 = select i1 %2926, i64 %2925, i64 0
  %2928 = extractelement <8 x float> %2719, i64 6
  %2929 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2930 = getelementptr inbounds nuw i8, ptr %2929, i64 %2927
  %2931 = load i8, ptr %2930, align 1
  %2932 = zext i8 %2931 to i32
  %2933 = shl i32 %2932, 23
  %2934 = bitcast i32 %2933 to float
  %2935 = fmul float %2934, %2928
  %2936 = extractelement <8 x float> %163, i64 6
  %2937 = fmul float %2936, %2935
  %2938 = call float @llvm.fabs.f32(float %2935)
  %2939 = fcmp olt float %2938, +inf
  %2940 = fcmp one float %2935, 0.000000e+00
  %2941 = and i1 %2939, %2940
  %2942 = call i1 @llvm.expect.i1(i1 %2941, i1 true)
  br i1 %2942, label %2943, label %2944

2943:                                             ; preds = %2924
  br label %2956

2944:                                             ; preds = %2924
  %2945 = fpext float %2936 to double
  %2946 = fpext float %2934 to double
  %2947 = fpext float %2928 to double
  %2948 = fmul double %2945, %2946
  %2949 = fmul double %2948, %2947
  %2950 = fptrunc double %2949 to float
  %2951 = fcmp oeq float %2936, 0.000000e+00
  %2952 = call float @llvm.fabs.f32(float %2928)
  %2953 = fcmp olt float %2952, +inf
  %2954 = and i1 %2951, %2953
  %2955 = select i1 %2954, float 0.000000e+00, float %2950
  br label %2956

2956:                                             ; preds = %2943, %2944
  %2957 = phi float [ %2955, %2944 ], [ %2937, %2943 ]
  br label %2958

2958:                                             ; preds = %2956
  %2959 = add i64 %91, %57
  %2960 = icmp slt i64 %2959, %26
  %2961 = select i1 %2960, i64 %2959, i64 0
  %2962 = extractelement <8 x float> %2719, i64 7
  %2963 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2964 = getelementptr inbounds nuw i8, ptr %2963, i64 %2961
  %2965 = load i8, ptr %2964, align 1
  %2966 = zext i8 %2965 to i32
  %2967 = shl i32 %2966, 23
  %2968 = bitcast i32 %2967 to float
  %2969 = fmul float %2968, %2962
  %2970 = extractelement <8 x float> %163, i64 7
  %2971 = fmul float %2970, %2969
  %2972 = call float @llvm.fabs.f32(float %2969)
  %2973 = fcmp olt float %2972, +inf
  %2974 = fcmp one float %2969, 0.000000e+00
  %2975 = and i1 %2973, %2974
  %2976 = call i1 @llvm.expect.i1(i1 %2975, i1 true)
  br i1 %2976, label %2977, label %2978

2977:                                             ; preds = %2958
  br label %2990

2978:                                             ; preds = %2958
  %2979 = fpext float %2970 to double
  %2980 = fpext float %2968 to double
  %2981 = fpext float %2962 to double
  %2982 = fmul double %2979, %2980
  %2983 = fmul double %2982, %2981
  %2984 = fptrunc double %2983 to float
  %2985 = fcmp oeq float %2970, 0.000000e+00
  %2986 = call float @llvm.fabs.f32(float %2962)
  %2987 = fcmp olt float %2986, +inf
  %2988 = and i1 %2985, %2987
  %2989 = select i1 %2988, float 0.000000e+00, float %2984
  br label %2990

2990:                                             ; preds = %2977, %2978
  %2991 = phi float [ %2989, %2978 ], [ %2971, %2977 ]
  br label %2992

2992:                                             ; preds = %2990
  %2993 = mul i64 %58, 8
  %2994 = add i64 %84, %2993
  %2995 = add i64 %91, %57
  %2996 = mul i64 %2994, %26
  %2997 = add i64 %2996, %2995
  %2998 = fptrunc float %2753 to bfloat
  %2999 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3000 = getelementptr inbounds nuw bfloat, ptr %2999, i64 %2997
  store bfloat %2998, ptr %3000, align 2
  %3001 = mul i64 %58, 8
  %3002 = add i64 %3001, 1
  %3003 = add i64 %84, %3002
  %3004 = add i64 %91, %57
  %3005 = mul i64 %3003, %26
  %3006 = add i64 %3005, %3004
  %3007 = fptrunc float %2787 to bfloat
  %3008 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3009 = getelementptr inbounds nuw bfloat, ptr %3008, i64 %3006
  store bfloat %3007, ptr %3009, align 2
  %3010 = mul i64 %58, 8
  %3011 = add i64 %3010, 2
  %3012 = add i64 %84, %3011
  %3013 = add i64 %91, %57
  %3014 = mul i64 %3012, %26
  %3015 = add i64 %3014, %3013
  %3016 = fptrunc float %2821 to bfloat
  %3017 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3018 = getelementptr inbounds nuw bfloat, ptr %3017, i64 %3015
  store bfloat %3016, ptr %3018, align 2
  %3019 = mul i64 %58, 8
  %3020 = add i64 %3019, 3
  %3021 = add i64 %84, %3020
  %3022 = add i64 %91, %57
  %3023 = mul i64 %3021, %26
  %3024 = add i64 %3023, %3022
  %3025 = fptrunc float %2855 to bfloat
  %3026 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3027 = getelementptr inbounds nuw bfloat, ptr %3026, i64 %3024
  store bfloat %3025, ptr %3027, align 2
  %3028 = mul i64 %58, 8
  %3029 = add i64 %3028, 4
  %3030 = add i64 %84, %3029
  %3031 = add i64 %91, %57
  %3032 = mul i64 %3030, %26
  %3033 = add i64 %3032, %3031
  %3034 = fptrunc float %2889 to bfloat
  %3035 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3036 = getelementptr inbounds nuw bfloat, ptr %3035, i64 %3033
  store bfloat %3034, ptr %3036, align 2
  %3037 = mul i64 %58, 8
  %3038 = add i64 %3037, 5
  %3039 = add i64 %84, %3038
  %3040 = add i64 %91, %57
  %3041 = mul i64 %3039, %26
  %3042 = add i64 %3041, %3040
  %3043 = fptrunc float %2923 to bfloat
  %3044 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3045 = getelementptr inbounds nuw bfloat, ptr %3044, i64 %3042
  store bfloat %3043, ptr %3045, align 2
  %3046 = mul i64 %58, 8
  %3047 = add i64 %3046, 6
  %3048 = add i64 %84, %3047
  %3049 = add i64 %91, %57
  %3050 = mul i64 %3048, %26
  %3051 = add i64 %3050, %3049
  %3052 = fptrunc float %2957 to bfloat
  %3053 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3054 = getelementptr inbounds nuw bfloat, ptr %3053, i64 %3051
  store bfloat %3052, ptr %3054, align 2
  %3055 = mul i64 %58, 8
  %3056 = add i64 %3055, 7
  %3057 = add i64 %84, %3056
  %3058 = add i64 %91, %57
  %3059 = mul i64 %3057, %26
  %3060 = add i64 %3059, %3058
  %3061 = fptrunc float %2991 to bfloat
  %3062 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3063 = getelementptr inbounds nuw bfloat, ptr %3062, i64 %3060
  store bfloat %3061, ptr %3063, align 2
  %3064 = mul i64 %58, 8
  %3065 = add i64 %86, %3064
  %3066 = add i64 %91, %57
  %3067 = add i64 %3065, 7
  %3068 = icmp ult i64 %3066, %26
  %3069 = icmp ult i64 %3067, %25
  %3070 = and i1 %3069, %3068
  %3071 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3072 = ptrtoint ptr %3071 to i64
  %3073 = mul i64 %3065, 4
  %3074 = add i64 %3072, %3073
  %3075 = urem i64 %3074, 16
  %3076 = icmp eq i64 %3075, 0
  %3077 = and i1 %3070, %3076
  br i1 %3077, label %3078, label %3087

3078:                                             ; preds = %2992
  %3079 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3080 = getelementptr float, ptr %3079, i64 %3065
  %3081 = load <4 x float>, ptr %3080, align 16
  %3082 = add i64 %3065, 4
  %3083 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3084 = getelementptr float, ptr %3083, i64 %3082
  %3085 = load <4 x float>, ptr %3084, align 16
  %3086 = shufflevector <4 x float> %3081, <4 x float> %3085, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3159

3087:                                             ; preds = %2992
  %3088 = mul i64 %58, 8
  %3089 = add i64 %86, %3088
  %3090 = icmp slt i64 %3089, %25
  %3091 = select i1 %3090, i64 %3089, i64 0
  %3092 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3093 = getelementptr inbounds nuw float, ptr %3092, i64 %3091
  %3094 = load float, ptr %3093, align 4
  %3095 = insertelement <8 x float> zeroinitializer, float %3094, i64 0
  %3096 = mul i64 %58, 8
  %3097 = add i64 %3096, 1
  %3098 = add i64 %86, %3097
  %3099 = icmp slt i64 %3098, %25
  %3100 = select i1 %3099, i64 %3098, i64 0
  %3101 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3102 = getelementptr inbounds nuw float, ptr %3101, i64 %3100
  %3103 = load float, ptr %3102, align 4
  %3104 = insertelement <8 x float> %3095, float %3103, i64 1
  %3105 = mul i64 %58, 8
  %3106 = add i64 %3105, 2
  %3107 = add i64 %86, %3106
  %3108 = icmp slt i64 %3107, %25
  %3109 = select i1 %3108, i64 %3107, i64 0
  %3110 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3111 = getelementptr inbounds nuw float, ptr %3110, i64 %3109
  %3112 = load float, ptr %3111, align 4
  %3113 = insertelement <8 x float> %3104, float %3112, i64 2
  %3114 = mul i64 %58, 8
  %3115 = add i64 %3114, 3
  %3116 = add i64 %86, %3115
  %3117 = icmp slt i64 %3116, %25
  %3118 = select i1 %3117, i64 %3116, i64 0
  %3119 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3120 = getelementptr inbounds nuw float, ptr %3119, i64 %3118
  %3121 = load float, ptr %3120, align 4
  %3122 = insertelement <8 x float> %3113, float %3121, i64 3
  %3123 = mul i64 %58, 8
  %3124 = add i64 %3123, 4
  %3125 = add i64 %86, %3124
  %3126 = icmp slt i64 %3125, %25
  %3127 = select i1 %3126, i64 %3125, i64 0
  %3128 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3129 = getelementptr inbounds nuw float, ptr %3128, i64 %3127
  %3130 = load float, ptr %3129, align 4
  %3131 = insertelement <8 x float> %3122, float %3130, i64 4
  %3132 = mul i64 %58, 8
  %3133 = add i64 %3132, 5
  %3134 = add i64 %86, %3133
  %3135 = icmp slt i64 %3134, %25
  %3136 = select i1 %3135, i64 %3134, i64 0
  %3137 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3138 = getelementptr inbounds nuw float, ptr %3137, i64 %3136
  %3139 = load float, ptr %3138, align 4
  %3140 = insertelement <8 x float> %3131, float %3139, i64 5
  %3141 = mul i64 %58, 8
  %3142 = add i64 %3141, 6
  %3143 = add i64 %86, %3142
  %3144 = icmp slt i64 %3143, %25
  %3145 = select i1 %3144, i64 %3143, i64 0
  %3146 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3147 = getelementptr inbounds nuw float, ptr %3146, i64 %3145
  %3148 = load float, ptr %3147, align 4
  %3149 = insertelement <8 x float> %3140, float %3148, i64 6
  %3150 = mul i64 %58, 8
  %3151 = add i64 %3150, 7
  %3152 = add i64 %86, %3151
  %3153 = icmp slt i64 %3152, %25
  %3154 = select i1 %3153, i64 %3152, i64 0
  %3155 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3156 = getelementptr inbounds nuw float, ptr %3155, i64 %3154
  %3157 = load float, ptr %3156, align 4
  %3158 = insertelement <8 x float> %3149, float %3157, i64 7
  br label %3159

3159:                                             ; preds = %3078, %3087
  %3160 = phi <8 x float> [ %3158, %3087 ], [ %3086, %3078 ]
  br label %3161

3161:                                             ; preds = %3159
  %3162 = add i64 %91, %57
  %3163 = icmp slt i64 %3162, %26
  %3164 = select i1 %3163, i64 %3162, i64 0
  %3165 = extractelement <8 x float> %3160, i64 0
  %3166 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3167 = getelementptr inbounds nuw i8, ptr %3166, i64 %3164
  %3168 = load i8, ptr %3167, align 1
  %3169 = zext i8 %3168 to i32
  %3170 = shl i32 %3169, 23
  %3171 = bitcast i32 %3170 to float
  %3172 = fmul float %3171, %3165
  %3173 = extractelement <8 x float> %165, i64 0
  %3174 = fmul float %3173, %3172
  %3175 = call float @llvm.fabs.f32(float %3172)
  %3176 = fcmp olt float %3175, +inf
  %3177 = fcmp one float %3172, 0.000000e+00
  %3178 = and i1 %3176, %3177
  %3179 = call i1 @llvm.expect.i1(i1 %3178, i1 true)
  br i1 %3179, label %3180, label %3181

3180:                                             ; preds = %3161
  br label %3193

3181:                                             ; preds = %3161
  %3182 = fpext float %3173 to double
  %3183 = fpext float %3171 to double
  %3184 = fpext float %3165 to double
  %3185 = fmul double %3182, %3183
  %3186 = fmul double %3185, %3184
  %3187 = fptrunc double %3186 to float
  %3188 = fcmp oeq float %3173, 0.000000e+00
  %3189 = call float @llvm.fabs.f32(float %3165)
  %3190 = fcmp olt float %3189, +inf
  %3191 = and i1 %3188, %3190
  %3192 = select i1 %3191, float 0.000000e+00, float %3187
  br label %3193

3193:                                             ; preds = %3180, %3181
  %3194 = phi float [ %3192, %3181 ], [ %3174, %3180 ]
  br label %3195

3195:                                             ; preds = %3193
  %3196 = add i64 %91, %57
  %3197 = icmp slt i64 %3196, %26
  %3198 = select i1 %3197, i64 %3196, i64 0
  %3199 = extractelement <8 x float> %3160, i64 1
  %3200 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3201 = getelementptr inbounds nuw i8, ptr %3200, i64 %3198
  %3202 = load i8, ptr %3201, align 1
  %3203 = zext i8 %3202 to i32
  %3204 = shl i32 %3203, 23
  %3205 = bitcast i32 %3204 to float
  %3206 = fmul float %3205, %3199
  %3207 = extractelement <8 x float> %165, i64 1
  %3208 = fmul float %3207, %3206
  %3209 = call float @llvm.fabs.f32(float %3206)
  %3210 = fcmp olt float %3209, +inf
  %3211 = fcmp one float %3206, 0.000000e+00
  %3212 = and i1 %3210, %3211
  %3213 = call i1 @llvm.expect.i1(i1 %3212, i1 true)
  br i1 %3213, label %3214, label %3215

3214:                                             ; preds = %3195
  br label %3227

3215:                                             ; preds = %3195
  %3216 = fpext float %3207 to double
  %3217 = fpext float %3205 to double
  %3218 = fpext float %3199 to double
  %3219 = fmul double %3216, %3217
  %3220 = fmul double %3219, %3218
  %3221 = fptrunc double %3220 to float
  %3222 = fcmp oeq float %3207, 0.000000e+00
  %3223 = call float @llvm.fabs.f32(float %3199)
  %3224 = fcmp olt float %3223, +inf
  %3225 = and i1 %3222, %3224
  %3226 = select i1 %3225, float 0.000000e+00, float %3221
  br label %3227

3227:                                             ; preds = %3214, %3215
  %3228 = phi float [ %3226, %3215 ], [ %3208, %3214 ]
  br label %3229

3229:                                             ; preds = %3227
  %3230 = add i64 %91, %57
  %3231 = icmp slt i64 %3230, %26
  %3232 = select i1 %3231, i64 %3230, i64 0
  %3233 = extractelement <8 x float> %3160, i64 2
  %3234 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3235 = getelementptr inbounds nuw i8, ptr %3234, i64 %3232
  %3236 = load i8, ptr %3235, align 1
  %3237 = zext i8 %3236 to i32
  %3238 = shl i32 %3237, 23
  %3239 = bitcast i32 %3238 to float
  %3240 = fmul float %3239, %3233
  %3241 = extractelement <8 x float> %165, i64 2
  %3242 = fmul float %3241, %3240
  %3243 = call float @llvm.fabs.f32(float %3240)
  %3244 = fcmp olt float %3243, +inf
  %3245 = fcmp one float %3240, 0.000000e+00
  %3246 = and i1 %3244, %3245
  %3247 = call i1 @llvm.expect.i1(i1 %3246, i1 true)
  br i1 %3247, label %3248, label %3249

3248:                                             ; preds = %3229
  br label %3261

3249:                                             ; preds = %3229
  %3250 = fpext float %3241 to double
  %3251 = fpext float %3239 to double
  %3252 = fpext float %3233 to double
  %3253 = fmul double %3250, %3251
  %3254 = fmul double %3253, %3252
  %3255 = fptrunc double %3254 to float
  %3256 = fcmp oeq float %3241, 0.000000e+00
  %3257 = call float @llvm.fabs.f32(float %3233)
  %3258 = fcmp olt float %3257, +inf
  %3259 = and i1 %3256, %3258
  %3260 = select i1 %3259, float 0.000000e+00, float %3255
  br label %3261

3261:                                             ; preds = %3248, %3249
  %3262 = phi float [ %3260, %3249 ], [ %3242, %3248 ]
  br label %3263

3263:                                             ; preds = %3261
  %3264 = add i64 %91, %57
  %3265 = icmp slt i64 %3264, %26
  %3266 = select i1 %3265, i64 %3264, i64 0
  %3267 = extractelement <8 x float> %3160, i64 3
  %3268 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3269 = getelementptr inbounds nuw i8, ptr %3268, i64 %3266
  %3270 = load i8, ptr %3269, align 1
  %3271 = zext i8 %3270 to i32
  %3272 = shl i32 %3271, 23
  %3273 = bitcast i32 %3272 to float
  %3274 = fmul float %3273, %3267
  %3275 = extractelement <8 x float> %165, i64 3
  %3276 = fmul float %3275, %3274
  %3277 = call float @llvm.fabs.f32(float %3274)
  %3278 = fcmp olt float %3277, +inf
  %3279 = fcmp one float %3274, 0.000000e+00
  %3280 = and i1 %3278, %3279
  %3281 = call i1 @llvm.expect.i1(i1 %3280, i1 true)
  br i1 %3281, label %3282, label %3283

3282:                                             ; preds = %3263
  br label %3295

3283:                                             ; preds = %3263
  %3284 = fpext float %3275 to double
  %3285 = fpext float %3273 to double
  %3286 = fpext float %3267 to double
  %3287 = fmul double %3284, %3285
  %3288 = fmul double %3287, %3286
  %3289 = fptrunc double %3288 to float
  %3290 = fcmp oeq float %3275, 0.000000e+00
  %3291 = call float @llvm.fabs.f32(float %3267)
  %3292 = fcmp olt float %3291, +inf
  %3293 = and i1 %3290, %3292
  %3294 = select i1 %3293, float 0.000000e+00, float %3289
  br label %3295

3295:                                             ; preds = %3282, %3283
  %3296 = phi float [ %3294, %3283 ], [ %3276, %3282 ]
  br label %3297

3297:                                             ; preds = %3295
  %3298 = add i64 %91, %57
  %3299 = icmp slt i64 %3298, %26
  %3300 = select i1 %3299, i64 %3298, i64 0
  %3301 = extractelement <8 x float> %3160, i64 4
  %3302 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3303 = getelementptr inbounds nuw i8, ptr %3302, i64 %3300
  %3304 = load i8, ptr %3303, align 1
  %3305 = zext i8 %3304 to i32
  %3306 = shl i32 %3305, 23
  %3307 = bitcast i32 %3306 to float
  %3308 = fmul float %3307, %3301
  %3309 = extractelement <8 x float> %165, i64 4
  %3310 = fmul float %3309, %3308
  %3311 = call float @llvm.fabs.f32(float %3308)
  %3312 = fcmp olt float %3311, +inf
  %3313 = fcmp one float %3308, 0.000000e+00
  %3314 = and i1 %3312, %3313
  %3315 = call i1 @llvm.expect.i1(i1 %3314, i1 true)
  br i1 %3315, label %3316, label %3317

3316:                                             ; preds = %3297
  br label %3329

3317:                                             ; preds = %3297
  %3318 = fpext float %3309 to double
  %3319 = fpext float %3307 to double
  %3320 = fpext float %3301 to double
  %3321 = fmul double %3318, %3319
  %3322 = fmul double %3321, %3320
  %3323 = fptrunc double %3322 to float
  %3324 = fcmp oeq float %3309, 0.000000e+00
  %3325 = call float @llvm.fabs.f32(float %3301)
  %3326 = fcmp olt float %3325, +inf
  %3327 = and i1 %3324, %3326
  %3328 = select i1 %3327, float 0.000000e+00, float %3323
  br label %3329

3329:                                             ; preds = %3316, %3317
  %3330 = phi float [ %3328, %3317 ], [ %3310, %3316 ]
  br label %3331

3331:                                             ; preds = %3329
  %3332 = add i64 %91, %57
  %3333 = icmp slt i64 %3332, %26
  %3334 = select i1 %3333, i64 %3332, i64 0
  %3335 = extractelement <8 x float> %3160, i64 5
  %3336 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3337 = getelementptr inbounds nuw i8, ptr %3336, i64 %3334
  %3338 = load i8, ptr %3337, align 1
  %3339 = zext i8 %3338 to i32
  %3340 = shl i32 %3339, 23
  %3341 = bitcast i32 %3340 to float
  %3342 = fmul float %3341, %3335
  %3343 = extractelement <8 x float> %165, i64 5
  %3344 = fmul float %3343, %3342
  %3345 = call float @llvm.fabs.f32(float %3342)
  %3346 = fcmp olt float %3345, +inf
  %3347 = fcmp one float %3342, 0.000000e+00
  %3348 = and i1 %3346, %3347
  %3349 = call i1 @llvm.expect.i1(i1 %3348, i1 true)
  br i1 %3349, label %3350, label %3351

3350:                                             ; preds = %3331
  br label %3363

3351:                                             ; preds = %3331
  %3352 = fpext float %3343 to double
  %3353 = fpext float %3341 to double
  %3354 = fpext float %3335 to double
  %3355 = fmul double %3352, %3353
  %3356 = fmul double %3355, %3354
  %3357 = fptrunc double %3356 to float
  %3358 = fcmp oeq float %3343, 0.000000e+00
  %3359 = call float @llvm.fabs.f32(float %3335)
  %3360 = fcmp olt float %3359, +inf
  %3361 = and i1 %3358, %3360
  %3362 = select i1 %3361, float 0.000000e+00, float %3357
  br label %3363

3363:                                             ; preds = %3350, %3351
  %3364 = phi float [ %3362, %3351 ], [ %3344, %3350 ]
  br label %3365

3365:                                             ; preds = %3363
  %3366 = add i64 %91, %57
  %3367 = icmp slt i64 %3366, %26
  %3368 = select i1 %3367, i64 %3366, i64 0
  %3369 = extractelement <8 x float> %3160, i64 6
  %3370 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3371 = getelementptr inbounds nuw i8, ptr %3370, i64 %3368
  %3372 = load i8, ptr %3371, align 1
  %3373 = zext i8 %3372 to i32
  %3374 = shl i32 %3373, 23
  %3375 = bitcast i32 %3374 to float
  %3376 = fmul float %3375, %3369
  %3377 = extractelement <8 x float> %165, i64 6
  %3378 = fmul float %3377, %3376
  %3379 = call float @llvm.fabs.f32(float %3376)
  %3380 = fcmp olt float %3379, +inf
  %3381 = fcmp one float %3376, 0.000000e+00
  %3382 = and i1 %3380, %3381
  %3383 = call i1 @llvm.expect.i1(i1 %3382, i1 true)
  br i1 %3383, label %3384, label %3385

3384:                                             ; preds = %3365
  br label %3397

3385:                                             ; preds = %3365
  %3386 = fpext float %3377 to double
  %3387 = fpext float %3375 to double
  %3388 = fpext float %3369 to double
  %3389 = fmul double %3386, %3387
  %3390 = fmul double %3389, %3388
  %3391 = fptrunc double %3390 to float
  %3392 = fcmp oeq float %3377, 0.000000e+00
  %3393 = call float @llvm.fabs.f32(float %3369)
  %3394 = fcmp olt float %3393, +inf
  %3395 = and i1 %3392, %3394
  %3396 = select i1 %3395, float 0.000000e+00, float %3391
  br label %3397

3397:                                             ; preds = %3384, %3385
  %3398 = phi float [ %3396, %3385 ], [ %3378, %3384 ]
  br label %3399

3399:                                             ; preds = %3397
  %3400 = add i64 %91, %57
  %3401 = icmp slt i64 %3400, %26
  %3402 = select i1 %3401, i64 %3400, i64 0
  %3403 = extractelement <8 x float> %3160, i64 7
  %3404 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3405 = getelementptr inbounds nuw i8, ptr %3404, i64 %3402
  %3406 = load i8, ptr %3405, align 1
  %3407 = zext i8 %3406 to i32
  %3408 = shl i32 %3407, 23
  %3409 = bitcast i32 %3408 to float
  %3410 = fmul float %3409, %3403
  %3411 = extractelement <8 x float> %165, i64 7
  %3412 = fmul float %3411, %3410
  %3413 = call float @llvm.fabs.f32(float %3410)
  %3414 = fcmp olt float %3413, +inf
  %3415 = fcmp one float %3410, 0.000000e+00
  %3416 = and i1 %3414, %3415
  %3417 = call i1 @llvm.expect.i1(i1 %3416, i1 true)
  br i1 %3417, label %3418, label %3419

3418:                                             ; preds = %3399
  br label %3431

3419:                                             ; preds = %3399
  %3420 = fpext float %3411 to double
  %3421 = fpext float %3409 to double
  %3422 = fpext float %3403 to double
  %3423 = fmul double %3420, %3421
  %3424 = fmul double %3423, %3422
  %3425 = fptrunc double %3424 to float
  %3426 = fcmp oeq float %3411, 0.000000e+00
  %3427 = call float @llvm.fabs.f32(float %3403)
  %3428 = fcmp olt float %3427, +inf
  %3429 = and i1 %3426, %3428
  %3430 = select i1 %3429, float 0.000000e+00, float %3425
  br label %3431

3431:                                             ; preds = %3418, %3419
  %3432 = phi float [ %3430, %3419 ], [ %3412, %3418 ]
  br label %3433

3433:                                             ; preds = %3431
  %3434 = mul i64 %58, 8
  %3435 = add i64 %86, %3434
  %3436 = add i64 %91, %57
  %3437 = mul i64 %3435, %26
  %3438 = add i64 %3437, %3436
  %3439 = fptrunc float %3194 to bfloat
  %3440 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3441 = getelementptr inbounds nuw bfloat, ptr %3440, i64 %3438
  store bfloat %3439, ptr %3441, align 2
  %3442 = mul i64 %58, 8
  %3443 = add i64 %3442, 1
  %3444 = add i64 %86, %3443
  %3445 = add i64 %91, %57
  %3446 = mul i64 %3444, %26
  %3447 = add i64 %3446, %3445
  %3448 = fptrunc float %3228 to bfloat
  %3449 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3450 = getelementptr inbounds nuw bfloat, ptr %3449, i64 %3447
  store bfloat %3448, ptr %3450, align 2
  %3451 = mul i64 %58, 8
  %3452 = add i64 %3451, 2
  %3453 = add i64 %86, %3452
  %3454 = add i64 %91, %57
  %3455 = mul i64 %3453, %26
  %3456 = add i64 %3455, %3454
  %3457 = fptrunc float %3262 to bfloat
  %3458 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3459 = getelementptr inbounds nuw bfloat, ptr %3458, i64 %3456
  store bfloat %3457, ptr %3459, align 2
  %3460 = mul i64 %58, 8
  %3461 = add i64 %3460, 3
  %3462 = add i64 %86, %3461
  %3463 = add i64 %91, %57
  %3464 = mul i64 %3462, %26
  %3465 = add i64 %3464, %3463
  %3466 = fptrunc float %3296 to bfloat
  %3467 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3468 = getelementptr inbounds nuw bfloat, ptr %3467, i64 %3465
  store bfloat %3466, ptr %3468, align 2
  %3469 = mul i64 %58, 8
  %3470 = add i64 %3469, 4
  %3471 = add i64 %86, %3470
  %3472 = add i64 %91, %57
  %3473 = mul i64 %3471, %26
  %3474 = add i64 %3473, %3472
  %3475 = fptrunc float %3330 to bfloat
  %3476 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3477 = getelementptr inbounds nuw bfloat, ptr %3476, i64 %3474
  store bfloat %3475, ptr %3477, align 2
  %3478 = mul i64 %58, 8
  %3479 = add i64 %3478, 5
  %3480 = add i64 %86, %3479
  %3481 = add i64 %91, %57
  %3482 = mul i64 %3480, %26
  %3483 = add i64 %3482, %3481
  %3484 = fptrunc float %3364 to bfloat
  %3485 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3486 = getelementptr inbounds nuw bfloat, ptr %3485, i64 %3483
  store bfloat %3484, ptr %3486, align 2
  %3487 = mul i64 %58, 8
  %3488 = add i64 %3487, 6
  %3489 = add i64 %86, %3488
  %3490 = add i64 %91, %57
  %3491 = mul i64 %3489, %26
  %3492 = add i64 %3491, %3490
  %3493 = fptrunc float %3398 to bfloat
  %3494 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3495 = getelementptr inbounds nuw bfloat, ptr %3494, i64 %3492
  store bfloat %3493, ptr %3495, align 2
  %3496 = mul i64 %58, 8
  %3497 = add i64 %3496, 7
  %3498 = add i64 %86, %3497
  %3499 = add i64 %91, %57
  %3500 = mul i64 %3498, %26
  %3501 = add i64 %3500, %3499
  %3502 = fptrunc float %3432 to bfloat
  %3503 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3504 = getelementptr inbounds nuw bfloat, ptr %3503, i64 %3501
  store bfloat %3502, ptr %3504, align 2
  %3505 = mul i64 %58, 8
  %3506 = add i64 %88, %3505
  %3507 = add i64 %91, %57
  %3508 = add i64 %3506, 7
  %3509 = icmp ult i64 %3507, %26
  %3510 = icmp ult i64 %3508, %25
  %3511 = and i1 %3510, %3509
  %3512 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3513 = ptrtoint ptr %3512 to i64
  %3514 = mul i64 %3506, 4
  %3515 = add i64 %3513, %3514
  %3516 = urem i64 %3515, 16
  %3517 = icmp eq i64 %3516, 0
  %3518 = and i1 %3511, %3517
  br i1 %3518, label %3519, label %3528

3519:                                             ; preds = %3433
  %3520 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3521 = getelementptr float, ptr %3520, i64 %3506
  %3522 = load <4 x float>, ptr %3521, align 16
  %3523 = add i64 %3506, 4
  %3524 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3525 = getelementptr float, ptr %3524, i64 %3523
  %3526 = load <4 x float>, ptr %3525, align 16
  %3527 = shufflevector <4 x float> %3522, <4 x float> %3526, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3600

3528:                                             ; preds = %3433
  %3529 = mul i64 %58, 8
  %3530 = add i64 %88, %3529
  %3531 = icmp slt i64 %3530, %25
  %3532 = select i1 %3531, i64 %3530, i64 0
  %3533 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3534 = getelementptr inbounds nuw float, ptr %3533, i64 %3532
  %3535 = load float, ptr %3534, align 4
  %3536 = insertelement <8 x float> zeroinitializer, float %3535, i64 0
  %3537 = mul i64 %58, 8
  %3538 = add i64 %3537, 1
  %3539 = add i64 %88, %3538
  %3540 = icmp slt i64 %3539, %25
  %3541 = select i1 %3540, i64 %3539, i64 0
  %3542 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3543 = getelementptr inbounds nuw float, ptr %3542, i64 %3541
  %3544 = load float, ptr %3543, align 4
  %3545 = insertelement <8 x float> %3536, float %3544, i64 1
  %3546 = mul i64 %58, 8
  %3547 = add i64 %3546, 2
  %3548 = add i64 %88, %3547
  %3549 = icmp slt i64 %3548, %25
  %3550 = select i1 %3549, i64 %3548, i64 0
  %3551 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3552 = getelementptr inbounds nuw float, ptr %3551, i64 %3550
  %3553 = load float, ptr %3552, align 4
  %3554 = insertelement <8 x float> %3545, float %3553, i64 2
  %3555 = mul i64 %58, 8
  %3556 = add i64 %3555, 3
  %3557 = add i64 %88, %3556
  %3558 = icmp slt i64 %3557, %25
  %3559 = select i1 %3558, i64 %3557, i64 0
  %3560 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3561 = getelementptr inbounds nuw float, ptr %3560, i64 %3559
  %3562 = load float, ptr %3561, align 4
  %3563 = insertelement <8 x float> %3554, float %3562, i64 3
  %3564 = mul i64 %58, 8
  %3565 = add i64 %3564, 4
  %3566 = add i64 %88, %3565
  %3567 = icmp slt i64 %3566, %25
  %3568 = select i1 %3567, i64 %3566, i64 0
  %3569 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3570 = getelementptr inbounds nuw float, ptr %3569, i64 %3568
  %3571 = load float, ptr %3570, align 4
  %3572 = insertelement <8 x float> %3563, float %3571, i64 4
  %3573 = mul i64 %58, 8
  %3574 = add i64 %3573, 5
  %3575 = add i64 %88, %3574
  %3576 = icmp slt i64 %3575, %25
  %3577 = select i1 %3576, i64 %3575, i64 0
  %3578 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3579 = getelementptr inbounds nuw float, ptr %3578, i64 %3577
  %3580 = load float, ptr %3579, align 4
  %3581 = insertelement <8 x float> %3572, float %3580, i64 5
  %3582 = mul i64 %58, 8
  %3583 = add i64 %3582, 6
  %3584 = add i64 %88, %3583
  %3585 = icmp slt i64 %3584, %25
  %3586 = select i1 %3585, i64 %3584, i64 0
  %3587 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3588 = getelementptr inbounds nuw float, ptr %3587, i64 %3586
  %3589 = load float, ptr %3588, align 4
  %3590 = insertelement <8 x float> %3581, float %3589, i64 6
  %3591 = mul i64 %58, 8
  %3592 = add i64 %3591, 7
  %3593 = add i64 %88, %3592
  %3594 = icmp slt i64 %3593, %25
  %3595 = select i1 %3594, i64 %3593, i64 0
  %3596 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3597 = getelementptr inbounds nuw float, ptr %3596, i64 %3595
  %3598 = load float, ptr %3597, align 4
  %3599 = insertelement <8 x float> %3590, float %3598, i64 7
  br label %3600

3600:                                             ; preds = %3519, %3528
  %3601 = phi <8 x float> [ %3599, %3528 ], [ %3527, %3519 ]
  br label %3602

3602:                                             ; preds = %3600
  %3603 = add i64 %91, %57
  %3604 = icmp slt i64 %3603, %26
  %3605 = select i1 %3604, i64 %3603, i64 0
  %3606 = extractelement <8 x float> %3601, i64 0
  %3607 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3608 = getelementptr inbounds nuw i8, ptr %3607, i64 %3605
  %3609 = load i8, ptr %3608, align 1
  %3610 = zext i8 %3609 to i32
  %3611 = shl i32 %3610, 23
  %3612 = bitcast i32 %3611 to float
  %3613 = fmul float %3612, %3606
  %3614 = extractelement <8 x float> %167, i64 0
  %3615 = fmul float %3614, %3613
  %3616 = call float @llvm.fabs.f32(float %3613)
  %3617 = fcmp olt float %3616, +inf
  %3618 = fcmp one float %3613, 0.000000e+00
  %3619 = and i1 %3617, %3618
  %3620 = call i1 @llvm.expect.i1(i1 %3619, i1 true)
  br i1 %3620, label %3621, label %3622

3621:                                             ; preds = %3602
  br label %3634

3622:                                             ; preds = %3602
  %3623 = fpext float %3614 to double
  %3624 = fpext float %3612 to double
  %3625 = fpext float %3606 to double
  %3626 = fmul double %3623, %3624
  %3627 = fmul double %3626, %3625
  %3628 = fptrunc double %3627 to float
  %3629 = fcmp oeq float %3614, 0.000000e+00
  %3630 = call float @llvm.fabs.f32(float %3606)
  %3631 = fcmp olt float %3630, +inf
  %3632 = and i1 %3629, %3631
  %3633 = select i1 %3632, float 0.000000e+00, float %3628
  br label %3634

3634:                                             ; preds = %3621, %3622
  %3635 = phi float [ %3633, %3622 ], [ %3615, %3621 ]
  br label %3636

3636:                                             ; preds = %3634
  %3637 = add i64 %91, %57
  %3638 = icmp slt i64 %3637, %26
  %3639 = select i1 %3638, i64 %3637, i64 0
  %3640 = extractelement <8 x float> %3601, i64 1
  %3641 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3642 = getelementptr inbounds nuw i8, ptr %3641, i64 %3639
  %3643 = load i8, ptr %3642, align 1
  %3644 = zext i8 %3643 to i32
  %3645 = shl i32 %3644, 23
  %3646 = bitcast i32 %3645 to float
  %3647 = fmul float %3646, %3640
  %3648 = extractelement <8 x float> %167, i64 1
  %3649 = fmul float %3648, %3647
  %3650 = call float @llvm.fabs.f32(float %3647)
  %3651 = fcmp olt float %3650, +inf
  %3652 = fcmp one float %3647, 0.000000e+00
  %3653 = and i1 %3651, %3652
  %3654 = call i1 @llvm.expect.i1(i1 %3653, i1 true)
  br i1 %3654, label %3655, label %3656

3655:                                             ; preds = %3636
  br label %3668

3656:                                             ; preds = %3636
  %3657 = fpext float %3648 to double
  %3658 = fpext float %3646 to double
  %3659 = fpext float %3640 to double
  %3660 = fmul double %3657, %3658
  %3661 = fmul double %3660, %3659
  %3662 = fptrunc double %3661 to float
  %3663 = fcmp oeq float %3648, 0.000000e+00
  %3664 = call float @llvm.fabs.f32(float %3640)
  %3665 = fcmp olt float %3664, +inf
  %3666 = and i1 %3663, %3665
  %3667 = select i1 %3666, float 0.000000e+00, float %3662
  br label %3668

3668:                                             ; preds = %3655, %3656
  %3669 = phi float [ %3667, %3656 ], [ %3649, %3655 ]
  br label %3670

3670:                                             ; preds = %3668
  %3671 = add i64 %91, %57
  %3672 = icmp slt i64 %3671, %26
  %3673 = select i1 %3672, i64 %3671, i64 0
  %3674 = extractelement <8 x float> %3601, i64 2
  %3675 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3676 = getelementptr inbounds nuw i8, ptr %3675, i64 %3673
  %3677 = load i8, ptr %3676, align 1
  %3678 = zext i8 %3677 to i32
  %3679 = shl i32 %3678, 23
  %3680 = bitcast i32 %3679 to float
  %3681 = fmul float %3680, %3674
  %3682 = extractelement <8 x float> %167, i64 2
  %3683 = fmul float %3682, %3681
  %3684 = call float @llvm.fabs.f32(float %3681)
  %3685 = fcmp olt float %3684, +inf
  %3686 = fcmp one float %3681, 0.000000e+00
  %3687 = and i1 %3685, %3686
  %3688 = call i1 @llvm.expect.i1(i1 %3687, i1 true)
  br i1 %3688, label %3689, label %3690

3689:                                             ; preds = %3670
  br label %3702

3690:                                             ; preds = %3670
  %3691 = fpext float %3682 to double
  %3692 = fpext float %3680 to double
  %3693 = fpext float %3674 to double
  %3694 = fmul double %3691, %3692
  %3695 = fmul double %3694, %3693
  %3696 = fptrunc double %3695 to float
  %3697 = fcmp oeq float %3682, 0.000000e+00
  %3698 = call float @llvm.fabs.f32(float %3674)
  %3699 = fcmp olt float %3698, +inf
  %3700 = and i1 %3697, %3699
  %3701 = select i1 %3700, float 0.000000e+00, float %3696
  br label %3702

3702:                                             ; preds = %3689, %3690
  %3703 = phi float [ %3701, %3690 ], [ %3683, %3689 ]
  br label %3704

3704:                                             ; preds = %3702
  %3705 = add i64 %91, %57
  %3706 = icmp slt i64 %3705, %26
  %3707 = select i1 %3706, i64 %3705, i64 0
  %3708 = extractelement <8 x float> %3601, i64 3
  %3709 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3710 = getelementptr inbounds nuw i8, ptr %3709, i64 %3707
  %3711 = load i8, ptr %3710, align 1
  %3712 = zext i8 %3711 to i32
  %3713 = shl i32 %3712, 23
  %3714 = bitcast i32 %3713 to float
  %3715 = fmul float %3714, %3708
  %3716 = extractelement <8 x float> %167, i64 3
  %3717 = fmul float %3716, %3715
  %3718 = call float @llvm.fabs.f32(float %3715)
  %3719 = fcmp olt float %3718, +inf
  %3720 = fcmp one float %3715, 0.000000e+00
  %3721 = and i1 %3719, %3720
  %3722 = call i1 @llvm.expect.i1(i1 %3721, i1 true)
  br i1 %3722, label %3723, label %3724

3723:                                             ; preds = %3704
  br label %3736

3724:                                             ; preds = %3704
  %3725 = fpext float %3716 to double
  %3726 = fpext float %3714 to double
  %3727 = fpext float %3708 to double
  %3728 = fmul double %3725, %3726
  %3729 = fmul double %3728, %3727
  %3730 = fptrunc double %3729 to float
  %3731 = fcmp oeq float %3716, 0.000000e+00
  %3732 = call float @llvm.fabs.f32(float %3708)
  %3733 = fcmp olt float %3732, +inf
  %3734 = and i1 %3731, %3733
  %3735 = select i1 %3734, float 0.000000e+00, float %3730
  br label %3736

3736:                                             ; preds = %3723, %3724
  %3737 = phi float [ %3735, %3724 ], [ %3717, %3723 ]
  br label %3738

3738:                                             ; preds = %3736
  %3739 = add i64 %91, %57
  %3740 = icmp slt i64 %3739, %26
  %3741 = select i1 %3740, i64 %3739, i64 0
  %3742 = extractelement <8 x float> %3601, i64 4
  %3743 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3744 = getelementptr inbounds nuw i8, ptr %3743, i64 %3741
  %3745 = load i8, ptr %3744, align 1
  %3746 = zext i8 %3745 to i32
  %3747 = shl i32 %3746, 23
  %3748 = bitcast i32 %3747 to float
  %3749 = fmul float %3748, %3742
  %3750 = extractelement <8 x float> %167, i64 4
  %3751 = fmul float %3750, %3749
  %3752 = call float @llvm.fabs.f32(float %3749)
  %3753 = fcmp olt float %3752, +inf
  %3754 = fcmp one float %3749, 0.000000e+00
  %3755 = and i1 %3753, %3754
  %3756 = call i1 @llvm.expect.i1(i1 %3755, i1 true)
  br i1 %3756, label %3757, label %3758

3757:                                             ; preds = %3738
  br label %3770

3758:                                             ; preds = %3738
  %3759 = fpext float %3750 to double
  %3760 = fpext float %3748 to double
  %3761 = fpext float %3742 to double
  %3762 = fmul double %3759, %3760
  %3763 = fmul double %3762, %3761
  %3764 = fptrunc double %3763 to float
  %3765 = fcmp oeq float %3750, 0.000000e+00
  %3766 = call float @llvm.fabs.f32(float %3742)
  %3767 = fcmp olt float %3766, +inf
  %3768 = and i1 %3765, %3767
  %3769 = select i1 %3768, float 0.000000e+00, float %3764
  br label %3770

3770:                                             ; preds = %3757, %3758
  %3771 = phi float [ %3769, %3758 ], [ %3751, %3757 ]
  br label %3772

3772:                                             ; preds = %3770
  %3773 = add i64 %91, %57
  %3774 = icmp slt i64 %3773, %26
  %3775 = select i1 %3774, i64 %3773, i64 0
  %3776 = extractelement <8 x float> %3601, i64 5
  %3777 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3778 = getelementptr inbounds nuw i8, ptr %3777, i64 %3775
  %3779 = load i8, ptr %3778, align 1
  %3780 = zext i8 %3779 to i32
  %3781 = shl i32 %3780, 23
  %3782 = bitcast i32 %3781 to float
  %3783 = fmul float %3782, %3776
  %3784 = extractelement <8 x float> %167, i64 5
  %3785 = fmul float %3784, %3783
  %3786 = call float @llvm.fabs.f32(float %3783)
  %3787 = fcmp olt float %3786, +inf
  %3788 = fcmp one float %3783, 0.000000e+00
  %3789 = and i1 %3787, %3788
  %3790 = call i1 @llvm.expect.i1(i1 %3789, i1 true)
  br i1 %3790, label %3791, label %3792

3791:                                             ; preds = %3772
  br label %3804

3792:                                             ; preds = %3772
  %3793 = fpext float %3784 to double
  %3794 = fpext float %3782 to double
  %3795 = fpext float %3776 to double
  %3796 = fmul double %3793, %3794
  %3797 = fmul double %3796, %3795
  %3798 = fptrunc double %3797 to float
  %3799 = fcmp oeq float %3784, 0.000000e+00
  %3800 = call float @llvm.fabs.f32(float %3776)
  %3801 = fcmp olt float %3800, +inf
  %3802 = and i1 %3799, %3801
  %3803 = select i1 %3802, float 0.000000e+00, float %3798
  br label %3804

3804:                                             ; preds = %3791, %3792
  %3805 = phi float [ %3803, %3792 ], [ %3785, %3791 ]
  br label %3806

3806:                                             ; preds = %3804
  %3807 = add i64 %91, %57
  %3808 = icmp slt i64 %3807, %26
  %3809 = select i1 %3808, i64 %3807, i64 0
  %3810 = extractelement <8 x float> %3601, i64 6
  %3811 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3812 = getelementptr inbounds nuw i8, ptr %3811, i64 %3809
  %3813 = load i8, ptr %3812, align 1
  %3814 = zext i8 %3813 to i32
  %3815 = shl i32 %3814, 23
  %3816 = bitcast i32 %3815 to float
  %3817 = fmul float %3816, %3810
  %3818 = extractelement <8 x float> %167, i64 6
  %3819 = fmul float %3818, %3817
  %3820 = call float @llvm.fabs.f32(float %3817)
  %3821 = fcmp olt float %3820, +inf
  %3822 = fcmp one float %3817, 0.000000e+00
  %3823 = and i1 %3821, %3822
  %3824 = call i1 @llvm.expect.i1(i1 %3823, i1 true)
  br i1 %3824, label %3825, label %3826

3825:                                             ; preds = %3806
  br label %3838

3826:                                             ; preds = %3806
  %3827 = fpext float %3818 to double
  %3828 = fpext float %3816 to double
  %3829 = fpext float %3810 to double
  %3830 = fmul double %3827, %3828
  %3831 = fmul double %3830, %3829
  %3832 = fptrunc double %3831 to float
  %3833 = fcmp oeq float %3818, 0.000000e+00
  %3834 = call float @llvm.fabs.f32(float %3810)
  %3835 = fcmp olt float %3834, +inf
  %3836 = and i1 %3833, %3835
  %3837 = select i1 %3836, float 0.000000e+00, float %3832
  br label %3838

3838:                                             ; preds = %3825, %3826
  %3839 = phi float [ %3837, %3826 ], [ %3819, %3825 ]
  br label %3840

3840:                                             ; preds = %3838
  %3841 = add i64 %91, %57
  %3842 = icmp slt i64 %3841, %26
  %3843 = select i1 %3842, i64 %3841, i64 0
  %3844 = extractelement <8 x float> %3601, i64 7
  %3845 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3846 = getelementptr inbounds nuw i8, ptr %3845, i64 %3843
  %3847 = load i8, ptr %3846, align 1
  %3848 = zext i8 %3847 to i32
  %3849 = shl i32 %3848, 23
  %3850 = bitcast i32 %3849 to float
  %3851 = fmul float %3850, %3844
  %3852 = extractelement <8 x float> %167, i64 7
  %3853 = fmul float %3852, %3851
  %3854 = call float @llvm.fabs.f32(float %3851)
  %3855 = fcmp olt float %3854, +inf
  %3856 = fcmp one float %3851, 0.000000e+00
  %3857 = and i1 %3855, %3856
  %3858 = call i1 @llvm.expect.i1(i1 %3857, i1 true)
  br i1 %3858, label %3859, label %3860

3859:                                             ; preds = %3840
  br label %3872

3860:                                             ; preds = %3840
  %3861 = fpext float %3852 to double
  %3862 = fpext float %3850 to double
  %3863 = fpext float %3844 to double
  %3864 = fmul double %3861, %3862
  %3865 = fmul double %3864, %3863
  %3866 = fptrunc double %3865 to float
  %3867 = fcmp oeq float %3852, 0.000000e+00
  %3868 = call float @llvm.fabs.f32(float %3844)
  %3869 = fcmp olt float %3868, +inf
  %3870 = and i1 %3867, %3869
  %3871 = select i1 %3870, float 0.000000e+00, float %3866
  br label %3872

3872:                                             ; preds = %3859, %3860
  %3873 = phi float [ %3871, %3860 ], [ %3853, %3859 ]
  br label %3874

3874:                                             ; preds = %3872
  %3875 = mul i64 %58, 8
  %3876 = add i64 %88, %3875
  %3877 = add i64 %91, %57
  %3878 = mul i64 %3876, %26
  %3879 = add i64 %3878, %3877
  %3880 = fptrunc float %3635 to bfloat
  %3881 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3882 = getelementptr inbounds nuw bfloat, ptr %3881, i64 %3879
  store bfloat %3880, ptr %3882, align 2
  %3883 = mul i64 %58, 8
  %3884 = add i64 %3883, 1
  %3885 = add i64 %88, %3884
  %3886 = add i64 %91, %57
  %3887 = mul i64 %3885, %26
  %3888 = add i64 %3887, %3886
  %3889 = fptrunc float %3669 to bfloat
  %3890 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3891 = getelementptr inbounds nuw bfloat, ptr %3890, i64 %3888
  store bfloat %3889, ptr %3891, align 2
  %3892 = mul i64 %58, 8
  %3893 = add i64 %3892, 2
  %3894 = add i64 %88, %3893
  %3895 = add i64 %91, %57
  %3896 = mul i64 %3894, %26
  %3897 = add i64 %3896, %3895
  %3898 = fptrunc float %3703 to bfloat
  %3899 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3900 = getelementptr inbounds nuw bfloat, ptr %3899, i64 %3897
  store bfloat %3898, ptr %3900, align 2
  %3901 = mul i64 %58, 8
  %3902 = add i64 %3901, 3
  %3903 = add i64 %88, %3902
  %3904 = add i64 %91, %57
  %3905 = mul i64 %3903, %26
  %3906 = add i64 %3905, %3904
  %3907 = fptrunc float %3737 to bfloat
  %3908 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3909 = getelementptr inbounds nuw bfloat, ptr %3908, i64 %3906
  store bfloat %3907, ptr %3909, align 2
  %3910 = mul i64 %58, 8
  %3911 = add i64 %3910, 4
  %3912 = add i64 %88, %3911
  %3913 = add i64 %91, %57
  %3914 = mul i64 %3912, %26
  %3915 = add i64 %3914, %3913
  %3916 = fptrunc float %3771 to bfloat
  %3917 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3918 = getelementptr inbounds nuw bfloat, ptr %3917, i64 %3915
  store bfloat %3916, ptr %3918, align 2
  %3919 = mul i64 %58, 8
  %3920 = add i64 %3919, 5
  %3921 = add i64 %88, %3920
  %3922 = add i64 %91, %57
  %3923 = mul i64 %3921, %26
  %3924 = add i64 %3923, %3922
  %3925 = fptrunc float %3805 to bfloat
  %3926 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3927 = getelementptr inbounds nuw bfloat, ptr %3926, i64 %3924
  store bfloat %3925, ptr %3927, align 2
  %3928 = mul i64 %58, 8
  %3929 = add i64 %3928, 6
  %3930 = add i64 %88, %3929
  %3931 = add i64 %91, %57
  %3932 = mul i64 %3930, %26
  %3933 = add i64 %3932, %3931
  %3934 = fptrunc float %3839 to bfloat
  %3935 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3936 = getelementptr inbounds nuw bfloat, ptr %3935, i64 %3933
  store bfloat %3934, ptr %3936, align 2
  %3937 = mul i64 %58, 8
  %3938 = add i64 %3937, 7
  %3939 = add i64 %88, %3938
  %3940 = add i64 %91, %57
  %3941 = mul i64 %3939, %26
  %3942 = add i64 %3941, %3940
  %3943 = fptrunc float %3873 to bfloat
  %3944 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3945 = getelementptr inbounds nuw bfloat, ptr %3944, i64 %3942
  store bfloat %3943, ptr %3945, align 2
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.expect.i1(i1, i1) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #4

; Function Attrs: convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #6

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.sched.barrier(i32 immarg) #3

attributes #0 = { "amdgpu-flat-work-group-size"="256,256" "target-features"="-cumode" "uniform-work-group-size" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { convergent nocallback nofree nounwind willreturn }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #6 = { convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
