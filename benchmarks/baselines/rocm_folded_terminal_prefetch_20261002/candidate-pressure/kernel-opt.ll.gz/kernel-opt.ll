; ModuleID = 'benchmarks/baselines/rocm_folded_terminal_prefetch_20261002/candidate-pressure/kernel.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"
target triple = "amdgcn-amd-amdhsa"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal unnamed_addr addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal unnamed_addr addrspace(3) global [5120 x i8] undef

; Function Attrs: norecurse nounwind
define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr nofree readnone captures(none) %0, ptr nofree readonly captures(none) %1, i64 %2, i64 %3, i64 %4, ptr nofree readnone captures(none) %5, ptr nofree readonly captures(none) %6, i64 %7, i64 %8, i64 %9, ptr nofree readnone captures(none) %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr nofree readnone captures(none) %15, ptr nofree readonly captures(none) %16, i64 %17, i64 %18, i64 %19, ptr nofree readnone captures(none) %20, ptr nofree writeonly %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) local_unnamed_addr #0 !reqd_work_group_size !1 {
  %29 = addrspacecast ptr %21 to ptr addrspace(1)
  %30 = addrspacecast ptr %16 to ptr addrspace(1)
  %31 = addrspacecast ptr %11 to ptr addrspace(1)
  %32 = addrspacecast ptr %6 to ptr addrspace(1)
  %33 = addrspacecast ptr %1 to ptr addrspace(1)
  %34 = tail call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %35 = zext nneg i32 %34 to i64
  %36 = and i64 %35, 15
  %37 = and i64 %35, 192
  %38 = and i64 %35, 32
  %39 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %40 = sext i32 %39 to i64
  %41 = add i64 %25, 255
  %42 = lshr i64 %41, 8
  %43 = add i64 %26, 63
  %44 = lshr i64 %43, 4
  %45 = and i64 %44, 1152921504606846972
  %.frozen = freeze i64 %45
  %46 = udiv i64 %40, %.frozen
  %47 = shl i64 %46, 2
  %48 = sub i64 %42, %47
  %49 = tail call i64 @llvm.umin.i64(i64 %48, i64 4)
  %50 = mul i64 %46, %.frozen
  %.decomposed = sub i64 %40, %50
  %.frozen189 = freeze i64 %49
  %51 = udiv i64 %.decomposed, %.frozen189
  %52 = mul i64 %51, %.frozen189
  %.decomposed190 = sub i64 %.decomposed, %52
  %53 = add nuw i64 %.decomposed190, %47
  %54 = shl i64 %53, 8
  %55 = shl i64 %51, 6
  %56 = or disjoint i64 %54, %37
  %57 = or disjoint i64 %37, 16
  %58 = or disjoint i64 %54, %57
  %59 = or disjoint i64 %37, 32
  %60 = or disjoint i64 %54, %59
  %61 = or disjoint i64 %37, 48
  %62 = or disjoint i64 %54, %61
  %63 = or disjoint i64 %38, 16
  %64 = lshr i64 %35, 2
  %65 = shl nuw nsw i64 %35, 4
  %66 = and i64 %65, 48
  %67 = or disjoint i64 %54, %64
  %68 = mul i64 %67, %27
  %69 = mul nuw nsw i64 %64, 80
  %70 = add nuw nsw i64 %69, %66
  %71 = or disjoint i64 %64, 64
  %72 = or disjoint i64 %54, %71
  %73 = mul i64 %72, %27
  %74 = mul nuw nsw i64 %71, 80
  %75 = add nuw nsw i64 %74, %66
  %76 = or disjoint i64 %64, 128
  %77 = or disjoint i64 %54, %76
  %78 = mul i64 %77, %27
  %79 = mul nuw nsw i64 %76, 80
  %80 = add nuw nsw i64 %79, %66
  %81 = or disjoint i64 %64, 192
  %82 = or disjoint i64 %54, %81
  %83 = mul i64 %82, %27
  %84 = mul nuw nsw i64 %81, 80
  %85 = add nuw nsw i64 %84, %66
  %86 = or disjoint i64 %55, %64
  %87 = mul i64 %86, %27
  %88 = icmp ugt i64 %27, 63
  tail call void @llvm.assume(i1 %88)
  %89 = add i64 %27, -64
  %90 = getelementptr i8, ptr addrspace(1) %33, i64 %68
  %91 = getelementptr i8, ptr addrspace(1) %90, i64 %66
  %92 = load <16 x i8>, ptr addrspace(1) %91, align 16
  %93 = getelementptr i8, ptr addrspace(1) %33, i64 %73
  %94 = getelementptr i8, ptr addrspace(1) %93, i64 %66
  %95 = load <16 x i8>, ptr addrspace(1) %94, align 16
  %96 = getelementptr i8, ptr addrspace(1) %33, i64 %78
  %97 = getelementptr i8, ptr addrspace(1) %96, i64 %66
  %98 = load <16 x i8>, ptr addrspace(1) %97, align 16
  %99 = getelementptr i8, ptr addrspace(1) %33, i64 %83
  %100 = getelementptr i8, ptr addrspace(1) %99, i64 %66
  %101 = load <16 x i8>, ptr addrspace(1) %100, align 16
  %102 = trunc nuw nsw i64 %70 to i32
  %103 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %102
  store <16 x i8> %92, ptr addrspace(3) %103, align 16
  %104 = trunc nuw nsw i64 %75 to i32
  %105 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %104
  store <16 x i8> %95, ptr addrspace(3) %105, align 16
  %106 = trunc nuw nsw i64 %80 to i32
  %107 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %106
  store <16 x i8> %98, ptr addrspace(3) %107, align 16
  %108 = trunc nuw nsw i64 %85 to i32
  %109 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %108
  store <16 x i8> %101, ptr addrspace(3) %109, align 16
  %110 = getelementptr i8, ptr addrspace(1) %32, i64 %87
  %111 = getelementptr i8, ptr addrspace(1) %110, i64 %66
  %112 = load <16 x i8>, ptr addrspace(1) %111, align 16
  %113 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %102
  store <16 x i8> %112, ptr addrspace(3) %113, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %114 = icmp ugt i64 %27, 127
  %115 = lshr i64 %35, 1
  %116 = and i64 %115, 8
  %117 = and i64 %35, 207
  %118 = mul nuw nsw i64 %117, 80
  %119 = or disjoint i64 %116, %118
  %120 = trunc nuw nsw i64 %119 to i32
  br i1 %114, label %.lr.ph, label %.._crit_edge_crit_edge

.._crit_edge_crit_edge:                           ; preds = %28
  %.pre39 = or disjoint i64 %57, %36
  %.pre41 = mul nuw nsw i64 %.pre39, 80
  %.pre43 = or disjoint i64 %.pre41, %116
  %.pre45 = trunc nuw nsw i64 %.pre43 to i32
  %.pre47 = or disjoint i64 %59, %36
  %.pre49 = mul nuw nsw i64 %.pre47, 80
  %.pre51 = or disjoint i64 %.pre49, %116
  %.pre53 = trunc nuw nsw i64 %.pre51 to i32
  %.pre55 = or disjoint i64 %61, %36
  %.pre57 = mul nuw nsw i64 %.pre55, 80
  %.pre59 = or disjoint i64 %.pre57, %116
  %.pre61 = trunc nuw nsw i64 %.pre59 to i32
  %.pre63 = and i64 %35, 47
  %.pre65 = mul nuw nsw i64 %.pre63, 80
  %.pre67 = or disjoint i64 %116, %.pre65
  %.pre69 = trunc nuw nsw i64 %.pre67 to i32
  %.pre71 = or disjoint i64 %63, %36
  %.pre73 = mul nuw nsw i64 %.pre71, 80
  %.pre75 = or disjoint i64 %.pre73, %116
  %.pre77 = trunc nuw nsw i64 %.pre75 to i32
  %.pre79 = or disjoint i64 %116, 16
  %.pre81 = add nuw nsw i64 %.pre79, %118
  %.pre83 = trunc nuw nsw i64 %.pre81 to i32
  %.pre85 = add nuw nsw i64 %.pre41, %.pre79
  %.pre87 = trunc nuw nsw i64 %.pre85 to i32
  %.pre89 = add nuw nsw i64 %.pre49, %.pre79
  %.pre91 = trunc nuw nsw i64 %.pre89 to i32
  %.pre93 = add nuw nsw i64 %.pre57, %.pre79
  %.pre95 = trunc nuw nsw i64 %.pre93 to i32
  %.pre97 = add nuw nsw i64 %.pre79, %.pre65
  %.pre99 = trunc nuw nsw i64 %.pre97 to i32
  %.pre101 = add nuw nsw i64 %.pre73, %.pre79
  %.pre103 = trunc nuw nsw i64 %.pre101 to i32
  %.pre105 = or disjoint i64 %116, 32
  %.pre107 = add nuw nsw i64 %.pre105, %118
  %.pre109 = trunc nuw nsw i64 %.pre107 to i32
  %.pre111 = add nuw nsw i64 %.pre41, %.pre105
  %.pre113 = trunc nuw nsw i64 %.pre111 to i32
  %.pre115 = add nuw nsw i64 %.pre49, %.pre105
  %.pre117 = trunc nuw nsw i64 %.pre115 to i32
  %.pre119 = add nuw nsw i64 %.pre57, %.pre105
  %.pre121 = trunc nuw nsw i64 %.pre119 to i32
  %.pre123 = add nuw nsw i64 %.pre105, %.pre65
  %.pre125 = trunc nuw nsw i64 %.pre123 to i32
  %.pre127 = add nuw nsw i64 %.pre73, %.pre105
  %.pre129 = trunc nuw nsw i64 %.pre127 to i32
  %.pre131 = or disjoint i64 %116, 48
  %.pre133 = add nuw nsw i64 %.pre131, %118
  %.pre135 = trunc nuw nsw i64 %.pre133 to i32
  %.pre137 = add nuw nsw i64 %.pre41, %.pre131
  %.pre139 = trunc nuw nsw i64 %.pre137 to i32
  %.pre141 = add nuw nsw i64 %.pre49, %.pre131
  %.pre143 = trunc nuw nsw i64 %.pre141 to i32
  %.pre145 = add nuw nsw i64 %.pre57, %.pre131
  %.pre147 = trunc nuw nsw i64 %.pre145 to i32
  %.pre149 = add nuw nsw i64 %.pre131, %.pre65
  %.pre151 = trunc nuw nsw i64 %.pre149 to i32
  %.pre153 = add nuw nsw i64 %.pre73, %.pre131
  %.pre155 = trunc nuw nsw i64 %.pre153 to i32
  br label %._crit_edge

.lr.ph:                                           ; preds = %28
  %121 = lshr i64 %27, 6
  %122 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %120
  %123 = or disjoint i64 %57, %36
  %124 = mul nuw nsw i64 %123, 80
  %125 = or disjoint i64 %124, %116
  %126 = trunc nuw nsw i64 %125 to i32
  %127 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %126
  %128 = or disjoint i64 %59, %36
  %129 = mul nuw nsw i64 %128, 80
  %130 = or disjoint i64 %129, %116
  %131 = trunc nuw nsw i64 %130 to i32
  %132 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %131
  %133 = or disjoint i64 %61, %36
  %134 = mul nuw nsw i64 %133, 80
  %135 = or disjoint i64 %134, %116
  %136 = trunc nuw nsw i64 %135 to i32
  %137 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %136
  %138 = and i64 %35, 47
  %139 = mul nuw nsw i64 %138, 80
  %140 = or disjoint i64 %116, %139
  %141 = trunc nuw nsw i64 %140 to i32
  %142 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %141
  %143 = or disjoint i64 %63, %36
  %144 = mul nuw nsw i64 %143, 80
  %145 = or disjoint i64 %144, %116
  %146 = trunc nuw nsw i64 %145 to i32
  %147 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %146
  %148 = or disjoint i64 %116, 16
  %149 = add nuw nsw i64 %148, %118
  %150 = trunc nuw nsw i64 %149 to i32
  %151 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %150
  %152 = add nuw nsw i64 %124, %148
  %153 = trunc nuw nsw i64 %152 to i32
  %154 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %153
  %155 = add nuw nsw i64 %129, %148
  %156 = trunc nuw nsw i64 %155 to i32
  %157 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %156
  %158 = add nuw nsw i64 %134, %148
  %159 = trunc nuw nsw i64 %158 to i32
  %160 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %159
  %161 = add nuw nsw i64 %148, %139
  %162 = trunc nuw nsw i64 %161 to i32
  %163 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %162
  %164 = add nuw nsw i64 %144, %148
  %165 = trunc nuw nsw i64 %164 to i32
  %166 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %165
  %167 = or disjoint i64 %116, 32
  %168 = add nuw nsw i64 %167, %118
  %169 = trunc nuw nsw i64 %168 to i32
  %170 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %169
  %171 = add nuw nsw i64 %124, %167
  %172 = trunc nuw nsw i64 %171 to i32
  %173 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %172
  %174 = add nuw nsw i64 %129, %167
  %175 = trunc nuw nsw i64 %174 to i32
  %176 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %175
  %177 = add nuw nsw i64 %134, %167
  %178 = trunc nuw nsw i64 %177 to i32
  %179 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %178
  %180 = add nuw nsw i64 %167, %139
  %181 = trunc nuw nsw i64 %180 to i32
  %182 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %181
  %183 = add nuw nsw i64 %144, %167
  %184 = trunc nuw nsw i64 %183 to i32
  %185 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %184
  %186 = or disjoint i64 %116, 48
  %187 = add nuw nsw i64 %186, %118
  %188 = trunc nuw nsw i64 %187 to i32
  %189 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %188
  %190 = add nuw nsw i64 %124, %186
  %191 = trunc nuw nsw i64 %190 to i32
  %192 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %191
  %193 = add nuw nsw i64 %129, %186
  %194 = trunc nuw nsw i64 %193 to i32
  %195 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %194
  %196 = add nuw nsw i64 %134, %186
  %197 = trunc nuw nsw i64 %196 to i32
  %198 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %197
  %199 = add nuw nsw i64 %186, %139
  %200 = trunc nuw nsw i64 %199 to i32
  %201 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %200
  %202 = add nuw nsw i64 %144, %186
  %203 = trunc nuw nsw i64 %202 to i32
  %204 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %203
  %205 = add nsw i64 %121, -2
  br label %206

206:                                              ; preds = %.lr.ph, %206
  %207 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %284, %206 ]
  %208 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %283, %206 ]
  %209 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %282, %206 ]
  %210 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %281, %206 ]
  %211 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %280, %206 ]
  %212 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %279, %206 ]
  %213 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %278, %206 ]
  %214 = phi <8 x float> [ zeroinitializer, %.lr.ph ], [ %277, %206 ]
  %215 = phi i64 [ 0, %.lr.ph ], [ %285, %206 ]
  %216 = shl i64 %215, 6
  %217 = add nuw i64 %216, 64
  %218 = tail call i64 @llvm.umin.i64(i64 %217, i64 %89)
  %219 = getelementptr i8, ptr addrspace(1) %91, i64 %218
  %220 = load <16 x i8>, ptr addrspace(1) %219, align 16
  %221 = getelementptr i8, ptr addrspace(1) %94, i64 %218
  %222 = load <16 x i8>, ptr addrspace(1) %221, align 16
  %223 = getelementptr i8, ptr addrspace(1) %97, i64 %218
  %224 = load <16 x i8>, ptr addrspace(1) %223, align 16
  %225 = getelementptr i8, ptr addrspace(1) %100, i64 %218
  %226 = load <16 x i8>, ptr addrspace(1) %225, align 16
  %227 = getelementptr i8, ptr addrspace(1) %111, i64 %218
  %228 = load <16 x i8>, ptr addrspace(1) %227, align 16
  %229 = load <2 x i32>, ptr addrspace(3) %122, align 8
  %230 = load <2 x i32>, ptr addrspace(3) %127, align 8
  %231 = load <2 x i32>, ptr addrspace(3) %132, align 8
  %232 = load <2 x i32>, ptr addrspace(3) %137, align 8
  %233 = load <2 x i32>, ptr addrspace(3) %142, align 8
  %234 = load <2 x i32>, ptr addrspace(3) %147, align 8
  %235 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %233, <8 x float> %214)
  %236 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %229, <2 x i32> %234, <8 x float> %213)
  %237 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %230, <2 x i32> %233, <8 x float> %212)
  %238 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %230, <2 x i32> %234, <8 x float> %211)
  %239 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %231, <2 x i32> %233, <8 x float> %210)
  %240 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %231, <2 x i32> %234, <8 x float> %209)
  %241 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %232, <2 x i32> %233, <8 x float> %208)
  %242 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %232, <2 x i32> %234, <8 x float> %207)
  %243 = load <2 x i32>, ptr addrspace(3) %151, align 8
  %244 = load <2 x i32>, ptr addrspace(3) %154, align 8
  %245 = load <2 x i32>, ptr addrspace(3) %157, align 8
  %246 = load <2 x i32>, ptr addrspace(3) %160, align 8
  %247 = load <2 x i32>, ptr addrspace(3) %163, align 8
  %248 = load <2 x i32>, ptr addrspace(3) %166, align 8
  %249 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %247, <8 x float> %235)
  %250 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %243, <2 x i32> %248, <8 x float> %236)
  %251 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %244, <2 x i32> %247, <8 x float> %237)
  %252 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %244, <2 x i32> %248, <8 x float> %238)
  %253 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %245, <2 x i32> %247, <8 x float> %239)
  %254 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %245, <2 x i32> %248, <8 x float> %240)
  %255 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %246, <2 x i32> %247, <8 x float> %241)
  %256 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %246, <2 x i32> %248, <8 x float> %242)
  %257 = load <2 x i32>, ptr addrspace(3) %170, align 8
  %258 = load <2 x i32>, ptr addrspace(3) %173, align 8
  %259 = load <2 x i32>, ptr addrspace(3) %176, align 8
  %260 = load <2 x i32>, ptr addrspace(3) %179, align 8
  %261 = load <2 x i32>, ptr addrspace(3) %182, align 8
  %262 = load <2 x i32>, ptr addrspace(3) %185, align 8
  %263 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %261, <8 x float> %249)
  %264 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %257, <2 x i32> %262, <8 x float> %250)
  %265 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %261, <8 x float> %251)
  %266 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %258, <2 x i32> %262, <8 x float> %252)
  %267 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %259, <2 x i32> %261, <8 x float> %253)
  %268 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %259, <2 x i32> %262, <8 x float> %254)
  %269 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %260, <2 x i32> %261, <8 x float> %255)
  %270 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %260, <2 x i32> %262, <8 x float> %256)
  %271 = load <2 x i32>, ptr addrspace(3) %189, align 8
  %272 = load <2 x i32>, ptr addrspace(3) %192, align 8
  %273 = load <2 x i32>, ptr addrspace(3) %195, align 8
  %274 = load <2 x i32>, ptr addrspace(3) %198, align 8
  %275 = load <2 x i32>, ptr addrspace(3) %201, align 8
  %276 = load <2 x i32>, ptr addrspace(3) %204, align 8
  %277 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %275, <8 x float> %263)
  %278 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %271, <2 x i32> %276, <8 x float> %264)
  %279 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %272, <2 x i32> %275, <8 x float> %265)
  %280 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %272, <2 x i32> %276, <8 x float> %266)
  %281 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %273, <2 x i32> %275, <8 x float> %267)
  %282 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %273, <2 x i32> %276, <8 x float> %268)
  %283 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %275, <8 x float> %269)
  %284 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %274, <2 x i32> %276, <8 x float> %270)
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  store <16 x i8> %220, ptr addrspace(3) %103, align 16
  store <16 x i8> %222, ptr addrspace(3) %105, align 16
  store <16 x i8> %224, ptr addrspace(3) %107, align 16
  store <16 x i8> %226, ptr addrspace(3) %109, align 16
  store <16 x i8> %228, ptr addrspace(3) %113, align 16
  fence syncscope("workgroup") release, !mmra !2
  tail call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  tail call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %285 = add nuw nsw i64 %215, 1
  %exitcond.not = icmp eq i64 %215, %205
  br i1 %exitcond.not, label %._crit_edge, label %206

._crit_edge:                                      ; preds = %206, %.._crit_edge_crit_edge
  %.pre-phi156 = phi i32 [ %.pre155, %.._crit_edge_crit_edge ], [ %203, %206 ]
  %.pre-phi152 = phi i32 [ %.pre151, %.._crit_edge_crit_edge ], [ %200, %206 ]
  %.pre-phi148 = phi i32 [ %.pre147, %.._crit_edge_crit_edge ], [ %197, %206 ]
  %.pre-phi144 = phi i32 [ %.pre143, %.._crit_edge_crit_edge ], [ %194, %206 ]
  %.pre-phi140 = phi i32 [ %.pre139, %.._crit_edge_crit_edge ], [ %191, %206 ]
  %.pre-phi136 = phi i32 [ %.pre135, %.._crit_edge_crit_edge ], [ %188, %206 ]
  %.pre-phi130 = phi i32 [ %.pre129, %.._crit_edge_crit_edge ], [ %184, %206 ]
  %.pre-phi126 = phi i32 [ %.pre125, %.._crit_edge_crit_edge ], [ %181, %206 ]
  %.pre-phi122 = phi i32 [ %.pre121, %.._crit_edge_crit_edge ], [ %178, %206 ]
  %.pre-phi118 = phi i32 [ %.pre117, %.._crit_edge_crit_edge ], [ %175, %206 ]
  %.pre-phi114 = phi i32 [ %.pre113, %.._crit_edge_crit_edge ], [ %172, %206 ]
  %.pre-phi110 = phi i32 [ %.pre109, %.._crit_edge_crit_edge ], [ %169, %206 ]
  %.pre-phi104 = phi i32 [ %.pre103, %.._crit_edge_crit_edge ], [ %165, %206 ]
  %.pre-phi100 = phi i32 [ %.pre99, %.._crit_edge_crit_edge ], [ %162, %206 ]
  %.pre-phi96 = phi i32 [ %.pre95, %.._crit_edge_crit_edge ], [ %159, %206 ]
  %.pre-phi92 = phi i32 [ %.pre91, %.._crit_edge_crit_edge ], [ %156, %206 ]
  %.pre-phi88 = phi i32 [ %.pre87, %.._crit_edge_crit_edge ], [ %153, %206 ]
  %.pre-phi84 = phi i32 [ %.pre83, %.._crit_edge_crit_edge ], [ %150, %206 ]
  %.pre-phi78 = phi i32 [ %.pre77, %.._crit_edge_crit_edge ], [ %146, %206 ]
  %.pre-phi72 = phi i64 [ %.pre71, %.._crit_edge_crit_edge ], [ %143, %206 ]
  %.pre-phi70 = phi i32 [ %.pre69, %.._crit_edge_crit_edge ], [ %141, %206 ]
  %.pre-phi62 = phi i32 [ %.pre61, %.._crit_edge_crit_edge ], [ %136, %206 ]
  %.pre-phi54 = phi i32 [ %.pre53, %.._crit_edge_crit_edge ], [ %131, %206 ]
  %.pre-phi46 = phi i32 [ %.pre45, %.._crit_edge_crit_edge ], [ %126, %206 ]
  %.lcssa15 = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %277, %206 ]
  %.lcssa14 = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %278, %206 ]
  %.lcssa13 = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %279, %206 ]
  %.lcssa12 = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %280, %206 ]
  %.lcssa11 = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %281, %206 ]
  %.lcssa10 = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %282, %206 ]
  %.lcssa9 = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %283, %206 ]
  %.lcssa = phi <8 x float> [ zeroinitializer, %.._crit_edge_crit_edge ], [ %284, %206 ]
  %286 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %120
  %287 = load <2 x i32>, ptr addrspace(3) %286, align 8
  %288 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi46
  %289 = load <2 x i32>, ptr addrspace(3) %288, align 1
  %290 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi54
  %291 = load <2 x i32>, ptr addrspace(3) %290, align 1
  %292 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi62
  %293 = load <2 x i32>, ptr addrspace(3) %292, align 1
  %294 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi70
  %295 = load <2 x i32>, ptr addrspace(3) %294, align 1
  %296 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi78
  %297 = load <2 x i32>, ptr addrspace(3) %296, align 1
  %298 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %287, <2 x i32> %295, <8 x float> %.lcssa15)
  %299 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %287, <2 x i32> %297, <8 x float> %.lcssa14)
  %300 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %289, <2 x i32> %295, <8 x float> %.lcssa13)
  %301 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %289, <2 x i32> %297, <8 x float> %.lcssa12)
  %302 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %291, <2 x i32> %295, <8 x float> %.lcssa11)
  %303 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %291, <2 x i32> %297, <8 x float> %.lcssa10)
  %304 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %293, <2 x i32> %295, <8 x float> %.lcssa9)
  %305 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %293, <2 x i32> %297, <8 x float> %.lcssa)
  %306 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi84
  %307 = load <2 x i32>, ptr addrspace(3) %306, align 1
  %308 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi88
  %309 = load <2 x i32>, ptr addrspace(3) %308, align 1
  %310 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi92
  %311 = load <2 x i32>, ptr addrspace(3) %310, align 1
  %312 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi96
  %313 = load <2 x i32>, ptr addrspace(3) %312, align 1
  %314 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi100
  %315 = load <2 x i32>, ptr addrspace(3) %314, align 1
  %316 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi104
  %317 = load <2 x i32>, ptr addrspace(3) %316, align 1
  %318 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %307, <2 x i32> %315, <8 x float> %298)
  %319 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %307, <2 x i32> %317, <8 x float> %299)
  %320 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %309, <2 x i32> %315, <8 x float> %300)
  %321 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %309, <2 x i32> %317, <8 x float> %301)
  %322 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %311, <2 x i32> %315, <8 x float> %302)
  %323 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %311, <2 x i32> %317, <8 x float> %303)
  %324 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %313, <2 x i32> %315, <8 x float> %304)
  %325 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %313, <2 x i32> %317, <8 x float> %305)
  %326 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi110
  %327 = load <2 x i32>, ptr addrspace(3) %326, align 1
  %328 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi114
  %329 = load <2 x i32>, ptr addrspace(3) %328, align 1
  %330 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi118
  %331 = load <2 x i32>, ptr addrspace(3) %330, align 1
  %332 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi122
  %333 = load <2 x i32>, ptr addrspace(3) %332, align 1
  %334 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi126
  %335 = load <2 x i32>, ptr addrspace(3) %334, align 1
  %336 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi130
  %337 = load <2 x i32>, ptr addrspace(3) %336, align 1
  %338 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %327, <2 x i32> %335, <8 x float> %318)
  %339 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %327, <2 x i32> %337, <8 x float> %319)
  %340 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %329, <2 x i32> %335, <8 x float> %320)
  %341 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %329, <2 x i32> %337, <8 x float> %321)
  %342 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %331, <2 x i32> %335, <8 x float> %322)
  %343 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %331, <2 x i32> %337, <8 x float> %323)
  %344 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %333, <2 x i32> %335, <8 x float> %324)
  %345 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %333, <2 x i32> %337, <8 x float> %325)
  %346 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi136
  %347 = load <2 x i32>, ptr addrspace(3) %346, align 1
  %348 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi140
  %349 = load <2 x i32>, ptr addrspace(3) %348, align 1
  %350 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi144
  %351 = load <2 x i32>, ptr addrspace(3) %350, align 1
  %352 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i32 %.pre-phi148
  %353 = load <2 x i32>, ptr addrspace(3) %352, align 1
  %354 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi152
  %355 = load <2 x i32>, ptr addrspace(3) %354, align 1
  %356 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i32 %.pre-phi156
  %357 = load <2 x i32>, ptr addrspace(3) %356, align 1
  %358 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %347, <2 x i32> %355, <8 x float> %338)
  %359 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %347, <2 x i32> %357, <8 x float> %339)
  %360 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %349, <2 x i32> %355, <8 x float> %340)
  %361 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %349, <2 x i32> %357, <8 x float> %341)
  %362 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %351, <2 x i32> %355, <8 x float> %342)
  %363 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %351, <2 x i32> %357, <8 x float> %343)
  %364 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %353, <2 x i32> %355, <8 x float> %344)
  %365 = tail call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %353, <2 x i32> %357, <8 x float> %345)
  %366 = or disjoint i64 %56, %116
  %367 = or disjoint i64 %55, %36
  %368 = or disjoint i64 %367, %38
  %369 = or disjoint i64 %366, 7
  %370 = icmp ult i64 %368, %26
  %371 = icmp ult i64 %369, %25
  %372 = and i1 %370, %371
  %373 = ptrtoint ptr %11 to i64
  %374 = and i64 %373, 15
  %375 = icmp eq i64 %374, 0
  %376 = and i1 %375, %372
  br i1 %376, label %377, label %383

377:                                              ; preds = %._crit_edge
  %378 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %366
  %379 = load <4 x float>, ptr addrspace(1) %378, align 16
  %380 = getelementptr i8, ptr addrspace(1) %378, i64 16
  %381 = load <4 x float>, ptr addrspace(1) %380, align 16
  %382 = shufflevector <4 x float> %379, <4 x float> %381, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %430

383:                                              ; preds = %._crit_edge
  %384 = icmp slt i64 %366, %25
  %385 = select i1 %384, i64 %366, i64 0
  %386 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %385
  %387 = load float, ptr addrspace(1) %386, align 4, !amdgpu.noclobber !3
  %388 = insertelement <8 x float> poison, float %387, i64 0
  %389 = or disjoint i64 %366, 1
  %390 = icmp slt i64 %389, %25
  %391 = select i1 %390, i64 %389, i64 0
  %392 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %391
  %393 = load float, ptr addrspace(1) %392, align 4, !amdgpu.noclobber !3
  %394 = insertelement <8 x float> %388, float %393, i64 1
  %395 = or disjoint i64 %366, 2
  %396 = icmp slt i64 %395, %25
  %397 = select i1 %396, i64 %395, i64 0
  %398 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %397
  %399 = load float, ptr addrspace(1) %398, align 4, !amdgpu.noclobber !3
  %400 = insertelement <8 x float> %394, float %399, i64 2
  %401 = or disjoint i64 %366, 3
  %402 = icmp slt i64 %401, %25
  %403 = select i1 %402, i64 %401, i64 0
  %404 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %403
  %405 = load float, ptr addrspace(1) %404, align 4, !amdgpu.noclobber !3
  %406 = insertelement <8 x float> %400, float %405, i64 3
  %407 = or disjoint i64 %366, 4
  %408 = icmp slt i64 %407, %25
  %409 = select i1 %408, i64 %407, i64 0
  %410 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %409
  %411 = load float, ptr addrspace(1) %410, align 4, !amdgpu.noclobber !3
  %412 = insertelement <8 x float> %406, float %411, i64 4
  %413 = or disjoint i64 %366, 5
  %414 = icmp slt i64 %413, %25
  %415 = select i1 %414, i64 %413, i64 0
  %416 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %415
  %417 = load float, ptr addrspace(1) %416, align 4, !amdgpu.noclobber !3
  %418 = insertelement <8 x float> %412, float %417, i64 5
  %419 = or disjoint i64 %366, 6
  %420 = icmp slt i64 %419, %25
  %421 = select i1 %420, i64 %419, i64 0
  %422 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %421
  %423 = load float, ptr addrspace(1) %422, align 4, !amdgpu.noclobber !3
  %424 = insertelement <8 x float> %418, float %423, i64 6
  %425 = icmp slt i64 %369, %25
  %426 = select i1 %425, i64 %369, i64 0
  %427 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %426
  %428 = load float, ptr addrspace(1) %427, align 4, !amdgpu.noclobber !3
  %429 = insertelement <8 x float> %424, float %428, i64 7
  br label %430

430:                                              ; preds = %377, %383
  %431 = phi <8 x float> [ %429, %383 ], [ %382, %377 ]
  %432 = icmp slt i64 %368, %26
  %433 = select i1 %432, i64 %368, i64 0
  %434 = extractelement <8 x float> %431, i64 0
  %435 = getelementptr inbounds i8, ptr addrspace(1) %30, i64 %433
  %436 = load i8, ptr addrspace(1) %435, align 1
  %437 = zext i8 %436 to i32
  %438 = shl nuw nsw i32 %437, 23
  %439 = bitcast i32 %438 to float
  %440 = fmul float %434, %439
  %441 = extractelement <8 x float> %358, i64 0
  %442 = fmul float %441, %440
  %443 = tail call i1 @llvm.is.fpclass.f32(float %440, /* (sub norm) */ i32 408)
  br i1 %443, label %456, label %444

444:                                              ; preds = %430
  %445 = fpext float %441 to double
  %446 = fpext nnan float %439 to double
  %447 = fpext float %434 to double
  %448 = fmul double %445, %446
  %449 = fmul double %448, %447
  %450 = fptrunc double %449 to float
  %451 = fcmp oeq float %441, 0.000000e+00
  %452 = tail call float @llvm.fabs.f32(float %434)
  %453 = fcmp one float %452, +inf
  %454 = and i1 %451, %453
  %455 = select i1 %454, float 0.000000e+00, float %450
  br label %456

456:                                              ; preds = %444, %430
  %457 = phi float [ %455, %444 ], [ %442, %430 ]
  %458 = extractelement <8 x float> %431, i64 1
  %459 = fmul float %458, %439
  %460 = extractelement <8 x float> %358, i64 1
  %461 = fmul float %460, %459
  %462 = tail call i1 @llvm.is.fpclass.f32(float %459, /* (sub norm) */ i32 408)
  br i1 %462, label %475, label %463

463:                                              ; preds = %456
  %464 = fpext float %460 to double
  %465 = fpext nnan float %439 to double
  %466 = fpext float %458 to double
  %467 = fmul double %464, %465
  %468 = fmul double %467, %466
  %469 = fptrunc double %468 to float
  %470 = fcmp oeq float %460, 0.000000e+00
  %471 = tail call float @llvm.fabs.f32(float %458)
  %472 = fcmp one float %471, +inf
  %473 = and i1 %470, %472
  %474 = select i1 %473, float 0.000000e+00, float %469
  br label %475

475:                                              ; preds = %463, %456
  %476 = phi float [ %474, %463 ], [ %461, %456 ]
  %477 = extractelement <8 x float> %431, i64 2
  %478 = fmul float %477, %439
  %479 = extractelement <8 x float> %358, i64 2
  %480 = fmul float %479, %478
  %481 = tail call i1 @llvm.is.fpclass.f32(float %478, /* (sub norm) */ i32 408)
  br i1 %481, label %494, label %482

482:                                              ; preds = %475
  %483 = fpext float %479 to double
  %484 = fpext nnan float %439 to double
  %485 = fpext float %477 to double
  %486 = fmul double %483, %484
  %487 = fmul double %486, %485
  %488 = fptrunc double %487 to float
  %489 = fcmp oeq float %479, 0.000000e+00
  %490 = tail call float @llvm.fabs.f32(float %477)
  %491 = fcmp one float %490, +inf
  %492 = and i1 %489, %491
  %493 = select i1 %492, float 0.000000e+00, float %488
  br label %494

494:                                              ; preds = %482, %475
  %495 = phi float [ %493, %482 ], [ %480, %475 ]
  %496 = extractelement <8 x float> %431, i64 3
  %497 = fmul float %496, %439
  %498 = extractelement <8 x float> %358, i64 3
  %499 = fmul float %498, %497
  %500 = tail call i1 @llvm.is.fpclass.f32(float %497, /* (sub norm) */ i32 408)
  br i1 %500, label %513, label %501

501:                                              ; preds = %494
  %502 = fpext float %498 to double
  %503 = fpext nnan float %439 to double
  %504 = fpext float %496 to double
  %505 = fmul double %502, %503
  %506 = fmul double %505, %504
  %507 = fptrunc double %506 to float
  %508 = fcmp oeq float %498, 0.000000e+00
  %509 = tail call float @llvm.fabs.f32(float %496)
  %510 = fcmp one float %509, +inf
  %511 = and i1 %508, %510
  %512 = select i1 %511, float 0.000000e+00, float %507
  br label %513

513:                                              ; preds = %501, %494
  %514 = phi float [ %512, %501 ], [ %499, %494 ]
  %515 = extractelement <8 x float> %431, i64 4
  %516 = fmul float %515, %439
  %517 = extractelement <8 x float> %358, i64 4
  %518 = fmul float %517, %516
  %519 = tail call i1 @llvm.is.fpclass.f32(float %516, /* (sub norm) */ i32 408)
  br i1 %519, label %532, label %520

520:                                              ; preds = %513
  %521 = fpext float %517 to double
  %522 = fpext nnan float %439 to double
  %523 = fpext float %515 to double
  %524 = fmul double %521, %522
  %525 = fmul double %524, %523
  %526 = fptrunc double %525 to float
  %527 = fcmp oeq float %517, 0.000000e+00
  %528 = tail call float @llvm.fabs.f32(float %515)
  %529 = fcmp one float %528, +inf
  %530 = and i1 %527, %529
  %531 = select i1 %530, float 0.000000e+00, float %526
  br label %532

532:                                              ; preds = %520, %513
  %533 = phi float [ %531, %520 ], [ %518, %513 ]
  %534 = extractelement <8 x float> %431, i64 5
  %535 = fmul float %534, %439
  %536 = extractelement <8 x float> %358, i64 5
  %537 = fmul float %536, %535
  %538 = tail call i1 @llvm.is.fpclass.f32(float %535, /* (sub norm) */ i32 408)
  br i1 %538, label %551, label %539

539:                                              ; preds = %532
  %540 = fpext float %536 to double
  %541 = fpext nnan float %439 to double
  %542 = fpext float %534 to double
  %543 = fmul double %540, %541
  %544 = fmul double %543, %542
  %545 = fptrunc double %544 to float
  %546 = fcmp oeq float %536, 0.000000e+00
  %547 = tail call float @llvm.fabs.f32(float %534)
  %548 = fcmp one float %547, +inf
  %549 = and i1 %546, %548
  %550 = select i1 %549, float 0.000000e+00, float %545
  br label %551

551:                                              ; preds = %539, %532
  %552 = phi float [ %550, %539 ], [ %537, %532 ]
  %553 = extractelement <8 x float> %431, i64 6
  %554 = fmul float %553, %439
  %555 = extractelement <8 x float> %358, i64 6
  %556 = fmul float %555, %554
  %557 = tail call i1 @llvm.is.fpclass.f32(float %554, /* (sub norm) */ i32 408)
  br i1 %557, label %570, label %558

558:                                              ; preds = %551
  %559 = fpext float %555 to double
  %560 = fpext nnan float %439 to double
  %561 = fpext float %553 to double
  %562 = fmul double %559, %560
  %563 = fmul double %562, %561
  %564 = fptrunc double %563 to float
  %565 = fcmp oeq float %555, 0.000000e+00
  %566 = tail call float @llvm.fabs.f32(float %553)
  %567 = fcmp one float %566, +inf
  %568 = and i1 %565, %567
  %569 = select i1 %568, float 0.000000e+00, float %564
  br label %570

570:                                              ; preds = %558, %551
  %571 = phi float [ %569, %558 ], [ %556, %551 ]
  %572 = extractelement <8 x float> %431, i64 7
  %573 = fmul float %572, %439
  %574 = extractelement <8 x float> %358, i64 7
  %575 = fmul float %574, %573
  %576 = tail call i1 @llvm.is.fpclass.f32(float %573, /* (sub norm) */ i32 408)
  br i1 %576, label %589, label %577

577:                                              ; preds = %570
  %578 = fpext float %574 to double
  %579 = fpext nnan float %439 to double
  %580 = fpext float %572 to double
  %581 = fmul double %578, %579
  %582 = fmul double %581, %580
  %583 = fptrunc double %582 to float
  %584 = fcmp oeq float %574, 0.000000e+00
  %585 = tail call float @llvm.fabs.f32(float %572)
  %586 = fcmp one float %585, +inf
  %587 = and i1 %584, %586
  %588 = select i1 %587, float 0.000000e+00, float %583
  br label %589

589:                                              ; preds = %577, %570
  %590 = phi float [ %588, %577 ], [ %575, %570 ]
  %591 = mul i64 %366, %26
  %592 = fptrunc float %457 to bfloat
  %593 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %591
  %594 = getelementptr [2 x i8], ptr addrspace(1) %593, i64 %368
  store bfloat %592, ptr addrspace(1) %594, align 2
  %595 = or disjoint i64 %116, 1
  %596 = or disjoint i64 %56, %595
  %597 = mul i64 %596, %26
  %598 = fptrunc float %476 to bfloat
  %599 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %597
  %600 = getelementptr [2 x i8], ptr addrspace(1) %599, i64 %368
  store bfloat %598, ptr addrspace(1) %600, align 2
  %601 = or disjoint i64 %116, 2
  %602 = or disjoint i64 %56, %601
  %603 = mul i64 %602, %26
  %604 = fptrunc float %495 to bfloat
  %605 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %603
  %606 = getelementptr [2 x i8], ptr addrspace(1) %605, i64 %368
  store bfloat %604, ptr addrspace(1) %606, align 2
  %607 = or disjoint i64 %116, 3
  %608 = or disjoint i64 %56, %607
  %609 = mul i64 %608, %26
  %610 = fptrunc float %514 to bfloat
  %611 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %609
  %612 = getelementptr [2 x i8], ptr addrspace(1) %611, i64 %368
  store bfloat %610, ptr addrspace(1) %612, align 2
  %613 = or disjoint i64 %116, 4
  %614 = or disjoint i64 %56, %613
  %615 = mul i64 %614, %26
  %616 = fptrunc float %533 to bfloat
  %617 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %615
  %618 = getelementptr [2 x i8], ptr addrspace(1) %617, i64 %368
  store bfloat %616, ptr addrspace(1) %618, align 2
  %619 = or disjoint i64 %116, 5
  %620 = or disjoint i64 %56, %619
  %621 = mul i64 %620, %26
  %622 = fptrunc float %552 to bfloat
  %623 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %621
  %624 = getelementptr [2 x i8], ptr addrspace(1) %623, i64 %368
  store bfloat %622, ptr addrspace(1) %624, align 2
  %625 = or disjoint i64 %116, 6
  %626 = or disjoint i64 %56, %625
  %627 = mul i64 %626, %26
  %628 = fptrunc float %571 to bfloat
  %629 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %627
  %630 = getelementptr [2 x i8], ptr addrspace(1) %629, i64 %368
  store bfloat %628, ptr addrspace(1) %630, align 2
  %631 = or disjoint i64 %116, 7
  %632 = or disjoint i64 %56, %631
  %633 = mul i64 %632, %26
  %634 = fptrunc float %590 to bfloat
  %635 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %633
  %636 = getelementptr [2 x i8], ptr addrspace(1) %635, i64 %368
  store bfloat %634, ptr addrspace(1) %636, align 2
  %637 = or disjoint i64 %58, %116
  %638 = or disjoint i64 %637, 7
  %639 = icmp ult i64 %638, %25
  %640 = and i1 %370, %639
  %641 = and i1 %375, %640
  br i1 %641, label %642, label %648

642:                                              ; preds = %589
  %643 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %637
  %644 = load <4 x float>, ptr addrspace(1) %643, align 16
  %645 = getelementptr i8, ptr addrspace(1) %643, i64 16
  %646 = load <4 x float>, ptr addrspace(1) %645, align 16
  %647 = shufflevector <4 x float> %644, <4 x float> %646, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %696

648:                                              ; preds = %589
  %649 = icmp slt i64 %637, %25
  %650 = select i1 %649, i64 %637, i64 0
  %651 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %650
  %652 = load float, ptr addrspace(1) %651, align 4
  %653 = insertelement <8 x float> poison, float %652, i64 0
  %654 = or disjoint i64 %58, %595
  %655 = icmp slt i64 %654, %25
  %656 = select i1 %655, i64 %654, i64 0
  %657 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %656
  %658 = load float, ptr addrspace(1) %657, align 4
  %659 = insertelement <8 x float> %653, float %658, i64 1
  %660 = or disjoint i64 %58, %601
  %661 = icmp slt i64 %660, %25
  %662 = select i1 %661, i64 %660, i64 0
  %663 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %662
  %664 = load float, ptr addrspace(1) %663, align 4
  %665 = insertelement <8 x float> %659, float %664, i64 2
  %666 = or disjoint i64 %58, %607
  %667 = icmp slt i64 %666, %25
  %668 = select i1 %667, i64 %666, i64 0
  %669 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %668
  %670 = load float, ptr addrspace(1) %669, align 4
  %671 = insertelement <8 x float> %665, float %670, i64 3
  %672 = or disjoint i64 %58, %613
  %673 = icmp slt i64 %672, %25
  %674 = select i1 %673, i64 %672, i64 0
  %675 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %674
  %676 = load float, ptr addrspace(1) %675, align 4
  %677 = insertelement <8 x float> %671, float %676, i64 4
  %678 = or disjoint i64 %58, %619
  %679 = icmp slt i64 %678, %25
  %680 = select i1 %679, i64 %678, i64 0
  %681 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %680
  %682 = load float, ptr addrspace(1) %681, align 4
  %683 = insertelement <8 x float> %677, float %682, i64 5
  %684 = or disjoint i64 %58, %625
  %685 = icmp slt i64 %684, %25
  %686 = select i1 %685, i64 %684, i64 0
  %687 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %686
  %688 = load float, ptr addrspace(1) %687, align 4
  %689 = insertelement <8 x float> %683, float %688, i64 6
  %690 = or disjoint i64 %58, %631
  %691 = icmp slt i64 %690, %25
  %692 = select i1 %691, i64 %690, i64 0
  %693 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %692
  %694 = load float, ptr addrspace(1) %693, align 4
  %695 = insertelement <8 x float> %689, float %694, i64 7
  br label %696

696:                                              ; preds = %642, %648
  %697 = phi <8 x float> [ %695, %648 ], [ %647, %642 ]
  %698 = extractelement <8 x float> %697, i64 0
  %699 = load i8, ptr addrspace(1) %435, align 1
  %700 = zext i8 %699 to i32
  %701 = shl nuw nsw i32 %700, 23
  %702 = bitcast i32 %701 to float
  %703 = fmul float %698, %702
  %704 = extractelement <8 x float> %360, i64 0
  %705 = fmul float %704, %703
  %706 = tail call i1 @llvm.is.fpclass.f32(float %703, /* (sub norm) */ i32 408)
  br i1 %706, label %719, label %707

707:                                              ; preds = %696
  %708 = fpext float %704 to double
  %709 = fpext nnan float %702 to double
  %710 = fpext float %698 to double
  %711 = fmul double %708, %709
  %712 = fmul double %711, %710
  %713 = fptrunc double %712 to float
  %714 = fcmp oeq float %704, 0.000000e+00
  %715 = tail call float @llvm.fabs.f32(float %698)
  %716 = fcmp one float %715, +inf
  %717 = and i1 %714, %716
  %718 = select i1 %717, float 0.000000e+00, float %713
  br label %719

719:                                              ; preds = %707, %696
  %720 = phi float [ %718, %707 ], [ %705, %696 ]
  %721 = extractelement <8 x float> %697, i64 1
  %722 = fmul float %721, %702
  %723 = extractelement <8 x float> %360, i64 1
  %724 = fmul float %723, %722
  %725 = tail call i1 @llvm.is.fpclass.f32(float %722, /* (sub norm) */ i32 408)
  br i1 %725, label %738, label %726

726:                                              ; preds = %719
  %727 = fpext float %723 to double
  %728 = fpext nnan float %702 to double
  %729 = fpext float %721 to double
  %730 = fmul double %727, %728
  %731 = fmul double %730, %729
  %732 = fptrunc double %731 to float
  %733 = fcmp oeq float %723, 0.000000e+00
  %734 = tail call float @llvm.fabs.f32(float %721)
  %735 = fcmp one float %734, +inf
  %736 = and i1 %733, %735
  %737 = select i1 %736, float 0.000000e+00, float %732
  br label %738

738:                                              ; preds = %726, %719
  %739 = phi float [ %737, %726 ], [ %724, %719 ]
  %740 = extractelement <8 x float> %697, i64 2
  %741 = fmul float %740, %702
  %742 = extractelement <8 x float> %360, i64 2
  %743 = fmul float %742, %741
  %744 = tail call i1 @llvm.is.fpclass.f32(float %741, /* (sub norm) */ i32 408)
  br i1 %744, label %757, label %745

745:                                              ; preds = %738
  %746 = fpext float %742 to double
  %747 = fpext nnan float %702 to double
  %748 = fpext float %740 to double
  %749 = fmul double %746, %747
  %750 = fmul double %749, %748
  %751 = fptrunc double %750 to float
  %752 = fcmp oeq float %742, 0.000000e+00
  %753 = tail call float @llvm.fabs.f32(float %740)
  %754 = fcmp one float %753, +inf
  %755 = and i1 %752, %754
  %756 = select i1 %755, float 0.000000e+00, float %751
  br label %757

757:                                              ; preds = %745, %738
  %758 = phi float [ %756, %745 ], [ %743, %738 ]
  %759 = extractelement <8 x float> %697, i64 3
  %760 = fmul float %759, %702
  %761 = extractelement <8 x float> %360, i64 3
  %762 = fmul float %761, %760
  %763 = tail call i1 @llvm.is.fpclass.f32(float %760, /* (sub norm) */ i32 408)
  br i1 %763, label %776, label %764

764:                                              ; preds = %757
  %765 = fpext float %761 to double
  %766 = fpext nnan float %702 to double
  %767 = fpext float %759 to double
  %768 = fmul double %765, %766
  %769 = fmul double %768, %767
  %770 = fptrunc double %769 to float
  %771 = fcmp oeq float %761, 0.000000e+00
  %772 = tail call float @llvm.fabs.f32(float %759)
  %773 = fcmp one float %772, +inf
  %774 = and i1 %771, %773
  %775 = select i1 %774, float 0.000000e+00, float %770
  br label %776

776:                                              ; preds = %764, %757
  %777 = phi float [ %775, %764 ], [ %762, %757 ]
  %778 = extractelement <8 x float> %697, i64 4
  %779 = fmul float %778, %702
  %780 = extractelement <8 x float> %360, i64 4
  %781 = fmul float %780, %779
  %782 = tail call i1 @llvm.is.fpclass.f32(float %779, /* (sub norm) */ i32 408)
  br i1 %782, label %795, label %783

783:                                              ; preds = %776
  %784 = fpext float %780 to double
  %785 = fpext nnan float %702 to double
  %786 = fpext float %778 to double
  %787 = fmul double %784, %785
  %788 = fmul double %787, %786
  %789 = fptrunc double %788 to float
  %790 = fcmp oeq float %780, 0.000000e+00
  %791 = tail call float @llvm.fabs.f32(float %778)
  %792 = fcmp one float %791, +inf
  %793 = and i1 %790, %792
  %794 = select i1 %793, float 0.000000e+00, float %789
  br label %795

795:                                              ; preds = %783, %776
  %796 = phi float [ %794, %783 ], [ %781, %776 ]
  %797 = extractelement <8 x float> %697, i64 5
  %798 = fmul float %797, %702
  %799 = extractelement <8 x float> %360, i64 5
  %800 = fmul float %799, %798
  %801 = tail call i1 @llvm.is.fpclass.f32(float %798, /* (sub norm) */ i32 408)
  br i1 %801, label %814, label %802

802:                                              ; preds = %795
  %803 = fpext float %799 to double
  %804 = fpext nnan float %702 to double
  %805 = fpext float %797 to double
  %806 = fmul double %803, %804
  %807 = fmul double %806, %805
  %808 = fptrunc double %807 to float
  %809 = fcmp oeq float %799, 0.000000e+00
  %810 = tail call float @llvm.fabs.f32(float %797)
  %811 = fcmp one float %810, +inf
  %812 = and i1 %809, %811
  %813 = select i1 %812, float 0.000000e+00, float %808
  br label %814

814:                                              ; preds = %802, %795
  %815 = phi float [ %813, %802 ], [ %800, %795 ]
  %816 = extractelement <8 x float> %697, i64 6
  %817 = fmul float %816, %702
  %818 = extractelement <8 x float> %360, i64 6
  %819 = fmul float %818, %817
  %820 = tail call i1 @llvm.is.fpclass.f32(float %817, /* (sub norm) */ i32 408)
  br i1 %820, label %833, label %821

821:                                              ; preds = %814
  %822 = fpext float %818 to double
  %823 = fpext nnan float %702 to double
  %824 = fpext float %816 to double
  %825 = fmul double %822, %823
  %826 = fmul double %825, %824
  %827 = fptrunc double %826 to float
  %828 = fcmp oeq float %818, 0.000000e+00
  %829 = tail call float @llvm.fabs.f32(float %816)
  %830 = fcmp one float %829, +inf
  %831 = and i1 %828, %830
  %832 = select i1 %831, float 0.000000e+00, float %827
  br label %833

833:                                              ; preds = %821, %814
  %834 = phi float [ %832, %821 ], [ %819, %814 ]
  %835 = extractelement <8 x float> %697, i64 7
  %836 = fmul float %835, %702
  %837 = extractelement <8 x float> %360, i64 7
  %838 = fmul float %837, %836
  %839 = tail call i1 @llvm.is.fpclass.f32(float %836, /* (sub norm) */ i32 408)
  br i1 %839, label %852, label %840

840:                                              ; preds = %833
  %841 = fpext float %837 to double
  %842 = fpext nnan float %702 to double
  %843 = fpext float %835 to double
  %844 = fmul double %841, %842
  %845 = fmul double %844, %843
  %846 = fptrunc double %845 to float
  %847 = fcmp oeq float %837, 0.000000e+00
  %848 = tail call float @llvm.fabs.f32(float %835)
  %849 = fcmp one float %848, +inf
  %850 = and i1 %847, %849
  %851 = select i1 %850, float 0.000000e+00, float %846
  br label %852

852:                                              ; preds = %840, %833
  %853 = phi float [ %851, %840 ], [ %838, %833 ]
  %854 = mul i64 %637, %26
  %855 = fptrunc float %720 to bfloat
  %856 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %854
  %857 = getelementptr [2 x i8], ptr addrspace(1) %856, i64 %368
  store bfloat %855, ptr addrspace(1) %857, align 2
  %858 = or disjoint i64 %58, %595
  %859 = mul i64 %858, %26
  %860 = fptrunc float %739 to bfloat
  %861 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %859
  %862 = getelementptr [2 x i8], ptr addrspace(1) %861, i64 %368
  store bfloat %860, ptr addrspace(1) %862, align 2
  %863 = or disjoint i64 %58, %601
  %864 = mul i64 %863, %26
  %865 = fptrunc float %758 to bfloat
  %866 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %864
  %867 = getelementptr [2 x i8], ptr addrspace(1) %866, i64 %368
  store bfloat %865, ptr addrspace(1) %867, align 2
  %868 = or disjoint i64 %58, %607
  %869 = mul i64 %868, %26
  %870 = fptrunc float %777 to bfloat
  %871 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %869
  %872 = getelementptr [2 x i8], ptr addrspace(1) %871, i64 %368
  store bfloat %870, ptr addrspace(1) %872, align 2
  %873 = or disjoint i64 %58, %613
  %874 = mul i64 %873, %26
  %875 = fptrunc float %796 to bfloat
  %876 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %874
  %877 = getelementptr [2 x i8], ptr addrspace(1) %876, i64 %368
  store bfloat %875, ptr addrspace(1) %877, align 2
  %878 = or disjoint i64 %58, %619
  %879 = mul i64 %878, %26
  %880 = fptrunc float %815 to bfloat
  %881 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %879
  %882 = getelementptr [2 x i8], ptr addrspace(1) %881, i64 %368
  store bfloat %880, ptr addrspace(1) %882, align 2
  %883 = or disjoint i64 %58, %625
  %884 = mul i64 %883, %26
  %885 = fptrunc float %834 to bfloat
  %886 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %884
  %887 = getelementptr [2 x i8], ptr addrspace(1) %886, i64 %368
  store bfloat %885, ptr addrspace(1) %887, align 2
  %888 = or disjoint i64 %58, %631
  %889 = mul i64 %888, %26
  %890 = fptrunc float %853 to bfloat
  %891 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %889
  %892 = getelementptr [2 x i8], ptr addrspace(1) %891, i64 %368
  store bfloat %890, ptr addrspace(1) %892, align 2
  %893 = or disjoint i64 %60, %116
  %894 = or disjoint i64 %893, 7
  %895 = icmp ult i64 %894, %25
  %896 = and i1 %370, %895
  %897 = and i1 %375, %896
  br i1 %897, label %898, label %904

898:                                              ; preds = %852
  %899 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %893
  %900 = load <4 x float>, ptr addrspace(1) %899, align 16
  %901 = getelementptr i8, ptr addrspace(1) %899, i64 16
  %902 = load <4 x float>, ptr addrspace(1) %901, align 16
  %903 = shufflevector <4 x float> %900, <4 x float> %902, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %952

904:                                              ; preds = %852
  %905 = icmp slt i64 %893, %25
  %906 = select i1 %905, i64 %893, i64 0
  %907 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %906
  %908 = load float, ptr addrspace(1) %907, align 4
  %909 = insertelement <8 x float> poison, float %908, i64 0
  %910 = or disjoint i64 %60, %595
  %911 = icmp slt i64 %910, %25
  %912 = select i1 %911, i64 %910, i64 0
  %913 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %912
  %914 = load float, ptr addrspace(1) %913, align 4
  %915 = insertelement <8 x float> %909, float %914, i64 1
  %916 = or disjoint i64 %60, %601
  %917 = icmp slt i64 %916, %25
  %918 = select i1 %917, i64 %916, i64 0
  %919 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %918
  %920 = load float, ptr addrspace(1) %919, align 4
  %921 = insertelement <8 x float> %915, float %920, i64 2
  %922 = or disjoint i64 %60, %607
  %923 = icmp slt i64 %922, %25
  %924 = select i1 %923, i64 %922, i64 0
  %925 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %924
  %926 = load float, ptr addrspace(1) %925, align 4
  %927 = insertelement <8 x float> %921, float %926, i64 3
  %928 = or disjoint i64 %60, %613
  %929 = icmp slt i64 %928, %25
  %930 = select i1 %929, i64 %928, i64 0
  %931 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %930
  %932 = load float, ptr addrspace(1) %931, align 4
  %933 = insertelement <8 x float> %927, float %932, i64 4
  %934 = or disjoint i64 %60, %619
  %935 = icmp slt i64 %934, %25
  %936 = select i1 %935, i64 %934, i64 0
  %937 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %936
  %938 = load float, ptr addrspace(1) %937, align 4
  %939 = insertelement <8 x float> %933, float %938, i64 5
  %940 = or disjoint i64 %60, %625
  %941 = icmp slt i64 %940, %25
  %942 = select i1 %941, i64 %940, i64 0
  %943 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %942
  %944 = load float, ptr addrspace(1) %943, align 4
  %945 = insertelement <8 x float> %939, float %944, i64 6
  %946 = or disjoint i64 %60, %631
  %947 = icmp slt i64 %946, %25
  %948 = select i1 %947, i64 %946, i64 0
  %949 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %948
  %950 = load float, ptr addrspace(1) %949, align 4
  %951 = insertelement <8 x float> %945, float %950, i64 7
  br label %952

952:                                              ; preds = %898, %904
  %953 = phi <8 x float> [ %951, %904 ], [ %903, %898 ]
  %954 = extractelement <8 x float> %953, i64 0
  %955 = load i8, ptr addrspace(1) %435, align 1
  %956 = zext i8 %955 to i32
  %957 = shl nuw nsw i32 %956, 23
  %958 = bitcast i32 %957 to float
  %959 = fmul float %954, %958
  %960 = extractelement <8 x float> %362, i64 0
  %961 = fmul float %960, %959
  %962 = tail call i1 @llvm.is.fpclass.f32(float %959, /* (sub norm) */ i32 408)
  br i1 %962, label %975, label %963

963:                                              ; preds = %952
  %964 = fpext float %960 to double
  %965 = fpext nnan float %958 to double
  %966 = fpext float %954 to double
  %967 = fmul double %964, %965
  %968 = fmul double %967, %966
  %969 = fptrunc double %968 to float
  %970 = fcmp oeq float %960, 0.000000e+00
  %971 = tail call float @llvm.fabs.f32(float %954)
  %972 = fcmp one float %971, +inf
  %973 = and i1 %970, %972
  %974 = select i1 %973, float 0.000000e+00, float %969
  br label %975

975:                                              ; preds = %963, %952
  %976 = phi float [ %974, %963 ], [ %961, %952 ]
  %977 = extractelement <8 x float> %953, i64 1
  %978 = fmul float %977, %958
  %979 = extractelement <8 x float> %362, i64 1
  %980 = fmul float %979, %978
  %981 = tail call i1 @llvm.is.fpclass.f32(float %978, /* (sub norm) */ i32 408)
  br i1 %981, label %994, label %982

982:                                              ; preds = %975
  %983 = fpext float %979 to double
  %984 = fpext nnan float %958 to double
  %985 = fpext float %977 to double
  %986 = fmul double %983, %984
  %987 = fmul double %986, %985
  %988 = fptrunc double %987 to float
  %989 = fcmp oeq float %979, 0.000000e+00
  %990 = tail call float @llvm.fabs.f32(float %977)
  %991 = fcmp one float %990, +inf
  %992 = and i1 %989, %991
  %993 = select i1 %992, float 0.000000e+00, float %988
  br label %994

994:                                              ; preds = %982, %975
  %995 = phi float [ %993, %982 ], [ %980, %975 ]
  %996 = extractelement <8 x float> %953, i64 2
  %997 = fmul float %996, %958
  %998 = extractelement <8 x float> %362, i64 2
  %999 = fmul float %998, %997
  %1000 = tail call i1 @llvm.is.fpclass.f32(float %997, /* (sub norm) */ i32 408)
  br i1 %1000, label %1013, label %1001

1001:                                             ; preds = %994
  %1002 = fpext float %998 to double
  %1003 = fpext nnan float %958 to double
  %1004 = fpext float %996 to double
  %1005 = fmul double %1002, %1003
  %1006 = fmul double %1005, %1004
  %1007 = fptrunc double %1006 to float
  %1008 = fcmp oeq float %998, 0.000000e+00
  %1009 = tail call float @llvm.fabs.f32(float %996)
  %1010 = fcmp one float %1009, +inf
  %1011 = and i1 %1008, %1010
  %1012 = select i1 %1011, float 0.000000e+00, float %1007
  br label %1013

1013:                                             ; preds = %1001, %994
  %1014 = phi float [ %1012, %1001 ], [ %999, %994 ]
  %1015 = extractelement <8 x float> %953, i64 3
  %1016 = fmul float %1015, %958
  %1017 = extractelement <8 x float> %362, i64 3
  %1018 = fmul float %1017, %1016
  %1019 = tail call i1 @llvm.is.fpclass.f32(float %1016, /* (sub norm) */ i32 408)
  br i1 %1019, label %1032, label %1020

1020:                                             ; preds = %1013
  %1021 = fpext float %1017 to double
  %1022 = fpext nnan float %958 to double
  %1023 = fpext float %1015 to double
  %1024 = fmul double %1021, %1022
  %1025 = fmul double %1024, %1023
  %1026 = fptrunc double %1025 to float
  %1027 = fcmp oeq float %1017, 0.000000e+00
  %1028 = tail call float @llvm.fabs.f32(float %1015)
  %1029 = fcmp one float %1028, +inf
  %1030 = and i1 %1027, %1029
  %1031 = select i1 %1030, float 0.000000e+00, float %1026
  br label %1032

1032:                                             ; preds = %1020, %1013
  %1033 = phi float [ %1031, %1020 ], [ %1018, %1013 ]
  %1034 = extractelement <8 x float> %953, i64 4
  %1035 = fmul float %1034, %958
  %1036 = extractelement <8 x float> %362, i64 4
  %1037 = fmul float %1036, %1035
  %1038 = tail call i1 @llvm.is.fpclass.f32(float %1035, /* (sub norm) */ i32 408)
  br i1 %1038, label %1051, label %1039

1039:                                             ; preds = %1032
  %1040 = fpext float %1036 to double
  %1041 = fpext nnan float %958 to double
  %1042 = fpext float %1034 to double
  %1043 = fmul double %1040, %1041
  %1044 = fmul double %1043, %1042
  %1045 = fptrunc double %1044 to float
  %1046 = fcmp oeq float %1036, 0.000000e+00
  %1047 = tail call float @llvm.fabs.f32(float %1034)
  %1048 = fcmp one float %1047, +inf
  %1049 = and i1 %1046, %1048
  %1050 = select i1 %1049, float 0.000000e+00, float %1045
  br label %1051

1051:                                             ; preds = %1039, %1032
  %1052 = phi float [ %1050, %1039 ], [ %1037, %1032 ]
  %1053 = extractelement <8 x float> %953, i64 5
  %1054 = fmul float %1053, %958
  %1055 = extractelement <8 x float> %362, i64 5
  %1056 = fmul float %1055, %1054
  %1057 = tail call i1 @llvm.is.fpclass.f32(float %1054, /* (sub norm) */ i32 408)
  br i1 %1057, label %1070, label %1058

1058:                                             ; preds = %1051
  %1059 = fpext float %1055 to double
  %1060 = fpext nnan float %958 to double
  %1061 = fpext float %1053 to double
  %1062 = fmul double %1059, %1060
  %1063 = fmul double %1062, %1061
  %1064 = fptrunc double %1063 to float
  %1065 = fcmp oeq float %1055, 0.000000e+00
  %1066 = tail call float @llvm.fabs.f32(float %1053)
  %1067 = fcmp one float %1066, +inf
  %1068 = and i1 %1065, %1067
  %1069 = select i1 %1068, float 0.000000e+00, float %1064
  br label %1070

1070:                                             ; preds = %1058, %1051
  %1071 = phi float [ %1069, %1058 ], [ %1056, %1051 ]
  %1072 = extractelement <8 x float> %953, i64 6
  %1073 = fmul float %1072, %958
  %1074 = extractelement <8 x float> %362, i64 6
  %1075 = fmul float %1074, %1073
  %1076 = tail call i1 @llvm.is.fpclass.f32(float %1073, /* (sub norm) */ i32 408)
  br i1 %1076, label %1089, label %1077

1077:                                             ; preds = %1070
  %1078 = fpext float %1074 to double
  %1079 = fpext nnan float %958 to double
  %1080 = fpext float %1072 to double
  %1081 = fmul double %1078, %1079
  %1082 = fmul double %1081, %1080
  %1083 = fptrunc double %1082 to float
  %1084 = fcmp oeq float %1074, 0.000000e+00
  %1085 = tail call float @llvm.fabs.f32(float %1072)
  %1086 = fcmp one float %1085, +inf
  %1087 = and i1 %1084, %1086
  %1088 = select i1 %1087, float 0.000000e+00, float %1083
  br label %1089

1089:                                             ; preds = %1077, %1070
  %1090 = phi float [ %1088, %1077 ], [ %1075, %1070 ]
  %1091 = extractelement <8 x float> %953, i64 7
  %1092 = fmul float %1091, %958
  %1093 = extractelement <8 x float> %362, i64 7
  %1094 = fmul float %1093, %1092
  %1095 = tail call i1 @llvm.is.fpclass.f32(float %1092, /* (sub norm) */ i32 408)
  br i1 %1095, label %1108, label %1096

1096:                                             ; preds = %1089
  %1097 = fpext float %1093 to double
  %1098 = fpext nnan float %958 to double
  %1099 = fpext float %1091 to double
  %1100 = fmul double %1097, %1098
  %1101 = fmul double %1100, %1099
  %1102 = fptrunc double %1101 to float
  %1103 = fcmp oeq float %1093, 0.000000e+00
  %1104 = tail call float @llvm.fabs.f32(float %1091)
  %1105 = fcmp one float %1104, +inf
  %1106 = and i1 %1103, %1105
  %1107 = select i1 %1106, float 0.000000e+00, float %1102
  br label %1108

1108:                                             ; preds = %1096, %1089
  %1109 = phi float [ %1107, %1096 ], [ %1094, %1089 ]
  %1110 = mul i64 %893, %26
  %1111 = fptrunc float %976 to bfloat
  %1112 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1110
  %1113 = getelementptr [2 x i8], ptr addrspace(1) %1112, i64 %368
  store bfloat %1111, ptr addrspace(1) %1113, align 2
  %1114 = or disjoint i64 %60, %595
  %1115 = mul i64 %1114, %26
  %1116 = fptrunc float %995 to bfloat
  %1117 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1115
  %1118 = getelementptr [2 x i8], ptr addrspace(1) %1117, i64 %368
  store bfloat %1116, ptr addrspace(1) %1118, align 2
  %1119 = or disjoint i64 %60, %601
  %1120 = mul i64 %1119, %26
  %1121 = fptrunc float %1014 to bfloat
  %1122 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1120
  %1123 = getelementptr [2 x i8], ptr addrspace(1) %1122, i64 %368
  store bfloat %1121, ptr addrspace(1) %1123, align 2
  %1124 = or disjoint i64 %60, %607
  %1125 = mul i64 %1124, %26
  %1126 = fptrunc float %1033 to bfloat
  %1127 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1125
  %1128 = getelementptr [2 x i8], ptr addrspace(1) %1127, i64 %368
  store bfloat %1126, ptr addrspace(1) %1128, align 2
  %1129 = or disjoint i64 %60, %613
  %1130 = mul i64 %1129, %26
  %1131 = fptrunc float %1052 to bfloat
  %1132 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1130
  %1133 = getelementptr [2 x i8], ptr addrspace(1) %1132, i64 %368
  store bfloat %1131, ptr addrspace(1) %1133, align 2
  %1134 = or disjoint i64 %60, %619
  %1135 = mul i64 %1134, %26
  %1136 = fptrunc float %1071 to bfloat
  %1137 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1135
  %1138 = getelementptr [2 x i8], ptr addrspace(1) %1137, i64 %368
  store bfloat %1136, ptr addrspace(1) %1138, align 2
  %1139 = or disjoint i64 %60, %625
  %1140 = mul i64 %1139, %26
  %1141 = fptrunc float %1090 to bfloat
  %1142 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1140
  %1143 = getelementptr [2 x i8], ptr addrspace(1) %1142, i64 %368
  store bfloat %1141, ptr addrspace(1) %1143, align 2
  %1144 = or disjoint i64 %60, %631
  %1145 = mul i64 %1144, %26
  %1146 = fptrunc float %1109 to bfloat
  %1147 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1145
  %1148 = getelementptr [2 x i8], ptr addrspace(1) %1147, i64 %368
  store bfloat %1146, ptr addrspace(1) %1148, align 2
  %1149 = or disjoint i64 %62, %116
  %1150 = or disjoint i64 %1149, 7
  %1151 = icmp ult i64 %1150, %25
  %1152 = and i1 %370, %1151
  %1153 = and i1 %375, %1152
  br i1 %1153, label %1154, label %1160

1154:                                             ; preds = %1108
  %1155 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %1149
  %1156 = load <4 x float>, ptr addrspace(1) %1155, align 16
  %1157 = getelementptr i8, ptr addrspace(1) %1155, i64 16
  %1158 = load <4 x float>, ptr addrspace(1) %1157, align 16
  %1159 = shufflevector <4 x float> %1156, <4 x float> %1158, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1208

1160:                                             ; preds = %1108
  %1161 = icmp slt i64 %1149, %25
  %1162 = select i1 %1161, i64 %1149, i64 0
  %1163 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1162
  %1164 = load float, ptr addrspace(1) %1163, align 4
  %1165 = insertelement <8 x float> poison, float %1164, i64 0
  %1166 = or disjoint i64 %62, %595
  %1167 = icmp slt i64 %1166, %25
  %1168 = select i1 %1167, i64 %1166, i64 0
  %1169 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1168
  %1170 = load float, ptr addrspace(1) %1169, align 4
  %1171 = insertelement <8 x float> %1165, float %1170, i64 1
  %1172 = or disjoint i64 %62, %601
  %1173 = icmp slt i64 %1172, %25
  %1174 = select i1 %1173, i64 %1172, i64 0
  %1175 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1174
  %1176 = load float, ptr addrspace(1) %1175, align 4
  %1177 = insertelement <8 x float> %1171, float %1176, i64 2
  %1178 = or disjoint i64 %62, %607
  %1179 = icmp slt i64 %1178, %25
  %1180 = select i1 %1179, i64 %1178, i64 0
  %1181 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1180
  %1182 = load float, ptr addrspace(1) %1181, align 4
  %1183 = insertelement <8 x float> %1177, float %1182, i64 3
  %1184 = or disjoint i64 %62, %613
  %1185 = icmp slt i64 %1184, %25
  %1186 = select i1 %1185, i64 %1184, i64 0
  %1187 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1186
  %1188 = load float, ptr addrspace(1) %1187, align 4
  %1189 = insertelement <8 x float> %1183, float %1188, i64 4
  %1190 = or disjoint i64 %62, %619
  %1191 = icmp slt i64 %1190, %25
  %1192 = select i1 %1191, i64 %1190, i64 0
  %1193 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1192
  %1194 = load float, ptr addrspace(1) %1193, align 4
  %1195 = insertelement <8 x float> %1189, float %1194, i64 5
  %1196 = or disjoint i64 %62, %625
  %1197 = icmp slt i64 %1196, %25
  %1198 = select i1 %1197, i64 %1196, i64 0
  %1199 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1198
  %1200 = load float, ptr addrspace(1) %1199, align 4
  %1201 = insertelement <8 x float> %1195, float %1200, i64 6
  %1202 = or disjoint i64 %62, %631
  %1203 = icmp slt i64 %1202, %25
  %1204 = select i1 %1203, i64 %1202, i64 0
  %1205 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1204
  %1206 = load float, ptr addrspace(1) %1205, align 4
  %1207 = insertelement <8 x float> %1201, float %1206, i64 7
  br label %1208

1208:                                             ; preds = %1154, %1160
  %1209 = phi <8 x float> [ %1207, %1160 ], [ %1159, %1154 ]
  %1210 = extractelement <8 x float> %1209, i64 0
  %1211 = load i8, ptr addrspace(1) %435, align 1
  %1212 = zext i8 %1211 to i32
  %1213 = shl nuw nsw i32 %1212, 23
  %1214 = bitcast i32 %1213 to float
  %1215 = fmul float %1210, %1214
  %1216 = extractelement <8 x float> %364, i64 0
  %1217 = fmul float %1216, %1215
  %1218 = tail call i1 @llvm.is.fpclass.f32(float %1215, /* (sub norm) */ i32 408)
  br i1 %1218, label %1231, label %1219

1219:                                             ; preds = %1208
  %1220 = fpext float %1216 to double
  %1221 = fpext nnan float %1214 to double
  %1222 = fpext float %1210 to double
  %1223 = fmul double %1220, %1221
  %1224 = fmul double %1223, %1222
  %1225 = fptrunc double %1224 to float
  %1226 = fcmp oeq float %1216, 0.000000e+00
  %1227 = tail call float @llvm.fabs.f32(float %1210)
  %1228 = fcmp one float %1227, +inf
  %1229 = and i1 %1226, %1228
  %1230 = select i1 %1229, float 0.000000e+00, float %1225
  br label %1231

1231:                                             ; preds = %1219, %1208
  %1232 = phi float [ %1230, %1219 ], [ %1217, %1208 ]
  %1233 = extractelement <8 x float> %1209, i64 1
  %1234 = fmul float %1233, %1214
  %1235 = extractelement <8 x float> %364, i64 1
  %1236 = fmul float %1235, %1234
  %1237 = tail call i1 @llvm.is.fpclass.f32(float %1234, /* (sub norm) */ i32 408)
  br i1 %1237, label %1250, label %1238

1238:                                             ; preds = %1231
  %1239 = fpext float %1235 to double
  %1240 = fpext nnan float %1214 to double
  %1241 = fpext float %1233 to double
  %1242 = fmul double %1239, %1240
  %1243 = fmul double %1242, %1241
  %1244 = fptrunc double %1243 to float
  %1245 = fcmp oeq float %1235, 0.000000e+00
  %1246 = tail call float @llvm.fabs.f32(float %1233)
  %1247 = fcmp one float %1246, +inf
  %1248 = and i1 %1245, %1247
  %1249 = select i1 %1248, float 0.000000e+00, float %1244
  br label %1250

1250:                                             ; preds = %1238, %1231
  %1251 = phi float [ %1249, %1238 ], [ %1236, %1231 ]
  %1252 = extractelement <8 x float> %1209, i64 2
  %1253 = fmul float %1252, %1214
  %1254 = extractelement <8 x float> %364, i64 2
  %1255 = fmul float %1254, %1253
  %1256 = tail call i1 @llvm.is.fpclass.f32(float %1253, /* (sub norm) */ i32 408)
  br i1 %1256, label %1269, label %1257

1257:                                             ; preds = %1250
  %1258 = fpext float %1254 to double
  %1259 = fpext nnan float %1214 to double
  %1260 = fpext float %1252 to double
  %1261 = fmul double %1258, %1259
  %1262 = fmul double %1261, %1260
  %1263 = fptrunc double %1262 to float
  %1264 = fcmp oeq float %1254, 0.000000e+00
  %1265 = tail call float @llvm.fabs.f32(float %1252)
  %1266 = fcmp one float %1265, +inf
  %1267 = and i1 %1264, %1266
  %1268 = select i1 %1267, float 0.000000e+00, float %1263
  br label %1269

1269:                                             ; preds = %1257, %1250
  %1270 = phi float [ %1268, %1257 ], [ %1255, %1250 ]
  %1271 = extractelement <8 x float> %1209, i64 3
  %1272 = fmul float %1271, %1214
  %1273 = extractelement <8 x float> %364, i64 3
  %1274 = fmul float %1273, %1272
  %1275 = tail call i1 @llvm.is.fpclass.f32(float %1272, /* (sub norm) */ i32 408)
  br i1 %1275, label %1288, label %1276

1276:                                             ; preds = %1269
  %1277 = fpext float %1273 to double
  %1278 = fpext nnan float %1214 to double
  %1279 = fpext float %1271 to double
  %1280 = fmul double %1277, %1278
  %1281 = fmul double %1280, %1279
  %1282 = fptrunc double %1281 to float
  %1283 = fcmp oeq float %1273, 0.000000e+00
  %1284 = tail call float @llvm.fabs.f32(float %1271)
  %1285 = fcmp one float %1284, +inf
  %1286 = and i1 %1283, %1285
  %1287 = select i1 %1286, float 0.000000e+00, float %1282
  br label %1288

1288:                                             ; preds = %1276, %1269
  %1289 = phi float [ %1287, %1276 ], [ %1274, %1269 ]
  %1290 = extractelement <8 x float> %1209, i64 4
  %1291 = fmul float %1290, %1214
  %1292 = extractelement <8 x float> %364, i64 4
  %1293 = fmul float %1292, %1291
  %1294 = tail call i1 @llvm.is.fpclass.f32(float %1291, /* (sub norm) */ i32 408)
  br i1 %1294, label %1307, label %1295

1295:                                             ; preds = %1288
  %1296 = fpext float %1292 to double
  %1297 = fpext nnan float %1214 to double
  %1298 = fpext float %1290 to double
  %1299 = fmul double %1296, %1297
  %1300 = fmul double %1299, %1298
  %1301 = fptrunc double %1300 to float
  %1302 = fcmp oeq float %1292, 0.000000e+00
  %1303 = tail call float @llvm.fabs.f32(float %1290)
  %1304 = fcmp one float %1303, +inf
  %1305 = and i1 %1302, %1304
  %1306 = select i1 %1305, float 0.000000e+00, float %1301
  br label %1307

1307:                                             ; preds = %1295, %1288
  %1308 = phi float [ %1306, %1295 ], [ %1293, %1288 ]
  %1309 = extractelement <8 x float> %1209, i64 5
  %1310 = fmul float %1309, %1214
  %1311 = extractelement <8 x float> %364, i64 5
  %1312 = fmul float %1311, %1310
  %1313 = tail call i1 @llvm.is.fpclass.f32(float %1310, /* (sub norm) */ i32 408)
  br i1 %1313, label %1326, label %1314

1314:                                             ; preds = %1307
  %1315 = fpext float %1311 to double
  %1316 = fpext nnan float %1214 to double
  %1317 = fpext float %1309 to double
  %1318 = fmul double %1315, %1316
  %1319 = fmul double %1318, %1317
  %1320 = fptrunc double %1319 to float
  %1321 = fcmp oeq float %1311, 0.000000e+00
  %1322 = tail call float @llvm.fabs.f32(float %1309)
  %1323 = fcmp one float %1322, +inf
  %1324 = and i1 %1321, %1323
  %1325 = select i1 %1324, float 0.000000e+00, float %1320
  br label %1326

1326:                                             ; preds = %1314, %1307
  %1327 = phi float [ %1325, %1314 ], [ %1312, %1307 ]
  %1328 = extractelement <8 x float> %1209, i64 6
  %1329 = fmul float %1328, %1214
  %1330 = extractelement <8 x float> %364, i64 6
  %1331 = fmul float %1330, %1329
  %1332 = tail call i1 @llvm.is.fpclass.f32(float %1329, /* (sub norm) */ i32 408)
  br i1 %1332, label %1345, label %1333

1333:                                             ; preds = %1326
  %1334 = fpext float %1330 to double
  %1335 = fpext nnan float %1214 to double
  %1336 = fpext float %1328 to double
  %1337 = fmul double %1334, %1335
  %1338 = fmul double %1337, %1336
  %1339 = fptrunc double %1338 to float
  %1340 = fcmp oeq float %1330, 0.000000e+00
  %1341 = tail call float @llvm.fabs.f32(float %1328)
  %1342 = fcmp one float %1341, +inf
  %1343 = and i1 %1340, %1342
  %1344 = select i1 %1343, float 0.000000e+00, float %1339
  br label %1345

1345:                                             ; preds = %1333, %1326
  %1346 = phi float [ %1344, %1333 ], [ %1331, %1326 ]
  %1347 = extractelement <8 x float> %1209, i64 7
  %1348 = fmul float %1347, %1214
  %1349 = extractelement <8 x float> %364, i64 7
  %1350 = fmul float %1349, %1348
  %1351 = tail call i1 @llvm.is.fpclass.f32(float %1348, /* (sub norm) */ i32 408)
  br i1 %1351, label %1364, label %1352

1352:                                             ; preds = %1345
  %1353 = fpext float %1349 to double
  %1354 = fpext nnan float %1214 to double
  %1355 = fpext float %1347 to double
  %1356 = fmul double %1353, %1354
  %1357 = fmul double %1356, %1355
  %1358 = fptrunc double %1357 to float
  %1359 = fcmp oeq float %1349, 0.000000e+00
  %1360 = tail call float @llvm.fabs.f32(float %1347)
  %1361 = fcmp one float %1360, +inf
  %1362 = and i1 %1359, %1361
  %1363 = select i1 %1362, float 0.000000e+00, float %1358
  br label %1364

1364:                                             ; preds = %1352, %1345
  %1365 = phi float [ %1363, %1352 ], [ %1350, %1345 ]
  %1366 = mul i64 %1149, %26
  %1367 = fptrunc float %1232 to bfloat
  %1368 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1366
  %1369 = getelementptr [2 x i8], ptr addrspace(1) %1368, i64 %368
  store bfloat %1367, ptr addrspace(1) %1369, align 2
  %1370 = or disjoint i64 %62, %595
  %1371 = mul i64 %1370, %26
  %1372 = fptrunc float %1251 to bfloat
  %1373 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1371
  %1374 = getelementptr [2 x i8], ptr addrspace(1) %1373, i64 %368
  store bfloat %1372, ptr addrspace(1) %1374, align 2
  %1375 = or disjoint i64 %62, %601
  %1376 = mul i64 %1375, %26
  %1377 = fptrunc float %1270 to bfloat
  %1378 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1376
  %1379 = getelementptr [2 x i8], ptr addrspace(1) %1378, i64 %368
  store bfloat %1377, ptr addrspace(1) %1379, align 2
  %1380 = or disjoint i64 %62, %607
  %1381 = mul i64 %1380, %26
  %1382 = fptrunc float %1289 to bfloat
  %1383 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1381
  %1384 = getelementptr [2 x i8], ptr addrspace(1) %1383, i64 %368
  store bfloat %1382, ptr addrspace(1) %1384, align 2
  %1385 = or disjoint i64 %62, %613
  %1386 = mul i64 %1385, %26
  %1387 = fptrunc float %1308 to bfloat
  %1388 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1386
  %1389 = getelementptr [2 x i8], ptr addrspace(1) %1388, i64 %368
  store bfloat %1387, ptr addrspace(1) %1389, align 2
  %1390 = or disjoint i64 %62, %619
  %1391 = mul i64 %1390, %26
  %1392 = fptrunc float %1327 to bfloat
  %1393 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1391
  %1394 = getelementptr [2 x i8], ptr addrspace(1) %1393, i64 %368
  store bfloat %1392, ptr addrspace(1) %1394, align 2
  %1395 = or disjoint i64 %62, %625
  %1396 = mul i64 %1395, %26
  %1397 = fptrunc float %1346 to bfloat
  %1398 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1396
  %1399 = getelementptr [2 x i8], ptr addrspace(1) %1398, i64 %368
  store bfloat %1397, ptr addrspace(1) %1399, align 2
  %1400 = or disjoint i64 %62, %631
  %1401 = mul i64 %1400, %26
  %1402 = fptrunc float %1365 to bfloat
  %1403 = getelementptr [2 x i8], ptr addrspace(1) %29, i64 %1401
  %1404 = getelementptr [2 x i8], ptr addrspace(1) %1403, i64 %368
  store bfloat %1402, ptr addrspace(1) %1404, align 2
  %1405 = or disjoint i64 %.pre-phi72, %55
  %1406 = icmp ult i64 %1405, %26
  %1407 = and i1 %1406, %371
  %1408 = and i1 %375, %1407
  br i1 %1408, label %1409, label %1415

1409:                                             ; preds = %1364
  %1410 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %366
  %1411 = load <4 x float>, ptr addrspace(1) %1410, align 16
  %1412 = getelementptr i8, ptr addrspace(1) %1410, i64 16
  %1413 = load <4 x float>, ptr addrspace(1) %1412, align 16
  %1414 = shufflevector <4 x float> %1411, <4 x float> %1413, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1456

1415:                                             ; preds = %1364
  %1416 = icmp slt i64 %366, %25
  %1417 = select i1 %1416, i64 %366, i64 0
  %1418 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1417
  %1419 = load float, ptr addrspace(1) %1418, align 4
  %1420 = insertelement <8 x float> poison, float %1419, i64 0
  %1421 = icmp slt i64 %596, %25
  %1422 = select i1 %1421, i64 %596, i64 0
  %1423 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1422
  %1424 = load float, ptr addrspace(1) %1423, align 4
  %1425 = insertelement <8 x float> %1420, float %1424, i64 1
  %1426 = icmp slt i64 %602, %25
  %1427 = select i1 %1426, i64 %602, i64 0
  %1428 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1427
  %1429 = load float, ptr addrspace(1) %1428, align 4
  %1430 = insertelement <8 x float> %1425, float %1429, i64 2
  %1431 = icmp slt i64 %608, %25
  %1432 = select i1 %1431, i64 %608, i64 0
  %1433 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1432
  %1434 = load float, ptr addrspace(1) %1433, align 4
  %1435 = insertelement <8 x float> %1430, float %1434, i64 3
  %1436 = icmp slt i64 %614, %25
  %1437 = select i1 %1436, i64 %614, i64 0
  %1438 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1437
  %1439 = load float, ptr addrspace(1) %1438, align 4
  %1440 = insertelement <8 x float> %1435, float %1439, i64 4
  %1441 = icmp slt i64 %620, %25
  %1442 = select i1 %1441, i64 %620, i64 0
  %1443 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1442
  %1444 = load float, ptr addrspace(1) %1443, align 4
  %1445 = insertelement <8 x float> %1440, float %1444, i64 5
  %1446 = icmp slt i64 %626, %25
  %1447 = select i1 %1446, i64 %626, i64 0
  %1448 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1447
  %1449 = load float, ptr addrspace(1) %1448, align 4
  %1450 = insertelement <8 x float> %1445, float %1449, i64 6
  %1451 = icmp slt i64 %632, %25
  %1452 = select i1 %1451, i64 %632, i64 0
  %1453 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1452
  %1454 = load float, ptr addrspace(1) %1453, align 4
  %1455 = insertelement <8 x float> %1450, float %1454, i64 7
  br label %1456

1456:                                             ; preds = %1409, %1415
  %1457 = phi <8 x float> [ %1455, %1415 ], [ %1414, %1409 ]
  %1458 = icmp slt i64 %1405, %26
  %1459 = select i1 %1458, i64 %1405, i64 0
  %1460 = extractelement <8 x float> %1457, i64 0
  %1461 = getelementptr inbounds i8, ptr addrspace(1) %30, i64 %1459
  %1462 = load i8, ptr addrspace(1) %1461, align 1
  %1463 = zext i8 %1462 to i32
  %1464 = shl nuw nsw i32 %1463, 23
  %1465 = bitcast i32 %1464 to float
  %1466 = fmul float %1460, %1465
  %1467 = extractelement <8 x float> %359, i64 0
  %1468 = fmul float %1467, %1466
  %1469 = tail call i1 @llvm.is.fpclass.f32(float %1466, /* (sub norm) */ i32 408)
  br i1 %1469, label %1482, label %1470

1470:                                             ; preds = %1456
  %1471 = fpext float %1467 to double
  %1472 = fpext nnan float %1465 to double
  %1473 = fpext float %1460 to double
  %1474 = fmul double %1471, %1472
  %1475 = fmul double %1474, %1473
  %1476 = fptrunc double %1475 to float
  %1477 = fcmp oeq float %1467, 0.000000e+00
  %1478 = tail call float @llvm.fabs.f32(float %1460)
  %1479 = fcmp one float %1478, +inf
  %1480 = and i1 %1477, %1479
  %1481 = select i1 %1480, float 0.000000e+00, float %1476
  br label %1482

1482:                                             ; preds = %1470, %1456
  %1483 = phi float [ %1481, %1470 ], [ %1468, %1456 ]
  %1484 = extractelement <8 x float> %1457, i64 1
  %1485 = fmul float %1484, %1465
  %1486 = extractelement <8 x float> %359, i64 1
  %1487 = fmul float %1486, %1485
  %1488 = tail call i1 @llvm.is.fpclass.f32(float %1485, /* (sub norm) */ i32 408)
  br i1 %1488, label %1501, label %1489

1489:                                             ; preds = %1482
  %1490 = fpext float %1486 to double
  %1491 = fpext nnan float %1465 to double
  %1492 = fpext float %1484 to double
  %1493 = fmul double %1490, %1491
  %1494 = fmul double %1493, %1492
  %1495 = fptrunc double %1494 to float
  %1496 = fcmp oeq float %1486, 0.000000e+00
  %1497 = tail call float @llvm.fabs.f32(float %1484)
  %1498 = fcmp one float %1497, +inf
  %1499 = and i1 %1496, %1498
  %1500 = select i1 %1499, float 0.000000e+00, float %1495
  br label %1501

1501:                                             ; preds = %1489, %1482
  %1502 = phi float [ %1500, %1489 ], [ %1487, %1482 ]
  %1503 = extractelement <8 x float> %1457, i64 2
  %1504 = fmul float %1503, %1465
  %1505 = extractelement <8 x float> %359, i64 2
  %1506 = fmul float %1505, %1504
  %1507 = tail call i1 @llvm.is.fpclass.f32(float %1504, /* (sub norm) */ i32 408)
  br i1 %1507, label %1520, label %1508

1508:                                             ; preds = %1501
  %1509 = fpext float %1505 to double
  %1510 = fpext nnan float %1465 to double
  %1511 = fpext float %1503 to double
  %1512 = fmul double %1509, %1510
  %1513 = fmul double %1512, %1511
  %1514 = fptrunc double %1513 to float
  %1515 = fcmp oeq float %1505, 0.000000e+00
  %1516 = tail call float @llvm.fabs.f32(float %1503)
  %1517 = fcmp one float %1516, +inf
  %1518 = and i1 %1515, %1517
  %1519 = select i1 %1518, float 0.000000e+00, float %1514
  br label %1520

1520:                                             ; preds = %1508, %1501
  %1521 = phi float [ %1519, %1508 ], [ %1506, %1501 ]
  %1522 = extractelement <8 x float> %1457, i64 3
  %1523 = fmul float %1522, %1465
  %1524 = extractelement <8 x float> %359, i64 3
  %1525 = fmul float %1524, %1523
  %1526 = tail call i1 @llvm.is.fpclass.f32(float %1523, /* (sub norm) */ i32 408)
  br i1 %1526, label %1539, label %1527

1527:                                             ; preds = %1520
  %1528 = fpext float %1524 to double
  %1529 = fpext nnan float %1465 to double
  %1530 = fpext float %1522 to double
  %1531 = fmul double %1528, %1529
  %1532 = fmul double %1531, %1530
  %1533 = fptrunc double %1532 to float
  %1534 = fcmp oeq float %1524, 0.000000e+00
  %1535 = tail call float @llvm.fabs.f32(float %1522)
  %1536 = fcmp one float %1535, +inf
  %1537 = and i1 %1534, %1536
  %1538 = select i1 %1537, float 0.000000e+00, float %1533
  br label %1539

1539:                                             ; preds = %1527, %1520
  %1540 = phi float [ %1538, %1527 ], [ %1525, %1520 ]
  %1541 = extractelement <8 x float> %1457, i64 4
  %1542 = fmul float %1541, %1465
  %1543 = extractelement <8 x float> %359, i64 4
  %1544 = fmul float %1543, %1542
  %1545 = tail call i1 @llvm.is.fpclass.f32(float %1542, /* (sub norm) */ i32 408)
  br i1 %1545, label %1558, label %1546

1546:                                             ; preds = %1539
  %1547 = fpext float %1543 to double
  %1548 = fpext nnan float %1465 to double
  %1549 = fpext float %1541 to double
  %1550 = fmul double %1547, %1548
  %1551 = fmul double %1550, %1549
  %1552 = fptrunc double %1551 to float
  %1553 = fcmp oeq float %1543, 0.000000e+00
  %1554 = tail call float @llvm.fabs.f32(float %1541)
  %1555 = fcmp one float %1554, +inf
  %1556 = and i1 %1553, %1555
  %1557 = select i1 %1556, float 0.000000e+00, float %1552
  br label %1558

1558:                                             ; preds = %1546, %1539
  %1559 = phi float [ %1557, %1546 ], [ %1544, %1539 ]
  %1560 = extractelement <8 x float> %1457, i64 5
  %1561 = fmul float %1560, %1465
  %1562 = extractelement <8 x float> %359, i64 5
  %1563 = fmul float %1562, %1561
  %1564 = tail call i1 @llvm.is.fpclass.f32(float %1561, /* (sub norm) */ i32 408)
  br i1 %1564, label %1577, label %1565

1565:                                             ; preds = %1558
  %1566 = fpext float %1562 to double
  %1567 = fpext nnan float %1465 to double
  %1568 = fpext float %1560 to double
  %1569 = fmul double %1566, %1567
  %1570 = fmul double %1569, %1568
  %1571 = fptrunc double %1570 to float
  %1572 = fcmp oeq float %1562, 0.000000e+00
  %1573 = tail call float @llvm.fabs.f32(float %1560)
  %1574 = fcmp one float %1573, +inf
  %1575 = and i1 %1572, %1574
  %1576 = select i1 %1575, float 0.000000e+00, float %1571
  br label %1577

1577:                                             ; preds = %1565, %1558
  %1578 = phi float [ %1576, %1565 ], [ %1563, %1558 ]
  %1579 = extractelement <8 x float> %1457, i64 6
  %1580 = fmul float %1579, %1465
  %1581 = extractelement <8 x float> %359, i64 6
  %1582 = fmul float %1581, %1580
  %1583 = tail call i1 @llvm.is.fpclass.f32(float %1580, /* (sub norm) */ i32 408)
  br i1 %1583, label %1596, label %1584

1584:                                             ; preds = %1577
  %1585 = fpext float %1581 to double
  %1586 = fpext nnan float %1465 to double
  %1587 = fpext float %1579 to double
  %1588 = fmul double %1585, %1586
  %1589 = fmul double %1588, %1587
  %1590 = fptrunc double %1589 to float
  %1591 = fcmp oeq float %1581, 0.000000e+00
  %1592 = tail call float @llvm.fabs.f32(float %1579)
  %1593 = fcmp one float %1592, +inf
  %1594 = and i1 %1591, %1593
  %1595 = select i1 %1594, float 0.000000e+00, float %1590
  br label %1596

1596:                                             ; preds = %1584, %1577
  %1597 = phi float [ %1595, %1584 ], [ %1582, %1577 ]
  %1598 = extractelement <8 x float> %1457, i64 7
  %1599 = fmul float %1598, %1465
  %1600 = extractelement <8 x float> %359, i64 7
  %1601 = fmul float %1600, %1599
  %1602 = tail call i1 @llvm.is.fpclass.f32(float %1599, /* (sub norm) */ i32 408)
  br i1 %1602, label %1615, label %1603

1603:                                             ; preds = %1596
  %1604 = fpext float %1600 to double
  %1605 = fpext nnan float %1465 to double
  %1606 = fpext float %1598 to double
  %1607 = fmul double %1604, %1605
  %1608 = fmul double %1607, %1606
  %1609 = fptrunc double %1608 to float
  %1610 = fcmp oeq float %1600, 0.000000e+00
  %1611 = tail call float @llvm.fabs.f32(float %1598)
  %1612 = fcmp one float %1611, +inf
  %1613 = and i1 %1610, %1612
  %1614 = select i1 %1613, float 0.000000e+00, float %1609
  br label %1615

1615:                                             ; preds = %1603, %1596
  %1616 = phi float [ %1614, %1603 ], [ %1601, %1596 ]
  %1617 = fptrunc float %1483 to bfloat
  %1618 = getelementptr [2 x i8], ptr addrspace(1) %593, i64 %1405
  store bfloat %1617, ptr addrspace(1) %1618, align 2
  %1619 = fptrunc float %1502 to bfloat
  %1620 = getelementptr [2 x i8], ptr addrspace(1) %599, i64 %1405
  store bfloat %1619, ptr addrspace(1) %1620, align 2
  %1621 = fptrunc float %1521 to bfloat
  %1622 = getelementptr [2 x i8], ptr addrspace(1) %605, i64 %1405
  store bfloat %1621, ptr addrspace(1) %1622, align 2
  %1623 = fptrunc float %1540 to bfloat
  %1624 = getelementptr [2 x i8], ptr addrspace(1) %611, i64 %1405
  store bfloat %1623, ptr addrspace(1) %1624, align 2
  %1625 = fptrunc float %1559 to bfloat
  %1626 = getelementptr [2 x i8], ptr addrspace(1) %617, i64 %1405
  store bfloat %1625, ptr addrspace(1) %1626, align 2
  %1627 = fptrunc float %1578 to bfloat
  %1628 = getelementptr [2 x i8], ptr addrspace(1) %623, i64 %1405
  store bfloat %1627, ptr addrspace(1) %1628, align 2
  %1629 = fptrunc float %1597 to bfloat
  %1630 = getelementptr [2 x i8], ptr addrspace(1) %629, i64 %1405
  store bfloat %1629, ptr addrspace(1) %1630, align 2
  %1631 = fptrunc float %1616 to bfloat
  %1632 = getelementptr [2 x i8], ptr addrspace(1) %635, i64 %1405
  store bfloat %1631, ptr addrspace(1) %1632, align 2
  %1633 = and i1 %1406, %639
  %1634 = and i1 %375, %1633
  br i1 %1634, label %1635, label %1641

1635:                                             ; preds = %1615
  %1636 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %637
  %1637 = load <4 x float>, ptr addrspace(1) %1636, align 16
  %1638 = getelementptr i8, ptr addrspace(1) %1636, i64 16
  %1639 = load <4 x float>, ptr addrspace(1) %1638, align 16
  %1640 = shufflevector <4 x float> %1637, <4 x float> %1639, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1682

1641:                                             ; preds = %1615
  %1642 = icmp slt i64 %637, %25
  %1643 = select i1 %1642, i64 %637, i64 0
  %1644 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1643
  %1645 = load float, ptr addrspace(1) %1644, align 4
  %1646 = insertelement <8 x float> poison, float %1645, i64 0
  %1647 = icmp slt i64 %858, %25
  %1648 = select i1 %1647, i64 %858, i64 0
  %1649 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1648
  %1650 = load float, ptr addrspace(1) %1649, align 4
  %1651 = insertelement <8 x float> %1646, float %1650, i64 1
  %1652 = icmp slt i64 %863, %25
  %1653 = select i1 %1652, i64 %863, i64 0
  %1654 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1653
  %1655 = load float, ptr addrspace(1) %1654, align 4
  %1656 = insertelement <8 x float> %1651, float %1655, i64 2
  %1657 = icmp slt i64 %868, %25
  %1658 = select i1 %1657, i64 %868, i64 0
  %1659 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1658
  %1660 = load float, ptr addrspace(1) %1659, align 4
  %1661 = insertelement <8 x float> %1656, float %1660, i64 3
  %1662 = icmp slt i64 %873, %25
  %1663 = select i1 %1662, i64 %873, i64 0
  %1664 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1663
  %1665 = load float, ptr addrspace(1) %1664, align 4
  %1666 = insertelement <8 x float> %1661, float %1665, i64 4
  %1667 = icmp slt i64 %878, %25
  %1668 = select i1 %1667, i64 %878, i64 0
  %1669 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1668
  %1670 = load float, ptr addrspace(1) %1669, align 4
  %1671 = insertelement <8 x float> %1666, float %1670, i64 5
  %1672 = icmp slt i64 %883, %25
  %1673 = select i1 %1672, i64 %883, i64 0
  %1674 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1673
  %1675 = load float, ptr addrspace(1) %1674, align 4
  %1676 = insertelement <8 x float> %1671, float %1675, i64 6
  %1677 = icmp slt i64 %888, %25
  %1678 = select i1 %1677, i64 %888, i64 0
  %1679 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1678
  %1680 = load float, ptr addrspace(1) %1679, align 4
  %1681 = insertelement <8 x float> %1676, float %1680, i64 7
  br label %1682

1682:                                             ; preds = %1635, %1641
  %1683 = phi <8 x float> [ %1681, %1641 ], [ %1640, %1635 ]
  %1684 = extractelement <8 x float> %1683, i64 0
  %1685 = load i8, ptr addrspace(1) %1461, align 1
  %1686 = zext i8 %1685 to i32
  %1687 = shl nuw nsw i32 %1686, 23
  %1688 = bitcast i32 %1687 to float
  %1689 = fmul float %1684, %1688
  %1690 = extractelement <8 x float> %361, i64 0
  %1691 = fmul float %1690, %1689
  %1692 = tail call i1 @llvm.is.fpclass.f32(float %1689, /* (sub norm) */ i32 408)
  br i1 %1692, label %1705, label %1693

1693:                                             ; preds = %1682
  %1694 = fpext float %1690 to double
  %1695 = fpext nnan float %1688 to double
  %1696 = fpext float %1684 to double
  %1697 = fmul double %1694, %1695
  %1698 = fmul double %1697, %1696
  %1699 = fptrunc double %1698 to float
  %1700 = fcmp oeq float %1690, 0.000000e+00
  %1701 = tail call float @llvm.fabs.f32(float %1684)
  %1702 = fcmp one float %1701, +inf
  %1703 = and i1 %1700, %1702
  %1704 = select i1 %1703, float 0.000000e+00, float %1699
  br label %1705

1705:                                             ; preds = %1693, %1682
  %1706 = phi float [ %1704, %1693 ], [ %1691, %1682 ]
  %1707 = extractelement <8 x float> %1683, i64 1
  %1708 = fmul float %1707, %1688
  %1709 = extractelement <8 x float> %361, i64 1
  %1710 = fmul float %1709, %1708
  %1711 = tail call i1 @llvm.is.fpclass.f32(float %1708, /* (sub norm) */ i32 408)
  br i1 %1711, label %1724, label %1712

1712:                                             ; preds = %1705
  %1713 = fpext float %1709 to double
  %1714 = fpext nnan float %1688 to double
  %1715 = fpext float %1707 to double
  %1716 = fmul double %1713, %1714
  %1717 = fmul double %1716, %1715
  %1718 = fptrunc double %1717 to float
  %1719 = fcmp oeq float %1709, 0.000000e+00
  %1720 = tail call float @llvm.fabs.f32(float %1707)
  %1721 = fcmp one float %1720, +inf
  %1722 = and i1 %1719, %1721
  %1723 = select i1 %1722, float 0.000000e+00, float %1718
  br label %1724

1724:                                             ; preds = %1712, %1705
  %1725 = phi float [ %1723, %1712 ], [ %1710, %1705 ]
  %1726 = extractelement <8 x float> %1683, i64 2
  %1727 = fmul float %1726, %1688
  %1728 = extractelement <8 x float> %361, i64 2
  %1729 = fmul float %1728, %1727
  %1730 = tail call i1 @llvm.is.fpclass.f32(float %1727, /* (sub norm) */ i32 408)
  br i1 %1730, label %1743, label %1731

1731:                                             ; preds = %1724
  %1732 = fpext float %1728 to double
  %1733 = fpext nnan float %1688 to double
  %1734 = fpext float %1726 to double
  %1735 = fmul double %1732, %1733
  %1736 = fmul double %1735, %1734
  %1737 = fptrunc double %1736 to float
  %1738 = fcmp oeq float %1728, 0.000000e+00
  %1739 = tail call float @llvm.fabs.f32(float %1726)
  %1740 = fcmp one float %1739, +inf
  %1741 = and i1 %1738, %1740
  %1742 = select i1 %1741, float 0.000000e+00, float %1737
  br label %1743

1743:                                             ; preds = %1731, %1724
  %1744 = phi float [ %1742, %1731 ], [ %1729, %1724 ]
  %1745 = extractelement <8 x float> %1683, i64 3
  %1746 = fmul float %1745, %1688
  %1747 = extractelement <8 x float> %361, i64 3
  %1748 = fmul float %1747, %1746
  %1749 = tail call i1 @llvm.is.fpclass.f32(float %1746, /* (sub norm) */ i32 408)
  br i1 %1749, label %1762, label %1750

1750:                                             ; preds = %1743
  %1751 = fpext float %1747 to double
  %1752 = fpext nnan float %1688 to double
  %1753 = fpext float %1745 to double
  %1754 = fmul double %1751, %1752
  %1755 = fmul double %1754, %1753
  %1756 = fptrunc double %1755 to float
  %1757 = fcmp oeq float %1747, 0.000000e+00
  %1758 = tail call float @llvm.fabs.f32(float %1745)
  %1759 = fcmp one float %1758, +inf
  %1760 = and i1 %1757, %1759
  %1761 = select i1 %1760, float 0.000000e+00, float %1756
  br label %1762

1762:                                             ; preds = %1750, %1743
  %1763 = phi float [ %1761, %1750 ], [ %1748, %1743 ]
  %1764 = extractelement <8 x float> %1683, i64 4
  %1765 = fmul float %1764, %1688
  %1766 = extractelement <8 x float> %361, i64 4
  %1767 = fmul float %1766, %1765
  %1768 = tail call i1 @llvm.is.fpclass.f32(float %1765, /* (sub norm) */ i32 408)
  br i1 %1768, label %1781, label %1769

1769:                                             ; preds = %1762
  %1770 = fpext float %1766 to double
  %1771 = fpext nnan float %1688 to double
  %1772 = fpext float %1764 to double
  %1773 = fmul double %1770, %1771
  %1774 = fmul double %1773, %1772
  %1775 = fptrunc double %1774 to float
  %1776 = fcmp oeq float %1766, 0.000000e+00
  %1777 = tail call float @llvm.fabs.f32(float %1764)
  %1778 = fcmp one float %1777, +inf
  %1779 = and i1 %1776, %1778
  %1780 = select i1 %1779, float 0.000000e+00, float %1775
  br label %1781

1781:                                             ; preds = %1769, %1762
  %1782 = phi float [ %1780, %1769 ], [ %1767, %1762 ]
  %1783 = extractelement <8 x float> %1683, i64 5
  %1784 = fmul float %1783, %1688
  %1785 = extractelement <8 x float> %361, i64 5
  %1786 = fmul float %1785, %1784
  %1787 = tail call i1 @llvm.is.fpclass.f32(float %1784, /* (sub norm) */ i32 408)
  br i1 %1787, label %1800, label %1788

1788:                                             ; preds = %1781
  %1789 = fpext float %1785 to double
  %1790 = fpext nnan float %1688 to double
  %1791 = fpext float %1783 to double
  %1792 = fmul double %1789, %1790
  %1793 = fmul double %1792, %1791
  %1794 = fptrunc double %1793 to float
  %1795 = fcmp oeq float %1785, 0.000000e+00
  %1796 = tail call float @llvm.fabs.f32(float %1783)
  %1797 = fcmp one float %1796, +inf
  %1798 = and i1 %1795, %1797
  %1799 = select i1 %1798, float 0.000000e+00, float %1794
  br label %1800

1800:                                             ; preds = %1788, %1781
  %1801 = phi float [ %1799, %1788 ], [ %1786, %1781 ]
  %1802 = extractelement <8 x float> %1683, i64 6
  %1803 = fmul float %1802, %1688
  %1804 = extractelement <8 x float> %361, i64 6
  %1805 = fmul float %1804, %1803
  %1806 = tail call i1 @llvm.is.fpclass.f32(float %1803, /* (sub norm) */ i32 408)
  br i1 %1806, label %1819, label %1807

1807:                                             ; preds = %1800
  %1808 = fpext float %1804 to double
  %1809 = fpext nnan float %1688 to double
  %1810 = fpext float %1802 to double
  %1811 = fmul double %1808, %1809
  %1812 = fmul double %1811, %1810
  %1813 = fptrunc double %1812 to float
  %1814 = fcmp oeq float %1804, 0.000000e+00
  %1815 = tail call float @llvm.fabs.f32(float %1802)
  %1816 = fcmp one float %1815, +inf
  %1817 = and i1 %1814, %1816
  %1818 = select i1 %1817, float 0.000000e+00, float %1813
  br label %1819

1819:                                             ; preds = %1807, %1800
  %1820 = phi float [ %1818, %1807 ], [ %1805, %1800 ]
  %1821 = extractelement <8 x float> %1683, i64 7
  %1822 = fmul float %1821, %1688
  %1823 = extractelement <8 x float> %361, i64 7
  %1824 = fmul float %1823, %1822
  %1825 = tail call i1 @llvm.is.fpclass.f32(float %1822, /* (sub norm) */ i32 408)
  br i1 %1825, label %1838, label %1826

1826:                                             ; preds = %1819
  %1827 = fpext float %1823 to double
  %1828 = fpext nnan float %1688 to double
  %1829 = fpext float %1821 to double
  %1830 = fmul double %1827, %1828
  %1831 = fmul double %1830, %1829
  %1832 = fptrunc double %1831 to float
  %1833 = fcmp oeq float %1823, 0.000000e+00
  %1834 = tail call float @llvm.fabs.f32(float %1821)
  %1835 = fcmp one float %1834, +inf
  %1836 = and i1 %1833, %1835
  %1837 = select i1 %1836, float 0.000000e+00, float %1832
  br label %1838

1838:                                             ; preds = %1826, %1819
  %1839 = phi float [ %1837, %1826 ], [ %1824, %1819 ]
  %1840 = fptrunc float %1706 to bfloat
  %1841 = getelementptr [2 x i8], ptr addrspace(1) %856, i64 %1405
  store bfloat %1840, ptr addrspace(1) %1841, align 2
  %1842 = fptrunc float %1725 to bfloat
  %1843 = getelementptr [2 x i8], ptr addrspace(1) %861, i64 %1405
  store bfloat %1842, ptr addrspace(1) %1843, align 2
  %1844 = fptrunc float %1744 to bfloat
  %1845 = getelementptr [2 x i8], ptr addrspace(1) %866, i64 %1405
  store bfloat %1844, ptr addrspace(1) %1845, align 2
  %1846 = fptrunc float %1763 to bfloat
  %1847 = getelementptr [2 x i8], ptr addrspace(1) %871, i64 %1405
  store bfloat %1846, ptr addrspace(1) %1847, align 2
  %1848 = fptrunc float %1782 to bfloat
  %1849 = getelementptr [2 x i8], ptr addrspace(1) %876, i64 %1405
  store bfloat %1848, ptr addrspace(1) %1849, align 2
  %1850 = fptrunc float %1801 to bfloat
  %1851 = getelementptr [2 x i8], ptr addrspace(1) %881, i64 %1405
  store bfloat %1850, ptr addrspace(1) %1851, align 2
  %1852 = fptrunc float %1820 to bfloat
  %1853 = getelementptr [2 x i8], ptr addrspace(1) %886, i64 %1405
  store bfloat %1852, ptr addrspace(1) %1853, align 2
  %1854 = fptrunc float %1839 to bfloat
  %1855 = getelementptr [2 x i8], ptr addrspace(1) %891, i64 %1405
  store bfloat %1854, ptr addrspace(1) %1855, align 2
  %1856 = and i1 %1406, %895
  %1857 = and i1 %375, %1856
  br i1 %1857, label %1858, label %1864

1858:                                             ; preds = %1838
  %1859 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %893
  %1860 = load <4 x float>, ptr addrspace(1) %1859, align 16
  %1861 = getelementptr i8, ptr addrspace(1) %1859, i64 16
  %1862 = load <4 x float>, ptr addrspace(1) %1861, align 16
  %1863 = shufflevector <4 x float> %1860, <4 x float> %1862, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1905

1864:                                             ; preds = %1838
  %1865 = icmp slt i64 %893, %25
  %1866 = select i1 %1865, i64 %893, i64 0
  %1867 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1866
  %1868 = load float, ptr addrspace(1) %1867, align 4
  %1869 = insertelement <8 x float> poison, float %1868, i64 0
  %1870 = icmp slt i64 %1114, %25
  %1871 = select i1 %1870, i64 %1114, i64 0
  %1872 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1871
  %1873 = load float, ptr addrspace(1) %1872, align 4
  %1874 = insertelement <8 x float> %1869, float %1873, i64 1
  %1875 = icmp slt i64 %1119, %25
  %1876 = select i1 %1875, i64 %1119, i64 0
  %1877 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1876
  %1878 = load float, ptr addrspace(1) %1877, align 4
  %1879 = insertelement <8 x float> %1874, float %1878, i64 2
  %1880 = icmp slt i64 %1124, %25
  %1881 = select i1 %1880, i64 %1124, i64 0
  %1882 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1881
  %1883 = load float, ptr addrspace(1) %1882, align 4
  %1884 = insertelement <8 x float> %1879, float %1883, i64 3
  %1885 = icmp slt i64 %1129, %25
  %1886 = select i1 %1885, i64 %1129, i64 0
  %1887 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1886
  %1888 = load float, ptr addrspace(1) %1887, align 4
  %1889 = insertelement <8 x float> %1884, float %1888, i64 4
  %1890 = icmp slt i64 %1134, %25
  %1891 = select i1 %1890, i64 %1134, i64 0
  %1892 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1891
  %1893 = load float, ptr addrspace(1) %1892, align 4
  %1894 = insertelement <8 x float> %1889, float %1893, i64 5
  %1895 = icmp slt i64 %1139, %25
  %1896 = select i1 %1895, i64 %1139, i64 0
  %1897 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1896
  %1898 = load float, ptr addrspace(1) %1897, align 4
  %1899 = insertelement <8 x float> %1894, float %1898, i64 6
  %1900 = icmp slt i64 %1144, %25
  %1901 = select i1 %1900, i64 %1144, i64 0
  %1902 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %1901
  %1903 = load float, ptr addrspace(1) %1902, align 4
  %1904 = insertelement <8 x float> %1899, float %1903, i64 7
  br label %1905

1905:                                             ; preds = %1858, %1864
  %1906 = phi <8 x float> [ %1904, %1864 ], [ %1863, %1858 ]
  %1907 = extractelement <8 x float> %1906, i64 0
  %1908 = load i8, ptr addrspace(1) %1461, align 1
  %1909 = zext i8 %1908 to i32
  %1910 = shl nuw nsw i32 %1909, 23
  %1911 = bitcast i32 %1910 to float
  %1912 = fmul float %1907, %1911
  %1913 = extractelement <8 x float> %363, i64 0
  %1914 = fmul float %1913, %1912
  %1915 = tail call i1 @llvm.is.fpclass.f32(float %1912, /* (sub norm) */ i32 408)
  br i1 %1915, label %1928, label %1916

1916:                                             ; preds = %1905
  %1917 = fpext float %1913 to double
  %1918 = fpext nnan float %1911 to double
  %1919 = fpext float %1907 to double
  %1920 = fmul double %1917, %1918
  %1921 = fmul double %1920, %1919
  %1922 = fptrunc double %1921 to float
  %1923 = fcmp oeq float %1913, 0.000000e+00
  %1924 = tail call float @llvm.fabs.f32(float %1907)
  %1925 = fcmp one float %1924, +inf
  %1926 = and i1 %1923, %1925
  %1927 = select i1 %1926, float 0.000000e+00, float %1922
  br label %1928

1928:                                             ; preds = %1916, %1905
  %1929 = phi float [ %1927, %1916 ], [ %1914, %1905 ]
  %1930 = extractelement <8 x float> %1906, i64 1
  %1931 = fmul float %1930, %1911
  %1932 = extractelement <8 x float> %363, i64 1
  %1933 = fmul float %1932, %1931
  %1934 = tail call i1 @llvm.is.fpclass.f32(float %1931, /* (sub norm) */ i32 408)
  br i1 %1934, label %1947, label %1935

1935:                                             ; preds = %1928
  %1936 = fpext float %1932 to double
  %1937 = fpext nnan float %1911 to double
  %1938 = fpext float %1930 to double
  %1939 = fmul double %1936, %1937
  %1940 = fmul double %1939, %1938
  %1941 = fptrunc double %1940 to float
  %1942 = fcmp oeq float %1932, 0.000000e+00
  %1943 = tail call float @llvm.fabs.f32(float %1930)
  %1944 = fcmp one float %1943, +inf
  %1945 = and i1 %1942, %1944
  %1946 = select i1 %1945, float 0.000000e+00, float %1941
  br label %1947

1947:                                             ; preds = %1935, %1928
  %1948 = phi float [ %1946, %1935 ], [ %1933, %1928 ]
  %1949 = extractelement <8 x float> %1906, i64 2
  %1950 = fmul float %1949, %1911
  %1951 = extractelement <8 x float> %363, i64 2
  %1952 = fmul float %1951, %1950
  %1953 = tail call i1 @llvm.is.fpclass.f32(float %1950, /* (sub norm) */ i32 408)
  br i1 %1953, label %1966, label %1954

1954:                                             ; preds = %1947
  %1955 = fpext float %1951 to double
  %1956 = fpext nnan float %1911 to double
  %1957 = fpext float %1949 to double
  %1958 = fmul double %1955, %1956
  %1959 = fmul double %1958, %1957
  %1960 = fptrunc double %1959 to float
  %1961 = fcmp oeq float %1951, 0.000000e+00
  %1962 = tail call float @llvm.fabs.f32(float %1949)
  %1963 = fcmp one float %1962, +inf
  %1964 = and i1 %1961, %1963
  %1965 = select i1 %1964, float 0.000000e+00, float %1960
  br label %1966

1966:                                             ; preds = %1954, %1947
  %1967 = phi float [ %1965, %1954 ], [ %1952, %1947 ]
  %1968 = extractelement <8 x float> %1906, i64 3
  %1969 = fmul float %1968, %1911
  %1970 = extractelement <8 x float> %363, i64 3
  %1971 = fmul float %1970, %1969
  %1972 = tail call i1 @llvm.is.fpclass.f32(float %1969, /* (sub norm) */ i32 408)
  br i1 %1972, label %1985, label %1973

1973:                                             ; preds = %1966
  %1974 = fpext float %1970 to double
  %1975 = fpext nnan float %1911 to double
  %1976 = fpext float %1968 to double
  %1977 = fmul double %1974, %1975
  %1978 = fmul double %1977, %1976
  %1979 = fptrunc double %1978 to float
  %1980 = fcmp oeq float %1970, 0.000000e+00
  %1981 = tail call float @llvm.fabs.f32(float %1968)
  %1982 = fcmp one float %1981, +inf
  %1983 = and i1 %1980, %1982
  %1984 = select i1 %1983, float 0.000000e+00, float %1979
  br label %1985

1985:                                             ; preds = %1973, %1966
  %1986 = phi float [ %1984, %1973 ], [ %1971, %1966 ]
  %1987 = extractelement <8 x float> %1906, i64 4
  %1988 = fmul float %1987, %1911
  %1989 = extractelement <8 x float> %363, i64 4
  %1990 = fmul float %1989, %1988
  %1991 = tail call i1 @llvm.is.fpclass.f32(float %1988, /* (sub norm) */ i32 408)
  br i1 %1991, label %2004, label %1992

1992:                                             ; preds = %1985
  %1993 = fpext float %1989 to double
  %1994 = fpext nnan float %1911 to double
  %1995 = fpext float %1987 to double
  %1996 = fmul double %1993, %1994
  %1997 = fmul double %1996, %1995
  %1998 = fptrunc double %1997 to float
  %1999 = fcmp oeq float %1989, 0.000000e+00
  %2000 = tail call float @llvm.fabs.f32(float %1987)
  %2001 = fcmp one float %2000, +inf
  %2002 = and i1 %1999, %2001
  %2003 = select i1 %2002, float 0.000000e+00, float %1998
  br label %2004

2004:                                             ; preds = %1992, %1985
  %2005 = phi float [ %2003, %1992 ], [ %1990, %1985 ]
  %2006 = extractelement <8 x float> %1906, i64 5
  %2007 = fmul float %2006, %1911
  %2008 = extractelement <8 x float> %363, i64 5
  %2009 = fmul float %2008, %2007
  %2010 = tail call i1 @llvm.is.fpclass.f32(float %2007, /* (sub norm) */ i32 408)
  br i1 %2010, label %2023, label %2011

2011:                                             ; preds = %2004
  %2012 = fpext float %2008 to double
  %2013 = fpext nnan float %1911 to double
  %2014 = fpext float %2006 to double
  %2015 = fmul double %2012, %2013
  %2016 = fmul double %2015, %2014
  %2017 = fptrunc double %2016 to float
  %2018 = fcmp oeq float %2008, 0.000000e+00
  %2019 = tail call float @llvm.fabs.f32(float %2006)
  %2020 = fcmp one float %2019, +inf
  %2021 = and i1 %2018, %2020
  %2022 = select i1 %2021, float 0.000000e+00, float %2017
  br label %2023

2023:                                             ; preds = %2011, %2004
  %2024 = phi float [ %2022, %2011 ], [ %2009, %2004 ]
  %2025 = extractelement <8 x float> %1906, i64 6
  %2026 = fmul float %2025, %1911
  %2027 = extractelement <8 x float> %363, i64 6
  %2028 = fmul float %2027, %2026
  %2029 = tail call i1 @llvm.is.fpclass.f32(float %2026, /* (sub norm) */ i32 408)
  br i1 %2029, label %2042, label %2030

2030:                                             ; preds = %2023
  %2031 = fpext float %2027 to double
  %2032 = fpext nnan float %1911 to double
  %2033 = fpext float %2025 to double
  %2034 = fmul double %2031, %2032
  %2035 = fmul double %2034, %2033
  %2036 = fptrunc double %2035 to float
  %2037 = fcmp oeq float %2027, 0.000000e+00
  %2038 = tail call float @llvm.fabs.f32(float %2025)
  %2039 = fcmp one float %2038, +inf
  %2040 = and i1 %2037, %2039
  %2041 = select i1 %2040, float 0.000000e+00, float %2036
  br label %2042

2042:                                             ; preds = %2030, %2023
  %2043 = phi float [ %2041, %2030 ], [ %2028, %2023 ]
  %2044 = extractelement <8 x float> %1906, i64 7
  %2045 = fmul float %2044, %1911
  %2046 = extractelement <8 x float> %363, i64 7
  %2047 = fmul float %2046, %2045
  %2048 = tail call i1 @llvm.is.fpclass.f32(float %2045, /* (sub norm) */ i32 408)
  br i1 %2048, label %2061, label %2049

2049:                                             ; preds = %2042
  %2050 = fpext float %2046 to double
  %2051 = fpext nnan float %1911 to double
  %2052 = fpext float %2044 to double
  %2053 = fmul double %2050, %2051
  %2054 = fmul double %2053, %2052
  %2055 = fptrunc double %2054 to float
  %2056 = fcmp oeq float %2046, 0.000000e+00
  %2057 = tail call float @llvm.fabs.f32(float %2044)
  %2058 = fcmp one float %2057, +inf
  %2059 = and i1 %2056, %2058
  %2060 = select i1 %2059, float 0.000000e+00, float %2055
  br label %2061

2061:                                             ; preds = %2049, %2042
  %2062 = phi float [ %2060, %2049 ], [ %2047, %2042 ]
  %2063 = fptrunc float %1929 to bfloat
  %2064 = getelementptr [2 x i8], ptr addrspace(1) %1112, i64 %1405
  store bfloat %2063, ptr addrspace(1) %2064, align 2
  %2065 = fptrunc float %1948 to bfloat
  %2066 = getelementptr [2 x i8], ptr addrspace(1) %1117, i64 %1405
  store bfloat %2065, ptr addrspace(1) %2066, align 2
  %2067 = fptrunc float %1967 to bfloat
  %2068 = getelementptr [2 x i8], ptr addrspace(1) %1122, i64 %1405
  store bfloat %2067, ptr addrspace(1) %2068, align 2
  %2069 = fptrunc float %1986 to bfloat
  %2070 = getelementptr [2 x i8], ptr addrspace(1) %1127, i64 %1405
  store bfloat %2069, ptr addrspace(1) %2070, align 2
  %2071 = fptrunc float %2005 to bfloat
  %2072 = getelementptr [2 x i8], ptr addrspace(1) %1132, i64 %1405
  store bfloat %2071, ptr addrspace(1) %2072, align 2
  %2073 = fptrunc float %2024 to bfloat
  %2074 = getelementptr [2 x i8], ptr addrspace(1) %1137, i64 %1405
  store bfloat %2073, ptr addrspace(1) %2074, align 2
  %2075 = fptrunc float %2043 to bfloat
  %2076 = getelementptr [2 x i8], ptr addrspace(1) %1142, i64 %1405
  store bfloat %2075, ptr addrspace(1) %2076, align 2
  %2077 = fptrunc float %2062 to bfloat
  %2078 = getelementptr [2 x i8], ptr addrspace(1) %1147, i64 %1405
  store bfloat %2077, ptr addrspace(1) %2078, align 2
  %2079 = and i1 %1406, %1151
  %2080 = and i1 %375, %2079
  br i1 %2080, label %2081, label %2087

2081:                                             ; preds = %2061
  %2082 = getelementptr [4 x i8], ptr addrspace(1) %31, i64 %1149
  %2083 = load <4 x float>, ptr addrspace(1) %2082, align 16
  %2084 = getelementptr i8, ptr addrspace(1) %2082, i64 16
  %2085 = load <4 x float>, ptr addrspace(1) %2084, align 16
  %2086 = shufflevector <4 x float> %2083, <4 x float> %2085, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2128

2087:                                             ; preds = %2061
  %2088 = icmp slt i64 %1149, %25
  %2089 = select i1 %2088, i64 %1149, i64 0
  %2090 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2089
  %2091 = load float, ptr addrspace(1) %2090, align 4
  %2092 = insertelement <8 x float> poison, float %2091, i64 0
  %2093 = icmp slt i64 %1370, %25
  %2094 = select i1 %2093, i64 %1370, i64 0
  %2095 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2094
  %2096 = load float, ptr addrspace(1) %2095, align 4
  %2097 = insertelement <8 x float> %2092, float %2096, i64 1
  %2098 = icmp slt i64 %1375, %25
  %2099 = select i1 %2098, i64 %1375, i64 0
  %2100 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2099
  %2101 = load float, ptr addrspace(1) %2100, align 4
  %2102 = insertelement <8 x float> %2097, float %2101, i64 2
  %2103 = icmp slt i64 %1380, %25
  %2104 = select i1 %2103, i64 %1380, i64 0
  %2105 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2104
  %2106 = load float, ptr addrspace(1) %2105, align 4
  %2107 = insertelement <8 x float> %2102, float %2106, i64 3
  %2108 = icmp slt i64 %1385, %25
  %2109 = select i1 %2108, i64 %1385, i64 0
  %2110 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2109
  %2111 = load float, ptr addrspace(1) %2110, align 4
  %2112 = insertelement <8 x float> %2107, float %2111, i64 4
  %2113 = icmp slt i64 %1390, %25
  %2114 = select i1 %2113, i64 %1390, i64 0
  %2115 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2114
  %2116 = load float, ptr addrspace(1) %2115, align 4
  %2117 = insertelement <8 x float> %2112, float %2116, i64 5
  %2118 = icmp slt i64 %1395, %25
  %2119 = select i1 %2118, i64 %1395, i64 0
  %2120 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2119
  %2121 = load float, ptr addrspace(1) %2120, align 4
  %2122 = insertelement <8 x float> %2117, float %2121, i64 6
  %2123 = icmp slt i64 %1400, %25
  %2124 = select i1 %2123, i64 %1400, i64 0
  %2125 = getelementptr inbounds [4 x i8], ptr addrspace(1) %31, i64 %2124
  %2126 = load float, ptr addrspace(1) %2125, align 4
  %2127 = insertelement <8 x float> %2122, float %2126, i64 7
  br label %2128

2128:                                             ; preds = %2081, %2087
  %2129 = phi <8 x float> [ %2127, %2087 ], [ %2086, %2081 ]
  %2130 = extractelement <8 x float> %2129, i64 0
  %2131 = load i8, ptr addrspace(1) %1461, align 1
  %2132 = zext i8 %2131 to i32
  %2133 = shl nuw nsw i32 %2132, 23
  %2134 = bitcast i32 %2133 to float
  %2135 = fmul float %2130, %2134
  %2136 = extractelement <8 x float> %365, i64 0
  %2137 = fmul float %2136, %2135
  %2138 = tail call i1 @llvm.is.fpclass.f32(float %2135, /* (sub norm) */ i32 408)
  br i1 %2138, label %2151, label %2139

2139:                                             ; preds = %2128
  %2140 = fpext float %2136 to double
  %2141 = fpext nnan float %2134 to double
  %2142 = fpext float %2130 to double
  %2143 = fmul double %2140, %2141
  %2144 = fmul double %2143, %2142
  %2145 = fptrunc double %2144 to float
  %2146 = fcmp oeq float %2136, 0.000000e+00
  %2147 = tail call float @llvm.fabs.f32(float %2130)
  %2148 = fcmp one float %2147, +inf
  %2149 = and i1 %2146, %2148
  %2150 = select i1 %2149, float 0.000000e+00, float %2145
  br label %2151

2151:                                             ; preds = %2139, %2128
  %2152 = phi float [ %2150, %2139 ], [ %2137, %2128 ]
  %2153 = extractelement <8 x float> %2129, i64 1
  %2154 = fmul float %2153, %2134
  %2155 = extractelement <8 x float> %365, i64 1
  %2156 = fmul float %2155, %2154
  %2157 = tail call i1 @llvm.is.fpclass.f32(float %2154, /* (sub norm) */ i32 408)
  br i1 %2157, label %2170, label %2158

2158:                                             ; preds = %2151
  %2159 = fpext float %2155 to double
  %2160 = fpext nnan float %2134 to double
  %2161 = fpext float %2153 to double
  %2162 = fmul double %2159, %2160
  %2163 = fmul double %2162, %2161
  %2164 = fptrunc double %2163 to float
  %2165 = fcmp oeq float %2155, 0.000000e+00
  %2166 = tail call float @llvm.fabs.f32(float %2153)
  %2167 = fcmp one float %2166, +inf
  %2168 = and i1 %2165, %2167
  %2169 = select i1 %2168, float 0.000000e+00, float %2164
  br label %2170

2170:                                             ; preds = %2158, %2151
  %2171 = phi float [ %2169, %2158 ], [ %2156, %2151 ]
  %2172 = extractelement <8 x float> %2129, i64 2
  %2173 = fmul float %2172, %2134
  %2174 = extractelement <8 x float> %365, i64 2
  %2175 = fmul float %2174, %2173
  %2176 = tail call i1 @llvm.is.fpclass.f32(float %2173, /* (sub norm) */ i32 408)
  br i1 %2176, label %2189, label %2177

2177:                                             ; preds = %2170
  %2178 = fpext float %2174 to double
  %2179 = fpext nnan float %2134 to double
  %2180 = fpext float %2172 to double
  %2181 = fmul double %2178, %2179
  %2182 = fmul double %2181, %2180
  %2183 = fptrunc double %2182 to float
  %2184 = fcmp oeq float %2174, 0.000000e+00
  %2185 = tail call float @llvm.fabs.f32(float %2172)
  %2186 = fcmp one float %2185, +inf
  %2187 = and i1 %2184, %2186
  %2188 = select i1 %2187, float 0.000000e+00, float %2183
  br label %2189

2189:                                             ; preds = %2177, %2170
  %2190 = phi float [ %2188, %2177 ], [ %2175, %2170 ]
  %2191 = extractelement <8 x float> %2129, i64 3
  %2192 = fmul float %2191, %2134
  %2193 = extractelement <8 x float> %365, i64 3
  %2194 = fmul float %2193, %2192
  %2195 = tail call i1 @llvm.is.fpclass.f32(float %2192, /* (sub norm) */ i32 408)
  br i1 %2195, label %2208, label %2196

2196:                                             ; preds = %2189
  %2197 = fpext float %2193 to double
  %2198 = fpext nnan float %2134 to double
  %2199 = fpext float %2191 to double
  %2200 = fmul double %2197, %2198
  %2201 = fmul double %2200, %2199
  %2202 = fptrunc double %2201 to float
  %2203 = fcmp oeq float %2193, 0.000000e+00
  %2204 = tail call float @llvm.fabs.f32(float %2191)
  %2205 = fcmp one float %2204, +inf
  %2206 = and i1 %2203, %2205
  %2207 = select i1 %2206, float 0.000000e+00, float %2202
  br label %2208

2208:                                             ; preds = %2196, %2189
  %2209 = phi float [ %2207, %2196 ], [ %2194, %2189 ]
  %2210 = extractelement <8 x float> %2129, i64 4
  %2211 = fmul float %2210, %2134
  %2212 = extractelement <8 x float> %365, i64 4
  %2213 = fmul float %2212, %2211
  %2214 = tail call i1 @llvm.is.fpclass.f32(float %2211, /* (sub norm) */ i32 408)
  br i1 %2214, label %2227, label %2215

2215:                                             ; preds = %2208
  %2216 = fpext float %2212 to double
  %2217 = fpext nnan float %2134 to double
  %2218 = fpext float %2210 to double
  %2219 = fmul double %2216, %2217
  %2220 = fmul double %2219, %2218
  %2221 = fptrunc double %2220 to float
  %2222 = fcmp oeq float %2212, 0.000000e+00
  %2223 = tail call float @llvm.fabs.f32(float %2210)
  %2224 = fcmp one float %2223, +inf
  %2225 = and i1 %2222, %2224
  %2226 = select i1 %2225, float 0.000000e+00, float %2221
  br label %2227

2227:                                             ; preds = %2215, %2208
  %2228 = phi float [ %2226, %2215 ], [ %2213, %2208 ]
  %2229 = extractelement <8 x float> %2129, i64 5
  %2230 = fmul float %2229, %2134
  %2231 = extractelement <8 x float> %365, i64 5
  %2232 = fmul float %2231, %2230
  %2233 = tail call i1 @llvm.is.fpclass.f32(float %2230, /* (sub norm) */ i32 408)
  br i1 %2233, label %2246, label %2234

2234:                                             ; preds = %2227
  %2235 = fpext float %2231 to double
  %2236 = fpext nnan float %2134 to double
  %2237 = fpext float %2229 to double
  %2238 = fmul double %2235, %2236
  %2239 = fmul double %2238, %2237
  %2240 = fptrunc double %2239 to float
  %2241 = fcmp oeq float %2231, 0.000000e+00
  %2242 = tail call float @llvm.fabs.f32(float %2229)
  %2243 = fcmp one float %2242, +inf
  %2244 = and i1 %2241, %2243
  %2245 = select i1 %2244, float 0.000000e+00, float %2240
  br label %2246

2246:                                             ; preds = %2234, %2227
  %2247 = phi float [ %2245, %2234 ], [ %2232, %2227 ]
  %2248 = extractelement <8 x float> %2129, i64 6
  %2249 = fmul float %2248, %2134
  %2250 = extractelement <8 x float> %365, i64 6
  %2251 = fmul float %2250, %2249
  %2252 = tail call i1 @llvm.is.fpclass.f32(float %2249, /* (sub norm) */ i32 408)
  br i1 %2252, label %2265, label %2253

2253:                                             ; preds = %2246
  %2254 = fpext float %2250 to double
  %2255 = fpext nnan float %2134 to double
  %2256 = fpext float %2248 to double
  %2257 = fmul double %2254, %2255
  %2258 = fmul double %2257, %2256
  %2259 = fptrunc double %2258 to float
  %2260 = fcmp oeq float %2250, 0.000000e+00
  %2261 = tail call float @llvm.fabs.f32(float %2248)
  %2262 = fcmp one float %2261, +inf
  %2263 = and i1 %2260, %2262
  %2264 = select i1 %2263, float 0.000000e+00, float %2259
  br label %2265

2265:                                             ; preds = %2253, %2246
  %2266 = phi float [ %2264, %2253 ], [ %2251, %2246 ]
  %2267 = extractelement <8 x float> %2129, i64 7
  %2268 = fmul float %2267, %2134
  %2269 = extractelement <8 x float> %365, i64 7
  %2270 = fmul float %2269, %2268
  %2271 = tail call i1 @llvm.is.fpclass.f32(float %2268, /* (sub norm) */ i32 408)
  br i1 %2271, label %2284, label %2272

2272:                                             ; preds = %2265
  %2273 = fpext float %2269 to double
  %2274 = fpext nnan float %2134 to double
  %2275 = fpext float %2267 to double
  %2276 = fmul double %2273, %2274
  %2277 = fmul double %2276, %2275
  %2278 = fptrunc double %2277 to float
  %2279 = fcmp oeq float %2269, 0.000000e+00
  %2280 = tail call float @llvm.fabs.f32(float %2267)
  %2281 = fcmp one float %2280, +inf
  %2282 = and i1 %2279, %2281
  %2283 = select i1 %2282, float 0.000000e+00, float %2278
  br label %2284

2284:                                             ; preds = %2272, %2265
  %2285 = phi float [ %2283, %2272 ], [ %2270, %2265 ]
  %2286 = fptrunc float %2152 to bfloat
  %2287 = getelementptr [2 x i8], ptr addrspace(1) %1368, i64 %1405
  store bfloat %2286, ptr addrspace(1) %2287, align 2
  %2288 = fptrunc float %2171 to bfloat
  %2289 = getelementptr [2 x i8], ptr addrspace(1) %1373, i64 %1405
  store bfloat %2288, ptr addrspace(1) %2289, align 2
  %2290 = fptrunc float %2190 to bfloat
  %2291 = getelementptr [2 x i8], ptr addrspace(1) %1378, i64 %1405
  store bfloat %2290, ptr addrspace(1) %2291, align 2
  %2292 = fptrunc float %2209 to bfloat
  %2293 = getelementptr [2 x i8], ptr addrspace(1) %1383, i64 %1405
  store bfloat %2292, ptr addrspace(1) %2293, align 2
  %2294 = fptrunc float %2228 to bfloat
  %2295 = getelementptr [2 x i8], ptr addrspace(1) %1388, i64 %1405
  store bfloat %2294, ptr addrspace(1) %2295, align 2
  %2296 = fptrunc float %2247 to bfloat
  %2297 = getelementptr [2 x i8], ptr addrspace(1) %1393, i64 %1405
  store bfloat %2296, ptr addrspace(1) %2297, align 2
  %2298 = fptrunc float %2266 to bfloat
  %2299 = getelementptr [2 x i8], ptr addrspace(1) %1398, i64 %1405
  store bfloat %2298, ptr addrspace(1) %2299, align 2
  %2300 = fptrunc float %2285 to bfloat
  %2301 = getelementptr [2 x i8], ptr addrspace(1) %1403, i64 %1405
  store bfloat %2300, ptr addrspace(1) %2301, align 2
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.is.fpclass.f32(float, i32 immarg) #6

attributes #0 = { norecurse nounwind "amdgpu-flat-work-group-size"="256,256" "amdgpu-no-cluster-id-x" "amdgpu-no-cluster-id-y" "amdgpu-no-cluster-id-z" "amdgpu-no-completion-action" "amdgpu-no-default-queue" "amdgpu-no-dispatch-id" "amdgpu-no-dispatch-ptr" "amdgpu-no-flat-scratch-init" "amdgpu-no-heap-ptr" "amdgpu-no-hostcall-ptr" "amdgpu-no-implicitarg-ptr" "amdgpu-no-lds-kernel-id" "amdgpu-no-multigrid-sync-arg" "amdgpu-no-queue-ptr" "amdgpu-no-workgroup-id-x" "amdgpu-no-workgroup-id-y" "amdgpu-no-workgroup-id-z" "amdgpu-no-workitem-id-x" "amdgpu-no-workitem-id-y" "amdgpu-no-workitem-id-z" "amdgpu-no-wwm" "target-cpu"="gfx1201" "target-features"="-cumode,+wavefrontsize32,-wavefrontsize64" "uniform-work-group-size" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #3 = { convergent mustprogress nocallback nofree nounwind willreturn "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #4 = { convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #5 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-cpu"="gfx1201" "target-features"="+wavefrontsize32,-wavefrontsize64" }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
!3 = !{}
