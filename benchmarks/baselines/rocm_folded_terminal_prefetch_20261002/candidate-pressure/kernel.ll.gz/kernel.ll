; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"

@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0 = internal addrspace(3) global [20480 x i8] undef
@__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1 = internal addrspace(3) global [5120 x i8] undef

define amdgpu_kernel void @tessera_rocm_folded_matmul_708d500594ff51c6(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5, ptr %6, i64 %7, i64 %8, i64 %9, ptr %10, ptr %11, i64 %12, i64 %13, i64 %14, ptr %15, ptr %16, i64 %17, i64 %18, i64 %19, ptr %20, ptr %21, i64 %22, i64 %23, i64 %24, i64 %25, i64 %26, i64 %27) #0 !reqd_work_group_size !1 {
  %29 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %20, 0
  %30 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %29, ptr %21, 1
  %31 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %30, i64 %22, 2
  %32 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %31, i64 %23, 3, 0
  %33 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %32, i64 %24, 4, 0
  %34 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %15, 0
  %35 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %34, ptr %16, 1
  %36 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %35, i64 %17, 2
  %37 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %36, i64 %18, 3, 0
  %38 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %37, i64 %19, 4, 0
  %39 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %10, 0
  %40 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %39, ptr %11, 1
  %41 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %40, i64 %12, 2
  %42 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %41, i64 %13, 3, 0
  %43 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %42, i64 %14, 4, 0
  %44 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %5, 0
  %45 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %44, ptr %6, 1
  %46 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %45, i64 %7, 2
  %47 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %46, i64 %8, 3, 0
  %48 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %47, i64 %9, 4, 0
  %49 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } poison, ptr %0, 0
  %50 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %49, ptr %1, 1
  %51 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %50, i64 %2, 2
  %52 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %51, i64 %3, 3, 0
  %53 = insertvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %52, i64 %4, 4, 0
  %54 = call range(i32 0, 256) i32 @llvm.amdgcn.workitem.id.x()
  %55 = sext i32 %54 to i64
  %56 = urem i64 %55, 32
  %57 = urem i64 %56, 16
  %58 = udiv i64 %56, 16
  %59 = udiv i64 %55, 32
  %60 = udiv i64 %59, 2
  %61 = urem i64 %59, 2
  %62 = call i32 @llvm.amdgcn.workgroup.id.x()
  %63 = sext i32 %62 to i64
  %64 = add i64 %25, 255
  %65 = udiv i64 %64, 256
  %66 = add i64 %26, 63
  %67 = udiv i64 %66, 64
  %68 = mul i64 %67, 4
  %69 = udiv i64 %63, %68
  %70 = mul i64 %69, 4
  %71 = sub i64 %65, %70
  %72 = icmp ult i64 %71, 4
  %73 = select i1 %72, i64 %71, i64 4
  %74 = urem i64 %63, %68
  %75 = urem i64 %74, %73
  %76 = add i64 %70, %75
  %77 = udiv i64 %74, %73
  %78 = mul i64 %76, 256
  %79 = mul i64 %77, 64
  %80 = mul i64 %60, 64
  %81 = mul i64 %61, 32
  %82 = add i64 %78, %80
  %83 = add i64 %80, 16
  %84 = add i64 %78, %83
  %85 = add i64 %80, 32
  %86 = add i64 %78, %85
  %87 = add i64 %80, 48
  %88 = add i64 %78, %87
  %89 = add i64 %79, %81
  %90 = add i64 %81, 16
  %91 = add i64 %79, %90
  %92 = udiv i64 %55, 4
  %93 = urem i64 %55, 4
  %94 = mul i64 %93, 16
  %95 = add i64 %78, %92
  %96 = mul i64 %95, %27
  %97 = add i64 %96, %94
  %98 = mul i64 %92, 80
  %99 = add i64 %98, %94
  %100 = add i64 %55, 256
  %101 = udiv i64 %100, 4
  %102 = urem i64 %100, 4
  %103 = mul i64 %102, 16
  %104 = add i64 %78, %101
  %105 = mul i64 %104, %27
  %106 = add i64 %105, %103
  %107 = mul i64 %101, 80
  %108 = add i64 %107, %103
  %109 = add i64 %55, 512
  %110 = udiv i64 %109, 4
  %111 = urem i64 %109, 4
  %112 = mul i64 %111, 16
  %113 = add i64 %78, %110
  %114 = mul i64 %113, %27
  %115 = add i64 %114, %112
  %116 = mul i64 %110, 80
  %117 = add i64 %116, %112
  %118 = add i64 %55, 768
  %119 = udiv i64 %118, 4
  %120 = urem i64 %118, 4
  %121 = mul i64 %120, 16
  %122 = add i64 %78, %119
  %123 = mul i64 %122, %27
  %124 = add i64 %123, %121
  %125 = mul i64 %119, 80
  %126 = add i64 %125, %121
  %127 = udiv i64 %55, 4
  %128 = urem i64 %55, 4
  %129 = mul i64 %128, 16
  %130 = add i64 %79, %127
  %131 = mul i64 %130, %27
  %132 = add i64 %131, %129
  %133 = mul i64 %127, 80
  %134 = add i64 %133, %129
  %135 = icmp uge i64 %27, 64
  call void @llvm.assume(i1 %135)
  %136 = udiv i64 %27, 64
  %137 = sub i64 %27, 64
  %138 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %139 = getelementptr i8, ptr %138, i64 %97
  %140 = load <16 x i8>, ptr %139, align 16
  %141 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %142 = getelementptr i8, ptr %141, i64 %106
  %143 = load <16 x i8>, ptr %142, align 16
  %144 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %145 = getelementptr i8, ptr %144, i64 %115
  %146 = load <16 x i8>, ptr %145, align 16
  %147 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %148 = getelementptr i8, ptr %147, i64 %124
  %149 = load <16 x i8>, ptr %148, align 16
  %150 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %140, ptr addrspace(3) %150, align 16
  %151 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %143, ptr addrspace(3) %151, align 16
  %152 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %146, ptr addrspace(3) %152, align 16
  %153 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %149, ptr addrspace(3) %153, align 16
  %154 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %155 = getelementptr i8, ptr %154, i64 %132
  %156 = load <16 x i8>, ptr %155, align 16
  %157 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %156, ptr addrspace(3) %157, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %158 = sub i64 %136, 1
  br label %159

159:                                              ; preds = %170, %28
  %160 = phi i64 [ %417, %170 ], [ 0, %28 ]
  %161 = phi <8 x float> [ %404, %170 ], [ zeroinitializer, %28 ]
  %162 = phi <8 x float> [ %405, %170 ], [ zeroinitializer, %28 ]
  %163 = phi <8 x float> [ %406, %170 ], [ zeroinitializer, %28 ]
  %164 = phi <8 x float> [ %407, %170 ], [ zeroinitializer, %28 ]
  %165 = phi <8 x float> [ %408, %170 ], [ zeroinitializer, %28 ]
  %166 = phi <8 x float> [ %409, %170 ], [ zeroinitializer, %28 ]
  %167 = phi <8 x float> [ %410, %170 ], [ zeroinitializer, %28 ]
  %168 = phi <8 x float> [ %411, %170 ], [ zeroinitializer, %28 ]
  %169 = icmp slt i64 %160, %158
  br i1 %169, label %170, label %418

170:                                              ; preds = %159
  %171 = mul i64 %160, 64
  %172 = add i64 %171, 64
  %173 = call i64 @llvm.umin.i64(i64 %172, i64 %137)
  %174 = add i64 %97, %173
  %175 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %176 = getelementptr i8, ptr %175, i64 %174
  %177 = load <16 x i8>, ptr %176, align 16
  %178 = add i64 %106, %173
  %179 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %180 = getelementptr i8, ptr %179, i64 %178
  %181 = load <16 x i8>, ptr %180, align 16
  %182 = add i64 %115, %173
  %183 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %184 = getelementptr i8, ptr %183, i64 %182
  %185 = load <16 x i8>, ptr %184, align 16
  %186 = add i64 %124, %173
  %187 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %53, 1
  %188 = getelementptr i8, ptr %187, i64 %186
  %189 = load <16 x i8>, ptr %188, align 16
  %190 = add i64 %132, %173
  %191 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %48, 1
  %192 = getelementptr i8, ptr %191, i64 %190
  %193 = load <16 x i8>, ptr %192, align 16
  %194 = mul i64 %58, 8
  %195 = add i64 %80, %57
  %196 = mul i64 %195, 80
  %197 = add i64 %196, %194
  %198 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %197
  %199 = load <8 x i8>, ptr addrspace(3) %198, align 1
  %200 = bitcast <8 x i8> %199 to <2 x i32>
  %201 = mul i64 %58, 8
  %202 = add i64 %83, %57
  %203 = mul i64 %202, 80
  %204 = add i64 %203, %201
  %205 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %204
  %206 = load <8 x i8>, ptr addrspace(3) %205, align 1
  %207 = bitcast <8 x i8> %206 to <2 x i32>
  %208 = mul i64 %58, 8
  %209 = add i64 %85, %57
  %210 = mul i64 %209, 80
  %211 = add i64 %210, %208
  %212 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %211
  %213 = load <8 x i8>, ptr addrspace(3) %212, align 1
  %214 = bitcast <8 x i8> %213 to <2 x i32>
  %215 = mul i64 %58, 8
  %216 = add i64 %87, %57
  %217 = mul i64 %216, 80
  %218 = add i64 %217, %215
  %219 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %218
  %220 = load <8 x i8>, ptr addrspace(3) %219, align 1
  %221 = bitcast <8 x i8> %220 to <2 x i32>
  %222 = mul i64 %58, 8
  %223 = add i64 %81, %57
  %224 = mul i64 %223, 80
  %225 = add i64 %224, %222
  %226 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %225
  %227 = load <8 x i8>, ptr addrspace(3) %226, align 1
  %228 = bitcast <8 x i8> %227 to <2 x i32>
  %229 = mul i64 %58, 8
  %230 = add i64 %90, %57
  %231 = mul i64 %230, 80
  %232 = add i64 %231, %229
  %233 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %232
  %234 = load <8 x i8>, ptr addrspace(3) %233, align 1
  %235 = bitcast <8 x i8> %234 to <2 x i32>
  %236 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %200, <2 x i32> %228, <8 x float> %161)
  %237 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %200, <2 x i32> %235, <8 x float> %162)
  %238 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %207, <2 x i32> %228, <8 x float> %163)
  %239 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %207, <2 x i32> %235, <8 x float> %164)
  %240 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %214, <2 x i32> %228, <8 x float> %165)
  %241 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %214, <2 x i32> %235, <8 x float> %166)
  %242 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %221, <2 x i32> %228, <8 x float> %167)
  %243 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %221, <2 x i32> %235, <8 x float> %168)
  %244 = mul i64 %58, 8
  %245 = add i64 %80, %57
  %246 = add i64 %244, 16
  %247 = mul i64 %245, 80
  %248 = add i64 %247, %246
  %249 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %248
  %250 = load <8 x i8>, ptr addrspace(3) %249, align 1
  %251 = bitcast <8 x i8> %250 to <2 x i32>
  %252 = mul i64 %58, 8
  %253 = add i64 %83, %57
  %254 = add i64 %252, 16
  %255 = mul i64 %253, 80
  %256 = add i64 %255, %254
  %257 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %256
  %258 = load <8 x i8>, ptr addrspace(3) %257, align 1
  %259 = bitcast <8 x i8> %258 to <2 x i32>
  %260 = mul i64 %58, 8
  %261 = add i64 %85, %57
  %262 = add i64 %260, 16
  %263 = mul i64 %261, 80
  %264 = add i64 %263, %262
  %265 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %264
  %266 = load <8 x i8>, ptr addrspace(3) %265, align 1
  %267 = bitcast <8 x i8> %266 to <2 x i32>
  %268 = mul i64 %58, 8
  %269 = add i64 %87, %57
  %270 = add i64 %268, 16
  %271 = mul i64 %269, 80
  %272 = add i64 %271, %270
  %273 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %272
  %274 = load <8 x i8>, ptr addrspace(3) %273, align 1
  %275 = bitcast <8 x i8> %274 to <2 x i32>
  %276 = mul i64 %58, 8
  %277 = add i64 %276, 16
  %278 = add i64 %81, %57
  %279 = mul i64 %278, 80
  %280 = add i64 %279, %277
  %281 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %280
  %282 = load <8 x i8>, ptr addrspace(3) %281, align 1
  %283 = bitcast <8 x i8> %282 to <2 x i32>
  %284 = mul i64 %58, 8
  %285 = add i64 %284, 16
  %286 = add i64 %90, %57
  %287 = mul i64 %286, 80
  %288 = add i64 %287, %285
  %289 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %288
  %290 = load <8 x i8>, ptr addrspace(3) %289, align 1
  %291 = bitcast <8 x i8> %290 to <2 x i32>
  %292 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %251, <2 x i32> %283, <8 x float> %236)
  %293 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %251, <2 x i32> %291, <8 x float> %237)
  %294 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %259, <2 x i32> %283, <8 x float> %238)
  %295 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %259, <2 x i32> %291, <8 x float> %239)
  %296 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %267, <2 x i32> %283, <8 x float> %240)
  %297 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %267, <2 x i32> %291, <8 x float> %241)
  %298 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %275, <2 x i32> %283, <8 x float> %242)
  %299 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %275, <2 x i32> %291, <8 x float> %243)
  %300 = mul i64 %58, 8
  %301 = add i64 %80, %57
  %302 = add i64 %300, 32
  %303 = mul i64 %301, 80
  %304 = add i64 %303, %302
  %305 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %304
  %306 = load <8 x i8>, ptr addrspace(3) %305, align 1
  %307 = bitcast <8 x i8> %306 to <2 x i32>
  %308 = mul i64 %58, 8
  %309 = add i64 %83, %57
  %310 = add i64 %308, 32
  %311 = mul i64 %309, 80
  %312 = add i64 %311, %310
  %313 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %312
  %314 = load <8 x i8>, ptr addrspace(3) %313, align 1
  %315 = bitcast <8 x i8> %314 to <2 x i32>
  %316 = mul i64 %58, 8
  %317 = add i64 %85, %57
  %318 = add i64 %316, 32
  %319 = mul i64 %317, 80
  %320 = add i64 %319, %318
  %321 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %320
  %322 = load <8 x i8>, ptr addrspace(3) %321, align 1
  %323 = bitcast <8 x i8> %322 to <2 x i32>
  %324 = mul i64 %58, 8
  %325 = add i64 %87, %57
  %326 = add i64 %324, 32
  %327 = mul i64 %325, 80
  %328 = add i64 %327, %326
  %329 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %328
  %330 = load <8 x i8>, ptr addrspace(3) %329, align 1
  %331 = bitcast <8 x i8> %330 to <2 x i32>
  %332 = mul i64 %58, 8
  %333 = add i64 %332, 32
  %334 = add i64 %81, %57
  %335 = mul i64 %334, 80
  %336 = add i64 %335, %333
  %337 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %336
  %338 = load <8 x i8>, ptr addrspace(3) %337, align 1
  %339 = bitcast <8 x i8> %338 to <2 x i32>
  %340 = mul i64 %58, 8
  %341 = add i64 %340, 32
  %342 = add i64 %90, %57
  %343 = mul i64 %342, 80
  %344 = add i64 %343, %341
  %345 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %344
  %346 = load <8 x i8>, ptr addrspace(3) %345, align 1
  %347 = bitcast <8 x i8> %346 to <2 x i32>
  %348 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %307, <2 x i32> %339, <8 x float> %292)
  %349 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %307, <2 x i32> %347, <8 x float> %293)
  %350 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %315, <2 x i32> %339, <8 x float> %294)
  %351 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %315, <2 x i32> %347, <8 x float> %295)
  %352 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %323, <2 x i32> %339, <8 x float> %296)
  %353 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %323, <2 x i32> %347, <8 x float> %297)
  %354 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %331, <2 x i32> %339, <8 x float> %298)
  %355 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %331, <2 x i32> %347, <8 x float> %299)
  %356 = mul i64 %58, 8
  %357 = add i64 %80, %57
  %358 = add i64 %356, 48
  %359 = mul i64 %357, 80
  %360 = add i64 %359, %358
  %361 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %360
  %362 = load <8 x i8>, ptr addrspace(3) %361, align 1
  %363 = bitcast <8 x i8> %362 to <2 x i32>
  %364 = mul i64 %58, 8
  %365 = add i64 %83, %57
  %366 = add i64 %364, 48
  %367 = mul i64 %365, 80
  %368 = add i64 %367, %366
  %369 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %368
  %370 = load <8 x i8>, ptr addrspace(3) %369, align 1
  %371 = bitcast <8 x i8> %370 to <2 x i32>
  %372 = mul i64 %58, 8
  %373 = add i64 %85, %57
  %374 = add i64 %372, 48
  %375 = mul i64 %373, 80
  %376 = add i64 %375, %374
  %377 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %376
  %378 = load <8 x i8>, ptr addrspace(3) %377, align 1
  %379 = bitcast <8 x i8> %378 to <2 x i32>
  %380 = mul i64 %58, 8
  %381 = add i64 %87, %57
  %382 = add i64 %380, 48
  %383 = mul i64 %381, 80
  %384 = add i64 %383, %382
  %385 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %384
  %386 = load <8 x i8>, ptr addrspace(3) %385, align 1
  %387 = bitcast <8 x i8> %386 to <2 x i32>
  %388 = mul i64 %58, 8
  %389 = add i64 %388, 48
  %390 = add i64 %81, %57
  %391 = mul i64 %390, 80
  %392 = add i64 %391, %389
  %393 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %392
  %394 = load <8 x i8>, ptr addrspace(3) %393, align 1
  %395 = bitcast <8 x i8> %394 to <2 x i32>
  %396 = mul i64 %58, 8
  %397 = add i64 %396, 48
  %398 = add i64 %90, %57
  %399 = mul i64 %398, 80
  %400 = add i64 %399, %397
  %401 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %400
  %402 = load <8 x i8>, ptr addrspace(3) %401, align 1
  %403 = bitcast <8 x i8> %402 to <2 x i32>
  %404 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %363, <2 x i32> %395, <8 x float> %348)
  %405 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %363, <2 x i32> %403, <8 x float> %349)
  %406 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %371, <2 x i32> %395, <8 x float> %350)
  %407 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %371, <2 x i32> %403, <8 x float> %351)
  %408 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %379, <2 x i32> %395, <8 x float> %352)
  %409 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %379, <2 x i32> %403, <8 x float> %353)
  %410 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %387, <2 x i32> %395, <8 x float> %354)
  %411 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %387, <2 x i32> %403, <8 x float> %355)
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %412 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %99
  store <16 x i8> %177, ptr addrspace(3) %412, align 16
  %413 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %108
  store <16 x i8> %181, ptr addrspace(3) %413, align 16
  %414 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %117
  store <16 x i8> %185, ptr addrspace(3) %414, align 16
  %415 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %126
  store <16 x i8> %189, ptr addrspace(3) %415, align 16
  %416 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %134
  store <16 x i8> %193, ptr addrspace(3) %416, align 16
  fence syncscope("workgroup") release, !mmra !2
  call void @llvm.amdgcn.s.barrier.signal(i32 -1)
  call void @llvm.amdgcn.s.barrier.wait(i16 -1)
  fence syncscope("workgroup") acquire, !mmra !2
  %417 = add i64 %160, 1
  br label %159

418:                                              ; preds = %159
  %419 = mul i64 %58, 8
  %420 = add i64 %80, %57
  %421 = mul i64 %420, 80
  %422 = add i64 %421, %419
  %423 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %422
  %424 = load <8 x i8>, ptr addrspace(3) %423, align 1
  %425 = bitcast <8 x i8> %424 to <2 x i32>
  %426 = mul i64 %58, 8
  %427 = add i64 %83, %57
  %428 = mul i64 %427, 80
  %429 = add i64 %428, %426
  %430 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %429
  %431 = load <8 x i8>, ptr addrspace(3) %430, align 1
  %432 = bitcast <8 x i8> %431 to <2 x i32>
  %433 = mul i64 %58, 8
  %434 = add i64 %85, %57
  %435 = mul i64 %434, 80
  %436 = add i64 %435, %433
  %437 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %436
  %438 = load <8 x i8>, ptr addrspace(3) %437, align 1
  %439 = bitcast <8 x i8> %438 to <2 x i32>
  %440 = mul i64 %58, 8
  %441 = add i64 %87, %57
  %442 = mul i64 %441, 80
  %443 = add i64 %442, %440
  %444 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %443
  %445 = load <8 x i8>, ptr addrspace(3) %444, align 1
  %446 = bitcast <8 x i8> %445 to <2 x i32>
  %447 = mul i64 %58, 8
  %448 = add i64 %81, %57
  %449 = mul i64 %448, 80
  %450 = add i64 %449, %447
  %451 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %450
  %452 = load <8 x i8>, ptr addrspace(3) %451, align 1
  %453 = bitcast <8 x i8> %452 to <2 x i32>
  %454 = mul i64 %58, 8
  %455 = add i64 %90, %57
  %456 = mul i64 %455, 80
  %457 = add i64 %456, %454
  %458 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %457
  %459 = load <8 x i8>, ptr addrspace(3) %458, align 1
  %460 = bitcast <8 x i8> %459 to <2 x i32>
  %461 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %425, <2 x i32> %453, <8 x float> %161)
  %462 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %425, <2 x i32> %460, <8 x float> %162)
  %463 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %432, <2 x i32> %453, <8 x float> %163)
  %464 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %432, <2 x i32> %460, <8 x float> %164)
  %465 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %439, <2 x i32> %453, <8 x float> %165)
  %466 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %439, <2 x i32> %460, <8 x float> %166)
  %467 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %446, <2 x i32> %453, <8 x float> %167)
  %468 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %446, <2 x i32> %460, <8 x float> %168)
  %469 = mul i64 %58, 8
  %470 = add i64 %80, %57
  %471 = add i64 %469, 16
  %472 = mul i64 %470, 80
  %473 = add i64 %472, %471
  %474 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %473
  %475 = load <8 x i8>, ptr addrspace(3) %474, align 1
  %476 = bitcast <8 x i8> %475 to <2 x i32>
  %477 = mul i64 %58, 8
  %478 = add i64 %83, %57
  %479 = add i64 %477, 16
  %480 = mul i64 %478, 80
  %481 = add i64 %480, %479
  %482 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %481
  %483 = load <8 x i8>, ptr addrspace(3) %482, align 1
  %484 = bitcast <8 x i8> %483 to <2 x i32>
  %485 = mul i64 %58, 8
  %486 = add i64 %85, %57
  %487 = add i64 %485, 16
  %488 = mul i64 %486, 80
  %489 = add i64 %488, %487
  %490 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %489
  %491 = load <8 x i8>, ptr addrspace(3) %490, align 1
  %492 = bitcast <8 x i8> %491 to <2 x i32>
  %493 = mul i64 %58, 8
  %494 = add i64 %87, %57
  %495 = add i64 %493, 16
  %496 = mul i64 %494, 80
  %497 = add i64 %496, %495
  %498 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %497
  %499 = load <8 x i8>, ptr addrspace(3) %498, align 1
  %500 = bitcast <8 x i8> %499 to <2 x i32>
  %501 = mul i64 %58, 8
  %502 = add i64 %501, 16
  %503 = add i64 %81, %57
  %504 = mul i64 %503, 80
  %505 = add i64 %504, %502
  %506 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %505
  %507 = load <8 x i8>, ptr addrspace(3) %506, align 1
  %508 = bitcast <8 x i8> %507 to <2 x i32>
  %509 = mul i64 %58, 8
  %510 = add i64 %509, 16
  %511 = add i64 %90, %57
  %512 = mul i64 %511, 80
  %513 = add i64 %512, %510
  %514 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %513
  %515 = load <8 x i8>, ptr addrspace(3) %514, align 1
  %516 = bitcast <8 x i8> %515 to <2 x i32>
  %517 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %476, <2 x i32> %508, <8 x float> %461)
  %518 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %476, <2 x i32> %516, <8 x float> %462)
  %519 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %484, <2 x i32> %508, <8 x float> %463)
  %520 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %484, <2 x i32> %516, <8 x float> %464)
  %521 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %492, <2 x i32> %508, <8 x float> %465)
  %522 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %492, <2 x i32> %516, <8 x float> %466)
  %523 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %500, <2 x i32> %508, <8 x float> %467)
  %524 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %500, <2 x i32> %516, <8 x float> %468)
  %525 = mul i64 %58, 8
  %526 = add i64 %80, %57
  %527 = add i64 %525, 32
  %528 = mul i64 %526, 80
  %529 = add i64 %528, %527
  %530 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %529
  %531 = load <8 x i8>, ptr addrspace(3) %530, align 1
  %532 = bitcast <8 x i8> %531 to <2 x i32>
  %533 = mul i64 %58, 8
  %534 = add i64 %83, %57
  %535 = add i64 %533, 32
  %536 = mul i64 %534, 80
  %537 = add i64 %536, %535
  %538 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %537
  %539 = load <8 x i8>, ptr addrspace(3) %538, align 1
  %540 = bitcast <8 x i8> %539 to <2 x i32>
  %541 = mul i64 %58, 8
  %542 = add i64 %85, %57
  %543 = add i64 %541, 32
  %544 = mul i64 %542, 80
  %545 = add i64 %544, %543
  %546 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %545
  %547 = load <8 x i8>, ptr addrspace(3) %546, align 1
  %548 = bitcast <8 x i8> %547 to <2 x i32>
  %549 = mul i64 %58, 8
  %550 = add i64 %87, %57
  %551 = add i64 %549, 32
  %552 = mul i64 %550, 80
  %553 = add i64 %552, %551
  %554 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %553
  %555 = load <8 x i8>, ptr addrspace(3) %554, align 1
  %556 = bitcast <8 x i8> %555 to <2 x i32>
  %557 = mul i64 %58, 8
  %558 = add i64 %557, 32
  %559 = add i64 %81, %57
  %560 = mul i64 %559, 80
  %561 = add i64 %560, %558
  %562 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %561
  %563 = load <8 x i8>, ptr addrspace(3) %562, align 1
  %564 = bitcast <8 x i8> %563 to <2 x i32>
  %565 = mul i64 %58, 8
  %566 = add i64 %565, 32
  %567 = add i64 %90, %57
  %568 = mul i64 %567, 80
  %569 = add i64 %568, %566
  %570 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %569
  %571 = load <8 x i8>, ptr addrspace(3) %570, align 1
  %572 = bitcast <8 x i8> %571 to <2 x i32>
  %573 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %532, <2 x i32> %564, <8 x float> %517)
  %574 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %532, <2 x i32> %572, <8 x float> %518)
  %575 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %540, <2 x i32> %564, <8 x float> %519)
  %576 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %540, <2 x i32> %572, <8 x float> %520)
  %577 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %548, <2 x i32> %564, <8 x float> %521)
  %578 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %548, <2 x i32> %572, <8 x float> %522)
  %579 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %556, <2 x i32> %564, <8 x float> %523)
  %580 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %556, <2 x i32> %572, <8 x float> %524)
  %581 = mul i64 %58, 8
  %582 = add i64 %80, %57
  %583 = add i64 %581, 48
  %584 = mul i64 %582, 80
  %585 = add i64 %584, %583
  %586 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %585
  %587 = load <8 x i8>, ptr addrspace(3) %586, align 1
  %588 = bitcast <8 x i8> %587 to <2 x i32>
  %589 = mul i64 %58, 8
  %590 = add i64 %83, %57
  %591 = add i64 %589, 48
  %592 = mul i64 %590, 80
  %593 = add i64 %592, %591
  %594 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %593
  %595 = load <8 x i8>, ptr addrspace(3) %594, align 1
  %596 = bitcast <8 x i8> %595 to <2 x i32>
  %597 = mul i64 %58, 8
  %598 = add i64 %85, %57
  %599 = add i64 %597, 48
  %600 = mul i64 %598, 80
  %601 = add i64 %600, %599
  %602 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %601
  %603 = load <8 x i8>, ptr addrspace(3) %602, align 1
  %604 = bitcast <8 x i8> %603 to <2 x i32>
  %605 = mul i64 %58, 8
  %606 = add i64 %87, %57
  %607 = add i64 %605, 48
  %608 = mul i64 %606, 80
  %609 = add i64 %608, %607
  %610 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_0, i64 %609
  %611 = load <8 x i8>, ptr addrspace(3) %610, align 1
  %612 = bitcast <8 x i8> %611 to <2 x i32>
  %613 = mul i64 %58, 8
  %614 = add i64 %613, 48
  %615 = add i64 %81, %57
  %616 = mul i64 %615, 80
  %617 = add i64 %616, %614
  %618 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %617
  %619 = load <8 x i8>, ptr addrspace(3) %618, align 1
  %620 = bitcast <8 x i8> %619 to <2 x i32>
  %621 = mul i64 %58, 8
  %622 = add i64 %621, 48
  %623 = add i64 %90, %57
  %624 = mul i64 %623, 80
  %625 = add i64 %624, %622
  %626 = getelementptr i8, ptr addrspace(3) @__wg_tessera_rocm_folded_matmul_708d500594ff51c6_1, i64 %625
  %627 = load <8 x i8>, ptr addrspace(3) %626, align 1
  %628 = bitcast <8 x i8> %627 to <2 x i32>
  %629 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %588, <2 x i32> %620, <8 x float> %573)
  %630 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %588, <2 x i32> %628, <8 x float> %574)
  %631 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %596, <2 x i32> %620, <8 x float> %575)
  %632 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %596, <2 x i32> %628, <8 x float> %576)
  %633 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %604, <2 x i32> %620, <8 x float> %577)
  %634 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %604, <2 x i32> %628, <8 x float> %578)
  %635 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %612, <2 x i32> %620, <8 x float> %579)
  %636 = call <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32> %612, <2 x i32> %628, <8 x float> %580)
  %637 = mul i64 %58, 8
  %638 = add i64 %82, %637
  %639 = add i64 %89, %57
  %640 = add i64 %638, 7
  %641 = icmp ult i64 %639, %26
  %642 = icmp ult i64 %640, %25
  %643 = and i1 %642, %641
  %644 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %645 = ptrtoint ptr %644 to i64
  %646 = mul i64 %638, 4
  %647 = add i64 %645, %646
  %648 = urem i64 %647, 16
  %649 = icmp eq i64 %648, 0
  %650 = and i1 %643, %649
  br i1 %650, label %651, label %660

651:                                              ; preds = %418
  %652 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %653 = getelementptr float, ptr %652, i64 %638
  %654 = load <4 x float>, ptr %653, align 16
  %655 = add i64 %638, 4
  %656 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %657 = getelementptr float, ptr %656, i64 %655
  %658 = load <4 x float>, ptr %657, align 16
  %659 = shufflevector <4 x float> %654, <4 x float> %658, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %732

660:                                              ; preds = %418
  %661 = mul i64 %58, 8
  %662 = add i64 %82, %661
  %663 = icmp slt i64 %662, %25
  %664 = select i1 %663, i64 %662, i64 0
  %665 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %666 = getelementptr inbounds nuw float, ptr %665, i64 %664
  %667 = load float, ptr %666, align 4
  %668 = insertelement <8 x float> zeroinitializer, float %667, i64 0
  %669 = mul i64 %58, 8
  %670 = add i64 %669, 1
  %671 = add i64 %82, %670
  %672 = icmp slt i64 %671, %25
  %673 = select i1 %672, i64 %671, i64 0
  %674 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %675 = getelementptr inbounds nuw float, ptr %674, i64 %673
  %676 = load float, ptr %675, align 4
  %677 = insertelement <8 x float> %668, float %676, i64 1
  %678 = mul i64 %58, 8
  %679 = add i64 %678, 2
  %680 = add i64 %82, %679
  %681 = icmp slt i64 %680, %25
  %682 = select i1 %681, i64 %680, i64 0
  %683 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %684 = getelementptr inbounds nuw float, ptr %683, i64 %682
  %685 = load float, ptr %684, align 4
  %686 = insertelement <8 x float> %677, float %685, i64 2
  %687 = mul i64 %58, 8
  %688 = add i64 %687, 3
  %689 = add i64 %82, %688
  %690 = icmp slt i64 %689, %25
  %691 = select i1 %690, i64 %689, i64 0
  %692 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %693 = getelementptr inbounds nuw float, ptr %692, i64 %691
  %694 = load float, ptr %693, align 4
  %695 = insertelement <8 x float> %686, float %694, i64 3
  %696 = mul i64 %58, 8
  %697 = add i64 %696, 4
  %698 = add i64 %82, %697
  %699 = icmp slt i64 %698, %25
  %700 = select i1 %699, i64 %698, i64 0
  %701 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %702 = getelementptr inbounds nuw float, ptr %701, i64 %700
  %703 = load float, ptr %702, align 4
  %704 = insertelement <8 x float> %695, float %703, i64 4
  %705 = mul i64 %58, 8
  %706 = add i64 %705, 5
  %707 = add i64 %82, %706
  %708 = icmp slt i64 %707, %25
  %709 = select i1 %708, i64 %707, i64 0
  %710 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %711 = getelementptr inbounds nuw float, ptr %710, i64 %709
  %712 = load float, ptr %711, align 4
  %713 = insertelement <8 x float> %704, float %712, i64 5
  %714 = mul i64 %58, 8
  %715 = add i64 %714, 6
  %716 = add i64 %82, %715
  %717 = icmp slt i64 %716, %25
  %718 = select i1 %717, i64 %716, i64 0
  %719 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %720 = getelementptr inbounds nuw float, ptr %719, i64 %718
  %721 = load float, ptr %720, align 4
  %722 = insertelement <8 x float> %713, float %721, i64 6
  %723 = mul i64 %58, 8
  %724 = add i64 %723, 7
  %725 = add i64 %82, %724
  %726 = icmp slt i64 %725, %25
  %727 = select i1 %726, i64 %725, i64 0
  %728 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %729 = getelementptr inbounds nuw float, ptr %728, i64 %727
  %730 = load float, ptr %729, align 4
  %731 = insertelement <8 x float> %722, float %730, i64 7
  br label %732

732:                                              ; preds = %651, %660
  %733 = phi <8 x float> [ %731, %660 ], [ %659, %651 ]
  br label %734

734:                                              ; preds = %732
  %735 = add i64 %89, %57
  %736 = icmp slt i64 %735, %26
  %737 = select i1 %736, i64 %735, i64 0
  %738 = extractelement <8 x float> %733, i64 0
  %739 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %740 = getelementptr inbounds nuw i8, ptr %739, i64 %737
  %741 = load i8, ptr %740, align 1
  %742 = zext i8 %741 to i32
  %743 = shl i32 %742, 23
  %744 = bitcast i32 %743 to float
  %745 = fmul float %744, %738
  %746 = extractelement <8 x float> %629, i64 0
  %747 = fmul float %746, %745
  %748 = call float @llvm.fabs.f32(float %745)
  %749 = fcmp olt float %748, +inf
  %750 = fcmp one float %745, 0.000000e+00
  %751 = and i1 %749, %750
  br i1 %751, label %752, label %753

752:                                              ; preds = %734
  br label %765

753:                                              ; preds = %734
  %754 = fpext float %746 to double
  %755 = fpext float %744 to double
  %756 = fpext float %738 to double
  %757 = fmul double %754, %755
  %758 = fmul double %757, %756
  %759 = fptrunc double %758 to float
  %760 = fcmp oeq float %746, 0.000000e+00
  %761 = call float @llvm.fabs.f32(float %738)
  %762 = fcmp olt float %761, +inf
  %763 = and i1 %760, %762
  %764 = select i1 %763, float 0.000000e+00, float %759
  br label %765

765:                                              ; preds = %752, %753
  %766 = phi float [ %764, %753 ], [ %747, %752 ]
  br label %767

767:                                              ; preds = %765
  %768 = add i64 %89, %57
  %769 = icmp slt i64 %768, %26
  %770 = select i1 %769, i64 %768, i64 0
  %771 = extractelement <8 x float> %733, i64 1
  %772 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %773 = getelementptr inbounds nuw i8, ptr %772, i64 %770
  %774 = load i8, ptr %773, align 1
  %775 = zext i8 %774 to i32
  %776 = shl i32 %775, 23
  %777 = bitcast i32 %776 to float
  %778 = fmul float %777, %771
  %779 = extractelement <8 x float> %629, i64 1
  %780 = fmul float %779, %778
  %781 = call float @llvm.fabs.f32(float %778)
  %782 = fcmp olt float %781, +inf
  %783 = fcmp one float %778, 0.000000e+00
  %784 = and i1 %782, %783
  br i1 %784, label %785, label %786

785:                                              ; preds = %767
  br label %798

786:                                              ; preds = %767
  %787 = fpext float %779 to double
  %788 = fpext float %777 to double
  %789 = fpext float %771 to double
  %790 = fmul double %787, %788
  %791 = fmul double %790, %789
  %792 = fptrunc double %791 to float
  %793 = fcmp oeq float %779, 0.000000e+00
  %794 = call float @llvm.fabs.f32(float %771)
  %795 = fcmp olt float %794, +inf
  %796 = and i1 %793, %795
  %797 = select i1 %796, float 0.000000e+00, float %792
  br label %798

798:                                              ; preds = %785, %786
  %799 = phi float [ %797, %786 ], [ %780, %785 ]
  br label %800

800:                                              ; preds = %798
  %801 = add i64 %89, %57
  %802 = icmp slt i64 %801, %26
  %803 = select i1 %802, i64 %801, i64 0
  %804 = extractelement <8 x float> %733, i64 2
  %805 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %806 = getelementptr inbounds nuw i8, ptr %805, i64 %803
  %807 = load i8, ptr %806, align 1
  %808 = zext i8 %807 to i32
  %809 = shl i32 %808, 23
  %810 = bitcast i32 %809 to float
  %811 = fmul float %810, %804
  %812 = extractelement <8 x float> %629, i64 2
  %813 = fmul float %812, %811
  %814 = call float @llvm.fabs.f32(float %811)
  %815 = fcmp olt float %814, +inf
  %816 = fcmp one float %811, 0.000000e+00
  %817 = and i1 %815, %816
  br i1 %817, label %818, label %819

818:                                              ; preds = %800
  br label %831

819:                                              ; preds = %800
  %820 = fpext float %812 to double
  %821 = fpext float %810 to double
  %822 = fpext float %804 to double
  %823 = fmul double %820, %821
  %824 = fmul double %823, %822
  %825 = fptrunc double %824 to float
  %826 = fcmp oeq float %812, 0.000000e+00
  %827 = call float @llvm.fabs.f32(float %804)
  %828 = fcmp olt float %827, +inf
  %829 = and i1 %826, %828
  %830 = select i1 %829, float 0.000000e+00, float %825
  br label %831

831:                                              ; preds = %818, %819
  %832 = phi float [ %830, %819 ], [ %813, %818 ]
  br label %833

833:                                              ; preds = %831
  %834 = add i64 %89, %57
  %835 = icmp slt i64 %834, %26
  %836 = select i1 %835, i64 %834, i64 0
  %837 = extractelement <8 x float> %733, i64 3
  %838 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %839 = getelementptr inbounds nuw i8, ptr %838, i64 %836
  %840 = load i8, ptr %839, align 1
  %841 = zext i8 %840 to i32
  %842 = shl i32 %841, 23
  %843 = bitcast i32 %842 to float
  %844 = fmul float %843, %837
  %845 = extractelement <8 x float> %629, i64 3
  %846 = fmul float %845, %844
  %847 = call float @llvm.fabs.f32(float %844)
  %848 = fcmp olt float %847, +inf
  %849 = fcmp one float %844, 0.000000e+00
  %850 = and i1 %848, %849
  br i1 %850, label %851, label %852

851:                                              ; preds = %833
  br label %864

852:                                              ; preds = %833
  %853 = fpext float %845 to double
  %854 = fpext float %843 to double
  %855 = fpext float %837 to double
  %856 = fmul double %853, %854
  %857 = fmul double %856, %855
  %858 = fptrunc double %857 to float
  %859 = fcmp oeq float %845, 0.000000e+00
  %860 = call float @llvm.fabs.f32(float %837)
  %861 = fcmp olt float %860, +inf
  %862 = and i1 %859, %861
  %863 = select i1 %862, float 0.000000e+00, float %858
  br label %864

864:                                              ; preds = %851, %852
  %865 = phi float [ %863, %852 ], [ %846, %851 ]
  br label %866

866:                                              ; preds = %864
  %867 = add i64 %89, %57
  %868 = icmp slt i64 %867, %26
  %869 = select i1 %868, i64 %867, i64 0
  %870 = extractelement <8 x float> %733, i64 4
  %871 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %872 = getelementptr inbounds nuw i8, ptr %871, i64 %869
  %873 = load i8, ptr %872, align 1
  %874 = zext i8 %873 to i32
  %875 = shl i32 %874, 23
  %876 = bitcast i32 %875 to float
  %877 = fmul float %876, %870
  %878 = extractelement <8 x float> %629, i64 4
  %879 = fmul float %878, %877
  %880 = call float @llvm.fabs.f32(float %877)
  %881 = fcmp olt float %880, +inf
  %882 = fcmp one float %877, 0.000000e+00
  %883 = and i1 %881, %882
  br i1 %883, label %884, label %885

884:                                              ; preds = %866
  br label %897

885:                                              ; preds = %866
  %886 = fpext float %878 to double
  %887 = fpext float %876 to double
  %888 = fpext float %870 to double
  %889 = fmul double %886, %887
  %890 = fmul double %889, %888
  %891 = fptrunc double %890 to float
  %892 = fcmp oeq float %878, 0.000000e+00
  %893 = call float @llvm.fabs.f32(float %870)
  %894 = fcmp olt float %893, +inf
  %895 = and i1 %892, %894
  %896 = select i1 %895, float 0.000000e+00, float %891
  br label %897

897:                                              ; preds = %884, %885
  %898 = phi float [ %896, %885 ], [ %879, %884 ]
  br label %899

899:                                              ; preds = %897
  %900 = add i64 %89, %57
  %901 = icmp slt i64 %900, %26
  %902 = select i1 %901, i64 %900, i64 0
  %903 = extractelement <8 x float> %733, i64 5
  %904 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %905 = getelementptr inbounds nuw i8, ptr %904, i64 %902
  %906 = load i8, ptr %905, align 1
  %907 = zext i8 %906 to i32
  %908 = shl i32 %907, 23
  %909 = bitcast i32 %908 to float
  %910 = fmul float %909, %903
  %911 = extractelement <8 x float> %629, i64 5
  %912 = fmul float %911, %910
  %913 = call float @llvm.fabs.f32(float %910)
  %914 = fcmp olt float %913, +inf
  %915 = fcmp one float %910, 0.000000e+00
  %916 = and i1 %914, %915
  br i1 %916, label %917, label %918

917:                                              ; preds = %899
  br label %930

918:                                              ; preds = %899
  %919 = fpext float %911 to double
  %920 = fpext float %909 to double
  %921 = fpext float %903 to double
  %922 = fmul double %919, %920
  %923 = fmul double %922, %921
  %924 = fptrunc double %923 to float
  %925 = fcmp oeq float %911, 0.000000e+00
  %926 = call float @llvm.fabs.f32(float %903)
  %927 = fcmp olt float %926, +inf
  %928 = and i1 %925, %927
  %929 = select i1 %928, float 0.000000e+00, float %924
  br label %930

930:                                              ; preds = %917, %918
  %931 = phi float [ %929, %918 ], [ %912, %917 ]
  br label %932

932:                                              ; preds = %930
  %933 = add i64 %89, %57
  %934 = icmp slt i64 %933, %26
  %935 = select i1 %934, i64 %933, i64 0
  %936 = extractelement <8 x float> %733, i64 6
  %937 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %938 = getelementptr inbounds nuw i8, ptr %937, i64 %935
  %939 = load i8, ptr %938, align 1
  %940 = zext i8 %939 to i32
  %941 = shl i32 %940, 23
  %942 = bitcast i32 %941 to float
  %943 = fmul float %942, %936
  %944 = extractelement <8 x float> %629, i64 6
  %945 = fmul float %944, %943
  %946 = call float @llvm.fabs.f32(float %943)
  %947 = fcmp olt float %946, +inf
  %948 = fcmp one float %943, 0.000000e+00
  %949 = and i1 %947, %948
  br i1 %949, label %950, label %951

950:                                              ; preds = %932
  br label %963

951:                                              ; preds = %932
  %952 = fpext float %944 to double
  %953 = fpext float %942 to double
  %954 = fpext float %936 to double
  %955 = fmul double %952, %953
  %956 = fmul double %955, %954
  %957 = fptrunc double %956 to float
  %958 = fcmp oeq float %944, 0.000000e+00
  %959 = call float @llvm.fabs.f32(float %936)
  %960 = fcmp olt float %959, +inf
  %961 = and i1 %958, %960
  %962 = select i1 %961, float 0.000000e+00, float %957
  br label %963

963:                                              ; preds = %950, %951
  %964 = phi float [ %962, %951 ], [ %945, %950 ]
  br label %965

965:                                              ; preds = %963
  %966 = add i64 %89, %57
  %967 = icmp slt i64 %966, %26
  %968 = select i1 %967, i64 %966, i64 0
  %969 = extractelement <8 x float> %733, i64 7
  %970 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %971 = getelementptr inbounds nuw i8, ptr %970, i64 %968
  %972 = load i8, ptr %971, align 1
  %973 = zext i8 %972 to i32
  %974 = shl i32 %973, 23
  %975 = bitcast i32 %974 to float
  %976 = fmul float %975, %969
  %977 = extractelement <8 x float> %629, i64 7
  %978 = fmul float %977, %976
  %979 = call float @llvm.fabs.f32(float %976)
  %980 = fcmp olt float %979, +inf
  %981 = fcmp one float %976, 0.000000e+00
  %982 = and i1 %980, %981
  br i1 %982, label %983, label %984

983:                                              ; preds = %965
  br label %996

984:                                              ; preds = %965
  %985 = fpext float %977 to double
  %986 = fpext float %975 to double
  %987 = fpext float %969 to double
  %988 = fmul double %985, %986
  %989 = fmul double %988, %987
  %990 = fptrunc double %989 to float
  %991 = fcmp oeq float %977, 0.000000e+00
  %992 = call float @llvm.fabs.f32(float %969)
  %993 = fcmp olt float %992, +inf
  %994 = and i1 %991, %993
  %995 = select i1 %994, float 0.000000e+00, float %990
  br label %996

996:                                              ; preds = %983, %984
  %997 = phi float [ %995, %984 ], [ %978, %983 ]
  br label %998

998:                                              ; preds = %996
  %999 = mul i64 %58, 8
  %1000 = add i64 %82, %999
  %1001 = add i64 %89, %57
  %1002 = mul i64 %1000, %26
  %1003 = add i64 %1002, %1001
  %1004 = fptrunc float %766 to bfloat
  %1005 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1006 = getelementptr inbounds nuw bfloat, ptr %1005, i64 %1003
  store bfloat %1004, ptr %1006, align 2
  %1007 = mul i64 %58, 8
  %1008 = add i64 %1007, 1
  %1009 = add i64 %82, %1008
  %1010 = add i64 %89, %57
  %1011 = mul i64 %1009, %26
  %1012 = add i64 %1011, %1010
  %1013 = fptrunc float %799 to bfloat
  %1014 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1015 = getelementptr inbounds nuw bfloat, ptr %1014, i64 %1012
  store bfloat %1013, ptr %1015, align 2
  %1016 = mul i64 %58, 8
  %1017 = add i64 %1016, 2
  %1018 = add i64 %82, %1017
  %1019 = add i64 %89, %57
  %1020 = mul i64 %1018, %26
  %1021 = add i64 %1020, %1019
  %1022 = fptrunc float %832 to bfloat
  %1023 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1024 = getelementptr inbounds nuw bfloat, ptr %1023, i64 %1021
  store bfloat %1022, ptr %1024, align 2
  %1025 = mul i64 %58, 8
  %1026 = add i64 %1025, 3
  %1027 = add i64 %82, %1026
  %1028 = add i64 %89, %57
  %1029 = mul i64 %1027, %26
  %1030 = add i64 %1029, %1028
  %1031 = fptrunc float %865 to bfloat
  %1032 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1033 = getelementptr inbounds nuw bfloat, ptr %1032, i64 %1030
  store bfloat %1031, ptr %1033, align 2
  %1034 = mul i64 %58, 8
  %1035 = add i64 %1034, 4
  %1036 = add i64 %82, %1035
  %1037 = add i64 %89, %57
  %1038 = mul i64 %1036, %26
  %1039 = add i64 %1038, %1037
  %1040 = fptrunc float %898 to bfloat
  %1041 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1042 = getelementptr inbounds nuw bfloat, ptr %1041, i64 %1039
  store bfloat %1040, ptr %1042, align 2
  %1043 = mul i64 %58, 8
  %1044 = add i64 %1043, 5
  %1045 = add i64 %82, %1044
  %1046 = add i64 %89, %57
  %1047 = mul i64 %1045, %26
  %1048 = add i64 %1047, %1046
  %1049 = fptrunc float %931 to bfloat
  %1050 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1051 = getelementptr inbounds nuw bfloat, ptr %1050, i64 %1048
  store bfloat %1049, ptr %1051, align 2
  %1052 = mul i64 %58, 8
  %1053 = add i64 %1052, 6
  %1054 = add i64 %82, %1053
  %1055 = add i64 %89, %57
  %1056 = mul i64 %1054, %26
  %1057 = add i64 %1056, %1055
  %1058 = fptrunc float %964 to bfloat
  %1059 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1060 = getelementptr inbounds nuw bfloat, ptr %1059, i64 %1057
  store bfloat %1058, ptr %1060, align 2
  %1061 = mul i64 %58, 8
  %1062 = add i64 %1061, 7
  %1063 = add i64 %82, %1062
  %1064 = add i64 %89, %57
  %1065 = mul i64 %1063, %26
  %1066 = add i64 %1065, %1064
  %1067 = fptrunc float %997 to bfloat
  %1068 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1069 = getelementptr inbounds nuw bfloat, ptr %1068, i64 %1066
  store bfloat %1067, ptr %1069, align 2
  %1070 = mul i64 %58, 8
  %1071 = add i64 %84, %1070
  %1072 = add i64 %89, %57
  %1073 = add i64 %1071, 7
  %1074 = icmp ult i64 %1072, %26
  %1075 = icmp ult i64 %1073, %25
  %1076 = and i1 %1075, %1074
  %1077 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1078 = ptrtoint ptr %1077 to i64
  %1079 = mul i64 %1071, 4
  %1080 = add i64 %1078, %1079
  %1081 = urem i64 %1080, 16
  %1082 = icmp eq i64 %1081, 0
  %1083 = and i1 %1076, %1082
  br i1 %1083, label %1084, label %1093

1084:                                             ; preds = %998
  %1085 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1086 = getelementptr float, ptr %1085, i64 %1071
  %1087 = load <4 x float>, ptr %1086, align 16
  %1088 = add i64 %1071, 4
  %1089 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1090 = getelementptr float, ptr %1089, i64 %1088
  %1091 = load <4 x float>, ptr %1090, align 16
  %1092 = shufflevector <4 x float> %1087, <4 x float> %1091, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1165

1093:                                             ; preds = %998
  %1094 = mul i64 %58, 8
  %1095 = add i64 %84, %1094
  %1096 = icmp slt i64 %1095, %25
  %1097 = select i1 %1096, i64 %1095, i64 0
  %1098 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1099 = getelementptr inbounds nuw float, ptr %1098, i64 %1097
  %1100 = load float, ptr %1099, align 4
  %1101 = insertelement <8 x float> zeroinitializer, float %1100, i64 0
  %1102 = mul i64 %58, 8
  %1103 = add i64 %1102, 1
  %1104 = add i64 %84, %1103
  %1105 = icmp slt i64 %1104, %25
  %1106 = select i1 %1105, i64 %1104, i64 0
  %1107 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1108 = getelementptr inbounds nuw float, ptr %1107, i64 %1106
  %1109 = load float, ptr %1108, align 4
  %1110 = insertelement <8 x float> %1101, float %1109, i64 1
  %1111 = mul i64 %58, 8
  %1112 = add i64 %1111, 2
  %1113 = add i64 %84, %1112
  %1114 = icmp slt i64 %1113, %25
  %1115 = select i1 %1114, i64 %1113, i64 0
  %1116 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1117 = getelementptr inbounds nuw float, ptr %1116, i64 %1115
  %1118 = load float, ptr %1117, align 4
  %1119 = insertelement <8 x float> %1110, float %1118, i64 2
  %1120 = mul i64 %58, 8
  %1121 = add i64 %1120, 3
  %1122 = add i64 %84, %1121
  %1123 = icmp slt i64 %1122, %25
  %1124 = select i1 %1123, i64 %1122, i64 0
  %1125 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1126 = getelementptr inbounds nuw float, ptr %1125, i64 %1124
  %1127 = load float, ptr %1126, align 4
  %1128 = insertelement <8 x float> %1119, float %1127, i64 3
  %1129 = mul i64 %58, 8
  %1130 = add i64 %1129, 4
  %1131 = add i64 %84, %1130
  %1132 = icmp slt i64 %1131, %25
  %1133 = select i1 %1132, i64 %1131, i64 0
  %1134 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1135 = getelementptr inbounds nuw float, ptr %1134, i64 %1133
  %1136 = load float, ptr %1135, align 4
  %1137 = insertelement <8 x float> %1128, float %1136, i64 4
  %1138 = mul i64 %58, 8
  %1139 = add i64 %1138, 5
  %1140 = add i64 %84, %1139
  %1141 = icmp slt i64 %1140, %25
  %1142 = select i1 %1141, i64 %1140, i64 0
  %1143 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1144 = getelementptr inbounds nuw float, ptr %1143, i64 %1142
  %1145 = load float, ptr %1144, align 4
  %1146 = insertelement <8 x float> %1137, float %1145, i64 5
  %1147 = mul i64 %58, 8
  %1148 = add i64 %1147, 6
  %1149 = add i64 %84, %1148
  %1150 = icmp slt i64 %1149, %25
  %1151 = select i1 %1150, i64 %1149, i64 0
  %1152 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1153 = getelementptr inbounds nuw float, ptr %1152, i64 %1151
  %1154 = load float, ptr %1153, align 4
  %1155 = insertelement <8 x float> %1146, float %1154, i64 6
  %1156 = mul i64 %58, 8
  %1157 = add i64 %1156, 7
  %1158 = add i64 %84, %1157
  %1159 = icmp slt i64 %1158, %25
  %1160 = select i1 %1159, i64 %1158, i64 0
  %1161 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1162 = getelementptr inbounds nuw float, ptr %1161, i64 %1160
  %1163 = load float, ptr %1162, align 4
  %1164 = insertelement <8 x float> %1155, float %1163, i64 7
  br label %1165

1165:                                             ; preds = %1084, %1093
  %1166 = phi <8 x float> [ %1164, %1093 ], [ %1092, %1084 ]
  br label %1167

1167:                                             ; preds = %1165
  %1168 = add i64 %89, %57
  %1169 = icmp slt i64 %1168, %26
  %1170 = select i1 %1169, i64 %1168, i64 0
  %1171 = extractelement <8 x float> %1166, i64 0
  %1172 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1173 = getelementptr inbounds nuw i8, ptr %1172, i64 %1170
  %1174 = load i8, ptr %1173, align 1
  %1175 = zext i8 %1174 to i32
  %1176 = shl i32 %1175, 23
  %1177 = bitcast i32 %1176 to float
  %1178 = fmul float %1177, %1171
  %1179 = extractelement <8 x float> %631, i64 0
  %1180 = fmul float %1179, %1178
  %1181 = call float @llvm.fabs.f32(float %1178)
  %1182 = fcmp olt float %1181, +inf
  %1183 = fcmp one float %1178, 0.000000e+00
  %1184 = and i1 %1182, %1183
  br i1 %1184, label %1185, label %1186

1185:                                             ; preds = %1167
  br label %1198

1186:                                             ; preds = %1167
  %1187 = fpext float %1179 to double
  %1188 = fpext float %1177 to double
  %1189 = fpext float %1171 to double
  %1190 = fmul double %1187, %1188
  %1191 = fmul double %1190, %1189
  %1192 = fptrunc double %1191 to float
  %1193 = fcmp oeq float %1179, 0.000000e+00
  %1194 = call float @llvm.fabs.f32(float %1171)
  %1195 = fcmp olt float %1194, +inf
  %1196 = and i1 %1193, %1195
  %1197 = select i1 %1196, float 0.000000e+00, float %1192
  br label %1198

1198:                                             ; preds = %1185, %1186
  %1199 = phi float [ %1197, %1186 ], [ %1180, %1185 ]
  br label %1200

1200:                                             ; preds = %1198
  %1201 = add i64 %89, %57
  %1202 = icmp slt i64 %1201, %26
  %1203 = select i1 %1202, i64 %1201, i64 0
  %1204 = extractelement <8 x float> %1166, i64 1
  %1205 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1206 = getelementptr inbounds nuw i8, ptr %1205, i64 %1203
  %1207 = load i8, ptr %1206, align 1
  %1208 = zext i8 %1207 to i32
  %1209 = shl i32 %1208, 23
  %1210 = bitcast i32 %1209 to float
  %1211 = fmul float %1210, %1204
  %1212 = extractelement <8 x float> %631, i64 1
  %1213 = fmul float %1212, %1211
  %1214 = call float @llvm.fabs.f32(float %1211)
  %1215 = fcmp olt float %1214, +inf
  %1216 = fcmp one float %1211, 0.000000e+00
  %1217 = and i1 %1215, %1216
  br i1 %1217, label %1218, label %1219

1218:                                             ; preds = %1200
  br label %1231

1219:                                             ; preds = %1200
  %1220 = fpext float %1212 to double
  %1221 = fpext float %1210 to double
  %1222 = fpext float %1204 to double
  %1223 = fmul double %1220, %1221
  %1224 = fmul double %1223, %1222
  %1225 = fptrunc double %1224 to float
  %1226 = fcmp oeq float %1212, 0.000000e+00
  %1227 = call float @llvm.fabs.f32(float %1204)
  %1228 = fcmp olt float %1227, +inf
  %1229 = and i1 %1226, %1228
  %1230 = select i1 %1229, float 0.000000e+00, float %1225
  br label %1231

1231:                                             ; preds = %1218, %1219
  %1232 = phi float [ %1230, %1219 ], [ %1213, %1218 ]
  br label %1233

1233:                                             ; preds = %1231
  %1234 = add i64 %89, %57
  %1235 = icmp slt i64 %1234, %26
  %1236 = select i1 %1235, i64 %1234, i64 0
  %1237 = extractelement <8 x float> %1166, i64 2
  %1238 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1239 = getelementptr inbounds nuw i8, ptr %1238, i64 %1236
  %1240 = load i8, ptr %1239, align 1
  %1241 = zext i8 %1240 to i32
  %1242 = shl i32 %1241, 23
  %1243 = bitcast i32 %1242 to float
  %1244 = fmul float %1243, %1237
  %1245 = extractelement <8 x float> %631, i64 2
  %1246 = fmul float %1245, %1244
  %1247 = call float @llvm.fabs.f32(float %1244)
  %1248 = fcmp olt float %1247, +inf
  %1249 = fcmp one float %1244, 0.000000e+00
  %1250 = and i1 %1248, %1249
  br i1 %1250, label %1251, label %1252

1251:                                             ; preds = %1233
  br label %1264

1252:                                             ; preds = %1233
  %1253 = fpext float %1245 to double
  %1254 = fpext float %1243 to double
  %1255 = fpext float %1237 to double
  %1256 = fmul double %1253, %1254
  %1257 = fmul double %1256, %1255
  %1258 = fptrunc double %1257 to float
  %1259 = fcmp oeq float %1245, 0.000000e+00
  %1260 = call float @llvm.fabs.f32(float %1237)
  %1261 = fcmp olt float %1260, +inf
  %1262 = and i1 %1259, %1261
  %1263 = select i1 %1262, float 0.000000e+00, float %1258
  br label %1264

1264:                                             ; preds = %1251, %1252
  %1265 = phi float [ %1263, %1252 ], [ %1246, %1251 ]
  br label %1266

1266:                                             ; preds = %1264
  %1267 = add i64 %89, %57
  %1268 = icmp slt i64 %1267, %26
  %1269 = select i1 %1268, i64 %1267, i64 0
  %1270 = extractelement <8 x float> %1166, i64 3
  %1271 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1272 = getelementptr inbounds nuw i8, ptr %1271, i64 %1269
  %1273 = load i8, ptr %1272, align 1
  %1274 = zext i8 %1273 to i32
  %1275 = shl i32 %1274, 23
  %1276 = bitcast i32 %1275 to float
  %1277 = fmul float %1276, %1270
  %1278 = extractelement <8 x float> %631, i64 3
  %1279 = fmul float %1278, %1277
  %1280 = call float @llvm.fabs.f32(float %1277)
  %1281 = fcmp olt float %1280, +inf
  %1282 = fcmp one float %1277, 0.000000e+00
  %1283 = and i1 %1281, %1282
  br i1 %1283, label %1284, label %1285

1284:                                             ; preds = %1266
  br label %1297

1285:                                             ; preds = %1266
  %1286 = fpext float %1278 to double
  %1287 = fpext float %1276 to double
  %1288 = fpext float %1270 to double
  %1289 = fmul double %1286, %1287
  %1290 = fmul double %1289, %1288
  %1291 = fptrunc double %1290 to float
  %1292 = fcmp oeq float %1278, 0.000000e+00
  %1293 = call float @llvm.fabs.f32(float %1270)
  %1294 = fcmp olt float %1293, +inf
  %1295 = and i1 %1292, %1294
  %1296 = select i1 %1295, float 0.000000e+00, float %1291
  br label %1297

1297:                                             ; preds = %1284, %1285
  %1298 = phi float [ %1296, %1285 ], [ %1279, %1284 ]
  br label %1299

1299:                                             ; preds = %1297
  %1300 = add i64 %89, %57
  %1301 = icmp slt i64 %1300, %26
  %1302 = select i1 %1301, i64 %1300, i64 0
  %1303 = extractelement <8 x float> %1166, i64 4
  %1304 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1305 = getelementptr inbounds nuw i8, ptr %1304, i64 %1302
  %1306 = load i8, ptr %1305, align 1
  %1307 = zext i8 %1306 to i32
  %1308 = shl i32 %1307, 23
  %1309 = bitcast i32 %1308 to float
  %1310 = fmul float %1309, %1303
  %1311 = extractelement <8 x float> %631, i64 4
  %1312 = fmul float %1311, %1310
  %1313 = call float @llvm.fabs.f32(float %1310)
  %1314 = fcmp olt float %1313, +inf
  %1315 = fcmp one float %1310, 0.000000e+00
  %1316 = and i1 %1314, %1315
  br i1 %1316, label %1317, label %1318

1317:                                             ; preds = %1299
  br label %1330

1318:                                             ; preds = %1299
  %1319 = fpext float %1311 to double
  %1320 = fpext float %1309 to double
  %1321 = fpext float %1303 to double
  %1322 = fmul double %1319, %1320
  %1323 = fmul double %1322, %1321
  %1324 = fptrunc double %1323 to float
  %1325 = fcmp oeq float %1311, 0.000000e+00
  %1326 = call float @llvm.fabs.f32(float %1303)
  %1327 = fcmp olt float %1326, +inf
  %1328 = and i1 %1325, %1327
  %1329 = select i1 %1328, float 0.000000e+00, float %1324
  br label %1330

1330:                                             ; preds = %1317, %1318
  %1331 = phi float [ %1329, %1318 ], [ %1312, %1317 ]
  br label %1332

1332:                                             ; preds = %1330
  %1333 = add i64 %89, %57
  %1334 = icmp slt i64 %1333, %26
  %1335 = select i1 %1334, i64 %1333, i64 0
  %1336 = extractelement <8 x float> %1166, i64 5
  %1337 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1338 = getelementptr inbounds nuw i8, ptr %1337, i64 %1335
  %1339 = load i8, ptr %1338, align 1
  %1340 = zext i8 %1339 to i32
  %1341 = shl i32 %1340, 23
  %1342 = bitcast i32 %1341 to float
  %1343 = fmul float %1342, %1336
  %1344 = extractelement <8 x float> %631, i64 5
  %1345 = fmul float %1344, %1343
  %1346 = call float @llvm.fabs.f32(float %1343)
  %1347 = fcmp olt float %1346, +inf
  %1348 = fcmp one float %1343, 0.000000e+00
  %1349 = and i1 %1347, %1348
  br i1 %1349, label %1350, label %1351

1350:                                             ; preds = %1332
  br label %1363

1351:                                             ; preds = %1332
  %1352 = fpext float %1344 to double
  %1353 = fpext float %1342 to double
  %1354 = fpext float %1336 to double
  %1355 = fmul double %1352, %1353
  %1356 = fmul double %1355, %1354
  %1357 = fptrunc double %1356 to float
  %1358 = fcmp oeq float %1344, 0.000000e+00
  %1359 = call float @llvm.fabs.f32(float %1336)
  %1360 = fcmp olt float %1359, +inf
  %1361 = and i1 %1358, %1360
  %1362 = select i1 %1361, float 0.000000e+00, float %1357
  br label %1363

1363:                                             ; preds = %1350, %1351
  %1364 = phi float [ %1362, %1351 ], [ %1345, %1350 ]
  br label %1365

1365:                                             ; preds = %1363
  %1366 = add i64 %89, %57
  %1367 = icmp slt i64 %1366, %26
  %1368 = select i1 %1367, i64 %1366, i64 0
  %1369 = extractelement <8 x float> %1166, i64 6
  %1370 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1371 = getelementptr inbounds nuw i8, ptr %1370, i64 %1368
  %1372 = load i8, ptr %1371, align 1
  %1373 = zext i8 %1372 to i32
  %1374 = shl i32 %1373, 23
  %1375 = bitcast i32 %1374 to float
  %1376 = fmul float %1375, %1369
  %1377 = extractelement <8 x float> %631, i64 6
  %1378 = fmul float %1377, %1376
  %1379 = call float @llvm.fabs.f32(float %1376)
  %1380 = fcmp olt float %1379, +inf
  %1381 = fcmp one float %1376, 0.000000e+00
  %1382 = and i1 %1380, %1381
  br i1 %1382, label %1383, label %1384

1383:                                             ; preds = %1365
  br label %1396

1384:                                             ; preds = %1365
  %1385 = fpext float %1377 to double
  %1386 = fpext float %1375 to double
  %1387 = fpext float %1369 to double
  %1388 = fmul double %1385, %1386
  %1389 = fmul double %1388, %1387
  %1390 = fptrunc double %1389 to float
  %1391 = fcmp oeq float %1377, 0.000000e+00
  %1392 = call float @llvm.fabs.f32(float %1369)
  %1393 = fcmp olt float %1392, +inf
  %1394 = and i1 %1391, %1393
  %1395 = select i1 %1394, float 0.000000e+00, float %1390
  br label %1396

1396:                                             ; preds = %1383, %1384
  %1397 = phi float [ %1395, %1384 ], [ %1378, %1383 ]
  br label %1398

1398:                                             ; preds = %1396
  %1399 = add i64 %89, %57
  %1400 = icmp slt i64 %1399, %26
  %1401 = select i1 %1400, i64 %1399, i64 0
  %1402 = extractelement <8 x float> %1166, i64 7
  %1403 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1404 = getelementptr inbounds nuw i8, ptr %1403, i64 %1401
  %1405 = load i8, ptr %1404, align 1
  %1406 = zext i8 %1405 to i32
  %1407 = shl i32 %1406, 23
  %1408 = bitcast i32 %1407 to float
  %1409 = fmul float %1408, %1402
  %1410 = extractelement <8 x float> %631, i64 7
  %1411 = fmul float %1410, %1409
  %1412 = call float @llvm.fabs.f32(float %1409)
  %1413 = fcmp olt float %1412, +inf
  %1414 = fcmp one float %1409, 0.000000e+00
  %1415 = and i1 %1413, %1414
  br i1 %1415, label %1416, label %1417

1416:                                             ; preds = %1398
  br label %1429

1417:                                             ; preds = %1398
  %1418 = fpext float %1410 to double
  %1419 = fpext float %1408 to double
  %1420 = fpext float %1402 to double
  %1421 = fmul double %1418, %1419
  %1422 = fmul double %1421, %1420
  %1423 = fptrunc double %1422 to float
  %1424 = fcmp oeq float %1410, 0.000000e+00
  %1425 = call float @llvm.fabs.f32(float %1402)
  %1426 = fcmp olt float %1425, +inf
  %1427 = and i1 %1424, %1426
  %1428 = select i1 %1427, float 0.000000e+00, float %1423
  br label %1429

1429:                                             ; preds = %1416, %1417
  %1430 = phi float [ %1428, %1417 ], [ %1411, %1416 ]
  br label %1431

1431:                                             ; preds = %1429
  %1432 = mul i64 %58, 8
  %1433 = add i64 %84, %1432
  %1434 = add i64 %89, %57
  %1435 = mul i64 %1433, %26
  %1436 = add i64 %1435, %1434
  %1437 = fptrunc float %1199 to bfloat
  %1438 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1439 = getelementptr inbounds nuw bfloat, ptr %1438, i64 %1436
  store bfloat %1437, ptr %1439, align 2
  %1440 = mul i64 %58, 8
  %1441 = add i64 %1440, 1
  %1442 = add i64 %84, %1441
  %1443 = add i64 %89, %57
  %1444 = mul i64 %1442, %26
  %1445 = add i64 %1444, %1443
  %1446 = fptrunc float %1232 to bfloat
  %1447 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1448 = getelementptr inbounds nuw bfloat, ptr %1447, i64 %1445
  store bfloat %1446, ptr %1448, align 2
  %1449 = mul i64 %58, 8
  %1450 = add i64 %1449, 2
  %1451 = add i64 %84, %1450
  %1452 = add i64 %89, %57
  %1453 = mul i64 %1451, %26
  %1454 = add i64 %1453, %1452
  %1455 = fptrunc float %1265 to bfloat
  %1456 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1457 = getelementptr inbounds nuw bfloat, ptr %1456, i64 %1454
  store bfloat %1455, ptr %1457, align 2
  %1458 = mul i64 %58, 8
  %1459 = add i64 %1458, 3
  %1460 = add i64 %84, %1459
  %1461 = add i64 %89, %57
  %1462 = mul i64 %1460, %26
  %1463 = add i64 %1462, %1461
  %1464 = fptrunc float %1298 to bfloat
  %1465 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1466 = getelementptr inbounds nuw bfloat, ptr %1465, i64 %1463
  store bfloat %1464, ptr %1466, align 2
  %1467 = mul i64 %58, 8
  %1468 = add i64 %1467, 4
  %1469 = add i64 %84, %1468
  %1470 = add i64 %89, %57
  %1471 = mul i64 %1469, %26
  %1472 = add i64 %1471, %1470
  %1473 = fptrunc float %1331 to bfloat
  %1474 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1475 = getelementptr inbounds nuw bfloat, ptr %1474, i64 %1472
  store bfloat %1473, ptr %1475, align 2
  %1476 = mul i64 %58, 8
  %1477 = add i64 %1476, 5
  %1478 = add i64 %84, %1477
  %1479 = add i64 %89, %57
  %1480 = mul i64 %1478, %26
  %1481 = add i64 %1480, %1479
  %1482 = fptrunc float %1364 to bfloat
  %1483 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1484 = getelementptr inbounds nuw bfloat, ptr %1483, i64 %1481
  store bfloat %1482, ptr %1484, align 2
  %1485 = mul i64 %58, 8
  %1486 = add i64 %1485, 6
  %1487 = add i64 %84, %1486
  %1488 = add i64 %89, %57
  %1489 = mul i64 %1487, %26
  %1490 = add i64 %1489, %1488
  %1491 = fptrunc float %1397 to bfloat
  %1492 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1493 = getelementptr inbounds nuw bfloat, ptr %1492, i64 %1490
  store bfloat %1491, ptr %1493, align 2
  %1494 = mul i64 %58, 8
  %1495 = add i64 %1494, 7
  %1496 = add i64 %84, %1495
  %1497 = add i64 %89, %57
  %1498 = mul i64 %1496, %26
  %1499 = add i64 %1498, %1497
  %1500 = fptrunc float %1430 to bfloat
  %1501 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1502 = getelementptr inbounds nuw bfloat, ptr %1501, i64 %1499
  store bfloat %1500, ptr %1502, align 2
  %1503 = mul i64 %58, 8
  %1504 = add i64 %86, %1503
  %1505 = add i64 %89, %57
  %1506 = add i64 %1504, 7
  %1507 = icmp ult i64 %1505, %26
  %1508 = icmp ult i64 %1506, %25
  %1509 = and i1 %1508, %1507
  %1510 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1511 = ptrtoint ptr %1510 to i64
  %1512 = mul i64 %1504, 4
  %1513 = add i64 %1511, %1512
  %1514 = urem i64 %1513, 16
  %1515 = icmp eq i64 %1514, 0
  %1516 = and i1 %1509, %1515
  br i1 %1516, label %1517, label %1526

1517:                                             ; preds = %1431
  %1518 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1519 = getelementptr float, ptr %1518, i64 %1504
  %1520 = load <4 x float>, ptr %1519, align 16
  %1521 = add i64 %1504, 4
  %1522 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1523 = getelementptr float, ptr %1522, i64 %1521
  %1524 = load <4 x float>, ptr %1523, align 16
  %1525 = shufflevector <4 x float> %1520, <4 x float> %1524, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %1598

1526:                                             ; preds = %1431
  %1527 = mul i64 %58, 8
  %1528 = add i64 %86, %1527
  %1529 = icmp slt i64 %1528, %25
  %1530 = select i1 %1529, i64 %1528, i64 0
  %1531 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1532 = getelementptr inbounds nuw float, ptr %1531, i64 %1530
  %1533 = load float, ptr %1532, align 4
  %1534 = insertelement <8 x float> zeroinitializer, float %1533, i64 0
  %1535 = mul i64 %58, 8
  %1536 = add i64 %1535, 1
  %1537 = add i64 %86, %1536
  %1538 = icmp slt i64 %1537, %25
  %1539 = select i1 %1538, i64 %1537, i64 0
  %1540 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1541 = getelementptr inbounds nuw float, ptr %1540, i64 %1539
  %1542 = load float, ptr %1541, align 4
  %1543 = insertelement <8 x float> %1534, float %1542, i64 1
  %1544 = mul i64 %58, 8
  %1545 = add i64 %1544, 2
  %1546 = add i64 %86, %1545
  %1547 = icmp slt i64 %1546, %25
  %1548 = select i1 %1547, i64 %1546, i64 0
  %1549 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1550 = getelementptr inbounds nuw float, ptr %1549, i64 %1548
  %1551 = load float, ptr %1550, align 4
  %1552 = insertelement <8 x float> %1543, float %1551, i64 2
  %1553 = mul i64 %58, 8
  %1554 = add i64 %1553, 3
  %1555 = add i64 %86, %1554
  %1556 = icmp slt i64 %1555, %25
  %1557 = select i1 %1556, i64 %1555, i64 0
  %1558 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1559 = getelementptr inbounds nuw float, ptr %1558, i64 %1557
  %1560 = load float, ptr %1559, align 4
  %1561 = insertelement <8 x float> %1552, float %1560, i64 3
  %1562 = mul i64 %58, 8
  %1563 = add i64 %1562, 4
  %1564 = add i64 %86, %1563
  %1565 = icmp slt i64 %1564, %25
  %1566 = select i1 %1565, i64 %1564, i64 0
  %1567 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1568 = getelementptr inbounds nuw float, ptr %1567, i64 %1566
  %1569 = load float, ptr %1568, align 4
  %1570 = insertelement <8 x float> %1561, float %1569, i64 4
  %1571 = mul i64 %58, 8
  %1572 = add i64 %1571, 5
  %1573 = add i64 %86, %1572
  %1574 = icmp slt i64 %1573, %25
  %1575 = select i1 %1574, i64 %1573, i64 0
  %1576 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1577 = getelementptr inbounds nuw float, ptr %1576, i64 %1575
  %1578 = load float, ptr %1577, align 4
  %1579 = insertelement <8 x float> %1570, float %1578, i64 5
  %1580 = mul i64 %58, 8
  %1581 = add i64 %1580, 6
  %1582 = add i64 %86, %1581
  %1583 = icmp slt i64 %1582, %25
  %1584 = select i1 %1583, i64 %1582, i64 0
  %1585 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1586 = getelementptr inbounds nuw float, ptr %1585, i64 %1584
  %1587 = load float, ptr %1586, align 4
  %1588 = insertelement <8 x float> %1579, float %1587, i64 6
  %1589 = mul i64 %58, 8
  %1590 = add i64 %1589, 7
  %1591 = add i64 %86, %1590
  %1592 = icmp slt i64 %1591, %25
  %1593 = select i1 %1592, i64 %1591, i64 0
  %1594 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1595 = getelementptr inbounds nuw float, ptr %1594, i64 %1593
  %1596 = load float, ptr %1595, align 4
  %1597 = insertelement <8 x float> %1588, float %1596, i64 7
  br label %1598

1598:                                             ; preds = %1517, %1526
  %1599 = phi <8 x float> [ %1597, %1526 ], [ %1525, %1517 ]
  br label %1600

1600:                                             ; preds = %1598
  %1601 = add i64 %89, %57
  %1602 = icmp slt i64 %1601, %26
  %1603 = select i1 %1602, i64 %1601, i64 0
  %1604 = extractelement <8 x float> %1599, i64 0
  %1605 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1606 = getelementptr inbounds nuw i8, ptr %1605, i64 %1603
  %1607 = load i8, ptr %1606, align 1
  %1608 = zext i8 %1607 to i32
  %1609 = shl i32 %1608, 23
  %1610 = bitcast i32 %1609 to float
  %1611 = fmul float %1610, %1604
  %1612 = extractelement <8 x float> %633, i64 0
  %1613 = fmul float %1612, %1611
  %1614 = call float @llvm.fabs.f32(float %1611)
  %1615 = fcmp olt float %1614, +inf
  %1616 = fcmp one float %1611, 0.000000e+00
  %1617 = and i1 %1615, %1616
  br i1 %1617, label %1618, label %1619

1618:                                             ; preds = %1600
  br label %1631

1619:                                             ; preds = %1600
  %1620 = fpext float %1612 to double
  %1621 = fpext float %1610 to double
  %1622 = fpext float %1604 to double
  %1623 = fmul double %1620, %1621
  %1624 = fmul double %1623, %1622
  %1625 = fptrunc double %1624 to float
  %1626 = fcmp oeq float %1612, 0.000000e+00
  %1627 = call float @llvm.fabs.f32(float %1604)
  %1628 = fcmp olt float %1627, +inf
  %1629 = and i1 %1626, %1628
  %1630 = select i1 %1629, float 0.000000e+00, float %1625
  br label %1631

1631:                                             ; preds = %1618, %1619
  %1632 = phi float [ %1630, %1619 ], [ %1613, %1618 ]
  br label %1633

1633:                                             ; preds = %1631
  %1634 = add i64 %89, %57
  %1635 = icmp slt i64 %1634, %26
  %1636 = select i1 %1635, i64 %1634, i64 0
  %1637 = extractelement <8 x float> %1599, i64 1
  %1638 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1639 = getelementptr inbounds nuw i8, ptr %1638, i64 %1636
  %1640 = load i8, ptr %1639, align 1
  %1641 = zext i8 %1640 to i32
  %1642 = shl i32 %1641, 23
  %1643 = bitcast i32 %1642 to float
  %1644 = fmul float %1643, %1637
  %1645 = extractelement <8 x float> %633, i64 1
  %1646 = fmul float %1645, %1644
  %1647 = call float @llvm.fabs.f32(float %1644)
  %1648 = fcmp olt float %1647, +inf
  %1649 = fcmp one float %1644, 0.000000e+00
  %1650 = and i1 %1648, %1649
  br i1 %1650, label %1651, label %1652

1651:                                             ; preds = %1633
  br label %1664

1652:                                             ; preds = %1633
  %1653 = fpext float %1645 to double
  %1654 = fpext float %1643 to double
  %1655 = fpext float %1637 to double
  %1656 = fmul double %1653, %1654
  %1657 = fmul double %1656, %1655
  %1658 = fptrunc double %1657 to float
  %1659 = fcmp oeq float %1645, 0.000000e+00
  %1660 = call float @llvm.fabs.f32(float %1637)
  %1661 = fcmp olt float %1660, +inf
  %1662 = and i1 %1659, %1661
  %1663 = select i1 %1662, float 0.000000e+00, float %1658
  br label %1664

1664:                                             ; preds = %1651, %1652
  %1665 = phi float [ %1663, %1652 ], [ %1646, %1651 ]
  br label %1666

1666:                                             ; preds = %1664
  %1667 = add i64 %89, %57
  %1668 = icmp slt i64 %1667, %26
  %1669 = select i1 %1668, i64 %1667, i64 0
  %1670 = extractelement <8 x float> %1599, i64 2
  %1671 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1672 = getelementptr inbounds nuw i8, ptr %1671, i64 %1669
  %1673 = load i8, ptr %1672, align 1
  %1674 = zext i8 %1673 to i32
  %1675 = shl i32 %1674, 23
  %1676 = bitcast i32 %1675 to float
  %1677 = fmul float %1676, %1670
  %1678 = extractelement <8 x float> %633, i64 2
  %1679 = fmul float %1678, %1677
  %1680 = call float @llvm.fabs.f32(float %1677)
  %1681 = fcmp olt float %1680, +inf
  %1682 = fcmp one float %1677, 0.000000e+00
  %1683 = and i1 %1681, %1682
  br i1 %1683, label %1684, label %1685

1684:                                             ; preds = %1666
  br label %1697

1685:                                             ; preds = %1666
  %1686 = fpext float %1678 to double
  %1687 = fpext float %1676 to double
  %1688 = fpext float %1670 to double
  %1689 = fmul double %1686, %1687
  %1690 = fmul double %1689, %1688
  %1691 = fptrunc double %1690 to float
  %1692 = fcmp oeq float %1678, 0.000000e+00
  %1693 = call float @llvm.fabs.f32(float %1670)
  %1694 = fcmp olt float %1693, +inf
  %1695 = and i1 %1692, %1694
  %1696 = select i1 %1695, float 0.000000e+00, float %1691
  br label %1697

1697:                                             ; preds = %1684, %1685
  %1698 = phi float [ %1696, %1685 ], [ %1679, %1684 ]
  br label %1699

1699:                                             ; preds = %1697
  %1700 = add i64 %89, %57
  %1701 = icmp slt i64 %1700, %26
  %1702 = select i1 %1701, i64 %1700, i64 0
  %1703 = extractelement <8 x float> %1599, i64 3
  %1704 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1705 = getelementptr inbounds nuw i8, ptr %1704, i64 %1702
  %1706 = load i8, ptr %1705, align 1
  %1707 = zext i8 %1706 to i32
  %1708 = shl i32 %1707, 23
  %1709 = bitcast i32 %1708 to float
  %1710 = fmul float %1709, %1703
  %1711 = extractelement <8 x float> %633, i64 3
  %1712 = fmul float %1711, %1710
  %1713 = call float @llvm.fabs.f32(float %1710)
  %1714 = fcmp olt float %1713, +inf
  %1715 = fcmp one float %1710, 0.000000e+00
  %1716 = and i1 %1714, %1715
  br i1 %1716, label %1717, label %1718

1717:                                             ; preds = %1699
  br label %1730

1718:                                             ; preds = %1699
  %1719 = fpext float %1711 to double
  %1720 = fpext float %1709 to double
  %1721 = fpext float %1703 to double
  %1722 = fmul double %1719, %1720
  %1723 = fmul double %1722, %1721
  %1724 = fptrunc double %1723 to float
  %1725 = fcmp oeq float %1711, 0.000000e+00
  %1726 = call float @llvm.fabs.f32(float %1703)
  %1727 = fcmp olt float %1726, +inf
  %1728 = and i1 %1725, %1727
  %1729 = select i1 %1728, float 0.000000e+00, float %1724
  br label %1730

1730:                                             ; preds = %1717, %1718
  %1731 = phi float [ %1729, %1718 ], [ %1712, %1717 ]
  br label %1732

1732:                                             ; preds = %1730
  %1733 = add i64 %89, %57
  %1734 = icmp slt i64 %1733, %26
  %1735 = select i1 %1734, i64 %1733, i64 0
  %1736 = extractelement <8 x float> %1599, i64 4
  %1737 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1738 = getelementptr inbounds nuw i8, ptr %1737, i64 %1735
  %1739 = load i8, ptr %1738, align 1
  %1740 = zext i8 %1739 to i32
  %1741 = shl i32 %1740, 23
  %1742 = bitcast i32 %1741 to float
  %1743 = fmul float %1742, %1736
  %1744 = extractelement <8 x float> %633, i64 4
  %1745 = fmul float %1744, %1743
  %1746 = call float @llvm.fabs.f32(float %1743)
  %1747 = fcmp olt float %1746, +inf
  %1748 = fcmp one float %1743, 0.000000e+00
  %1749 = and i1 %1747, %1748
  br i1 %1749, label %1750, label %1751

1750:                                             ; preds = %1732
  br label %1763

1751:                                             ; preds = %1732
  %1752 = fpext float %1744 to double
  %1753 = fpext float %1742 to double
  %1754 = fpext float %1736 to double
  %1755 = fmul double %1752, %1753
  %1756 = fmul double %1755, %1754
  %1757 = fptrunc double %1756 to float
  %1758 = fcmp oeq float %1744, 0.000000e+00
  %1759 = call float @llvm.fabs.f32(float %1736)
  %1760 = fcmp olt float %1759, +inf
  %1761 = and i1 %1758, %1760
  %1762 = select i1 %1761, float 0.000000e+00, float %1757
  br label %1763

1763:                                             ; preds = %1750, %1751
  %1764 = phi float [ %1762, %1751 ], [ %1745, %1750 ]
  br label %1765

1765:                                             ; preds = %1763
  %1766 = add i64 %89, %57
  %1767 = icmp slt i64 %1766, %26
  %1768 = select i1 %1767, i64 %1766, i64 0
  %1769 = extractelement <8 x float> %1599, i64 5
  %1770 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1771 = getelementptr inbounds nuw i8, ptr %1770, i64 %1768
  %1772 = load i8, ptr %1771, align 1
  %1773 = zext i8 %1772 to i32
  %1774 = shl i32 %1773, 23
  %1775 = bitcast i32 %1774 to float
  %1776 = fmul float %1775, %1769
  %1777 = extractelement <8 x float> %633, i64 5
  %1778 = fmul float %1777, %1776
  %1779 = call float @llvm.fabs.f32(float %1776)
  %1780 = fcmp olt float %1779, +inf
  %1781 = fcmp one float %1776, 0.000000e+00
  %1782 = and i1 %1780, %1781
  br i1 %1782, label %1783, label %1784

1783:                                             ; preds = %1765
  br label %1796

1784:                                             ; preds = %1765
  %1785 = fpext float %1777 to double
  %1786 = fpext float %1775 to double
  %1787 = fpext float %1769 to double
  %1788 = fmul double %1785, %1786
  %1789 = fmul double %1788, %1787
  %1790 = fptrunc double %1789 to float
  %1791 = fcmp oeq float %1777, 0.000000e+00
  %1792 = call float @llvm.fabs.f32(float %1769)
  %1793 = fcmp olt float %1792, +inf
  %1794 = and i1 %1791, %1793
  %1795 = select i1 %1794, float 0.000000e+00, float %1790
  br label %1796

1796:                                             ; preds = %1783, %1784
  %1797 = phi float [ %1795, %1784 ], [ %1778, %1783 ]
  br label %1798

1798:                                             ; preds = %1796
  %1799 = add i64 %89, %57
  %1800 = icmp slt i64 %1799, %26
  %1801 = select i1 %1800, i64 %1799, i64 0
  %1802 = extractelement <8 x float> %1599, i64 6
  %1803 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1804 = getelementptr inbounds nuw i8, ptr %1803, i64 %1801
  %1805 = load i8, ptr %1804, align 1
  %1806 = zext i8 %1805 to i32
  %1807 = shl i32 %1806, 23
  %1808 = bitcast i32 %1807 to float
  %1809 = fmul float %1808, %1802
  %1810 = extractelement <8 x float> %633, i64 6
  %1811 = fmul float %1810, %1809
  %1812 = call float @llvm.fabs.f32(float %1809)
  %1813 = fcmp olt float %1812, +inf
  %1814 = fcmp one float %1809, 0.000000e+00
  %1815 = and i1 %1813, %1814
  br i1 %1815, label %1816, label %1817

1816:                                             ; preds = %1798
  br label %1829

1817:                                             ; preds = %1798
  %1818 = fpext float %1810 to double
  %1819 = fpext float %1808 to double
  %1820 = fpext float %1802 to double
  %1821 = fmul double %1818, %1819
  %1822 = fmul double %1821, %1820
  %1823 = fptrunc double %1822 to float
  %1824 = fcmp oeq float %1810, 0.000000e+00
  %1825 = call float @llvm.fabs.f32(float %1802)
  %1826 = fcmp olt float %1825, +inf
  %1827 = and i1 %1824, %1826
  %1828 = select i1 %1827, float 0.000000e+00, float %1823
  br label %1829

1829:                                             ; preds = %1816, %1817
  %1830 = phi float [ %1828, %1817 ], [ %1811, %1816 ]
  br label %1831

1831:                                             ; preds = %1829
  %1832 = add i64 %89, %57
  %1833 = icmp slt i64 %1832, %26
  %1834 = select i1 %1833, i64 %1832, i64 0
  %1835 = extractelement <8 x float> %1599, i64 7
  %1836 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %1837 = getelementptr inbounds nuw i8, ptr %1836, i64 %1834
  %1838 = load i8, ptr %1837, align 1
  %1839 = zext i8 %1838 to i32
  %1840 = shl i32 %1839, 23
  %1841 = bitcast i32 %1840 to float
  %1842 = fmul float %1841, %1835
  %1843 = extractelement <8 x float> %633, i64 7
  %1844 = fmul float %1843, %1842
  %1845 = call float @llvm.fabs.f32(float %1842)
  %1846 = fcmp olt float %1845, +inf
  %1847 = fcmp one float %1842, 0.000000e+00
  %1848 = and i1 %1846, %1847
  br i1 %1848, label %1849, label %1850

1849:                                             ; preds = %1831
  br label %1862

1850:                                             ; preds = %1831
  %1851 = fpext float %1843 to double
  %1852 = fpext float %1841 to double
  %1853 = fpext float %1835 to double
  %1854 = fmul double %1851, %1852
  %1855 = fmul double %1854, %1853
  %1856 = fptrunc double %1855 to float
  %1857 = fcmp oeq float %1843, 0.000000e+00
  %1858 = call float @llvm.fabs.f32(float %1835)
  %1859 = fcmp olt float %1858, +inf
  %1860 = and i1 %1857, %1859
  %1861 = select i1 %1860, float 0.000000e+00, float %1856
  br label %1862

1862:                                             ; preds = %1849, %1850
  %1863 = phi float [ %1861, %1850 ], [ %1844, %1849 ]
  br label %1864

1864:                                             ; preds = %1862
  %1865 = mul i64 %58, 8
  %1866 = add i64 %86, %1865
  %1867 = add i64 %89, %57
  %1868 = mul i64 %1866, %26
  %1869 = add i64 %1868, %1867
  %1870 = fptrunc float %1632 to bfloat
  %1871 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1872 = getelementptr inbounds nuw bfloat, ptr %1871, i64 %1869
  store bfloat %1870, ptr %1872, align 2
  %1873 = mul i64 %58, 8
  %1874 = add i64 %1873, 1
  %1875 = add i64 %86, %1874
  %1876 = add i64 %89, %57
  %1877 = mul i64 %1875, %26
  %1878 = add i64 %1877, %1876
  %1879 = fptrunc float %1665 to bfloat
  %1880 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1881 = getelementptr inbounds nuw bfloat, ptr %1880, i64 %1878
  store bfloat %1879, ptr %1881, align 2
  %1882 = mul i64 %58, 8
  %1883 = add i64 %1882, 2
  %1884 = add i64 %86, %1883
  %1885 = add i64 %89, %57
  %1886 = mul i64 %1884, %26
  %1887 = add i64 %1886, %1885
  %1888 = fptrunc float %1698 to bfloat
  %1889 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1890 = getelementptr inbounds nuw bfloat, ptr %1889, i64 %1887
  store bfloat %1888, ptr %1890, align 2
  %1891 = mul i64 %58, 8
  %1892 = add i64 %1891, 3
  %1893 = add i64 %86, %1892
  %1894 = add i64 %89, %57
  %1895 = mul i64 %1893, %26
  %1896 = add i64 %1895, %1894
  %1897 = fptrunc float %1731 to bfloat
  %1898 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1899 = getelementptr inbounds nuw bfloat, ptr %1898, i64 %1896
  store bfloat %1897, ptr %1899, align 2
  %1900 = mul i64 %58, 8
  %1901 = add i64 %1900, 4
  %1902 = add i64 %86, %1901
  %1903 = add i64 %89, %57
  %1904 = mul i64 %1902, %26
  %1905 = add i64 %1904, %1903
  %1906 = fptrunc float %1764 to bfloat
  %1907 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1908 = getelementptr inbounds nuw bfloat, ptr %1907, i64 %1905
  store bfloat %1906, ptr %1908, align 2
  %1909 = mul i64 %58, 8
  %1910 = add i64 %1909, 5
  %1911 = add i64 %86, %1910
  %1912 = add i64 %89, %57
  %1913 = mul i64 %1911, %26
  %1914 = add i64 %1913, %1912
  %1915 = fptrunc float %1797 to bfloat
  %1916 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1917 = getelementptr inbounds nuw bfloat, ptr %1916, i64 %1914
  store bfloat %1915, ptr %1917, align 2
  %1918 = mul i64 %58, 8
  %1919 = add i64 %1918, 6
  %1920 = add i64 %86, %1919
  %1921 = add i64 %89, %57
  %1922 = mul i64 %1920, %26
  %1923 = add i64 %1922, %1921
  %1924 = fptrunc float %1830 to bfloat
  %1925 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1926 = getelementptr inbounds nuw bfloat, ptr %1925, i64 %1923
  store bfloat %1924, ptr %1926, align 2
  %1927 = mul i64 %58, 8
  %1928 = add i64 %1927, 7
  %1929 = add i64 %86, %1928
  %1930 = add i64 %89, %57
  %1931 = mul i64 %1929, %26
  %1932 = add i64 %1931, %1930
  %1933 = fptrunc float %1863 to bfloat
  %1934 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %1935 = getelementptr inbounds nuw bfloat, ptr %1934, i64 %1932
  store bfloat %1933, ptr %1935, align 2
  %1936 = mul i64 %58, 8
  %1937 = add i64 %88, %1936
  %1938 = add i64 %89, %57
  %1939 = add i64 %1937, 7
  %1940 = icmp ult i64 %1938, %26
  %1941 = icmp ult i64 %1939, %25
  %1942 = and i1 %1941, %1940
  %1943 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1944 = ptrtoint ptr %1943 to i64
  %1945 = mul i64 %1937, 4
  %1946 = add i64 %1944, %1945
  %1947 = urem i64 %1946, 16
  %1948 = icmp eq i64 %1947, 0
  %1949 = and i1 %1942, %1948
  br i1 %1949, label %1950, label %1959

1950:                                             ; preds = %1864
  %1951 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1952 = getelementptr float, ptr %1951, i64 %1937
  %1953 = load <4 x float>, ptr %1952, align 16
  %1954 = add i64 %1937, 4
  %1955 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1956 = getelementptr float, ptr %1955, i64 %1954
  %1957 = load <4 x float>, ptr %1956, align 16
  %1958 = shufflevector <4 x float> %1953, <4 x float> %1957, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2031

1959:                                             ; preds = %1864
  %1960 = mul i64 %58, 8
  %1961 = add i64 %88, %1960
  %1962 = icmp slt i64 %1961, %25
  %1963 = select i1 %1962, i64 %1961, i64 0
  %1964 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1965 = getelementptr inbounds nuw float, ptr %1964, i64 %1963
  %1966 = load float, ptr %1965, align 4
  %1967 = insertelement <8 x float> zeroinitializer, float %1966, i64 0
  %1968 = mul i64 %58, 8
  %1969 = add i64 %1968, 1
  %1970 = add i64 %88, %1969
  %1971 = icmp slt i64 %1970, %25
  %1972 = select i1 %1971, i64 %1970, i64 0
  %1973 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1974 = getelementptr inbounds nuw float, ptr %1973, i64 %1972
  %1975 = load float, ptr %1974, align 4
  %1976 = insertelement <8 x float> %1967, float %1975, i64 1
  %1977 = mul i64 %58, 8
  %1978 = add i64 %1977, 2
  %1979 = add i64 %88, %1978
  %1980 = icmp slt i64 %1979, %25
  %1981 = select i1 %1980, i64 %1979, i64 0
  %1982 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1983 = getelementptr inbounds nuw float, ptr %1982, i64 %1981
  %1984 = load float, ptr %1983, align 4
  %1985 = insertelement <8 x float> %1976, float %1984, i64 2
  %1986 = mul i64 %58, 8
  %1987 = add i64 %1986, 3
  %1988 = add i64 %88, %1987
  %1989 = icmp slt i64 %1988, %25
  %1990 = select i1 %1989, i64 %1988, i64 0
  %1991 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %1992 = getelementptr inbounds nuw float, ptr %1991, i64 %1990
  %1993 = load float, ptr %1992, align 4
  %1994 = insertelement <8 x float> %1985, float %1993, i64 3
  %1995 = mul i64 %58, 8
  %1996 = add i64 %1995, 4
  %1997 = add i64 %88, %1996
  %1998 = icmp slt i64 %1997, %25
  %1999 = select i1 %1998, i64 %1997, i64 0
  %2000 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2001 = getelementptr inbounds nuw float, ptr %2000, i64 %1999
  %2002 = load float, ptr %2001, align 4
  %2003 = insertelement <8 x float> %1994, float %2002, i64 4
  %2004 = mul i64 %58, 8
  %2005 = add i64 %2004, 5
  %2006 = add i64 %88, %2005
  %2007 = icmp slt i64 %2006, %25
  %2008 = select i1 %2007, i64 %2006, i64 0
  %2009 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2010 = getelementptr inbounds nuw float, ptr %2009, i64 %2008
  %2011 = load float, ptr %2010, align 4
  %2012 = insertelement <8 x float> %2003, float %2011, i64 5
  %2013 = mul i64 %58, 8
  %2014 = add i64 %2013, 6
  %2015 = add i64 %88, %2014
  %2016 = icmp slt i64 %2015, %25
  %2017 = select i1 %2016, i64 %2015, i64 0
  %2018 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2019 = getelementptr inbounds nuw float, ptr %2018, i64 %2017
  %2020 = load float, ptr %2019, align 4
  %2021 = insertelement <8 x float> %2012, float %2020, i64 6
  %2022 = mul i64 %58, 8
  %2023 = add i64 %2022, 7
  %2024 = add i64 %88, %2023
  %2025 = icmp slt i64 %2024, %25
  %2026 = select i1 %2025, i64 %2024, i64 0
  %2027 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2028 = getelementptr inbounds nuw float, ptr %2027, i64 %2026
  %2029 = load float, ptr %2028, align 4
  %2030 = insertelement <8 x float> %2021, float %2029, i64 7
  br label %2031

2031:                                             ; preds = %1950, %1959
  %2032 = phi <8 x float> [ %2030, %1959 ], [ %1958, %1950 ]
  br label %2033

2033:                                             ; preds = %2031
  %2034 = add i64 %89, %57
  %2035 = icmp slt i64 %2034, %26
  %2036 = select i1 %2035, i64 %2034, i64 0
  %2037 = extractelement <8 x float> %2032, i64 0
  %2038 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2039 = getelementptr inbounds nuw i8, ptr %2038, i64 %2036
  %2040 = load i8, ptr %2039, align 1
  %2041 = zext i8 %2040 to i32
  %2042 = shl i32 %2041, 23
  %2043 = bitcast i32 %2042 to float
  %2044 = fmul float %2043, %2037
  %2045 = extractelement <8 x float> %635, i64 0
  %2046 = fmul float %2045, %2044
  %2047 = call float @llvm.fabs.f32(float %2044)
  %2048 = fcmp olt float %2047, +inf
  %2049 = fcmp one float %2044, 0.000000e+00
  %2050 = and i1 %2048, %2049
  br i1 %2050, label %2051, label %2052

2051:                                             ; preds = %2033
  br label %2064

2052:                                             ; preds = %2033
  %2053 = fpext float %2045 to double
  %2054 = fpext float %2043 to double
  %2055 = fpext float %2037 to double
  %2056 = fmul double %2053, %2054
  %2057 = fmul double %2056, %2055
  %2058 = fptrunc double %2057 to float
  %2059 = fcmp oeq float %2045, 0.000000e+00
  %2060 = call float @llvm.fabs.f32(float %2037)
  %2061 = fcmp olt float %2060, +inf
  %2062 = and i1 %2059, %2061
  %2063 = select i1 %2062, float 0.000000e+00, float %2058
  br label %2064

2064:                                             ; preds = %2051, %2052
  %2065 = phi float [ %2063, %2052 ], [ %2046, %2051 ]
  br label %2066

2066:                                             ; preds = %2064
  %2067 = add i64 %89, %57
  %2068 = icmp slt i64 %2067, %26
  %2069 = select i1 %2068, i64 %2067, i64 0
  %2070 = extractelement <8 x float> %2032, i64 1
  %2071 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2072 = getelementptr inbounds nuw i8, ptr %2071, i64 %2069
  %2073 = load i8, ptr %2072, align 1
  %2074 = zext i8 %2073 to i32
  %2075 = shl i32 %2074, 23
  %2076 = bitcast i32 %2075 to float
  %2077 = fmul float %2076, %2070
  %2078 = extractelement <8 x float> %635, i64 1
  %2079 = fmul float %2078, %2077
  %2080 = call float @llvm.fabs.f32(float %2077)
  %2081 = fcmp olt float %2080, +inf
  %2082 = fcmp one float %2077, 0.000000e+00
  %2083 = and i1 %2081, %2082
  br i1 %2083, label %2084, label %2085

2084:                                             ; preds = %2066
  br label %2097

2085:                                             ; preds = %2066
  %2086 = fpext float %2078 to double
  %2087 = fpext float %2076 to double
  %2088 = fpext float %2070 to double
  %2089 = fmul double %2086, %2087
  %2090 = fmul double %2089, %2088
  %2091 = fptrunc double %2090 to float
  %2092 = fcmp oeq float %2078, 0.000000e+00
  %2093 = call float @llvm.fabs.f32(float %2070)
  %2094 = fcmp olt float %2093, +inf
  %2095 = and i1 %2092, %2094
  %2096 = select i1 %2095, float 0.000000e+00, float %2091
  br label %2097

2097:                                             ; preds = %2084, %2085
  %2098 = phi float [ %2096, %2085 ], [ %2079, %2084 ]
  br label %2099

2099:                                             ; preds = %2097
  %2100 = add i64 %89, %57
  %2101 = icmp slt i64 %2100, %26
  %2102 = select i1 %2101, i64 %2100, i64 0
  %2103 = extractelement <8 x float> %2032, i64 2
  %2104 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2105 = getelementptr inbounds nuw i8, ptr %2104, i64 %2102
  %2106 = load i8, ptr %2105, align 1
  %2107 = zext i8 %2106 to i32
  %2108 = shl i32 %2107, 23
  %2109 = bitcast i32 %2108 to float
  %2110 = fmul float %2109, %2103
  %2111 = extractelement <8 x float> %635, i64 2
  %2112 = fmul float %2111, %2110
  %2113 = call float @llvm.fabs.f32(float %2110)
  %2114 = fcmp olt float %2113, +inf
  %2115 = fcmp one float %2110, 0.000000e+00
  %2116 = and i1 %2114, %2115
  br i1 %2116, label %2117, label %2118

2117:                                             ; preds = %2099
  br label %2130

2118:                                             ; preds = %2099
  %2119 = fpext float %2111 to double
  %2120 = fpext float %2109 to double
  %2121 = fpext float %2103 to double
  %2122 = fmul double %2119, %2120
  %2123 = fmul double %2122, %2121
  %2124 = fptrunc double %2123 to float
  %2125 = fcmp oeq float %2111, 0.000000e+00
  %2126 = call float @llvm.fabs.f32(float %2103)
  %2127 = fcmp olt float %2126, +inf
  %2128 = and i1 %2125, %2127
  %2129 = select i1 %2128, float 0.000000e+00, float %2124
  br label %2130

2130:                                             ; preds = %2117, %2118
  %2131 = phi float [ %2129, %2118 ], [ %2112, %2117 ]
  br label %2132

2132:                                             ; preds = %2130
  %2133 = add i64 %89, %57
  %2134 = icmp slt i64 %2133, %26
  %2135 = select i1 %2134, i64 %2133, i64 0
  %2136 = extractelement <8 x float> %2032, i64 3
  %2137 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2138 = getelementptr inbounds nuw i8, ptr %2137, i64 %2135
  %2139 = load i8, ptr %2138, align 1
  %2140 = zext i8 %2139 to i32
  %2141 = shl i32 %2140, 23
  %2142 = bitcast i32 %2141 to float
  %2143 = fmul float %2142, %2136
  %2144 = extractelement <8 x float> %635, i64 3
  %2145 = fmul float %2144, %2143
  %2146 = call float @llvm.fabs.f32(float %2143)
  %2147 = fcmp olt float %2146, +inf
  %2148 = fcmp one float %2143, 0.000000e+00
  %2149 = and i1 %2147, %2148
  br i1 %2149, label %2150, label %2151

2150:                                             ; preds = %2132
  br label %2163

2151:                                             ; preds = %2132
  %2152 = fpext float %2144 to double
  %2153 = fpext float %2142 to double
  %2154 = fpext float %2136 to double
  %2155 = fmul double %2152, %2153
  %2156 = fmul double %2155, %2154
  %2157 = fptrunc double %2156 to float
  %2158 = fcmp oeq float %2144, 0.000000e+00
  %2159 = call float @llvm.fabs.f32(float %2136)
  %2160 = fcmp olt float %2159, +inf
  %2161 = and i1 %2158, %2160
  %2162 = select i1 %2161, float 0.000000e+00, float %2157
  br label %2163

2163:                                             ; preds = %2150, %2151
  %2164 = phi float [ %2162, %2151 ], [ %2145, %2150 ]
  br label %2165

2165:                                             ; preds = %2163
  %2166 = add i64 %89, %57
  %2167 = icmp slt i64 %2166, %26
  %2168 = select i1 %2167, i64 %2166, i64 0
  %2169 = extractelement <8 x float> %2032, i64 4
  %2170 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2171 = getelementptr inbounds nuw i8, ptr %2170, i64 %2168
  %2172 = load i8, ptr %2171, align 1
  %2173 = zext i8 %2172 to i32
  %2174 = shl i32 %2173, 23
  %2175 = bitcast i32 %2174 to float
  %2176 = fmul float %2175, %2169
  %2177 = extractelement <8 x float> %635, i64 4
  %2178 = fmul float %2177, %2176
  %2179 = call float @llvm.fabs.f32(float %2176)
  %2180 = fcmp olt float %2179, +inf
  %2181 = fcmp one float %2176, 0.000000e+00
  %2182 = and i1 %2180, %2181
  br i1 %2182, label %2183, label %2184

2183:                                             ; preds = %2165
  br label %2196

2184:                                             ; preds = %2165
  %2185 = fpext float %2177 to double
  %2186 = fpext float %2175 to double
  %2187 = fpext float %2169 to double
  %2188 = fmul double %2185, %2186
  %2189 = fmul double %2188, %2187
  %2190 = fptrunc double %2189 to float
  %2191 = fcmp oeq float %2177, 0.000000e+00
  %2192 = call float @llvm.fabs.f32(float %2169)
  %2193 = fcmp olt float %2192, +inf
  %2194 = and i1 %2191, %2193
  %2195 = select i1 %2194, float 0.000000e+00, float %2190
  br label %2196

2196:                                             ; preds = %2183, %2184
  %2197 = phi float [ %2195, %2184 ], [ %2178, %2183 ]
  br label %2198

2198:                                             ; preds = %2196
  %2199 = add i64 %89, %57
  %2200 = icmp slt i64 %2199, %26
  %2201 = select i1 %2200, i64 %2199, i64 0
  %2202 = extractelement <8 x float> %2032, i64 5
  %2203 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2204 = getelementptr inbounds nuw i8, ptr %2203, i64 %2201
  %2205 = load i8, ptr %2204, align 1
  %2206 = zext i8 %2205 to i32
  %2207 = shl i32 %2206, 23
  %2208 = bitcast i32 %2207 to float
  %2209 = fmul float %2208, %2202
  %2210 = extractelement <8 x float> %635, i64 5
  %2211 = fmul float %2210, %2209
  %2212 = call float @llvm.fabs.f32(float %2209)
  %2213 = fcmp olt float %2212, +inf
  %2214 = fcmp one float %2209, 0.000000e+00
  %2215 = and i1 %2213, %2214
  br i1 %2215, label %2216, label %2217

2216:                                             ; preds = %2198
  br label %2229

2217:                                             ; preds = %2198
  %2218 = fpext float %2210 to double
  %2219 = fpext float %2208 to double
  %2220 = fpext float %2202 to double
  %2221 = fmul double %2218, %2219
  %2222 = fmul double %2221, %2220
  %2223 = fptrunc double %2222 to float
  %2224 = fcmp oeq float %2210, 0.000000e+00
  %2225 = call float @llvm.fabs.f32(float %2202)
  %2226 = fcmp olt float %2225, +inf
  %2227 = and i1 %2224, %2226
  %2228 = select i1 %2227, float 0.000000e+00, float %2223
  br label %2229

2229:                                             ; preds = %2216, %2217
  %2230 = phi float [ %2228, %2217 ], [ %2211, %2216 ]
  br label %2231

2231:                                             ; preds = %2229
  %2232 = add i64 %89, %57
  %2233 = icmp slt i64 %2232, %26
  %2234 = select i1 %2233, i64 %2232, i64 0
  %2235 = extractelement <8 x float> %2032, i64 6
  %2236 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2237 = getelementptr inbounds nuw i8, ptr %2236, i64 %2234
  %2238 = load i8, ptr %2237, align 1
  %2239 = zext i8 %2238 to i32
  %2240 = shl i32 %2239, 23
  %2241 = bitcast i32 %2240 to float
  %2242 = fmul float %2241, %2235
  %2243 = extractelement <8 x float> %635, i64 6
  %2244 = fmul float %2243, %2242
  %2245 = call float @llvm.fabs.f32(float %2242)
  %2246 = fcmp olt float %2245, +inf
  %2247 = fcmp one float %2242, 0.000000e+00
  %2248 = and i1 %2246, %2247
  br i1 %2248, label %2249, label %2250

2249:                                             ; preds = %2231
  br label %2262

2250:                                             ; preds = %2231
  %2251 = fpext float %2243 to double
  %2252 = fpext float %2241 to double
  %2253 = fpext float %2235 to double
  %2254 = fmul double %2251, %2252
  %2255 = fmul double %2254, %2253
  %2256 = fptrunc double %2255 to float
  %2257 = fcmp oeq float %2243, 0.000000e+00
  %2258 = call float @llvm.fabs.f32(float %2235)
  %2259 = fcmp olt float %2258, +inf
  %2260 = and i1 %2257, %2259
  %2261 = select i1 %2260, float 0.000000e+00, float %2256
  br label %2262

2262:                                             ; preds = %2249, %2250
  %2263 = phi float [ %2261, %2250 ], [ %2244, %2249 ]
  br label %2264

2264:                                             ; preds = %2262
  %2265 = add i64 %89, %57
  %2266 = icmp slt i64 %2265, %26
  %2267 = select i1 %2266, i64 %2265, i64 0
  %2268 = extractelement <8 x float> %2032, i64 7
  %2269 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2270 = getelementptr inbounds nuw i8, ptr %2269, i64 %2267
  %2271 = load i8, ptr %2270, align 1
  %2272 = zext i8 %2271 to i32
  %2273 = shl i32 %2272, 23
  %2274 = bitcast i32 %2273 to float
  %2275 = fmul float %2274, %2268
  %2276 = extractelement <8 x float> %635, i64 7
  %2277 = fmul float %2276, %2275
  %2278 = call float @llvm.fabs.f32(float %2275)
  %2279 = fcmp olt float %2278, +inf
  %2280 = fcmp one float %2275, 0.000000e+00
  %2281 = and i1 %2279, %2280
  br i1 %2281, label %2282, label %2283

2282:                                             ; preds = %2264
  br label %2295

2283:                                             ; preds = %2264
  %2284 = fpext float %2276 to double
  %2285 = fpext float %2274 to double
  %2286 = fpext float %2268 to double
  %2287 = fmul double %2284, %2285
  %2288 = fmul double %2287, %2286
  %2289 = fptrunc double %2288 to float
  %2290 = fcmp oeq float %2276, 0.000000e+00
  %2291 = call float @llvm.fabs.f32(float %2268)
  %2292 = fcmp olt float %2291, +inf
  %2293 = and i1 %2290, %2292
  %2294 = select i1 %2293, float 0.000000e+00, float %2289
  br label %2295

2295:                                             ; preds = %2282, %2283
  %2296 = phi float [ %2294, %2283 ], [ %2277, %2282 ]
  br label %2297

2297:                                             ; preds = %2295
  %2298 = mul i64 %58, 8
  %2299 = add i64 %88, %2298
  %2300 = add i64 %89, %57
  %2301 = mul i64 %2299, %26
  %2302 = add i64 %2301, %2300
  %2303 = fptrunc float %2065 to bfloat
  %2304 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2305 = getelementptr inbounds nuw bfloat, ptr %2304, i64 %2302
  store bfloat %2303, ptr %2305, align 2
  %2306 = mul i64 %58, 8
  %2307 = add i64 %2306, 1
  %2308 = add i64 %88, %2307
  %2309 = add i64 %89, %57
  %2310 = mul i64 %2308, %26
  %2311 = add i64 %2310, %2309
  %2312 = fptrunc float %2098 to bfloat
  %2313 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2314 = getelementptr inbounds nuw bfloat, ptr %2313, i64 %2311
  store bfloat %2312, ptr %2314, align 2
  %2315 = mul i64 %58, 8
  %2316 = add i64 %2315, 2
  %2317 = add i64 %88, %2316
  %2318 = add i64 %89, %57
  %2319 = mul i64 %2317, %26
  %2320 = add i64 %2319, %2318
  %2321 = fptrunc float %2131 to bfloat
  %2322 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2323 = getelementptr inbounds nuw bfloat, ptr %2322, i64 %2320
  store bfloat %2321, ptr %2323, align 2
  %2324 = mul i64 %58, 8
  %2325 = add i64 %2324, 3
  %2326 = add i64 %88, %2325
  %2327 = add i64 %89, %57
  %2328 = mul i64 %2326, %26
  %2329 = add i64 %2328, %2327
  %2330 = fptrunc float %2164 to bfloat
  %2331 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2332 = getelementptr inbounds nuw bfloat, ptr %2331, i64 %2329
  store bfloat %2330, ptr %2332, align 2
  %2333 = mul i64 %58, 8
  %2334 = add i64 %2333, 4
  %2335 = add i64 %88, %2334
  %2336 = add i64 %89, %57
  %2337 = mul i64 %2335, %26
  %2338 = add i64 %2337, %2336
  %2339 = fptrunc float %2197 to bfloat
  %2340 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2341 = getelementptr inbounds nuw bfloat, ptr %2340, i64 %2338
  store bfloat %2339, ptr %2341, align 2
  %2342 = mul i64 %58, 8
  %2343 = add i64 %2342, 5
  %2344 = add i64 %88, %2343
  %2345 = add i64 %89, %57
  %2346 = mul i64 %2344, %26
  %2347 = add i64 %2346, %2345
  %2348 = fptrunc float %2230 to bfloat
  %2349 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2350 = getelementptr inbounds nuw bfloat, ptr %2349, i64 %2347
  store bfloat %2348, ptr %2350, align 2
  %2351 = mul i64 %58, 8
  %2352 = add i64 %2351, 6
  %2353 = add i64 %88, %2352
  %2354 = add i64 %89, %57
  %2355 = mul i64 %2353, %26
  %2356 = add i64 %2355, %2354
  %2357 = fptrunc float %2263 to bfloat
  %2358 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2359 = getelementptr inbounds nuw bfloat, ptr %2358, i64 %2356
  store bfloat %2357, ptr %2359, align 2
  %2360 = mul i64 %58, 8
  %2361 = add i64 %2360, 7
  %2362 = add i64 %88, %2361
  %2363 = add i64 %89, %57
  %2364 = mul i64 %2362, %26
  %2365 = add i64 %2364, %2363
  %2366 = fptrunc float %2296 to bfloat
  %2367 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2368 = getelementptr inbounds nuw bfloat, ptr %2367, i64 %2365
  store bfloat %2366, ptr %2368, align 2
  %2369 = mul i64 %58, 8
  %2370 = add i64 %82, %2369
  %2371 = add i64 %91, %57
  %2372 = add i64 %2370, 7
  %2373 = icmp ult i64 %2371, %26
  %2374 = icmp ult i64 %2372, %25
  %2375 = and i1 %2374, %2373
  %2376 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2377 = ptrtoint ptr %2376 to i64
  %2378 = mul i64 %2370, 4
  %2379 = add i64 %2377, %2378
  %2380 = urem i64 %2379, 16
  %2381 = icmp eq i64 %2380, 0
  %2382 = and i1 %2375, %2381
  br i1 %2382, label %2383, label %2392

2383:                                             ; preds = %2297
  %2384 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2385 = getelementptr float, ptr %2384, i64 %2370
  %2386 = load <4 x float>, ptr %2385, align 16
  %2387 = add i64 %2370, 4
  %2388 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2389 = getelementptr float, ptr %2388, i64 %2387
  %2390 = load <4 x float>, ptr %2389, align 16
  %2391 = shufflevector <4 x float> %2386, <4 x float> %2390, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2464

2392:                                             ; preds = %2297
  %2393 = mul i64 %58, 8
  %2394 = add i64 %82, %2393
  %2395 = icmp slt i64 %2394, %25
  %2396 = select i1 %2395, i64 %2394, i64 0
  %2397 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2398 = getelementptr inbounds nuw float, ptr %2397, i64 %2396
  %2399 = load float, ptr %2398, align 4
  %2400 = insertelement <8 x float> zeroinitializer, float %2399, i64 0
  %2401 = mul i64 %58, 8
  %2402 = add i64 %2401, 1
  %2403 = add i64 %82, %2402
  %2404 = icmp slt i64 %2403, %25
  %2405 = select i1 %2404, i64 %2403, i64 0
  %2406 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2407 = getelementptr inbounds nuw float, ptr %2406, i64 %2405
  %2408 = load float, ptr %2407, align 4
  %2409 = insertelement <8 x float> %2400, float %2408, i64 1
  %2410 = mul i64 %58, 8
  %2411 = add i64 %2410, 2
  %2412 = add i64 %82, %2411
  %2413 = icmp slt i64 %2412, %25
  %2414 = select i1 %2413, i64 %2412, i64 0
  %2415 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2416 = getelementptr inbounds nuw float, ptr %2415, i64 %2414
  %2417 = load float, ptr %2416, align 4
  %2418 = insertelement <8 x float> %2409, float %2417, i64 2
  %2419 = mul i64 %58, 8
  %2420 = add i64 %2419, 3
  %2421 = add i64 %82, %2420
  %2422 = icmp slt i64 %2421, %25
  %2423 = select i1 %2422, i64 %2421, i64 0
  %2424 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2425 = getelementptr inbounds nuw float, ptr %2424, i64 %2423
  %2426 = load float, ptr %2425, align 4
  %2427 = insertelement <8 x float> %2418, float %2426, i64 3
  %2428 = mul i64 %58, 8
  %2429 = add i64 %2428, 4
  %2430 = add i64 %82, %2429
  %2431 = icmp slt i64 %2430, %25
  %2432 = select i1 %2431, i64 %2430, i64 0
  %2433 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2434 = getelementptr inbounds nuw float, ptr %2433, i64 %2432
  %2435 = load float, ptr %2434, align 4
  %2436 = insertelement <8 x float> %2427, float %2435, i64 4
  %2437 = mul i64 %58, 8
  %2438 = add i64 %2437, 5
  %2439 = add i64 %82, %2438
  %2440 = icmp slt i64 %2439, %25
  %2441 = select i1 %2440, i64 %2439, i64 0
  %2442 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2443 = getelementptr inbounds nuw float, ptr %2442, i64 %2441
  %2444 = load float, ptr %2443, align 4
  %2445 = insertelement <8 x float> %2436, float %2444, i64 5
  %2446 = mul i64 %58, 8
  %2447 = add i64 %2446, 6
  %2448 = add i64 %82, %2447
  %2449 = icmp slt i64 %2448, %25
  %2450 = select i1 %2449, i64 %2448, i64 0
  %2451 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2452 = getelementptr inbounds nuw float, ptr %2451, i64 %2450
  %2453 = load float, ptr %2452, align 4
  %2454 = insertelement <8 x float> %2445, float %2453, i64 6
  %2455 = mul i64 %58, 8
  %2456 = add i64 %2455, 7
  %2457 = add i64 %82, %2456
  %2458 = icmp slt i64 %2457, %25
  %2459 = select i1 %2458, i64 %2457, i64 0
  %2460 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2461 = getelementptr inbounds nuw float, ptr %2460, i64 %2459
  %2462 = load float, ptr %2461, align 4
  %2463 = insertelement <8 x float> %2454, float %2462, i64 7
  br label %2464

2464:                                             ; preds = %2383, %2392
  %2465 = phi <8 x float> [ %2463, %2392 ], [ %2391, %2383 ]
  br label %2466

2466:                                             ; preds = %2464
  %2467 = add i64 %91, %57
  %2468 = icmp slt i64 %2467, %26
  %2469 = select i1 %2468, i64 %2467, i64 0
  %2470 = extractelement <8 x float> %2465, i64 0
  %2471 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2472 = getelementptr inbounds nuw i8, ptr %2471, i64 %2469
  %2473 = load i8, ptr %2472, align 1
  %2474 = zext i8 %2473 to i32
  %2475 = shl i32 %2474, 23
  %2476 = bitcast i32 %2475 to float
  %2477 = fmul float %2476, %2470
  %2478 = extractelement <8 x float> %630, i64 0
  %2479 = fmul float %2478, %2477
  %2480 = call float @llvm.fabs.f32(float %2477)
  %2481 = fcmp olt float %2480, +inf
  %2482 = fcmp one float %2477, 0.000000e+00
  %2483 = and i1 %2481, %2482
  br i1 %2483, label %2484, label %2485

2484:                                             ; preds = %2466
  br label %2497

2485:                                             ; preds = %2466
  %2486 = fpext float %2478 to double
  %2487 = fpext float %2476 to double
  %2488 = fpext float %2470 to double
  %2489 = fmul double %2486, %2487
  %2490 = fmul double %2489, %2488
  %2491 = fptrunc double %2490 to float
  %2492 = fcmp oeq float %2478, 0.000000e+00
  %2493 = call float @llvm.fabs.f32(float %2470)
  %2494 = fcmp olt float %2493, +inf
  %2495 = and i1 %2492, %2494
  %2496 = select i1 %2495, float 0.000000e+00, float %2491
  br label %2497

2497:                                             ; preds = %2484, %2485
  %2498 = phi float [ %2496, %2485 ], [ %2479, %2484 ]
  br label %2499

2499:                                             ; preds = %2497
  %2500 = add i64 %91, %57
  %2501 = icmp slt i64 %2500, %26
  %2502 = select i1 %2501, i64 %2500, i64 0
  %2503 = extractelement <8 x float> %2465, i64 1
  %2504 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2505 = getelementptr inbounds nuw i8, ptr %2504, i64 %2502
  %2506 = load i8, ptr %2505, align 1
  %2507 = zext i8 %2506 to i32
  %2508 = shl i32 %2507, 23
  %2509 = bitcast i32 %2508 to float
  %2510 = fmul float %2509, %2503
  %2511 = extractelement <8 x float> %630, i64 1
  %2512 = fmul float %2511, %2510
  %2513 = call float @llvm.fabs.f32(float %2510)
  %2514 = fcmp olt float %2513, +inf
  %2515 = fcmp one float %2510, 0.000000e+00
  %2516 = and i1 %2514, %2515
  br i1 %2516, label %2517, label %2518

2517:                                             ; preds = %2499
  br label %2530

2518:                                             ; preds = %2499
  %2519 = fpext float %2511 to double
  %2520 = fpext float %2509 to double
  %2521 = fpext float %2503 to double
  %2522 = fmul double %2519, %2520
  %2523 = fmul double %2522, %2521
  %2524 = fptrunc double %2523 to float
  %2525 = fcmp oeq float %2511, 0.000000e+00
  %2526 = call float @llvm.fabs.f32(float %2503)
  %2527 = fcmp olt float %2526, +inf
  %2528 = and i1 %2525, %2527
  %2529 = select i1 %2528, float 0.000000e+00, float %2524
  br label %2530

2530:                                             ; preds = %2517, %2518
  %2531 = phi float [ %2529, %2518 ], [ %2512, %2517 ]
  br label %2532

2532:                                             ; preds = %2530
  %2533 = add i64 %91, %57
  %2534 = icmp slt i64 %2533, %26
  %2535 = select i1 %2534, i64 %2533, i64 0
  %2536 = extractelement <8 x float> %2465, i64 2
  %2537 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2538 = getelementptr inbounds nuw i8, ptr %2537, i64 %2535
  %2539 = load i8, ptr %2538, align 1
  %2540 = zext i8 %2539 to i32
  %2541 = shl i32 %2540, 23
  %2542 = bitcast i32 %2541 to float
  %2543 = fmul float %2542, %2536
  %2544 = extractelement <8 x float> %630, i64 2
  %2545 = fmul float %2544, %2543
  %2546 = call float @llvm.fabs.f32(float %2543)
  %2547 = fcmp olt float %2546, +inf
  %2548 = fcmp one float %2543, 0.000000e+00
  %2549 = and i1 %2547, %2548
  br i1 %2549, label %2550, label %2551

2550:                                             ; preds = %2532
  br label %2563

2551:                                             ; preds = %2532
  %2552 = fpext float %2544 to double
  %2553 = fpext float %2542 to double
  %2554 = fpext float %2536 to double
  %2555 = fmul double %2552, %2553
  %2556 = fmul double %2555, %2554
  %2557 = fptrunc double %2556 to float
  %2558 = fcmp oeq float %2544, 0.000000e+00
  %2559 = call float @llvm.fabs.f32(float %2536)
  %2560 = fcmp olt float %2559, +inf
  %2561 = and i1 %2558, %2560
  %2562 = select i1 %2561, float 0.000000e+00, float %2557
  br label %2563

2563:                                             ; preds = %2550, %2551
  %2564 = phi float [ %2562, %2551 ], [ %2545, %2550 ]
  br label %2565

2565:                                             ; preds = %2563
  %2566 = add i64 %91, %57
  %2567 = icmp slt i64 %2566, %26
  %2568 = select i1 %2567, i64 %2566, i64 0
  %2569 = extractelement <8 x float> %2465, i64 3
  %2570 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2571 = getelementptr inbounds nuw i8, ptr %2570, i64 %2568
  %2572 = load i8, ptr %2571, align 1
  %2573 = zext i8 %2572 to i32
  %2574 = shl i32 %2573, 23
  %2575 = bitcast i32 %2574 to float
  %2576 = fmul float %2575, %2569
  %2577 = extractelement <8 x float> %630, i64 3
  %2578 = fmul float %2577, %2576
  %2579 = call float @llvm.fabs.f32(float %2576)
  %2580 = fcmp olt float %2579, +inf
  %2581 = fcmp one float %2576, 0.000000e+00
  %2582 = and i1 %2580, %2581
  br i1 %2582, label %2583, label %2584

2583:                                             ; preds = %2565
  br label %2596

2584:                                             ; preds = %2565
  %2585 = fpext float %2577 to double
  %2586 = fpext float %2575 to double
  %2587 = fpext float %2569 to double
  %2588 = fmul double %2585, %2586
  %2589 = fmul double %2588, %2587
  %2590 = fptrunc double %2589 to float
  %2591 = fcmp oeq float %2577, 0.000000e+00
  %2592 = call float @llvm.fabs.f32(float %2569)
  %2593 = fcmp olt float %2592, +inf
  %2594 = and i1 %2591, %2593
  %2595 = select i1 %2594, float 0.000000e+00, float %2590
  br label %2596

2596:                                             ; preds = %2583, %2584
  %2597 = phi float [ %2595, %2584 ], [ %2578, %2583 ]
  br label %2598

2598:                                             ; preds = %2596
  %2599 = add i64 %91, %57
  %2600 = icmp slt i64 %2599, %26
  %2601 = select i1 %2600, i64 %2599, i64 0
  %2602 = extractelement <8 x float> %2465, i64 4
  %2603 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2604 = getelementptr inbounds nuw i8, ptr %2603, i64 %2601
  %2605 = load i8, ptr %2604, align 1
  %2606 = zext i8 %2605 to i32
  %2607 = shl i32 %2606, 23
  %2608 = bitcast i32 %2607 to float
  %2609 = fmul float %2608, %2602
  %2610 = extractelement <8 x float> %630, i64 4
  %2611 = fmul float %2610, %2609
  %2612 = call float @llvm.fabs.f32(float %2609)
  %2613 = fcmp olt float %2612, +inf
  %2614 = fcmp one float %2609, 0.000000e+00
  %2615 = and i1 %2613, %2614
  br i1 %2615, label %2616, label %2617

2616:                                             ; preds = %2598
  br label %2629

2617:                                             ; preds = %2598
  %2618 = fpext float %2610 to double
  %2619 = fpext float %2608 to double
  %2620 = fpext float %2602 to double
  %2621 = fmul double %2618, %2619
  %2622 = fmul double %2621, %2620
  %2623 = fptrunc double %2622 to float
  %2624 = fcmp oeq float %2610, 0.000000e+00
  %2625 = call float @llvm.fabs.f32(float %2602)
  %2626 = fcmp olt float %2625, +inf
  %2627 = and i1 %2624, %2626
  %2628 = select i1 %2627, float 0.000000e+00, float %2623
  br label %2629

2629:                                             ; preds = %2616, %2617
  %2630 = phi float [ %2628, %2617 ], [ %2611, %2616 ]
  br label %2631

2631:                                             ; preds = %2629
  %2632 = add i64 %91, %57
  %2633 = icmp slt i64 %2632, %26
  %2634 = select i1 %2633, i64 %2632, i64 0
  %2635 = extractelement <8 x float> %2465, i64 5
  %2636 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2637 = getelementptr inbounds nuw i8, ptr %2636, i64 %2634
  %2638 = load i8, ptr %2637, align 1
  %2639 = zext i8 %2638 to i32
  %2640 = shl i32 %2639, 23
  %2641 = bitcast i32 %2640 to float
  %2642 = fmul float %2641, %2635
  %2643 = extractelement <8 x float> %630, i64 5
  %2644 = fmul float %2643, %2642
  %2645 = call float @llvm.fabs.f32(float %2642)
  %2646 = fcmp olt float %2645, +inf
  %2647 = fcmp one float %2642, 0.000000e+00
  %2648 = and i1 %2646, %2647
  br i1 %2648, label %2649, label %2650

2649:                                             ; preds = %2631
  br label %2662

2650:                                             ; preds = %2631
  %2651 = fpext float %2643 to double
  %2652 = fpext float %2641 to double
  %2653 = fpext float %2635 to double
  %2654 = fmul double %2651, %2652
  %2655 = fmul double %2654, %2653
  %2656 = fptrunc double %2655 to float
  %2657 = fcmp oeq float %2643, 0.000000e+00
  %2658 = call float @llvm.fabs.f32(float %2635)
  %2659 = fcmp olt float %2658, +inf
  %2660 = and i1 %2657, %2659
  %2661 = select i1 %2660, float 0.000000e+00, float %2656
  br label %2662

2662:                                             ; preds = %2649, %2650
  %2663 = phi float [ %2661, %2650 ], [ %2644, %2649 ]
  br label %2664

2664:                                             ; preds = %2662
  %2665 = add i64 %91, %57
  %2666 = icmp slt i64 %2665, %26
  %2667 = select i1 %2666, i64 %2665, i64 0
  %2668 = extractelement <8 x float> %2465, i64 6
  %2669 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2670 = getelementptr inbounds nuw i8, ptr %2669, i64 %2667
  %2671 = load i8, ptr %2670, align 1
  %2672 = zext i8 %2671 to i32
  %2673 = shl i32 %2672, 23
  %2674 = bitcast i32 %2673 to float
  %2675 = fmul float %2674, %2668
  %2676 = extractelement <8 x float> %630, i64 6
  %2677 = fmul float %2676, %2675
  %2678 = call float @llvm.fabs.f32(float %2675)
  %2679 = fcmp olt float %2678, +inf
  %2680 = fcmp one float %2675, 0.000000e+00
  %2681 = and i1 %2679, %2680
  br i1 %2681, label %2682, label %2683

2682:                                             ; preds = %2664
  br label %2695

2683:                                             ; preds = %2664
  %2684 = fpext float %2676 to double
  %2685 = fpext float %2674 to double
  %2686 = fpext float %2668 to double
  %2687 = fmul double %2684, %2685
  %2688 = fmul double %2687, %2686
  %2689 = fptrunc double %2688 to float
  %2690 = fcmp oeq float %2676, 0.000000e+00
  %2691 = call float @llvm.fabs.f32(float %2668)
  %2692 = fcmp olt float %2691, +inf
  %2693 = and i1 %2690, %2692
  %2694 = select i1 %2693, float 0.000000e+00, float %2689
  br label %2695

2695:                                             ; preds = %2682, %2683
  %2696 = phi float [ %2694, %2683 ], [ %2677, %2682 ]
  br label %2697

2697:                                             ; preds = %2695
  %2698 = add i64 %91, %57
  %2699 = icmp slt i64 %2698, %26
  %2700 = select i1 %2699, i64 %2698, i64 0
  %2701 = extractelement <8 x float> %2465, i64 7
  %2702 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2703 = getelementptr inbounds nuw i8, ptr %2702, i64 %2700
  %2704 = load i8, ptr %2703, align 1
  %2705 = zext i8 %2704 to i32
  %2706 = shl i32 %2705, 23
  %2707 = bitcast i32 %2706 to float
  %2708 = fmul float %2707, %2701
  %2709 = extractelement <8 x float> %630, i64 7
  %2710 = fmul float %2709, %2708
  %2711 = call float @llvm.fabs.f32(float %2708)
  %2712 = fcmp olt float %2711, +inf
  %2713 = fcmp one float %2708, 0.000000e+00
  %2714 = and i1 %2712, %2713
  br i1 %2714, label %2715, label %2716

2715:                                             ; preds = %2697
  br label %2728

2716:                                             ; preds = %2697
  %2717 = fpext float %2709 to double
  %2718 = fpext float %2707 to double
  %2719 = fpext float %2701 to double
  %2720 = fmul double %2717, %2718
  %2721 = fmul double %2720, %2719
  %2722 = fptrunc double %2721 to float
  %2723 = fcmp oeq float %2709, 0.000000e+00
  %2724 = call float @llvm.fabs.f32(float %2701)
  %2725 = fcmp olt float %2724, +inf
  %2726 = and i1 %2723, %2725
  %2727 = select i1 %2726, float 0.000000e+00, float %2722
  br label %2728

2728:                                             ; preds = %2715, %2716
  %2729 = phi float [ %2727, %2716 ], [ %2710, %2715 ]
  br label %2730

2730:                                             ; preds = %2728
  %2731 = mul i64 %58, 8
  %2732 = add i64 %82, %2731
  %2733 = add i64 %91, %57
  %2734 = mul i64 %2732, %26
  %2735 = add i64 %2734, %2733
  %2736 = fptrunc float %2498 to bfloat
  %2737 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2738 = getelementptr inbounds nuw bfloat, ptr %2737, i64 %2735
  store bfloat %2736, ptr %2738, align 2
  %2739 = mul i64 %58, 8
  %2740 = add i64 %2739, 1
  %2741 = add i64 %82, %2740
  %2742 = add i64 %91, %57
  %2743 = mul i64 %2741, %26
  %2744 = add i64 %2743, %2742
  %2745 = fptrunc float %2531 to bfloat
  %2746 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2747 = getelementptr inbounds nuw bfloat, ptr %2746, i64 %2744
  store bfloat %2745, ptr %2747, align 2
  %2748 = mul i64 %58, 8
  %2749 = add i64 %2748, 2
  %2750 = add i64 %82, %2749
  %2751 = add i64 %91, %57
  %2752 = mul i64 %2750, %26
  %2753 = add i64 %2752, %2751
  %2754 = fptrunc float %2564 to bfloat
  %2755 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2756 = getelementptr inbounds nuw bfloat, ptr %2755, i64 %2753
  store bfloat %2754, ptr %2756, align 2
  %2757 = mul i64 %58, 8
  %2758 = add i64 %2757, 3
  %2759 = add i64 %82, %2758
  %2760 = add i64 %91, %57
  %2761 = mul i64 %2759, %26
  %2762 = add i64 %2761, %2760
  %2763 = fptrunc float %2597 to bfloat
  %2764 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2765 = getelementptr inbounds nuw bfloat, ptr %2764, i64 %2762
  store bfloat %2763, ptr %2765, align 2
  %2766 = mul i64 %58, 8
  %2767 = add i64 %2766, 4
  %2768 = add i64 %82, %2767
  %2769 = add i64 %91, %57
  %2770 = mul i64 %2768, %26
  %2771 = add i64 %2770, %2769
  %2772 = fptrunc float %2630 to bfloat
  %2773 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2774 = getelementptr inbounds nuw bfloat, ptr %2773, i64 %2771
  store bfloat %2772, ptr %2774, align 2
  %2775 = mul i64 %58, 8
  %2776 = add i64 %2775, 5
  %2777 = add i64 %82, %2776
  %2778 = add i64 %91, %57
  %2779 = mul i64 %2777, %26
  %2780 = add i64 %2779, %2778
  %2781 = fptrunc float %2663 to bfloat
  %2782 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2783 = getelementptr inbounds nuw bfloat, ptr %2782, i64 %2780
  store bfloat %2781, ptr %2783, align 2
  %2784 = mul i64 %58, 8
  %2785 = add i64 %2784, 6
  %2786 = add i64 %82, %2785
  %2787 = add i64 %91, %57
  %2788 = mul i64 %2786, %26
  %2789 = add i64 %2788, %2787
  %2790 = fptrunc float %2696 to bfloat
  %2791 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2792 = getelementptr inbounds nuw bfloat, ptr %2791, i64 %2789
  store bfloat %2790, ptr %2792, align 2
  %2793 = mul i64 %58, 8
  %2794 = add i64 %2793, 7
  %2795 = add i64 %82, %2794
  %2796 = add i64 %91, %57
  %2797 = mul i64 %2795, %26
  %2798 = add i64 %2797, %2796
  %2799 = fptrunc float %2729 to bfloat
  %2800 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %2801 = getelementptr inbounds nuw bfloat, ptr %2800, i64 %2798
  store bfloat %2799, ptr %2801, align 2
  %2802 = mul i64 %58, 8
  %2803 = add i64 %84, %2802
  %2804 = add i64 %91, %57
  %2805 = add i64 %2803, 7
  %2806 = icmp ult i64 %2804, %26
  %2807 = icmp ult i64 %2805, %25
  %2808 = and i1 %2807, %2806
  %2809 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2810 = ptrtoint ptr %2809 to i64
  %2811 = mul i64 %2803, 4
  %2812 = add i64 %2810, %2811
  %2813 = urem i64 %2812, 16
  %2814 = icmp eq i64 %2813, 0
  %2815 = and i1 %2808, %2814
  br i1 %2815, label %2816, label %2825

2816:                                             ; preds = %2730
  %2817 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2818 = getelementptr float, ptr %2817, i64 %2803
  %2819 = load <4 x float>, ptr %2818, align 16
  %2820 = add i64 %2803, 4
  %2821 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2822 = getelementptr float, ptr %2821, i64 %2820
  %2823 = load <4 x float>, ptr %2822, align 16
  %2824 = shufflevector <4 x float> %2819, <4 x float> %2823, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %2897

2825:                                             ; preds = %2730
  %2826 = mul i64 %58, 8
  %2827 = add i64 %84, %2826
  %2828 = icmp slt i64 %2827, %25
  %2829 = select i1 %2828, i64 %2827, i64 0
  %2830 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2831 = getelementptr inbounds nuw float, ptr %2830, i64 %2829
  %2832 = load float, ptr %2831, align 4
  %2833 = insertelement <8 x float> zeroinitializer, float %2832, i64 0
  %2834 = mul i64 %58, 8
  %2835 = add i64 %2834, 1
  %2836 = add i64 %84, %2835
  %2837 = icmp slt i64 %2836, %25
  %2838 = select i1 %2837, i64 %2836, i64 0
  %2839 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2840 = getelementptr inbounds nuw float, ptr %2839, i64 %2838
  %2841 = load float, ptr %2840, align 4
  %2842 = insertelement <8 x float> %2833, float %2841, i64 1
  %2843 = mul i64 %58, 8
  %2844 = add i64 %2843, 2
  %2845 = add i64 %84, %2844
  %2846 = icmp slt i64 %2845, %25
  %2847 = select i1 %2846, i64 %2845, i64 0
  %2848 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2849 = getelementptr inbounds nuw float, ptr %2848, i64 %2847
  %2850 = load float, ptr %2849, align 4
  %2851 = insertelement <8 x float> %2842, float %2850, i64 2
  %2852 = mul i64 %58, 8
  %2853 = add i64 %2852, 3
  %2854 = add i64 %84, %2853
  %2855 = icmp slt i64 %2854, %25
  %2856 = select i1 %2855, i64 %2854, i64 0
  %2857 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2858 = getelementptr inbounds nuw float, ptr %2857, i64 %2856
  %2859 = load float, ptr %2858, align 4
  %2860 = insertelement <8 x float> %2851, float %2859, i64 3
  %2861 = mul i64 %58, 8
  %2862 = add i64 %2861, 4
  %2863 = add i64 %84, %2862
  %2864 = icmp slt i64 %2863, %25
  %2865 = select i1 %2864, i64 %2863, i64 0
  %2866 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2867 = getelementptr inbounds nuw float, ptr %2866, i64 %2865
  %2868 = load float, ptr %2867, align 4
  %2869 = insertelement <8 x float> %2860, float %2868, i64 4
  %2870 = mul i64 %58, 8
  %2871 = add i64 %2870, 5
  %2872 = add i64 %84, %2871
  %2873 = icmp slt i64 %2872, %25
  %2874 = select i1 %2873, i64 %2872, i64 0
  %2875 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2876 = getelementptr inbounds nuw float, ptr %2875, i64 %2874
  %2877 = load float, ptr %2876, align 4
  %2878 = insertelement <8 x float> %2869, float %2877, i64 5
  %2879 = mul i64 %58, 8
  %2880 = add i64 %2879, 6
  %2881 = add i64 %84, %2880
  %2882 = icmp slt i64 %2881, %25
  %2883 = select i1 %2882, i64 %2881, i64 0
  %2884 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2885 = getelementptr inbounds nuw float, ptr %2884, i64 %2883
  %2886 = load float, ptr %2885, align 4
  %2887 = insertelement <8 x float> %2878, float %2886, i64 6
  %2888 = mul i64 %58, 8
  %2889 = add i64 %2888, 7
  %2890 = add i64 %84, %2889
  %2891 = icmp slt i64 %2890, %25
  %2892 = select i1 %2891, i64 %2890, i64 0
  %2893 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %2894 = getelementptr inbounds nuw float, ptr %2893, i64 %2892
  %2895 = load float, ptr %2894, align 4
  %2896 = insertelement <8 x float> %2887, float %2895, i64 7
  br label %2897

2897:                                             ; preds = %2816, %2825
  %2898 = phi <8 x float> [ %2896, %2825 ], [ %2824, %2816 ]
  br label %2899

2899:                                             ; preds = %2897
  %2900 = add i64 %91, %57
  %2901 = icmp slt i64 %2900, %26
  %2902 = select i1 %2901, i64 %2900, i64 0
  %2903 = extractelement <8 x float> %2898, i64 0
  %2904 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2905 = getelementptr inbounds nuw i8, ptr %2904, i64 %2902
  %2906 = load i8, ptr %2905, align 1
  %2907 = zext i8 %2906 to i32
  %2908 = shl i32 %2907, 23
  %2909 = bitcast i32 %2908 to float
  %2910 = fmul float %2909, %2903
  %2911 = extractelement <8 x float> %632, i64 0
  %2912 = fmul float %2911, %2910
  %2913 = call float @llvm.fabs.f32(float %2910)
  %2914 = fcmp olt float %2913, +inf
  %2915 = fcmp one float %2910, 0.000000e+00
  %2916 = and i1 %2914, %2915
  br i1 %2916, label %2917, label %2918

2917:                                             ; preds = %2899
  br label %2930

2918:                                             ; preds = %2899
  %2919 = fpext float %2911 to double
  %2920 = fpext float %2909 to double
  %2921 = fpext float %2903 to double
  %2922 = fmul double %2919, %2920
  %2923 = fmul double %2922, %2921
  %2924 = fptrunc double %2923 to float
  %2925 = fcmp oeq float %2911, 0.000000e+00
  %2926 = call float @llvm.fabs.f32(float %2903)
  %2927 = fcmp olt float %2926, +inf
  %2928 = and i1 %2925, %2927
  %2929 = select i1 %2928, float 0.000000e+00, float %2924
  br label %2930

2930:                                             ; preds = %2917, %2918
  %2931 = phi float [ %2929, %2918 ], [ %2912, %2917 ]
  br label %2932

2932:                                             ; preds = %2930
  %2933 = add i64 %91, %57
  %2934 = icmp slt i64 %2933, %26
  %2935 = select i1 %2934, i64 %2933, i64 0
  %2936 = extractelement <8 x float> %2898, i64 1
  %2937 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2938 = getelementptr inbounds nuw i8, ptr %2937, i64 %2935
  %2939 = load i8, ptr %2938, align 1
  %2940 = zext i8 %2939 to i32
  %2941 = shl i32 %2940, 23
  %2942 = bitcast i32 %2941 to float
  %2943 = fmul float %2942, %2936
  %2944 = extractelement <8 x float> %632, i64 1
  %2945 = fmul float %2944, %2943
  %2946 = call float @llvm.fabs.f32(float %2943)
  %2947 = fcmp olt float %2946, +inf
  %2948 = fcmp one float %2943, 0.000000e+00
  %2949 = and i1 %2947, %2948
  br i1 %2949, label %2950, label %2951

2950:                                             ; preds = %2932
  br label %2963

2951:                                             ; preds = %2932
  %2952 = fpext float %2944 to double
  %2953 = fpext float %2942 to double
  %2954 = fpext float %2936 to double
  %2955 = fmul double %2952, %2953
  %2956 = fmul double %2955, %2954
  %2957 = fptrunc double %2956 to float
  %2958 = fcmp oeq float %2944, 0.000000e+00
  %2959 = call float @llvm.fabs.f32(float %2936)
  %2960 = fcmp olt float %2959, +inf
  %2961 = and i1 %2958, %2960
  %2962 = select i1 %2961, float 0.000000e+00, float %2957
  br label %2963

2963:                                             ; preds = %2950, %2951
  %2964 = phi float [ %2962, %2951 ], [ %2945, %2950 ]
  br label %2965

2965:                                             ; preds = %2963
  %2966 = add i64 %91, %57
  %2967 = icmp slt i64 %2966, %26
  %2968 = select i1 %2967, i64 %2966, i64 0
  %2969 = extractelement <8 x float> %2898, i64 2
  %2970 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %2971 = getelementptr inbounds nuw i8, ptr %2970, i64 %2968
  %2972 = load i8, ptr %2971, align 1
  %2973 = zext i8 %2972 to i32
  %2974 = shl i32 %2973, 23
  %2975 = bitcast i32 %2974 to float
  %2976 = fmul float %2975, %2969
  %2977 = extractelement <8 x float> %632, i64 2
  %2978 = fmul float %2977, %2976
  %2979 = call float @llvm.fabs.f32(float %2976)
  %2980 = fcmp olt float %2979, +inf
  %2981 = fcmp one float %2976, 0.000000e+00
  %2982 = and i1 %2980, %2981
  br i1 %2982, label %2983, label %2984

2983:                                             ; preds = %2965
  br label %2996

2984:                                             ; preds = %2965
  %2985 = fpext float %2977 to double
  %2986 = fpext float %2975 to double
  %2987 = fpext float %2969 to double
  %2988 = fmul double %2985, %2986
  %2989 = fmul double %2988, %2987
  %2990 = fptrunc double %2989 to float
  %2991 = fcmp oeq float %2977, 0.000000e+00
  %2992 = call float @llvm.fabs.f32(float %2969)
  %2993 = fcmp olt float %2992, +inf
  %2994 = and i1 %2991, %2993
  %2995 = select i1 %2994, float 0.000000e+00, float %2990
  br label %2996

2996:                                             ; preds = %2983, %2984
  %2997 = phi float [ %2995, %2984 ], [ %2978, %2983 ]
  br label %2998

2998:                                             ; preds = %2996
  %2999 = add i64 %91, %57
  %3000 = icmp slt i64 %2999, %26
  %3001 = select i1 %3000, i64 %2999, i64 0
  %3002 = extractelement <8 x float> %2898, i64 3
  %3003 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3004 = getelementptr inbounds nuw i8, ptr %3003, i64 %3001
  %3005 = load i8, ptr %3004, align 1
  %3006 = zext i8 %3005 to i32
  %3007 = shl i32 %3006, 23
  %3008 = bitcast i32 %3007 to float
  %3009 = fmul float %3008, %3002
  %3010 = extractelement <8 x float> %632, i64 3
  %3011 = fmul float %3010, %3009
  %3012 = call float @llvm.fabs.f32(float %3009)
  %3013 = fcmp olt float %3012, +inf
  %3014 = fcmp one float %3009, 0.000000e+00
  %3015 = and i1 %3013, %3014
  br i1 %3015, label %3016, label %3017

3016:                                             ; preds = %2998
  br label %3029

3017:                                             ; preds = %2998
  %3018 = fpext float %3010 to double
  %3019 = fpext float %3008 to double
  %3020 = fpext float %3002 to double
  %3021 = fmul double %3018, %3019
  %3022 = fmul double %3021, %3020
  %3023 = fptrunc double %3022 to float
  %3024 = fcmp oeq float %3010, 0.000000e+00
  %3025 = call float @llvm.fabs.f32(float %3002)
  %3026 = fcmp olt float %3025, +inf
  %3027 = and i1 %3024, %3026
  %3028 = select i1 %3027, float 0.000000e+00, float %3023
  br label %3029

3029:                                             ; preds = %3016, %3017
  %3030 = phi float [ %3028, %3017 ], [ %3011, %3016 ]
  br label %3031

3031:                                             ; preds = %3029
  %3032 = add i64 %91, %57
  %3033 = icmp slt i64 %3032, %26
  %3034 = select i1 %3033, i64 %3032, i64 0
  %3035 = extractelement <8 x float> %2898, i64 4
  %3036 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3037 = getelementptr inbounds nuw i8, ptr %3036, i64 %3034
  %3038 = load i8, ptr %3037, align 1
  %3039 = zext i8 %3038 to i32
  %3040 = shl i32 %3039, 23
  %3041 = bitcast i32 %3040 to float
  %3042 = fmul float %3041, %3035
  %3043 = extractelement <8 x float> %632, i64 4
  %3044 = fmul float %3043, %3042
  %3045 = call float @llvm.fabs.f32(float %3042)
  %3046 = fcmp olt float %3045, +inf
  %3047 = fcmp one float %3042, 0.000000e+00
  %3048 = and i1 %3046, %3047
  br i1 %3048, label %3049, label %3050

3049:                                             ; preds = %3031
  br label %3062

3050:                                             ; preds = %3031
  %3051 = fpext float %3043 to double
  %3052 = fpext float %3041 to double
  %3053 = fpext float %3035 to double
  %3054 = fmul double %3051, %3052
  %3055 = fmul double %3054, %3053
  %3056 = fptrunc double %3055 to float
  %3057 = fcmp oeq float %3043, 0.000000e+00
  %3058 = call float @llvm.fabs.f32(float %3035)
  %3059 = fcmp olt float %3058, +inf
  %3060 = and i1 %3057, %3059
  %3061 = select i1 %3060, float 0.000000e+00, float %3056
  br label %3062

3062:                                             ; preds = %3049, %3050
  %3063 = phi float [ %3061, %3050 ], [ %3044, %3049 ]
  br label %3064

3064:                                             ; preds = %3062
  %3065 = add i64 %91, %57
  %3066 = icmp slt i64 %3065, %26
  %3067 = select i1 %3066, i64 %3065, i64 0
  %3068 = extractelement <8 x float> %2898, i64 5
  %3069 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3070 = getelementptr inbounds nuw i8, ptr %3069, i64 %3067
  %3071 = load i8, ptr %3070, align 1
  %3072 = zext i8 %3071 to i32
  %3073 = shl i32 %3072, 23
  %3074 = bitcast i32 %3073 to float
  %3075 = fmul float %3074, %3068
  %3076 = extractelement <8 x float> %632, i64 5
  %3077 = fmul float %3076, %3075
  %3078 = call float @llvm.fabs.f32(float %3075)
  %3079 = fcmp olt float %3078, +inf
  %3080 = fcmp one float %3075, 0.000000e+00
  %3081 = and i1 %3079, %3080
  br i1 %3081, label %3082, label %3083

3082:                                             ; preds = %3064
  br label %3095

3083:                                             ; preds = %3064
  %3084 = fpext float %3076 to double
  %3085 = fpext float %3074 to double
  %3086 = fpext float %3068 to double
  %3087 = fmul double %3084, %3085
  %3088 = fmul double %3087, %3086
  %3089 = fptrunc double %3088 to float
  %3090 = fcmp oeq float %3076, 0.000000e+00
  %3091 = call float @llvm.fabs.f32(float %3068)
  %3092 = fcmp olt float %3091, +inf
  %3093 = and i1 %3090, %3092
  %3094 = select i1 %3093, float 0.000000e+00, float %3089
  br label %3095

3095:                                             ; preds = %3082, %3083
  %3096 = phi float [ %3094, %3083 ], [ %3077, %3082 ]
  br label %3097

3097:                                             ; preds = %3095
  %3098 = add i64 %91, %57
  %3099 = icmp slt i64 %3098, %26
  %3100 = select i1 %3099, i64 %3098, i64 0
  %3101 = extractelement <8 x float> %2898, i64 6
  %3102 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3103 = getelementptr inbounds nuw i8, ptr %3102, i64 %3100
  %3104 = load i8, ptr %3103, align 1
  %3105 = zext i8 %3104 to i32
  %3106 = shl i32 %3105, 23
  %3107 = bitcast i32 %3106 to float
  %3108 = fmul float %3107, %3101
  %3109 = extractelement <8 x float> %632, i64 6
  %3110 = fmul float %3109, %3108
  %3111 = call float @llvm.fabs.f32(float %3108)
  %3112 = fcmp olt float %3111, +inf
  %3113 = fcmp one float %3108, 0.000000e+00
  %3114 = and i1 %3112, %3113
  br i1 %3114, label %3115, label %3116

3115:                                             ; preds = %3097
  br label %3128

3116:                                             ; preds = %3097
  %3117 = fpext float %3109 to double
  %3118 = fpext float %3107 to double
  %3119 = fpext float %3101 to double
  %3120 = fmul double %3117, %3118
  %3121 = fmul double %3120, %3119
  %3122 = fptrunc double %3121 to float
  %3123 = fcmp oeq float %3109, 0.000000e+00
  %3124 = call float @llvm.fabs.f32(float %3101)
  %3125 = fcmp olt float %3124, +inf
  %3126 = and i1 %3123, %3125
  %3127 = select i1 %3126, float 0.000000e+00, float %3122
  br label %3128

3128:                                             ; preds = %3115, %3116
  %3129 = phi float [ %3127, %3116 ], [ %3110, %3115 ]
  br label %3130

3130:                                             ; preds = %3128
  %3131 = add i64 %91, %57
  %3132 = icmp slt i64 %3131, %26
  %3133 = select i1 %3132, i64 %3131, i64 0
  %3134 = extractelement <8 x float> %2898, i64 7
  %3135 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3136 = getelementptr inbounds nuw i8, ptr %3135, i64 %3133
  %3137 = load i8, ptr %3136, align 1
  %3138 = zext i8 %3137 to i32
  %3139 = shl i32 %3138, 23
  %3140 = bitcast i32 %3139 to float
  %3141 = fmul float %3140, %3134
  %3142 = extractelement <8 x float> %632, i64 7
  %3143 = fmul float %3142, %3141
  %3144 = call float @llvm.fabs.f32(float %3141)
  %3145 = fcmp olt float %3144, +inf
  %3146 = fcmp one float %3141, 0.000000e+00
  %3147 = and i1 %3145, %3146
  br i1 %3147, label %3148, label %3149

3148:                                             ; preds = %3130
  br label %3161

3149:                                             ; preds = %3130
  %3150 = fpext float %3142 to double
  %3151 = fpext float %3140 to double
  %3152 = fpext float %3134 to double
  %3153 = fmul double %3150, %3151
  %3154 = fmul double %3153, %3152
  %3155 = fptrunc double %3154 to float
  %3156 = fcmp oeq float %3142, 0.000000e+00
  %3157 = call float @llvm.fabs.f32(float %3134)
  %3158 = fcmp olt float %3157, +inf
  %3159 = and i1 %3156, %3158
  %3160 = select i1 %3159, float 0.000000e+00, float %3155
  br label %3161

3161:                                             ; preds = %3148, %3149
  %3162 = phi float [ %3160, %3149 ], [ %3143, %3148 ]
  br label %3163

3163:                                             ; preds = %3161
  %3164 = mul i64 %58, 8
  %3165 = add i64 %84, %3164
  %3166 = add i64 %91, %57
  %3167 = mul i64 %3165, %26
  %3168 = add i64 %3167, %3166
  %3169 = fptrunc float %2931 to bfloat
  %3170 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3171 = getelementptr inbounds nuw bfloat, ptr %3170, i64 %3168
  store bfloat %3169, ptr %3171, align 2
  %3172 = mul i64 %58, 8
  %3173 = add i64 %3172, 1
  %3174 = add i64 %84, %3173
  %3175 = add i64 %91, %57
  %3176 = mul i64 %3174, %26
  %3177 = add i64 %3176, %3175
  %3178 = fptrunc float %2964 to bfloat
  %3179 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3180 = getelementptr inbounds nuw bfloat, ptr %3179, i64 %3177
  store bfloat %3178, ptr %3180, align 2
  %3181 = mul i64 %58, 8
  %3182 = add i64 %3181, 2
  %3183 = add i64 %84, %3182
  %3184 = add i64 %91, %57
  %3185 = mul i64 %3183, %26
  %3186 = add i64 %3185, %3184
  %3187 = fptrunc float %2997 to bfloat
  %3188 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3189 = getelementptr inbounds nuw bfloat, ptr %3188, i64 %3186
  store bfloat %3187, ptr %3189, align 2
  %3190 = mul i64 %58, 8
  %3191 = add i64 %3190, 3
  %3192 = add i64 %84, %3191
  %3193 = add i64 %91, %57
  %3194 = mul i64 %3192, %26
  %3195 = add i64 %3194, %3193
  %3196 = fptrunc float %3030 to bfloat
  %3197 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3198 = getelementptr inbounds nuw bfloat, ptr %3197, i64 %3195
  store bfloat %3196, ptr %3198, align 2
  %3199 = mul i64 %58, 8
  %3200 = add i64 %3199, 4
  %3201 = add i64 %84, %3200
  %3202 = add i64 %91, %57
  %3203 = mul i64 %3201, %26
  %3204 = add i64 %3203, %3202
  %3205 = fptrunc float %3063 to bfloat
  %3206 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3207 = getelementptr inbounds nuw bfloat, ptr %3206, i64 %3204
  store bfloat %3205, ptr %3207, align 2
  %3208 = mul i64 %58, 8
  %3209 = add i64 %3208, 5
  %3210 = add i64 %84, %3209
  %3211 = add i64 %91, %57
  %3212 = mul i64 %3210, %26
  %3213 = add i64 %3212, %3211
  %3214 = fptrunc float %3096 to bfloat
  %3215 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3216 = getelementptr inbounds nuw bfloat, ptr %3215, i64 %3213
  store bfloat %3214, ptr %3216, align 2
  %3217 = mul i64 %58, 8
  %3218 = add i64 %3217, 6
  %3219 = add i64 %84, %3218
  %3220 = add i64 %91, %57
  %3221 = mul i64 %3219, %26
  %3222 = add i64 %3221, %3220
  %3223 = fptrunc float %3129 to bfloat
  %3224 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3225 = getelementptr inbounds nuw bfloat, ptr %3224, i64 %3222
  store bfloat %3223, ptr %3225, align 2
  %3226 = mul i64 %58, 8
  %3227 = add i64 %3226, 7
  %3228 = add i64 %84, %3227
  %3229 = add i64 %91, %57
  %3230 = mul i64 %3228, %26
  %3231 = add i64 %3230, %3229
  %3232 = fptrunc float %3162 to bfloat
  %3233 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3234 = getelementptr inbounds nuw bfloat, ptr %3233, i64 %3231
  store bfloat %3232, ptr %3234, align 2
  %3235 = mul i64 %58, 8
  %3236 = add i64 %86, %3235
  %3237 = add i64 %91, %57
  %3238 = add i64 %3236, 7
  %3239 = icmp ult i64 %3237, %26
  %3240 = icmp ult i64 %3238, %25
  %3241 = and i1 %3240, %3239
  %3242 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3243 = ptrtoint ptr %3242 to i64
  %3244 = mul i64 %3236, 4
  %3245 = add i64 %3243, %3244
  %3246 = urem i64 %3245, 16
  %3247 = icmp eq i64 %3246, 0
  %3248 = and i1 %3241, %3247
  br i1 %3248, label %3249, label %3258

3249:                                             ; preds = %3163
  %3250 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3251 = getelementptr float, ptr %3250, i64 %3236
  %3252 = load <4 x float>, ptr %3251, align 16
  %3253 = add i64 %3236, 4
  %3254 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3255 = getelementptr float, ptr %3254, i64 %3253
  %3256 = load <4 x float>, ptr %3255, align 16
  %3257 = shufflevector <4 x float> %3252, <4 x float> %3256, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3330

3258:                                             ; preds = %3163
  %3259 = mul i64 %58, 8
  %3260 = add i64 %86, %3259
  %3261 = icmp slt i64 %3260, %25
  %3262 = select i1 %3261, i64 %3260, i64 0
  %3263 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3264 = getelementptr inbounds nuw float, ptr %3263, i64 %3262
  %3265 = load float, ptr %3264, align 4
  %3266 = insertelement <8 x float> zeroinitializer, float %3265, i64 0
  %3267 = mul i64 %58, 8
  %3268 = add i64 %3267, 1
  %3269 = add i64 %86, %3268
  %3270 = icmp slt i64 %3269, %25
  %3271 = select i1 %3270, i64 %3269, i64 0
  %3272 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3273 = getelementptr inbounds nuw float, ptr %3272, i64 %3271
  %3274 = load float, ptr %3273, align 4
  %3275 = insertelement <8 x float> %3266, float %3274, i64 1
  %3276 = mul i64 %58, 8
  %3277 = add i64 %3276, 2
  %3278 = add i64 %86, %3277
  %3279 = icmp slt i64 %3278, %25
  %3280 = select i1 %3279, i64 %3278, i64 0
  %3281 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3282 = getelementptr inbounds nuw float, ptr %3281, i64 %3280
  %3283 = load float, ptr %3282, align 4
  %3284 = insertelement <8 x float> %3275, float %3283, i64 2
  %3285 = mul i64 %58, 8
  %3286 = add i64 %3285, 3
  %3287 = add i64 %86, %3286
  %3288 = icmp slt i64 %3287, %25
  %3289 = select i1 %3288, i64 %3287, i64 0
  %3290 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3291 = getelementptr inbounds nuw float, ptr %3290, i64 %3289
  %3292 = load float, ptr %3291, align 4
  %3293 = insertelement <8 x float> %3284, float %3292, i64 3
  %3294 = mul i64 %58, 8
  %3295 = add i64 %3294, 4
  %3296 = add i64 %86, %3295
  %3297 = icmp slt i64 %3296, %25
  %3298 = select i1 %3297, i64 %3296, i64 0
  %3299 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3300 = getelementptr inbounds nuw float, ptr %3299, i64 %3298
  %3301 = load float, ptr %3300, align 4
  %3302 = insertelement <8 x float> %3293, float %3301, i64 4
  %3303 = mul i64 %58, 8
  %3304 = add i64 %3303, 5
  %3305 = add i64 %86, %3304
  %3306 = icmp slt i64 %3305, %25
  %3307 = select i1 %3306, i64 %3305, i64 0
  %3308 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3309 = getelementptr inbounds nuw float, ptr %3308, i64 %3307
  %3310 = load float, ptr %3309, align 4
  %3311 = insertelement <8 x float> %3302, float %3310, i64 5
  %3312 = mul i64 %58, 8
  %3313 = add i64 %3312, 6
  %3314 = add i64 %86, %3313
  %3315 = icmp slt i64 %3314, %25
  %3316 = select i1 %3315, i64 %3314, i64 0
  %3317 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3318 = getelementptr inbounds nuw float, ptr %3317, i64 %3316
  %3319 = load float, ptr %3318, align 4
  %3320 = insertelement <8 x float> %3311, float %3319, i64 6
  %3321 = mul i64 %58, 8
  %3322 = add i64 %3321, 7
  %3323 = add i64 %86, %3322
  %3324 = icmp slt i64 %3323, %25
  %3325 = select i1 %3324, i64 %3323, i64 0
  %3326 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3327 = getelementptr inbounds nuw float, ptr %3326, i64 %3325
  %3328 = load float, ptr %3327, align 4
  %3329 = insertelement <8 x float> %3320, float %3328, i64 7
  br label %3330

3330:                                             ; preds = %3249, %3258
  %3331 = phi <8 x float> [ %3329, %3258 ], [ %3257, %3249 ]
  br label %3332

3332:                                             ; preds = %3330
  %3333 = add i64 %91, %57
  %3334 = icmp slt i64 %3333, %26
  %3335 = select i1 %3334, i64 %3333, i64 0
  %3336 = extractelement <8 x float> %3331, i64 0
  %3337 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3338 = getelementptr inbounds nuw i8, ptr %3337, i64 %3335
  %3339 = load i8, ptr %3338, align 1
  %3340 = zext i8 %3339 to i32
  %3341 = shl i32 %3340, 23
  %3342 = bitcast i32 %3341 to float
  %3343 = fmul float %3342, %3336
  %3344 = extractelement <8 x float> %634, i64 0
  %3345 = fmul float %3344, %3343
  %3346 = call float @llvm.fabs.f32(float %3343)
  %3347 = fcmp olt float %3346, +inf
  %3348 = fcmp one float %3343, 0.000000e+00
  %3349 = and i1 %3347, %3348
  br i1 %3349, label %3350, label %3351

3350:                                             ; preds = %3332
  br label %3363

3351:                                             ; preds = %3332
  %3352 = fpext float %3344 to double
  %3353 = fpext float %3342 to double
  %3354 = fpext float %3336 to double
  %3355 = fmul double %3352, %3353
  %3356 = fmul double %3355, %3354
  %3357 = fptrunc double %3356 to float
  %3358 = fcmp oeq float %3344, 0.000000e+00
  %3359 = call float @llvm.fabs.f32(float %3336)
  %3360 = fcmp olt float %3359, +inf
  %3361 = and i1 %3358, %3360
  %3362 = select i1 %3361, float 0.000000e+00, float %3357
  br label %3363

3363:                                             ; preds = %3350, %3351
  %3364 = phi float [ %3362, %3351 ], [ %3345, %3350 ]
  br label %3365

3365:                                             ; preds = %3363
  %3366 = add i64 %91, %57
  %3367 = icmp slt i64 %3366, %26
  %3368 = select i1 %3367, i64 %3366, i64 0
  %3369 = extractelement <8 x float> %3331, i64 1
  %3370 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3371 = getelementptr inbounds nuw i8, ptr %3370, i64 %3368
  %3372 = load i8, ptr %3371, align 1
  %3373 = zext i8 %3372 to i32
  %3374 = shl i32 %3373, 23
  %3375 = bitcast i32 %3374 to float
  %3376 = fmul float %3375, %3369
  %3377 = extractelement <8 x float> %634, i64 1
  %3378 = fmul float %3377, %3376
  %3379 = call float @llvm.fabs.f32(float %3376)
  %3380 = fcmp olt float %3379, +inf
  %3381 = fcmp one float %3376, 0.000000e+00
  %3382 = and i1 %3380, %3381
  br i1 %3382, label %3383, label %3384

3383:                                             ; preds = %3365
  br label %3396

3384:                                             ; preds = %3365
  %3385 = fpext float %3377 to double
  %3386 = fpext float %3375 to double
  %3387 = fpext float %3369 to double
  %3388 = fmul double %3385, %3386
  %3389 = fmul double %3388, %3387
  %3390 = fptrunc double %3389 to float
  %3391 = fcmp oeq float %3377, 0.000000e+00
  %3392 = call float @llvm.fabs.f32(float %3369)
  %3393 = fcmp olt float %3392, +inf
  %3394 = and i1 %3391, %3393
  %3395 = select i1 %3394, float 0.000000e+00, float %3390
  br label %3396

3396:                                             ; preds = %3383, %3384
  %3397 = phi float [ %3395, %3384 ], [ %3378, %3383 ]
  br label %3398

3398:                                             ; preds = %3396
  %3399 = add i64 %91, %57
  %3400 = icmp slt i64 %3399, %26
  %3401 = select i1 %3400, i64 %3399, i64 0
  %3402 = extractelement <8 x float> %3331, i64 2
  %3403 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3404 = getelementptr inbounds nuw i8, ptr %3403, i64 %3401
  %3405 = load i8, ptr %3404, align 1
  %3406 = zext i8 %3405 to i32
  %3407 = shl i32 %3406, 23
  %3408 = bitcast i32 %3407 to float
  %3409 = fmul float %3408, %3402
  %3410 = extractelement <8 x float> %634, i64 2
  %3411 = fmul float %3410, %3409
  %3412 = call float @llvm.fabs.f32(float %3409)
  %3413 = fcmp olt float %3412, +inf
  %3414 = fcmp one float %3409, 0.000000e+00
  %3415 = and i1 %3413, %3414
  br i1 %3415, label %3416, label %3417

3416:                                             ; preds = %3398
  br label %3429

3417:                                             ; preds = %3398
  %3418 = fpext float %3410 to double
  %3419 = fpext float %3408 to double
  %3420 = fpext float %3402 to double
  %3421 = fmul double %3418, %3419
  %3422 = fmul double %3421, %3420
  %3423 = fptrunc double %3422 to float
  %3424 = fcmp oeq float %3410, 0.000000e+00
  %3425 = call float @llvm.fabs.f32(float %3402)
  %3426 = fcmp olt float %3425, +inf
  %3427 = and i1 %3424, %3426
  %3428 = select i1 %3427, float 0.000000e+00, float %3423
  br label %3429

3429:                                             ; preds = %3416, %3417
  %3430 = phi float [ %3428, %3417 ], [ %3411, %3416 ]
  br label %3431

3431:                                             ; preds = %3429
  %3432 = add i64 %91, %57
  %3433 = icmp slt i64 %3432, %26
  %3434 = select i1 %3433, i64 %3432, i64 0
  %3435 = extractelement <8 x float> %3331, i64 3
  %3436 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3437 = getelementptr inbounds nuw i8, ptr %3436, i64 %3434
  %3438 = load i8, ptr %3437, align 1
  %3439 = zext i8 %3438 to i32
  %3440 = shl i32 %3439, 23
  %3441 = bitcast i32 %3440 to float
  %3442 = fmul float %3441, %3435
  %3443 = extractelement <8 x float> %634, i64 3
  %3444 = fmul float %3443, %3442
  %3445 = call float @llvm.fabs.f32(float %3442)
  %3446 = fcmp olt float %3445, +inf
  %3447 = fcmp one float %3442, 0.000000e+00
  %3448 = and i1 %3446, %3447
  br i1 %3448, label %3449, label %3450

3449:                                             ; preds = %3431
  br label %3462

3450:                                             ; preds = %3431
  %3451 = fpext float %3443 to double
  %3452 = fpext float %3441 to double
  %3453 = fpext float %3435 to double
  %3454 = fmul double %3451, %3452
  %3455 = fmul double %3454, %3453
  %3456 = fptrunc double %3455 to float
  %3457 = fcmp oeq float %3443, 0.000000e+00
  %3458 = call float @llvm.fabs.f32(float %3435)
  %3459 = fcmp olt float %3458, +inf
  %3460 = and i1 %3457, %3459
  %3461 = select i1 %3460, float 0.000000e+00, float %3456
  br label %3462

3462:                                             ; preds = %3449, %3450
  %3463 = phi float [ %3461, %3450 ], [ %3444, %3449 ]
  br label %3464

3464:                                             ; preds = %3462
  %3465 = add i64 %91, %57
  %3466 = icmp slt i64 %3465, %26
  %3467 = select i1 %3466, i64 %3465, i64 0
  %3468 = extractelement <8 x float> %3331, i64 4
  %3469 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3470 = getelementptr inbounds nuw i8, ptr %3469, i64 %3467
  %3471 = load i8, ptr %3470, align 1
  %3472 = zext i8 %3471 to i32
  %3473 = shl i32 %3472, 23
  %3474 = bitcast i32 %3473 to float
  %3475 = fmul float %3474, %3468
  %3476 = extractelement <8 x float> %634, i64 4
  %3477 = fmul float %3476, %3475
  %3478 = call float @llvm.fabs.f32(float %3475)
  %3479 = fcmp olt float %3478, +inf
  %3480 = fcmp one float %3475, 0.000000e+00
  %3481 = and i1 %3479, %3480
  br i1 %3481, label %3482, label %3483

3482:                                             ; preds = %3464
  br label %3495

3483:                                             ; preds = %3464
  %3484 = fpext float %3476 to double
  %3485 = fpext float %3474 to double
  %3486 = fpext float %3468 to double
  %3487 = fmul double %3484, %3485
  %3488 = fmul double %3487, %3486
  %3489 = fptrunc double %3488 to float
  %3490 = fcmp oeq float %3476, 0.000000e+00
  %3491 = call float @llvm.fabs.f32(float %3468)
  %3492 = fcmp olt float %3491, +inf
  %3493 = and i1 %3490, %3492
  %3494 = select i1 %3493, float 0.000000e+00, float %3489
  br label %3495

3495:                                             ; preds = %3482, %3483
  %3496 = phi float [ %3494, %3483 ], [ %3477, %3482 ]
  br label %3497

3497:                                             ; preds = %3495
  %3498 = add i64 %91, %57
  %3499 = icmp slt i64 %3498, %26
  %3500 = select i1 %3499, i64 %3498, i64 0
  %3501 = extractelement <8 x float> %3331, i64 5
  %3502 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3503 = getelementptr inbounds nuw i8, ptr %3502, i64 %3500
  %3504 = load i8, ptr %3503, align 1
  %3505 = zext i8 %3504 to i32
  %3506 = shl i32 %3505, 23
  %3507 = bitcast i32 %3506 to float
  %3508 = fmul float %3507, %3501
  %3509 = extractelement <8 x float> %634, i64 5
  %3510 = fmul float %3509, %3508
  %3511 = call float @llvm.fabs.f32(float %3508)
  %3512 = fcmp olt float %3511, +inf
  %3513 = fcmp one float %3508, 0.000000e+00
  %3514 = and i1 %3512, %3513
  br i1 %3514, label %3515, label %3516

3515:                                             ; preds = %3497
  br label %3528

3516:                                             ; preds = %3497
  %3517 = fpext float %3509 to double
  %3518 = fpext float %3507 to double
  %3519 = fpext float %3501 to double
  %3520 = fmul double %3517, %3518
  %3521 = fmul double %3520, %3519
  %3522 = fptrunc double %3521 to float
  %3523 = fcmp oeq float %3509, 0.000000e+00
  %3524 = call float @llvm.fabs.f32(float %3501)
  %3525 = fcmp olt float %3524, +inf
  %3526 = and i1 %3523, %3525
  %3527 = select i1 %3526, float 0.000000e+00, float %3522
  br label %3528

3528:                                             ; preds = %3515, %3516
  %3529 = phi float [ %3527, %3516 ], [ %3510, %3515 ]
  br label %3530

3530:                                             ; preds = %3528
  %3531 = add i64 %91, %57
  %3532 = icmp slt i64 %3531, %26
  %3533 = select i1 %3532, i64 %3531, i64 0
  %3534 = extractelement <8 x float> %3331, i64 6
  %3535 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3536 = getelementptr inbounds nuw i8, ptr %3535, i64 %3533
  %3537 = load i8, ptr %3536, align 1
  %3538 = zext i8 %3537 to i32
  %3539 = shl i32 %3538, 23
  %3540 = bitcast i32 %3539 to float
  %3541 = fmul float %3540, %3534
  %3542 = extractelement <8 x float> %634, i64 6
  %3543 = fmul float %3542, %3541
  %3544 = call float @llvm.fabs.f32(float %3541)
  %3545 = fcmp olt float %3544, +inf
  %3546 = fcmp one float %3541, 0.000000e+00
  %3547 = and i1 %3545, %3546
  br i1 %3547, label %3548, label %3549

3548:                                             ; preds = %3530
  br label %3561

3549:                                             ; preds = %3530
  %3550 = fpext float %3542 to double
  %3551 = fpext float %3540 to double
  %3552 = fpext float %3534 to double
  %3553 = fmul double %3550, %3551
  %3554 = fmul double %3553, %3552
  %3555 = fptrunc double %3554 to float
  %3556 = fcmp oeq float %3542, 0.000000e+00
  %3557 = call float @llvm.fabs.f32(float %3534)
  %3558 = fcmp olt float %3557, +inf
  %3559 = and i1 %3556, %3558
  %3560 = select i1 %3559, float 0.000000e+00, float %3555
  br label %3561

3561:                                             ; preds = %3548, %3549
  %3562 = phi float [ %3560, %3549 ], [ %3543, %3548 ]
  br label %3563

3563:                                             ; preds = %3561
  %3564 = add i64 %91, %57
  %3565 = icmp slt i64 %3564, %26
  %3566 = select i1 %3565, i64 %3564, i64 0
  %3567 = extractelement <8 x float> %3331, i64 7
  %3568 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3569 = getelementptr inbounds nuw i8, ptr %3568, i64 %3566
  %3570 = load i8, ptr %3569, align 1
  %3571 = zext i8 %3570 to i32
  %3572 = shl i32 %3571, 23
  %3573 = bitcast i32 %3572 to float
  %3574 = fmul float %3573, %3567
  %3575 = extractelement <8 x float> %634, i64 7
  %3576 = fmul float %3575, %3574
  %3577 = call float @llvm.fabs.f32(float %3574)
  %3578 = fcmp olt float %3577, +inf
  %3579 = fcmp one float %3574, 0.000000e+00
  %3580 = and i1 %3578, %3579
  br i1 %3580, label %3581, label %3582

3581:                                             ; preds = %3563
  br label %3594

3582:                                             ; preds = %3563
  %3583 = fpext float %3575 to double
  %3584 = fpext float %3573 to double
  %3585 = fpext float %3567 to double
  %3586 = fmul double %3583, %3584
  %3587 = fmul double %3586, %3585
  %3588 = fptrunc double %3587 to float
  %3589 = fcmp oeq float %3575, 0.000000e+00
  %3590 = call float @llvm.fabs.f32(float %3567)
  %3591 = fcmp olt float %3590, +inf
  %3592 = and i1 %3589, %3591
  %3593 = select i1 %3592, float 0.000000e+00, float %3588
  br label %3594

3594:                                             ; preds = %3581, %3582
  %3595 = phi float [ %3593, %3582 ], [ %3576, %3581 ]
  br label %3596

3596:                                             ; preds = %3594
  %3597 = mul i64 %58, 8
  %3598 = add i64 %86, %3597
  %3599 = add i64 %91, %57
  %3600 = mul i64 %3598, %26
  %3601 = add i64 %3600, %3599
  %3602 = fptrunc float %3364 to bfloat
  %3603 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3604 = getelementptr inbounds nuw bfloat, ptr %3603, i64 %3601
  store bfloat %3602, ptr %3604, align 2
  %3605 = mul i64 %58, 8
  %3606 = add i64 %3605, 1
  %3607 = add i64 %86, %3606
  %3608 = add i64 %91, %57
  %3609 = mul i64 %3607, %26
  %3610 = add i64 %3609, %3608
  %3611 = fptrunc float %3397 to bfloat
  %3612 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3613 = getelementptr inbounds nuw bfloat, ptr %3612, i64 %3610
  store bfloat %3611, ptr %3613, align 2
  %3614 = mul i64 %58, 8
  %3615 = add i64 %3614, 2
  %3616 = add i64 %86, %3615
  %3617 = add i64 %91, %57
  %3618 = mul i64 %3616, %26
  %3619 = add i64 %3618, %3617
  %3620 = fptrunc float %3430 to bfloat
  %3621 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3622 = getelementptr inbounds nuw bfloat, ptr %3621, i64 %3619
  store bfloat %3620, ptr %3622, align 2
  %3623 = mul i64 %58, 8
  %3624 = add i64 %3623, 3
  %3625 = add i64 %86, %3624
  %3626 = add i64 %91, %57
  %3627 = mul i64 %3625, %26
  %3628 = add i64 %3627, %3626
  %3629 = fptrunc float %3463 to bfloat
  %3630 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3631 = getelementptr inbounds nuw bfloat, ptr %3630, i64 %3628
  store bfloat %3629, ptr %3631, align 2
  %3632 = mul i64 %58, 8
  %3633 = add i64 %3632, 4
  %3634 = add i64 %86, %3633
  %3635 = add i64 %91, %57
  %3636 = mul i64 %3634, %26
  %3637 = add i64 %3636, %3635
  %3638 = fptrunc float %3496 to bfloat
  %3639 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3640 = getelementptr inbounds nuw bfloat, ptr %3639, i64 %3637
  store bfloat %3638, ptr %3640, align 2
  %3641 = mul i64 %58, 8
  %3642 = add i64 %3641, 5
  %3643 = add i64 %86, %3642
  %3644 = add i64 %91, %57
  %3645 = mul i64 %3643, %26
  %3646 = add i64 %3645, %3644
  %3647 = fptrunc float %3529 to bfloat
  %3648 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3649 = getelementptr inbounds nuw bfloat, ptr %3648, i64 %3646
  store bfloat %3647, ptr %3649, align 2
  %3650 = mul i64 %58, 8
  %3651 = add i64 %3650, 6
  %3652 = add i64 %86, %3651
  %3653 = add i64 %91, %57
  %3654 = mul i64 %3652, %26
  %3655 = add i64 %3654, %3653
  %3656 = fptrunc float %3562 to bfloat
  %3657 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3658 = getelementptr inbounds nuw bfloat, ptr %3657, i64 %3655
  store bfloat %3656, ptr %3658, align 2
  %3659 = mul i64 %58, 8
  %3660 = add i64 %3659, 7
  %3661 = add i64 %86, %3660
  %3662 = add i64 %91, %57
  %3663 = mul i64 %3661, %26
  %3664 = add i64 %3663, %3662
  %3665 = fptrunc float %3595 to bfloat
  %3666 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %3667 = getelementptr inbounds nuw bfloat, ptr %3666, i64 %3664
  store bfloat %3665, ptr %3667, align 2
  %3668 = mul i64 %58, 8
  %3669 = add i64 %88, %3668
  %3670 = add i64 %91, %57
  %3671 = add i64 %3669, 7
  %3672 = icmp ult i64 %3670, %26
  %3673 = icmp ult i64 %3671, %25
  %3674 = and i1 %3673, %3672
  %3675 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3676 = ptrtoint ptr %3675 to i64
  %3677 = mul i64 %3669, 4
  %3678 = add i64 %3676, %3677
  %3679 = urem i64 %3678, 16
  %3680 = icmp eq i64 %3679, 0
  %3681 = and i1 %3674, %3680
  br i1 %3681, label %3682, label %3691

3682:                                             ; preds = %3596
  %3683 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3684 = getelementptr float, ptr %3683, i64 %3669
  %3685 = load <4 x float>, ptr %3684, align 16
  %3686 = add i64 %3669, 4
  %3687 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3688 = getelementptr float, ptr %3687, i64 %3686
  %3689 = load <4 x float>, ptr %3688, align 16
  %3690 = shufflevector <4 x float> %3685, <4 x float> %3689, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  br label %3763

3691:                                             ; preds = %3596
  %3692 = mul i64 %58, 8
  %3693 = add i64 %88, %3692
  %3694 = icmp slt i64 %3693, %25
  %3695 = select i1 %3694, i64 %3693, i64 0
  %3696 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3697 = getelementptr inbounds nuw float, ptr %3696, i64 %3695
  %3698 = load float, ptr %3697, align 4
  %3699 = insertelement <8 x float> zeroinitializer, float %3698, i64 0
  %3700 = mul i64 %58, 8
  %3701 = add i64 %3700, 1
  %3702 = add i64 %88, %3701
  %3703 = icmp slt i64 %3702, %25
  %3704 = select i1 %3703, i64 %3702, i64 0
  %3705 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3706 = getelementptr inbounds nuw float, ptr %3705, i64 %3704
  %3707 = load float, ptr %3706, align 4
  %3708 = insertelement <8 x float> %3699, float %3707, i64 1
  %3709 = mul i64 %58, 8
  %3710 = add i64 %3709, 2
  %3711 = add i64 %88, %3710
  %3712 = icmp slt i64 %3711, %25
  %3713 = select i1 %3712, i64 %3711, i64 0
  %3714 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3715 = getelementptr inbounds nuw float, ptr %3714, i64 %3713
  %3716 = load float, ptr %3715, align 4
  %3717 = insertelement <8 x float> %3708, float %3716, i64 2
  %3718 = mul i64 %58, 8
  %3719 = add i64 %3718, 3
  %3720 = add i64 %88, %3719
  %3721 = icmp slt i64 %3720, %25
  %3722 = select i1 %3721, i64 %3720, i64 0
  %3723 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3724 = getelementptr inbounds nuw float, ptr %3723, i64 %3722
  %3725 = load float, ptr %3724, align 4
  %3726 = insertelement <8 x float> %3717, float %3725, i64 3
  %3727 = mul i64 %58, 8
  %3728 = add i64 %3727, 4
  %3729 = add i64 %88, %3728
  %3730 = icmp slt i64 %3729, %25
  %3731 = select i1 %3730, i64 %3729, i64 0
  %3732 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3733 = getelementptr inbounds nuw float, ptr %3732, i64 %3731
  %3734 = load float, ptr %3733, align 4
  %3735 = insertelement <8 x float> %3726, float %3734, i64 4
  %3736 = mul i64 %58, 8
  %3737 = add i64 %3736, 5
  %3738 = add i64 %88, %3737
  %3739 = icmp slt i64 %3738, %25
  %3740 = select i1 %3739, i64 %3738, i64 0
  %3741 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3742 = getelementptr inbounds nuw float, ptr %3741, i64 %3740
  %3743 = load float, ptr %3742, align 4
  %3744 = insertelement <8 x float> %3735, float %3743, i64 5
  %3745 = mul i64 %58, 8
  %3746 = add i64 %3745, 6
  %3747 = add i64 %88, %3746
  %3748 = icmp slt i64 %3747, %25
  %3749 = select i1 %3748, i64 %3747, i64 0
  %3750 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3751 = getelementptr inbounds nuw float, ptr %3750, i64 %3749
  %3752 = load float, ptr %3751, align 4
  %3753 = insertelement <8 x float> %3744, float %3752, i64 6
  %3754 = mul i64 %58, 8
  %3755 = add i64 %3754, 7
  %3756 = add i64 %88, %3755
  %3757 = icmp slt i64 %3756, %25
  %3758 = select i1 %3757, i64 %3756, i64 0
  %3759 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %43, 1
  %3760 = getelementptr inbounds nuw float, ptr %3759, i64 %3758
  %3761 = load float, ptr %3760, align 4
  %3762 = insertelement <8 x float> %3753, float %3761, i64 7
  br label %3763

3763:                                             ; preds = %3682, %3691
  %3764 = phi <8 x float> [ %3762, %3691 ], [ %3690, %3682 ]
  br label %3765

3765:                                             ; preds = %3763
  %3766 = add i64 %91, %57
  %3767 = icmp slt i64 %3766, %26
  %3768 = select i1 %3767, i64 %3766, i64 0
  %3769 = extractelement <8 x float> %3764, i64 0
  %3770 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3771 = getelementptr inbounds nuw i8, ptr %3770, i64 %3768
  %3772 = load i8, ptr %3771, align 1
  %3773 = zext i8 %3772 to i32
  %3774 = shl i32 %3773, 23
  %3775 = bitcast i32 %3774 to float
  %3776 = fmul float %3775, %3769
  %3777 = extractelement <8 x float> %636, i64 0
  %3778 = fmul float %3777, %3776
  %3779 = call float @llvm.fabs.f32(float %3776)
  %3780 = fcmp olt float %3779, +inf
  %3781 = fcmp one float %3776, 0.000000e+00
  %3782 = and i1 %3780, %3781
  br i1 %3782, label %3783, label %3784

3783:                                             ; preds = %3765
  br label %3796

3784:                                             ; preds = %3765
  %3785 = fpext float %3777 to double
  %3786 = fpext float %3775 to double
  %3787 = fpext float %3769 to double
  %3788 = fmul double %3785, %3786
  %3789 = fmul double %3788, %3787
  %3790 = fptrunc double %3789 to float
  %3791 = fcmp oeq float %3777, 0.000000e+00
  %3792 = call float @llvm.fabs.f32(float %3769)
  %3793 = fcmp olt float %3792, +inf
  %3794 = and i1 %3791, %3793
  %3795 = select i1 %3794, float 0.000000e+00, float %3790
  br label %3796

3796:                                             ; preds = %3783, %3784
  %3797 = phi float [ %3795, %3784 ], [ %3778, %3783 ]
  br label %3798

3798:                                             ; preds = %3796
  %3799 = add i64 %91, %57
  %3800 = icmp slt i64 %3799, %26
  %3801 = select i1 %3800, i64 %3799, i64 0
  %3802 = extractelement <8 x float> %3764, i64 1
  %3803 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3804 = getelementptr inbounds nuw i8, ptr %3803, i64 %3801
  %3805 = load i8, ptr %3804, align 1
  %3806 = zext i8 %3805 to i32
  %3807 = shl i32 %3806, 23
  %3808 = bitcast i32 %3807 to float
  %3809 = fmul float %3808, %3802
  %3810 = extractelement <8 x float> %636, i64 1
  %3811 = fmul float %3810, %3809
  %3812 = call float @llvm.fabs.f32(float %3809)
  %3813 = fcmp olt float %3812, +inf
  %3814 = fcmp one float %3809, 0.000000e+00
  %3815 = and i1 %3813, %3814
  br i1 %3815, label %3816, label %3817

3816:                                             ; preds = %3798
  br label %3829

3817:                                             ; preds = %3798
  %3818 = fpext float %3810 to double
  %3819 = fpext float %3808 to double
  %3820 = fpext float %3802 to double
  %3821 = fmul double %3818, %3819
  %3822 = fmul double %3821, %3820
  %3823 = fptrunc double %3822 to float
  %3824 = fcmp oeq float %3810, 0.000000e+00
  %3825 = call float @llvm.fabs.f32(float %3802)
  %3826 = fcmp olt float %3825, +inf
  %3827 = and i1 %3824, %3826
  %3828 = select i1 %3827, float 0.000000e+00, float %3823
  br label %3829

3829:                                             ; preds = %3816, %3817
  %3830 = phi float [ %3828, %3817 ], [ %3811, %3816 ]
  br label %3831

3831:                                             ; preds = %3829
  %3832 = add i64 %91, %57
  %3833 = icmp slt i64 %3832, %26
  %3834 = select i1 %3833, i64 %3832, i64 0
  %3835 = extractelement <8 x float> %3764, i64 2
  %3836 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3837 = getelementptr inbounds nuw i8, ptr %3836, i64 %3834
  %3838 = load i8, ptr %3837, align 1
  %3839 = zext i8 %3838 to i32
  %3840 = shl i32 %3839, 23
  %3841 = bitcast i32 %3840 to float
  %3842 = fmul float %3841, %3835
  %3843 = extractelement <8 x float> %636, i64 2
  %3844 = fmul float %3843, %3842
  %3845 = call float @llvm.fabs.f32(float %3842)
  %3846 = fcmp olt float %3845, +inf
  %3847 = fcmp one float %3842, 0.000000e+00
  %3848 = and i1 %3846, %3847
  br i1 %3848, label %3849, label %3850

3849:                                             ; preds = %3831
  br label %3862

3850:                                             ; preds = %3831
  %3851 = fpext float %3843 to double
  %3852 = fpext float %3841 to double
  %3853 = fpext float %3835 to double
  %3854 = fmul double %3851, %3852
  %3855 = fmul double %3854, %3853
  %3856 = fptrunc double %3855 to float
  %3857 = fcmp oeq float %3843, 0.000000e+00
  %3858 = call float @llvm.fabs.f32(float %3835)
  %3859 = fcmp olt float %3858, +inf
  %3860 = and i1 %3857, %3859
  %3861 = select i1 %3860, float 0.000000e+00, float %3856
  br label %3862

3862:                                             ; preds = %3849, %3850
  %3863 = phi float [ %3861, %3850 ], [ %3844, %3849 ]
  br label %3864

3864:                                             ; preds = %3862
  %3865 = add i64 %91, %57
  %3866 = icmp slt i64 %3865, %26
  %3867 = select i1 %3866, i64 %3865, i64 0
  %3868 = extractelement <8 x float> %3764, i64 3
  %3869 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3870 = getelementptr inbounds nuw i8, ptr %3869, i64 %3867
  %3871 = load i8, ptr %3870, align 1
  %3872 = zext i8 %3871 to i32
  %3873 = shl i32 %3872, 23
  %3874 = bitcast i32 %3873 to float
  %3875 = fmul float %3874, %3868
  %3876 = extractelement <8 x float> %636, i64 3
  %3877 = fmul float %3876, %3875
  %3878 = call float @llvm.fabs.f32(float %3875)
  %3879 = fcmp olt float %3878, +inf
  %3880 = fcmp one float %3875, 0.000000e+00
  %3881 = and i1 %3879, %3880
  br i1 %3881, label %3882, label %3883

3882:                                             ; preds = %3864
  br label %3895

3883:                                             ; preds = %3864
  %3884 = fpext float %3876 to double
  %3885 = fpext float %3874 to double
  %3886 = fpext float %3868 to double
  %3887 = fmul double %3884, %3885
  %3888 = fmul double %3887, %3886
  %3889 = fptrunc double %3888 to float
  %3890 = fcmp oeq float %3876, 0.000000e+00
  %3891 = call float @llvm.fabs.f32(float %3868)
  %3892 = fcmp olt float %3891, +inf
  %3893 = and i1 %3890, %3892
  %3894 = select i1 %3893, float 0.000000e+00, float %3889
  br label %3895

3895:                                             ; preds = %3882, %3883
  %3896 = phi float [ %3894, %3883 ], [ %3877, %3882 ]
  br label %3897

3897:                                             ; preds = %3895
  %3898 = add i64 %91, %57
  %3899 = icmp slt i64 %3898, %26
  %3900 = select i1 %3899, i64 %3898, i64 0
  %3901 = extractelement <8 x float> %3764, i64 4
  %3902 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3903 = getelementptr inbounds nuw i8, ptr %3902, i64 %3900
  %3904 = load i8, ptr %3903, align 1
  %3905 = zext i8 %3904 to i32
  %3906 = shl i32 %3905, 23
  %3907 = bitcast i32 %3906 to float
  %3908 = fmul float %3907, %3901
  %3909 = extractelement <8 x float> %636, i64 4
  %3910 = fmul float %3909, %3908
  %3911 = call float @llvm.fabs.f32(float %3908)
  %3912 = fcmp olt float %3911, +inf
  %3913 = fcmp one float %3908, 0.000000e+00
  %3914 = and i1 %3912, %3913
  br i1 %3914, label %3915, label %3916

3915:                                             ; preds = %3897
  br label %3928

3916:                                             ; preds = %3897
  %3917 = fpext float %3909 to double
  %3918 = fpext float %3907 to double
  %3919 = fpext float %3901 to double
  %3920 = fmul double %3917, %3918
  %3921 = fmul double %3920, %3919
  %3922 = fptrunc double %3921 to float
  %3923 = fcmp oeq float %3909, 0.000000e+00
  %3924 = call float @llvm.fabs.f32(float %3901)
  %3925 = fcmp olt float %3924, +inf
  %3926 = and i1 %3923, %3925
  %3927 = select i1 %3926, float 0.000000e+00, float %3922
  br label %3928

3928:                                             ; preds = %3915, %3916
  %3929 = phi float [ %3927, %3916 ], [ %3910, %3915 ]
  br label %3930

3930:                                             ; preds = %3928
  %3931 = add i64 %91, %57
  %3932 = icmp slt i64 %3931, %26
  %3933 = select i1 %3932, i64 %3931, i64 0
  %3934 = extractelement <8 x float> %3764, i64 5
  %3935 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3936 = getelementptr inbounds nuw i8, ptr %3935, i64 %3933
  %3937 = load i8, ptr %3936, align 1
  %3938 = zext i8 %3937 to i32
  %3939 = shl i32 %3938, 23
  %3940 = bitcast i32 %3939 to float
  %3941 = fmul float %3940, %3934
  %3942 = extractelement <8 x float> %636, i64 5
  %3943 = fmul float %3942, %3941
  %3944 = call float @llvm.fabs.f32(float %3941)
  %3945 = fcmp olt float %3944, +inf
  %3946 = fcmp one float %3941, 0.000000e+00
  %3947 = and i1 %3945, %3946
  br i1 %3947, label %3948, label %3949

3948:                                             ; preds = %3930
  br label %3961

3949:                                             ; preds = %3930
  %3950 = fpext float %3942 to double
  %3951 = fpext float %3940 to double
  %3952 = fpext float %3934 to double
  %3953 = fmul double %3950, %3951
  %3954 = fmul double %3953, %3952
  %3955 = fptrunc double %3954 to float
  %3956 = fcmp oeq float %3942, 0.000000e+00
  %3957 = call float @llvm.fabs.f32(float %3934)
  %3958 = fcmp olt float %3957, +inf
  %3959 = and i1 %3956, %3958
  %3960 = select i1 %3959, float 0.000000e+00, float %3955
  br label %3961

3961:                                             ; preds = %3948, %3949
  %3962 = phi float [ %3960, %3949 ], [ %3943, %3948 ]
  br label %3963

3963:                                             ; preds = %3961
  %3964 = add i64 %91, %57
  %3965 = icmp slt i64 %3964, %26
  %3966 = select i1 %3965, i64 %3964, i64 0
  %3967 = extractelement <8 x float> %3764, i64 6
  %3968 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %3969 = getelementptr inbounds nuw i8, ptr %3968, i64 %3966
  %3970 = load i8, ptr %3969, align 1
  %3971 = zext i8 %3970 to i32
  %3972 = shl i32 %3971, 23
  %3973 = bitcast i32 %3972 to float
  %3974 = fmul float %3973, %3967
  %3975 = extractelement <8 x float> %636, i64 6
  %3976 = fmul float %3975, %3974
  %3977 = call float @llvm.fabs.f32(float %3974)
  %3978 = fcmp olt float %3977, +inf
  %3979 = fcmp one float %3974, 0.000000e+00
  %3980 = and i1 %3978, %3979
  br i1 %3980, label %3981, label %3982

3981:                                             ; preds = %3963
  br label %3994

3982:                                             ; preds = %3963
  %3983 = fpext float %3975 to double
  %3984 = fpext float %3973 to double
  %3985 = fpext float %3967 to double
  %3986 = fmul double %3983, %3984
  %3987 = fmul double %3986, %3985
  %3988 = fptrunc double %3987 to float
  %3989 = fcmp oeq float %3975, 0.000000e+00
  %3990 = call float @llvm.fabs.f32(float %3967)
  %3991 = fcmp olt float %3990, +inf
  %3992 = and i1 %3989, %3991
  %3993 = select i1 %3992, float 0.000000e+00, float %3988
  br label %3994

3994:                                             ; preds = %3981, %3982
  %3995 = phi float [ %3993, %3982 ], [ %3976, %3981 ]
  br label %3996

3996:                                             ; preds = %3994
  %3997 = add i64 %91, %57
  %3998 = icmp slt i64 %3997, %26
  %3999 = select i1 %3998, i64 %3997, i64 0
  %4000 = extractelement <8 x float> %3764, i64 7
  %4001 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %38, 1
  %4002 = getelementptr inbounds nuw i8, ptr %4001, i64 %3999
  %4003 = load i8, ptr %4002, align 1
  %4004 = zext i8 %4003 to i32
  %4005 = shl i32 %4004, 23
  %4006 = bitcast i32 %4005 to float
  %4007 = fmul float %4006, %4000
  %4008 = extractelement <8 x float> %636, i64 7
  %4009 = fmul float %4008, %4007
  %4010 = call float @llvm.fabs.f32(float %4007)
  %4011 = fcmp olt float %4010, +inf
  %4012 = fcmp one float %4007, 0.000000e+00
  %4013 = and i1 %4011, %4012
  br i1 %4013, label %4014, label %4015

4014:                                             ; preds = %3996
  br label %4027

4015:                                             ; preds = %3996
  %4016 = fpext float %4008 to double
  %4017 = fpext float %4006 to double
  %4018 = fpext float %4000 to double
  %4019 = fmul double %4016, %4017
  %4020 = fmul double %4019, %4018
  %4021 = fptrunc double %4020 to float
  %4022 = fcmp oeq float %4008, 0.000000e+00
  %4023 = call float @llvm.fabs.f32(float %4000)
  %4024 = fcmp olt float %4023, +inf
  %4025 = and i1 %4022, %4024
  %4026 = select i1 %4025, float 0.000000e+00, float %4021
  br label %4027

4027:                                             ; preds = %4014, %4015
  %4028 = phi float [ %4026, %4015 ], [ %4009, %4014 ]
  br label %4029

4029:                                             ; preds = %4027
  %4030 = mul i64 %58, 8
  %4031 = add i64 %88, %4030
  %4032 = add i64 %91, %57
  %4033 = mul i64 %4031, %26
  %4034 = add i64 %4033, %4032
  %4035 = fptrunc float %3797 to bfloat
  %4036 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4037 = getelementptr inbounds nuw bfloat, ptr %4036, i64 %4034
  store bfloat %4035, ptr %4037, align 2
  %4038 = mul i64 %58, 8
  %4039 = add i64 %4038, 1
  %4040 = add i64 %88, %4039
  %4041 = add i64 %91, %57
  %4042 = mul i64 %4040, %26
  %4043 = add i64 %4042, %4041
  %4044 = fptrunc float %3830 to bfloat
  %4045 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4046 = getelementptr inbounds nuw bfloat, ptr %4045, i64 %4043
  store bfloat %4044, ptr %4046, align 2
  %4047 = mul i64 %58, 8
  %4048 = add i64 %4047, 2
  %4049 = add i64 %88, %4048
  %4050 = add i64 %91, %57
  %4051 = mul i64 %4049, %26
  %4052 = add i64 %4051, %4050
  %4053 = fptrunc float %3863 to bfloat
  %4054 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4055 = getelementptr inbounds nuw bfloat, ptr %4054, i64 %4052
  store bfloat %4053, ptr %4055, align 2
  %4056 = mul i64 %58, 8
  %4057 = add i64 %4056, 3
  %4058 = add i64 %88, %4057
  %4059 = add i64 %91, %57
  %4060 = mul i64 %4058, %26
  %4061 = add i64 %4060, %4059
  %4062 = fptrunc float %3896 to bfloat
  %4063 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4064 = getelementptr inbounds nuw bfloat, ptr %4063, i64 %4061
  store bfloat %4062, ptr %4064, align 2
  %4065 = mul i64 %58, 8
  %4066 = add i64 %4065, 4
  %4067 = add i64 %88, %4066
  %4068 = add i64 %91, %57
  %4069 = mul i64 %4067, %26
  %4070 = add i64 %4069, %4068
  %4071 = fptrunc float %3929 to bfloat
  %4072 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4073 = getelementptr inbounds nuw bfloat, ptr %4072, i64 %4070
  store bfloat %4071, ptr %4073, align 2
  %4074 = mul i64 %58, 8
  %4075 = add i64 %4074, 5
  %4076 = add i64 %88, %4075
  %4077 = add i64 %91, %57
  %4078 = mul i64 %4076, %26
  %4079 = add i64 %4078, %4077
  %4080 = fptrunc float %3962 to bfloat
  %4081 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4082 = getelementptr inbounds nuw bfloat, ptr %4081, i64 %4079
  store bfloat %4080, ptr %4082, align 2
  %4083 = mul i64 %58, 8
  %4084 = add i64 %4083, 6
  %4085 = add i64 %88, %4084
  %4086 = add i64 %91, %57
  %4087 = mul i64 %4085, %26
  %4088 = add i64 %4087, %4086
  %4089 = fptrunc float %3995 to bfloat
  %4090 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4091 = getelementptr inbounds nuw bfloat, ptr %4090, i64 %4088
  store bfloat %4089, ptr %4091, align 2
  %4092 = mul i64 %58, 8
  %4093 = add i64 %4092, 7
  %4094 = add i64 %88, %4093
  %4095 = add i64 %91, %57
  %4096 = mul i64 %4094, %26
  %4097 = add i64 %4096, %4095
  %4098 = fptrunc float %4028 to bfloat
  %4099 = extractvalue { ptr, ptr, i64, [1 x i64], [1 x i64] } %33, 1
  %4100 = getelementptr inbounds nuw bfloat, ptr %4099, i64 %4097
  store bfloat %4098, ptr %4100, align 2
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.signal(i32 immarg) #3

; Function Attrs: convergent nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier.wait(i16 immarg) #3

; Function Attrs: convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare <8 x float> @llvm.amdgcn.wmma.f32.16x16x16.fp8.fp8.v8f32.v2i32(<2 x i32>, <2 x i32>, <8 x float>) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fabs.f32(float) #5

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #5

attributes #0 = { "amdgpu-flat-work-group-size"="256,256" "target-features"="-cumode" "uniform-work-group-size" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { convergent nocallback nofree nounwind willreturn }
attributes #4 = { convergent nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 256, i32 1, i32 1}
!2 = !{!"amdgpu-synchronize-as", !"local"}
