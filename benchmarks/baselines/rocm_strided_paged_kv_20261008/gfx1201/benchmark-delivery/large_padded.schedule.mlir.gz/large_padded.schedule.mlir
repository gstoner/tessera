module attributes {tessera.arch = "gfx1201", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.target = "rocm_gfx1201"} {
  func.func @paged_full(%arg0: tensor<32x16x8x128xf32> {tessera.layout = "strided"}, %arg1: tensor<64xi32>) -> tensor<1024x8x128xf32> attributes {tessera.bindings = ["a0", "a1", "v0"], tessera.frontend.authority = "tracer", tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "c754085d55b2dfdc01758b11f1761205a49ed509abeaa8d28a787fb162a90553", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %0 = tessera.paged_kv_read %arg0, %arg1 {end = 1024 : i64, schedule.artifact_hash = "fb63d6b9dbf0cc4f0d62d0a7bb3ee1b27d3bebdee821f254ea9662c7867a48f9", start = 0 : i64} : (tensor<32x16x8x128xf32>, tensor<64xi32>) -> tensor<1024x8x128xf32>
    %1 = schedule.paged_kv_read %0 {artifact_hash = "fb63d6b9dbf0cc4f0d62d0a7bb3ee1b27d3bebdee821f254ea9662c7867a48f9", contract = {arch = "gfx1201", bindings = ["a0", "a1", "v0"], layout = "strided", page_ownership = "read_only_borrow", page_stride_policy = "positive_runtime_element_strides", shape = array<i64: 32, 64, 16, 8, 128, 0, 1024>, source_extent_policy = "checked_physical_span", table_bounds = "runtime_checked_physical_page_indices", target = "rocm_gfx1201"}} : tensor<1024x8x128xf32> -> tensor<1024x8x128xf32>
    return %1 : tensor<1024x8x128xf32>
  }
}

