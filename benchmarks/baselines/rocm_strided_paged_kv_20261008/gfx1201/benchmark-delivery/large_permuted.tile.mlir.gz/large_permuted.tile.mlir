module attributes {tessera.arch = "gfx1201", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.target = "rocm_gfx1201"} {
  llvm.func @tessera_tile_paged_kv_read_f32_strided(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: i64, %arg8: i64, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64) attributes {tessera.native_contract = {arch = "gfx1201", bindings = ["a0", "a1", "v0"], layout = "strided", page_ownership = "read_only_borrow", page_stride_policy = "positive_runtime_element_strides", shape = array<i64: 32, 64, 16, 8, 128, 0, 1024>, source_extent_policy = "checked_physical_span", table_bounds = "runtime_checked_physical_page_indices", target = "rocm_gfx1201"}, tessera.schedule_hash = "fb63d6b9dbf0cc4f0d62d0a7bb3ee1b27d3bebdee821f254ea9662c7867a48f9"} {
    tile.paged_kv_read_kernel %arg0, %arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13 {page_layout = "strided", route = "direct", storage = "f32", table_storage = "i32"} : !llvm.ptr, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64
    llvm.return
  }
}

