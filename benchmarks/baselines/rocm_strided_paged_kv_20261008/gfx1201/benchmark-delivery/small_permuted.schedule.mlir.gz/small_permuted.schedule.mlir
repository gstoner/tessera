module attributes {tessera.arch = "gfx1201", tessera.frontend.authority = "tracer", tessera.ir.version = "1.0", tessera.target = "rocm_gfx1201"} {
  func.func @paged_full(%arg0: tensor<4x256x3x8xf32> {tessera.layout = "strided"}, %arg1: tensor<4xi32>) -> tensor<1024x3x8xf32> attributes {tessera.bindings = ["a0", "a1", "v0"], tessera.frontend.authority = "tracer", tessera.structured_cfg.blocks = 2 : i64, tessera.structured_cfg.digest = "c754085d55b2dfdc01758b11f1761205a49ed509abeaa8d28a787fb162a90553", tessera.structured_cfg.schema = "tessera.structured_cfg.v1"} {
    %0 = tessera.paged_kv_read %arg0, %arg1 {end = 1024 : i64, schedule.artifact_hash = "b7e3338ee8c01debe0f093bd194160acdb7983e2a021e55a5f92489661101f84", start = 0 : i64} : (tensor<4x256x3x8xf32>, tensor<4xi32>) -> tensor<1024x3x8xf32>
    %1 = schedule.paged_kv_read %0 {artifact_hash = "b7e3338ee8c01debe0f093bd194160acdb7983e2a021e55a5f92489661101f84", contract = {arch = "gfx1201", bindings = ["a0", "a1", "v0"], layout = "strided", page_ownership = "read_only_borrow", page_stride_policy = "positive_runtime_element_strides", shape = array<i64: 4, 4, 256, 3, 8, 0, 1024>, source_extent_policy = "checked_physical_span", table_bounds = "runtime_checked_physical_page_indices", target = "rocm_gfx1201"}} : tensor<1024x3x8xf32> -> tensor<1024x3x8xf32>
    return %1 : tensor<1024x3x8xf32>
  }
}

