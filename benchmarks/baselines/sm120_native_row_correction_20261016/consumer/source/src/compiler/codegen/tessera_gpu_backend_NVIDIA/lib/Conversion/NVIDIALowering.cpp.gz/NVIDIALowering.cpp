#include "Tessera/IR/TileBufferViewContract.h"
#include "Tessera/IR/RowRegionContract.h"
#include "mlir/Dialect/GPU/IR/GPUDialect.h"
#include "tessera/gpu/BackendRegistration.h"
#include "Tessera/Dialect/Tile/TileDialect.h"
#include "Tessera/Dialect/Tile/TileEpilogue.h"
#include "Tessera/Transforms/Passes.h"

#include "mlir/Dialect/Arith/IR/Arith.h"
#include "mlir/Dialect/Bufferization/IR/Bufferization.h"
#include "mlir/Dialect/Func/IR/FuncOps.h"
#include "mlir/Dialect/LLVMIR/LLVMDialect.h"
#include "mlir/Dialect/LLVMIR/NVVMDialect.h"
#include "mlir/Dialect/NVGPU/IR/NVGPUDialect.h"
#include "mlir/Conversion/NVGPUToNVVM/NVGPUToNVVM.h"
#include "mlir/Dialect/Math/IR/Math.h"
#include "mlir/Dialect/MemRef/IR/MemRef.h"
#include "mlir/Dialect/SCF/IR/SCF.h"
#include "mlir/Dialect/SCF/Transforms/Patterns.h"
#include "mlir/Dialect/Vector/IR/VectorOps.h"
#include "mlir/IR/Builders.h"
#include "mlir/IR/BuiltinOps.h"
#include "mlir/IR/BuiltinTypes.h"
#include "mlir/IR/Dialect.h"
#include "mlir/IR/ExtensibleDialect.h"
#include "mlir/IR/PatternMatch.h"
#include "mlir/IR/SymbolTable.h"
#include "mlir/Pass/Pass.h"
#include "mlir/Pass/PassManager.h"
#include "mlir/Transforms/DialectConversion.h"

#include <functional>
#include <optional>

#include "TesseraNVIDIADialect.h.inc"
#define GET_OP_CLASSES
#include "TesseraNVIDIAOps.h.inc"

using namespace mlir;

namespace tessera {
namespace {

static constexpr int kHopperSM = 90;
static constexpr int kBlackwellSM = 100;          // datacenter Blackwell (sm_100a)
static constexpr int kConsumerBlackwellSM = 120;  // consumer Blackwell (sm_120)

static StringRef archStringForSM(int sm) {
  if (sm >= 120)
    return "sm_120";
  if (sm >= 100)
    return "sm_100a";
  if (sm >= 90)
    return "sm_90a";
  if (sm >= 80)
    return "sm_80";
  return "sm_unknown";
}

static bool isTileOp(Operation *op, StringRef suffix) {
  return op->getName().getStringRef() == suffix;
}

static Operation *createContractOp(OpBuilder &builder, Location loc,
                                   StringRef name, ValueRange operands,
                                   TypeRange results,
                                   ArrayRef<NamedAttribute> attrs = {}) {
  OperationState state(loc, name);
  state.addOperands(operands);
  state.addTypes(results);
  state.addAttributes(attrs);
  return builder.create(state);
}

enum class Sm120InputPacking {
  PairF16,
  ScalarF64,
  ScalarF32,
  PackedX4I8,
  PackedX8E2M1,
};

struct Sm120FragmentDescriptor {
  StringRef dtype;
  int64_t k;
  StringRef accumulator;
  Sm120InputPacking packing;
  unsigned aRegistersPerLane;
  unsigned bRegistersPerLane;
  unsigned accumulatorRegistersPerLane;
  StringRef instructionFamily;
};

static std::optional<Sm120FragmentDescriptor>
selectSm120Fragment(tessera::tile::TileMmaDescAttr desc) {
  if (!desc || (desc.getFamily() != "auto" && desc.getFamily() != "mma_sync" &&
                desc.getFamily() != "mma_sync_block_scale") ||
      desc.getAType() != desc.getBType() ||
      desc.getALayout() != "row_major" || desc.getBLayout() != "col_major" ||
      desc.getKBlocks() != 1)
    return std::nullopt;
  StringRef dtype = desc.getAType();
  if (dtype == "f64" && desc.getM() == 8 && desc.getN() == 8 &&
      desc.getK() == 4 && desc.getAccType() == "f64")
    return Sm120FragmentDescriptor{
        dtype, 4, "f64", Sm120InputPacking::ScalarF64, 1, 1, 2,
        "mma.sync.aligned.m8n8k4.row.col.f64.f64.f64.f64"};
  if (desc.getM() != 16 || desc.getN() != 8)
    return std::nullopt;
  if (dtype == "nvfp4" && desc.getK() == 64 &&
      desc.getAccType() == "f32")
    return Sm120FragmentDescriptor{
        dtype, 64, "f32", Sm120InputPacking::PackedX8E2M1, 4, 2, 4,
        "mma.sync.aligned.m16n8k64.row.col.kind::mxf4nvf4.block_scale"
        ".scale_vec::4X.f32.e2m1.e2m1.f32.ue4m3"};
  if (dtype == "f16" && desc.getK() == 16 && desc.getAccType() == "f16")
    return Sm120FragmentDescriptor{
        dtype, 16, "f16", Sm120InputPacking::PairF16, 4, 2, 2,
        "mma.sync.aligned.m16n8k16.row.col.f16.f16.f16.f16"};
  if ((dtype == "f16" || dtype == "bf16") && desc.getK() == 16 &&
      desc.getAccType() == "f32")
    return Sm120FragmentDescriptor{
        dtype, 16, "f32", Sm120InputPacking::PairF16, 4, 2, 4,
        dtype == "f16"
            ? "mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32"
            : "mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32"};
  if (dtype == "tf32" && desc.getK() == 8)
    return desc.getAccType() == "f32"
        ? std::optional<Sm120FragmentDescriptor>(Sm120FragmentDescriptor{
              dtype, 8, "f32", Sm120InputPacking::ScalarF32, 4, 2, 4,
              "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32"})
        : std::nullopt;
  if ((dtype == "e4m3" || dtype == "e5m2") && desc.getK() == 32)
    return desc.getAccType() == "f32"
        ? std::optional<Sm120FragmentDescriptor>(Sm120FragmentDescriptor{
              dtype, 32, "f32", Sm120InputPacking::PackedX4I8, 4, 2, 4,
              dtype == "e4m3"
                  ? "mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32"
                  : "mma.sync.aligned.m16n8k32.row.col.f32.e5m2.e5m2.f32"})
        : std::nullopt;
  if ((dtype == "e2m3" || dtype == "e3m2") && desc.getK() == 32 &&
      desc.getAccType() == "f32")
    return Sm120FragmentDescriptor{
        dtype, 32, "f32", Sm120InputPacking::PackedX4I8, 4, 2, 4,
        dtype == "e2m3"
            ? "mma.sync.aligned.m16n8k32.row.col.kind::mxf8f6f4.block_scale"
              ".scale_vec::1X.f32.e2m3.e2m3.f32.ue8m0"
            : "mma.sync.aligned.m16n8k32.row.col.kind::mxf8f6f4.block_scale"
              ".scale_vec::1X.f32.e3m2.e3m2.f32.ue8m0"};
  if (dtype == "fp4_e2m1" && desc.getK() == 64 &&
      desc.getAccType() == "f32")
    return Sm120FragmentDescriptor{
        dtype, 64, "f32", Sm120InputPacking::PackedX8E2M1, 4, 2, 4,
        "mma.sync.aligned.m16n8k64.row.col.kind::mxf4.block_scale"
        ".scale_vec::2X.f32.e2m1.e2m1.f32.ue8m0"};
  if ((dtype == "s8" || dtype == "int8") && desc.getK() == 32)
    return (desc.getAccType() == "s32" || desc.getAccType() == "int32")
        ? std::optional<Sm120FragmentDescriptor>(Sm120FragmentDescriptor{
              dtype, 32, "s32", Sm120InputPacking::PackedX4I8, 4, 2, 4,
              "mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32"})
        : std::nullopt;
  return std::nullopt;
}

static bool isCanonicalSm120Mma16(tessera::tile::TileMmaDescAttr desc) {
  return selectSm120Fragment(desc).has_value();
}

static Value i64Constant(OpBuilder &builder, Location loc, int64_t value) {
  return arith::ConstantIntOp::create(builder, loc, value, 64);
}

static Value addI64(OpBuilder &builder, Location loc, Value lhs, Value rhs) {
  return arith::AddIOp::create(builder, loc, lhs, rhs);
}

static Value mulI64(OpBuilder &builder, Location loc, Value lhs, Value rhs) {
  return arith::MulIOp::create(builder, loc, lhs, rhs);
}

static Value lessI64(OpBuilder &builder, Location loc, Value lhs, Value rhs) {
  return arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ult,
                               lhs, rhs);
}

static Value mask2(OpBuilder &builder, Location loc, Value first, Value second) {
  auto maskTy = VectorType::get({2}, builder.getI1Type());
  Value mask = arith::ConstantOp::create(builder, loc, maskTy,
                                         builder.getZeroAttr(maskTy));
  Value zero = arith::ConstantIntOp::create(builder, loc, 0, 64);
  Value one = arith::ConstantIntOp::create(builder, loc, 1, 64);
  mask = LLVM::InsertElementOp::create(builder, loc, maskTy, mask, first, zero);
  return LLVM::InsertElementOp::create(builder, loc, maskTy, mask, second, one);
}

static Value maskedLoadPair(OpBuilder &builder, Location loc, Value base,
                            Type elementType, Value linear, Value valid0,
                            Value valid1, unsigned alignment) {
  auto pairTy = VectorType::get({2}, elementType);
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), elementType,
                                  base, ValueRange{linear});
  Value passthru = arith::ConstantOp::create(builder, loc, pairTy,
                                              builder.getZeroAttr(pairTy));
  return LLVM::MaskedLoadOp::create(builder, loc, pairTy, ptr,
                                    mask2(builder, loc, valid0, valid1),
                                    passthru, alignment, false);
}

static Value pairFromScalars(OpBuilder &builder, Location loc, Type elementType,
                             Value first, Value second) {
  auto pairTy = VectorType::get({2}, elementType);
  Value pair = arith::ConstantOp::create(builder, loc, pairTy,
                                         builder.getZeroAttr(pairTy));
  Value zero = arith::ConstantIntOp::create(builder, loc, 0, 64);
  Value one = arith::ConstantIntOp::create(builder, loc, 1, 64);
  pair = LLVM::InsertElementOp::create(builder, loc, pairTy, pair, first, zero);
  return LLVM::InsertElementOp::create(builder, loc, pairTy, pair, second, one);
}

static Value maskedLoadScalar(OpBuilder &builder, Location loc, Value base,
                              Type elementType, Value linear, Value valid,
                              unsigned alignment) {
  auto vectorTy = VectorType::get({1}, elementType);
  auto maskTy = VectorType::get({1}, builder.getI1Type());
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), elementType,
                                  base, ValueRange{linear});
  Value passthru = arith::ConstantOp::create(builder, loc, vectorTy,
                                              builder.getZeroAttr(vectorTy));
  Value mask = arith::ConstantOp::create(builder, loc, maskTy,
                                          builder.getZeroAttr(maskTy));
  Value zero = i64Constant(builder, loc, 0);
  mask = LLVM::InsertElementOp::create(builder, loc, maskTy, mask, valid, zero);
  Value loaded = LLVM::MaskedLoadOp::create(builder, loc, vectorTy, ptr, mask,
                                             passthru, alignment, false);
  return LLVM::ExtractElementOp::create(builder, loc, elementType, loaded, zero);
}

static FailureOr<Value> sm120SharedBuffer(Operation *anchor, OpBuilder &builder,
                                          Type elementType, StringRef dtype,
                                          bool doubleBuffered) {
  ModuleOp module = anchor->getParentOfType<ModuleOp>();
  if (!module)
    return failure();
  std::string symbol = ("__tessera_sm120_ab_stage_" + dtype).str();
  auto global = module.lookupSymbol<LLVM::GlobalOp>(symbol);
  // Four warps own a 32x32 CTA macro-tile.  One K panel stages A[32,16]
  // followed by B[32,16] in its column-major physical representation.
  auto arrayTy = LLVM::LLVMArrayType::get(
      elementType, doubleBuffered ? 2048 : 1024);
  if (!global) {
    OpBuilder globalBuilder(module.getBodyRegion());
    globalBuilder.setInsertionPointToStart(module.getBody());
    global = LLVM::GlobalOp::create(
        globalBuilder, anchor->getLoc(), arrayTy, /*isConstant=*/false,
        LLVM::Linkage::Internal, symbol, Attribute(), /*alignment=*/16,
        /*addrSpace=*/3, /*dsoLocal=*/false, /*threadLocal=*/false,
        SymbolRefAttr(), ArrayRef<NamedAttribute>{}, ArrayRef<Attribute>{});
  }
  return Value(LLVM::AddressOfOp::create(builder, anchor->getLoc(), global));
}

static FailureOr<Value> sm120ReductionScratch(Operation *anchor,
                                              OpBuilder &builder) {
  ModuleOp module = anchor->getParentOfType<ModuleOp>();
  if (!module)
    return failure();
  constexpr StringLiteral symbol = "__tessera_sm120_reduce_scratch_f32";
  auto global = module.lookupSymbol<LLVM::GlobalOp>(symbol);
  auto arrayTy = LLVM::LLVMArrayType::get(builder.getF32Type(), 128);
  if (!global) {
    OpBuilder globalBuilder(module.getBodyRegion());
    globalBuilder.setInsertionPointToStart(module.getBody());
    global = LLVM::GlobalOp::create(
        globalBuilder, anchor->getLoc(), arrayTy, /*isConstant=*/false,
        LLVM::Linkage::Internal, symbol, Attribute(), /*alignment=*/16,
        /*addrSpace=*/3, /*dsoLocal=*/false, /*threadLocal=*/false,
        SymbolRefAttr(), ArrayRef<NamedAttribute>{}, ArrayRef<Attribute>{});
  }
  return Value(LLVM::AddressOfOp::create(builder, anchor->getLoc(), global));
}

// Launch-level general-shape NVFP4 materialization.  The portable ABI carries
// packed E2M1 A/B, logical UE4M3 scale-A/scale-B views, D, and runtime M/N/K.
// One warp owns each 16x8 output tile and accumulates K64 fragments.  Ragged
// matrix/scale reads zero-fill and output stores are masked.
static LogicalResult requireStoragePackDescriptor(
    Operation *op, StringRef logical, int64_t factor,
    StringRef signedness = "format_defined") {
  auto packed = op->getAttrOfType<BoolAttr>("tessera.storage_packed");
  auto container = op->getAttrOfType<StringAttr>("tessera.storage_container");
  auto descriptor =
      op->getAttrOfType<tessera::tile::TilePackedFormatAttr>(
          "tessera.storage_pack");
  if (!packed || !packed.getValue() || !container ||
      container.getValue() != "int8" || !descriptor) {
    op->emitError("NVIDIA packed matmul requires terminal storage legalization "
                  "with an int8 tessera.storage_pack descriptor");
    return failure();
  }
  int64_t expectedBits = logical.starts_with("fp6_") ? 6 : 4;
  if (descriptor.getLogicalType() != logical ||
      descriptor.getContainerType() != "int8" ||
      descriptor.getLogicalBits() != expectedBits ||
      descriptor.getElementsPerContainer() != factor ||
      descriptor.getSignedness() != signedness) {
    op->emitError("NVIDIA packed matmul storage descriptor disagrees with the "
                  "selected physical fragment ABI");
    return failure();
  }
  return success();
}

// Canonical signed-int4 storage consumer. A is row-major with K packed along
// each row; B is column-major with K packed down each column. Two two's-
// complement nibbles occupy every int8 container byte, low logical index in
// the low nibble. This correctness schedule deliberately owns only the
// load/decode/accumulate/store ABI; selector promotion to an s4 MMA or dp4a
// schedule requires separate comparative evidence.
static LogicalResult materializeSm120Int4MatmulKernel(
    tessera::tile::MatmulKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto epilogue = op->getAttrOfType<tessera::tile::TileEpilogueAttr>("epilogue");
  if (!desc || (desc.getAType() != "int4" && desc.getAType() != "s4") ||
      desc.getBType() != desc.getAType() ||
      (desc.getAccType() != "int32" && desc.getAccType() != "s32") ||
      !epilogue || epilogue.getOutputType() != "i32" ||
      epilogue.getBias() || epilogue.getActivation() != "none" ||
      kernel.getInputs().size() != 6) {
    op->emitError("sm_120 INT4 matmul requires packed A/B, i32 D, M/N/K, "
                  "signed i32 accumulation, and no scale or fused epilogue");
    return failure();
  }
  if (failed(requireStoragePackDescriptor(
          op, "int4", 2, "signed_twos_complement")))
    return failure();
  if (auto attr = op->getAttrOfType<StringAttr>("staging");
      !attr || attr.getValue() != "global") {
    op->emitError("sm_120 INT4 packed consumer requires direct global staging");
    return failure();
  }

  ValueRange inputs = kernel.getInputs();
  Value aBase = inputs[0], bBase = inputs[1], dBase = inputs[2];
  Value m = inputs[3], n = inputs[4], k = inputs[5];
  Location loc = op->getLoc();
  Type i8 = builder.getI8Type();
  Type i32 = builder.getI32Type();
  Value one = i64Constant(builder, loc, 1);
  Value two = i64Constant(builder, loc, 2);
  Value packedK = arith::DivUIOp::create(
      builder, loc, addI64(builder, loc, k, one), two);
  Value tidX = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value tidY = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::ThreadIdYOp::create(builder, loc, i32));
  Value blockX = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::BlockIdXOp::create(builder, loc, i32));
  Value blockY = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::BlockIdYOp::create(builder, loc, i32));
  Value row = addI64(
      builder, loc, mulI64(builder, loc, blockY,
                           i64Constant(builder, loc, 8)), tidY);
  Value col = addI64(
      builder, loc, mulI64(builder, loc, blockX,
                           i64Constant(builder, loc, 32)), tidX);
  Value valid = arith::AndIOp::create(
      builder, loc, lessI64(builder, loc, row, m),
      lessI64(builder, loc, col, n));
  auto guarded = scf::IfOp::create(builder, loc, valid, false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(&guarded.getThenRegion().front());
    Value zero64 = i64Constant(builder, loc, 0);
    Value zero32 = arith::ConstantIntOp::create(builder, loc, 0, 32);
    auto loop = scf::ForOp::create(
        builder, loc, zero64, k, one, ValueRange{zero32});
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(loop.getBody());
      Value logicalK = loop.getInductionVar();
      Value byteK = arith::DivUIOp::create(builder, loc, logicalK, two);
      Value aLinear = addI64(
          builder, loc, mulI64(builder, loc, row, packedK), byteK);
      Value bLinear = addI64(
          builder, loc, mulI64(builder, loc, byteK, n), col);
      Value aByte = LLVM::LoadOp::create(
          builder, loc, i8,
          LLVM::GEPOp::create(builder, loc, aBase.getType(), i8, aBase,
                              ValueRange{aLinear}),
          1);
      Value bByte = LLVM::LoadOp::create(
          builder, loc, i8,
          LLVM::GEPOp::create(builder, loc, bBase.getType(), i8, bBase,
                              ValueRange{bLinear}),
          1);
      Value parity64 = arith::RemUIOp::create(builder, loc, logicalK, two);
      Value shift64 = mulI64(builder, loc, parity64,
                             i64Constant(builder, loc, 4));
      Value shift = arith::TruncIOp::create(builder, loc, i32, shift64);
      auto decode = [&](Value byte) {
        Value wide = arith::ExtUIOp::create(builder, loc, i32, byte);
        Value nibble = arith::AndIOp::create(
            builder, loc,
            arith::ShRUIOp::create(builder, loc, wide, shift),
            arith::ConstantIntOp::create(builder, loc, 15, 32));
        Value signBit = arith::AndIOp::create(
            builder, loc, nibble,
            arith::ConstantIntOp::create(builder, loc, 8, 32));
        Value negative = arith::CmpIOp::create(
            builder, loc, arith::CmpIPredicate::ne, signBit, zero32);
        return Value(arith::SelectOp::create(
            builder, loc, negative,
            arith::SubIOp::create(
                builder, loc, nibble,
                arith::ConstantIntOp::create(builder, loc, 16, 32)),
            nibble));
      };
      Value product = arith::MulIOp::create(
          builder, loc, decode(aByte), decode(bByte));
      scf::YieldOp::create(
          builder, loc,
          ValueRange{arith::AddIOp::create(
              builder, loc, loop.getRegionIterArgs()[0], product)});
    }
    builder.setInsertionPointAfter(loop);
    Value linear = addI64(builder, loc, mulI64(builder, loc, row, n), col);
    LLVM::StoreOp::create(
        builder, loc, loop.getResult(0),
        LLVM::GEPOp::create(builder, loc, dBase.getType(), i32, dBase,
                            ValueRange{linear}),
        4);
  }
  op->erase();
  return success();
}

static LogicalResult materializeSm120Nvfp4MatmulKernel(
    tessera::tile::MatmulKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto epilogue = op->getAttrOfType<tessera::tile::TileEpilogueAttr>("epilogue");
  auto batchPolicy = op->getAttrOfType<StringAttr>("batching");
  const bool independentRhs = batchPolicy && batchPolicy.getValue() == "independent_rhs";
  const bool sharedLhs = batchPolicy && batchPolicy.getValue() == "shared_lhs";
  const bool batched = independentRhs || sharedLhs || (batchPolicy && batchPolicy.getValue() == "shared_rhs_rows");
  std::optional<Sm120FragmentDescriptor> physical = selectSm120Fragment(desc);
  if (!physical || physical->packing != Sm120InputPacking::PackedX8E2M1 ||
      !epilogue || epilogue.getBias() || epilogue.getActivation() != "none" ||
      epilogue.getOutputType() != "f32" || kernel.getInputs().size() != (batched ? 10u : 8u)) {
    op->emitError("sm_120 NVFP4 matmul_kernel requires packed A/B, scale A/B, "
                  "D, M/N/K, f32 output, and no fused epilogue");
    return failure();
  }
  if (failed(requireStoragePackDescriptor(op, "nvfp4", 2)))
    return failure();
  auto physicalContract = op->getAttrOfType<StringAttr>("physical_contract");
  auto scaleVector =
      op->getAttrOfType<IntegerAttr>("tessera.scale_vector_size");
  if (!physicalContract ||
      physicalContract.getValue() != "nvidia_sm120_nvfp4_blockscale_v1" ||
      !scaleVector || scaleVector.getInt() != 16) {
    op->emitError("SM120 NVFP4 Tile requires the named K16 block-scale contract");
    return failure();
  }
  for (StringRef name : {"transposeA", "transposeB"}) {
    Attribute value = op->getAttr(name);
    if (value && !isa<BoolAttr>(value)) {
      op->emitError("SM120 NVFP4 orientation flags must be boolean");
      return failure();
    }
  }
  auto orientation = [&](StringRef name) {
    auto value = op->getAttrOfType<BoolAttr>(name);
    return value && value.getValue();
  };
  const bool transposeA = orientation("transposeA");
  const bool transposeB = orientation("transposeB");
  ValueRange inputs = kernel.getInputs();
  Value aBase = inputs[0], bBase = inputs[1];
  Value scaleABase = inputs[2], scaleBBase = inputs[3];
  Value dBase = inputs[4];
  Value m = inputs[5], n = inputs[6], k = inputs[7];
  Location loc = op->getLoc();
  Type i8 = builder.getI8Type();
  Type i32 = builder.getI32Type();
  auto f32 = builder.getF32Type();
  Value zero64 = i64Constant(builder, loc, 0);
  Value one64 = i64Constant(builder, loc, 1);
  Value two64 = i64Constant(builder, loc, 2);
  Value four64 = i64Constant(builder, loc, 4);
  Value sixteen64 = i64Constant(builder, loc, 16);
  Value thirtyTwo64 = i64Constant(builder, loc, 32);
  Value sixtyFour64 = i64Constant(builder, loc, 64);
  Value zero32 = arith::ConstantIntOp::create(builder, loc, 0, 32);

  Value blockX32 = NVVM::BlockIdXOp::create(builder, loc, i32);
  Value blockY32 = NVVM::BlockIdYOp::create(builder, loc, i32);
  Value blockX = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockX32);
  Value blockY = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockY32);
  Value localBlockY = blockY;
  Value batchIndex = zero64;
  if (batched) {
    m = inputs[8];
    Value rowsPerBatchTile = arith::DivUIOp::create(
        builder, loc, addI64(builder, loc, m, i64Constant(builder, loc, 15)), sixteen64);
    batchIndex = arith::DivUIOp::create(builder, loc, blockY, rowsPerBatchTile);
    localBlockY = arith::RemUIOp::create(builder, loc, blockY, rowsPerBatchTile);
  }
  Value mt = mulI64(builder, loc, localBlockY, sixteen64);
  Value nt = mulI64(builder, loc, blockX, i64Constant(builder, loc, 8));
  Value tid = NVVM::ThreadIdXOp::create(builder, loc, i32);
  Value lane = arith::AndIOp::create(
      builder, loc, tid, arith::ConstantIntOp::create(builder, loc, 31, 32));
  Value gid32 = arith::ShRUIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 2, 32));
  Value tig32 = arith::AndIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 3, 32));
  Value gid = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), gid32);
  Value tig = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), tig32);
  Value eightTig = mulI64(builder, loc, tig, i64Constant(builder, loc, 8));
  Value packedK = arith::DivUIOp::create(
      builder, loc, addI64(builder, loc, k, one64), two64);
  Value scaleK = arith::DivUIOp::create(
      builder, loc, addI64(builder, loc, k, i64Constant(builder, loc, 15)),
      sixteen64);

  if (batched) {
    auto offset = [&](Value base, Type element, Value count) -> Value {
      return LLVM::GEPOp::create(builder, loc, base.getType(), element, base,
                                SmallVector<LLVM::GEPArg>{count});
    };
    Value batchRow = mulI64(builder, loc, batchIndex, m);
    if (!sharedLhs)
      aBase = offset(aBase, i8, mulI64(builder, loc, batchRow, packedK));
    if (independentRhs || sharedLhs)
      bBase = offset(bBase, i8, mulI64(builder, loc, batchIndex,
          mulI64(builder, loc, packedK, n)));
    if (!sharedLhs)
      scaleABase = offset(scaleABase, i8, mulI64(builder, loc, batchRow, scaleK));
    if (independentRhs || sharedLhs)
      scaleBBase = offset(scaleBBase, i8, mulI64(builder, loc, batchIndex,
          mulI64(builder, loc, scaleK, n)));
    dBase = offset(dBase, f32, mulI64(builder, loc, batchRow, n));
  }

  auto packCodes = [&](Value base, Value row, Value col, bool operandA) {
    Value word = zero32;
    for (int64_t j = 0; j < 8; ++j) {
      Value logicalRow = operandA ? row : addI64(
          builder, loc, row, i64Constant(builder, loc, j));
      Value logicalCol = operandA ? addI64(
          builder, loc, col, i64Constant(builder, loc, j)) : col;
      Value valid = arith::AndIOp::create(
          builder, loc, lessI64(builder, loc, logicalRow, operandA ? m : k),
          lessI64(builder, loc, logicalCol, operandA ? k : n));
      Value contraction = operandA ? logicalCol : logicalRow;
      Value packedIndex = arith::DivUIOp::create(
          builder, loc, contraction, two64);
      Value linear = operandA
          ? addI64(builder, loc, mulI64(builder, loc, logicalRow, packedK),
                   packedIndex)
          : addI64(builder, loc, mulI64(builder, loc, packedIndex, n),
                   logicalCol);
      if (operandA && transposeA)
        linear = addI64(builder, loc, mulI64(builder, loc, packedIndex, m), logicalRow);
      if (!operandA && transposeB)
        linear = addI64(builder, loc, mulI64(builder, loc, logicalCol, packedK), packedIndex);
      Value byte = maskedLoadScalar(builder, loc, base, i8, linear, valid, 1);
      Value extended = arith::ExtUIOp::create(builder, loc, i32, byte);
      Value parity64 = arith::RemUIOp::create(
          builder, loc, contraction, two64);
      Value shift64 = mulI64(builder, loc, parity64, four64);
      Value shift = arith::TruncIOp::create(builder, loc, i32, shift64);
      Value code = arith::ShRUIOp::create(builder, loc, extended, shift);
      code = arith::AndIOp::create(
          builder, loc, code, arith::ConstantIntOp::create(builder, loc, 15, 32));
      if (j != 0)
        code = arith::ShLIOp::create(
            builder, loc, code,
            arith::ConstantIntOp::create(builder, loc, 4 * j, 32));
      word = arith::OrIOp::create(builder, loc, word, code);
    }
    return word;
  };

  auto packScales = [&](Value base, Value row, Value col, Value kOrigin,
                        Value laneValid, bool operandA) {
    Value word = zero32;
    Value kBlockOrigin = arith::DivUIOp::create(
        builder, loc, kOrigin, sixteen64);
    for (int64_t j = 0; j < 4; ++j) {
      Value kBlock = addI64(
          builder, loc, kBlockOrigin, i64Constant(builder, loc, j));
      Value bound = operandA ? m : n;
      Value outer = operandA ? row : col;
      Value valid = arith::AndIOp::create(
          builder, loc, laneValid,
          arith::AndIOp::create(
              builder, loc, lessI64(builder, loc, outer, bound),
              lessI64(builder, loc, kBlock, scaleK)));
      Value linear = operandA
          ? addI64(builder, loc, mulI64(builder, loc, row, scaleK), kBlock)
          : addI64(builder, loc, mulI64(builder, loc, kBlock, n), col);
      if (operandA && transposeA)
        linear = addI64(builder, loc, mulI64(builder, loc, kBlock, m), row);
      if (!operandA && transposeB)
        linear = addI64(builder, loc, mulI64(builder, loc, col, scaleK), kBlock);
      Value byte = maskedLoadScalar(builder, loc, base, i8, linear, valid, 1);
      Value extended = arith::ExtUIOp::create(builder, loc, i32, byte);
      if (j != 0)
        extended = arith::ShLIOp::create(
            builder, loc, extended,
            arith::ConstantIntOp::create(builder, loc, 8 * j, 32));
      word = arith::OrIOp::create(builder, loc, word, extended);
    }
    return word;
  };

  Value zeroF32 = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
  SmallVector<Value> init(4, zeroF32);
  auto loop = scf::ForOp::create(builder, loc, zero64, k, sixtyFour64, init);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(loop.getBody());
    Value kOrigin = loop.getInductionVar();
    Value row0 = addI64(builder, loc, mt, gid);
    Value row1 = addI64(builder, loc, row0, i64Constant(builder, loc, 8));
    Value aCol0 = addI64(builder, loc, kOrigin, eightTig);
    Value aCol1 = addI64(builder, loc, aCol0, thirtyTwo64);
    Value bRow0 = addI64(builder, loc, kOrigin, eightTig);
    Value bRow1 = addI64(builder, loc, bRow0, thirtyTwo64);
    Value bCol = addI64(builder, loc, nt, gid);
    SmallVector<Value> operands = {
        packCodes(aBase, row0, aCol0, true),
        packCodes(aBase, row1, aCol0, true),
        packCodes(aBase, row0, aCol1, true),
        packCodes(aBase, row1, aCol1, true),
        packCodes(bBase, bRow0, bCol, false),
        packCodes(bBase, bRow1, bCol, false),
    };
    operands.append(loop.getRegionIterArgs().begin(),
                    loop.getRegionIterArgs().end());
    Value isTig0 = arith::CmpIOp::create(
        builder, loc, arith::CmpIPredicate::eq, tig32, zero32);
    Value isTig1 = arith::CmpIOp::create(
        builder, loc, arith::CmpIPredicate::eq, tig32,
        arith::ConstantIntOp::create(builder, loc, 1, 32));
    Value scaleARow = arith::SelectOp::create(builder, loc, isTig1, row1, row0);
    Value scaleALane = arith::OrIOp::create(builder, loc, isTig0, isTig1);
    operands.push_back(packScales(
        scaleABase, scaleARow, zero64, kOrigin, scaleALane, true));
    operands.push_back(packScales(
        scaleBBase, zero64, bCol, kOrigin, isTig0, false));
    Type resultTy = LLVM::LLVMStructType::getLiteral(
        builder.getContext(), {f32, f32, f32, f32});
    SmallVector<NamedAttribute> attrs = {
        builder.getNamedAttr("arch", builder.getStringAttr("sm_120a")),
        builder.getNamedAttr("shape", builder.getStringAttr("m16n8k64")),
        builder.getNamedAttr("dtype_ab", builder.getStringAttr("nvfp4")),
        builder.getNamedAttr("dtype_c", builder.getStringAttr("f32")),
        builder.getNamedAttr("block_scaled", builder.getBoolAttr(true))};
    Operation *mma = createContractOp(
        builder, loc, "tessera_nvidia.nvfp4_block_scale_mma", operands,
        TypeRange{resultTy}, attrs);
    SmallVector<Value> next;
    for (int64_t index = 0; index < 4; ++index)
      next.push_back(LLVM::ExtractValueOp::create(
          builder, loc, f32, mma->getResult(0), ArrayRef<int64_t>{index}));
    scf::YieldOp::create(builder, loc, next);
  }

  builder.setInsertionPointAfter(loop);
  Value outCol = addI64(
      builder, loc, nt,
      arith::ExtUIOp::create(
          builder, loc, builder.getI64Type(),
          arith::MulIOp::create(
              builder, loc, tig32,
              arith::ConstantIntOp::create(builder, loc, 2, 32))));
  Value colValid0 = lessI64(builder, loc, outCol, n);
  Value colValid1 = lessI64(builder, loc, addI64(builder, loc, outCol, one64), n);
  for (unsigned pair = 0; pair < 2; ++pair) {
    Value row = addI64(
        builder, loc, mt,
        pair == 0 ? gid : addI64(builder, loc, gid, i64Constant(builder, loc, 8)));
    Value rowValid = lessI64(builder, loc, row, m);
    Value valid0 = arith::AndIOp::create(builder, loc, rowValid, colValid0);
    Value valid1 = arith::AndIOp::create(builder, loc, rowValid, colValid1);
    Value linear = addI64(builder, loc, mulI64(builder, loc, row, n), outCol);
    Value ptr = LLVM::GEPOp::create(
        builder, loc, dBase.getType(), f32, dBase, ValueRange{linear});
    Value outPair = pairFromScalars(
        builder, loc, f32, loop.getResult(pair * 2),
        loop.getResult(pair * 2 + 1));
    LLVM::MaskedStoreOp::create(
        builder, loc, outPair, ptr, mask2(builder, loc, valid0, valid1), 4);
  }
  op->erase();
  return success();
}

// General-shape OCP MX materialization. FP6 values occupy one byte each (the
// low six bits carry E2M3/E3M2); MXFP4 values are nibble packed. Both use one
// UE8M0 scale per logical 32-value block, unlike NVFP4's UE4M3/16 contract.
static LogicalResult materializeSm120MxMatmulKernel(
    tessera::tile::MatmulKernelOp kernel, OpBuilder &builder,
    const Sm120FragmentDescriptor &physical) {
  Operation *op = kernel.getOperation();
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto epilogue = op->getAttrOfType<tessera::tile::TileEpilogueAttr>("epilogue");
  bool isFP6 = desc && (desc.getAType() == "e2m3" || desc.getAType() == "e3m2");
  bool isMXFP4 = desc && desc.getAType() == "fp4_e2m1";
  if ((!isFP6 && !isMXFP4) || !epilogue || epilogue.getBias() ||
      epilogue.getActivation() != "none" || epilogue.getOutputType() != "f32" ||
      kernel.getInputs().size() != 8) {
    op->emitError("sm_120 FP6/MXFP4 matmul_kernel requires packed A/B, "
                  "UE8M0 scale A/B, D, M/N/K, and f32 output");
    return failure();
  }
  StringRef logical =
      isMXFP4 ? "fp4_e2m1"
              : desc.getAType() == "e2m3" ? "fp6_e2m3" : "fp6_e3m2";
  if (failed(requireStoragePackDescriptor(op, logical, isMXFP4 ? 2 : 1)))
    return failure();
  if (auto attr = op->getAttrOfType<StringAttr>("staging");
      !attr || attr.getValue() != "global") {
    op->emitError("sm_120 FP6/MXFP4 materializer requires direct global staging");
    return failure();
  }
  ValueRange inputs = kernel.getInputs();
  Value aBase = inputs[0], bBase = inputs[1];
  Value scaleABase = inputs[2], scaleBBase = inputs[3], dBase = inputs[4];
  Value m = inputs[5], n = inputs[6], k = inputs[7];
  Location loc = op->getLoc();
  Type i8 = builder.getI8Type();
  Type i32 = builder.getI32Type();
  auto f32 = builder.getF32Type();
  Value one = i64Constant(builder, loc, 1);
  Value two = i64Constant(builder, loc, 2);
  Value eight = i64Constant(builder, loc, 8);
  Value thirtyTwo = i64Constant(builder, loc, 32);
  Value fragmentK = i64Constant(builder, loc, physical.k);
  Value halfK = i64Constant(builder, loc, physical.k / 2);
  int64_t valuesPerRegister = isFP6 ? 4 : 8;
  int64_t scaleBytesPerFragment = isFP6 ? 1 : 2;

  Value blockX32 = NVVM::BlockIdXOp::create(builder, loc, i32);
  Value blockY32 = NVVM::BlockIdYOp::create(builder, loc, i32);
  Value blockX = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockX32);
  Value blockY = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockY32);
  Value rowOrigin = mulI64(builder, loc, blockY, i64Constant(builder, loc, 16));
  Value colOrigin = mulI64(builder, loc, blockX, eight);
  Value tid = NVVM::ThreadIdXOp::create(builder, loc, i32);
  Value lane = arith::AndIOp::create(
      builder, loc, tid, arith::ConstantIntOp::create(builder, loc, 31, 32));
  Value gid32 = arith::ShRUIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 2, 32));
  Value tig32 = arith::AndIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 3, 32));
  Value gid = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), gid32);
  Value tig = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), tig32);
  Value registerOffset = mulI64(
      builder, loc, tig, i64Constant(builder, loc, valuesPerRegister));
  Value packedK = arith::DivUIOp::create(
      builder, loc, addI64(builder, loc, k, one), two);
  Value scaleK = arith::DivUIOp::create(
      builder, loc, addI64(builder, loc, k, i64Constant(builder, loc, 31)),
      thirtyTwo);

  auto packData = [&](Value base, Value row, Value col, bool operandA) {
    Value word = arith::ConstantIntOp::create(builder, loc, 0, 32);
    for (int64_t index = 0; index < valuesPerRegister; ++index) {
      Value logicalRow = operandA ? row : addI64(
          builder, loc, row, i64Constant(builder, loc, index));
      Value logicalCol = operandA ? addI64(
          builder, loc, col, i64Constant(builder, loc, index)) : col;
      Value valid = arith::AndIOp::create(
          builder, loc, lessI64(builder, loc, logicalRow, operandA ? m : k),
          lessI64(builder, loc, logicalCol, operandA ? k : n));
      Value contraction = operandA ? logicalCol : logicalRow;
      Value physicalContraction = isFP6
          ? contraction
          : Value(arith::DivUIOp::create(builder, loc, contraction, two));
      Value leading = isFP6 ? k : packedK;
      Value linear = operandA
          ? addI64(builder, loc, mulI64(builder, loc, logicalRow, leading),
                   physicalContraction)
          : addI64(builder, loc, mulI64(builder, loc, physicalContraction, n),
                   logicalCol);
      Value byte = maskedLoadScalar(builder, loc, base, i8, linear, valid, 1);
      Value code = arith::ExtUIOp::create(builder, loc, i32, byte);
      if (!isFP6) {
        Value parity = arith::RemUIOp::create(builder, loc, contraction, two);
        Value shift64 = mulI64(builder, loc, parity, i64Constant(builder, loc, 4));
        Value shift = arith::TruncIOp::create(builder, loc, i32, shift64);
        code = arith::ShRUIOp::create(builder, loc, code, shift);
        code = arith::AndIOp::create(
            builder, loc, code, arith::ConstantIntOp::create(builder, loc, 15, 32));
      }
      int64_t bits = isFP6 ? 8 : 4;
      if (index != 0)
        code = arith::ShLIOp::create(
            builder, loc, code,
            arith::ConstantIntOp::create(builder, loc, bits * index, 32));
      word = arith::OrIOp::create(builder, loc, word, code);
    }
    return word;
  };

  auto packScale = [&](Value base, Value outer, Value kOrigin,
                       Value laneValid, bool operandA) {
    Value word = arith::ConstantIntOp::create(builder, loc, 0, 32);
    Value blockOrigin = arith::DivUIOp::create(builder, loc, kOrigin, thirtyTwo);
    for (int64_t index = 0; index < scaleBytesPerFragment; ++index) {
      Value block = addI64(
          builder, loc, blockOrigin, i64Constant(builder, loc, index));
      Value valid = arith::AndIOp::create(
          builder, loc, laneValid,
          arith::AndIOp::create(
              builder, loc, lessI64(builder, loc, outer, operandA ? m : n),
              lessI64(builder, loc, block, scaleK)));
      Value linear = operandA
          ? addI64(builder, loc, mulI64(builder, loc, outer, scaleK), block)
          : addI64(builder, loc, mulI64(builder, loc, block, n), outer);
      Value byte = maskedLoadScalar(builder, loc, base, i8, linear, valid, 1);
      Value widened = arith::ExtUIOp::create(builder, loc, i32, byte);
      if (index != 0)
        widened = arith::ShLIOp::create(
            builder, loc, widened,
            arith::ConstantIntOp::create(builder, loc, 8 * index, 32));
      word = arith::OrIOp::create(builder, loc, word, widened);
    }
    return word;
  };

  Value zeroF32 = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
  auto loop = scf::ForOp::create(
      builder, loc, i64Constant(builder, loc, 0), k, fragmentK,
      ValueRange{zeroF32, zeroF32, zeroF32, zeroF32});
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(loop.getBody());
    Value kOrigin = loop.getInductionVar();
    Value row0 = addI64(builder, loc, rowOrigin, gid);
    Value row1 = addI64(builder, loc, row0, eight);
    Value k0 = addI64(builder, loc, kOrigin, registerOffset);
    Value k1 = addI64(builder, loc, k0, halfK);
    Value bCol = addI64(builder, loc, colOrigin, gid);
    SmallVector<Value> operands = {
        packData(aBase, row0, k0, true), packData(aBase, row1, k0, true),
        packData(aBase, row0, k1, true), packData(aBase, row1, k1, true),
        packData(bBase, k0, bCol, false), packData(bBase, k1, bCol, false)};
    operands.append(loop.getRegionIterArgs().begin(),
                    loop.getRegionIterArgs().end());
    Value isTig0 = arith::CmpIOp::create(
        builder, loc, arith::CmpIPredicate::eq, tig32,
        arith::ConstantIntOp::create(builder, loc, 0, 32));
    Value isTig1 = arith::CmpIOp::create(
        builder, loc, arith::CmpIPredicate::eq, tig32,
        arith::ConstantIntOp::create(builder, loc, 1, 32));
    Value scaleARow = arith::SelectOp::create(builder, loc, isTig1, row1, row0);
    operands.push_back(packScale(
        scaleABase, scaleARow, kOrigin,
        arith::OrIOp::create(builder, loc, isTig0, isTig1), true));
    operands.push_back(packScale(scaleBBase, bCol, kOrigin, isTig0, false));
    Type resultTy = LLVM::LLVMStructType::getLiteral(
        builder.getContext(), {f32, f32, f32, f32});
    SmallVector<NamedAttribute> attrs = {
        builder.getNamedAttr("arch", builder.getStringAttr("sm_120a")),
        builder.getNamedAttr("shape", builder.getStringAttr(
            isFP6 ? "m16n8k32" : "m16n8k64")),
        builder.getNamedAttr("dtype_ab", builder.getStringAttr(
            isFP6 ? desc.getAType() : StringRef("e2m1"))),
        builder.getNamedAttr("dtype_c", builder.getStringAttr("f32")),
        builder.getNamedAttr("scale_dtype", builder.getStringAttr("ue8m0")),
        builder.getNamedAttr("scale_vector", builder.getStringAttr(
            isFP6 ? "1X" : "2X")),
        builder.getNamedAttr("block_scaled", builder.getBoolAttr(true))};
    Operation *mma = createContractOp(
        builder, loc, "tessera_nvidia.mx_block_scale_mma", operands,
        TypeRange{resultTy}, attrs);
    SmallVector<Value> next;
    for (int64_t index = 0; index < 4; ++index)
      next.push_back(LLVM::ExtractValueOp::create(
          builder, loc, f32, mma->getResult(0), ArrayRef<int64_t>{index}));
    scf::YieldOp::create(builder, loc, next);
  }

  builder.setInsertionPointAfter(loop);
  Value outCol = addI64(
      builder, loc, colOrigin,
      mulI64(builder, loc, tig, i64Constant(builder, loc, 2)));
  Value colValid0 = lessI64(builder, loc, outCol, n);
  Value colValid1 = lessI64(builder, loc, addI64(builder, loc, outCol, one), n);
  for (unsigned pair = 0; pair < 2; ++pair) {
    Value row = addI64(
        builder, loc, rowOrigin,
        pair == 0 ? gid : addI64(builder, loc, gid, eight));
    Value rowValid = lessI64(builder, loc, row, m);
    Value valid0 = arith::AndIOp::create(builder, loc, rowValid, colValid0);
    Value valid1 = arith::AndIOp::create(builder, loc, rowValid, colValid1);
    Value linear = addI64(builder, loc, mulI64(builder, loc, row, n), outCol);
    Value ptr = LLVM::GEPOp::create(
        builder, loc, dBase.getType(), f32, dBase, ValueRange{linear});
    Value outPair = pairFromScalars(
        builder, loc, f32, loop.getResult(pair * 2),
        loop.getResult(pair * 2 + 1));
    LLVM::MaskedStoreOp::create(
        builder, loc, outPair, ptr, mask2(builder, loc, valid0, valid1), 4);
  }
  op->erase();
  return success();
}

// General-shape launch materialization for the f32-accumulating scalar-f32
// (TF32 math mode) and packed-four-byte (FP8) MMA families.  Storage remains
// explicit: TF32 consumes ordinary f32 memory while FP8 consumes one byte per
// logical element.  One warp owns each m16n8 output tile; ragged reads zero-fill
// before register packing and stores are masked.
static LogicalResult materializeSm120F32PackedMatmulKernel(
    tessera::tile::MatmulKernelOp kernel, OpBuilder &builder,
    const Sm120FragmentDescriptor &physical) {
  Operation *op = kernel.getOperation();
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto epilogue = op->getAttrOfType<tessera::tile::TileEpilogueAttr>("epilogue");
  bool isInt8 = physical.accumulator == "s32";
  bool hasBias = epilogue && epilogue.getBias();
  bool hasResidual = false;
  if (auto attr = op->getAttrOfType<BoolAttr>("residual"))
    hasResidual = attr.getValue();
  StringRef expectedOutput = isInt8 ? "i32" : "f32";
  unsigned expectedInputs = 6 + unsigned(hasBias) + unsigned(hasResidual);
  if (!desc || !epilogue ||
      epilogue.getOutputType() != expectedOutput ||
      kernel.getInputs().size() != expectedInputs ||
      (isInt8 && (hasBias || hasResidual || epilogue.getActivation() != "none"))) {
    op->emitError("sm_120 TF32/FP8/INT8 matmul_kernel has an invalid fused "
                  "epilogue ABI (INT8 requires the unfused i32 route)");
    return failure();
  }
  if (auto attr = op->getAttrOfType<StringAttr>("staging");
      !attr || attr.getValue() != "global") {
    op->emitError("sm_120 TF32/FP8 canonical materializer currently requires "
                  "direct global staging");
    return failure();
  }
  if (auto attr = op->getAttrOfType<IntegerAttr>("warps");
      !attr || attr.getInt() != 1) {
    op->emitError("sm_120 TF32/FP8 canonical materializer requires one warp");
    return failure();
  }

  ValueRange inputs = kernel.getInputs();
  Value aBase = inputs[0], bBase = inputs[1];
  Value biasBase = hasBias ? inputs[2] : Value();
  unsigned residualIndex = 2 + unsigned(hasBias);
  Value residualBase = hasResidual ? inputs[residualIndex] : Value();
  unsigned dIndex = 2 + unsigned(hasBias) + unsigned(hasResidual);
  Value dBase = inputs[dIndex];
  Value m = inputs[dIndex + 1], n = inputs[dIndex + 2], k = inputs[dIndex + 3];
  Location loc = op->getLoc();
  Type i8 = builder.getI8Type();
  Type i32 = builder.getI32Type();
  auto f32 = builder.getF32Type();
  bool isTF32 = physical.packing == Sm120InputPacking::ScalarF32;
  int64_t packWidth = isTF32 ? 1 : 4;
  Value one = i64Constant(builder, loc, 1);
  Value eight = i64Constant(builder, loc, 8);
  Value fragmentK = i64Constant(builder, loc, physical.k);
  Value halfK = i64Constant(builder, loc, physical.k / 2);

  Value blockX32 = NVVM::BlockIdXOp::create(builder, loc, i32);
  Value blockY32 = NVVM::BlockIdYOp::create(builder, loc, i32);
  Value blockX = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockX32);
  Value blockY = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockY32);
  Value rowOrigin = mulI64(builder, loc, blockY, i64Constant(builder, loc, 16));
  Value colOrigin = mulI64(builder, loc, blockX, eight);
  Value tid = NVVM::ThreadIdXOp::create(builder, loc, i32);
  Value lane = arith::AndIOp::create(
      builder, loc, tid, arith::ConstantIntOp::create(builder, loc, 31, 32));
  Value gid32 = arith::ShRUIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 2, 32));
  Value tig32 = arith::AndIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 3, 32));
  Value gid = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), gid32);
  Value tig = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), tig32);
  Value registerColumn = mulI64(
      builder, loc, tig, i64Constant(builder, loc, packWidth));

  auto loadRegister = [&](Value base, Value row, Value col, bool operandA) {
    if (isTF32) {
      Value valid = arith::AndIOp::create(
          builder, loc, lessI64(builder, loc, row, operandA ? m : k),
          lessI64(builder, loc, col, operandA ? k : n));
      Value linear = operandA
          ? addI64(builder, loc, mulI64(builder, loc, row, k), col)
          : addI64(builder, loc, mulI64(builder, loc, col, k), row);
      Value scalar = maskedLoadScalar(builder, loc, base, f32, linear, valid, 4);
      return Value(LLVM::BitcastOp::create(builder, loc, i32, scalar));
    }
    Value word = arith::ConstantIntOp::create(builder, loc, 0, 32);
    for (int64_t index = 0; index < 4; ++index) {
      Value logicalRow = operandA ? row : addI64(
          builder, loc, row, i64Constant(builder, loc, index));
      Value logicalCol = operandA ? addI64(
          builder, loc, col, i64Constant(builder, loc, index)) : col;
      Value valid = arith::AndIOp::create(
          builder, loc, lessI64(builder, loc, logicalRow, operandA ? m : k),
          lessI64(builder, loc, logicalCol, operandA ? k : n));
      Value linear = operandA
          ? addI64(builder, loc, mulI64(builder, loc, logicalRow, k), logicalCol)
          : addI64(builder, loc, mulI64(builder, loc, logicalCol, k), logicalRow);
      Value byte = maskedLoadScalar(builder, loc, base, i8, linear, valid, 1);
      Value widened = arith::ExtUIOp::create(builder, loc, i32, byte);
      if (index != 0)
        widened = arith::ShLIOp::create(
            builder, loc, widened,
            arith::ConstantIntOp::create(builder, loc, index * 8, 32));
      word = arith::OrIOp::create(builder, loc, word, widened);
    }
    return word;
  };

  Type accumulatorType = isInt8 ? Type(i32) : Type(f32);
  Value zeroAccumulator = isInt8
      ? Value(arith::ConstantIntOp::create(builder, loc, 0, 32))
      : Value(arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f)));
  SmallVector<Value> init(4, zeroAccumulator);
  auto loop = scf::ForOp::create(
      builder, loc, i64Constant(builder, loc, 0), k, fragmentK, init);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(loop.getBody());
    Value kOrigin = loop.getInductionVar();
    Value row0 = addI64(builder, loc, rowOrigin, gid);
    Value row1 = addI64(builder, loc, row0, eight);
    Value k0 = addI64(builder, loc, kOrigin, registerColumn);
    Value k1 = addI64(builder, loc, k0, halfK);
    Value bCol = addI64(builder, loc, colOrigin, gid);
    SmallVector<Value> operands = {
        loadRegister(aBase, row0, k0, true),
        loadRegister(aBase, row1, k0, true),
        loadRegister(aBase, row0, k1, true),
        loadRegister(aBase, row1, k1, true),
        loadRegister(bBase, k0, bCol, false),
        loadRegister(bBase, k1, bCol, false),
    };
    operands.append(loop.getRegionIterArgs().begin(),
                    loop.getRegionIterArgs().end());
    Type resultTy = LLVM::LLVMStructType::getLiteral(
        builder.getContext(), {accumulatorType, accumulatorType,
                               accumulatorType, accumulatorType});
    SmallVector<NamedAttribute> attrs = {
        builder.getNamedAttr("arch", builder.getStringAttr("sm_120")),
        builder.getNamedAttr(
            "shape", builder.getStringAttr(
                isTF32 ? "m16n8k8" : "m16n8k32")),
        builder.getNamedAttr("dtype_ab", builder.getStringAttr(desc.getAType())),
        builder.getNamedAttr(
            "dtype_c", builder.getStringAttr(isInt8 ? "s32" : "f32")),
        builder.getNamedAttr("block_scaled", builder.getBoolAttr(false))};
    Operation *mma = createContractOp(
        builder, loc, "tessera_nvidia.mma_sync", operands,
        TypeRange{resultTy}, attrs);
    SmallVector<Value> next;
    for (int64_t index = 0; index < 4; ++index)
      next.push_back(LLVM::ExtractValueOp::create(
          builder, loc, accumulatorType, mma->getResult(0),
          ArrayRef<int64_t>{index}));
    scf::YieldOp::create(builder, loc, next);
  }

  builder.setInsertionPointAfter(loop);
  Value outCol = addI64(
      builder, loc, colOrigin,
      mulI64(builder, loc, tig, i64Constant(builder, loc, 2)));
  Value colValid0 = lessI64(builder, loc, outCol, n);
  Value colValid1 = lessI64(builder, loc, addI64(builder, loc, outCol, one), n);
  for (unsigned pair = 0; pair < 2; ++pair) {
    Value row = addI64(
        builder, loc, rowOrigin,
        pair == 0 ? gid : addI64(builder, loc, gid, eight));
    Value rowValid = lessI64(builder, loc, row, m);
    Value valid0 = arith::AndIOp::create(builder, loc, rowValid, colValid0);
    Value valid1 = arith::AndIOp::create(builder, loc, rowValid, colValid1);
    Value linear = addI64(builder, loc, mulI64(builder, loc, row, n), outCol);
    Value value0 = loop.getResult(pair * 2);
    Value value1 = loop.getResult(pair * 2 + 1);
    if (hasBias) {
      Value biasPair = maskedLoadPair(
          builder, loc, biasBase, f32, outCol, colValid0, colValid1, 4);
      value0 = arith::AddFOp::create(
          builder, loc, value0, LLVM::ExtractElementOp::create(
              builder, loc, f32, biasPair, i64Constant(builder, loc, 0)));
      value1 = arith::AddFOp::create(
          builder, loc, value1, LLVM::ExtractElementOp::create(
              builder, loc, f32, biasPair, i64Constant(builder, loc, 1)));
    }
    if (epilogue.getActivation() != "none") {
      value0 = tessera::tile::emitScalarFloatActivation(
          builder, loc, value0, epilogue.getActivation());
      value1 = tessera::tile::emitScalarFloatActivation(
          builder, loc, value1, epilogue.getActivation());
    }
    if (hasResidual) {
      Value residualPair = maskedLoadPair(
          builder, loc, residualBase, f32, linear, valid0, valid1, 4);
      value0 = arith::AddFOp::create(
          builder, loc, value0, LLVM::ExtractElementOp::create(
              builder, loc, f32, residualPair, i64Constant(builder, loc, 0)));
      value1 = arith::AddFOp::create(
          builder, loc, value1, LLVM::ExtractElementOp::create(
              builder, loc, f32, residualPair, i64Constant(builder, loc, 1)));
    }
    Value ptr = LLVM::GEPOp::create(
        builder, loc, dBase.getType(), accumulatorType, dBase,
        ValueRange{linear});
    Value outPair = pairFromScalars(
        builder, loc, accumulatorType, value0, value1);
    LLVM::MaskedStoreOp::create(
        builder, loc, outPair, ptr, mask2(builder, loc, valid0, valid1), 4);
  }
  op->erase();
  return success();
}

// General-shape FP64 DMMA materialization.  For m8n8k4 each lane owns A(gid,
// tig), B(tig,gid), and two adjacent f64 outputs at (gid,2*tig+[0,1]).
static LogicalResult materializeSm120F64MatmulKernel(
    tessera::tile::MatmulKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto epilogue = op->getAttrOfType<tessera::tile::TileEpilogueAttr>("epilogue");
  if (!desc || !epilogue || epilogue.getBias() ||
      epilogue.getActivation() != "none" ||
      epilogue.getOutputType() != "f64" || kernel.getInputs().size() != 6) {
    op->emitError("sm_120 FP64 matmul_kernel requires A/B/D/M/N/K, f64 "
                  "output, and no fused epilogue");
    return failure();
  }
  if (auto attr = op->getAttrOfType<StringAttr>("staging");
      !attr || attr.getValue() != "global") {
    op->emitError("sm_120 FP64 canonical materializer requires direct global staging");
    return failure();
  }
  ValueRange inputs = kernel.getInputs();
  Value aBase = inputs[0], bBase = inputs[1], dBase = inputs[2];
  Value m = inputs[3], n = inputs[4], k = inputs[5];
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type();
  auto f64 = builder.getF64Type();
  Value one = i64Constant(builder, loc, 1);
  Value eight = i64Constant(builder, loc, 8);
  Value blockX32 = NVVM::BlockIdXOp::create(builder, loc, i32);
  Value blockY32 = NVVM::BlockIdYOp::create(builder, loc, i32);
  Value blockX = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockX32);
  Value blockY = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockY32);
  Value rowOrigin = mulI64(builder, loc, blockY, eight);
  Value colOrigin = mulI64(builder, loc, blockX, eight);
  Value tid = NVVM::ThreadIdXOp::create(builder, loc, i32);
  Value lane = arith::AndIOp::create(
      builder, loc, tid, arith::ConstantIntOp::create(builder, loc, 31, 32));
  Value gid32 = arith::ShRUIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 2, 32));
  Value tig32 = arith::AndIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 3, 32));
  Value gid = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), gid32);
  Value tig = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), tig32);
  Value zero = arith::ConstantFloatOp::create(
      builder, loc, f64, APFloat(0.0));
  auto loop = scf::ForOp::create(
      builder, loc, i64Constant(builder, loc, 0), k,
      i64Constant(builder, loc, 4), ValueRange{zero, zero});
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(loop.getBody());
    Value kOrigin = loop.getInductionVar();
    Value row = addI64(builder, loc, rowOrigin, gid);
    Value contraction = addI64(builder, loc, kOrigin, tig);
    Value col = addI64(builder, loc, colOrigin, gid);
    Value aValid = arith::AndIOp::create(
        builder, loc, lessI64(builder, loc, row, m),
        lessI64(builder, loc, contraction, k));
    Value bValid = arith::AndIOp::create(
        builder, loc, lessI64(builder, loc, contraction, k),
        lessI64(builder, loc, col, n));
    Value aLinear = addI64(
        builder, loc, mulI64(builder, loc, row, k), contraction);
    Value bLinear = addI64(
        builder, loc, mulI64(builder, loc, col, k), contraction);
    Value a = maskedLoadScalar(builder, loc, aBase, f64, aLinear, aValid, 8);
    Value b = maskedLoadScalar(builder, loc, bBase, f64, bLinear, bValid, 8);
    SmallVector<Value> operands = {a, b, loop.getRegionIterArgs()[0],
                                   loop.getRegionIterArgs()[1]};
    Type resultTy = LLVM::LLVMStructType::getLiteral(
        builder.getContext(), {f64, f64});
    SmallVector<NamedAttribute> attrs = {
        builder.getNamedAttr("arch", builder.getStringAttr("sm_120")),
        builder.getNamedAttr("shape", builder.getStringAttr("m8n8k4")),
        builder.getNamedAttr("dtype_ab", builder.getStringAttr("f64")),
        builder.getNamedAttr("dtype_c", builder.getStringAttr("f64")),
        builder.getNamedAttr("block_scaled", builder.getBoolAttr(false))};
    Operation *mma = createContractOp(
        builder, loc, "tessera_nvidia.mma_sync", operands,
        TypeRange{resultTy}, attrs);
    scf::YieldOp::create(builder, loc, ValueRange{
        LLVM::ExtractValueOp::create(
            builder, loc, f64, mma->getResult(0), ArrayRef<int64_t>{0}),
        LLVM::ExtractValueOp::create(
            builder, loc, f64, mma->getResult(0), ArrayRef<int64_t>{1})});
  }
  builder.setInsertionPointAfter(loop);
  Value row = addI64(builder, loc, rowOrigin, gid);
  Value outCol = addI64(
      builder, loc, colOrigin,
      mulI64(builder, loc, tig, i64Constant(builder, loc, 2)));
  Value rowValid = lessI64(builder, loc, row, m);
  Value valid0 = arith::AndIOp::create(
      builder, loc, rowValid, lessI64(builder, loc, outCol, n));
  Value valid1 = arith::AndIOp::create(
      builder, loc, rowValid,
      lessI64(builder, loc, addI64(builder, loc, outCol, one), n));
  Value linear = addI64(builder, loc, mulI64(builder, loc, row, n), outCol);
  Value ptr = LLVM::GEPOp::create(
      builder, loc, dBase.getType(), f64, dBase, ValueRange{linear});
  Value outPair = pairFromScalars(
      builder, loc, f64, loop.getResult(0), loop.getResult(1));
  LLVM::MaskedStoreOp::create(
      builder, loc, outPair, ptr, mask2(builder, loc, valid0, valid1), 8);
  op->erase();
  return success();
}

static LogicalResult materializeSm120MatmulKernel(
    tessera::tile::MatmulKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto epilogue = op->getAttrOfType<tessera::tile::TileEpilogueAttr>("epilogue");
  if (desc && (desc.getAType() == "int4" || desc.getAType() == "s4"))
    return materializeSm120Int4MatmulKernel(kernel, builder);
  std::optional<Sm120FragmentDescriptor> physical = selectSm120Fragment(desc);
  if (physical && desc.getAType() == "nvfp4")
    return materializeSm120Nvfp4MatmulKernel(kernel, builder);
  if (physical && (desc.getAType() == "e2m3" || desc.getAType() == "e3m2" ||
                   desc.getAType() == "fp4_e2m1"))
    return materializeSm120MxMatmulKernel(kernel, builder, *physical);
  if (physical && physical->packing == Sm120InputPacking::ScalarF64)
    return materializeSm120F64MatmulKernel(kernel, builder);
  if (physical && (physical->packing == Sm120InputPacking::ScalarF32 ||
                   physical->packing == Sm120InputPacking::PackedX4I8) &&
      (physical->accumulator == "f32" || physical->accumulator == "s32"))
    return materializeSm120F32PackedMatmulKernel(kernel, builder, *physical);
  if (!physical || physical->packing != Sm120InputPacking::PairF16 ||
      desc.getAccType() != "f32" || !epilogue) {
    op->emitError("sm_120 matmul_kernel requires m16n8k16 f16 or bf16 inputs "
                  "with f32 accumulation");
    return failure();
  }
  ValueRange inputs = kernel.getInputs();
  bool hasBias = epilogue.getBias();
  bool hasResidual = false;
  if (auto attr = op->getAttrOfType<BoolAttr>("residual"))
    hasResidual = attr.getValue();
  Value aBase = inputs[0], bBase = inputs[1];
  Value biasBase = hasBias ? inputs[2] : Value();
  unsigned residualIndex = 2 + unsigned(hasBias);
  Value residualBase = hasResidual ? inputs[residualIndex] : Value();
  unsigned dIndex = 2 + unsigned(hasBias) + unsigned(hasResidual);
  Value dBase = inputs[dIndex];
  Value m = inputs[dIndex + 1], n = inputs[dIndex + 2], k = inputs[dIndex + 3];
  // Dynamic scheduled packages carry physical row strides after their logical
  // M/N/K extents.  Keep the compact ABI as a strict subset: when the three
  // values are absent, the mathematical row strides are K, K, and N.
  bool hasLeadingDimensions = inputs.size() == dIndex + 7;
  if (inputs.size() != dIndex + 4 && !hasLeadingDimensions) {
    op->emitError("sm_120 matmul_kernel requires A, B, D, M, N, K and "
                  "optional lda, ldb, ldd operands");
    return failure();
  }
  Value lda = hasLeadingDimensions ? inputs[dIndex + 4] : k;
  Value ldb = hasLeadingDimensions ? inputs[dIndex + 5] : k;
  Value ldd = hasLeadingDimensions ? inputs[dIndex + 6] : n;
  Location loc = op->getLoc();
  Type inputType = desc.getAType() == "bf16"
      ? Type(builder.getBF16Type()) : Type(builder.getF16Type());
  Type f16 = builder.getF16Type();
  auto f32 = builder.getF32Type();
  int64_t warps = 1;
  if (auto attr = op->getAttrOfType<IntegerAttr>("warps"))
    warps = attr.getInt();
  bool sharedStaging = false;
  if (auto attr = op->getAttrOfType<StringAttr>("staging"))
    sharedStaging = attr.getValue() == "shared";
  bool vectorizedSharedPanel = false;
  if (auto attr =
          op->getAttrOfType<BoolAttr>("tessera.vectorized_shared_panel"))
    vectorizedSharedPanel = attr.getValue();
  bool asyncSharedPanel = false;
  if (auto attr = op->getAttrOfType<BoolAttr>("tessera.async_shared_panel"))
    asyncSharedPanel = attr.getValue();
  FailureOr<Value> sharedBase = failure();
  if (sharedStaging) {
    sharedBase = sm120SharedBuffer(op, builder, inputType, desc.getAType(),
                                   asyncSharedPanel);
    if (failed(sharedBase)) {
      op->emitError("failed to materialize sm_120 shared staging buffer");
      return failure();
    }
  }

  Value blockX32 = NVVM::BlockIdXOp::create(builder, loc, builder.getI32Type());
  Value blockY32 = NVVM::BlockIdYOp::create(builder, loc, builder.getI32Type());
  Value blockX = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockX32);
  Value blockY = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), blockY32);
  Value tid = NVVM::ThreadIdXOp::create(builder, loc, builder.getI32Type());
  Value warp32 = arith::ShRUIOp::create(
      builder, loc, tid, arith::ConstantIntOp::create(builder, loc, 5, 32));
  Value warpRow32 = warps == 4
      ? Value(arith::ShRUIOp::create(
            builder, loc, warp32,
            arith::ConstantIntOp::create(builder, loc, 1, 32)))
      : Value(arith::ConstantIntOp::create(builder, loc, 0, 32));
  Value warpCol32 = warps == 4
      ? Value(arith::AndIOp::create(
            builder, loc, warp32,
            arith::ConstantIntOp::create(builder, loc, 1, 32)))
      : Value(arith::ConstantIntOp::create(builder, loc, 0, 32));
  Value warpRow = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(), warpRow32);
  Value warpCol = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(), warpCol32);
  Value macroRowOrigin = mulI64(
      builder, loc, blockY,
      i64Constant(builder, loc, warps == 4 ? 32 : 16));
  Value macroColOrigin = mulI64(
      builder, loc, blockX,
      i64Constant(builder, loc, warps == 4 ? 32 : 8));
  Value rowOrigin = addI64(
      builder, loc, macroRowOrigin,
      mulI64(builder, loc, warpRow, i64Constant(builder, loc, 16)));
  Value colOrigin = addI64(
      builder, loc, macroColOrigin,
      mulI64(builder, loc, warpCol,
             i64Constant(builder, loc, warps == 4 ? 16 : 8)));

  Value lane = arith::AndIOp::create(
      builder, loc, tid, arith::ConstantIntOp::create(builder, loc, 31, 32));
  Value gid32 = arith::ShRUIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 2, 32));
  Value tig32 = arith::AndIOp::create(
      builder, loc, lane, arith::ConstantIntOp::create(builder, loc, 3, 32));
  Value twoTig32 = arith::MulIOp::create(
      builder, loc, tig32, arith::ConstantIntOp::create(builder, loc, 2, 32));
  Value gid = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), gid32);
  Value twoTig = arith::ExtUIOp::create(builder, loc, builder.getI64Type(),
                                        twoTig32);

  Value zeroI64 = i64Constant(builder, loc, 0);
  Value sixteen = i64Constant(builder, loc, 16);
  int64_t canonicalTileK = 16;
  if (auto canonical =
          op->getAttrOfType<BoolAttr>("tessera.canonical_k_loop");
      canonical && canonical.getValue())
    canonicalTileK =
        op->getAttrOfType<IntegerAttr>("tessera.tile_k").getInt();
  Value kStep = i64Constant(builder, loc, canonicalTileK);
  Value zeroF32 = arith::ConstantFloatOp::create(
      builder, loc, builder.getF32Type(), APFloat(0.0f));
  Value tid64 = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(), tid);
  auto asyncSlotOffset = [&](Value panelK) {
    Value panel = arith::DivUIOp::create(builder, loc, panelK, sixteen);
    Value slot = arith::AndIOp::create(
        builder, loc, panel, i64Constant(builder, loc, 1));
    return Value(mulI64(builder, loc, slot,
                        i64Constant(builder, loc, 1024)));
  };
  // Keep copy/commit/completion as SSA values until the final NVGPU lowering.
  // Each descriptor is the exact 16-byte window already selected by the panel
  // address calculation; partial panels retain zero-fill via srcElements.
  builder.getContext()->getOrLoadDialect<nvgpu::NVGPUDialect>();
  Type asyncToken = nvgpu::DeviceAsyncTokenType::get(builder.getContext());
  auto panelView = [&](Value ptr, unsigned space) {
    auto i64 = builder.getI64Type();
    auto array = LLVM::LLVMArrayType::get(i64, 1);
    auto desc = LLVM::LLVMStructType::getLiteral(builder.getContext(),
        {ptr.getType(), ptr.getType(), i64, array, array});
    Value value = LLVM::UndefOp::create(builder, loc, desc);
    value = LLVM::InsertValueOp::create(builder, loc, value, ptr, ArrayRef<int64_t>{0});
    value = LLVM::InsertValueOp::create(builder, loc, value, ptr, ArrayRef<int64_t>{1});
    value = LLVM::InsertValueOp::create(builder, loc, value, zeroI64, ArrayRef<int64_t>{2});
    value = LLVM::InsertValueOp::create(builder, loc, value, i64Constant(builder, loc, 8), ArrayRef<int64_t>{3, 0});
    value = LLVM::InsertValueOp::create(builder, loc, value, i64Constant(builder, loc, 1), ArrayRef<int64_t>{4, 0});
    auto type = MemRefType::get({8}, inputType, MemRefLayoutAttrInterface{}, builder.getI64IntegerAttr(space));
    return UnrealizedConversionCastOp::create(builder, loc, TypeRange{type}, ValueRange{value}).getResult(0);
  };
  auto issuePanelCopy = [&](Value sharedPtr, Value globalPtr, Value bytes) {
    Value zero = arith::ConstantIndexOp::create(builder, loc, 0);
    Value elements = arith::DivUIOp::create(builder, loc, bytes,
        arith::ConstantIntOp::create(builder, loc, 2, 32));
    elements = arith::IndexCastOp::create(builder, loc, builder.getIndexType(), elements);
    return nvgpu::DeviceAsyncCopyOp::create(builder, loc, panelView(sharedPtr, 3),
        ValueRange{zero}, panelView(globalPtr, 1), ValueRange{zero},
        builder.getIndexAttr(8), elements, UnitAttr()).getAsyncToken();
  };
  auto stageAsyncPanel = [&](Value panelK, Value slotOffset) {
    Value eight = i64Constant(builder, loc, 8);
    Value isA = lessI64(builder, loc, tid64,
                        i64Constant(builder, loc, 64));
    auto branch = scf::IfOp::create(builder, loc, TypeRange{asyncToken}, isA,
                                    /*withElseRegion=*/true);
    {
      OpBuilder::InsertionGuard branchGuard(builder);
      builder.setInsertionPointToStart(branch.thenBlock());
      Value localRow = arith::DivUIOp::create(
          builder, loc, tid64, i64Constant(builder, loc, 2));
      Value chunk = mulI64(
          builder, loc,
          arith::RemUIOp::create(builder, loc, tid64,
                                 i64Constant(builder, loc, 2)),
          eight);
      Value globalRow = addI64(builder, loc, macroRowOrigin, localRow);
      Value globalK = addI64(builder, loc, panelK, chunk);
      Value rowInBounds = lessI64(builder, loc, globalRow, m);
      Value kInBounds = lessI64(builder, loc, globalK, k);
      Value inBounds = arith::AndIOp::create(
          builder, loc, rowInBounds, kInBounds);
      Value remaining = arith::SelectOp::create(
          builder, loc, kInBounds,
          arith::SubIOp::create(builder, loc, k, globalK), zeroI64);
      Value copiedElements = arith::SelectOp::create(
          builder, loc, lessI64(builder, loc, remaining, eight), remaining,
          eight);
      Value globalLinear = addI64(
          builder, loc, mulI64(builder, loc, globalRow, lda), globalK);
      Value safeGlobalLinear = arith::SelectOp::create(
          builder, loc, inBounds, globalLinear, zeroI64);
      Value copyBytes64 = arith::SelectOp::create(
          builder, loc, rowInBounds,
          mulI64(builder, loc, copiedElements,
                 i64Constant(builder, loc, 2)),
          zeroI64);
      Value copyBytes = arith::TruncIOp::create(
          builder, loc, builder.getI32Type(), copyBytes64);
      Value sharedLinear = addI64(
          builder, loc, slotOffset,
          addI64(builder, loc, mulI64(builder, loc, localRow, sixteen),
                 chunk));
      Value genericPtr = LLVM::GEPOp::create(
          builder, loc, aBase.getType(), inputType, aBase,
          ValueRange{safeGlobalLinear});
      auto globalType = LLVM::LLVMPointerType::get(builder.getContext(), 1);
      Value globalPtr = LLVM::AddrSpaceCastOp::create(
          builder, loc, globalType, genericPtr);
      Value sharedPtr = LLVM::GEPOp::create(
          builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
          ValueRange{sharedLinear});
      Value token = issuePanelCopy(sharedPtr, globalPtr, copyBytes);
      scf::YieldOp::create(builder, loc, token);
    }
    {
      OpBuilder::InsertionGuard branchGuard(builder);
      builder.setInsertionPointToStart(branch.elseBlock());
      Value owner = arith::SubIOp::create(
          builder, loc, tid64, i64Constant(builder, loc, 64));
      Value localCol = arith::DivUIOp::create(
          builder, loc, owner, i64Constant(builder, loc, 2));
      Value chunk = mulI64(
          builder, loc,
          arith::RemUIOp::create(builder, loc, owner,
                                 i64Constant(builder, loc, 2)),
          eight);
      Value globalCol = addI64(builder, loc, macroColOrigin, localCol);
      Value globalK = addI64(builder, loc, panelK, chunk);
      Value colInBounds = lessI64(builder, loc, globalCol, n);
      Value kInBounds = lessI64(builder, loc, globalK, k);
      Value inBounds = arith::AndIOp::create(
          builder, loc, colInBounds, kInBounds);
      Value remaining = arith::SelectOp::create(
          builder, loc, kInBounds,
          arith::SubIOp::create(builder, loc, k, globalK), zeroI64);
      Value copiedElements = arith::SelectOp::create(
          builder, loc, lessI64(builder, loc, remaining, eight), remaining,
          eight);
      Value globalLinear = addI64(
          builder, loc, mulI64(builder, loc, globalCol, ldb), globalK);
      Value safeGlobalLinear = arith::SelectOp::create(
          builder, loc, inBounds, globalLinear, zeroI64);
      Value copyBytes64 = arith::SelectOp::create(
          builder, loc, colInBounds,
          mulI64(builder, loc, copiedElements,
                 i64Constant(builder, loc, 2)),
          zeroI64);
      Value copyBytes = arith::TruncIOp::create(
          builder, loc, builder.getI32Type(), copyBytes64);
      Value sharedLinear = addI64(
          builder, loc, slotOffset,
          addI64(builder, loc, i64Constant(builder, loc, 512),
                 addI64(builder, loc,
                        mulI64(builder, loc, localCol, sixteen), chunk)));
      Value genericPtr = LLVM::GEPOp::create(
          builder, loc, bBase.getType(), inputType, bBase,
          ValueRange{safeGlobalLinear});
      auto globalType = LLVM::LLVMPointerType::get(builder.getContext(), 1);
      Value globalPtr = LLVM::AddrSpaceCastOp::create(
          builder, loc, globalType, genericPtr);
      Value sharedPtr = LLVM::GEPOp::create(
          builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
          ValueRange{sharedLinear});
      Value token = issuePanelCopy(sharedPtr, globalPtr, copyBytes);
      scf::YieldOp::create(builder, loc, token);
    }
    builder.setInsertionPointAfter(branch);
    return nvgpu::DeviceAsyncCreateGroupOp::create(builder, loc, asyncToken, ValueRange{branch.getResult(0)}).getAsyncToken();
  };
  Value primeToken;
  if (asyncSharedPanel) {
    primeToken = stageAsyncPanel(zeroI64, zeroI64);
    nvgpu::DeviceAsyncWaitOp::create(builder, loc, primeToken, builder.getI32IntegerAttr(0));
    NVVM::BarrierOp::create(builder, loc);
  }
  // A shared-staged warp computes two adjacent m16n8 fragments so each pair of
  // CTA barriers is amortized over eight MMA instructions rather than four.
  SmallVector<Value> init(sharedStaging ? 8 : 4, zeroF32);
  if (asyncSharedPanel) init.push_back(primeToken);
  auto loop = scf::ForOp::create(builder, loc, zeroI64, k, kStep, init);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(loop.getBody());
    Value kOrigin = loop.getInductionVar();
    Value eight = i64Constant(builder, loc, 8);
    Value one = i64Constant(builder, loc, 1);
    Value row0 = addI64(builder, loc, rowOrigin, gid);
    Value row1 = addI64(builder, loc, row0, eight);
    Value k0 = addI64(builder, loc, kOrigin, twoTig);
    Value k1 = addI64(builder, loc, k0, eight);
    Value currentSlotOffset = asyncSharedPanel
        ? asyncSlotOffset(kOrigin) : zeroI64;

    Value nextPanelToken;
    if (sharedStaging) {
      if (asyncSharedPanel) {
        Value nextK = addI64(builder, loc, kOrigin, kStep);
        Value hasNext = lessI64(builder, loc, nextK, k);
        auto prefetch = scf::IfOp::create(builder, loc, TypeRange{asyncToken}, hasNext,
                                          /*withElseRegion=*/true);
        {
          OpBuilder::InsertionGuard prefetchGuard(builder);
          builder.setInsertionPointToStart(prefetch.thenBlock());
          Value issued = stageAsyncPanel(nextK, asyncSlotOffset(nextK));
          scf::YieldOp::create(builder, loc, issued);
          builder.setInsertionPointToStart(prefetch.elseBlock());
          scf::YieldOp::create(builder, loc, loop.getRegionIterArgs().back());
        }
        builder.setInsertionPointAfter(prefetch);
        nextPanelToken = prefetch.getResult(0);
      } else if (vectorizedSharedPanel) {
        // Exactly 128 threads move the complete 2 KiB panel: warps 0-1 each
        // own one aligned 16-byte A vector and warps 2-3 one B vector. Full
        // CTA bounds are part of the target contract, so no masked tail is
        // silently introduced here.
        Value isA = lessI64(builder, loc, tid64,
                            i64Constant(builder, loc, 64));
        auto branch = scf::IfOp::create(builder, loc, isA,
                                        /*withElseRegion=*/true);
        {
          OpBuilder::InsertionGuard branchGuard(builder);
          {
            builder.setInsertionPointToStart(branch.thenBlock());
            Value localRow = arith::DivUIOp::create(
                builder, loc, tid64, i64Constant(builder, loc, 2));
            Value chunk = mulI64(
                builder, loc,
                arith::RemUIOp::create(
                    builder, loc, tid64, i64Constant(builder, loc, 2)),
                eight);
            Value globalRow = addI64(builder, loc, macroRowOrigin, localRow);
            Value globalK = addI64(builder, loc, kOrigin, chunk);
            Value globalLinear = addI64(
                builder, loc, mulI64(builder, loc, globalRow, lda), globalK);
            Value sharedLinear = addI64(
                builder, loc, currentSlotOffset,
                addI64(builder, loc,
                       mulI64(builder, loc, localRow, sixteen), chunk));
            Value globalPtr = LLVM::GEPOp::create(
                builder, loc, aBase.getType(), inputType, aBase,
                ValueRange{globalLinear});
            Value sharedPtr = LLVM::GEPOp::create(
                builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
                ValueRange{sharedLinear});
            Value vector = LLVM::LoadOp::create(
                builder, loc, VectorType::get({8}, inputType), globalPtr,
                /*alignment=*/16);
            LLVM::StoreOp::create(builder, loc, vector, sharedPtr,
                                  /*alignment=*/16);
          }
          {
            builder.setInsertionPointToStart(branch.elseBlock());
            Value owner = arith::SubIOp::create(
                builder, loc, tid64, i64Constant(builder, loc, 64));
            Value localCol = arith::DivUIOp::create(
                builder, loc, owner, i64Constant(builder, loc, 2));
            Value chunk = mulI64(
                builder, loc,
                arith::RemUIOp::create(
                    builder, loc, owner, i64Constant(builder, loc, 2)),
                eight);
            Value globalCol = addI64(builder, loc, macroColOrigin, localCol);
            Value globalK = addI64(builder, loc, kOrigin, chunk);
            Value globalLinear = addI64(
                builder, loc, mulI64(builder, loc, globalCol, ldb), globalK);
            Value sharedLinear = addI64(
                builder, loc, currentSlotOffset,
                addI64(builder, loc, i64Constant(builder, loc, 512),
                       addI64(builder, loc,
                              mulI64(builder, loc, localCol, sixteen), chunk)));
            Value globalPtr = LLVM::GEPOp::create(
                builder, loc, bBase.getType(), inputType, bBase,
                ValueRange{globalLinear});
            Value sharedPtr = LLVM::GEPOp::create(
                builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
                ValueRange{sharedLinear});
            Value vector = LLVM::LoadOp::create(
                builder, loc, VectorType::get({8}, inputType), globalPtr,
                /*alignment=*/16);
            LLVM::StoreOp::create(builder, loc, vector, sharedPtr,
                                  /*alignment=*/16);
          }
        }
      } else {
        auto stageLoop = scf::ForOp::create(
            builder, loc, tid64, i64Constant(builder, loc, 1024),
            i64Constant(builder, loc, warps * 32));
        {
          OpBuilder::InsertionGuard stageGuard(builder);
          builder.setInsertionPointToStart(stageLoop.getBody());
          Value index = stageLoop.getInductionVar();
          Value isA = lessI64(builder, loc, index,
                              i64Constant(builder, loc, 512));
          auto branch = scf::IfOp::create(builder, loc, isA,
                                          /*withElseRegion=*/true);
          {
            OpBuilder::InsertionGuard branchGuard(builder);
            {
              builder.setInsertionPointToStart(branch.thenBlock());
            Value localRow = arith::DivUIOp::create(
                builder, loc, index, sixteen);
            Value localK = arith::RemUIOp::create(
                builder, loc, index, sixteen);
            Value globalRow = addI64(builder, loc, macroRowOrigin, localRow);
            Value globalK = addI64(builder, loc, kOrigin, localK);
            Value valid = arith::AndIOp::create(
                builder, loc, lessI64(builder, loc, globalRow, m),
                lessI64(builder, loc, globalK, k));
            Value linear = addI64(
                builder, loc, mulI64(builder, loc, globalRow, lda), globalK);
            Value scalar = maskedLoadScalar(
                builder, loc, aBase, inputType, linear, valid, 2);
            Value ptr = LLVM::GEPOp::create(
                builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
                ValueRange{index});
            LLVM::StoreOp::create(builder, loc, scalar, ptr, /*alignment=*/2);
            }
            {
              builder.setInsertionPointToStart(branch.elseBlock());
            Value bIndex = arith::SubIOp::create(
                builder, loc, index, i64Constant(builder, loc, 512));
            Value localCol = arith::DivUIOp::create(
                builder, loc, bIndex, sixteen);
            Value localK = arith::RemUIOp::create(
                builder, loc, bIndex, sixteen);
            Value globalCol = addI64(builder, loc, macroColOrigin, localCol);
            Value globalK = addI64(builder, loc, kOrigin, localK);
            Value valid = arith::AndIOp::create(
                builder, loc, lessI64(builder, loc, globalCol, n),
                lessI64(builder, loc, globalK, k));
            Value linear = addI64(
                builder, loc, mulI64(builder, loc, globalCol, ldb), globalK);
            Value scalar = maskedLoadScalar(
                builder, loc, bBase, inputType, linear, valid, 2);
            Value ptr = LLVM::GEPOp::create(
                builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
                ValueRange{index});
            LLVM::StoreOp::create(builder, loc, scalar, ptr, /*alignment=*/2);
            }
          }
        }
        builder.setInsertionPointAfter(stageLoop);
      }
      if (!asyncSharedPanel)
        NVVM::BarrierOp::create(builder, loc);
    }

    auto loadA = [&](Value row, Value col) {
      if (sharedStaging) {
        Value localRow = arith::SubIOp::create(
            builder, loc, row, macroRowOrigin);
        Value localCol = arith::SubIOp::create(builder, loc, col, kOrigin);
        Value linear = addI64(
            builder, loc, currentSlotOffset,
            addI64(builder, loc,
                   mulI64(builder, loc, localRow, sixteen), localCol));
        Value ptr = LLVM::GEPOp::create(
            builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
            ValueRange{linear});
        return Value(LLVM::LoadOp::create(
            builder, loc, VectorType::get({2}, inputType), ptr, /*alignment=*/2));
      }
      Value linear = addI64(builder, loc, mulI64(builder, loc, row, lda), col);
      Value rowValid = lessI64(builder, loc, row, m);
      Value valid0 = arith::AndIOp::create(
          builder, loc, rowValid, lessI64(builder, loc, col, k));
      Value valid1 = arith::AndIOp::create(
          builder, loc, rowValid,
          lessI64(builder, loc, addI64(builder, loc, col, one), k));
      return maskedLoadPair(builder, loc, aBase, inputType, linear,
                            valid0, valid1, 2);
    };
    auto loadB = [&](Value row, Value tileColOrigin) {
      Value fragmentCol = addI64(builder, loc, tileColOrigin, gid);
      if (sharedStaging) {
        Value localRow = arith::SubIOp::create(builder, loc, row, kOrigin);
        Value localCol = arith::SubIOp::create(
            builder, loc, fragmentCol, macroColOrigin);
        Value linear = addI64(
            builder, loc, currentSlotOffset,
            addI64(builder, loc, i64Constant(builder, loc, 512),
                   addI64(builder, loc,
                          mulI64(builder, loc, localCol, sixteen), localRow)));
        Value ptr = LLVM::GEPOp::create(
            builder, loc, (*sharedBase).getType(), inputType, *sharedBase,
            ValueRange{linear});
        return Value(LLVM::LoadOp::create(
            builder, loc, VectorType::get({2}, inputType), ptr, /*alignment=*/2));
      }
      Value linear = addI64(
          builder, loc, mulI64(builder, loc, fragmentCol, ldb), row);
      Value colValid = lessI64(builder, loc, fragmentCol, n);
      Value valid0 = arith::AndIOp::create(
          builder, loc, colValid, lessI64(builder, loc, row, k));
      Value valid1 = arith::AndIOp::create(
          builder, loc, colValid,
          lessI64(builder, loc, addI64(builder, loc, row, one), k));
      return maskedLoadPair(builder, loc, bBase, inputType, linear,
                            valid0, valid1, 2);
    };

    Type resultTy = LLVM::LLVMStructType::getLiteral(
        builder.getContext(), {f32, f32, f32, f32});
    SmallVector<NamedAttribute> attrs = {
        builder.getNamedAttr("arch", builder.getStringAttr("sm_120")),
        builder.getNamedAttr("shape", builder.getStringAttr("m16n8k16")),
        builder.getNamedAttr("dtype_ab", builder.getStringAttr(desc.getAType())),
        builder.getNamedAttr("dtype_c", builder.getStringAttr("f32")),
        builder.getNamedAttr("block_scaled", builder.getBoolAttr(false))};
    SmallVector<Value> next;
    SmallVector<Value> aOperands = {loadA(row0, k0), loadA(row1, k0),
                                    loadA(row0, k1), loadA(row1, k1)};
    auto emitMma = [&](Value mmaCol, unsigned accumulatorBase) {
      SmallVector<Value> operands(aOperands.begin(), aOperands.end());
      operands.push_back(loadB(k0, mmaCol));
      operands.push_back(loadB(k1, mmaCol));
      if (desc.getAType() == "bf16")
        for (Value &operand : operands)
          operand = LLVM::BitcastOp::create(
              builder, loc, builder.getI32Type(), operand);
      for (unsigned i = 0; i < 4; ++i)
        operands.push_back(loop.getRegionIterArgs()[accumulatorBase + i]);
      Operation *mma = createContractOp(
          builder, loc, "tessera_nvidia.mma_sync", operands,
          TypeRange{resultTy}, attrs);
      for (int64_t index = 0; index < 4; ++index)
        next.push_back(LLVM::ExtractValueOp::create(
            builder, loc, f32, mma->getResult(0), ArrayRef<int64_t>{index}));
    };
    emitMma(colOrigin, 0);
    if (sharedStaging)
      emitMma(addI64(builder, loc, colOrigin, eight), 4);
    if (sharedStaging) {
      NVVM::BarrierOp::create(builder, loc);
      if (asyncSharedPanel) {
        nvgpu::DeviceAsyncWaitOp::create(builder, loc, nextPanelToken, builder.getI32IntegerAttr(0));
        NVVM::BarrierOp::create(builder, loc);
        next.push_back(nextPanelToken);
      }
    }
    scf::YieldOp::create(builder, loc, next);
  }

  builder.setInsertionPointAfter(loop);
  SmallVector<Value> values(loop.getResults().begin(), loop.getResults().end());
  Value one = i64Constant(builder, loc, 1);
  Value eight = i64Constant(builder, loc, 8);
  Type outputType = epilogue.getOutputType() == "f16" ? f16 : f32;
  unsigned nTiles = sharedStaging ? 2 : 1;
  for (unsigned nTile = 0; nTile < nTiles; ++nTile) {
    unsigned base = nTile * 4;
    Value tileCol = nTile == 0
        ? colOrigin : addI64(builder, loc, colOrigin, eight);
    Value outCol = addI64(builder, loc, tileCol, twoTig);
    Value colValid0 = lessI64(builder, loc, outCol, n);
    Value colValid1 = lessI64(
        builder, loc, addI64(builder, loc, outCol, one), n);

    if (hasBias) {
      Value biasPair = maskedLoadPair(builder, loc, biasBase, f32, outCol,
                                      colValid0, colValid1, 4);
      Value bias0 = LLVM::ExtractElementOp::create(
          builder, loc, f32, biasPair, i64Constant(builder, loc, 0));
      Value bias1 = LLVM::ExtractElementOp::create(
          builder, loc, f32, biasPair, i64Constant(builder, loc, 1));
      values[base] = arith::AddFOp::create(
          builder, loc, values[base], bias0);
      values[base + 1] = arith::AddFOp::create(
          builder, loc, values[base + 1], bias1);
      values[base + 2] = arith::AddFOp::create(
          builder, loc, values[base + 2], bias0);
      values[base + 3] = arith::AddFOp::create(
          builder, loc, values[base + 3], bias1);
    }
    if (epilogue.getActivation() != "none")
      for (unsigned i = 0; i < 4; ++i)
        values[base + i] = tessera::tile::emitScalarFloatActivation(
            builder, loc, values[base + i], epilogue.getActivation());
    if (hasResidual) {
      for (unsigned pair = 0; pair < 2; ++pair) {
        Value rowOffset = pair == 0 ? gid : addI64(builder, loc, gid, eight);
        Value row = addI64(builder, loc, rowOrigin, rowOffset);
        Value rowValid = lessI64(builder, loc, row, m);
        Value valid0 = arith::AndIOp::create(builder, loc, rowValid, colValid0);
        Value valid1 = arith::AndIOp::create(builder, loc, rowValid, colValid1);
        Value linear = addI64(builder, loc, mulI64(builder, loc, row, ldd), outCol);
        Value residualPair = maskedLoadPair(
            builder, loc, residualBase, f32, linear, valid0, valid1, 4);
        for (unsigned element = 0; element < 2; ++element) {
          Value residualValue = LLVM::ExtractElementOp::create(
              builder, loc, f32, residualPair,
              i64Constant(builder, loc, element));
          unsigned valueIndex = base + pair * 2 + element;
          values[valueIndex] = arith::AddFOp::create(
              builder, loc, values[valueIndex], residualValue);
        }
      }
    }
    if (outputType == f16)
      for (unsigned i = 0; i < 4; ++i)
        values[base + i] = tessera::tile::emitFloatOutputConversion(
            builder, loc, values[base + i], outputType);

    for (unsigned pair = 0; pair < 2; ++pair) {
      Value rowOffset = pair == 0 ? gid : addI64(builder, loc, gid, eight);
      Value row = addI64(builder, loc, rowOrigin, rowOffset);
      Value rowValid = lessI64(builder, loc, row, m);
      Value valid0 = arith::AndIOp::create(builder, loc, rowValid, colValid0);
      Value valid1 = arith::AndIOp::create(builder, loc, rowValid, colValid1);
      Value linear = addI64(builder, loc, mulI64(builder, loc, row, ldd), outCol);
      Value ptr = LLVM::GEPOp::create(builder, loc, dBase.getType(), outputType,
                                      dBase, ValueRange{linear});
      Value outPair = pairFromScalars(
          builder, loc, outputType, values[base + pair * 2],
          values[base + pair * 2 + 1]);
      LLVM::MaskedStoreOp::create(builder, loc, outPair, ptr,
                                  mask2(builder, loc, valid0, valid1),
                                  outputType == f16 ? 2 : 4);
    }
  }
  op->erase();
  return success();
}

// NVIDIA-E2E-2 row-softmax pilot. One CUDA thread owns one flattened row and
// performs a stable max-shifted f32 reduction over the last axis. This is a
// correctness-first compiler-native candidate: it deliberately does not claim
// the cooperative block reduction schedule used by the existing CUDA-C lane.
static LogicalResult materializeSm120SoftmaxKernel(
    tessera::tile::SoftmaxKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange inputs = kernel.getInputs();
  if (inputs.size() != 4) {
    op->emitError("sm_120 softmax_kernel requires X, O, rows, and columns");
    return failure();
  }
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto accum = op->getAttrOfType<StringAttr>("accum");
  auto axis = op->getAttrOfType<IntegerAttr>("axis");
  auto expMode = op->getAttrOfType<StringAttr>("exp_mode");
  auto ftz = op->getAttrOfType<BoolAttr>("ftz");
  bool f16Storage = storage && storage.getValue() == "f16";
  bool bf16Storage = storage && storage.getValue() == "bf16";
  if (!storage ||
      (!f16Storage && !bf16Storage && storage.getValue() != "f32") || !accum ||
      accum.getValue() != "f32" || !axis || axis.getInt() != -1 ||
      !expMode || expMode.getValue() != "approx_exp2" || !ftz ||
      ftz.getValue()) {
    op->emitError(
        "sm_120 softmax_kernel requires f16/bf16/f32 storage, f32 accum, "
        "axis=-1, exp_mode=approx_exp2, and ftz=false");
    return failure();
  }

  auto schedule = op->getAttrOfType<StringAttr>("schedule");
  bool cooperative = schedule && schedule.getValue() == "cooperative_128";
  if (schedule && schedule.getValue() != "serial" && !cooperative)
    return op->emitError("SM120 softmax schedule must be serial|cooperative_128");

  Location loc = op->getLoc();
  Value xBase = inputs[0], outBase = inputs[1];
  Value rows = inputs[2], columns = inputs[3];
  Type i32 = builder.getI32Type();
  Type i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  Type storageType = f16Storage
                         ? Type(builder.getF16Type())
                         : bf16Storage ? Type(builder.getBF16Type()) : Type(f32);
  unsigned storageAlignment = (f16Storage || bf16Storage) ? 2 : 4;
  Value block = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value row = cooperative ? block : addI64(
      builder, loc, mulI64(builder, loc, block, i64Constant(builder, loc, 128)),
      thread);
  Value active = lessI64(builder, loc, row, rows);
  auto expF32 = [&](Value value) -> Value {
    Value log2e = arith::ConstantFloatOp::create(
        builder, loc, f32, APFloat(1.4426950408889634f));
    Value scaled = arith::MulFOp::create(builder, loc, value, log2e);
    return NVVM::Ex2Op::create(builder, loc, scaled, /*ftz=*/false);
  };
  auto loadF32 = [&](Value linear) -> Value {
    Value ptr = LLVM::GEPOp::create(
        builder, loc, xBase.getType(), storageType, xBase,
        ValueRange{linear});
    Value value = LLVM::LoadOp::create(
        builder, loc, storageType, ptr, storageAlignment);
    return (f16Storage || bf16Storage)
        ? Value(LLVM::FPExtOp::create(builder, loc, f32, value))
        : value;
  };
  auto storeF32 = [&](Value linear, Value value) {
    Value stored = (f16Storage || bf16Storage)
        ? Value(LLVM::FPTruncOp::create(builder, loc, storageType, value))
        : value;
    Value ptr = LLVM::GEPOp::create(
        builder, loc, outBase.getType(), storageType, outBase,
        ValueRange{linear});
    LLVM::StoreOp::create(builder, loc, stored, ptr, storageAlignment);
  };
  Value scratch;
  if (cooperative) {
    FailureOr<Value> allocated = sm120ReductionScratch(op, builder);
    if (failed(allocated))
      return op->emitError("failed to materialize cooperative softmax scratch");
    scratch = *allocated;
  }
  auto reduceF32 = [&](Value partial, bool maximum) -> Value {
    if (!cooperative) return partial;
    Value lanePointer = LLVM::GEPOp::create(
        builder, loc, scratch.getType(), f32, scratch, ValueRange{thread});
    LLVM::StoreOp::create(builder, loc, partial, lanePointer, 4);
    NVVM::BarrierOp::create(builder, loc);
    for (int64_t stride = 64; stride >= 1; stride >>= 1) {
      Value participates = lessI64(
          builder, loc, thread, i64Constant(builder, loc, stride));
      auto combine = scf::IfOp::create(builder, loc, participates, false);
      {
        OpBuilder::InsertionGuard combineGuard(builder);
        builder.setInsertionPointToStart(combine.thenBlock());
        Value lhsPointer = LLVM::GEPOp::create(
            builder, loc, scratch.getType(), f32, scratch, ValueRange{thread});
        Value rhsPointer = LLVM::GEPOp::create(
            builder, loc, scratch.getType(), f32, scratch,
            ValueRange{addI64(builder, loc, thread,
                             i64Constant(builder, loc, stride))});
        Value lhs = LLVM::LoadOp::create(builder, loc, f32, lhsPointer, 4);
        Value rhs = LLVM::LoadOp::create(builder, loc, f32, rhsPointer, 4);
        Value combined = maximum
            ? Value(arith::MaximumFOp::create(builder, loc, lhs, rhs))
            : Value(arith::AddFOp::create(builder, loc, lhs, rhs));
        LLVM::StoreOp::create(builder, loc, combined, lhsPointer, 4);
      }
      builder.setInsertionPointAfter(combine);
      NVVM::BarrierOp::create(builder, loc);
    }
    Value leaderPointer = LLVM::GEPOp::create(
        builder, loc, scratch.getType(), f32, scratch,
        ValueRange{i64Constant(builder, loc, 0)});
    Value result = LLVM::LoadOp::create(builder, loc, f32, leaderPointer, 4);
    // Every lane must capture the broadcast before sum reduction reuses it.
    NVVM::BarrierOp::create(builder, loc);
    return result;
  };
  auto guarded = scf::IfOp::create(builder, loc, active, /*withElseRegion=*/false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(guarded.thenBlock());
    Value zero = cooperative ? thread : i64Constant(builder, loc, 0);
    Value one = i64Constant(builder, loc, cooperative ? 128 : 1);
    Value rowBase = mulI64(builder, loc, row, columns);
    Value negInf = arith::ConstantFloatOp::create(
        builder, loc, f32,
        APFloat::getInf(APFloat::IEEEsingle(), /*negative=*/true));
    auto maxLoop = scf::ForOp::create(
        builder, loc, zero, columns, one, ValueRange{negInf});
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(maxLoop.getBody());
      Value linear = addI64(
          builder, loc, rowBase, maxLoop.getInductionVar());
      Value value = loadF32(linear);
      Value next = arith::MaximumFOp::create(
          builder, loc, maxLoop.getRegionIterArgs()[0], value);
      scf::YieldOp::create(builder, loc, ValueRange{next});
    }
    builder.setInsertionPointAfter(maxLoop);
    Value maximum = reduceF32(maxLoop.getResult(0), true);
    Value zeroF32 = arith::ConstantFloatOp::create(
        builder, loc, f32, APFloat(0.0f));
    auto sumLoop = scf::ForOp::create(
        builder, loc, zero, columns, one, ValueRange{zeroF32});
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(sumLoop.getBody());
      Value linear = addI64(
          builder, loc, rowBase, sumLoop.getInductionVar());
      Value value = loadF32(linear);
      Value shifted = arith::SubFOp::create(builder, loc, value, maximum);
      Value exponent = expF32(shifted);
      Value next = arith::AddFOp::create(
          builder, loc, sumLoop.getRegionIterArgs()[0], exponent);
      scf::YieldOp::create(builder, loc, ValueRange{next});
    }
    builder.setInsertionPointAfter(sumLoop);
    Value denominator = reduceF32(sumLoop.getResult(0), false);
    auto storeLoop = scf::ForOp::create(builder, loc, zero, columns, one);
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(storeLoop.getBody());
      Value linear = addI64(
          builder, loc, rowBase, storeLoop.getInductionVar());
      Value value = loadF32(linear);
      Value shifted = arith::SubFOp::create(builder, loc, value, maximum);
      Value exponent = expF32(shifted);
      Value normalized = arith::DivFOp::create(
          builder, loc, exponent, denominator);
      storeF32(linear, normalized);
    }
  }
  builder.setInsertionPointAfter(guarded);
  op->erase();
  return success();
}

// Canonical arbitrary-axis reduction over contiguous [outer, axis, inner].
// The serial schedule assigns one output to a thread; cooperative_128 assigns
// one output to a CTA and reduces thread partials through shared memory.
static LogicalResult materializeSm120ReduceKernel(
    tessera::tile::ReduceKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange inputs = kernel.getInputs();
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto accum = op->getAttrOfType<StringAttr>("accum");
  auto kind = op->getAttrOfType<StringAttr>("kind");
  auto axis = op->getAttrOfType<IntegerAttr>("axis");
  auto keepdims = op->getAttrOfType<BoolAttr>("keepdims");
  auto schedule = op->getAttrOfType<StringAttr>("schedule");
  auto nanMode = op->getAttrOfType<StringAttr>("nan_mode");
  bool f16Storage = storage && storage.getValue() == "f16";
  bool bf16Storage = storage && storage.getValue() == "bf16";
  if (inputs.size() != 5 || !storage ||
      (!f16Storage && !bf16Storage && storage.getValue() != "f32") || !accum ||
      accum.getValue() != "f32" || !kind ||
      (kind.getValue() != "sum" && kind.getValue() != "mean" &&
       kind.getValue() != "max" && kind.getValue() != "min") ||
      !axis || axis.getInt() < 0 || !keepdims ||
      !schedule || (schedule.getValue() != "serial" &&
                    schedule.getValue() != "cooperative_128") ||
      !nanMode || nanMode.getValue() != "propagate") {
    op->emitError(
        "sm_120 reduce_kernel requires f16/bf16/f32 storage, f32 accum, "
        "normalized axis, keepdims, serial|cooperative_128 schedule, and "
        "nan_mode=propagate");
    return failure();
  }
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type();
  Type i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  Type storageType = f16Storage
                         ? Type(builder.getF16Type())
                         : bf16Storage ? Type(builder.getBF16Type()) : Type(f32);
  unsigned alignment = (f16Storage || bf16Storage) ? 2 : 4;
  Value block = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value outer = inputs[2], axisExtent = inputs[3], inner = inputs[4];
  bool cooperative = schedule.getValue() == "cooperative_128";
  Value output = cooperative ? block : addI64(
      builder, loc, mulI64(builder, loc, block, i64Constant(builder, loc, 128)),
      thread);
  Value outputs = mulI64(builder, loc, outer, inner);
  Value active = lessI64(builder, loc, output, outputs);
  auto guarded = scf::IfOp::create(builder, loc, active, false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(guarded.thenBlock());
    Value initial = (kind.getValue() == "max" || kind.getValue() == "min")
        ? Value(arith::ConstantFloatOp::create(
              builder, loc, f32,
              APFloat::getInf(APFloat::IEEEsingle(),
                              /*negative=*/kind.getValue() == "max")))
        : Value(arith::ConstantFloatOp::create(
              builder, loc, f32, APFloat(0.0f)));
    Value outerIndex = arith::DivUIOp::create(builder, loc, output, inner);
    Value innerIndex = arith::RemUIOp::create(builder, loc, output, inner);
    Value first = cooperative ? thread : i64Constant(builder, loc, 0);
    Value step = i64Constant(builder, loc, cooperative ? 128 : 1);
    auto loop = scf::ForOp::create(
        builder, loc, first, axisExtent, step, ValueRange{initial});
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(loop.getBody());
      Value linear = addI64(builder, loc, mulI64(builder, loc,
          addI64(builder, loc, mulI64(builder, loc, outerIndex, axisExtent),
                 loop.getInductionVar()), inner), innerIndex);
      Value ptr = LLVM::GEPOp::create(
          builder, loc, inputs[0].getType(), storageType, inputs[0],
          ValueRange{linear});
      Value loaded = LLVM::LoadOp::create(
          builder, loc, storageType, ptr, alignment);
      Value value = (f16Storage || bf16Storage)
          ? Value(LLVM::FPExtOp::create(builder, loc, f32, loaded))
          : loaded;
      Value next =
          kind.getValue() == "max"
              ? Value(arith::MaximumFOp::create(
                    builder, loc, loop.getRegionIterArgs()[0], value))
          : kind.getValue() == "min"
              ? Value(arith::MinimumFOp::create(
                    builder, loc, loop.getRegionIterArgs()[0], value))
              : Value(arith::AddFOp::create(
                    builder, loc, loop.getRegionIterArgs()[0], value));
      scf::YieldOp::create(builder, loc, ValueRange{next});
    }
    builder.setInsertionPointAfter(loop);
    Value result = loop.getResult(0);
    if (cooperative) {
      FailureOr<Value> scratch = sm120ReductionScratch(op, builder);
      if (failed(scratch)) {
        op->emitError("failed to materialize cooperative reduction scratch");
        return failure();
      }
      Value scratchPtr = LLVM::GEPOp::create(
          builder, loc, scratch->getType(), f32, *scratch, ValueRange{thread});
      LLVM::StoreOp::create(builder, loc, result, scratchPtr, 4);
      NVVM::BarrierOp::create(builder, loc);
      for (int64_t stride = 64; stride >= 1; stride >>= 1) {
        Value participates = lessI64(
            builder, loc, thread, i64Constant(builder, loc, stride));
        auto combine = scf::IfOp::create(builder, loc, participates, false);
        {
          OpBuilder::InsertionGuard combineGuard(builder);
          builder.setInsertionPointToStart(combine.thenBlock());
          Value lhsPtr = LLVM::GEPOp::create(
              builder, loc, scratch->getType(), f32, *scratch,
              ValueRange{thread});
          Value rhsPtr = LLVM::GEPOp::create(
              builder, loc, scratch->getType(), f32, *scratch,
              ValueRange{addI64(builder, loc, thread,
                                i64Constant(builder, loc, stride))});
          Value lhs = LLVM::LoadOp::create(builder, loc, f32, lhsPtr, 4);
          Value rhs = LLVM::LoadOp::create(builder, loc, f32, rhsPtr, 4);
          Value combined =
              kind.getValue() == "max"
                  ? Value(arith::MaximumFOp::create(builder, loc, lhs, rhs))
              : kind.getValue() == "min"
                  ? Value(arith::MinimumFOp::create(builder, loc, lhs, rhs))
                  : Value(arith::AddFOp::create(builder, loc, lhs, rhs));
          LLVM::StoreOp::create(builder, loc, combined, lhsPtr, 4);
        }
        builder.setInsertionPointAfter(combine);
        NVVM::BarrierOp::create(builder, loc);
      }
      Value leader = arith::CmpIOp::create(
          builder, loc, arith::CmpIPredicate::eq, thread,
          i64Constant(builder, loc, 0));
      auto store = scf::IfOp::create(builder, loc, leader, false);
      {
        OpBuilder::InsertionGuard storeGuard(builder);
        builder.setInsertionPointToStart(store.thenBlock());
        Value ptr = LLVM::GEPOp::create(
            builder, loc, scratch->getType(), f32, *scratch,
            ValueRange{i64Constant(builder, loc, 0)});
        Value reduced = LLVM::LoadOp::create(builder, loc, f32, ptr, 4);
        if (kind.getValue() == "mean")
          reduced = arith::DivFOp::create(
              builder, loc, reduced,
              arith::UIToFPOp::create(builder, loc, f32, axisExtent));
        Value outPtr = LLVM::GEPOp::create(
            builder, loc, inputs[1].getType(), f32, inputs[1],
            ValueRange{output});
        LLVM::StoreOp::create(builder, loc, reduced, outPtr, 4);
      }
      builder.setInsertionPointAfter(store);
    } else {
      if (kind.getValue() == "mean")
        result = arith::DivFOp::create(
            builder, loc, result,
            arith::UIToFPOp::create(builder, loc, f32, axisExtent));
      Value outPtr = LLVM::GEPOp::create(
          builder, loc, inputs[1].getType(), f32, inputs[1], ValueRange{output});
      LLVM::StoreOp::create(builder, loc, result, outPtr, 4);
    }
  }
  builder.setInsertionPointAfter(guarded);
  op->erase();
  return success();
}

// Compiler-owned row normalization. Serial assigns one thread per row;
// cooperative_128 assigns one CTA per row with coalesced loads and a checked
// shared-memory reduction. Both schedules use centered LayerNorm variance and
// performs every reduction in f32 before rounding the normalized value back to
// the declared storage type. Epsilon is embedded in the immutable PTX image,
// leaving the launch ABI as X/O/Rows/Columns.
// Preserve the standalone store with propagated NaNs and the dtype-specific zero rule.
static LogicalResult materializeSm120ActivationKernel(
    tessera::tile::ActivationKernelOp kernel, OpBuilder &builder) {
  if (failed(kernel.verify())) return failure();
  Operation *op = kernel.getOperation();
  Location loc = op->getLoc();
  auto inputs = kernel.getInputs();
  auto storage = op->getAttrOfType<StringAttr>("storage");
  Type element = storage.getValue() == "f16" ? Type(builder.getF16Type()) :
                                                    Type(builder.getBF16Type());
  Type i32 = builder.getI32Type(), i64 = builder.getI64Type();
  Value block = arith::ExtUIOp::create(builder, loc, i64,
      NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(builder, loc, i64,
      NVVM::ThreadIdXOp::create(builder, loc, i32));
  bool flat = op->getAttrOfType<StringAttr>("schedule").getValue() == "flat_128";
  Value row = addI64(builder, loc,
      mulI64(builder, loc, block, i64Constant(builder, loc, 128)), thread);
  auto active = scf::IfOp::create(builder, loc, lessI64(builder, loc, row, flat ? mulI64(builder, loc, inputs[2], inputs[3]) : inputs[2]), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(active.thenBlock());
    Value start = i64Constant(builder, loc, 0), step = i64Constant(builder, loc, 1);
    // Flat maps adjacent lanes to adjacent stored elements; serial remains a
    // separately hashed control. Both preserve the exact storage select below.
    Value linear = row;
    if (!flat) {
      auto loop = scf::ForOp::create(builder, loc, start, inputs[3], step);
      builder.setInsertionPointToStart(loop.getBody());
      linear = addI64(builder, loc, mulI64(builder, loc, row, inputs[3]), loop.getInductionVar());
    }
    Value source = LLVM::GEPOp::create(builder, loc, inputs[0].getType(), element,
        inputs[0], ValueRange{linear});
    Value output = LLVM::GEPOp::create(builder, loc, inputs[1].getType(), element,
        inputs[1], ValueRange{linear});
    Value loaded = LLVM::LoadOp::create(builder, loc, element, source, 2);
    Value wide = LLVM::FPExtOp::create(builder, loc, builder.getF32Type(), loaded);
    Value zero = arith::ConstantFloatOp::create(builder, loc, builder.getF32Type(), APFloat(0.0f));
    Value negative = arith::CmpFOp::create(builder, loc,
        storage.getValue() == "f16" ? arith::CmpFPredicate::OLE : arith::CmpFPredicate::OLT, wide, zero);
    // Retain the original NaN payload; f16 canonicalizes zero and bf16 preserves its sign.
    Value storedZero = LLVM::FPTruncOp::create(builder, loc, element, zero);
    Value result = arith::SelectOp::create(builder, loc, negative, storedZero, loaded);
    LLVM::StoreOp::create(builder, loc, result, output, 2);
  }
  op->erase();
  return success();
}

static LogicalResult materializeSm120NormKernel(
    tessera::tile::NormKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange inputs = kernel.getInputs();
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto accum = op->getAttrOfType<StringAttr>("accum");
  auto kind = op->getAttrOfType<StringAttr>("kind");
  auto axis = op->getAttrOfType<IntegerAttr>("axis");
  auto affine = op->getAttrOfType<BoolAttr>("affine");
  bool f16Storage = storage && storage.getValue() == "f16";
  bool bf16Storage = storage && storage.getValue() == "bf16";
  bool layer = kind && kind.getValue() == "layernorm";
  auto schedule = op->getAttrOfType<StringAttr>("schedule");
  bool cooperative = schedule && schedule.getValue() == "cooperative_128";
  if (schedule && schedule.getValue() != "serial" && !cooperative)
    return op->emitError("SM120 norm schedule must be serial|cooperative_128");
  if (inputs.size() != 5 || !storage ||
      (!f16Storage && !bf16Storage && storage.getValue() != "f32") ||
      !accum || accum.getValue() != "f32" || !kind ||
      (!layer && kind.getValue() != "rmsnorm") || !axis ||
      axis.getInt() != -1 || !affine || affine.getValue() ||
      !inputs[4].getType().isF32()) {
    op->emitError(
        "sm_120 norm_kernel requires f16/bf16/f32 storage, f32 accumulation, "
        "rmsnorm|layernorm, axis=-1, affine=false, and f32 epsilon");
    return failure();
  }
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type();
  Type i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  Type storageType = f16Storage
                         ? Type(builder.getF16Type())
                         : bf16Storage ? Type(builder.getBF16Type()) : Type(f32);
  unsigned alignment = (f16Storage || bf16Storage) ? 2 : 4;
  Value xBase = inputs[0], outBase = inputs[1];
  Value rows = inputs[2], columns = inputs[3], epsilon = inputs[4];
  Value block = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value row = cooperative ? block : addI64(
      builder, loc, mulI64(builder, loc, block, i64Constant(builder, loc, 128)),
      thread);
  Value active = lessI64(builder, loc, row, rows);
  auto loadF32 = [&](Value linear) -> Value {
    Value ptr = LLVM::GEPOp::create(
        builder, loc, xBase.getType(), storageType, xBase,
        ValueRange{linear});
    Value value =
        LLVM::LoadOp::create(builder, loc, storageType, ptr, alignment);
    return (f16Storage || bf16Storage)
               ? Value(LLVM::FPExtOp::create(builder, loc, f32, value))
               : value;
  };
  auto storeF32 = [&](Value linear, Value value) {
    Value stored = (f16Storage || bf16Storage)
                       ? Value(LLVM::FPTruncOp::create(
                             builder, loc, storageType, value))
                       : value;
    Value ptr = LLVM::GEPOp::create(
        builder, loc, outBase.getType(), storageType, outBase,
        ValueRange{linear});
    LLVM::StoreOp::create(builder, loc, stored, ptr, alignment);
  };
  Value scratch;
  if (cooperative) {
    FailureOr<Value> allocated = sm120ReductionScratch(op, builder);
    if (failed(allocated)) return failure();
    scratch = *allocated;
  }
  // All 128 threads participate, including neutral lanes on a ragged row.
  // The row guard is CTA-uniform. The final barrier also protects the next
  // reduction's reuse of scratch from racing with readers of this result.
  auto reduceSum = [&](Value partial) -> Value {
    if (!cooperative) return partial;
    Value ptr = LLVM::GEPOp::create(
        builder, loc, scratch.getType(), f32, scratch, ValueRange{thread});
    LLVM::StoreOp::create(builder, loc, partial, ptr, 4);
    NVVM::BarrierOp::create(builder, loc);
    for (int64_t stride = 64; stride >= 1; stride >>= 1) {
      auto combine = scf::IfOp::create(builder, loc,
          lessI64(builder, loc, thread, i64Constant(builder, loc, stride)), false);
      {
        OpBuilder::InsertionGuard guard(builder);
        builder.setInsertionPointToStart(combine.thenBlock());
        Value rhsPtr = LLVM::GEPOp::create(
            builder, loc, scratch.getType(), f32, scratch,
            ValueRange{addI64(builder, loc, thread, i64Constant(builder, loc, stride))});
        Value lhs = LLVM::LoadOp::create(builder, loc, f32, ptr, 4);
        Value rhs = LLVM::LoadOp::create(builder, loc, f32, rhsPtr, 4);
        LLVM::StoreOp::create(builder, loc,
            arith::AddFOp::create(builder, loc, lhs, rhs), ptr, 4);
      }
      builder.setInsertionPointAfter(combine);
      NVVM::BarrierOp::create(builder, loc);
    }
    Value leader = LLVM::GEPOp::create(builder, loc, scratch.getType(), f32, scratch,
        ValueRange{i64Constant(builder, loc, 0)});
    Value reduced = LLVM::LoadOp::create(builder, loc, f32, leader, 4);
    NVVM::BarrierOp::create(builder, loc);
    return reduced;
  };
  auto guarded =
      scf::IfOp::create(builder, loc, active, /*withElseRegion=*/false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(guarded.thenBlock());
    Value zero = cooperative ? thread : i64Constant(builder, loc, 0);
    Value one = i64Constant(builder, loc, cooperative ? 128 : 1);
    Value rowBase = mulI64(builder, loc, row, columns);
    Value zeroF32 = arith::ConstantFloatOp::create(
        builder, loc, f32, APFloat(0.0f));
    // Serial long rows otherwise lose low-order contributions before storage
    // rounding. Kahan compensation uses only f32 operations; cooperative lanes
    // keep their short local sums and shared pairwise reduction.
    SmallVector<Value> initial{zeroF32};
    if (!cooperative) initial.push_back(zeroF32);
    auto accumulate = [&](ValueRange state, Value contribution) {
      if (cooperative)
        return SmallVector<Value>{arith::AddFOp::create(
            builder, loc, state[0], contribution)};
      Value corrected =
          arith::SubFOp::create(builder, loc, contribution, state[1]);
      Value next = arith::AddFOp::create(builder, loc, state[0], corrected);
      Value correction = arith::SubFOp::create(
          builder, loc, arith::SubFOp::create(builder, loc, next, state[0]),
          corrected);
      // Keep IEEE non-finite propagation: Inf plus finite remains Inf.
      // The compensation formula alone would turn Inf-Inf into a NaN
      // correction and incorrectly poison otherwise-zero RMSNorm outputs.
      Value infinity = arith::ConstantFloatOp::create(
          builder, loc, f32, APFloat::getInf(APFloat::IEEEsingle()));
      Value finite = arith::CmpFOp::create(
          builder, loc, arith::CmpFPredicate::OLT,
          math::AbsFOp::create(builder, loc, next), infinity);
      correction =
          arith::SelectOp::create(builder, loc, finite, correction, zeroF32);
      return SmallVector<Value>{next, correction};
    };
    auto sumLoop = scf::ForOp::create(
        builder, loc, zero, columns, one, initial);
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(sumLoop.getBody());
      Value linear =
          addI64(builder, loc, rowBase, sumLoop.getInductionVar());
      Value value = loadF32(linear);
      Value contribution =
          layer ? value : Value(arith::MulFOp::create(builder, loc, value, value));
      auto next = accumulate(sumLoop.getRegionIterArgs(), contribution);
      scf::YieldOp::create(builder, loc, next);
    }
    builder.setInsertionPointAfter(sumLoop);
    Value total = reduceSum(sumLoop.getResult(0));
    Value columnsF32 =
        arith::UIToFPOp::create(builder, loc, f32, columns);
    Value mean = layer
                     ? Value(arith::DivFOp::create(
                           builder, loc, total, columnsF32))
                     : zeroF32;
    Value varianceSum = total;
    if (layer) {
      auto varianceLoop = scf::ForOp::create(
          builder, loc, zero, columns, one, initial);
      {
        OpBuilder::InsertionGuard loopGuard(builder);
        builder.setInsertionPointToStart(varianceLoop.getBody());
        Value linear =
            addI64(builder, loc, rowBase, varianceLoop.getInductionVar());
        Value centered =
            arith::SubFOp::create(builder, loc, loadF32(linear), mean);
        Value squared =
            arith::MulFOp::create(builder, loc, centered, centered);
        auto next = accumulate(varianceLoop.getRegionIterArgs(), squared);
        scf::YieldOp::create(builder, loc, next);
      }
      builder.setInsertionPointAfter(varianceLoop);
      varianceSum = reduceSum(varianceLoop.getResult(0));
    }
    Value variance =
        arith::DivFOp::create(builder, loc, varianceSum, columnsF32);
    Value adjusted = arith::AddFOp::create(builder, loc, variance, epsilon);
    Value denominator = math::SqrtOp::create(builder, loc, adjusted);
    auto outputLoop =
        scf::ForOp::create(builder, loc, zero, columns, one);
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(outputLoop.getBody());
      Value linear =
          addI64(builder, loc, rowBase, outputLoop.getInductionVar());
      Value value = loadF32(linear);
      if (layer)
        value = arith::SubFOp::create(builder, loc, value, mean);
      storeF32(
          linear, arith::DivFOp::create(builder, loc, value, denominator));
    }
  }
  builder.setInsertionPointAfter(guarded);
  op->erase();
  return success();
}

// Correctness-first SDPA materializer. One thread owns one O[b,hq,q,dv]
// element and recomputes the score row. This deliberately favors a small,
// auditable ABI/semantic proof over the existing optimized CUDA-C candidate.
static LogicalResult materializeSm120AttentionKernel(
    tessera::tile::AttentionKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange in = kernel.getInputs();
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto accum = op->getAttrOfType<StringAttr>("accum");
  auto scaleAttr = op->getAttrOfType<FloatAttr>("scale");
  auto causalAttr = op->getAttrOfType<BoolAttr>("causal");
  auto biasAttr = op->getAttrOfType<BoolAttr>("bias");
  auto windowLeftAttr = op->getAttrOfType<IntegerAttr>("window_left");
  auto windowRightAttr = op->getAttrOfType<IntegerAttr>("window_right");
  auto softcapAttr = op->getAttrOfType<FloatAttr>("softcap");
  auto dropoutAttr = op->getAttrOfType<FloatAttr>("dropout_p");
  auto dropoutSeedAttr = op->getAttrOfType<IntegerAttr>("dropout_seed");
  auto lseCheckpoint = op->getAttrOfType<StringAttr>("lse_checkpoint");
  bool hasBias = biasAttr && biasAttr.getValue();
  bool hasSavedLse = lseCheckpoint && lseCheckpoint.getValue() == "saved";
  unsigned outputIndex = 3 + unsigned(hasBias);
  unsigned lseIndex = outputIndex + 1;
  unsigned dimStart = lseIndex + unsigned(hasSavedLse);
  bool f16Storage = storage && storage.getValue() == "f16";
  bool bf16Storage = storage && storage.getValue() == "bf16";
  auto biasShape = op->getAttrOfType<DenseI64ArrayAttr>("bias_shape");
  bool dynamicBias = biasShape && llvm::any_of(biasShape.asArrayRef(),
      [](int64_t dim) { return ShapedType::isDynamic(dim); });
  if (in.size() != 11 + unsigned(hasBias) + unsigned(hasSavedLse) + 4 * unsigned(dynamicBias) || !storage ||
      (!f16Storage && !bf16Storage && storage.getValue() != "f32") || !accum ||
      accum.getValue() != "f32" || !scaleAttr || !causalAttr || !biasAttr ||
      !windowLeftAttr || !windowRightAttr || !softcapAttr || !dropoutAttr ||
      !dropoutSeedAttr ||
      (lseCheckpoint && lseCheckpoint.getValue() != "recompute" &&
       lseCheckpoint.getValue() != "saved")) {
    op->emitError("sm_120 attention_kernel requires f16/bf16/f32 storage, f32 "
                  "accum, complete mask/dropout/LSE attrs, and the canonical ABI");
    return failure();
  }
  if (op->hasAttr("bias_shape") && (!biasShape || !hasBias || biasShape.size() != 4 ||
      biasShape[0] <= 0 || biasShape[1] <= 0 ||
      llvm::any_of(biasShape.asArrayRef(), [](int64_t dim) {
        return dim <= 0 && !ShapedType::isDynamic(dim);
      })))
    return op->emitError("attention broadcast bias requires fixed batch/head and positive or symbolic sequence dimensions");
  if (dynamicBias && !hasSavedLse)
    return op->emitError("symbolic physical bias requires saved LSE");
  auto outputStorage = op->getAttrOfType<StringAttr>("output_storage");
  bool halfOutput = outputStorage && outputStorage.getValue() != "f32";
  if (op->hasAttr("output_storage") &&
      (!outputStorage || (halfOutput &&
       (outputStorage.getValue() != storage.getValue() ||
        (!f16Storage && !bf16Storage)))))
    return op->emitError("half attention result requires matching f16/bf16 storage");
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type();
  Type i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  Type storageType = f16Storage
                         ? Type(builder.getF16Type())
                         : bf16Storage ? Type(builder.getBF16Type()) : Type(f32);
  unsigned alignment = (f16Storage || bf16Storage) ? 2 : 4;
  Value B = in[dimStart], Hq = in[dimStart + 1], Hkv = in[dimStart + 2];
  Value Sq = in[dimStart + 3], Sk = in[dimStart + 4];
  Value D = in[dimStart + 5], Dv = in[dimStart + 6];
  Value block = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value linearOut = addI64(
      builder, loc, mulI64(builder, loc, block, i64Constant(builder, loc, 128)),
      thread);
  Value total = mulI64(builder, loc, mulI64(builder, loc,
      mulI64(builder, loc, B, Hq), Sq), Dv);
  Value active = lessI64(builder, loc, linearOut, total);
  auto guarded = scf::IfOp::create(builder, loc, active, false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(guarded.thenBlock());
    Value dv = arith::RemUIOp::create(builder, loc, linearOut, Dv);
    Value t0 = arith::DivUIOp::create(builder, loc, linearOut, Dv);
    Value q = arith::RemUIOp::create(builder, loc, t0, Sq);
    Value t1 = arith::DivUIOp::create(builder, loc, t0, Sq);
    Value hq = arith::RemUIOp::create(builder, loc, t1, Hq);
    Value b = arith::DivUIOp::create(builder, loc, t1, Hq);
    Value ratio = arith::DivUIOp::create(builder, loc, Hq, Hkv);
    Value hkv = arith::DivUIOp::create(builder, loc, hq, ratio);
    Value zero = i64Constant(builder, loc, 0);
    Value one = i64Constant(builder, loc, 1);
    Value scale = arith::ConstantFloatOp::create(
        builder, loc, f32, scaleAttr.getValue());
    Value log2e = arith::ConstantFloatOp::create(
        builder, loc, f32, APFloat(1.4426950408889634f));
    auto load = [&](Value base, Value index) -> Value {
      Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), storageType,
                                      base, ValueRange{index});
      Value value = LLVM::LoadOp::create(builder, loc, storageType, ptr, alignment);
      return (f16Storage || bf16Storage)
                 ? Value(LLVM::FPExtOp::create(builder, loc, f32, value))
                 : value;
    };
    auto score = [&](Value key) -> Value {
      Value qBase = mulI64(builder, loc,
          addI64(builder, loc, mulI64(builder, loc,
              addI64(builder, loc, mulI64(builder, loc, b, Hq), hq), Sq), q), D);
      Value kBase = mulI64(builder, loc,
          addI64(builder, loc, mulI64(builder, loc,
              addI64(builder, loc, mulI64(builder, loc, b, Hkv), hkv), Sk), key), D);
      Value z = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
      auto dot = scf::ForOp::create(builder, loc, zero, D, one, ValueRange{z});
      {
        OpBuilder::InsertionGuard dotGuard(builder);
        builder.setInsertionPointToStart(dot.getBody());
        Value qv = load(in[0], addI64(builder, loc, qBase, dot.getInductionVar()));
        Value kv = load(in[1], addI64(builder, loc, kBase, dot.getInductionVar()));
        Value product = arith::MulFOp::create(builder, loc, qv, kv);
        Value next = arith::AddFOp::create(
            builder, loc, dot.getRegionIterArgs()[0], product);
        scf::YieldOp::create(builder, loc, ValueRange{next});
      }
      builder.setInsertionPointAfter(dot);
      Value value = arith::MulFOp::create(builder, loc, dot.getResult(0), scale);
      if (hasBias) {
        // Physical bias indexing: a broadcast axis (extent 1 in bias_shape)
        // reads index 0 and contributes a stride of 1; the others use the
        // attention coordinate and the physical extent (query/key axes since
        // 2026-09-15, batch/head since 2026-09-12).
        Value bb = biasShape && biasShape[0] == 1 ? i64Constant(builder, loc, 0) : b;
        Value bh = biasShape && biasShape[1] == 1 ? i64Constant(builder, loc, 0) : hq;
        Value bq = biasShape && biasShape[2] == 1 ? i64Constant(builder, loc, 0) : q;
        Value bk = biasShape && biasShape[3] == 1 ? i64Constant(builder, loc, 0) : key;
        Value physicalHeads = biasShape ? (ShapedType::isDynamic(biasShape[1]) ? in[dimStart + 7 + 1] : i64Constant(builder, loc, biasShape[1])) : Hq;
        Value physicalQueries = biasShape ? (ShapedType::isDynamic(biasShape[2]) ? in[dimStart + 7 + 2] : i64Constant(builder, loc, biasShape[2])) : Sq;
        Value physicalKeys = biasShape ? (ShapedType::isDynamic(biasShape[3]) ? in[dimStart + 7 + 3] : i64Constant(builder, loc, biasShape[3])) : Sk;
        Value biasIndex = addI64(builder, loc,
            mulI64(builder, loc,
                addI64(builder, loc, mulI64(builder, loc,
                    addI64(builder, loc, mulI64(builder, loc, bb, physicalHeads), bh), physicalQueries), bq),
                physicalKeys),
            bk);
        Value biasPtr = LLVM::GEPOp::create(builder, loc, in[3].getType(), f32,
                                            in[3], ValueRange{biasIndex});
        Value bias = LLVM::LoadOp::create(builder, loc, f32, biasPtr, 4);
        value = arith::AddFOp::create(builder, loc, value, bias);
      }
      if (softcapAttr.getValueAsDouble() > 0.0) {
        Value cap = arith::ConstantFloatOp::create(
            builder, loc, f32, softcapAttr.getValue());
        Value normalized = arith::DivFOp::create(builder, loc, value, cap);
        value = arith::MulFOp::create(
            builder, loc, cap,
            tessera::tile::emitBoundedTanhApprox(builder, loc, normalized));
      }
      Value alignedQuery = addI64(builder, loc, q,
          arith::MaxSIOp::create(builder, loc,
              arith::SubIOp::create(builder, loc, Sk, Sq), zero));
      Value legal = arith::ConstantIntOp::create(builder, loc, 1, 1);
      if (causalAttr.getValue())
        legal = arith::AndIOp::create(
            builder, loc, legal,
            arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ule, key, alignedQuery));
      if (windowLeftAttr.getInt() >= 0) {
        Value lower = arith::SubIOp::create(
            builder, loc, alignedQuery, i64Constant(builder, loc, windowLeftAttr.getInt()));
        legal = arith::AndIOp::create(
            builder, loc, legal,
            arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::sge, key, lower));
      }
      if (windowRightAttr.getInt() >= 0) {
        Value upper = addI64(builder, loc, alignedQuery,
                             i64Constant(builder, loc, windowRightAttr.getInt()));
        legal = arith::AndIOp::create(
            builder, loc, legal,
            arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::sle, key, upper));
      }
      Value negInf = arith::ConstantFloatOp::create(
          builder, loc, f32,
          APFloat::getInf(APFloat::IEEEsingle(), /*negative=*/true));
      value = arith::SelectOp::create(builder, loc, legal, value, negInf);
      return value;
    };
    Value negInf = arith::ConstantFloatOp::create(
        builder, loc, f32,
        APFloat::getInf(APFloat::IEEEsingle(), /*negative=*/true));
    auto maxLoop = scf::ForOp::create(builder, loc, zero, Sk, one,
                                      ValueRange{negInf});
    {
      OpBuilder::InsertionGuard maxGuard(builder);
      builder.setInsertionPointToStart(maxLoop.getBody());
      Value s = score(maxLoop.getInductionVar());
      Value next = arith::MaximumFOp::create(
          builder, loc, maxLoop.getRegionIterArgs()[0], s);
      scf::YieldOp::create(builder, loc, ValueRange{next});
    }
    builder.setInsertionPointAfter(maxLoop);
    Value z = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto accumLoop = scf::ForOp::create(builder, loc, zero, Sk, one,
                                        ValueRange{z, z});
    {
      OpBuilder::InsertionGuard accumGuard(builder);
      builder.setInsertionPointToStart(accumLoop.getBody());
      Value key = accumLoop.getInductionVar();
      Value shifted = arith::SubFOp::create(builder, loc, score(key),
                                            maxLoop.getResult(0));
      Value weight = NVVM::Ex2Op::create(
          builder, loc,
          arith::MulFOp::create(builder, loc, shifted, log2e), false);
      Value outputWeight = weight;
      if (dropoutAttr.getValueAsDouble() > 0.0) {
        Value counter = addI64(builder, loc,
            mulI64(builder, loc,
                addI64(builder, loc, mulI64(builder, loc,
                    addI64(builder, loc, mulI64(builder, loc, b, Hq), hq), Sq), q), Sk),
            key);
        Value hash = addI64(builder, loc,
            mulI64(builder, loc, counter, i64Constant(builder, loc, 1664525)),
            i64Constant(builder, loc, static_cast<int64_t>(static_cast<uint32_t>(dropoutSeedAttr.getInt())) + 1013904223LL));
        hash = arith::AndIOp::create(
            builder, loc, hash, i64Constant(builder, loc, 0xffffffffULL));
        uint64_t threshold = static_cast<uint64_t>(
            dropoutAttr.getValueAsDouble() * 4294967296.0);
        Value keep = arith::CmpIOp::create(
            builder, loc, arith::CmpIPredicate::uge, hash,
            i64Constant(builder, loc, threshold));
        Value invKeep = arith::ConstantFloatOp::create(
            builder, loc, f32,
            APFloat(static_cast<float>(1.0 / (1.0 - dropoutAttr.getValueAsDouble()))));
        Value scaledWeight = arith::MulFOp::create(builder, loc, weight, invKeep);
        Value zeroWeight = arith::ConstantFloatOp::create(
            builder, loc, f32, APFloat(0.0f));
        outputWeight = arith::SelectOp::create(
            builder, loc, keep, scaledWeight, zeroWeight);
      }
      Value vIndex = addI64(builder, loc,
          mulI64(builder, loc,
              addI64(builder, loc, mulI64(builder, loc,
                  addI64(builder, loc, mulI64(builder, loc, b, Hkv), hkv), Sk), key), Dv),
          dv);
      Value vv = load(in[2], vIndex);
      Value denom = arith::AddFOp::create(
          builder, loc, accumLoop.getRegionIterArgs()[0], weight);
      Value numer = arith::AddFOp::create(
          builder, loc, accumLoop.getRegionIterArgs()[1],
          arith::MulFOp::create(builder, loc, outputWeight, vv));
      scf::YieldOp::create(builder, loc, ValueRange{denom, numer});
    }
    builder.setInsertionPointAfter(accumLoop);
    Value result = arith::DivFOp::create(builder, loc, accumLoop.getResult(1),
                                         accumLoop.getResult(0));
    Type outputType = halfOutput ? storageType : Type(f32);
    if (halfOutput)
      result = arith::TruncFOp::create(builder, loc, outputType, result);
    Value outPtr = LLVM::GEPOp::create(builder, loc, in[outputIndex].getType(), outputType,
                                       in[outputIndex], ValueRange{linearOut});
    LLVM::StoreOp::create(builder, loc, result, outPtr, halfOutput ? 2 : 4);
    if (hasSavedLse) {
      Value ln2 = arith::ConstantFloatOp::create(
          builder, loc, f32, APFloat(0.6931471805599453f));
      Value rowLse = arith::AddFOp::create(
          builder, loc, maxLoop.getResult(0),
          arith::MulFOp::create(
              builder, loc,
              NVVM::Log2Op::create(builder, loc, f32,
                                   accumLoop.getResult(0), false),
              ln2));
      Value firstValue = arith::CmpIOp::create(
          builder, loc, arith::CmpIPredicate::eq, dv,
          i64Constant(builder, loc, 0));
      auto writeLse = scf::IfOp::create(builder, loc, firstValue, false);
      {
        OpBuilder::InsertionGuard lseGuard(builder);
        builder.setInsertionPointToStart(writeLse.thenBlock());
        Value rowIndex = addI64(builder, loc,
            mulI64(builder, loc,
                addI64(builder, loc, mulI64(builder, loc, b, Hq), hq), Sq), q);
        Value rowPtr = LLVM::GEPOp::create(
            builder, loc, in[lseIndex].getType(), f32, in[lseIndex],
            ValueRange{rowIndex});
        LLVM::StoreOp::create(builder, loc, rowLse, rowPtr, 4);
      }
      builder.setInsertionPointAfter(writeLse);
    }
  }
  builder.setInsertionPointAfter(guarded);
  op->erase();
  return success();
}

// Shared ordered FP32 reduction for inline reverse and the outlined residual.
// Keep the probability, product, accumulation and final seed subtraction order.
template <typename Score, typename Dot, typename Dropout>
static Value emitProbabilityRowCorrection(OpBuilder &builder, Location loc,
    Value Sk, Value savedLse, Value log2e, Score score, Dot dot,
    Dropout dropout, Value seed = {}) {
  Value zero = i64Constant(builder, loc, 0);
  Value one = i64Constant(builder, loc, 1);
  auto f32 = builder.getF32Type();
  Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
  auto loop = scf::ForOp::create(builder, loc, zero, Sk, one, ValueRange{zf});
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(loop.getBody());
    Value key = loop.getInductionVar();
    Value weight = NVVM::Ex2Op::create(builder, loc,
        arith::MulFOp::create(builder, loc,
            arith::SubFOp::create(builder, loc, score(key), savedLse), log2e), false);
    Value term = arith::MulFOp::create(builder, loc, weight,
        arith::MulFOp::create(builder, loc, dropout(key), dot(key)));
    scf::YieldOp::create(builder, loc, ValueRange{
        arith::AddFOp::create(builder, loc, loop.getRegionIterArgs()[0], term)});
  }
  builder.setInsertionPointAfter(loop);
  Value result = loop.getResult(0);
  if (seed) result = arith::SubFOp::create(builder, loc, result, seed);
  return result;
}

static LogicalResult materializeSm120AttentionRowCorrectionKernel(
    tessera::tile::AttentionRowCorrectionKernelOp kernel, OpBuilder &builder) {
  // Recheck the complete typed/parent seal at the target boundary.
  if (failed(kernel.verify())) return failure();
  Operation *op = kernel.getOperation();
  ValueRange in = kernel.getInputs();
  Location loc = op->getLoc();
  auto i32 = builder.getI32Type();
  auto i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  bool bias = op->getAttrOfType<BoolAttr>("bias").getValue();
  bool seeded = op->getAttrOfType<BoolAttr>("lse_cotangent").getValue();
  bool causal = op->getAttrOfType<BoolAttr>("causal").getValue();
  bool wide = op->getAttrOfType<StringAttr>("output_storage").getValue() == "f32";
  Type half = op->getAttrOfType<StringAttr>("storage").getValue() == "f16"
      ? Type(builder.getF16Type()) : Type(builder.getBF16Type());
  unsigned lse = 4 + unsigned(bias);
  unsigned output = lse + 1 + unsigned(seeded);
  unsigned dims = output + 1;
  Value B = in[dims], Hq = in[dims+1], Hkv = in[dims+2];
  Value Sq = in[dims+3], Sk = in[dims+4], D = in[dims+5], Dv = in[dims+6];
  Value zero = i64Constant(builder, loc, 0), one = i64Constant(builder, loc, 1);
  Value scale = arith::ConstantFloatOp::create(builder, loc, f32,
      op->getAttrOfType<FloatAttr>("scale").getValue());
  Value log2e = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.4426950408889634f));
  auto load = [&](unsigned role, Value index) -> Value {
    bool fp32 = role >= 4 || (role == 0 && wide);
    Type type = fp32 ? Type(f32) : half;
    Value ptr = LLVM::GEPOp::create(builder, loc, in[role].getType(), type,
        in[role], ValueRange{index});
    Value value = LLVM::LoadOp::create(builder, loc, type, ptr, fp32 ? 4 : 2);
    return fp32 ? value : Value(LLVM::FPExtOp::create(builder, loc, f32, value));
  };
  auto index4 = [&](Value b, Value h, Value row, Value d,
                     Value heads, Value rows, Value width) -> Value {
    return addI64(builder, loc, mulI64(builder, loc,
        addI64(builder, loc, mulI64(builder, loc,
            addI64(builder, loc, mulI64(builder, loc, b, heads), h), rows), row), width), d);
  };
  Value block = arith::ExtUIOp::create(builder, loc, i64,
      NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(builder, loc, i64,
      NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value linear = addI64(builder, loc, mulI64(builder, loc, block,
      i64Constant(builder, loc, op->getAttrOfType<IntegerAttr>("block_threads").getInt())), thread);
  auto active = scf::IfOp::create(builder, loc,
      lessI64(builder, loc, linear, mulI64(builder, loc, mulI64(builder, loc, B, Hq), Sq)), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(active.thenBlock());
    Value q = arith::RemUIOp::create(builder, loc, linear, Sq);
    Value bh = arith::DivUIOp::create(builder, loc, linear, Sq);
    Value h = arith::RemUIOp::create(builder, loc, bh, Hq);
    Value b = arith::DivUIOp::create(builder, loc, bh, Hq);
    Value hk = arith::DivUIOp::create(builder, loc, h,
        arith::DivUIOp::create(builder, loc, Hq, Hkv));
    auto dot = [&](Value key, bool qk) -> Value {
      Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
      Value width = qk ? D : Dv;
      auto loop = scf::ForOp::create(builder, loc, zero, width, one, ValueRange{zf});
      {
        OpBuilder::InsertionGuard dotGuard(builder);
        builder.setInsertionPointToStart(loop.getBody());
        Value d = loop.getInductionVar();
        Value a = load(qk ? 1 : 0, index4(b, h, q, d, Hq, Sq, width));
        Value v = load(qk ? 2 : 3, index4(b, hk, key, d, Hkv, Sk, width));
        scf::YieldOp::create(builder, loc, ValueRange{
            arith::AddFOp::create(builder, loc, loop.getRegionIterArgs()[0],
                arith::MulFOp::create(builder, loc, a, v))});
      }
      builder.setInsertionPointAfter(loop);
      return loop.getResult(0);
    };
    auto score = [&](Value key) -> Value {
      Value value = arith::MulFOp::create(builder, loc, dot(key, true), scale);
      if (bias) {
        auto shape = op->getAttrOfType<DenseI64ArrayAttr>("bias_shape");
        Value bb = shape[0] == 1 ? zero : b, hh = shape[1] == 1 ? zero : h;
        Value qq = shape[2] == 1 ? zero : q, kk = shape[3] == 1 ? zero : key;
        Value index = index4(bb, hh, qq, kk, i64Constant(builder, loc, shape[1]),
            i64Constant(builder, loc, shape[2]), i64Constant(builder, loc, shape[3]));
        value = arith::AddFOp::create(builder, loc, value, load(4, index));
      }
      if (causal) {
        Value aligned = addI64(builder, loc, q, arith::MaxSIOp::create(builder, loc,
            arith::SubIOp::create(builder, loc, Sk, Sq), zero));
        Value legal = arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ule, key, aligned);
        Value negInf = arith::ConstantFloatOp::create(builder, loc, f32,
            APFloat::getInf(APFloat::IEEEsingle(), true));
        value = arith::SelectOp::create(builder, loc, legal, value, negInf);
      }
      return value;
    };
    Value savedLse = load(lse, linear);
    Value seed = seeded ? load(lse + 1, linear) : Value();
    Value delta = emitProbabilityRowCorrection(builder, loc, Sk, savedLse, log2e,
        score, [&](Value key) { return dot(key, false); },
        [&](Value) -> Value { return arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f)); }, seed);
    Value ptr = LLVM::GEPOp::create(builder, loc, in[output].getType(), f32,
        in[output], ValueRange{linear});
    LLVM::StoreOp::create(builder, loc, delta, ptr, 4);
  }
  builder.setInsertionPointAfter(active);
  op->erase();
  return success();
}

static LogicalResult materializeSm120AttentionBackwardKernel(
    Operation *op, OpBuilder &builder, bool externalRows = false) {
  if (externalRows && failed(cast<tessera::tile::AttentionBackwardRowsKernelOp>(op).verify()))
    return failure();
  ValueRange in = op->getOperands();
  auto biasAttr = op->getAttrOfType<BoolAttr>("bias");
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto accum = op->getAttrOfType<StringAttr>("accum");
  auto scaleAttr = op->getAttrOfType<FloatAttr>("scale");
  auto causalAttr = op->getAttrOfType<BoolAttr>("causal");
  auto windowLeftAttr = (externalRows ? builder.getI64IntegerAttr(-1) : op->getAttrOfType<IntegerAttr>("window_left"));
  auto windowRightAttr = (externalRows ? builder.getI64IntegerAttr(-1) : op->getAttrOfType<IntegerAttr>("window_right"));
  auto softcapAttr = (externalRows ? builder.getF32FloatAttr(0) : op->getAttrOfType<FloatAttr>("softcap"));
  auto dropoutAttr = (externalRows ? builder.getF32FloatAttr(0) : op->getAttrOfType<FloatAttr>("dropout_p"));
  auto dropoutSeedAttr = (externalRows ? builder.getI64IntegerAttr(0) : op->getAttrOfType<IntegerAttr>("dropout_seed"));
  auto route = (externalRows ? builder.getStringAttr("deterministic_direct") : op->getAttrOfType<StringAttr>("route"));
  auto deterministic = (externalRows ? builder.getBoolAttr(true) : op->getAttrOfType<BoolAttr>("deterministic"));
  auto workspace = (externalRows ? builder.getI64IntegerAttr(0) : op->getAttrOfType<IntegerAttr>("workspace_bytes"));
  auto workspaceOwner = (externalRows ? builder.getStringAttr("output_element") : op->getAttrOfType<StringAttr>("workspace_owner"));
  auto lseCheckpoint = (externalRows ? builder.getStringAttr("saved") : op->getAttrOfType<StringAttr>("lse_checkpoint"));
  const bool hasBias = biasAttr && biasAttr.getValue();
  const bool hasSavedLse = lseCheckpoint && lseCheckpoint.getValue() == "saved";
  auto savedOutputAttr = op->getAttrOfType<BoolAttr>("saved_output");
  const bool hasSavedOutput = externalRows || (savedOutputAttr && savedOutputAttr.getValue());
  auto lseCotangentAttr = op->getAttrOfType<BoolAttr>("lse_cotangent");
  const bool hasLseCotangent = !externalRows && lseCotangentAttr && lseCotangentAttr.getValue();
  if (op->hasAttr("lse_cotangent") && !lseCotangentAttr)
    return op->emitError("lse_cotangent must be boolean");
  auto biasGradientAttr = op->getAttrOfType<BoolAttr>("bias_gradient");
  const bool hasBiasGradient = biasGradientAttr && biasGradientAttr.getValue();
  auto activityAttr = op->getAttr("gradient_activity");
  auto activity = dyn_cast_or_null<DenseI64ArrayAttr>(activityAttr);
  if (activityAttr && (!activity || !hasSavedLse || !hasSavedOutput ||
      activity.size() != 3 + unsigned(hasBiasGradient) ||
      llvm::any_of(activity.asArrayRef(), [](int64_t x) { return x != 0 && x != 1; }) ||
      llvm::none_of(activity.asArrayRef(), [](int64_t x) { return x == 1; })))
    return op->emitError("gradient_activity requires nonempty binary saved-checkpoint result roles");
  auto gradientActive = [&](unsigned index) { return !activity || activity[index] == 1; };
  auto outputAttr = op->getAttr("gradient_output");
  auto output = dyn_cast_or_null<StringAttr>(outputAttr);
  bool compact = bool(outputAttr);
  unsigned removed = 0;
  if (compact) {
    if (!output || output.getValue() != "compact_v1" || !activity)
      return op->emitError("compact gradient output requires verified saved-checkpoint activity");
    auto launch = op->getAttrOfType<StringAttr>("gradient_launch");
    if (!launch || (launch.getValue() != "packed_v1" && launch.getValue() != "logical_v1"))
      return op->emitError("compact checkpoint launch requires packed_v1 or logical_v1");
    auto threads = op->getAttrOfType<IntegerAttr>("block_threads");
    if (!threads || !threads.getType().isInteger(64) || (threads.getInt() != 64 && threads.getInt() != 128))
      return op->emitError("compact checkpoint threads require 64 or 128");
    removed = llvm::count(activity.asArrayRef(), int64_t(0));
  }
  const bool f16Storage = storage && storage.getValue() == "f16";
  const bool bf16Storage = storage && storage.getValue() == "bf16";
  auto outputStorage = op->getAttrOfType<StringAttr>("output_storage");
  auto correction = op->getAttrOfType<StringAttr>("row_correction");
  bool halfSaved = hasSavedOutput && (f16Storage || bf16Storage);
  if (halfSaved && (!outputStorage || !correction ||
      correction.getValue() != "probability_dot_v_f32_v1" ||
      (outputStorage.getValue() != storage.getValue() && outputStorage.getValue() != "f32")))
    return op->emitError("half saved-output backward requires typed output and f32 row correction");
  if ((op->hasAttr("row_correction") || op->hasAttr("output_storage")) && !halfSaved)
    return op->emitError("typed backward policy requires half saved-output storage");
  auto biasShape = op->getAttrOfType<DenseI64ArrayAttr>("bias_shape");
  bool dynamicBias = biasShape && llvm::any_of(biasShape.asArrayRef(),
      [](int64_t dim) { return ShapedType::isDynamic(dim); });
  if (in.size() != 14 + unsigned(hasBias) + unsigned(hasSavedLse) + unsigned(hasSavedOutput) + unsigned(hasBiasGradient) + unsigned(hasLseCotangent) - removed + 4 * unsigned(dynamicBias) || !storage ||
      (!f16Storage && !bf16Storage && storage.getValue() != "f32") ||
      (hasLseCotangent && (!hasSavedLse || !hasSavedOutput || (storage.getValue() != "f32" && !halfSaved))) ||
      (hasBiasGradient && (!hasBias || !hasSavedOutput || !hasSavedLse || (storage.getValue() != "f32" && !halfSaved))) ||
      !accum || accum.getValue() != "f32" ||
      !scaleAttr || !causalAttr || !windowLeftAttr || !windowRightAttr ||
      !softcapAttr || !dropoutAttr || !dropoutSeedAttr || !route ||
      route.getValue() != "deterministic_direct" ||
      !deterministic || !deterministic.getValue() ||
      (hasSavedOutput && (!hasSavedLse || (storage.getValue() != "f32" && !halfSaved))) || !workspace ||
      workspace.getInt() != 0 || !workspaceOwner ||
      workspaceOwner.getValue() != "output_element" ||
      (lseCheckpoint && lseCheckpoint.getValue() != "recompute" &&
       lseCheckpoint.getValue() != "saved")) {
    op->emitError("sm_120 attention_backward_kernel requires the canonical "
                  "deterministic-direct f16/bf16/f32 ABI with dropout replay "
                  "attrs");
    return failure();
  }

  if (op->hasAttr("bias_shape") && (!biasShape || !hasBias || biasShape.size() != 4 ||
      biasShape[0] <= 0 || biasShape[1] <= 0 ||
      llvm::any_of(biasShape.asArrayRef(), [](int64_t dim) {
        return dim <= 0 && !ShapedType::isDynamic(dim);
      })))
    return op->emitError("attention backward broadcast bias requires fixed batch/head and positive or symbolic sequence dimensions");

  if (dynamicBias && (!hasSavedLse || !hasSavedOutput))
    return op->emitError("symbolic physical bias requires saved output and LSE");
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type();
  Type i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  Type storageType = f16Storage
                         ? Type(builder.getF16Type())
                         : bf16Storage ? Type(builder.getBF16Type()) : Type(f32);
  unsigned storageAlignment = (f16Storage || bf16Storage) ? 2 : 4;
  const unsigned savedOutputIndex = 4;
  const unsigned biasIndex = 4 + unsigned(hasSavedOutput && !externalRows);
  const unsigned lseIndex = biasIndex + unsigned(hasBias);
  const unsigned lseCotangentIndex = lseIndex + unsigned(hasSavedLse);
  const unsigned rowCorrectionIndex = lseIndex + 1;
  const unsigned outputBase = lseCotangentIndex + unsigned(hasLseCotangent) + unsigned(externalRows);
  auto gradientIndex = [&](unsigned role) {
    unsigned index = outputBase;
    for (unsigned i = 0; i < role; ++i) index += !compact || gradientActive(i);
    return index;
  };
  const unsigned dqIndex = gradientIndex(0);
  const unsigned dkIndex = gradientIndex(1);
  const unsigned dvIndex = gradientIndex(2);
  const unsigned dbIndex = gradientIndex(3);
  const unsigned dimIndex = outputBase + 3 + unsigned(hasBiasGradient) - removed;
  Value B = in[dimIndex], Hq = in[dimIndex + 1], Hkv = in[dimIndex + 2];
  Value Sq = in[dimIndex + 3], Sk = in[dimIndex + 4];
  Value D = in[dimIndex + 5], Dv = in[dimIndex + 6];
  Value zero = i64Constant(builder, loc, 0);
  Value one = i64Constant(builder, loc, 1);
  Value scale = arith::ConstantFloatOp::create(
      builder, loc, f32, scaleAttr.getValue());
  Value log2e = arith::ConstantFloatOp::create(
      builder, loc, f32, APFloat(1.4426950408889634f));
  Value ratio = arith::DivUIOp::create(builder, loc, Hq, Hkv);

  auto load = [&](unsigned pointer, Value index) -> Value {
    bool biasPointer = hasBias && pointer == biasIndex;
    bool lsePointer = hasSavedLse && pointer == lseIndex;
    bool lseSeedPointer = hasLseCotangent && pointer == lseCotangentIndex;
    bool wideOutputPointer = halfSaved && outputStorage.getValue() == "f32" &&
        (pointer == 0 || pointer == savedOutputIndex);
    bool wide = biasPointer || lsePointer || lseSeedPointer || wideOutputPointer ||
        (externalRows && pointer == rowCorrectionIndex);
    Type type = wide ? Type(f32) : storageType;
    unsigned alignment = wide ? 4 : storageAlignment;
    Value ptr = LLVM::GEPOp::create(builder, loc, in[pointer].getType(), type,
                                    in[pointer], ValueRange{index});
    Value loaded = LLVM::LoadOp::create(builder, loc, type, ptr, alignment);
    return !wide && (f16Storage || bf16Storage)
        ? Value(LLVM::FPExtOp::create(builder, loc, f32, loaded))
        : loaded;
  };
  auto store = [&](unsigned pointer, Value index, Value value) {
    bool biasGradientPointer = hasBiasGradient && pointer == dbIndex;
    Type type = biasGradientPointer ? Type(f32) : storageType;
    unsigned alignment = biasGradientPointer ? 4 : storageAlignment;
    Value stored = !biasGradientPointer && (f16Storage || bf16Storage)
        ? Value(LLVM::FPTruncOp::create(builder, loc, storageType, value))
        : value;
    Value ptr = LLVM::GEPOp::create(builder, loc, in[pointer].getType(),
                                    type, in[pointer], ValueRange{index});
    LLVM::StoreOp::create(builder, loc, stored, ptr, alignment);
  };
  auto qIndex = [&](Value b, Value h, Value q, Value d) -> Value {
    return addI64(builder, loc,
        mulI64(builder, loc,
            addI64(builder, loc,
                mulI64(builder, loc,
                    addI64(builder, loc, mulI64(builder, loc, b, Hq), h), Sq), q), D), d);
  };
  auto kvIndex = [&](Value b, Value h, Value key, Value d, Value width) -> Value {
    return addI64(builder, loc,
        mulI64(builder, loc,
            addI64(builder, loc,
                mulI64(builder, loc,
                    addI64(builder, loc, mulI64(builder, loc, b, Hkv), h), Sk), key), width), d);
  };
  auto outputIndex = [&](Value b, Value h, Value q, Value d) -> Value {
    return addI64(builder, loc,
        mulI64(builder, loc,
            addI64(builder, loc,
                mulI64(builder, loc,
                    addI64(builder, loc, mulI64(builder, loc, b, Hq), h), Sq), q), Dv), d);
  };
  auto legalKey = [&](Value q, Value key) -> Value {
    Value alignedQuery = addI64(builder, loc, q,
        arith::MaxSIOp::create(builder, loc,
            arith::SubIOp::create(builder, loc, Sk, Sq), zero));
    Value legal = arith::ConstantIntOp::create(builder, loc, 1, 1);
    if (causalAttr.getValue())
      legal = arith::AndIOp::create(
          builder, loc, legal,
          arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ule, key, alignedQuery));
    if (windowLeftAttr.getInt() >= 0) {
      Value lower = arith::SubIOp::create(
          builder, loc, alignedQuery, i64Constant(builder, loc, windowLeftAttr.getInt()));
      legal = arith::AndIOp::create(
          builder, loc, legal,
          arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::sge, key, lower));
    }
    if (windowRightAttr.getInt() >= 0) {
      Value upper = addI64(builder, loc, alignedQuery,
                           i64Constant(builder, loc, windowRightAttr.getInt()));
      legal = arith::AndIOp::create(
          builder, loc, legal,
          arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::sle, key, upper));
    }
    return legal;
  };
  auto rawScore = [&](Value b, Value hq, Value hkv, Value q, Value key) -> Value {
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto dot = scf::ForOp::create(builder, loc, zero, D, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(dot.getBody());
      Value d = dot.getInductionVar();
      Value product = arith::MulFOp::create(
          builder, loc, load(1, qIndex(b, hq, q, d)),
          load(2, kvIndex(b, hkv, key, d, D)));
      scf::YieldOp::create(builder, loc, ValueRange{
          arith::AddFOp::create(builder, loc, dot.getRegionIterArgs()[0], product)});
    }
    builder.setInsertionPointAfter(dot);
    Value value = arith::MulFOp::create(builder, loc, dot.getResult(0), scale);
    if (hasBias) {
      Value bb = biasShape && biasShape[0] == 1 ? zero : b;
      Value bh = biasShape && biasShape[1] == 1 ? zero : hq;
      Value bq = biasShape && biasShape[2] == 1 ? zero : q;
      Value bk = biasShape && biasShape[3] == 1 ? zero : key;
      Value ph = biasShape ? (ShapedType::isDynamic(biasShape[1]) ? in[dimIndex + 7 + 1] : i64Constant(builder, loc, biasShape[1])) : Hq;
      Value pq = biasShape ? (ShapedType::isDynamic(biasShape[2]) ? in[dimIndex + 7 + 2] : i64Constant(builder, loc, biasShape[2])) : Sq;
      Value pk = biasShape ? (ShapedType::isDynamic(biasShape[3]) ? in[dimIndex + 7 + 3] : i64Constant(builder, loc, biasShape[3])) : Sk;
      Value index = addI64(builder, loc,
          mulI64(builder, loc,
              addI64(builder, loc,
                  mulI64(builder, loc,
                      addI64(builder, loc, mulI64(builder, loc, bb, ph), bh), pq), bq), pk), bk);
      value = arith::AddFOp::create(builder, loc, value, load(biasIndex, index));
    }
    return value;
  };
  auto cappedScore = [&](Value raw) -> Value {
    if (softcapAttr.getValueAsDouble() <= 0.0)
      return raw;
    Value cap = arith::ConstantFloatOp::create(
        builder, loc, f32, softcapAttr.getValue());
    return arith::MulFOp::create(
        builder, loc, cap,
        tessera::tile::emitBoundedTanhApprox(
            builder, loc, arith::DivFOp::create(builder, loc, raw, cap)));
  };
  auto softcapDerivative = [&](Value raw) -> Value {
    Value onef = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f));
    if (softcapAttr.getValueAsDouble() <= 0.0)
      return onef;
    Value cap = arith::ConstantFloatOp::create(
        builder, loc, f32, softcapAttr.getValue());
    Value t = tessera::tile::emitBoundedTanhApprox(
        builder, loc, arith::DivFOp::create(builder, loc, raw, cap));
    return arith::SubFOp::create(
        builder, loc, onef, arith::MulFOp::create(builder, loc, t, t));
  };
  auto maskedScore = [&](Value b, Value hq, Value hkv, Value q, Value key) -> Value {
    Value value = cappedScore(rawScore(b, hq, hkv, q, key));
    Value negInf = arith::ConstantFloatOp::create(
        builder, loc, f32, APFloat::getInf(APFloat::IEEEsingle(), true));
    return arith::SelectOp::create(builder, loc, legalKey(q, key), value, negInf);
  };
  auto doDotV = [&](Value b, Value hq, Value hkv, Value q, Value key) -> Value {
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto dot = scf::ForOp::create(builder, loc, zero, Dv, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(dot.getBody());
      Value d = dot.getInductionVar();
      Value product = arith::MulFOp::create(
          builder, loc, load(0, outputIndex(b, hq, q, d)),
          load(3, kvIndex(b, hkv, key, d, Dv)));
      scf::YieldOp::create(builder, loc, ValueRange{
          arith::AddFOp::create(builder, loc, dot.getRegionIterArgs()[0], product)});
    }
    builder.setInsertionPointAfter(dot);
    return dot.getResult(0);
  };
  auto doDotOutput = [&](Value b, Value hq, Value q) -> Value {
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto dot = scf::ForOp::create(builder, loc, zero, Dv, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(dot.getBody());
      Value d = dot.getInductionVar();
      Value index = outputIndex(b, hq, q, d);
      Value product = arith::MulFOp::create(
          builder, loc, load(0, index), load(savedOutputIndex, index));
      scf::YieldOp::create(builder, loc, ValueRange{
          arith::AddFOp::create(builder, loc, dot.getRegionIterArgs()[0], product)});
    }
    builder.setInsertionPointAfter(dot);
    return dot.getResult(0);
  };
  auto dropoutScale = [&](Value b, Value hq, Value q, Value key) -> Value {
    Value onef = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f));
    if (dropoutAttr.getValueAsDouble() <= 0.0)
      return onef;
    Value counter = addI64(builder, loc,
        mulI64(builder, loc,
            addI64(builder, loc, mulI64(builder, loc,
                addI64(builder, loc, mulI64(builder, loc, b, Hq), hq), Sq), q), Sk),
        key);
    Value hash = addI64(builder, loc,
        mulI64(builder, loc, counter, i64Constant(builder, loc, 1664525)),
        i64Constant(builder, loc, static_cast<int64_t>(static_cast<uint32_t>(dropoutSeedAttr.getInt())) + 1013904223LL));
    hash = arith::AndIOp::create(
        builder, loc, hash, i64Constant(builder, loc, 0xffffffffULL));
    uint64_t threshold = static_cast<uint64_t>(
        dropoutAttr.getValueAsDouble() * 4294967296.0);
    Value keep = arith::CmpIOp::create(
        builder, loc, arith::CmpIPredicate::uge, hash,
        i64Constant(builder, loc, threshold));
    Value invKeep = arith::ConstantFloatOp::create(
        builder, loc, f32,
        APFloat(static_cast<float>(1.0 / (1.0 - dropoutAttr.getValueAsDouble()))));
    Value zerof = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    return arith::SelectOp::create(builder, loc, keep, invKeep, zerof);
  };
  // Return the saved row maximum, normalization, and row delta.
  auto rowStats = [&](Value b, Value hq, Value hkv, Value q) -> SmallVector<Value, 3> {
    if (hasSavedLse) {
      Value rowIndex = addI64(builder, loc,
          mulI64(builder, loc,
              addI64(builder, loc, mulI64(builder, loc, b, Hq), hq), Sq), q);
      Value savedLse = load(lseIndex, rowIndex);
      if (externalRows) {
        Value onef = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f));
        // The producer already subtracted dLSE. Never subtract a seed twice.
        return {savedLse, onef, load(rowCorrectionIndex, rowIndex)};
      }
      // Half O has already rounded at its public store. Recompute sum(P*dP)
      // in f32 below instead of feeding that rounding into the row correction.
      if (hasSavedOutput && !halfSaved) {
        Value onef = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f));
        Value delta = doDotOutput(b, hq, q);
        // dScores = P * (dO.V - dot(dO,O) + dLSE). The LSE term
        // contributes only to Q/K/bias; dV still uses the original probability.
        if (hasLseCotangent)
          delta = arith::SubFOp::create(builder, loc, delta,
                                      load(lseCotangentIndex, rowIndex));
        return {savedLse, onef, delta};
      }
      Value seed = hasLseCotangent ? load(lseCotangentIndex, rowIndex) : Value();
      Value delta = emitProbabilityRowCorrection(builder, loc, Sk, savedLse, log2e,
          [&](Value key) { return maskedScore(b, hq, hkv, q, key); },
          [&](Value key) { return doDotV(b, hq, hkv, q, key); },
          [&](Value key) { return dropoutScale(b, hq, q, key); }, seed);
      Value onef = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f));
      return {savedLse, onef, delta};
    }
    Value negInf = arith::ConstantFloatOp::create(
        builder, loc, f32, APFloat::getInf(APFloat::IEEEsingle(), true));
    auto maxLoop = scf::ForOp::create(builder, loc, zero, Sk, one, ValueRange{negInf});
    {
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(maxLoop.getBody());
      Value s = maskedScore(b, hq, hkv, q, maxLoop.getInductionVar());
      scf::YieldOp::create(builder, loc, ValueRange{
          arith::MaximumFOp::create(builder, loc, maxLoop.getRegionIterArgs()[0], s)});
    }
    builder.setInsertionPointAfter(maxLoop);
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto sums = scf::ForOp::create(builder, loc, zero, Sk, one, ValueRange{zf, zf});
    {
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(sums.getBody());
      Value key = sums.getInductionVar();
      Value shifted = arith::SubFOp::create(
          builder, loc, maskedScore(b, hq, hkv, q, key), maxLoop.getResult(0));
      Value weight = NVVM::Ex2Op::create(
          builder, loc, arith::MulFOp::create(builder, loc, shifted, log2e), false);
      Value denom = arith::AddFOp::create(
          builder, loc, sums.getRegionIterArgs()[0], weight);
      Value numer = arith::AddFOp::create(
          builder, loc, sums.getRegionIterArgs()[1],
          arith::MulFOp::create(builder, loc, weight,
              arith::MulFOp::create(builder, loc,
                  dropoutScale(b, hq, q, key), doDotV(b, hq, hkv, q, key))));
      scf::YieldOp::create(builder, loc, ValueRange{denom, numer});
    }
    builder.setInsertionPointAfter(sums);
    Value delta = arith::DivFOp::create(
        builder, loc, sums.getResult(1), sums.getResult(0));
    return {maxLoop.getResult(0), sums.getResult(0), delta};
  };
  auto probability = [&](Value b, Value hq, Value hkv, Value q, Value key,
                         Value maxValue, Value denom) -> Value {
    if (hasSavedLse)
      return NVVM::Ex2Op::create(
          builder, loc,
          arith::MulFOp::create(builder, loc,
              arith::SubFOp::create(builder, loc,
                  maskedScore(b, hq, hkv, q, key), maxValue), log2e), false);
    Value shifted = arith::SubFOp::create(
        builder, loc, maskedScore(b, hq, hkv, q, key), maxValue);
    Value weight = NVVM::Ex2Op::create(
        builder, loc, arith::MulFOp::create(builder, loc, shifted, log2e), false);
    return arith::DivFOp::create(builder, loc, weight, denom);
  };

  Value block = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value linear = addI64(builder, loc,
      mulI64(builder, loc, block, i64Constant(builder, loc,
          (compact || externalRows) ? op->getAttrOfType<IntegerAttr>("block_threads").getInt() : 128)), thread);
  Value dqCount = mulI64(builder, loc, mulI64(builder, loc,
      mulI64(builder, loc, B, Hq), Sq), D);
  Value dkCount = mulI64(builder, loc, mulI64(builder, loc,
      mulI64(builder, loc, B, Hkv), Sk), D);
  Value dvCount = mulI64(builder, loc, mulI64(builder, loc,
      mulI64(builder, loc, B, Hkv), Sk), Dv);

  bool packed = compact && op->getAttrOfType<StringAttr>("gradient_launch").getValue() == "packed_v1";
  if (packed && !gradientActive(0)) dqCount = zero;
  if (packed && !gradientActive(1)) dkCount = zero;
  if (packed && !gradientActive(2)) dvCount = zero;
  auto dqGuard = scf::IfOp::create(builder, loc,
      lessI64(builder, loc, linear, dqCount), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(dqGuard.thenBlock());
    if (!gradientActive(0)) {
      if (!compact)
        store(dqIndex, linear,
              arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f)));
    } else {
    Value d = arith::RemUIOp::create(builder, loc, linear, D);
    Value t0 = arith::DivUIOp::create(builder, loc, linear, D);
    Value q = arith::RemUIOp::create(builder, loc, t0, Sq);
    Value t1 = arith::DivUIOp::create(builder, loc, t0, Sq);
    Value hq = arith::RemUIOp::create(builder, loc, t1, Hq);
    Value b = arith::DivUIOp::create(builder, loc, t1, Hq);
    Value hkv = arith::DivUIOp::create(builder, loc, hq, ratio);
    SmallVector<Value, 3> stats = rowStats(b, hq, hkv, q);
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto sum = scf::ForOp::create(builder, loc, zero, Sk, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard sumGuard(builder);
      builder.setInsertionPointToStart(sum.getBody());
      Value key = sum.getInductionVar();
      Value raw = rawScore(b, hq, hkv, q, key);
      Value p = probability(b, hq, hkv, q, key, stats[0], stats[1]);
      Value ds = arith::MulFOp::create(builder, loc, p,
          arith::SubFOp::create(builder, loc,
              arith::MulFOp::create(builder, loc,
                  dropoutScale(b, hq, q, key), doDotV(b, hq, hkv, q, key)),
              stats[2]));
      ds = arith::MulFOp::create(builder, loc, ds, softcapDerivative(raw));
      Value term = arith::MulFOp::create(builder, loc,
          arith::MulFOp::create(builder, loc, ds, scale),
          load(2, kvIndex(b, hkv, key, d, D)));
      scf::YieldOp::create(builder, loc, ValueRange{
          arith::AddFOp::create(builder, loc, sum.getRegionIterArgs()[0], term)});
    }
    builder.setInsertionPointAfter(sum);
    store(dqIndex, linear, sum.getResult(0));
    }
  }
  builder.setInsertionPointAfter(dqGuard);

  Value dkLinear = arith::SubIOp::create(builder, loc, linear, dqCount);
  auto dkGuard = scf::IfOp::create(builder, loc,
      arith::AndIOp::create(builder, loc,
          arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::uge, linear, dqCount),
          lessI64(builder, loc, dkLinear, dkCount)), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(dkGuard.thenBlock());
    if (!gradientActive(1)) {
      if (!compact)
        store(dkIndex, dkLinear,
              arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f)));
    } else {
    Value d = arith::RemUIOp::create(builder, loc, dkLinear, D);
    Value t0 = arith::DivUIOp::create(builder, loc, dkLinear, D);
    Value key = arith::RemUIOp::create(builder, loc, t0, Sk);
    Value t1 = arith::DivUIOp::create(builder, loc, t0, Sk);
    Value hkv = arith::RemUIOp::create(builder, loc, t1, Hkv);
    Value b = arith::DivUIOp::create(builder, loc, t1, Hkv);
    Value hqBegin = mulI64(builder, loc, hkv, ratio);
    Value hqEnd = addI64(builder, loc, hqBegin, ratio);
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto headLoop = scf::ForOp::create(builder, loc, hqBegin, hqEnd, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard headGuard(builder);
      builder.setInsertionPointToStart(headLoop.getBody());
      Value hq = headLoop.getInductionVar();
      auto qLoop = scf::ForOp::create(builder, loc, zero, Sq, one,
                                      ValueRange{headLoop.getRegionIterArgs()[0]});
      {
        OpBuilder::InsertionGuard qGuard(builder);
        builder.setInsertionPointToStart(qLoop.getBody());
        Value q = qLoop.getInductionVar();
        SmallVector<Value, 3> stats = rowStats(b, hq, hkv, q);
        Value raw = rawScore(b, hq, hkv, q, key);
        Value p = probability(b, hq, hkv, q, key, stats[0], stats[1]);
        Value ds = arith::MulFOp::create(builder, loc, p,
            arith::SubFOp::create(builder, loc,
                arith::MulFOp::create(builder, loc,
                    dropoutScale(b, hq, q, key), doDotV(b, hq, hkv, q, key)),
                stats[2]));
        ds = arith::MulFOp::create(builder, loc, ds, softcapDerivative(raw));
        Value term = arith::MulFOp::create(builder, loc,
            arith::MulFOp::create(builder, loc, ds, scale),
            load(1, qIndex(b, hq, q, d)));
        scf::YieldOp::create(builder, loc, ValueRange{
            arith::AddFOp::create(builder, loc, qLoop.getRegionIterArgs()[0], term)});
      }
      builder.setInsertionPointAfter(qLoop);
      scf::YieldOp::create(builder, loc, ValueRange{qLoop.getResult(0)});
    }
    builder.setInsertionPointAfter(headLoop);
    store(dkIndex, dkLinear, headLoop.getResult(0));
    }
  }
  builder.setInsertionPointAfter(dkGuard);

  Value dvLinear = arith::SubIOp::create(builder, loc, dkLinear, dkCount);
  Value dqDkCount = addI64(builder, loc, dqCount, dkCount);
  auto dvGuard = scf::IfOp::create(builder, loc,
      arith::AndIOp::create(builder, loc,
          arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::uge, linear, dqDkCount),
          lessI64(builder, loc, dvLinear, dvCount)), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(dvGuard.thenBlock());
    if (!gradientActive(2)) {
      if (!compact)
        store(dvIndex, dvLinear,
              arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f)));
    } else {
    Value d = arith::RemUIOp::create(builder, loc, dvLinear, Dv);
    Value t0 = arith::DivUIOp::create(builder, loc, dvLinear, Dv);
    Value key = arith::RemUIOp::create(builder, loc, t0, Sk);
    Value t1 = arith::DivUIOp::create(builder, loc, t0, Sk);
    Value hkv = arith::RemUIOp::create(builder, loc, t1, Hkv);
    Value b = arith::DivUIOp::create(builder, loc, t1, Hkv);
    Value hqBegin = mulI64(builder, loc, hkv, ratio);
    Value hqEnd = addI64(builder, loc, hqBegin, ratio);
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    auto headLoop = scf::ForOp::create(builder, loc, hqBegin, hqEnd, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard headGuard(builder);
      builder.setInsertionPointToStart(headLoop.getBody());
      Value hq = headLoop.getInductionVar();
      auto qLoop = scf::ForOp::create(builder, loc, zero, Sq, one,
                                      ValueRange{headLoop.getRegionIterArgs()[0]});
      {
        OpBuilder::InsertionGuard qGuard(builder);
        builder.setInsertionPointToStart(qLoop.getBody());
        Value q = qLoop.getInductionVar();
        Value rowNormalizer;
        Value rowDenominator;
        if (hasSavedLse) {
          Value rowIndex = addI64(builder, loc,
              mulI64(builder, loc,
                  addI64(builder, loc, mulI64(builder, loc, b, Hq), hq), Sq), q);
          rowNormalizer = load(lseIndex, rowIndex);
          rowDenominator = arith::ConstantFloatOp::create(
              builder, loc, f32, APFloat(1.0f));
        } else {
          SmallVector<Value, 3> stats = rowStats(b, hq, hkv, q);
          rowNormalizer = stats[0];
          rowDenominator = stats[1];
        }
        // Saved LSE is sufficient for dV probabilities. Do not compute the
        // dO.V row delta here: it is consumed by dQ/dK only and used to cost
        // O(Sk*Dv) work for every dV output element.
        Value p = probability(
            b, hq, hkv, q, key, rowNormalizer, rowDenominator);
        Value term = arith::MulFOp::create(builder, loc,
            arith::MulFOp::create(builder, loc, p,
                dropoutScale(b, hq, q, key)),
            load(0, outputIndex(b, hq, q, d)));
        scf::YieldOp::create(builder, loc, ValueRange{
            arith::AddFOp::create(builder, loc, qLoop.getRegionIterArgs()[0], term)});
      }
      builder.setInsertionPointAfter(qLoop);
      scf::YieldOp::create(builder, loc, ValueRange{qLoop.getResult(0)});
    }
    builder.setInsertionPointAfter(headLoop);
    store(dvIndex, dvLinear, headLoop.getResult(0));
    }
  }
  builder.setInsertionPointAfter(dvGuard);
  if (hasBiasGradient && (!compact || gradientActive(3)) && biasShape) {
    // One thread owns one physical bias gradient. Reduce all corresponding
    // logical scores in B/Hq/Q/K order; no atomics or dense temporary buffer.
    Value gradientBegin = addI64(builder, loc, dqDkCount, dvCount);
    Value biasLinear = arith::SubIOp::create(builder, loc, linear, gradientBegin);
    SmallVector<Value, 4> physical, logical{B,Hq,Sq,Sk};
    Value count = one;
    for (unsigned axis = 0; axis < 4; ++axis) {
      int64_t extent = biasShape[axis];
      physical.push_back(ShapedType::isDynamic(extent) ?
          in[dimIndex + 7 + axis] : i64Constant(builder, loc, extent));
      count = mulI64(builder, loc, count, physical.back());
    }
    auto biasGuard = scf::IfOp::create(builder, loc,
        arith::AndIOp::create(builder, loc,
            arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::uge, linear, gradientBegin),
            lessI64(builder, loc, biasLinear, count)), false);
    {
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(biasGuard.thenBlock());
    if (!gradientActive(3)) {
      if (!compact)
        store(dbIndex, biasLinear,
              arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f)));
    } else {
      SmallVector<Value, 4> coordinates(4);
      Value remaining = biasLinear;
      for (int axis = 3; axis >= 0; --axis) {
        coordinates[axis] = arith::RemUIOp::create(builder, loc, remaining, physical[axis]);
        remaining = arith::DivUIOp::create(builder, loc, remaining, physical[axis]);
      }
      SmallVector<Value, 4> indices;
      auto contribution = [&]() -> Value {
        Value b = indices[0], hq = indices[1], q = indices[2], key = indices[3];
        Value hkv = arith::DivUIOp::create(builder, loc, hq, ratio);
        auto stats = rowStats(b,hq,hkv,q);
        Value p = probability(b,hq,hkv,q,key,stats[0],stats[1]);
        Value ds = arith::MulFOp::create(builder, loc, p,
            arith::SubFOp::create(builder, loc,
                arith::MulFOp::create(builder, loc,
                    dropoutScale(b,hq,q,key), doDotV(b,hq,hkv,q,key)), stats[2]));
        return arith::MulFOp::create(builder, loc, ds,
            softcapDerivative(rawScore(b,hq,hkv,q,key)));
      };
      std::function<Value(unsigned,Value)> reduce = [&](unsigned axis, Value acc) -> Value {
        if (axis == 4)
          return arith::AddFOp::create(builder, loc, acc, contribution());
        Value begin = biasShape[axis] == 1 ? zero : coordinates[axis];
        Value end = biasShape[axis] == 1 ? logical[axis] : addI64(builder, loc, begin, one);
        auto loop = scf::ForOp::create(builder, loc, begin, end, one, ValueRange{acc});
        {
          OpBuilder::InsertionGuard loopGuard(builder);
          builder.setInsertionPointToStart(loop.getBody());
          indices.push_back(loop.getInductionVar());
          Value value = reduce(axis+1, loop.getRegionIterArgs()[0]);
          indices.pop_back();
          scf::YieldOp::create(builder, loc, ValueRange{value});
        }
        builder.setInsertionPointAfter(loop);
        return loop.getResult(0);
      };
      Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
      store(dbIndex, biasLinear, reduce(0,zf));
    }
    }
    builder.setInsertionPointAfter(biasGuard);
  } else   if (hasBiasGradient && (!compact || gradientActive(3))) {
    Value gradientBegin = addI64(builder, loc, dqDkCount, dvCount);
    Value biasLinear = arith::SubIOp::create(builder, loc, linear, gradientBegin);
    Value biasCount = mulI64(builder, loc, mulI64(builder, loc,
        mulI64(builder, loc, B, Hq), Sq), Sk);
    auto biasGuard = scf::IfOp::create(builder, loc,
        arith::AndIOp::create(builder, loc,
            arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::uge, linear, gradientBegin),
            lessI64(builder, loc, biasLinear, biasCount)), false);
    {
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(biasGuard.thenBlock());
    if (!gradientActive(3)) {
      if (!compact)
        store(dbIndex, biasLinear,
              arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f)));
    } else {
      Value key = arith::RemUIOp::create(builder, loc, biasLinear, Sk);
      Value row = arith::DivUIOp::create(builder, loc, biasLinear, Sk);
      Value q = arith::RemUIOp::create(builder, loc, row, Sq);
      Value headBatch = arith::DivUIOp::create(builder, loc, row, Sq);
      Value hq = arith::RemUIOp::create(builder, loc, headBatch, Hq);
      Value b = arith::DivUIOp::create(builder, loc, headBatch, Hq);
      Value hkv = arith::DivUIOp::create(builder, loc, hq, ratio);
      SmallVector<Value, 3> stats = rowStats(b, hq, hkv, q);
      Value p = probability(b, hq, hkv, q, key, stats[0], stats[1]);
      // Bias is added after Q.K scaling. Its derivative therefore has no
      // extra attention scale, unlike dQ/dK.
      Value ds = arith::MulFOp::create(builder, loc, p,
          arith::SubFOp::create(builder, loc,
              arith::MulFOp::create(builder, loc,
                  dropoutScale(b, hq, q, key), doDotV(b, hq, hkv, q, key)),
              stats[2]));
      ds = arith::MulFOp::create(builder, loc, ds,
          softcapDerivative(rawScore(b, hq, hkv, q, key)));
      store(dbIndex, biasLinear, ds);
    }
    }
    builder.setInsertionPointAfter(biasGuard);
  }
  op->erase();
  return success();
}

static LogicalResult materializeSm120PagedKVReadKernel(
    tessera::tile::PagedKVReadKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange in = kernel.getInputs();
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto tableStorage = op->getAttrOfType<StringAttr>("table_storage");
  auto route = op->getAttrOfType<StringAttr>("route");
  if (in.size() != 10 || !storage || storage.getValue() != "f32" ||
      !tableStorage || tableStorage.getValue() != "i32" || !route ||
      route.getValue() != "direct") {
    op->emitError("sm_120 paged_kv_read_kernel requires f32 pages, i32 table, "
                  "route=direct, and the canonical ten-operand ABI");
    return failure();
  }
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type();
  Type i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  Value pageSize = in[5], heads = in[6], dim = in[7];
  Value start = in[8], tokens = in[9];
  Value block = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value z = addI64(builder, loc,
      mulI64(builder, loc, block, i64Constant(builder, loc, 256)), thread);
  Value total = mulI64(builder, loc, mulI64(builder, loc, tokens, heads), dim);
  auto guarded = scf::IfOp::create(builder, loc, lessI64(builder, loc, z, total), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(guarded.thenBlock());
    Value d = arith::RemUIOp::create(builder, loc, z, dim);
    Value t0 = arith::DivUIOp::create(builder, loc, z, dim);
    Value h = arith::RemUIOp::create(builder, loc, t0, heads);
    Value token = arith::DivUIOp::create(builder, loc, t0, heads);
    Value logical = addI64(builder, loc, start, token);
    Value logicalPage = arith::DivUIOp::create(builder, loc, logical, pageSize);
    Value pageOffset = arith::RemUIOp::create(builder, loc, logical, pageSize);
    Value tablePtr = LLVM::GEPOp::create(builder, loc, in[1].getType(), i32,
                                         in[1], ValueRange{logicalPage});
    Value physical32 = LLVM::LoadOp::create(builder, loc, i32, tablePtr, 4);
    Value physical = arith::ExtUIOp::create(builder, loc, i64, physical32);
    Value pageIndex = addI64(builder, loc,
        mulI64(builder, loc,
            addI64(builder, loc,
                mulI64(builder, loc,
                    addI64(builder, loc, mulI64(builder, loc, physical, pageSize), pageOffset),
                    heads), h),
            dim), d);
    Value pagePtr = LLVM::GEPOp::create(builder, loc, in[0].getType(), f32,
                                        in[0], ValueRange{pageIndex});
    Value value = LLVM::LoadOp::create(builder, loc, f32, pagePtr, 4);
    Value outPtr = LLVM::GEPOp::create(builder, loc, in[2].getType(), f32,
                                       in[2], ValueRange{z});
    LLVM::StoreOp::create(builder, loc, value, outPtr, 4);
  }
  builder.setInsertionPointAfter(guarded);
  op->erase();
  return success();
}

static LogicalResult materializeSm120PagedAttentionKernel(
    tessera::tile::PagedAttentionKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange in = kernel.getInputs();
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto accum = op->getAttrOfType<StringAttr>("accum");
  auto tableStorage = op->getAttrOfType<StringAttr>("table_storage");
  auto indexStorage = op->getAttrOfType<StringAttr>("token_index_storage");
  auto scaleAttr = op->getAttrOfType<FloatAttr>("scale");
  auto causalAttr = op->getAttrOfType<BoolAttr>("causal");
  auto route = op->getAttrOfType<StringAttr>("route");
  if (in.size() != 14 || !storage || storage.getValue() != "f32" ||
      !accum || accum.getValue() != "f32" || !tableStorage ||
      tableStorage.getValue() != "i32" || !indexStorage ||
      indexStorage.getValue() != "i64" || !scaleAttr || !causalAttr ||
      !route || route.getValue() != "fused_direct") {
    op->emitError("sm_120 paged_attention_kernel requires the canonical "
                  "f32/i32/i64 fused-direct ABI");
    return failure();
  }
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type(), i64 = builder.getI64Type();
  auto f32 = builder.getF32Type();
  Value pageSize=in[8], H=in[9], Q=in[10], T=in[11], D=in[12];
  Value causalOffset=in[13], zero=i64Constant(builder,loc,0), one=i64Constant(builder,loc,1);
  Value scale=arith::ConstantFloatOp::create(builder,loc,f32,scaleAttr.getValue());
  Value log2e=arith::ConstantFloatOp::create(builder,loc,f32,APFloat(1.4426950408889634f));
  auto loadF32 = [&](Value base, Value index) -> Value {
    Value ptr=LLVM::GEPOp::create(builder,loc,base.getType(),f32,base,ValueRange{index});
    return LLVM::LoadOp::create(builder,loc,f32,ptr,4);
  };
  auto pageValue = [&](unsigned pageBuffer, Value tokenOrdinal, Value h, Value d) -> Value {
    Value indexPtr=LLVM::GEPOp::create(builder,loc,in[4].getType(),i64,in[4],ValueRange{tokenOrdinal});
    Value logical=LLVM::LoadOp::create(builder,loc,i64,indexPtr,8);
    Value logicalPage=arith::DivUIOp::create(builder,loc,logical,pageSize);
    Value pageOffset=arith::RemUIOp::create(builder,loc,logical,pageSize);
    Value tablePtr=LLVM::GEPOp::create(builder,loc,in[3].getType(),i32,in[3],ValueRange{logicalPage});
    Value physical=arith::ExtUIOp::create(builder,loc,i64,
        LLVM::LoadOp::create(builder,loc,i32,tablePtr,4));
    Value pageIndex=addI64(builder,loc,
        mulI64(builder,loc,
            addI64(builder,loc,
                mulI64(builder,loc,
                    addI64(builder,loc,mulI64(builder,loc,physical,pageSize),pageOffset),H),h),D),d);
    return loadF32(in[pageBuffer],pageIndex);
  };
  auto score = [&](Value h, Value q, Value token) -> Value {
    Value zf=arith::ConstantFloatOp::create(builder,loc,f32,APFloat(0.0f));
    auto dot=scf::ForOp::create(builder,loc,zero,D,one,ValueRange{zf});
    {
      OpBuilder::InsertionGuard guard(builder); builder.setInsertionPointToStart(dot.getBody());
      Value d=dot.getInductionVar();
      Value qIndex=addI64(builder,loc,mulI64(builder,loc,addI64(builder,loc,mulI64(builder,loc,h,Q),q),D),d);
      Value product=arith::MulFOp::create(builder,loc,loadF32(in[0],qIndex),pageValue(1,token,h,d));
      scf::YieldOp::create(builder,loc,ValueRange{arith::AddFOp::create(builder,loc,dot.getRegionIterArgs()[0],product)});
    }
    builder.setInsertionPointAfter(dot);
    Value value=arith::MulFOp::create(builder,loc,dot.getResult(0),scale);
    if (causalAttr.getValue()) {
      Value limit=addI64(builder,loc,q,causalOffset);
      Value legal=arith::CmpIOp::create(builder,loc,arith::CmpIPredicate::ule,token,limit);
      Value negInf=arith::ConstantFloatOp::create(builder,loc,f32,
          APFloat::getInf(APFloat::IEEEsingle(),true));
      value=arith::SelectOp::create(builder,loc,legal,value,negInf);
    }
    return value;
  };
  Value z=addI64(builder,loc,
      mulI64(builder,loc,arith::ExtUIOp::create(builder,loc,i64,NVVM::BlockIdXOp::create(builder,loc,i32)),
             i64Constant(builder,loc,128)),
      arith::ExtUIOp::create(builder,loc,i64,NVVM::ThreadIdXOp::create(builder,loc,i32)));
  Value total=mulI64(builder,loc,mulI64(builder,loc,H,Q),D);
  auto guarded=scf::IfOp::create(builder,loc,lessI64(builder,loc,z,total),false);
  {
    OpBuilder::InsertionGuard guard(builder); builder.setInsertionPointToStart(guarded.thenBlock());
    Value d=arith::RemUIOp::create(builder,loc,z,D), t0=arith::DivUIOp::create(builder,loc,z,D);
    Value q=arith::RemUIOp::create(builder,loc,t0,Q), h=arith::DivUIOp::create(builder,loc,t0,Q);
    Value negInf=arith::ConstantFloatOp::create(builder,loc,f32,APFloat::getInf(APFloat::IEEEsingle(),true));
    auto maxLoop=scf::ForOp::create(builder,loc,zero,T,one,ValueRange{negInf});
    { OpBuilder::InsertionGuard g(builder); builder.setInsertionPointToStart(maxLoop.getBody());
      Value s=score(h,q,maxLoop.getInductionVar());
      scf::YieldOp::create(builder,loc,ValueRange{arith::MaximumFOp::create(builder,loc,maxLoop.getRegionIterArgs()[0],s)}); }
    builder.setInsertionPointAfter(maxLoop);
    Value zf=arith::ConstantFloatOp::create(builder,loc,f32,APFloat(0.0f));
    auto sums=scf::ForOp::create(builder,loc,zero,T,one,ValueRange{zf,zf});
    { OpBuilder::InsertionGuard g(builder); builder.setInsertionPointToStart(sums.getBody());
      Value token=sums.getInductionVar();
      Value shifted=arith::SubFOp::create(builder,loc,score(h,q,token),maxLoop.getResult(0));
      Value weight=NVVM::Ex2Op::create(builder,loc,arith::MulFOp::create(builder,loc,shifted,log2e),false);
      Value denom=arith::AddFOp::create(builder,loc,sums.getRegionIterArgs()[0],weight);
      Value numer=arith::AddFOp::create(builder,loc,sums.getRegionIterArgs()[1],
          arith::MulFOp::create(builder,loc,weight,pageValue(2,token,h,d)));
      scf::YieldOp::create(builder,loc,ValueRange{denom,numer}); }
    builder.setInsertionPointAfter(sums);
    Value out=arith::DivFOp::create(builder,loc,sums.getResult(1),sums.getResult(0));
    Value outPtr=LLVM::GEPOp::create(builder,loc,in[5].getType(),f32,in[5],ValueRange{z});
    LLVM::StoreOp::create(builder,loc,out,outPtr,4);
  }
  builder.setInsertionPointAfter(guarded); op->erase(); return success();
}

static Value sm120LinearThread(OpBuilder &builder, Location loc,
                               int64_t threads) {
  Type i32 = builder.getI32Type();
  Type i64 = builder.getI64Type();
  Value block = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
  Value thread = arith::ExtUIOp::create(
      builder, loc, i64, NVVM::ThreadIdXOp::create(builder, loc, i32));
  return addI64(builder, loc,
                mulI64(builder, loc, block, i64Constant(builder, loc, threads)),
                thread);
}

static Value sm120LoadF32(OpBuilder &builder, Location loc, Value base,
                          Value index) {
  FloatType f32 = builder.getF32Type();
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), f32, base,
                                  ValueRange{index});
  return LLVM::LoadOp::create(builder, loc, f32, ptr, 4);
}

static Value sm120LoadI32(OpBuilder &builder, Location loc, Value base,
                          Value index) {
  Type i32 = builder.getI32Type();
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), i32, base,
                                  ValueRange{index});
  return LLVM::LoadOp::create(builder, loc, i32, ptr, 4);
}

static void sm120StoreF32(OpBuilder &builder, Location loc, Value base,
                          Value index, Value value) {
  Type f32 = builder.getF32Type();
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), f32, base,
                                  ValueRange{index});
  LLVM::StoreOp::create(builder, loc, value, ptr, 4);
}

static Value sm120LoadStorageF32(OpBuilder &builder, Location loc, Value base,
                                 Value index, StringRef storage) {
  Type f32 = builder.getF32Type();
  Type type = storage == "f16" ? Type(builder.getF16Type())
            : storage == "bf16" ? Type(builder.getBF16Type()) : f32;
  unsigned alignment = storage == "f32" ? 4 : 2;
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), type, base,
                                  ValueRange{index});
  Value loaded = LLVM::LoadOp::create(builder, loc, type, ptr, alignment);
  return storage == "f32" ? loaded
                           : Value(LLVM::FPExtOp::create(builder, loc, f32, loaded));
}

static void sm120StoreStorageF32(OpBuilder &builder, Location loc, Value base,
                                 Value index, Value value, StringRef storage) {
  Type type = storage == "f16" ? Type(builder.getF16Type())
            : storage == "bf16" ? Type(builder.getBF16Type())
                                  : Type(builder.getF32Type());
  unsigned alignment = storage == "f32" ? 4 : 2;
  Value stored = storage == "f32"
      ? value : Value(LLVM::FPTruncOp::create(builder, loc, type, value));
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), type, base,
                                  ValueRange{index});
  LLVM::StoreOp::create(builder, loc, stored, ptr, alignment);
}

static Value sm120ExpF32(OpBuilder &builder, Location loc, Value value) {
  Value log2e = arith::ConstantFloatOp::create(
      builder, loc, builder.getF32Type(), APFloat(1.4426950408889634f));
  return NVVM::Ex2Op::create(
      builder, loc, arith::MulFOp::create(builder, loc, value, log2e), false);
}

static LogicalResult materializeSm120ReplaySSMDecodeKernel(
    tessera::tile::ReplaySSMDecodeKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange in = kernel.getInputs();
  auto storage = op->getAttrOfType<StringAttr>("storage");
  auto route = op->getAttrOfType<StringAttr>("route");
  if (in.size() != 11 || !storage || storage.getValue() != "f32" || !route ||
      route.getValue() != "output_only") {
    op->emitError("sm_120 ReplaySSM decode requires f32 output_only and the canonical ABI");
    return failure();
  }
  Location loc = op->getLoc();
  FloatType f32 = builder.getF32Type();
  Value B = in[7], D = in[8], N = in[9], M = in[10];
  Value z = sm120LinearThread(builder, loc, 128);
  Value total = mulI64(builder, loc, B, D);
  auto guarded = scf::IfOp::create(builder, loc, lessI64(builder, loc, z, total), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(guarded.thenBlock());
    Value bi = arith::DivUIOp::create(builder, loc, z, D);
    Value di = arith::RemUIOp::create(builder, loc, z, D);
    Value zero = i64Constant(builder, loc, 0), one = i64Constant(builder, loc, 1);
    Value zf = arith::ConstantFloatOp::create(builder, loc, f32, APFloat(0.0f));
    Value a = sm120LoadF32(builder, loc, in[5], di);
    auto decayLoop = scf::ForOp::create(builder, loc, zero, M, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(decayLoop.getBody());
      Value i = decayLoop.getInductionVar();
      Value q = addI64(builder, loc,
          mulI64(builder, loc, addI64(builder, loc, mulI64(builder, loc, i, B), bi), D), di);
      Value term = arith::MulFOp::create(builder, loc,
          sm120LoadF32(builder, loc, in[0], q), a);
      scf::YieldOp::create(builder, loc, ValueRange{arith::AddFOp::create(
          builder, loc, decayLoop.getRegionIterArgs()[0], term)});
    }
    builder.setInsertionPointAfter(decayLoop);
    auto baseLoop = scf::ForOp::create(builder, loc, zero, N, one, ValueRange{zf});
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(baseLoop.getBody());
      Value n = baseLoop.getInductionVar();
      Value cIdx = addI64(builder, loc, mulI64(builder, loc, bi, N), n);
      Value sIdx = addI64(builder, loc, mulI64(builder, loc, z, N), n);
      Value term = arith::MulFOp::create(builder, loc,
          sm120LoadF32(builder, loc, in[4], cIdx),
          sm120LoadF32(builder, loc, in[3], sIdx));
      scf::YieldOp::create(builder, loc, ValueRange{arith::AddFOp::create(
          builder, loc, baseLoop.getRegionIterArgs()[0], term)});
    }
    builder.setInsertionPointAfter(baseLoop);
    Value initial = arith::MulFOp::create(
        builder, loc, baseLoop.getResult(0), sm120ExpF32(builder, loc, decayLoop.getResult(0)));
    auto replayLoop = scf::ForOp::create(builder, loc, zero, M, one,
                                         ValueRange{zf, initial});
    {
      OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(replayLoop.getBody());
      Value i = replayLoop.getInductionVar();
      Value q = addI64(builder, loc,
          mulI64(builder, loc, addI64(builder, loc, mulI64(builder, loc, i, B), bi), D), di);
      Value delta = sm120LoadF32(builder, loc, in[0], q);
      Value prefix = arith::AddFOp::create(builder, loc,
          replayLoop.getRegionIterArgs()[0], arith::MulFOp::create(builder, loc, delta, a));
      auto gramLoop = scf::ForOp::create(builder, loc, zero, N, one, ValueRange{zf});
      {
        OpBuilder::InsertionGuard gramGuard(builder);
        builder.setInsertionPointToStart(gramLoop.getBody());
        Value n = gramLoop.getInductionVar();
        Value cIdx = addI64(builder, loc, mulI64(builder, loc, bi, N), n);
        Value bIdx = addI64(builder, loc,
            mulI64(builder, loc, addI64(builder, loc, mulI64(builder, loc, i, B), bi), N), n);
        Value term = arith::MulFOp::create(builder, loc,
            sm120LoadF32(builder, loc, in[4], cIdx),
            sm120LoadF32(builder, loc, in[2], bIdx));
        scf::YieldOp::create(builder, loc, ValueRange{arith::AddFOp::create(
            builder, loc, gramLoop.getRegionIterArgs()[0], term)});
      }
      builder.setInsertionPointAfter(gramLoop);
      Value exponent = arith::SubFOp::create(builder, loc, decayLoop.getResult(0), prefix);
      Value term = arith::MulFOp::create(builder, loc,
          arith::MulFOp::create(builder, loc, sm120ExpF32(builder, loc, exponent), delta),
          arith::MulFOp::create(builder, loc,
              sm120LoadF32(builder, loc, in[1], q), gramLoop.getResult(0)));
      Value output = arith::AddFOp::create(builder, loc,
          replayLoop.getRegionIterArgs()[1], term);
      scf::YieldOp::create(builder, loc, ValueRange{prefix, output});
    }
    builder.setInsertionPointAfter(replayLoop);
    sm120StoreF32(builder, loc, in[6], z, replayLoop.getResult(1));
  }
  builder.setInsertionPointAfter(guarded);
  op->erase();
  return success();
}

static LogicalResult materializeSm120ReplaySSMFlushKernel(
    tessera::tile::ReplaySSMFlushKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  ValueRange in = kernel.getInputs();
  if (in.size() != 9) return failure();
  Location loc = op->getLoc();
  Value B=in[5], D=in[6], N=in[7], M=in[8];
  Value z=sm120LinearThread(builder,loc,128);
  Value total=mulI64(builder,loc,mulI64(builder,loc,B,D),N);
  auto guarded=scf::IfOp::create(builder,loc,lessI64(builder,loc,z,total),false);
  {
    OpBuilder::InsertionGuard guard(builder); builder.setInsertionPointToStart(guarded.thenBlock());
    Value n=arith::RemUIOp::create(builder,loc,z,N);
    Value t=arith::DivUIOp::create(builder,loc,z,N);
    Value di=arith::RemUIOp::create(builder,loc,t,D);
    Value bi=arith::DivUIOp::create(builder,loc,t,D);
    Value a=sm120LoadF32(builder,loc,in[4],di);
    Value zero=i64Constant(builder,loc,0), one=i64Constant(builder,loc,1);
    auto loop=scf::ForOp::create(builder,loc,zero,M,one,
                                 ValueRange{sm120LoadF32(builder,loc,in[3],z)});
    {
      OpBuilder::InsertionGuard loopGuard(builder); builder.setInsertionPointToStart(loop.getBody());
      Value i=loop.getInductionVar();
      Value q=addI64(builder,loc,mulI64(builder,loc,addI64(builder,loc,mulI64(builder,loc,i,B),bi),D),di);
      Value bIdx=addI64(builder,loc,mulI64(builder,loc,addI64(builder,loc,mulI64(builder,loc,i,B),bi),N),n);
      Value decay=sm120ExpF32(builder,loc,arith::MulFOp::create(builder,loc,
          sm120LoadF32(builder,loc,in[0],q),a));
      Value next=arith::AddFOp::create(builder,loc,
          arith::MulFOp::create(builder,loc,decay,loop.getRegionIterArgs()[0]),
          arith::MulFOp::create(builder,loc,
              arith::MulFOp::create(builder,loc,sm120LoadF32(builder,loc,in[0],q),
                                    sm120LoadF32(builder,loc,in[1],q)),
              sm120LoadF32(builder,loc,in[2],bIdx)));
      scf::YieldOp::create(builder,loc,ValueRange{next});
    }
    builder.setInsertionPointAfter(loop); sm120StoreF32(builder,loc,in[3],z,loop.getResult(0));
  }
  builder.setInsertionPointAfter(guarded); op->erase(); return success();
}

static LogicalResult materializeSm120MoEDispatchKernel(
    tessera::tile::MoEDispatchKernelOp kernel, OpBuilder &builder) {
  Operation *op=kernel.getOperation(); ValueRange in=kernel.getInputs(); Location loc=op->getLoc();
  StringRef storage=op->getAttrOfType<StringAttr>("storage").getValue();
  Value T=in[3], S=in[4], H=in[5], z=sm120LinearThread(builder,loc,256);
  auto guarded=scf::IfOp::create(builder,loc,lessI64(builder,loc,z,mulI64(builder,loc,S,H)),false);
  { OpBuilder::InsertionGuard guard(builder); builder.setInsertionPointToStart(guarded.thenBlock());
    Value slot=arith::DivUIOp::create(builder,loc,z,H), h=arith::RemUIOp::create(builder,loc,z,H);
    Value token=arith::ExtUIOp::create(builder,loc,builder.getI64Type(),sm120LoadI32(builder,loc,in[1],slot));
    Value idx=addI64(builder,loc,mulI64(builder,loc,token,H),h);
    sm120StoreStorageF32(builder,loc,in[2],z,
        sm120LoadStorageF32(builder,loc,in[0],idx,storage),storage); }
  builder.setInsertionPointAfter(guarded); (void)T; op->erase(); return success();
}

static LogicalResult materializeSm120MoECombineKernel(
    tessera::tile::MoECombineKernelOp kernel, OpBuilder &builder) {
  Operation *op=kernel.getOperation(); ValueRange in=kernel.getInputs(); Location loc=op->getLoc();
  StringRef storage=op->getAttrOfType<StringAttr>("storage").getValue();
  FloatType f32=builder.getF32Type(); Value T=in[4],S=in[5],H=in[6],z=sm120LinearThread(builder,loc,256);
  auto guarded=scf::IfOp::create(builder,loc,lessI64(builder,loc,z,mulI64(builder,loc,T,H)),false);
  { OpBuilder::InsertionGuard guard(builder); builder.setInsertionPointToStart(guarded.thenBlock());
    Value tokenOut=arith::DivUIOp::create(builder,loc,z,H), h=arith::RemUIOp::create(builder,loc,z,H);
    Value zero=i64Constant(builder,loc,0),one=i64Constant(builder,loc,1);
    Value zf=arith::ConstantFloatOp::create(builder,loc,f32,APFloat(0.0f));
    auto loop=scf::ForOp::create(builder,loc,zero,S,one,ValueRange{zf});
    { OpBuilder::InsertionGuard loopGuard(builder); builder.setInsertionPointToStart(loop.getBody());
      Value slot=loop.getInductionVar();
      Value token=arith::ExtUIOp::create(builder,loc,builder.getI64Type(),sm120LoadI32(builder,loc,in[1],slot));
      Value match=arith::CmpIOp::create(builder,loc,arith::CmpIPredicate::eq,token,tokenOut);
      Value idx=addI64(builder,loc,mulI64(builder,loc,slot,H),h);
      Value term=arith::MulFOp::create(builder,loc,sm120LoadStorageF32(builder,loc,in[0],idx,storage),
                                      sm120LoadF32(builder,loc,in[2],slot));
      Value selected=arith::SelectOp::create(builder,loc,match,term,zf);
      scf::YieldOp::create(builder,loc,ValueRange{arith::AddFOp::create(builder,loc,loop.getRegionIterArgs()[0],selected)}); }
    builder.setInsertionPointAfter(loop); sm120StoreStorageF32(builder,loc,in[3],z,loop.getResult(0),storage); }
  builder.setInsertionPointAfter(guarded); op->erase(); return success();
}

static LogicalResult materializeSm120GroupedGemmKernel(
    tessera::tile::GroupedGemmKernelOp kernel, OpBuilder &builder) {
  Operation *op=kernel.getOperation(); ValueRange in=kernel.getInputs(); Location loc=op->getLoc();
  StringRef storage=op->getAttrOfType<StringAttr>("storage").getValue();
  FloatType f32=builder.getF32Type(); Value T=in[4],K=in[5],N=in[6],E=in[7];
  Value z=sm120LinearThread(builder,loc,256);
  auto guarded=scf::IfOp::create(builder,loc,lessI64(builder,loc,z,mulI64(builder,loc,T,N)),false);
  { OpBuilder::InsertionGuard guard(builder); builder.setInsertionPointToStart(guarded.thenBlock());
    Value row=arith::DivUIOp::create(builder,loc,z,N), col=arith::RemUIOp::create(builder,loc,z,N);
    Value zero=i64Constant(builder,loc,0),one=i64Constant(builder,loc,1);
    auto expertLoop=scf::ForOp::create(builder,loc,zero,E,one,ValueRange{zero});
    { OpBuilder::InsertionGuard expertGuard(builder); builder.setInsertionPointToStart(expertLoop.getBody());
      Value e=expertLoop.getInductionVar();
      Value begin=arith::ExtUIOp::create(builder,loc,builder.getI64Type(),sm120LoadI32(builder,loc,in[2],e));
      Value end=arith::ExtUIOp::create(builder,loc,builder.getI64Type(),sm120LoadI32(builder,loc,in[2],addI64(builder,loc,e,one)));
      Value ge=arith::CmpIOp::create(builder,loc,arith::CmpIPredicate::uge,row,begin);
      Value lt=lessI64(builder,loc,row,end);
      Value match=arith::AndIOp::create(builder,loc,ge,lt);
      scf::YieldOp::create(builder,loc,ValueRange{arith::SelectOp::create(builder,loc,match,e,expertLoop.getRegionIterArgs()[0])}); }
    builder.setInsertionPointAfter(expertLoop);
    Value zf=arith::ConstantFloatOp::create(builder,loc,f32,APFloat(0.0f));
    auto kLoop=scf::ForOp::create(builder,loc,zero,K,one,ValueRange{zf});
    { OpBuilder::InsertionGuard kGuard(builder); builder.setInsertionPointToStart(kLoop.getBody());
      Value k=kLoop.getInductionVar();
      Value xIdx=addI64(builder,loc,mulI64(builder,loc,row,K),k);
      Value wIdx=addI64(builder,loc,mulI64(builder,loc,
          addI64(builder,loc,mulI64(builder,loc,expertLoop.getResult(0),K),k),N),col);
      Value term=arith::MulFOp::create(builder,loc,sm120LoadStorageF32(builder,loc,in[0],xIdx,storage),
                                      sm120LoadStorageF32(builder,loc,in[1],wIdx,storage));
      scf::YieldOp::create(builder,loc,ValueRange{arith::AddFOp::create(builder,loc,kLoop.getRegionIterArgs()[0],term)}); }
    builder.setInsertionPointAfter(kLoop); sm120StoreStorageF32(builder,loc,in[3],z,kLoop.getResult(0),storage); }
  builder.setInsertionPointAfter(guarded); op->erase(); return success();
}

static FailureOr<SmallVector<Value>> materializeSm120Mma16Pack(
    tessera::tile::FragmentPackOp pack, OpBuilder &builder, Value gid,
    Value tig) {
  Operation *op = pack.getOperation();
  auto role = op->getAttrOfType<StringAttr>("role");
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  std::optional<Sm120FragmentDescriptor> physical =
      selectSm120Fragment(desc);
  if (!role || !physical) {
    op->emitError("sm_120 fragment materialization requires a supported "
                  "m16n8k{8,16,32} row/col descriptor");
    return failure();
  }

  auto view = pack.getInputs().front().getDefiningOp<tessera::tile::ViewOp>();
  if (!view) {
    op->emitError("fragment_pack source must be produced by tile.view");
    return failure();
  }
  auto memory = view->getAttrOfType<tessera::tile::TileMemoryLayoutAttr>(
      "tile.memory");
  auto layout = view->getAttrOfType<tessera::tile::TileLayoutAttr>("tile.layout");
  const bool dynamicLeadingDim = memory && memory.getLeadingDim() == 0;
  const bool precomputedLinearBase = view->hasAttr("tile.linear_base");
  const size_t linearBaseOffset = precomputedLinearBase ? 1 : 0;
  const size_t viewInputs = view.getInputs().size();
  const bool validViewArity =
      dynamicLeadingDim
          ? (viewInputs == 4 + linearBaseOffset ||
             viewInputs == 6 + linearBaseOffset)
          : (viewInputs == 3 + linearBaseOffset ||
             viewInputs == 5 + linearBaseOffset);
  if (!memory || !layout || !validViewArity) {
    op->emitError("fragment_pack requires pointer-backed tile.view with "
                  "base, row/column origins, optional bounds, and a dynamic "
                  "leading dimension only when tile.memory leading_dim is zero");
    return failure();
  }

  StringRef expectedOrder = role.getValue() == "a" ? "row_major" : "col_major";
  SmallVector<int64_t, 2> expectedShape = role.getValue() == "a"
      ? SmallVector<int64_t, 2>{16, desc.getK()}
      : SmallVector<int64_t, 2>{desc.getK(), 8};
  // Row-major tensor producers can feed the column-major B register
  // contract without a staging transpose. Require explicit transpose intent;
  // paired f16/bf16 registers gather their two K elements at the physical
  // pitch instead of assuming adjacent addresses.
  const bool rowMajorB = role.getValue() == "b" &&
      memory.getOrder() == "row_major" && pack.getTranspose() &&
      physical->packing == Sm120InputPacking::PairF16;
  if ((role.getValue() != "a" && role.getValue() != "b") ||
      (memory.getOrder() != expectedOrder && !rowMajorB) ||
      (pack.getTranspose() && !rowMajorB) || memory.getSpace() == "lds" ||
      layout.getShardExtents() != ArrayRef<int64_t>(expectedShape) ||
      layout.getSwizzle()) {
    op->emitError("unsupported sm_120 fragment source layout for role ")
        << role.getValue();
    return failure();
  }

  const size_t originOffset = 1 + linearBaseOffset;
  const bool haveBounds = dynamicLeadingDim
      ? viewInputs == 6 + linearBaseOffset
      : viewInputs == 5 + linearBaseOffset;
  Value base = view.getInputs()[0];
  Value rowOrigin = view.getInputs()[originOffset];
  Value colOrigin = view.getInputs()[originOffset + 1];
  auto pointerType = dyn_cast<LLVM::LLVMPointerType>(base.getType());
  if (!pointerType ||
      !rowOrigin.getType().isInteger(64) || !colOrigin.getType().isInteger(64) ||
      (precomputedLinearBase &&
       !view.getInputs()[1].getType().isInteger(64))) {
    op->emitError("pointer-backed tile.view requires !llvm.ptr base and "
                  "i64 row/column origins");
    return failure();
  }
  unsigned addressSpace = pointerType.getAddressSpace();
  bool validAddressSpace = memory.getSpace() == "gmem"
      ? (addressSpace == 0 || addressSpace == 1)
      : (memory.getSpace() == "smem" && addressSpace == 3);
  if (!validAddressSpace) {
    op->emitError("tile.memory space does not match the LLVM pointer address space");
    return failure();
  }

  Location loc = op->getLoc();
  MLIRContext *ctx = builder.getContext();
  StringRef dtype = physical->dtype;
  Type inputTy;
  Type loadTy;
  unsigned alignment;
  int64_t columnsPerRegister;
  switch (physical->packing) {
  case Sm120InputPacking::PairF16:
    inputTy = dtype == "bf16" ? Type(BFloat16Type::get(ctx))
                               : Type(Float16Type::get(ctx));
    loadTy = VectorType::get({2}, inputTy);
    alignment = 2;
    columnsPerRegister = 2;
    break;
  case Sm120InputPacking::ScalarF64:
    inputTy = builder.getF64Type();
    loadTy = inputTy;
    alignment = 8;
    columnsPerRegister = 1;
    break;
  case Sm120InputPacking::ScalarF32:
    inputTy = builder.getF32Type();
    loadTy = inputTy;
    alignment = 4;
    columnsPerRegister = 1;
    break;
  case Sm120InputPacking::PackedX4I8:
    inputTy = builder.getI8Type();
    loadTy = VectorType::get({4}, inputTy);
    alignment = 1;
    columnsPerRegister = 4;
    break;
  case Sm120InputPacking::PackedX8E2M1:
    // Canonical NVFP4 storage is nibble-packed: two logical E2M1 codes per
    // byte.  Each OMMA input register covers eight logical elements, so the
    // physical materializer loads four bytes while Tile IR retains logical
    // [16x64]/[64x8] coordinates.
    inputTy = builder.getI8Type();
    loadTy = builder.getI32Type();
    alignment = 4;
    columnsPerRegister = 8;
    break;
  }
  Value leadingDim = dynamicLeadingDim
      ? view.getInputs().back()
      : i64Constant(builder, loc, memory.getLeadingDim());
  Value linearBase = precomputedLinearBase ? view.getInputs()[1] : Value();
  Value rowBound;
  Value colBound;
  if (haveBounds) {
    rowBound = view.getInputs()[originOffset + 2];
    colBound = view.getInputs()[originOffset + 3];
    if (!rowBound.getType().isInteger(64) ||
        !colBound.getType().isInteger(64)) {
      op->emitError("bounded tile.view requires i64 row and column bounds");
      return failure();
    }
  }
  Value eight = i64Constant(builder, loc, 8);
  Value registerColumn = mulI64(
      builder, loc, tig, i64Constant(builder, loc, columnsPerRegister));
  Value halfK = i64Constant(builder, loc, desc.getK() / 2);

  SmallVector<std::pair<Value, Value>> coords;
  if (physical->packing == Sm120InputPacking::ScalarF64) {
    coords = role.getValue() == "a"
        ? SmallVector<std::pair<Value, Value>>{{gid, tig}}
        : SmallVector<std::pair<Value, Value>>{{tig, gid}};
  } else if (role.getValue() == "a") {
    coords = {{gid, registerColumn},
              {addI64(builder, loc, gid, eight), registerColumn},
              {gid, addI64(builder, loc, registerColumn, halfK)},
              {addI64(builder, loc, gid, eight),
               addI64(builder, loc, registerColumn, halfK)}};
  } else {
    coords = {{registerColumn, gid},
              {addI64(builder, loc, registerColumn, halfK), gid}};
  }

  SmallVector<Value> fragments;
  for (auto [row, col] : coords) {
    Value relativeRow = row;
    Value relativeCol = col;
    row = addI64(builder, loc, rowOrigin, relativeRow);
    col = addI64(builder, loc, colOrigin, relativeCol);
    if (physical->packing == Sm120InputPacking::PackedX8E2M1) {
      Value two = i64Constant(builder, loc, 2);
      if (dynamicLeadingDim || haveBounds || precomputedLinearBase ||
          memory.getLeadingDim() != 32) {
        op->emitError("NVFP4 fragment storage requires a nibble-packed 32-byte leading dimension");
        return failure();
      }
      if (role.getValue() == "a")
        col = arith::DivUIOp::create(builder, loc, col, two);
      else
        row = arith::DivUIOp::create(builder, loc, row, two);
    }
    Value relativeLinear = *tessera::tile::materializeLinearIndex(
        builder, loc, relativeRow, relativeCol, leadingDim,
        memory.getOrder());
    Value linear = precomputedLinearBase
        ? addI64(builder, loc, linearBase, relativeLinear)
        : *tessera::tile::materializeLinearIndex(
              builder, loc, row, col, leadingDim, memory.getOrder());
    Value fragment;
    if (haveBounds && !isa<VectorType>(loadTy)) {
      // Scalar f32/f64 fragments have one logical element per register. Keep
      // the same safe-address-before-load rule as the vector path so a bounded
      // view can never fault even when the selected element is outside the
      // ragged edge.
      Value inBounds = arith::AndIOp::create(
          builder, loc,
          arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ult,
                                row, rowBound),
          arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ult,
                                col, colBound));
      Value safeLinear = arith::SelectOp::create(
          builder, loc, inBounds, linear, i64Constant(builder, loc, 0));
      Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), inputTy,
                                      base, ValueRange{safeLinear});
      Value element = LLVM::LoadOp::create(builder, loc, inputTy, ptr, alignment);
      Value zeroElement = arith::ConstantOp::create(
          builder, loc, inputTy, builder.getZeroAttr(inputTy));
      fragment = arith::SelectOp::create(builder, loc, inBounds, element,
                                         zeroElement);
    } else if (haveBounds || rowMajorB) {
      auto vectorTy = cast<VectorType>(loadTy);
      Value zero = arith::ConstantOp::create(
          builder, loc, vectorTy, builder.getZeroAttr(vectorTy));
      fragment = zero;
      for (int64_t lane = 0; lane < columnsPerRegister; ++lane) {
        Value laneValue = i64Constant(builder, loc, lane);
        Value logicalRow = role.getValue() == "a"
            ? row
            : addI64(builder, loc, row, laneValue);
        Value logicalCol = role.getValue() == "a"
            ? addI64(builder, loc, col, laneValue)
            : col;
        Value inBounds;
        if (haveBounds)
          inBounds = arith::AndIOp::create(
              builder, loc,
              arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ult,
                                     logicalRow, rowBound),
              arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::ult,
                                     logicalCol, colBound));
        Value relativeLogicalRow = role.getValue() == "a"
            ? relativeRow
            : addI64(builder, loc, relativeRow, laneValue);
        Value relativeLogicalCol = role.getValue() == "a"
            ? addI64(builder, loc, relativeCol, laneValue)
            : relativeCol;
        Value relativeElementLinear =
            *tessera::tile::materializeLinearIndex(
                builder, loc, relativeLogicalRow, relativeLogicalCol,
                leadingDim, memory.getOrder());
        Value elementLinear = precomputedLinearBase
            ? addI64(builder, loc, linearBase, relativeElementLinear)
            : *tessera::tile::materializeLinearIndex(
                  builder, loc, logicalRow, logicalCol, leadingDim,
                  memory.getOrder());
        Value safeLinear = haveBounds
            ? Value(arith::SelectOp::create(
                  builder, loc, inBounds, elementLinear,
                  i64Constant(builder, loc, 0)))
            : elementLinear;
        Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), inputTy,
                                        base, ValueRange{safeLinear});
        Value element = LLVM::LoadOp::create(builder, loc, inputTy, ptr, alignment);
        Value zeroElement = arith::ConstantOp::create(
            builder, loc, inputTy, builder.getZeroAttr(inputTy));
        if (haveBounds)
          element = arith::SelectOp::create(builder, loc, inBounds, element,
                                            zeroElement);
        Value laneIndex = arith::ConstantIntOp::create(builder, loc, lane, 64);
        fragment = LLVM::InsertElementOp::create(
            builder, loc, cast<VectorType>(loadTy), fragment, element,
            laneIndex);
      }
    } else {
      Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), inputTy, base,
                                      ValueRange{linear});
      fragment = LLVM::LoadOp::create(builder, loc, loadTy, ptr, alignment);
    }
    if (dtype != "f16" && dtype != "f64")
      fragment = LLVM::BitcastOp::create(
          builder, loc, builder.getI32Type(), fragment);
    fragments.push_back(fragment);
  }
  unsigned expectedRegisters = role.getValue() == "a"
      ? physical->aRegistersPerLane : physical->bRegistersPerLane;
  if (fragments.size() != expectedRegisters) {
    op->emitError("selected sm_120 fragment packing produced an invalid register count");
    return failure();
  }
  return fragments;
}

static FailureOr<Value> materializeSm120NVFP4ScalePack(
    tessera::tile::FragmentPackOp pack, OpBuilder &builder, Value gid,
    Value tig) {
  Operation *op = pack.getOperation();
  auto role = op->getAttrOfType<StringAttr>("role");
  auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto physical = selectSm120Fragment(desc);
  if (!role || !physical ||
      physical->packing != Sm120InputPacking::PackedX8E2M1 ||
      (role.getValue() != "scale_a" && role.getValue() != "scale_b")) {
    op->emitError("NVFP4 scale materialization requires scale_a/scale_b fragments");
    return failure();
  }
  auto view = pack.getInputs().front().getDefiningOp<tessera::tile::ViewOp>();
  auto memory = view ? view->getAttrOfType<tessera::tile::TileMemoryLayoutAttr>(
                           "tile.memory") : nullptr;
  auto layout = view ? view->getAttrOfType<tessera::tile::TileLayoutAttr>(
                           "tile.layout") : nullptr;
  SmallVector<int64_t, 2> expectedShape = role.getValue() == "scale_a"
      ? SmallVector<int64_t, 2>{16, 4}
      : SmallVector<int64_t, 2>{4, 8};
  StringRef expectedOrder = role.getValue() == "scale_a" ? "row_major"
                                                          : "col_major";
  if (!view || !memory || !layout || view.getInputs().size() != 3 ||
      memory.getSpace() != "gmem" || memory.getOrder() != expectedOrder ||
      memory.getLeadingDim() != 4 ||
      layout.getShardExtents() != ArrayRef<int64_t>(expectedShape) ||
      layout.getSwizzle()) {
    op->emitError("NVFP4 scale fragment requires logical 16x4 row-major A or 4x8 col-major B view");
    return failure();
  }
  Value base = view.getInputs()[0];
  Value rowOrigin = view.getInputs()[1];
  Value colOrigin = view.getInputs()[2];
  auto pointerType = dyn_cast<LLVM::LLVMPointerType>(base.getType());
  if (!pointerType ||
      (pointerType.getAddressSpace() != 0 && pointerType.getAddressSpace() != 1) ||
      !rowOrigin.getType().isInteger(64) ||
      !colOrigin.getType().isInteger(64)) {
    op->emitError("NVFP4 scale view requires a global-memory LLVM pointer and "
                  "i64 origins");
    return failure();
  }

  Location loc = op->getLoc();
  Value zero32 = arith::ConstantIntOp::create(builder, loc, 0, 32);
  Value zero64 = i64Constant(builder, loc, 0);
  Value one = i64Constant(builder, loc, 1);
  Value activeTig = arith::CmpIOp::create(
      builder, loc, arith::CmpIPredicate::eq, tig, zero64);
  Value scaleRow = gid;
  if (role.getValue() == "scale_a") {
    Value isUpper = arith::CmpIOp::create(
        builder, loc, arith::CmpIPredicate::eq, tig, one);
    activeTig = arith::OrIOp::create(builder, loc, activeTig, isUpper);
    scaleRow = arith::SelectOp::create(
        builder, loc, isUpper, addI64(builder, loc, gid,
                                     i64Constant(builder, loc, 8)), gid);
  }
  Value row = role.getValue() == "scale_a"
      ? addI64(builder, loc, rowOrigin, scaleRow)
      : rowOrigin;
  Value col = role.getValue() == "scale_a"
      ? colOrigin
      : addI64(builder, loc, colOrigin, gid);
  Value leadingDim = i64Constant(builder, loc, memory.getLeadingDim());
  Value linear = memory.getOrder() == "row_major"
      ? addI64(builder, loc, mulI64(builder, loc, row, leadingDim), col)
      : addI64(builder, loc, mulI64(builder, loc, col, leadingDim), row);
  Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(),
                                  builder.getI8Type(), base,
                                  ValueRange{linear});
  Value loaded = LLVM::LoadOp::create(builder, loc, builder.getI32Type(), ptr,
                                      /*alignment=*/1);
  return arith::SelectOp::create(builder, loc, activeTig, loaded, zero32)
      .getResult();
}

static LogicalResult materializeSm120AccumulatorStore(
    Value accumulator, tessera::tile::FragmentUnpackOp unpack,
    tessera::tile::StoreOp store, OpBuilder &builder, Value gid,
    Value twoTig) {
  Operation *op = store.getOperation();
  auto desc = unpack->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
  auto unpackLayout =
      unpack->getAttrOfType<tessera::tile::TileLayoutAttr>("tile.layout");
  auto storeLayout =
      store->getAttrOfType<tessera::tile::TileLayoutAttr>("tile.layout");
  auto memory =
      store->getAttrOfType<tessera::tile::TileMemoryLayoutAttr>("tile.memory");
  std::array<int64_t, 2> outputShape{16, 8};
  bool isF32 = desc && desc.getAccType() == "f32";
  bool isS32 = desc && (desc.getAccType() == "s32" ||
                        desc.getAccType() == "int32");
  auto epilogue = store->getAttrOfType<tessera::tile::TileEpilogueAttr>("tile.epilogue");
  auto residualAttr = store->getAttrOfType<BoolAttr>("tile.residual");
  const bool hasResidual = residualAttr && residualAttr.getValue();
  const bool hasBias = epilogue && epilogue.getBias();
  const size_t extra = size_t(hasBias) + size_t(hasResidual);
  if (store.getInputs().size() < extra) return failure();
  const size_t addressInputs = store.getInputs().size() - extra;
  if (epilogue && (!isF32 ||
       (epilogue.getOutputType() != "f32" && epilogue.getOutputType() != "f16") ||
       !tessera::tile::isSupportedActivation(epilogue.getActivation()))) {
    op->emitError("sm_120 fragment epilogue requires f32 accumulation, "
                  "none/relu/gelu/silu activation and f32/f16 output");
    return failure();
  }
  const bool dynamicLeadingDim = memory && memory.getLeadingDim() == 0;
  const bool boundedDynamic = dynamicLeadingDim && addressInputs == 7;
  const bool boundedStatic = !dynamicLeadingDim && addressInputs == 6;
  const bool bounded = boundedDynamic || boundedStatic;
  if (!isCanonicalSm120Mma16(desc) || (!isF32 && !isS32) ||
      !unpackLayout || !storeLayout || !memory ||
      unpackLayout.getShardExtents() != ArrayRef<int64_t>(outputShape) ||
      storeLayout.getShardExtents() != ArrayRef<int64_t>(outputShape) ||
      unpackLayout.getSwizzle() ||
      storeLayout.getSwizzle() || memory.getSpace() != "gmem" ||
      memory.getOrder() != "row_major" ||
      (!bounded && (dynamicLeadingDim || addressInputs != 4))) {
    op->emitError("sm_120 accumulator store requires unswizzled 16x8 row-major "
                  "gmem output and f32 or s32 accumulator");
    return failure();
  }

  Value base = store.getInputs()[1];
  Value rowOrigin = store.getInputs()[2];
  Value colOrigin = store.getInputs()[3];
  auto pointerType = dyn_cast<LLVM::LLVMPointerType>(base.getType());
  if (!pointerType ||
      (pointerType.getAddressSpace() != 0 && pointerType.getAddressSpace() != 1) ||
      !rowOrigin.getType().isInteger(64) || !colOrigin.getType().isInteger(64)) {
    op->emitError("sm_120 accumulator store requires gmem !llvm.ptr and i64 origins");
    return failure();
  }

  Location loc = op->getLoc();
  Type accumulatorTy = isF32 ? Type(builder.getF32Type())
                             : Type(builder.getI32Type());
  Value one = i64Constant(builder, loc, 1);
  Value eight = i64Constant(builder, loc, 8);
  SmallVector<std::pair<Value, Value>> coords = {
      {gid, twoTig},
      {gid, addI64(builder, loc, twoTig, one)},
      {addI64(builder, loc, gid, eight), twoTig},
      {addI64(builder, loc, gid, eight),
       addI64(builder, loc, twoTig, one)}};
  Value leadingDim = dynamicLeadingDim
      ? store.getInputs()[6]
      : i64Constant(builder, loc, memory.getLeadingDim());
  Value rowBound = bounded ? store.getInputs()[4] : Value();
  Value colBound = bounded ? store.getInputs()[5] : Value();
  Value biasBase = hasBias ? store.getInputs()[addressInputs] : Value();
  Value residualBase = hasResidual ? store.getInputs().back() : Value();
  for (Value pointer : {biasBase, residualBase}) {
    if (pointer && !isa<LLVM::LLVMPointerType>(pointer.getType())) {
      op->emitError("sm_120 fragment epilogue buffers require !llvm.ptr");
      return failure();
    }
  }
  Type outputTy = epilogue && epilogue.getOutputType() == "f16"
      ? Type(builder.getF16Type()) : accumulatorTy;
  for (auto [index, coord] : llvm::enumerate(coords)) {
    Value row = addI64(builder, loc, rowOrigin, coord.first);
    Value col = addI64(builder, loc, colOrigin, coord.second);
    Value linear = *tessera::tile::materializeLinearIndex(
        builder, loc, row, col, leadingDim, "row_major");
    Value ptr = LLVM::GEPOp::create(builder, loc, base.getType(), outputTy, base,
                                    ValueRange{linear});
    Value scalar = LLVM::ExtractValueOp::create(
        builder, loc, accumulatorTy, accumulator,
        ArrayRef<int64_t>{static_cast<int64_t>(index)});
    auto emitStore = [&]() {
      // Loads belong inside the same logical M/N guard as the output store.
      // Padding lanes must not read bias/residual buffers past their extent.
      Value value = scalar;
      if (hasBias) {
        Value pointer = LLVM::GEPOp::create(builder, loc, biasBase.getType(),
            builder.getF32Type(), biasBase, ValueRange{col});
        value = arith::AddFOp::create(builder, loc, value,
            LLVM::LoadOp::create(builder, loc, builder.getF32Type(), pointer, 4));
      }
      if (epilogue)
        value = tessera::tile::emitScalarFloatActivation(
            builder, loc, value, epilogue.getActivation());
      if (hasResidual) {
        Value pointer = LLVM::GEPOp::create(builder, loc, residualBase.getType(),
            builder.getF32Type(), residualBase, ValueRange{linear});
        value = arith::AddFOp::create(builder, loc, value,
            LLVM::LoadOp::create(builder, loc, builder.getF32Type(), pointer, 4));
      }
      if (outputTy.isF16())
        value = arith::TruncFOp::create(builder, loc, outputTy, value);
      LLVM::StoreOp::create(builder, loc, value, ptr,
                           /*alignment=*/outputTy.isF16() ? 2 : 4);
    };
    if (bounded) {
      Value valid = arith::AndIOp::create(
          builder, loc, lessI64(builder, loc, row, rowBound),
          lessI64(builder, loc, col, colBound));
      auto guarded = scf::IfOp::create(builder, loc, valid, false);
      OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(guarded.thenBlock());
      emitStore();
    } else {
      emitStore();
    }
  }
  return success();
}

// W1.1 step 2b -- physical representation of one typed Tile fragment on
// consumer Blackwell. A fragment remains one SSA value by using an LLVM
// literal struct around its per-lane registers. That 1:1 representation lets
// MLIR's structural SCF conversion change a loop iter_arg without a custom
// loop rewrite, so the non-zero accumulator survives every K panel.
static std::optional<Type>
sm120PhysicalFragmentType(tessera::tile::FragmentType fragment) {
  if (!fragment || fragment.isUnknown() || fragment.getM() != 16 ||
      fragment.getN() != 8)
    return std::nullopt;
  MLIRContext *ctx = fragment.getContext();
  StringRef role = fragment.getRole();
  StringRef elem = fragment.getElem();
  StringRef acc = fragment.getAcc();
  if (role == "scale_a" || role == "scale_b")
    return IntegerType::get(ctx, 32);

  Type fieldType;
  unsigned fields = 0;
  if (role == "acc") {
    if (acc == "f32" && elem == "f32") {
      fieldType = Float32Type::get(ctx);
      fields = 4;
    } else if (acc == "f16" && elem == "f16") {
      fieldType = VectorType::get({2}, Float16Type::get(ctx));
      fields = 2;
    } else if ((acc == "s32" || acc == "int32") &&
               (elem == "s32" || elem == "int32")) {
      fieldType = IntegerType::get(ctx, 32);
      fields = 4;
    }
  } else if (role == "a" || role == "b") {
    fields = role == "a" ? 4 : 2;
    if (elem == "f16" && fragment.getK() == 16)
      fieldType = VectorType::get({2}, Float16Type::get(ctx));
    else if ((elem == "bf16" && fragment.getK() == 16) ||
             (elem == "tf32" && fragment.getK() == 8) ||
             ((elem == "e4m3" || elem == "e5m2" || elem == "s8" ||
               elem == "int8") && fragment.getK() == 32) ||
             (elem == "nvfp4" && fragment.getK() == 64))
      fieldType = IntegerType::get(ctx, 32);
  }
  if (!fieldType || fields == 0)
    return std::nullopt;
  SmallVector<Type> body(fields, fieldType);
  return LLVM::LLVMStructType::getLiteral(ctx, body);
}

static Value packSm120FragmentRegisters(ConversionPatternRewriter &rewriter,
                                        Location loc, Type resultType,
                                        ValueRange registers) {
  auto structType = cast<LLVM::LLVMStructType>(resultType);
  Value packed = LLVM::UndefOp::create(rewriter, loc, structType);
  for (auto [index, value] : llvm::enumerate(registers))
    packed = LLVM::InsertValueOp::create(
        rewriter, loc, structType, packed, value,
        ArrayRef<int64_t>{static_cast<int64_t>(index)});
  return packed;
}

static SmallVector<Value>
unpackSm120FragmentRegisters(ConversionPatternRewriter &rewriter, Location loc,
                             Value fragment) {
  auto structType = cast<LLVM::LLVMStructType>(fragment.getType());
  SmallVector<Value> registers;
  for (auto [index, type] : llvm::enumerate(structType.getBody()))
    registers.push_back(LLVM::ExtractValueOp::create(
        rewriter, loc, type, fragment,
        ArrayRef<int64_t>{static_cast<int64_t>(index)}));
  return registers;
}

struct ConvertSm120FragmentPack
    : public OpConversionPattern<tessera::tile::FragmentPackOp> {
  using OpConversionPattern::OpConversionPattern;

  LogicalResult matchAndRewrite(
      tessera::tile::FragmentPackOp op, OpAdaptor,
      ConversionPatternRewriter &rewriter) const override {
    auto fragment = dyn_cast<tessera::tile::FragmentType>(op.getResult().getType());
    Type converted = getTypeConverter()->convertType(fragment);
    if (!converted)
      return rewriter.notifyMatchFailure(op, "unsupported SM120 fragment type");
    StringRef role = fragment.getRole();
    if (role == "scale_a" || role == "scale_b")
      return rewriter.notifyMatchFailure(
          op, "block-scaled fragment conversion is handled by the existing straight-line path");
    Location loc = op.getLoc();
    Value tid = NVVM::ThreadIdXOp::create(rewriter, loc, rewriter.getI32Type());
    Value lane = arith::AndIOp::create(
        rewriter, loc, tid,
        arith::ConstantIntOp::create(rewriter, loc, 31, 32));
    Value gid32 = arith::ShRUIOp::create(
        rewriter, loc, lane,
        arith::ConstantIntOp::create(rewriter, loc, 2, 32));
    Value tig32 = arith::AndIOp::create(
        rewriter, loc, lane,
        arith::ConstantIntOp::create(rewriter, loc, 3, 32));
    Value gid = arith::ExtUIOp::create(rewriter, loc, rewriter.getI64Type(), gid32);
    Value tig = arith::ExtUIOp::create(rewriter, loc, rewriter.getI64Type(), tig32);
    FailureOr<SmallVector<Value>> registers =
        materializeSm120Mma16Pack(op, rewriter, gid, tig);
    if (failed(registers))
      return failure();
    rewriter.replaceOp(
        op, packSm120FragmentRegisters(rewriter, loc, converted, *registers));
    return success();
  }
};

struct ConvertSm120FragmentZero
    : public OpConversionPattern<tessera::tile::FragmentZeroOp> {
  using OpConversionPattern::OpConversionPattern;

  LogicalResult matchAndRewrite(
      tessera::tile::FragmentZeroOp op, OpAdaptor,
      ConversionPatternRewriter &rewriter) const override {
    Type converted = getTypeConverter()->convertType(op.getResult().getType());
    auto structType = dyn_cast_or_null<LLVM::LLVMStructType>(converted);
    if (!structType)
      return rewriter.notifyMatchFailure(op, "unsupported SM120 accumulator type");
    SmallVector<Value> zeros;
    for (Type type : structType.getBody())
      zeros.push_back(arith::ConstantOp::create(
          rewriter, op.getLoc(), type, rewriter.getZeroAttr(type)));
    rewriter.replaceOp(
        op, packSm120FragmentRegisters(rewriter, op.getLoc(), structType, zeros));
    return success();
  }
};

struct ConvertSm120TypedMMA
    : public OpConversionPattern<tessera::tile::MMAOp> {
  using OpConversionPattern::OpConversionPattern;

  LogicalResult matchAndRewrite(
      tessera::tile::MMAOp op, OpAdaptor adaptor,
      ConversionPatternRewriter &rewriter) const override {
    SmallVector<Value> data;
    for (auto [original, converted] :
         llvm::zip(op->getOperands(), adaptor.getOperands()))
      if (!isa<tessera::tile::AsyncTokenType>(original.getType()))
        data.push_back(converted);
    if (data.size() != 3 || op->getNumResults() != 1)
      return rewriter.notifyMatchFailure(
          op, "typed SM120 MMA requires A, B, accumulator -> one fragment");
    auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
    auto physical = selectSm120Fragment(desc);
    if (!physical || physical->packing == Sm120InputPacking::PackedX8E2M1)
      return rewriter.notifyMatchFailure(
          op, "typed loop conversion requires a non-block-scaled SM120 MMA");
    auto a = unpackSm120FragmentRegisters(rewriter, op.getLoc(), data[0]);
    auto b = unpackSm120FragmentRegisters(rewriter, op.getLoc(), data[1]);
    auto c = unpackSm120FragmentRegisters(rewriter, op.getLoc(), data[2]);
    SmallVector<Value> operands(a);
    operands.append(b);
    operands.append(c);
    Type resultType =
        getTypeConverter()->convertType(op->getResult(0).getType());
    SmallVector<NamedAttribute> attrs = {
        rewriter.getNamedAttr("arch", rewriter.getStringAttr("sm_120")),
        rewriter.getNamedAttr(
            "shape", rewriter.getStringAttr(
                         ("m16n8k" + Twine(desc.getK())).str())),
        rewriter.getNamedAttr("dtype_ab",
                              rewriter.getStringAttr(desc.getAType())),
        rewriter.getNamedAttr("dtype_c",
                              rewriter.getStringAttr(desc.getAccType())),
        rewriter.getNamedAttr(
            "instruction_family",
            rewriter.getStringAttr(physical->instructionFamily)),
        rewriter.getNamedAttr(
            "a_registers_per_lane",
            rewriter.getI32IntegerAttr(physical->aRegistersPerLane)),
        rewriter.getNamedAttr(
            "b_registers_per_lane",
            rewriter.getI32IntegerAttr(physical->bRegistersPerLane)),
        rewriter.getNamedAttr(
            "accumulator_registers_per_lane",
            rewriter.getI32IntegerAttr(physical->accumulatorRegistersPerLane)),
        rewriter.getNamedAttr("block_scaled", rewriter.getBoolAttr(false))};
    Operation *target = createContractOp(
        rewriter, op.getLoc(), "tessera_nvidia.mma_sync", operands,
        TypeRange{resultType}, attrs);
    rewriter.replaceOp(op, target->getResults());
    return success();
  }
};

struct ConvertSm120FragmentUnpack
    : public OpConversionPattern<tessera::tile::FragmentUnpackOp> {
  using OpConversionPattern::OpConversionPattern;

  LogicalResult matchAndRewrite(
      tessera::tile::FragmentUnpackOp op, OpAdaptor adaptor,
      ConversionPatternRewriter &rewriter) const override {
    if (!op.getResult().hasOneUse())
      return rewriter.notifyMatchFailure(op, "fragment unpack must feed one store");
    auto store = dyn_cast<tessera::tile::StoreOp>(*op.getResult().getUsers().begin());
    if (!store)
      return rewriter.notifyMatchFailure(op, "fragment unpack must feed tile.store");
    Location loc = op.getLoc();
    Value tid = NVVM::ThreadIdXOp::create(rewriter, loc, rewriter.getI32Type());
    Value lane = arith::AndIOp::create(
        rewriter, loc, tid,
        arith::ConstantIntOp::create(rewriter, loc, 31, 32));
    Value gid32 = arith::ShRUIOp::create(
        rewriter, loc, lane,
        arith::ConstantIntOp::create(rewriter, loc, 2, 32));
    Value tig32 = arith::AndIOp::create(
        rewriter, loc, lane,
        arith::ConstantIntOp::create(rewriter, loc, 3, 32));
    Value twoTig32 = arith::MulIOp::create(
        rewriter, loc, tig32,
        arith::ConstantIntOp::create(rewriter, loc, 2, 32));
    Value gid = arith::ExtUIOp::create(rewriter, loc, rewriter.getI64Type(), gid32);
    Value twoTig = arith::ExtUIOp::create(
        rewriter, loc, rewriter.getI64Type(), twoTig32);
    if (failed(materializeSm120AccumulatorStore(
            adaptor.getInputs().front(), op, store, rewriter, gid, twoTig)))
      return failure();
    rewriter.eraseOp(store);
    rewriter.eraseOp(op);
    return success();
  }
};

static LogicalResult lowerTypedSm120Fragments(ModuleOp module) {
  MLIRContext *ctx = module.getContext();
  TypeConverter converter;
  converter.addConversion([](Type type) { return type; });
  converter.addConversion(
      [](tessera::tile::FragmentType fragment) -> std::optional<Type> {
        return sm120PhysicalFragmentType(fragment);
      });

  ConversionTarget target(*ctx);
  target.markUnknownOpDynamicallyLegal([](Operation *) { return true; });
  // Logical NVFP4 scale fragments are consumed by the existing block-scaled
  // straight-line materializer below; they are not register-valued MMA
  // fragments and therefore must remain legal in this structural conversion.
  target.addIllegalOp<tessera::tile::FragmentZeroOp,
                      tessera::tile::FragmentUnpackOp>();
  target.addDynamicallyLegalOp<tessera::tile::FragmentZeroOp>(
      [](tessera::tile::FragmentZeroOp op) {
        auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
        auto physical = desc ? selectSm120Fragment(desc)
                              : std::optional<Sm120FragmentDescriptor>();
        return physical &&
               physical->packing == Sm120InputPacking::PackedX8E2M1;
      });
  target.addDynamicallyLegalOp<tessera::tile::FragmentUnpackOp>(
      [](tessera::tile::FragmentUnpackOp op) {
        if (op->getNumOperands() != 1)
          return false;
        auto mma = op->getOperand(0).getDefiningOp<tessera::tile::MMAOp>();
        if (!mma)
          return false;
        auto desc = mma->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
        auto physical = desc ? selectSm120Fragment(desc)
                              : std::optional<Sm120FragmentDescriptor>();
        return physical &&
               physical->packing == Sm120InputPacking::PackedX8E2M1;
      });
  target.addDynamicallyLegalOp<tessera::tile::FragmentPackOp>(
      [](tessera::tile::FragmentPackOp op) {
        auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
        auto physical = desc ? selectSm120Fragment(desc)
                              : std::optional<Sm120FragmentDescriptor>();
        return physical &&
               physical->packing == Sm120InputPacking::PackedX8E2M1;
      });
  // Typed fragment MMA must be rewritten by ConvertSm120TypedMMA after the
  // surrounding SCF regions have undergone structural type conversion.  The
  // old predicate used only TypeConverter::isLegal(op), which treats a
  // convertible FragmentType as legal and therefore let the operation survive
  // with a fragment-typed loop block argument.  That made the straight-line
  // fallback appear healthy while loop-carried accumulators failed closed (or,
  // worse, were eligible for a zero-C fallback).  Keep untyped compatibility
  // MMA legal, but force every operation carrying a fragment operand/result
  // through the typed producer pattern.
  target.addDynamicallyLegalOp<tessera::tile::MMAOp>(
      [&](tessera::tile::MMAOp op) {
        auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
        if (desc) {
          auto physical = selectSm120Fragment(desc);
          if (physical &&
              physical->packing == Sm120InputPacking::PackedX8E2M1)
            return true; // handled by the block-scaled path below
        }
        bool typed = op.getNumResults() == 1 &&
                     isa<tessera::tile::FragmentType>(op.getResult(0).getType());
        for (Value operand : op->getOperands())
          typed |= isa<tessera::tile::FragmentType>(operand.getType());
        return !typed;
      });

  RewritePatternSet patterns(ctx);
  patterns.add<ConvertSm120FragmentPack, ConvertSm120FragmentZero,
               ConvertSm120TypedMMA, ConvertSm120FragmentUnpack>(converter,
                                                                 ctx);
  scf::populateSCFStructuralTypeConversionsAndLegality(converter, patterns,
                                                       target);
  if (failed(applyPartialConversion(module, target, std::move(patterns))))
    return failure();

  SmallVector<tessera::tile::ViewOp> deadViews;
  module.walk([&](tessera::tile::ViewOp view) {
    if (view.getResult().use_empty())
      deadViews.push_back(view);
  });
  for (auto view : deadViews)
    view.erase();
  return success();
}

static LogicalResult materializeSm120CudaIntrinsicKernel(
    tessera::nvidia::CudaMathKernelOp kernel, OpBuilder &builder) {
  Operation *op = kernel.getOperation();
  auto kindAttr = op->getAttrOfType<StringAttr>("kind");
  if (!kindAttr || kernel.getInputs().size() != 5) {
    op->emitError("SM120 CUDA intrinsic kernel requires a verified typed ABI");
    return failure();
  }
  StringRef kind = kindAttr.getValue();
  ValueRange inputs = kernel.getInputs();
  Value aBase = inputs[0], bBase = inputs[1], cBase = inputs[2];
  Value outBase = inputs[3], n = inputs[4];
  Location loc = op->getLoc();
  Type i32 = builder.getI32Type();
  Type f32 = builder.getF32Type();
  Value tid = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::ThreadIdXOp::create(builder, loc, i32));
  Value block = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::BlockIdXOp::create(builder, loc, i32));
  Value index = addI64(
      builder, loc,
      mulI64(builder, loc, block, i64Constant(builder, loc, 128)), tid);
  auto guarded = scf::IfOp::create(
      builder, loc, lessI64(builder, loc, index, n), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(&guarded.getThenRegion().front());
    auto loadI32 = [&](Value base) {
      return Value(LLVM::LoadOp::create(
          builder, loc, i32,
          LLVM::GEPOp::create(builder, loc, base.getType(), i32, base,
                              ValueRange{index}),
          4));
    };
    Value a;
    bool cast = kind.starts_with("cvt_f32_i32_");
    bool bitcastF32I32 = kind == "bitcast_f32_i32";
    bool bitcastI32F32 = kind == "bitcast_i32_f32";
    if (cast || bitcastF32I32)
      a = LLVM::LoadOp::create(
          builder, loc, f32,
          LLVM::GEPOp::create(builder, loc, aBase.getType(), f32, aBase,
                              ValueRange{index}),
          4);
    else
      a = loadI32(aBase);
    Value b = loadI32(bBase);
    Value c = loadI32(cBase);
    Value result;
    std::string assembly;
    SmallVector<Value> asmInputs;
    auto packedByteLane = [&](Value packed, unsigned lane, bool signedLane) {
      Value shift = arith::ConstantIntOp::create(builder, loc, lane * 8, 32);
      Value byte = arith::AndIOp::create(
          builder, loc,
          arith::ShRUIOp::create(builder, loc, packed, shift),
          arith::ConstantIntOp::create(builder, loc, 0xff, 32));
      if (!signedLane)
        return byte;
      Value left = arith::ShLIOp::create(
          builder, loc, byte,
          arith::ConstantIntOp::create(builder, loc, 24, 32));
      return Value(arith::ShRSIOp::create(
          builder, loc, left,
          arith::ConstantIntOp::create(builder, loc, 24, 32)));
    };
    auto clampSignedByte = [&](Value value) {
      Value lo = arith::ConstantIntOp::create(builder, loc, -128, 32);
      Value hi = arith::ConstantIntOp::create(builder, loc, 127, 32);
      Value below = arith::CmpIOp::create(
          builder, loc, arith::CmpIPredicate::slt, value, lo);
      value = arith::SelectOp::create(builder, loc, below, lo, value);
      Value above = arith::CmpIOp::create(
          builder, loc, arith::CmpIPredicate::sgt, value, hi);
      return Value(arith::SelectOp::create(builder, loc, above, hi, value));
    };
    auto lowerPackedFourByte = [&]() -> Value {
      bool signedLane = kind.contains("_s8x4");
      bool compare = kind.starts_with("vcmpeq4_");
      bool predicateBits = kind.ends_with("_pred");
      Value packed = arith::ConstantIntOp::create(builder, loc, 0, 32);
      for (unsigned lane = 0; lane < 4; ++lane) {
        Value lhs = packedByteLane(a, lane, signedLane);
        Value rhs = packedByteLane(b, lane, signedLane);
        Value laneValue;
        if (compare) {
          Value equal = arith::CmpIOp::create(
              builder, loc, arith::CmpIPredicate::eq, lhs, rhs);
          int64_t trueValue = predicateBits ? 1 : 0xff;
          laneValue = arith::SelectOp::create(
              builder, loc, equal,
              arith::ConstantIntOp::create(builder, loc, trueValue, 32),
              arith::ConstantIntOp::create(builder, loc, 0, 32));
        } else if (kind == "vabsdiff4_u8x4") {
          Value lhsGreater = arith::CmpIOp::create(
              builder, loc, arith::CmpIPredicate::ugt, lhs, rhs);
          laneValue = arith::SelectOp::create(
              builder, loc, lhsGreater,
              arith::SubIOp::create(builder, loc, lhs, rhs),
              arith::SubIOp::create(builder, loc, rhs, lhs));
        } else {
          bool subtract = kind.starts_with("vsub");
          laneValue = subtract
              ? Value(arith::SubIOp::create(builder, loc, lhs, rhs))
              : Value(arith::AddIOp::create(builder, loc, lhs, rhs));
          if (kind.contains("ss4"))
            laneValue = clampSignedByte(laneValue);
        }
        laneValue = arith::AndIOp::create(
            builder, loc, laneValue,
            arith::ConstantIntOp::create(builder, loc, 0xff, 32));
        unsigned shiftAmount = predicateBits ? lane : lane * 8;
        Value shifted = arith::ShLIOp::create(
            builder, loc, laneValue,
            arith::ConstantIntOp::create(builder, loc, shiftAmount, 32));
        packed = arith::OrIOp::create(builder, loc, packed, shifted);
      }
      return packed;
    };
    if (bitcastF32I32) {
      result = LLVM::BitcastOp::create(builder, loc, i32, a);
    } else if (bitcastI32F32) {
      result = LLVM::BitcastOp::create(builder, loc, f32, a);
    } else if (kind.starts_with("vadd4_") ||
               kind.starts_with("vaddss4_") ||
               kind.starts_with("vsub4_") ||
               kind.starts_with("vsubss4_") ||
               kind == "vabsdiff4_u8x4" ||
               kind.starts_with("vcmpeq4_")) {
      result = lowerPackedFourByte();
    } else {
      if (kind == "abs_i32") assembly = "abs.s32 $0, $1;";
      else if (kind == "min_i32") assembly = "min.s32 $0, $1, $2;";
      else if (kind == "max_i32") assembly = "max.s32 $0, $1, $2;";
      else if (kind == "brev_u32") assembly = "brev.b32 $0, $1;";
      else if (kind == "byte_perm_u32")
        assembly = "prmt.b32 $0, $1, $2, 0x5410;";
      else if (kind == "clz_u32") assembly = "clz.b32 $0, $1;";
      else if (kind == "ffs_u32")
        assembly =
            "{ .reg .u32 r; .reg .pred p; brev.b32 r, $1; "
            "bfind.u32 r, r; sub.u32 r, 32, r; "
            "setp.eq.u32 p, $1, 0; selp.u32 $0, 0, r, p; }";
      else if (kind == "popc_u32") assembly = "popc.b32 $0, $1;";
      else if (kind == "funnelshift_l_wrap_u32")
        assembly = "shf.l.wrap.b32 $0, $1, $2, $3;";
      else if (kind == "dp2a_lo_s32")
        assembly = "dp2a.lo.s32.s32 $0, $1, $2, $3;";
      else if (kind == "dp4a_s32")
        assembly = "dp4a.s32.s32 $0, $1, $2, $3;";
      else if (kind == "vadd2_u16x2")
        assembly = "add.u16x2 $0, $1, $2;";
      else if (cast) {
        StringRef mode = kind.drop_front(StringRef("cvt_f32_i32_").size());
        StringRef suffix =
            mode == "rn" ? "rni" : mode == "rd" ? "rmi" :
            mode == "ru" ? "rpi" : "rzi";
        assembly = ("cvt." + suffix + ".s32.f32 $0, $1;").str();
      } else {
        op->emitError("unsupported SM120 CUDA intrinsic lowering kind ") << kind;
        return failure();
      }
      asmInputs.push_back(a);
      bool binary = kind == "min_i32" || kind == "max_i32" ||
                    kind == "byte_perm_u32" ||
                    kind == "funnelshift_l_wrap_u32" ||
                    kind == "dp2a_lo_s32" || kind == "dp4a_s32" ||
                    kind == "vadd2_u16x2";
      bool ternary = kind == "funnelshift_l_wrap_u32" ||
                     kind == "dp2a_lo_s32" || kind == "dp4a_s32";
      if (binary) asmInputs.push_back(b);
      if (ternary) asmInputs.push_back(c);
      std::string constraints = "=r";
      for (Value value : asmInputs)
        constraints += value.getType().isF32() ? ",f" : ",r";
      result = LLVM::InlineAsmOp::create(
          builder, loc, i32, ValueRange(asmInputs), assembly, constraints,
          /*has_side_effects=*/false, /*is_align_stack=*/false,
          LLVM::tailcallkind::TailCallKind::None,
          /*asm_dialect=*/nullptr, /*operand_attrs=*/nullptr).getResult(0);
    }
    Type outputType = bitcastI32F32 ? Type(f32) : Type(i32);
    LLVM::StoreOp::create(
        builder, loc, result,
        LLVM::GEPOp::create(builder, loc, outBase.getType(), outputType, outBase,
                            ValueRange{index}),
        4);
  }
  op->erase();
  return success();
}

static Value loadPackedContainerByte(OpBuilder &builder, Location loc,
                                     Value base, Value row, Value col,
                                     ArrayRef<int64_t> strides,
                                     int64_t offset, int64_t alignment) {
  Value linear = addI64(
      builder, loc,
      addI64(builder, loc,
             mulI64(builder, loc, row,
                    i64Constant(builder, loc, strides[0])),
             mulI64(builder, loc, col,
                    i64Constant(builder, loc, strides[1]))),
      i64Constant(builder, loc, offset));
  Type i8 = builder.getI8Type();
  return LLVM::LoadOp::create(
      builder, loc, i8,
      LLVM::GEPOp::create(builder, loc, base.getType(), i8, base,
                          ValueRange{linear}),
      alignment);
}

static Value decodeE2M1(OpBuilder &builder, Location loc, Value code) {
  FloatType f32 = builder.getF32Type();
  Value magnitude = arith::AndIOp::create(
      builder, loc, code, arith::ConstantIntOp::create(builder, loc, 7, 32));
  static constexpr float kMagnitude[8] = {0.0f, 0.5f, 1.0f, 1.5f,
                                          2.0f, 3.0f, 4.0f, 6.0f};
  Value decoded =
      arith::ConstantFloatOp::create(builder, loc, f32,
                                     APFloat(kMagnitude[0]));
  for (int index = 1; index < 8; ++index) {
    Value match = arith::CmpIOp::create(
        builder, loc, arith::CmpIPredicate::eq, magnitude,
        arith::ConstantIntOp::create(builder, loc, index, 32));
    decoded = arith::SelectOp::create(
        builder, loc, match,
        arith::ConstantFloatOp::create(builder, loc, f32,
                                       APFloat(kMagnitude[index])),
        decoded);
  }
  Value negative = arith::CmpIOp::create(
      builder, loc, arith::CmpIPredicate::ne,
      arith::AndIOp::create(
          builder, loc, code,
          arith::ConstantIntOp::create(builder, loc, 8, 32)),
      arith::ConstantIntOp::create(builder, loc, 0, 32));
  Value negated = arith::NegFOp::create(builder, loc, decoded);
  return arith::SelectOp::create(builder, loc, negative, negated, decoded);
}

static Value decodeFP6(OpBuilder &builder, Location loc, Value code,
                       bool e2m3) {
  Type i32 = builder.getI32Type();
  FloatType f32 = builder.getF32Type();
  int exponentBits = e2m3 ? 2 : 3;
  int mantissaBits = e2m3 ? 3 : 2;
  int bias = e2m3 ? 1 : 3;
  int mantissaMask = (1 << mantissaBits) - 1;
  int exponentMask = (1 << exponentBits) - 1;
  Value mantissa = arith::AndIOp::create(
      builder, loc, code,
      arith::ConstantIntOp::create(builder, loc, mantissaMask, 32));
  Value exponent = arith::AndIOp::create(
      builder, loc,
      arith::ShRUIOp::create(
          builder, loc, code,
          arith::ConstantIntOp::create(builder, loc, mantissaBits, 32)),
      arith::ConstantIntOp::create(builder, loc, exponentMask, 32));
  Value mantissaF = arith::UIToFPOp::create(builder, loc, f32, mantissa);
  Value fraction = arith::DivFOp::create(
      builder, loc, mantissaF,
      arith::ConstantFloatOp::create(
          builder, loc, f32,
          APFloat(static_cast<float>(1 << mantissaBits))));
  Value isSubnormal = arith::CmpIOp::create(
      builder, loc, arith::CmpIPredicate::eq, exponent,
      arith::ConstantIntOp::create(builder, loc, 0, 32));
  Value significand = arith::SelectOp::create(
      builder, loc, isSubnormal, fraction,
      arith::AddFOp::create(
          builder, loc,
          arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f)),
          fraction));
  Value normalExponent = arith::SubIOp::create(
      builder, loc, exponent,
      arith::ConstantIntOp::create(builder, loc, bias, 32));
  Value subnormalExponent =
      arith::ConstantIntOp::create(builder, loc, 1 - bias, 32);
  Value unbiased = arith::SelectOp::create(
      builder, loc, isSubnormal, subnormalExponent, normalExponent);
  Value power = math::Exp2Op::create(
      builder, loc,
      arith::SIToFPOp::create(builder, loc, f32, unbiased));
  Value decoded = arith::MulFOp::create(builder, loc, significand, power);
  Value negative = arith::CmpIOp::create(
      builder, loc, arith::CmpIPredicate::ne,
      arith::AndIOp::create(
          builder, loc, code,
          arith::ConstantIntOp::create(builder, loc, 32, 32)),
      arith::ConstantIntOp::create(builder, loc, 0, 32));
  Value negated = arith::NegFOp::create(builder, loc, decoded);
  (void)i32;
  return arith::SelectOp::create(builder, loc, negative, negated, decoded);
}

static Value decodeScale(OpBuilder &builder, Location loc, Value code,
                         StringRef dtype) {
  FloatType f32 = builder.getF32Type();
  Value exponent;
  Value mantissa;
  int bias;
  int mantissaBits;
  if (dtype == "ue8m0") {
    exponent = code;
    mantissa = arith::ConstantIntOp::create(builder, loc, 0, 32);
    bias = 127;
    mantissaBits = 0;
  } else {
    exponent = arith::ShRUIOp::create(
        builder, loc, code,
        arith::ConstantIntOp::create(builder, loc, 3, 32));
    mantissa = arith::AndIOp::create(
        builder, loc, code,
        arith::ConstantIntOp::create(builder, loc, 7, 32));
    bias = 7;
    mantissaBits = 3;
  }
  Value unbiased = arith::SubIOp::create(
      builder, loc, exponent,
      arith::ConstantIntOp::create(builder, loc, bias, 32));
  Value power = math::Exp2Op::create(
      builder, loc,
      arith::SIToFPOp::create(builder, loc, f32, unbiased));
  if (dtype == "ue8m0")
    return power;
  Value fraction = arith::DivFOp::create(
      builder, loc, arith::UIToFPOp::create(builder, loc, f32, mantissa),
      arith::ConstantFloatOp::create(
          builder, loc, f32,
          APFloat(static_cast<float>(1 << mantissaBits))));
  Value isSubnormal = arith::CmpIOp::create(
      builder, loc, arith::CmpIPredicate::eq, exponent,
      arith::ConstantIntOp::create(builder, loc, 0, 32));
  Value normal = arith::MulFOp::create(
      builder, loc,
      arith::AddFOp::create(
          builder, loc,
          arith::ConstantFloatOp::create(builder, loc, f32, APFloat(1.0f)),
          fraction),
      power);
  Value subnormal = arith::MulFOp::create(
      builder, loc, fraction,
      arith::ConstantFloatOp::create(builder, loc, f32,
                                     APFloat(1.0f / 64.0f)));
  return arith::SelectOp::create(builder, loc, isSubnormal, subnormal, normal);
}

static FailureOr<Value> decodePackedLogicalValue(
    tessera::tile::PackedLoadOp load, OpBuilder &builder, Value logicalRow,
    Value logicalCol) {
  Operation *op = load.getOperation();
  auto view = op->getAttrOfType<tessera::tile::TilePackedPhysicalViewAttr>(
      "tile.packed_view");
  auto format = view.getFormat();
  ArrayRef<int64_t> strides = view.getStrides();
  if (strides.size() != 2) {
    op->emitError("SM120 generic packed loads currently require rank-2 "
                  "container strides");
    return failure();
  }
  int64_t factor = format.getElementsPerContainer();
  Value factorValue = i64Constant(builder, op->getLoc(), factor);
  Value containerRow = logicalRow;
  Value containerCol = logicalCol;
  Value lane;
  if (view.getPackingAxis() == 0) {
    containerRow =
        arith::DivUIOp::create(builder, op->getLoc(), logicalRow, factorValue);
    lane = arith::RemUIOp::create(builder, op->getLoc(), logicalRow, factorValue);
  } else if (view.getPackingAxis() == 1) {
    containerCol =
        arith::DivUIOp::create(builder, op->getLoc(), logicalCol, factorValue);
    lane = arith::RemUIOp::create(builder, op->getLoc(), logicalCol, factorValue);
  } else {
    op->emitError("SM120 generic packed loads require packing_axis 0 or 1");
    return failure();
  }
  Value byte = loadPackedContainerByte(
      builder, op->getLoc(), load.getInputs()[0], containerRow, containerCol,
      strides, view.getOffset(), view.getAlignment());
  Value code = arith::ExtUIOp::create(
      builder, op->getLoc(), builder.getI32Type(), byte);
  if (factor > 1) {
    Value shift64 = mulI64(
        builder, op->getLoc(), lane,
        i64Constant(builder, op->getLoc(), format.getLogicalBits()));
    Value shift = arith::TruncIOp::create(
        builder, op->getLoc(), builder.getI32Type(), shift64);
    if (format.getLaneOrder() == "high_to_low")
      shift = arith::SubIOp::create(
          builder, op->getLoc(),
          arith::ConstantIntOp::create(
              builder, op->getLoc(),
              (factor - 1) * format.getLogicalBits(), 32),
          shift);
    code = arith::AndIOp::create(
        builder, op->getLoc(),
        arith::ShRUIOp::create(builder, op->getLoc(), code, shift),
        arith::ConstantIntOp::create(
            builder, op->getLoc(),
            (1 << format.getLogicalBits()) - 1, 32));
  } else if (format.getLogicalBits() < 8) {
    code = arith::AndIOp::create(
        builder, op->getLoc(), code,
        arith::ConstantIntOp::create(
            builder, op->getLoc(),
            (1 << format.getLogicalBits()) - 1, 32));
  }

  Value decoded;
  StringRef logical = format.getLogicalType();
  if (logical == "int4") {
    Value negative = arith::CmpIOp::create(
        builder, op->getLoc(), arith::CmpIPredicate::ne,
        arith::AndIOp::create(
            builder, op->getLoc(), code,
            arith::ConstantIntOp::create(builder, op->getLoc(), 8, 32)),
        arith::ConstantIntOp::create(builder, op->getLoc(), 0, 32));
    Value signedValue = arith::SelectOp::create(
        builder, op->getLoc(), negative,
        arith::SubIOp::create(
            builder, op->getLoc(), code,
            arith::ConstantIntOp::create(builder, op->getLoc(), 16, 32)),
        code);
    decoded = arith::SIToFPOp::create(
        builder, op->getLoc(), builder.getF32Type(), signedValue);
  } else if (logical == "uint4") {
    decoded = arith::UIToFPOp::create(
        builder, op->getLoc(), builder.getF32Type(), code);
  } else if (logical == "fp4_e2m1" || logical == "nvfp4") {
    decoded = decodeE2M1(builder, op->getLoc(), code);
  } else if (logical == "fp6_e2m3" || logical == "fp6_e3m2") {
    decoded = decodeFP6(builder, op->getLoc(), code,
                        logical == "fp6_e2m3");
  } else {
    op->emitError("unsupported SM120 generic packed logical dtype ") << logical;
    return failure();
  }

  auto scale = view.getScale();
  if (scale.getDtype() != "none") {
    Value scaleBase = load.getInputs()[1];
    Value block = i64Constant(builder, op->getLoc(), scale.getBlockSize());
    Value scaleRow = logicalRow;
    Value scaleCol = logicalCol;
    if (scale.getAxis() == 0)
      scaleRow =
          arith::DivUIOp::create(builder, op->getLoc(), logicalRow, block);
    else
      scaleCol =
          arith::DivUIOp::create(builder, op->getLoc(), logicalCol, block);
    Value scaleLinear;
    if (scale.getLayout() == "row_major")
      scaleLinear = addI64(
          builder, op->getLoc(),
          mulI64(builder, op->getLoc(), scaleRow,
                 i64Constant(builder, op->getLoc(), scale.getStride())),
          scaleCol);
    else if (scale.getLayout() == "col_major")
      scaleLinear = addI64(
          builder, op->getLoc(),
          mulI64(builder, op->getLoc(), scaleCol,
                 i64Constant(builder, op->getLoc(), scale.getStride())),
          scaleRow);
    else
      scaleLinear = mulI64(
          builder, op->getLoc(),
          scale.getAxis() == 0 ? scaleRow : scaleCol,
          i64Constant(builder, op->getLoc(), scale.getStride()));
    scaleLinear = addI64(
        builder, op->getLoc(), scaleLinear,
        i64Constant(builder, op->getLoc(), scale.getOffset()));
    Value scaleByte = LLVM::LoadOp::create(
        builder, op->getLoc(), builder.getI8Type(),
        LLVM::GEPOp::create(builder, op->getLoc(), scaleBase.getType(),
                            builder.getI8Type(), scaleBase,
                            ValueRange{scaleLinear}),
        scale.getAlignment());
    Value scaleCode = arith::ExtUIOp::create(
        builder, op->getLoc(), builder.getI32Type(), scaleByte);
    decoded = arith::MulFOp::create(
        builder, op->getLoc(), decoded,
        decodeScale(builder, op->getLoc(), scaleCode, scale.getDtype()));
  }
  return decoded;
}

static LogicalResult materializeSm120PackedDecodeStore(
    tessera::tile::PackedLoadOp load, tessera::tile::StoreOp store,
    OpBuilder &builder) {
  Operation *op = load.getOperation();
  auto view = op->getAttrOfType<tessera::tile::TilePackedPhysicalViewAttr>(
      "tile.packed_view");
  auto outputMemory =
      store->getAttrOfType<tessera::tile::TileMemoryLayoutAttr>("tile.memory");
  bool scaled = view.getScale().getDtype() != "none";
  unsigned prefix = scaled ? 2 : 1;
  ValueRange inputs = load.getInputs();
  Value rowOrigin = inputs[prefix];
  Value colOrigin = inputs[prefix + 1];
  Value rows = inputs[prefix + 2];
  Value cols = inputs[prefix + 3];
  Value outputBase = store.getInputs()[1];
  if (!isa<LLVM::LLVMPointerType>(inputs[0].getType()) ||
      (scaled && !isa<LLVM::LLVMPointerType>(inputs[1].getType())) ||
      !isa<LLVM::LLVMPointerType>(outputBase.getType()) ||
      !outputMemory || outputMemory.getSpace() != "gmem") {
    op->emitError("SM120 generic packed decode requires LLVM global pointers "
                  "and a global-memory f32 tile.store");
    return failure();
  }
  Location loc = op->getLoc();
  Value tid = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::ThreadIdXOp::create(builder, loc, builder.getI32Type()));
  Value block = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::BlockIdXOp::create(builder, loc, builder.getI32Type()));
  Value index = addI64(
      builder, loc,
      mulI64(builder, loc, block, i64Constant(builder, loc, 128)), tid);
  Value count = mulI64(builder, loc, rows, cols);
  auto guarded =
      scf::IfOp::create(builder, loc, lessI64(builder, loc, index, count), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(&guarded.getThenRegion().front());
    Value row = arith::DivUIOp::create(builder, loc, index, cols);
    Value col = arith::RemUIOp::create(builder, loc, index, cols);
    Value logicalRow = addI64(builder, loc, rowOrigin, row);
    Value logicalCol = addI64(builder, loc, colOrigin, col);
    FailureOr<Value> decoded =
        decodePackedLogicalValue(load, builder, logicalRow, logicalCol);
    if (failed(decoded))
      return failure();
    Value outputRow = addI64(builder, loc, store.getInputs()[2], row);
    Value outputCol = addI64(builder, loc, store.getInputs()[3], col);
    Value leading =
        i64Constant(builder, loc, outputMemory.getLeadingDim());
    Value outputLinear = outputMemory.getOrder() == "row_major"
        ? addI64(builder, loc, mulI64(builder, loc, outputRow, leading),
                 outputCol)
        : addI64(builder, loc, mulI64(builder, loc, outputCol, leading),
                 outputRow);
    LLVM::StoreOp::create(
        builder, loc, *decoded,
        LLVM::GEPOp::create(builder, loc, outputBase.getType(),
                            builder.getF32Type(), outputBase,
                            ValueRange{outputLinear}),
        4);
  }
  store.erase();
  load.erase();
  return success();
}

static LogicalResult materializeSm120PackedRoundTrip(
    tessera::tile::PackedLoadOp load, tessera::tile::PackedStoreOp store,
    OpBuilder &builder) {
  Operation *op = load.getOperation();
  auto sourceView =
      op->getAttrOfType<tessera::tile::TilePackedPhysicalViewAttr>(
          "tile.packed_view");
  auto destinationView =
      store->getAttrOfType<tessera::tile::TilePackedPhysicalViewAttr>(
          "tile.packed_view");
  if (sourceView.getScale().getDtype() != "none" ||
      sourceView.getFormat() != destinationView.getFormat() ||
      sourceView.getPackingAxis() != destinationView.getPackingAxis() ||
      sourceView.getStrides().size() != 2 ||
      destinationView.getStrides().size() != 2 ||
      load.getInputs().drop_front(1) != store.getInputs().drop_front(2) ||
      !isa<LLVM::LLVMPointerType>(load.getInputs()[0].getType()) ||
      !isa<LLVM::LLVMPointerType>(store.getInputs()[1].getType())) {
    op->emitError("SM120 packed round-trip requires matching unscaled rank-2 "
                  "views, origins/extents, and LLVM pointers");
    return failure();
  }
  Location loc = op->getLoc();
  Value rowOrigin = load.getInputs()[1];
  Value colOrigin = load.getInputs()[2];
  Value rows = load.getInputs()[3];
  Value cols = load.getInputs()[4];
  int64_t factor = sourceView.getFormat().getElementsPerContainer();
  Value factorValue = i64Constant(builder, loc, factor);
  Value containersPerLine;
  Value lines;
  if (sourceView.getPackingAxis() == 1) {
    Value leadingPartial =
        arith::RemUIOp::create(builder, loc, colOrigin, factorValue);
    containersPerLine = arith::DivUIOp::create(
        builder, loc,
        addI64(builder, loc,
               addI64(builder, loc, leadingPartial, cols),
               i64Constant(builder, loc, factor - 1)),
        factorValue);
    lines = rows;
  } else {
    Value leadingPartial =
        arith::RemUIOp::create(builder, loc, rowOrigin, factorValue);
    containersPerLine = arith::DivUIOp::create(
        builder, loc,
        addI64(builder, loc,
               addI64(builder, loc, leadingPartial, rows),
               i64Constant(builder, loc, factor - 1)),
        factorValue);
    lines = cols;
  }
  Value tid = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::ThreadIdXOp::create(builder, loc, builder.getI32Type()));
  Value block = arith::ExtUIOp::create(
      builder, loc, builder.getI64Type(),
      NVVM::BlockIdXOp::create(builder, loc, builder.getI32Type()));
  Value index = addI64(
      builder, loc,
      mulI64(builder, loc, block, i64Constant(builder, loc, 128)), tid);
  Value count = mulI64(builder, loc, lines, containersPerLine);
  auto guarded =
      scf::IfOp::create(builder, loc, lessI64(builder, loc, index, count), false);
  {
    OpBuilder::InsertionGuard guard(builder);
    builder.setInsertionPointToStart(&guarded.getThenRegion().front());
    Value line = arith::DivUIOp::create(builder, loc, index, containersPerLine);
    Value containerInLine =
        arith::RemUIOp::create(builder, loc, index, containersPerLine);
    Value sourceRow;
    Value sourceCol;
    if (sourceView.getPackingAxis() == 1) {
      sourceRow = addI64(builder, loc, rowOrigin, line);
      sourceCol = addI64(
          builder, loc,
          arith::DivUIOp::create(builder, loc, colOrigin, factorValue),
          containerInLine);
    } else {
      sourceRow = addI64(
          builder, loc,
          arith::DivUIOp::create(builder, loc, rowOrigin, factorValue),
          containerInLine);
      sourceCol = addI64(builder, loc, colOrigin, line);
    }
    Value byte = loadPackedContainerByte(
        builder, loc, load.getInputs()[0], sourceRow, sourceCol,
        sourceView.getStrides(), sourceView.getOffset(),
        sourceView.getAlignment());
    ArrayRef<int64_t> destinationStrides = destinationView.getStrides();
    Value destinationLinear = addI64(
        builder, loc,
        addI64(builder, loc,
               mulI64(builder, loc, sourceRow,
                      i64Constant(builder, loc, destinationStrides[0])),
               mulI64(builder, loc, sourceCol,
                      i64Constant(builder, loc, destinationStrides[1]))),
        i64Constant(builder, loc, destinationView.getOffset()));
    LLVM::StoreOp::create(
        builder, loc, byte,
        LLVM::GEPOp::create(builder, loc, store.getInputs()[1].getType(),
                            builder.getI8Type(), store.getInputs()[1],
                            ValueRange{destinationLinear}),
        destinationView.getAlignment());
  }
  store.erase();
  load.erase();
  return success();
}

struct LowerTileToNVIDIAPass
    : PassWrapper<LowerTileToNVIDIAPass, OperationPass<ModuleOp>> {
  MLIR_DEFINE_EXPLICIT_INTERNAL_INLINE_TYPE_ID(LowerTileToNVIDIAPass)

  LowerTileToNVIDIAPass() = default;
  explicit LowerTileToNVIDIAPass(int sm) { smVersion = sm; }
  LowerTileToNVIDIAPass(const LowerTileToNVIDIAPass &other)
      : PassWrapper(other) {
    smVersion = other.smVersion;
  }

  Option<int> smVersion{*this, "sm",
                        llvm::cl::desc("Target NVIDIA SM version"),
                        llvm::cl::init(kHopperSM)};

  StringRef getArgument() const final { return "lower-tile-to-nvidia"; }

  StringRef getDescription() const final {
    return "Lower Tessera Tile IR to NVIDIA Hopper/Blackwell Target IR contracts";
  }

  void getDependentDialects(DialectRegistry &registry) const final {
    // The tile dialect was loaded from inside runOnOperation (getOrLoadDialect
    // below), which an assertions-ON driver refuses: sm120_macro_cta_matmul
    // aborted on Tajasarus 2026-09-17 with "Loading a dialect (tile) while in
    // a multi-threaded execution context". Declared here instead.
    registry.insert<arith::ArithDialect, bufferization::BufferizationDialect,
                    func::FuncDialect, memref::MemRefDialect, nvgpu::NVGPUDialect,
                    LLVM::LLVMDialect, math::MathDialect, NVVM::NVVMDialect,
                    scf::SCFDialect, tessera::tile::TesseraTileDialect,
                    tessera::nvidia::TesseraNVIDIADialect>();
  }

  // Datacenter-Blackwell tensor memory (sm_100a). The registered Tile ops are
  // exactly `tile.tmem.allocate`, `tile.tmem.load` and `tile.tmem.store`
  // (TileOps.td); each maps to one NVIDIA contract, and the opaque
  // `!tile.tmem` handle becomes the 32-bit tensor-memory address that
  // `tcgen05.alloc` publishes and `tcgen05.ld`/`tcgen05.st` take (`[taddr]`).
  // The handle type itself is not an NVIDIA target value, so the contract ops
  // carry the address instead. Index operands are widened to i64 because
  // `index` is not a target value either.
  //
  // Fail-closed cases (Decision #21): an op under the prefix that is not one
  // of the three; a handle consumed by an op this pass does not lower (today
  // `tile.tcgen05.mma` has no NVIDIA lowering, so its TMEM operand cannot be
  // rewritten onto an address); a load/store whose handle did not come from
  // a lowered allocation; a loaded/stored value that is not a target value.
  LogicalResult lowerTmemOp(Operation *op, OpBuilder &builder,
                            SmallVectorImpl<NamedAttribute> &attrs,
                            llvm::DenseMap<Value, Value> &tmemAddress,
                            SmallVectorImpl<Operation *> &loweredAllocs) {
    namespace tile = tessera::tile;
    Location loc = op->getLoc();
    int sm = smVersion;
    auto isTargetValue = [](Type type) {
      return isa<RankedTensorType, UnrankedTensorType, BaseMemRefType,
                 VectorType, IntegerType, FloatType, LLVM::LLVMPointerType,
                 LLVM::LLVMStructType>(type);
    };
    auto unlowered = [&](Operation *at, const Twine &why) {
      return at->emitError("NVIDIA_TMEM_HANDLE_UNLOWERED: ")
             << why << " (NVIDIA sm_" << sm << ")";
    };
    auto addressFor = [&](Value handle, Operation *user) -> Value {
      Value address = tmemAddress.lookup(handle);
      if (!address)
        (void)unlowered(user, "'" + user->getName().getStringRef() +
                                  "' reads a TMEM handle that no lowered "
                                  "'tile.tmem.allocate' produced");
      return address;
    };
    auto appendIndices = [&](SmallVectorImpl<Value> &operands,
                             ValueRange indices) {
      for (Value index : indices)
        operands.push_back(arith::IndexCastOp::create(
            builder, loc, builder.getI64Type(), index));
    };

    if (auto alloc = dyn_cast<tile::TMEMAllocOp>(op)) {
      for (Operation *user : alloc.getHandle().getUsers())
        if (!isa<tile::TMEMLoadOp, tile::TMEMStoreOp>(user))
          return unlowered(user, "'" + user->getName().getStringRef() +
                                     "' consumes a TMEM handle and has no "
                                     "NVIDIA lowering onto a TMEM address");
      attrs.push_back(builder.getNamedAttr("bytes", alloc.getBytesAttr()));
      attrs.push_back(
          builder.getNamedAttr("alignment", alloc.getAlignmentAttr()));
      // The NVIDIA pipeline runs TileBufferReuse/TileBufferArena first; carry
      // their placement (`tile.buffer_group`, `tile.tmem_offset`) onto the
      // contract rather than dropping it at the boundary (Decision #32).
      for (StringRef planned : {"tile.buffer_group", "tile.tmem_offset"})
        if (Attribute value = op->getAttr(planned))
          attrs.push_back(builder.getNamedAttr(planned, value));
      Operation *target = createContractOp(builder, loc,
                                           "tessera_nvidia.tmem_alloc",
                                           ValueRange{}, builder.getI32Type(),
                                           attrs);
      tmemAddress[alloc.getHandle()] = target->getResult(0);
      loweredAllocs.push_back(op);
      return success();
    }
    if (auto load = dyn_cast<tile::TMEMLoadOp>(op)) {
      Value address = addressFor(load.getHandle(), op);
      if (!address)
        return failure();
      Type valueType = load.getValue().getType();
      if (!isTargetValue(valueType))
        return unlowered(op, "'tile.tmem.load' result type is not an NVIDIA "
                             "target value");
      SmallVector<Value> operands{address};
      appendIndices(operands, load.getIndices());
      Operation *target = createContractOp(
          builder, loc, "tessera_nvidia.tmem_load", operands, valueType, attrs);
      load.getValue().replaceAllUsesWith(target->getResult(0));
      op->erase();
      return success();
    }
    if (auto store = dyn_cast<tile::TMEMStoreOp>(op)) {
      Value address = addressFor(store.getHandle(), op);
      if (!address)
        return failure();
      if (!isTargetValue(store.getValue().getType()))
        return unlowered(op, "'tile.tmem.store' value type is not an NVIDIA "
                             "target value");
      SmallVector<Value> operands{store.getValue(), address};
      appendIndices(operands, store.getIndices());
      createContractOp(builder, loc, "tessera_nvidia.tmem_store", operands,
                       TypeRange{}, attrs);
      op->erase();
      return success();
    }
    return op->emitError("NVIDIA_TMEM_UNKNOWN_OP: '")
           << op->getName() << "' is not a declared Tile TMEM op "
           << "(tile.tmem.allocate / tile.tmem.load / tile.tmem.store); no "
           << "NVIDIA sm_" << sm << " lowering";
  }

  void runOnOperation() final {
    MLIRContext *ctx = &getContext();
    ctx->loadDialect<tessera::nvidia::TesseraNVIDIADialect>();

    ModuleOp module = getOperation();
    OpBuilder moduleBuilder(ctx);
    module->setAttr("tessera.nvidia.arch",
                    moduleBuilder.getStringAttr(archStringForSM(smVersion)));

    SmallVector<tessera::tile::RowRegionKernelOp> rowKernels;
    for (auto kernel : module.getOps<tessera::tile::RowRegionKernelOp>()) rowKernels.push_back(kernel);
    if (!rowKernels.empty()) {
      if (smVersion != 120 || rowKernels.size() != 1 || module.getBody()->getOperations().size() != 1) {
        module.emitError("native row region requires an isolated SM120 Target projection");
        return signalPassFailure();
      }
      auto kernel = rowKernels.front();
      if (failed(tessera::row_region::verifyKernel(kernel))) return signalPassFailure();
      OpBuilder b(kernel);
      OperationState state(kernel.getLoc(),"tessera_nvidia.row_region_kernel");
      state.addAttributes(kernel->getAttrs()); state.addRegion();
      auto *target = b.create(state);
      target->getRegion(0).takeBody(kernel->getRegion(0));
      auto function = cast<LLVM::LLVMFuncOp>(target->getRegion(0).front().front());
      target->setAttr("tile_body_hash",kernel->getAttr("body_hash"));
      if (failed(tessera::tile::lowerScalarBufferAccesses(function))) return signalPassFailure();
      target->setAttr("body_hash",b.getStringAttr(tessera::row_region::digest(function)));
      kernel.erase();
      if (failed(tessera::row_region::verifyKernel(target))) return signalPassFailure();
      return;
    }
    // Preserve a tuple codomain as a product of scalar proof operations.  The
    // scalar materializer below remains the sole place that implements the
    // mixed-radix arithmetic; this expansion only preserves product structure.
    SmallVector<tessera::tile::MaterializeComposedLayoutTupleOp> tupleLayouts;
    module.walk([&](tessera::tile::MaterializeComposedLayoutTupleOp op) {
      tupleLayouts.push_back(op);
    });
    for (auto tuple : tupleLayouts) {
      OpBuilder builder(tuple);
      for (auto [index, attr] : llvm::enumerate(tuple.getLayouts())) {
        OperationState state(tuple.getLoc(),
                             "tile.materialize_composed_layout");
        state.addOperands(tuple.getCoordinates());
        state.addTypes(builder.getI64Type());
        state.addAttribute("layout",
                           cast<tessera::tile::TileComposedLayoutAttr>(attr));
        Operation *component = builder.create(state);
        tuple.getResults()[index].replaceAllUsesWith(component->getResult(0));
      }
      tuple.erase();
    }

    if (smVersion >= kConsumerBlackwellSM &&
        failed(lowerTypedSm120Fragments(module))) {
      signalPassFailure();
      return;
    }

    SmallVector<Operation *> worklist;
    module.walk([&](Operation *op) {
      StringRef name = op->getName().getStringRef();
      if (name == "tile.mma" || name == "tile.async_copy" ||
          name == "tessera_nvidia.block_coordinate" ||
          name == "tessera_nvidia.macro_cta_matmul" ||
          name == "tile.matmul_kernel" || name == "tile.softmax_kernel" ||
          name == "tile.materialize_composed_layout" ||
          name == "tile.activation_kernel" ||
          name == "tile.reduce_kernel" || name == "tile.norm_kernel" ||
          name == "tile.cuda_intrinsic_kernel" ||
          name == "tile.packed_store" ||
          (name == "tile.store" && op->getNumOperands() > 0 &&
           op->getOperand(0).getDefiningOp<
               tessera::tile::PackedLoadOp>()) ||
          name == "tile.attention_kernel" ||
          name == "tile.attention_row_correction_kernel" ||
          name == "tile.attention_backward_rows_kernel" ||
          name == "tile.attention_backward_kernel" ||
          name == "tile.training_kernel" ||
          name == "tile.paged_kv_read_kernel" ||
          name == "tile.paged_attention_kernel" ||
          name == "tile.replay_ssm_decode_kernel" ||
          name == "tile.replay_ssm_flush_kernel" ||
          name == "tile.moe_dispatch_kernel" ||
          name == "tile.moe_combine_kernel" ||
          name == "tile.grouped_gemm_kernel" ||
          name == "tile.wait_async" || name == "tile.conv2d" ||
          name == "tile.kv_cache" || name.starts_with("tile.control_") ||
          name.starts_with("tile.tmem."))
        worklist.push_back(op);
    });

    Value lastAsyncToken;
    // `!tile.tmem` handle -> the i32 tensor-memory address its lowered
    // `tessera_nvidia.tmem_alloc` yields (see lowerTmemOp).
    llvm::DenseMap<Value, Value> tmemAddress;
    SmallVector<Operation *> loweredTmemAllocs;
    for (Operation *op : worklist) {
      OpBuilder builder(op);
      Location loc = op->getLoc();
      StringRef name = op->getName().getStringRef();
      SmallVector<NamedAttribute> attrs;
      attrs.push_back(builder.getNamedAttr("arch",
                                           builder.getStringAttr(archStringForSM(smVersion))));

      if (name.starts_with("tile.tmem.") &&
          (smVersion < kBlackwellSM || smVersion >= kConsumerBlackwellSM)) {
        // TMEM is datacenter-Blackwell-only (sm_100a). Consumer Blackwell
        // sm_120 has no TMEM — it is NOT a superset of sm_100.
        op->emitError("NVIDIA TMEM lowering requires datacenter Blackwell "
                      "SM100 (consumer sm_120 has no TMEM)");
        signalPassFailure();
        return;
      }

      if (name == "tessera_nvidia.block_coordinate") {
        auto coordinate =
            cast<tessera::nvidia::BlockCoordinateOp>(op);
        Type i32 = builder.getI32Type();
        Type i64 = builder.getI64Type();
        // This is the sole lowering authority for the canonical SM120 grid:
        // grid.x enumerates 8-column tiles and grid.y enumerates 16-row tiles.
        // The operation verifier has already rejected every other contract.
        Value blockX = arith::ExtUIOp::create(
            builder, loc, i64, NVVM::BlockIdXOp::create(builder, loc, i32));
        Value blockY = arith::ExtUIOp::create(
            builder, loc, i64, NVVM::BlockIdYOp::create(builder, loc, i32));
        Value rowBase = mulI64(builder, loc, blockY,
                               i64Constant(builder, loc, 16));
        Value colBase = mulI64(builder, loc, blockX,
                               i64Constant(builder, loc, 8));
        coordinate.getRowBase().replaceAllUsesWith(rowBase);
        coordinate.getColBase().replaceAllUsesWith(colBase);
        op->erase();
        continue;
      }

      if (name == "tessera_nvidia.macro_cta_matmul") {
        // This target-only input need not contain a parsed Tile op, so load
        // the dialect explicitly before constructing its physical descriptor.
        getContext().getOrLoadDialect<tessera::tile::TesseraTileDialect>();
        auto macro = cast<tessera::nvidia::MacroCTAMatmulOp>(op);
        StringRef storage = macro.getStorage();
        auto mma = tessera::tile::TileMmaDescAttr::get(
            ctx, "mma_sync", 16, 8, 16, storage, storage, "f32",
            "row_major", "col_major", 1, /*scaleBlockK=*/0,
            /*scaleFormat=*/"");
        auto epilogue = tessera::tile::TileEpilogueAttr::get(
            ctx, /*bias=*/false, "none", "f32");
        OperationState state(loc, "tile.matmul_kernel");
        state.addOperands(op->getOperands());
        state.addAttribute("mma", mma);
        state.addAttribute("epilogue", epilogue);
        state.addAttribute("warps", builder.getI64IntegerAttr(4));
        state.addAttribute("staging", builder.getStringAttr("shared"));
        state.addAttribute("tessera.canonical_k_loop", builder.getBoolAttr(true));
        state.addAttribute("tessera.tile_m", builder.getI64IntegerAttr(16));
        state.addAttribute("tessera.tile_n", builder.getI64IntegerAttr(8));
        state.addAttribute("tessera.tile_k", builder.getI64IntegerAttr(16));
        if (macro.getLeadingDimensions().empty()) {
          state.addAttribute("tessera.vectorized_shared_panel",
                             builder.getBoolAttr(true));
          state.addAttribute("tessera.async_shared_panel",
                             builder.getBoolAttr(true));
        }
        Operation *kernel = builder.create(state);
        if (failed(materializeSm120MatmulKernel(
                cast<tessera::tile::MatmulKernelOp>(kernel), builder))) {
          signalPassFailure();
          return;
        }
        op->erase();
        continue;
      }

      // A composed layout reaches CUDA only through the shared proof boundary.
      // Coordinates precede runtime leaves in the canonical order defined by
      // TileDialect.h.  Nested outer tuples and dynamic scalar affine leaves
      // are exact after substitution; tuple-valued basis maps use their proven
      // mixed-radix div/rem materialization rather than flattening structure.
      if (isTileOp(op, "tile.materialize_composed_layout")) {
        auto materialize = cast<tessera::tile::MaterializeComposedLayoutOp>(op);
        if (smVersion < kConsumerBlackwellSM) {
          op->emitError("composed-layout CUDA materialization currently requires sm_120");
          signalPassFailure();
          return;
        }
        SmallVector<tessera::tile::ComposedLayoutMaterializationMode> modes;
        SmallVector<tessera::tile::ComposedLayoutDynamicLeaf> dynamicLeaves;
        if (!tessera::tile::getMaterializableComposedLayout(
                materialize.getLayout(), modes, dynamicLeaves) ||
            materialize.getCoordinates().size() !=
                modes.size() + dynamicLeaves.size()) {
          op->emitError("composed layout is not a scalar-output map proven by "
                        "the native layout authority");
          signalPassFailure();
          return;
        }
        ValueRange allOperands = materialize.getCoordinates();
        ValueRange coordinates = allOperands.take_front(modes.size());
        ValueRange runtimeLeaves = allOperands.drop_front(modes.size());
        auto resolve = [&](tessera::tile::ComposedLayoutDynamicLeaf::Kind kind,
                           unsigned mode, unsigned leafIndex,
                           int64_t staticValue) -> Value {
          if (staticValue != -1)
            return i64Constant(builder, loc, staticValue);
          for (auto [index, dynamicLeaf] : llvm::enumerate(dynamicLeaves))
            if (dynamicLeaf.kind == kind && dynamicLeaf.mode == mode &&
                dynamicLeaf.leaf == leafIndex)
              return runtimeLeaves[index];
          llvm_unreachable("verified dynamic composed-layout leaf is missing");
        };
        Value linear = i64Constant(builder, loc, 0);
        for (auto [mode, coordinate] : llvm::enumerate(coordinates)) {
          const auto &plan = modes[mode];
          Value outerStride = resolve(
              tessera::tile::ComposedLayoutDynamicLeaf::Kind::OuterStride,
              mode, 0, plan.outerStride);
          Value remaining = coordinate;
          Value basis = i64Constant(builder, loc, plan.offset);
          for (auto [leafIndex, staticShape] :
               llvm::enumerate(plan.basisShapes)) {
            Value shape = resolve(
                tessera::tile::ComposedLayoutDynamicLeaf::Kind::BasisShape,
                mode, leafIndex, staticShape);
            Value stride = resolve(
                tessera::tile::ComposedLayoutDynamicLeaf::Kind::BasisStride,
                mode, leafIndex, plan.basisStrides[leafIndex]);
            // Keep the complete quotient in the slowest mode, matching the
            // shared layout algebra's affine-outside-shape semantics.  A rem
            // on the final leaf would silently wrap non-compact tilers.
            const bool isSlowest = leafIndex + 1 == plan.basisShapes.size();
            Value digit = isSlowest
                              ? remaining
                              : arith::RemUIOp::create(builder, loc, remaining,
                                                      shape);
            basis = addI64(builder, loc, basis,
                           mulI64(builder, loc, digit, stride));
            if (!isSlowest)
              remaining =
                  arith::DivUIOp::create(builder, loc, remaining, shape);
          }
          linear = addI64(builder, loc, linear,
                          mulI64(builder, loc, basis, outerStride));
        }
        materialize.getResult().replaceAllUsesWith(linear);
        op->erase();
        continue;
      }

      if (isTileOp(op, "tile.packed_store")) {
        auto store = cast<tessera::tile::PackedStoreOp>(op);
        auto load =
            store.getInputs().front().getDefiningOp<
                tessera::tile::PackedLoadOp>();
        if (smVersion < kConsumerBlackwellSM || !load ||
            failed(materializeSm120PackedRoundTrip(load, store, builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("generic packed value lowering currently requires "
                          "sm_120");
          else if (!load)
            op->emitError("tile.packed_store requires a tile.packed_load "
                          "producer on SM120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.store")) {
        auto store = cast<tessera::tile::StoreOp>(op);
        if (store->hasAttr("tile.epilogue") || store->hasAttr("tile.residual")) {
          op->emitError("SM120 epilogue store requires a typed fragment_unpack producer");
          signalPassFailure();
          return;
        }
        auto memory =
            store->getAttrOfType<tessera::tile::TileMemoryLayoutAttr>(
                "tile.memory");
        if (!memory || memory.getLeadingDim() == 0 ||
            store.getInputs().size() != 4) {
          op->emitError("generic packed tile.store does not yet support bounds "
                        "or an SSA-supplied dynamic leading dimension");
          signalPassFailure();
          return;
        }
        auto load =
            store.getInputs().front().getDefiningOp<
                tessera::tile::PackedLoadOp>();
        if (smVersion < kConsumerBlackwellSM || !load ||
            failed(materializeSm120PackedDecodeStore(load, store, builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("generic packed decode currently requires sm_120");
          else if (!load)
            op->emitError("generic packed tile.store requires a "
                          "tile.packed_load producer");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.matmul_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120MatmulKernel(
                cast<tessera::tile::MatmulKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.matmul_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.softmax_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120SoftmaxKernel(
                cast<tessera::tile::SoftmaxKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.softmax_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.cuda_intrinsic_kernel")) {
        if (smVersion < kConsumerBlackwellSM) {
          op->emitError("tile.cuda_intrinsic_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        auto kernel = cast<tessera::tile::CudaIntrinsicKernelOp>(op);
        SmallVector<NamedAttribute> mathAttrs;
        for (StringRef key :
             {"kind", "input_storage", "output_storage", "rounding",
              "saturation", "lane_width", "signedness", "predicate_form"})
          mathAttrs.push_back(
              builder.getNamedAttr(key, op->getAttr(key)));
        createContractOp(builder, loc, "tessera_nvidia.cuda_math_kernel",
                         kernel.getInputs(), TypeRange{}, mathAttrs);
        op->erase();
        continue;
      }

      if (isTileOp(op, "tile.reduce_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120ReduceKernel(
                cast<tessera::tile::ReduceKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.reduce_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.activation_kernel")) {
        if (smVersion != kConsumerBlackwellSM ||
            failed(materializeSm120ActivationKernel(
                cast<tessera::tile::ActivationKernelOp>(op), builder))) {
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.norm_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120NormKernel(
                cast<tessera::tile::NormKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.norm_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.attention_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120AttentionKernel(
                cast<tessera::tile::AttentionKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.attention_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.attention_row_correction_kernel")) {
        if (smVersion != kConsumerBlackwellSM ||
            failed(materializeSm120AttentionRowCorrectionKernel(
                cast<tessera::tile::AttentionRowCorrectionKernelOp>(op), builder))) {
          if (smVersion != kConsumerBlackwellSM)
            op->emitError("tile.attention_row_correction_kernel requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.attention_backward_rows_kernel")) {
        if (smVersion != kConsumerBlackwellSM ||
            failed(materializeSm120AttentionBackwardKernel(op, builder, true))) {
          if (smVersion != kConsumerBlackwellSM)
            op->emitError("tile.attention_backward_rows_kernel requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.attention_backward_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120AttentionBackwardKernel(
                op, builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError(
                "tile.attention_backward_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.training_kernel")) {
        if (smVersion < kConsumerBlackwellSM) {
          op->emitError("tile.training_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        auto family = op->getAttrOfType<StringAttr>("family");
        auto storage = op->getAttrOfType<StringAttr>("storage");
        auto lineage = op->getAttrOfType<StringAttr>("tessera.schedule_hash");
        if (!family || !storage || storage.getValue() != "f32" || !lineage ||
            lineage.getValue().size() != 64) {
          op->emitError("SM120 training kernel requires f32 storage and a "
                        "64-character tessera.schedule_hash state-lineage digest");
          signalPassFailure();
          return;
        }
        if (family.getValue() != "lion_vjp" &&
            family.getValue() != "adafactor_vjp" &&
            family.getValue() != "optimizer_vjp" &&
            family.getValue() != "sequence_mixer_backward") {
          op->emitError("SM120 training kernel has an unsupported state-lineage family");
          signalPassFailure();
          return;
        }
        SmallVector<NamedAttribute> trainingAttrs;
        for (NamedAttribute attr : op->getAttrs())
          if (attr.getName() != "arch" &&
              attr.getName() != "state_lineage_digest")
            trainingAttrs.push_back(attr);
        trainingAttrs.push_back(builder.getNamedAttr(
            "state_lineage_digest", builder.getStringAttr(lineage.getValue())));
        trainingAttrs.push_back(builder.getNamedAttr(
            "arch", builder.getStringAttr(archStringForSM(smVersion))));
        createContractOp(builder, loc, "tessera_nvidia.training_kernel",
                         op->getOperands(), TypeRange{}, trainingAttrs);
        op->erase();
        continue;
      }

      if (isTileOp(op, "tile.paged_kv_read_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120PagedKVReadKernel(
                cast<tessera::tile::PagedKVReadKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.paged_kv_read_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }
      if (isTileOp(op, "tile.paged_attention_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120PagedAttentionKernel(
                cast<tessera::tile::PagedAttentionKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.paged_attention_kernel currently requires sm_120");
          signalPassFailure();
          return;
        }
        continue;
      }

      if (isTileOp(op, "tile.replay_ssm_decode_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120ReplaySSMDecodeKernel(
                cast<tessera::tile::ReplaySSMDecodeKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.replay_ssm_decode_kernel currently requires sm_120");
          signalPassFailure(); return;
        }
        continue;
      }
      if (isTileOp(op, "tile.replay_ssm_flush_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120ReplaySSMFlushKernel(
                cast<tessera::tile::ReplaySSMFlushKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.replay_ssm_flush_kernel currently requires sm_120");
          signalPassFailure(); return;
        }
        continue;
      }
      if (isTileOp(op, "tile.moe_dispatch_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120MoEDispatchKernel(
                cast<tessera::tile::MoEDispatchKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.moe_dispatch_kernel currently requires sm_120");
          signalPassFailure(); return;
        }
        continue;
      }
      if (isTileOp(op, "tile.moe_combine_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120MoECombineKernel(
                cast<tessera::tile::MoECombineKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.moe_combine_kernel currently requires sm_120");
          signalPassFailure(); return;
        }
        continue;
      }
      if (isTileOp(op, "tile.grouped_gemm_kernel")) {
        if (smVersion < kConsumerBlackwellSM ||
            failed(materializeSm120GroupedGemmKernel(
                cast<tessera::tile::GroupedGemmKernelOp>(op), builder))) {
          if (smVersion < kConsumerBlackwellSM)
            op->emitError("tile.grouped_gemm_kernel currently requires sm_120");
          signalPassFailure(); return;
        }
        continue;
      }

      if (isTileOp(op, "tile.mma")) {
        bool typedFragmentForm = llvm::any_of(op->getOperandTypes(), [](Type type) {
              return isa<tessera::tile::FragmentType>(type);
            });
        if (typedFragmentForm) {
          tessera::tile::FragmentUnpackOp unpack;
          tessera::tile::StoreOp store;
          bool hasOutputStore = false;
          if (op->getNumResults() == 1 && op->getResult(0).hasOneUse()) {
            unpack = dyn_cast<tessera::tile::FragmentUnpackOp>(
                *op->getResult(0).getUsers().begin());
            if (unpack && unpack.getResult().hasOneUse()) {
              store = dyn_cast<tessera::tile::StoreOp>(
                  *unpack.getResult().getUsers().begin());
              hasOutputStore = static_cast<bool>(store);
            }
          }
          auto desc = op->getAttrOfType<tessera::tile::TileMmaDescAttr>("mma");
          std::optional<Sm120FragmentDescriptor> physical =
              selectSm120Fragment(desc);
          bool isNVFP4 = physical &&
              physical->packing == Sm120InputPacking::PackedX8E2M1;
          unsigned expectedOperands = isNVFP4 ? 5 : 3;
          // Count DATA operands, matching MMAOp::verify() and the ROCm
          // lowering. A typed `tile.mma` legitimately carries a
          // `!tile.async_token` alongside A/B/acc -- WarpSpecLegalityPass
          // REQUIRES that edge -- so a raw `getNumOperands()` sees 4 where the
          // contract says 3 and rejects exactly the form the shared verifier
          // now accepts. Indexing must use the same filtered list, or operand
          // 3 would be the token rather than an NVFP4 scale.
          SmallVector<Value> mmaData = tessera::tile::dataOperands(op);
          if (smVersion < kConsumerBlackwellSM ||
              mmaData.size() != expectedOperands ||
              op->getNumResults() != 1 ||
              (!op->getResult(0).use_empty() && !hasOutputStore)) {
            op->emitError("initial typed fragment lowering requires sm_120, "
                          "logical A/B/zero-C operands (plus NVFP4 scales), and either an unused result or "
                          "fragment_unpack -> tile.store");
            signalPassFailure();
            return;
          }
          auto aPack = mmaData[0].getDefiningOp<tessera::tile::FragmentPackOp>();
          auto bPack = mmaData[1].getDefiningOp<tessera::tile::FragmentPackOp>();
          auto cZero = mmaData[2].getDefiningOp<tessera::tile::FragmentZeroOp>();
          tessera::tile::FragmentPackOp scaleAPack;
          tessera::tile::FragmentPackOp scaleBPack;
          if (isNVFP4) {
            scaleAPack = mmaData[3].getDefiningOp<
                tessera::tile::FragmentPackOp>();
            scaleBPack = mmaData[4].getDefiningOp<
                tessera::tile::FragmentPackOp>();
          }
          if (!aPack || !bPack || !cZero || !physical) {
            op->emitError("typed sm_120 lowering requires fragment_pack A/B "
                          "and fragment_zero accumulator with one descriptor");
            signalPassFailure();
            return;
          }
          if (isNVFP4 && (!scaleAPack || !scaleBPack)) {
            op->emitError("typed NVFP4 lowering requires logical scale_a and scale_b fragment packs");
            signalPassFailure();
            return;
          }
          if (hasOutputStore && desc.getAccType() != "f32" &&
              desc.getAccType() != "s32" && desc.getAccType() != "int32") {
            op->emitError("sm_120 fragment unpack/store requires f32 or s32 accumulator");
            signalPassFailure();
            return;
          }

          Value tid = NVVM::ThreadIdXOp::create(builder, loc, builder.getI32Type());
          Value lane = arith::AndIOp::create(
              builder, loc, tid,
              arith::ConstantIntOp::create(builder, loc, 31, 32));
          Value gid32 = arith::ShRUIOp::create(
              builder, loc, lane,
              arith::ConstantIntOp::create(builder, loc, 2, 32));
          Value tig32 = arith::AndIOp::create(
              builder, loc, lane,
              arith::ConstantIntOp::create(builder, loc, 3, 32));
          Value twoTig32 = arith::MulIOp::create(
              builder, loc, tig32,
              arith::ConstantIntOp::create(builder, loc, 2, 32));
          Value gid = arith::ExtUIOp::create(builder, loc, builder.getI64Type(), gid32);
          Value tig = arith::ExtUIOp::create(builder, loc, builder.getI64Type(),
                                             tig32);
          Value twoTig = arith::ExtUIOp::create(builder, loc, builder.getI64Type(),
                                                twoTig32);
          FailureOr<SmallVector<Value>> a =
              materializeSm120Mma16Pack(aPack, builder, gid, tig);
          FailureOr<SmallVector<Value>> b =
              materializeSm120Mma16Pack(bPack, builder, gid, tig);
          if (failed(a) || failed(b)) {
            signalPassFailure();
            return;
          }
          FailureOr<Value> scaleA = failure();
          FailureOr<Value> scaleB = failure();
          if (isNVFP4) {
            scaleA = materializeSm120NVFP4ScalePack(
                scaleAPack, builder, gid, tig);
            scaleB = materializeSm120NVFP4ScalePack(
                scaleBPack, builder, gid, tig);
            if (failed(scaleA) || failed(scaleB)) {
              signalPassFailure();
              return;
            }
          }

          Type fragTy = desc.getAType() == "f16"
              ? Type(VectorType::get({2}, Float16Type::get(ctx)))
              : Type(builder.getI32Type());
          SmallVector<Value> operands(*a);
          operands.append(b->begin(), b->end());
          Type resultTy;
          if (desc.getAccType() == "f32") {
            Value zero = arith::ConstantFloatOp::create(
                builder, loc, builder.getF32Type(), APFloat(0.0f));
            operands.append(4, zero);
            resultTy = LLVM::LLVMStructType::getLiteral(
                ctx, {builder.getF32Type(), builder.getF32Type(),
                      builder.getF32Type(), builder.getF32Type()});
          } else if (desc.getAccType() == "f16") {
            Value zero = arith::ConstantOp::create(
                builder, loc, fragTy, builder.getZeroAttr(fragTy));
            operands.push_back(zero);
            operands.push_back(zero);
            resultTy = LLVM::LLVMStructType::getLiteral(ctx, {fragTy, fragTy});
          } else {
            Value zero = arith::ConstantIntOp::create(builder, loc, 0, 32);
            operands.append(4, zero);
            resultTy = LLVM::LLVMStructType::getLiteral(
                ctx, {builder.getI32Type(), builder.getI32Type(),
                      builder.getI32Type(), builder.getI32Type()});
          }
          if (isNVFP4) {
            operands.push_back(*scaleA);
            operands.push_back(*scaleB);
          }
          std::string shape = "m16n8k" + std::to_string(desc.getK());
          SmallVector<NamedAttribute> mmaAttrs = {
              builder.getNamedAttr("arch", builder.getStringAttr("sm_120")),
              builder.getNamedAttr("shape", builder.getStringAttr(shape)),
              builder.getNamedAttr("dtype_ab",
                                   builder.getStringAttr(desc.getAType())),
              builder.getNamedAttr("dtype_c",
                                   builder.getStringAttr(desc.getAccType())),
              builder.getNamedAttr(
                  "instruction_family",
                  builder.getStringAttr(physical->instructionFamily)),
              builder.getNamedAttr(
                  "a_registers_per_lane",
                  builder.getI32IntegerAttr(physical->aRegistersPerLane)),
              builder.getNamedAttr(
                  "b_registers_per_lane",
                  builder.getI32IntegerAttr(physical->bRegistersPerLane)),
              builder.getNamedAttr(
                  "accumulator_registers_per_lane",
                  builder.getI32IntegerAttr(
                      physical->accumulatorRegistersPerLane)),
              builder.getNamedAttr("block_scaled", builder.getBoolAttr(isNVFP4))};
          if (isNVFP4) {
            mmaAttrs.push_back(builder.getNamedAttr(
                "scale_dtype", builder.getStringAttr("ue4m3")));
            mmaAttrs.push_back(builder.getNamedAttr(
                "scale_vector", builder.getStringAttr("4X")));
          }
          Operation *target = createContractOp(
              builder, loc,
              isNVFP4 ? "tessera_nvidia.nvfp4_block_scale_mma"
                      : "tessera_nvidia.mma_sync",
              operands,
              TypeRange{resultTy}, mmaAttrs);
          if (hasOutputStore &&
              failed(materializeSm120AccumulatorStore(
                  target->getResult(0), unpack, store, builder, gid, twoTig))) {
            signalPassFailure();
            return;
          }

          Operation *aView = aPack.getInputs().front().getDefiningOp();
          Operation *bView = bPack.getInputs().front().getDefiningOp();
          Operation *scaleAView = isNVFP4
              ? scaleAPack.getInputs().front().getDefiningOp() : nullptr;
          Operation *scaleBView = isNVFP4
              ? scaleBPack.getInputs().front().getDefiningOp() : nullptr;
          if (hasOutputStore) {
            store->erase();
            unpack->erase();
          }
          op->erase();
          if (aPack.getResult().use_empty())
            aPack->erase();
          if (bPack.getResult().use_empty())
            bPack->erase();
          if (cZero.getResult().use_empty())
            cZero->erase();
          if (scaleAPack && scaleAPack.getResult().use_empty())
            scaleAPack->erase();
          if (scaleBPack && scaleBPack.getResult().use_empty())
            scaleBPack->erase();
          if (aView && aView->use_empty())
            aView->erase();
          if (bView && bView != aView && bView->use_empty())
            bView->erase();
          if (scaleAView && scaleAView->use_empty())
            scaleAView->erase();
          if (scaleBView && scaleBView != scaleAView && scaleBView->use_empty())
            scaleBView->erase();
          continue;
        }
        if (op->getNumOperands() < 2 || op->getNumResults() > 1) {
          op->emitError("NVIDIA lowering requires tile.mma(lhs, rhs) -> optional result");
          signalPassFailure();
          return;
        }

        TypeRange resultTypes = op->getResultTypes();
        ValueRange operands = op->getOperands();
        if (smVersion >= kConsumerBlackwellSM) {
          // Consumer Blackwell (RTX 50-series, sm_120): warp-level `mma.sync`.
          // NOT a superset of datacenter sm_100 — no tcgen05/TMEM, no Hopper
          // wgmma (FP4 rides `mma.sync.aligned...block_scale`). Grounded in
          // gpu_target._CUDA_13_3_FEATURES[SM_120]. Mirrors the Python emitter
          // target_ir.py::_lower_nvidia_op; the tma_async_copy + mbarrier
          // companions come from the separate tile.async_copy / tile.wait_async
          // ops in the worklist (as with the wgmma path below).
          // The canonical fragment form is deliberately explicit at Tile IR:
          // A[4], B[2], C[2] all use vector<2xf16>, with the struct result
          // required by NVVM's m16n8k16 f16 MMA builder.  Do not synthesize
          // fragments from scalar/tensor values here: Tile IR must first carry
          // a real lane/layout pack, otherwise that would invent semantics.
          bool fragmentForm = operands.size() == 8 && resultTypes.size() == 1;
          auto fragTy = VectorType::get({2}, Float16Type::get(ctx));
          if (fragmentForm) {
            for (Value operand : operands)
              fragmentForm &= operand.getType() == fragTy;
            auto resultTy = dyn_cast<LLVM::LLVMStructType>(resultTypes.front());
            fragmentForm &= resultTy && resultTy.getBody().size() == 2 &&
                resultTy.getBody()[0] == fragTy && resultTy.getBody()[1] == fragTy;
          }
          if (!fragmentForm) {
            op->emitError("sm_120 tile.mma requires typed fragment registers "
                          "and an accumulator; tensor-valued producers must "
                          "materialize fragments before NVIDIA lowering");
            signalPassFailure();
            return;
          }
          attrs.push_back(builder.getNamedAttr("shape",
                                               builder.getStringAttr("m16n8k16")));
          attrs.push_back(builder.getNamedAttr("dtype_ab",
                                               builder.getStringAttr(fragmentForm ? "f16" : "bf16")));
          attrs.push_back(builder.getNamedAttr("dtype_c",
                                               builder.getStringAttr(fragmentForm ? "f16" : "f32")));
          attrs.push_back(builder.getNamedAttr("block_scaled",
                                               builder.getBoolAttr(false)));
          Operation *target = createContractOp(builder, loc,
                                               "tessera_nvidia.mma_sync",
                                               operands, resultTypes, attrs);
          op->replaceAllUsesWith(target->getResults());
          op->erase();
          continue;
        }
        if (smVersion >= kBlackwellSM) {
          attrs.push_back(builder.getNamedAttr("shape",
                                               builder.getStringAttr("m128n128k32")));
          attrs.push_back(builder.getNamedAttr("accum",
                                               builder.getStringAttr("tmem_f32")));
          attrs.push_back(builder.getNamedAttr("cta_group",
                                               builder.getI64IntegerAttr(2)));
          attrs.push_back(builder.getNamedAttr("source",
                                               builder.getStringAttr("tessera.matmul")));
          auto alloc = createContractOp(builder, loc, "tessera_nvidia.tmem_alloc",
                                        ValueRange{}, TypeRange{},
                                        {builder.getNamedAttr("columns",
                                                              builder.getI64IntegerAttr(128)),
                                         builder.getNamedAttr("arch",
                                                              builder.getStringAttr(archStringForSM(smVersion)))});
          (void)alloc;
          Operation *target = createContractOp(builder, loc,
                                               "tessera_nvidia.tcgen05_mma",
                                               operands, resultTypes, attrs);
          op->replaceAllUsesWith(target->getResults());
          op->erase();
          continue;
        }

        if (smVersion >= kHopperSM) {
          attrs.push_back(builder.getNamedAttr("shape",
                                               builder.getStringAttr("m64n64k16")));
          attrs.push_back(builder.getNamedAttr("dtype_ab",
                                               builder.getStringAttr("bf16")));
          attrs.push_back(builder.getNamedAttr("dtype_c",
                                               builder.getStringAttr("f32")));
          attrs.push_back(builder.getNamedAttr("warpgroup",
                                               builder.getI64IntegerAttr(4)));
          Operation *target = createContractOp(builder, loc,
                                               "tessera_nvidia.wgmma",
                                               operands, resultTypes, attrs);
          op->replaceAllUsesWith(target->getResults());
          op->erase();
          continue;
        }

        attrs.push_back(builder.getNamedAttr("shape",
                                             builder.getStringAttr("m16n16k16")));
        Operation *target = createContractOp(builder, loc, "tessera_nvidia.wmma",
                                             operands, resultTypes, attrs);
        op->replaceAllUsesWith(target->getResults());
        op->erase();
        continue;
      }

      if (isTileOp(op, "tile.async_copy")) {
        if (smVersion < kHopperSM) {
          op->emitError("NVIDIA TMA lowering requires Hopper SM90+");
          signalPassFailure();
          return;
        }
        attrs.push_back(builder.getNamedAttr("src_space",
                                             builder.getStringAttr("global")));
        attrs.push_back(builder.getNamedAttr("dst_space",
                                             builder.getStringAttr("shared")));
        attrs.push_back(builder.getNamedAttr("bytes",
                                             builder.getI64IntegerAttr(16)));
        Operation *target = createContractOp(builder, loc,
                                             "tessera_nvidia.tma_async_copy",
                                             op->getOperands(), op->getResultTypes(),
                                             attrs);
        if (target->getNumResults() > 0)
          lastAsyncToken = target->getResult(0);
        op->replaceAllUsesWith(target->getResults());
        op->erase();
        continue;
      }

      if (isTileOp(op, "tile.wait_async")) {
        if (smVersion < kHopperSM) {
          op->emitError("NVIDIA mbarrier lowering requires Hopper SM90+");
          signalPassFailure();
          return;
        }
        if (lastAsyncToken)
          createContractOp(builder, loc, "tessera_nvidia.mbarrier",
                           ValueRange{lastAsyncToken}, TypeRange{}, attrs);
        else
          createContractOp(builder, loc, "tessera_nvidia.mbarrier",
                           ValueRange{}, TypeRange{}, attrs);
        op->erase();
        continue;
      }

      // Structured kernels that do not map to a single NVIDIA matrix or
      // movement instruction still need a typed Target-IR contract.  Keep
      // their SSA signature intact and identify the canonical source op so a
      // later executable CUDA lowering can select the kernel implementation.
      // This is deliberately hardware-free Target-IR codegen evidence, not an
      // execution or linked-PTX claim.
      if (isTileOp(op, "tile.conv2d") || isTileOp(op, "tile.kv_cache")) {
        StringRef source = "tessera.conv2d_nhwc";
        if (isTileOp(op, "tile.kv_cache")) {
          source = "tessera.kv_cache.read";
          if (auto sourceAttr = op->getAttrOfType<StringAttr>("source"))
            source = sourceAttr.getValue();
        }
        attrs.push_back(builder.getNamedAttr("source",
                                             builder.getStringAttr(source)));
        Operation *target = createContractOp(
            builder, loc, "tessera_nvidia.cuda_kernel", op->getOperands(),
            op->getResultTypes(), attrs);
        op->replaceAllUsesWith(target->getResults());
        op->erase();
        continue;
      }

      if (name.starts_with("tile.control_")) {
        for (NamedAttribute attr : op->getAttrs())
          if (attr.getName() != "arch")
            attrs.push_back(attr);
        StringRef targetName = "tessera_nvidia.control_for";
        if (name == "tile.control_if")
          targetName = "tessera_nvidia.control_if";
        else if (name == "tile.control_while")
          targetName = "tessera_nvidia.control_while";
        else if (name == "tile.control_scan")
          targetName = "tessera_nvidia.control_scan";
        Operation *target = createContractOp(
            builder, loc, targetName, op->getOperands(), op->getResultTypes(),
            attrs);
        op->replaceAllUsesWith(target->getResults());
        op->erase();
        continue;
      }

      if (name.starts_with("tile.tmem.")) {
        // TILE-LATENT-DEFECTS-2026-09-27: every declared tile.tmem.* op is
        // mapped by op identity, and anything else under the prefix is
        // refused (Decision #21). This branch used to default any
        // unrecognized tile.tmem.* op -- including the unregistered legacy
        // spelling `tile.tmem.alloc` -- to a `tmem_store` contract, and it
        // erased ops without wiring their results, leaving users of a load
        // result or an allocation handle pointing at an erased op.
        if (failed(lowerTmemOp(op, builder, attrs, tmemAddress,
                               loweredTmemAllocs))) {
          signalPassFailure();
          return;
        }
        continue;
      }
    }

    // A TMEM allocation is erased only once every load/store that read its
    // handle has been rewritten onto the address; the alloc validation above
    // admits no other user, so a surviving use is a lowering bug, not input.
    for (Operation *alloc : loweredTmemAllocs) {
      if (!alloc->use_empty()) {
        alloc->emitError("NVIDIA_TMEM_HANDLE_UNLOWERED: TMEM handle still "
                         "has users after NVIDIA sm_")
            << static_cast<int>(smVersion) << " TMEM lowering";
        signalPassFailure();
        return;
      }
      alloc->erase();
    }

    Operation *unloweredFragment = nullptr;
    module.walk([&](Operation *candidate) {
      StringRef candidateName = candidate->getName().getStringRef();
      if (!unloweredFragment &&
          (candidateName == "tile.fragment_pack" ||
           candidateName == "tile.fragment_zero" ||
           candidateName == "tile.fragment_unpack" ||
           candidateName == "tile.store"))
        unloweredFragment = candidate;
    });
    if (unloweredFragment) {
      unloweredFragment->emitError(
          "NVIDIA lowering left an unsupported Tile fragment operation");
      signalPassFailure();
    }
  }
};

static LLVM::LLVMFuncOp declareVoidMarker(ModuleOp module, StringRef name) {
  if (auto fn = module.lookupSymbol<LLVM::LLVMFuncOp>(name))
    return fn;
  OpBuilder builder(module.getBodyRegion());
  builder.setInsertionPointToStart(module.getBody());
  auto fnType = LLVM::LLVMFunctionType::get(
      LLVM::LLVMVoidType::get(module.getContext()), {}, false);
  return builder.create<LLVM::LLVMFuncOp>(module.getLoc(), name, fnType);
}

static StringRef markerForTargetOp(StringRef opName) {
  if (opName == "tessera_nvidia.wgmma")
    return "llvm.nvvm.wgmma.contract";
  if (opName == "tessera_nvidia.tma_async_copy")
    return "llvm.nvvm.cp.async.bulk.tensor.contract";
  if (opName == "tessera_nvidia.mbarrier")
    return "llvm.nvvm.mbarrier.contract";
  if (opName == "tessera_nvidia.wmma")
    return "llvm.nvvm.mma.sync.contract";
  if (opName == "tessera_nvidia.mma_sync")  // consumer Blackwell sm_120 warp-level MMA
    return "llvm.nvvm.mma.sync.contract";
  if (opName == "tessera_nvidia.nvfp4_block_scale_mma")
    return "llvm.nvvm.mma.sync.block.scale.contract";
  if (opName == "tessera_nvidia.mx_block_scale_mma")
    return "llvm.nvvm.mma.sync.block.scale.contract";
  if (opName == "tessera_nvidia.tcgen05_mma")
    return "llvm.nvvm.tcgen05.mma.contract";
  if (opName == "tessera_nvidia.tmem_alloc")
    return "llvm.nvvm.tmem.alloc.contract";
  if (opName == "tessera_nvidia.tmem_load")
    return "llvm.nvvm.tmem.load.contract";
  if (opName == "tessera_nvidia.tmem_store")
    return "llvm.nvvm.tmem.store.contract";
  if (opName == "tessera_nvidia.cuda_kernel")
    return "llvm.nvvm.cuda.kernel.contract";
  if (opName == "tessera_nvidia.training_kernel")
    return "llvm.nvvm.cuda.training.kernel.contract";
  if (opName.starts_with("tessera_nvidia.control_"))
    return "llvm.nvvm.cuda.control.contract";
  return "llvm.nvvm.tessera.nvidia.diagnostic.contract";
}

// Increment 2 of the Tile IR / native Target IR tail: emit a *real*
// `nvvm.mma.sync` for the canonical m16n8k16 f16 fragment contract instead of a
// void marker. This is the codegen-contract end of the NVIDIA Target IR path —
// the emitted op is validated by the NVVM verifier (fragment counts / types /
// result struct), a real structural correctness signal even without a device.
//
// It fires only when `mma_sync` already carries the fragment operands. Both the
// f16 accumulator ABI (C:2 vector<2xf16>) and the execution-proven f32 ABI
// (C:4 f32, four-f32 struct result) are accepted. The abstract tile->target form
// (scalar operands, dtype_ab="bf16") does NOT match and falls through to the
// honest marker (Decision #21: never silently emit a different / wrong kernel).
// f16/bf16, tf32, fp8, and int8 use four A and two B registers for the
// canonical m16n8 shapes. FP64 DMMA uses the distinct m8n8k4 contract with one
// f64 A, one f64 B, and two f64 accumulator/result elements.
static bool tryLowerMmaSyncToNVVM(Operation *op, OpBuilder &builder) {
  if (op->getName().getStringRef() ==
      "tessera_nvidia.mx_block_scale_mma") {
    auto shape = op->getAttrOfType<StringAttr>("shape");
    auto dtypeAB = op->getAttrOfType<StringAttr>("dtype_ab");
    auto dtypeC = op->getAttrOfType<StringAttr>("dtype_c");
    auto scaleDtype = op->getAttrOfType<StringAttr>("scale_dtype");
    auto scaleVector = op->getAttrOfType<StringAttr>("scale_vector");
    auto blockScaled = op->getAttrOfType<BoolAttr>("block_scaled");
    if (!shape || !dtypeAB || !dtypeC || dtypeC.getValue() != "f32" ||
        !scaleDtype || scaleDtype.getValue() != "ue8m0" || !scaleVector ||
        !blockScaled || !blockScaled.getValue() ||
        op->getNumOperands() != 12 || op->getNumResults() != 1)
      return false;
    StringRef dtype = dtypeAB.getValue();
    bool isFP6 = dtype == "e2m3" || dtype == "e3m2";
    bool isMXFP4 = dtype == "e2m1";
    if (!((isFP6 && shape.getValue() == "m16n8k32" &&
           scaleVector.getValue() == "1X") ||
          (isMXFP4 && shape.getValue() == "m16n8k64" &&
           scaleVector.getValue() == "2X")))
      return false;
    auto structTy = dyn_cast<LLVM::LLVMStructType>(op->getResult(0).getType());
    if (!structTy || structTy.getBody().size() != 4 ||
        llvm::any_of(structTy.getBody(), [](Type type) { return !type.isF32(); }))
      return false;
    ValueRange operands = op->getOperands();
    for (Value value : operands.take_front(6))
      if (!value.getType().isInteger(32))
        return false;
    for (Value value : operands.slice(6, 4))
      if (!value.getType().isF32())
        return false;
    for (Value value : operands.take_back(2))
      if (!value.getType().isInteger(32))
        return false;
    std::string assembly = "mma.sync.aligned." + shape.getValue().str() +
        ".row.col.kind::" + (isMXFP4 ? std::string("mxf4")
                                     : std::string("mxf8f6f4")) +
        ".block_scale.scale_vec::" + scaleVector.getValue().str() +
        ".f32." + dtype.str() + "." + dtype.str() +
        ".f32.ue8m0 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, "
        "{$10,$11,$12,$13}, {$14}, {0, 0}, {$15}, {0, 0};";
    builder.setInsertionPoint(op);
    auto inlineMma = LLVM::InlineAsmOp::create(
        builder, op->getLoc(), structTy, operands, assembly,
        "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3,r,r",
        /*has_side_effects=*/false, /*is_align_stack=*/false,
        LLVM::tailcallkind::TailCallKind::None, /*asm_dialect=*/nullptr,
        /*operand_attrs=*/nullptr);
    op->replaceAllUsesWith(inlineMma.getOperation()->getResults());
    op->erase();
    return true;
  }
  if (op->getName().getStringRef() ==
      "tessera_nvidia.nvfp4_block_scale_mma") {
    auto shape = op->getAttrOfType<StringAttr>("shape");
    auto dtypeC = op->getAttrOfType<StringAttr>("dtype_c");
    auto blockScaled = op->getAttrOfType<BoolAttr>("block_scaled");
    if (!shape || shape.getValue() != "m16n8k64" || !dtypeC ||
        dtypeC.getValue() != "f32" || !blockScaled ||
        !blockScaled.getValue() || op->getNumOperands() != 12 ||
        op->getNumResults() != 1)
      return false;
    auto structTy = dyn_cast<LLVM::LLVMStructType>(op->getResult(0).getType());
    if (!structTy || structTy.getBody().size() != 4 ||
        llvm::any_of(structTy.getBody(), [](Type type) { return !type.isF32(); }))
      return false;
    ValueRange operands = op->getOperands();
    for (Value value : operands.take_front(6))
      if (!value.getType().isInteger(32))
        return false;
    for (Value value : operands.slice(6, 4))
      if (!value.getType().isF32())
        return false;
    for (Value value : operands.take_back(2))
      if (!value.getType().isInteger(32))
        return false;
    builder.setInsertionPoint(op);
    std::string assembly =
        "mma.sync.aligned.m16n8k64.row.col.kind::mxf4nvf4.block_scale."
        "scale_vec::4X.f32.e2m1.e2m1.f32.ue4m3 "
        "{$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13}, "
        "{$14}, {0, 0}, {$15}, {0, 0};";
    auto inlineMma = LLVM::InlineAsmOp::create(
        builder, op->getLoc(), structTy, operands, assembly,
        "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3,r,r",
        /*has_side_effects=*/false, /*is_align_stack=*/false,
        LLVM::tailcallkind::TailCallKind::None, /*asm_dialect=*/nullptr,
        /*operand_attrs=*/nullptr);
    op->replaceAllUsesWith(inlineMma.getOperation()->getResults());
    op->erase();
    return true;
  }
  if (op->getName().getStringRef() != "tessera_nvidia.mma_sync")
    return false;
  auto shape = op->getAttrOfType<StringAttr>("shape");
  auto dtypeAB = op->getAttrOfType<StringAttr>("dtype_ab");
  auto dtypeC = op->getAttrOfType<StringAttr>("dtype_c");
  if (!shape || !dtypeAB)
    return false;
  StringRef dtype = dtypeAB.getValue();
  bool isF16 = dtype == "f16";
  bool isBF16 = dtype == "bf16";
  bool isF64 = dtype == "f64";
  bool isTF32 = dtype == "tf32";
  bool isFP8 = dtype == "e4m3" || dtype == "e5m2";
  bool isS8 = dtype == "s8" || dtype == "int8";
  if (!((shape.getValue() == "m8n8k4" && isF64) ||
        (shape.getValue() == "m16n8k16" && (isF16 || isBF16)) ||
        (shape.getValue() == "m16n8k8" && isTF32) ||
        (shape.getValue() == "m16n8k32" && (isFP8 || isS8))))
    return false;
  if (op->getNumResults() != 1)
    return false;
  auto structTy = dyn_cast<LLVM::LLVMStructType>(op->getResult(0).getType());
  if (!structTy)
    return false;
  ValueRange operands = op->getOperands();
  Type fragTy = isF64
      ? Type(Float64Type::get(op->getContext()))
      : isF16
      ? Type(VectorType::get({2}, Float16Type::get(op->getContext())))
      : Type(IntegerType::get(op->getContext(), 32));
  unsigned aCount = isF64 ? 1 : 4;
  unsigned bCount = isF64 ? 1 : 2;
  bool isF32Accumulator = dtypeC && dtypeC.getValue() == "f32";
  bool isF16Accumulator = dtypeC && dtypeC.getValue() == "f16";
  bool isS32Accumulator = dtypeC &&
      (dtypeC.getValue() == "s32" || dtypeC.getValue() == "int32");
  bool isF64Accumulator = dtypeC && dtypeC.getValue() == "f64";
  if ((isF64 && !isF64Accumulator) ||
      (!isF64 && !isS8 && !isF32Accumulator &&
       !(isF16 && isF16Accumulator)) ||
      (isS8 && !isS32Accumulator))
    return false;
  unsigned cCount = (isF16Accumulator || isF64Accumulator) ? 2 : 4;
  if (operands.size() != aCount + bCount + cCount)
    return false;
  for (Value v : operands.take_front(aCount + bCount))
    if (v.getType() != fragTy)
      return false;
  Type cType = isF32Accumulator
      ? Type(Float32Type::get(op->getContext()))
      : (isS32Accumulator ? Type(IntegerType::get(op->getContext(), 32))
         : (isF64Accumulator ? Type(Float64Type::get(op->getContext()))
                             : Type(fragTy)));
  for (Value v : operands.drop_front(aCount + bCount))
    if (v.getType() != cType)
      return false;
  ArrayRef<Type> resultBody = structTy.getBody();
  if (resultBody.size() != cCount ||
      llvm::any_of(resultBody, [&](Type type) { return type != cType; }))
    return false;

  SmallVector<Value> a(operands.begin(), operands.begin() + aCount);
  SmallVector<Value> b(operands.begin() + aCount,
                       operands.begin() + aCount + bCount);
  SmallVector<Value> c(operands.begin() + aCount + bCount, operands.end());
  builder.setInsertionPoint(op);
  // LLVM 23 exposes FP8 MMA enums but its NVVM MmaOp verifier does not yet
  // admit the m16n8k32 FP8 shapes accepted by CUDA 13.3 and sm_120. Keep the
  // same typed i32/f32 contract and legalize only that gap through inline PTX.
  if (isFP8) {
    SmallVector<Value> asmOperands(a);
    asmOperands.append(b.begin(), b.end());
    asmOperands.append(c.begin(), c.end());
    std::string assembly =
        "mma.sync.aligned.m16n8k32.row.col.f32." + dtype.str() + "." +
        dtype.str() +
        ".f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, "
        "{$10,$11,$12,$13};";
    auto inlineMma = LLVM::InlineAsmOp::create(
        builder, op->getLoc(), structTy, ValueRange(asmOperands), assembly,
        "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3",
        /*has_side_effects=*/false, /*is_align_stack=*/false,
        LLVM::tailcallkind::TailCallKind::None, /*asm_dialect=*/nullptr,
        /*operand_attrs=*/nullptr);
    op->replaceAllUsesWith(inlineMma.getOperation()->getResults());
    op->erase();
    return true;
  }
  NVVM::MMATypes inputPtxType = NVVM::MMATypes::f16;
  if (isF64)
    inputPtxType = NVVM::MMATypes::f64;
  else if (isBF16)
    inputPtxType = NVVM::MMATypes::bf16;
  else if (isTF32)
    inputPtxType = NVVM::MMATypes::tf32;
  else if (dtype == "e4m3")
    inputPtxType = NVVM::MMATypes::e4m3;
  else if (dtype == "e5m2")
    inputPtxType = NVVM::MMATypes::e5m2;
  else if (isS8)
    inputPtxType = NVVM::MMATypes::s8;
  int64_t m = isF64 ? 8 : 16;
  int64_t n = 8;
  int64_t k = isF64 ? 4 : shape.getValue() == "m16n8k8" ? 8 :
              (shape.getValue() == "m16n8k32" ? 32 : 16);
  std::optional<NVVM::MMAIntOverflow> intOverflow = std::nullopt;
  if (isS8)
    intOverflow = NVVM::MMAIntOverflow::wrapped;
  auto mma = builder.create<NVVM::MmaOp>(
      op->getLoc(), structTy, ValueRange(a), ValueRange(b), ValueRange(c),
      ArrayRef<int64_t>{m, n, k}, /*b1Op=*/std::nullopt,
      /*intOverflow=*/intOverflow,
      /*multiplicandPtxTypes=*/
      std::array<NVVM::MMATypes, 2>{inputPtxType, inputPtxType},
      /*multiplicandLayouts=*/
      std::array<NVVM::MMALayout, 2>{NVVM::MMALayout::row, NVVM::MMALayout::col});
  op->replaceAllUsesWith(mma.getOperation()->getResults());
  op->erase();
  return true;
}

struct LowerNVIDIAToNVVMPass
    : PassWrapper<LowerNVIDIAToNVVMPass, OperationPass<ModuleOp>> {
  MLIR_DEFINE_EXPLICIT_INTERNAL_INLINE_TYPE_ID(LowerNVIDIAToNVVMPass)

  StringRef getArgument() const final { return "lower-tessera-nvidia-to-nvvm"; }

  StringRef getDescription() const final {
    return "Lower Tessera NVIDIA Target IR contracts to LLVM/NVVM artifact markers";
  }

  void getDependentDialects(DialectRegistry &registry) const final {
    registry.insert<gpu::GPUDialect, tessera::tile::TesseraTileDialect, arith::ArithDialect, LLVM::LLVMDialect, math::MathDialect,
                    NVVM::NVVMDialect, scf::SCFDialect>();
  }

  void runOnOperation() final {
    getContext().loadDialect<LLVM::LLVMDialect, NVVM::NVVMDialect>();
    ModuleOp module = getOperation();
    SmallVector<Operation *> targetOps;
    module.walk([&](Operation *op) {
      if (op->getName().getStringRef().starts_with("tessera_nvidia."))
        targetOps.push_back(op);
    });

    // A void marker carries no value. Before this guard the pass dropped every
    // use of a replaced contract's results, so a result consumed outside the
    // contract family (a TMEM load feeding arithmetic or a return) left its
    // user with a null operand -- an abort on an assertions-ON MLIR, undefined
    // behavior on NDEBUG. Uses by other contracts (or by ops nested inside
    // one) are erased together with them and stay legal.
    llvm::SmallPtrSet<Operation *, 32> contractSet(targetOps.begin(),
                                                   targetOps.end());
    auto erasedWithContracts = [&](Operation *user) {
      for (Operation *at = user; at; at = at->getParentOp())
        if (contractSet.contains(at))
          return true;
      return false;
    };

    for (Operation *op : targetOps) {
      // Every path below erases `op`; drop it first so the set only ever
      // names live, not-yet-processed contracts.
      contractSet.erase(op);
      OpBuilder builder(op);
      if (auto cudaMath =
              dyn_cast<tessera::nvidia::CudaMathKernelOp>(op)) {
        if (failed(materializeSm120CudaIntrinsicKernel(cudaMath, builder))) {
          signalPassFailure();
          return;
        }
        continue;
      }
      if (auto row = dyn_cast<tessera::nvidia::RowRegionKernelOp>(op)) {
        if (failed(tessera::row_region::verifyKernel(op))) return signalPassFailure();
        auto fn = cast<LLVM::LLVMFuncOp>(op->getRegion(0).front().front());
        SmallVector<Operation *> ids;
        fn.walk([&](Operation *child) { if (isa<gpu::ThreadIdOp,gpu::BlockIdOp,gpu::BlockDimOp>(child)) ids.push_back(child); });
        for (Operation *id : ids) {
          OpBuilder b(id); Value value;
          if (auto thread = dyn_cast<gpu::ThreadIdOp>(id)) {
            if (thread.getDimension()!=gpu::Dimension::x) return signalPassFailure();
            value=NVVM::ThreadIdXOp::create(b,id->getLoc(),b.getI32Type());
          } else if (auto block=dyn_cast<gpu::BlockIdOp>(id)) {
            if (block.getDimension()!=gpu::Dimension::x) return signalPassFailure();
            value=NVVM::BlockIdXOp::create(b,id->getLoc(),b.getI32Type());
          } else {
            auto dimension=cast<gpu::BlockDimOp>(id);
            if (dimension.getDimension()!=gpu::Dimension::x) return signalPassFailure();
            value=NVVM::BlockDimXOp::create(b,id->getLoc(),b.getI32Type());
          }
          Value index=arith::IndexCastOp::create(b,id->getLoc(),b.getIndexType(),value);
          id->getResult(0).replaceAllUsesWith(index); id->erase();
        }
        fn->setAttr("nvvm.kernel",UnitAttr::get(module.getContext()));
        fn->moveBefore(op); op->erase(); continue;
      }
      // Real NVVM emission for the fragment-typed mma_sync contract; the abstract
      // marker form falls through to the void-marker path below.
      if (tryLowerMmaSyncToNVVM(op, builder))
        continue;
      for (Operation *user : op->getUsers()) {
        if (erasedWithContracts(user))
          continue;
        op->emitError("NVIDIA_MARKER_RESULT_USED: '")
            << op->getName() << "' has no value-producing NVVM lowering, but "
            << "its result is used by '" << user->getName()
            << "'; a void artifact marker cannot supply it";
        signalPassFailure();
        return;
      }
      auto marker = declareVoidMarker(module, markerForTargetOp(op->getName().getStringRef()));
      builder.create<LLVM::CallOp>(op->getLoc(), TypeRange{},
                                   SymbolRefAttr::get(marker), ValueRange{});
      if (!op->use_empty())
        op->dropAllUses();
      op->erase();
    }

    bool unconsumedPackedLoad = false;
    module.walk([&](tessera::tile::PackedLoadOp load) {
      load.emitError("SM120 packed load must feed tile.store, "
                     "tile.packed_store, or a supported fragment consumer");
      unconsumedPackedLoad = true;
    });
    if (unconsumedPackedLoad) {
      signalPassFailure();
      return;
    }
  }
};

} // namespace

std::unique_ptr<Pass> createLowerTileToNVIDIAPass(int sm) {
  return std::make_unique<LowerTileToNVIDIAPass>(sm);
}

std::unique_ptr<Pass> createLowerNVIDIAToNVVMPass() {
  return std::make_unique<LowerNVIDIAToNVVMPass>();
}

void buildTesseraNVIDIABackendPipeline(OpPassManager &pm) {
  pm.addPass(createTileBufferReusePass());
  pm.addPass(createTileBufferArenaPass());
  pm.addPass(createLowerTileToNVIDIAPass(kHopperSM));
  pm.addPass(createLowerNVIDIAToNVVMPass());
}

void buildTesseraHopperBackendPipeline(OpPassManager &pm) {
  pm.addPass(createTileBufferReusePass());
  pm.addPass(createTileBufferArenaPass());
  pm.addPass(createLowerTileToNVIDIAPass(kHopperSM));
  pm.addPass(createLowerNVIDIAToNVVMPass());
}

void buildTesseraBlackwellBackendPipeline(OpPassManager &pm) {
  pm.addPass(createTileBufferReusePass());
  pm.addPass(createTileBufferArenaPass());
  pm.addPass(createLowerTileToNVIDIAPass(kBlackwellSM));
  pm.addPass(createLowerNVIDIAToNVVMPass());
}

void buildTesseraConsumerBlackwellBackendPipeline(OpPassManager &pm) {
  pm.addPass(createTileBufferReusePass());
  pm.addPass(createTileBufferArenaPass());
  pm.addPass(createLowerTileToNVIDIAPass(kConsumerBlackwellSM));
  pm.addPass(createLowerNVIDIAToNVVMPass());
  pm.addPass(createConvertNVGPUToNVVMPass());
}

void registerTesseraNVIDIABackendPasses() {
  registerPass([]() { return createLowerTileToNVIDIAPass(kHopperSM); });
  registerPass([]() { return createLowerNVIDIAToNVVMPass(); });
  registerPass([]() { return createNVIDIADynamicSharedPass(); });
  registerPass([]() { return createGenerateNVIDIAPhiloxKernelPass(); });

  PassPipelineRegistration<> nvidiaPipeline(
      "tessera-lower-to-nvidia",
      "Lower Tessera Tile IR to NVIDIA NVVM/PTX artifact contracts",
      [](OpPassManager &pm) { buildTesseraNVIDIABackendPipeline(pm); });
  PassPipelineRegistration<> hopperPipeline(
      "tessera-lower-to-hopper",
      "Lower Tessera Tile IR to Hopper WGMMA/TMA artifact contracts",
      [](OpPassManager &pm) { buildTesseraHopperBackendPipeline(pm); });
  PassPipelineRegistration<> blackwellPipeline(
      "tessera-lower-to-blackwell",
      "Lower Tessera Tile IR to Blackwell TCGEN05/TMEM artifact contracts",
      [](OpPassManager &pm) { buildTesseraBlackwellBackendPipeline(pm); });
  PassPipelineRegistration<> sm90Pipeline(
      "tessera-lower-to-nvidia-sm90",
      "Lower Tessera Tile IR to exact SM90 WGMMA/TMA NVVM contracts",
      [](OpPassManager &pm) { buildTesseraHopperBackendPipeline(pm); });
  PassPipelineRegistration<> sm100Pipeline(
      "tessera-lower-to-nvidia-sm100",
      "Lower Tessera Tile IR to exact SM100 TCGEN05/TMEM NVVM contracts",
      [](OpPassManager &pm) { buildTesseraBlackwellBackendPipeline(pm); });
  PassPipelineRegistration<> sm120Pipeline(
      "tessera-lower-to-nvidia-sm120",
      "Lower Tessera Tile IR to exact SM120 warp-level MMA NVVM contracts",
      [](OpPassManager &pm) {
        buildTesseraConsumerBlackwellBackendPipeline(pm);
      });
}

void registerTesseraNVIDIATargetDialect(DialectRegistry &registry) {
  registry.insert<nvgpu::NVGPUDialect, arith::ArithDialect, func::FuncDialect, gpu::GPUDialect,
                  math::MathDialect, memref::MemRefDialect, scf::SCFDialect,
                  LLVM::LLVMDialect, NVVM::NVVMDialect,
                  tessera::nvidia::TesseraNVIDIADialect>();
}

void registerTesseraNVIDIABackendDialects(DialectRegistry &registry) {
  registerTesseraNVIDIATargetDialect(registry);
  // The backend tool parses Tile producer IR, including the buffer views
  // emitted by the canonical scheduled-package path.  Keep this source
  // dialect out of the narrower Target-IR registry above: Target IR must not
  // accept upstream bufferization operations.
  registry.insert<bufferization::BufferizationDialect,
                  tessera::tile::TesseraTileDialect>();
}

} // namespace tessera
