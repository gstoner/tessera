#include "NativeRowSchedule.h"
//===- PMPasses.cpp — Programming Model v1.1 passes and pipelines ---------===//
//
// Library-owned pass bodies. Previously these lived in
// `tools/tessera-opt/PassPipelinesPM11.cpp`, a driver source, so the passes
// could not be constructed or lit-tested independently of that driver (W0.6).
//
// See PMPasses.h for the maturity contract: the verifier is general, while the
// two lowering passes are real only for explicitly registered bounded family
// contracts and fail closed outside them.
//
//===----------------------------------------------------------------------===//

#include "tessera/ProgrammingModel/PMPasses.h"
#include "tessera/ProgrammingModel/ScheduleDialect.h"
#include "Tessera/Dialect/Tile/TileDialect.h"
#include "Tessera/IR/Dialects.h"
#include "Tessera/IR/TesseraOps.h"
#include "Tessera/IR/NVFP4IngestContract.h"
#include "Tessera/IR/ScaledBatchContract.h"
#include "Tessera/IR/AttentionShapeContract.h"
#include "Tessera/IR/AttentionCheckpointStorage.h"
#include "Tessera/IR/AttentionTangentZero.h"
#include "tessera/Dialect/Attn/AttnDialect.h"

#include "mlir/Dialect/Arith/IR/Arith.h"
#include "mlir/Dialect/Bufferization/IR/Bufferization.h"
#include "mlir/Dialect/Func/IR/FuncOps.h"
#include "mlir/Dialect/GPU/IR/GPUDialect.h"
#include "mlir/Parser/Parser.h"
#include "mlir/Dialect/LLVMIR/LLVMDialect.h"
#include "mlir/Dialect/LLVMIR/NVVMDialect.h"
#include "mlir/Dialect/MemRef/IR/MemRef.h"
#include "mlir/Dialect/Math/IR/Math.h"
#include "mlir/Dialect/SCF/IR/SCF.h"
#include "mlir/Dialect/Tensor/IR/Tensor.h"
#include "mlir/Dialect/Vector/IR/VectorOps.h"
#include "mlir/IR/Builders.h"
#include "Tessera/IR/StructuredReductionContract.h"
#include "Tessera/IR/StaticPermutationContract.h"
#include "Tessera/IR/TransposeUtils.h"
#include "mlir/IR/IRMapping.h"
#include "mlir/IR/Verifier.h"
#include "llvm/ADT/SetVector.h"
#include "mlir/Transforms/RegionUtils.h"
#include "mlir/IR/BuiltinAttributes.h"
#include "mlir/IR/BuiltinOps.h"
#include "mlir/IR/DialectRegistry.h"
#include "mlir/IR/SymbolTable.h"
#include "mlir/Pass/Pass.h"
#include "mlir/Pass/PassManager.h"
#include "mlir/Pass/PassRegistry.h"
#include "mlir/Transforms/Passes.h"
#include "llvm/ADT/StringExtras.h"
#include "llvm/ADT/DenseSet.h"
#include "llvm/ADT/StringSet.h"
#include "llvm/ADT/StringSwitch.h"
#include "llvm/Support/MathExtras.h"
#include "llvm/Support/JSON.h"
#include "llvm/Support/SHA256.h"
#include "llvm/Support/raw_ostream.h"

#ifdef TESSERA_HAVE_NVIDIA_TARGET_IR
#include "TesseraNVIDIADialect.h.inc"
#endif

#include <algorithm>
#include <cmath>
#include <limits>
#include <optional>
#include <string>

using namespace mlir;

namespace tessera {

#include "NativeCheckpoint.h"
#include "NativeAttentionRowCorrection.h"
#include "NativeAttentionRecompute.h"
#include "NativeAttentionJvp.h"
#include "NativePagedKV.h"
#include "NativeScaleTranspose.h"
#include "NativeNVFP4Ingest.h"
#include "NativeMXFP4Storage.h"
#include "NativeMoeDispatch.h"
#include "NativeSSD.h"
#include "NativeAbsolute.h"
#include "NativeX86Kernel.h"
#include "NativeROCMMath.h"
#include "NativeResultPermutation.h"
#include "NativeSparse.h"

// ---------------------------------------------------------------------------
// Dialect registration
// ---------------------------------------------------------------------------

void registerPMPipelinesV11(DialectRegistry &registry) {
  schedule::registerScheduleDialect(registry);
}

// ---------------------------------------------------------------------------
// PMV11 verifier pass — walks the module and verifies every op whose dialect
// name starts with schedule/cache/tile. This is a real verifier.
// ---------------------------------------------------------------------------

namespace {
struct PMV11VerifierPass
    : public PassWrapper<PMV11VerifierPass, OperationPass<ModuleOp>> {

  MLIR_DEFINE_EXPLICIT_INTERNAL_INLINE_TYPE_ID(PMV11VerifierPass)

  StringRef getArgument() const override { return "tessera-pm-verify"; }
  StringRef getDescription() const override {
    return "Verify all Schedule / Cache / TileMemory v1.1 ops";
  }

  void runOnOperation() override {
    ModuleOp mod = getOperation();
    bool anyFailed = false;
    mod.walk([&](Operation *op) -> WalkResult {
      StringRef name = op->getName().getStringRef();
      if (!name.starts_with("schedule.") && !name.starts_with("cache.") &&
          !name.starts_with("tile."))
        return WalkResult::advance();

      if (failed(verifyOp(op)))
        anyFailed = true;
      return WalkResult::advance();
    });
    if (anyFailed) signalPassFailure();
  }

private:
  // Inline lightweight verification — the single production implementation of
  // the schedule./cache./tile. structural checks (Decision #31; the unbuilt
  // ScheduleOps.cpp duplicate was deleted 2026-08-10).
  LogicalResult verifyOp(Operation *op) {
    StringRef name = op->getName().getStringRef();

    // schedule.mesh.define
    if (name == "schedule.mesh.define") {
      auto dims  = op->getAttrOfType<ArrayAttr>("dims");
      auto names = op->getAttrOfType<ArrayAttr>("axis_names");
      if (!dims || dims.empty())
        return op->emitOpError("requires non-empty 'dims'");
      if (!names || names.size() != dims.size())
        return op->emitOpError("'axis_names' must have same length as 'dims'");
      return success();
    }

    // schedule.pipeline.region
    if (name == "schedule.pipeline.region") {
      auto mb = op->getAttrOfType<IntegerAttr>("micro_batches");
      if (!mb || mb.getInt() < 1)
        return op->emitOpError("'micro_batches' must be >= 1");
      return success();
    }

    // tile.async_copy / tile.wait_async — `stage` is an OPTIONAL legacy-form
    // grouping key under the declared contract (TileOps.td): the production
    // dependency encoding is the `!tile.async_token` SSA edge, which carries no
    // stage at all. Requiring the attribute here rejected the production
    // TileIRLoweringPass output; only well-formedness is checked. The full
    // contract (token placement, producer identity) is owned by the registered
    // dialect's AsyncCopyOp/WaitAsyncOp verifiers in TileOps.cpp.
    if (name == "tile.async_copy" || name == "tile.wait_async") {
      if (auto stage = op->getAttrOfType<IntegerAttr>("stage");
          stage && stage.getInt() < 0)
        return op->emitOpError("'stage' must be >= 0 when present");
      return success();
    }

    // tile.mbarrier.alloc
    if (name == "tile.mbarrier.alloc") {
      auto count = op->getAttrOfType<IntegerAttr>("count");
      if (!count || count.getInt() <= 0)
        return op->emitOpError("'count' must be > 0");
      auto scope = op->getAttrOfType<StringAttr>("scope");
      if (!scope || !isValidScope(scope.getValue()))
        return op->emitOpError("'scope' must be one of thread, warp, block, cluster, device, mesh");
      if (!supportsMBarrier(op))
        return op->emitOpError("mbarrier requires target/arch containing sm90, sm100, sm120, hopper, or blackwell");
      return success();
    }

    if (name == "tile.mbarrier.arrive_expect_tx") {
      auto bytes = op->getAttrOfType<IntegerAttr>("bytes");
      if (!bytes || bytes.getInt() <= 0)
        return op->emitOpError("'bytes' must be > 0");
      auto scope = op->getAttrOfType<StringAttr>("scope");
      if (!scope || !isValidScope(scope.getValue()))
        return op->emitOpError("'scope' must be one of thread, warp, block, cluster, device, mesh");
      auto semantics = op->getAttrOfType<StringAttr>("semantics");
      if (!semantics || (semantics.getValue() != "release" &&
                         semantics.getValue() != "acq_rel" &&
                         semantics.getValue() != "seq_cst"))
        return op->emitOpError("'semantics' must be release, acq_rel, or seq_cst");
      return success();
    }

    if (name == "tile.mbarrier.try_wait") {
      if (op->getNumOperands() != 2)
        return op->emitOpError("expected exactly 2 operands (barrier, token)");
      return success();
    }

    if (name == "tile.atomic") {
      auto order = op->getAttrOfType<StringAttr>("order");
      if (!order || !isValidOrder(order.getValue()))
        return op->emitOpError("'order' must be relaxed, acquire, release, acq_rel, or seq_cst");
      auto scope = op->getAttrOfType<StringAttr>("scope");
      if (!scope || !isValidScope(scope.getValue()))
        return op->emitOpError("'scope' must be one of thread, warp, block, cluster, device, mesh");
      return success();
    }

    if (name == "tile.barrier") {
      auto divergent = op->getAttrOfType<BoolAttr>("divergent");
      if (divergent && divergent.getValue())
        return op->emitOpError("barrier cannot be marked divergent");
      return success();
    }

    // schedule.knob
    if (name == "schedule.knob") {
      auto choices = op->getAttrOfType<ArrayAttr>("choices");
      if (!choices || choices.empty())
        return op->emitOpError("'choices' must be non-empty");
      auto logits = op->getAttrOfType<ArrayAttr>("logits");
      if (logits && logits.size() != choices.size())
        return op->emitOpError("'logits' must have same size as 'choices'");
      return success();
    }

    return success(); // other ops: no custom constraint
  }

  bool isValidScope(StringRef scope) const {
    return scope == "thread" || scope == "warp" || scope == "block" ||
           scope == "cluster" || scope == "device" || scope == "mesh";
  }

  bool isValidOrder(StringRef order) const {
    return order == "relaxed" || order == "acquire" || order == "release" ||
           order == "acq_rel" || order == "seq_cst";
  }

  bool supportsMBarrier(Operation *op) const {
    ModuleOp module = op->getParentOfType<ModuleOp>();
    if (!module) return false;
    auto target = module->getAttrOfType<StringAttr>("target");
    auto arch = module->getAttrOfType<StringAttr>("arch");
    StringRef value = target ? target.getValue() : (arch ? arch.getValue() : "");
    return value.contains("sm90") || value.contains("sm_90") ||
           value.contains("sm100") || value.contains("sm_100") ||
           value.contains("sm120") || value.contains("sm_120") ||
           value.contains("hopper") || value.contains("blackwell");
  }
};
} // anonymous namespace

// ---------------------------------------------------------------------------
// Graph -> Schedule — bounded mixed-level static matmul contract.
// ---------------------------------------------------------------------------

namespace {
// Whole-row, zero-origin, unit-step views retain entry storage roots.
// The caller owns the roots throughout the launch; the output is fresh.
static FailureOr<std::pair<Value, int64_t>> foldedInputStorage(Value value) {
  auto slice = value.getDefiningOp<tensor::ExtractSliceOp>();
  // MLIR canonicalization removes identity slices. An entry argument is the
  // same whole-row view with row pitch K; retain the named physical ABI.
  Value storage = slice ? Value(slice.getSource()) : value;
  auto root = dyn_cast<BlockArgument>(storage);
  auto type = dyn_cast<RankedTensorType>(storage.getType());
  auto logical = dyn_cast<RankedTensorType>(value.getType());
  if ((type && type.getEncoding()) || (logical && logical.getEncoding())) {
    emitError(value.getLoc(),
              "row-pitched folded storage requires unencoded dense roots and logical views");
    return failure();
  }
  if (!root || !isa<func::FuncOp>(root.getOwner()->getParentOp()) ||
      !root.getOwner()->isEntryBlock() || !type || !logical ||
      type.getRank() != 2 || logical.getRank() != 2 ||
      !type.hasStaticShape() || !logical.hasStaticShape() ||
      type.getElementType() != logical.getElementType() ||
      type.getDimSize(0) != logical.getDimSize(0) ||
      type.getDimSize(1) < logical.getDimSize(1) ||
      type.getDimSize(1) <= 0 || type.getDimSize(1) % 16 != 0 ||
      type.getDimSize(0) > INT64_MAX / type.getDimSize(1) ||
      (slice && (slice.getStaticOffsets() != ArrayRef<int64_t>({0, 0}) ||
                 slice.getStaticStrides() != ArrayRef<int64_t>({1, 1}) ||
                 slice.getStaticSizes() != logical.getShape())))
    return failure();
  return std::pair<Value, int64_t>{storage, type.getDimSize(1)};
}

struct MatmulSchedule {
  StringRef bLayout = "col_major";
  bool nvfp4TransposeA = false;
  bool nvfp4TransposeB = false;
  StringRef target;
  StringRef arch;
  StringRef storage;
  //: B's storage when it differs from A's. Empty means "same as A", which is
  //: every case but RDNA4's mixed OCP FP8 pairs -- the hardware has
  //: V_WMMA_F32_16X16X16_FP8_BF8 and its mirror, and the descriptor is where
  //: that pairing has to be expressible or nothing below it can select it.
  StringRef storageB;
  //: The block-scale contract, when the Graph op carried one. `scaleBlockK`
  //: is the contraction extent sharing a scale (0 = unscaled) and
  //: `scaleFormat` its element form. The Schedule is where this has to live:
  //: it decides what the program computes, and a scale dropped here is
  //: Decision #32 loss on the attribute that picks the instruction.
  int64_t scaleBlockK = 0;
  StringRef scaleFormat;
  StringRef physicalContract;
  int64_t aRowStride = 0, bRowStride = 0;
  int64_t independentBatchRows = 0;
  int64_t independentBatchCount = 0;
  bool sharedBatchRhs = false;
  bool sharedBatchLhs = false;
  bool typedTransposeA = false;
  SmallVector<RankedTensorType> broadcastTypes;
  RankedTensorType broadcastResult;
  //: ROCM-FP8-BLOCKSCALE-1: the B (weight) scale block along N, from
  //: `scale_layout.block[0]`. 0 unless the logical W8A8 block-scale contract
  //: was derived; semantic (it selects which scale multiplies a column), so it
  //: enters the digest whenever it is set.
  int64_t scaleBlockN = 0;
  //: The macro K tile (ROCM-MACRO-K-TILE-1). 0 means "one instruction K per
  //: block", i.e. the historical unblocked loop. `kBlocks = blockK / tileK`.
  int64_t blockK = 0;
  //: ROCM-SPLIT-K-1: cross-workgroup split-K. `splitK` K slices each write
  //: an fp32 partial into an [S, M, N] workspace, and a second kernel sums
  //: them in fixed slice order and applies the epilogue. 1 = no split.
  //: Both fields are SEMANTIC (Decision #21a): the slice count and the
  //: reduction order decide the floating-point result, so they enter the
  //: digest and every consumer refuses a split that arrives without an
  //: explicit `ordered` reduction.
  int64_t splitK = 1;
  StringRef splitKReduction;
  //: Why an occupancy-short schedule was left unsplit (empty otherwise). Not
  //: part of the contract or the digest; Graph->Schedule turns it into a
  //: ROCM_SPLIT_K_NOT_APPLIED warning so the fallback is never silent.
  std::string splitKFallback;
  //: Why a W8A8 schedule kept the register panel although its rule would
  //: have asked for the LDS body (empty otherwise). Not part of the digest;
  //: Graph->Schedule turns it into ROCM_FP8_BLOCKSCALE_LDS_NOT_APPLIED.
  std::string panelFallback;
  StringRef accum;
  int64_t m;
  int64_t n;
  int64_t k;
  int64_t tileM = 16;
  int64_t tileN = 16;
  int64_t tileK = 16;
  int64_t macroTileM = 16;
  int64_t macroTileN = 16;
  int64_t warps = 1;
  int64_t pipelineDepth = 1;
  //: ROCM-FP8-BLOCKSCALE-1 large-M body: "global" (the one-wave register
  //: panel) or "lds" (the multi-wave LDS-staged workgroup). A performance
  //: key the W8A8 rule sets; every other schedule is "global".
  StringRef staging = "global";
  StringRef rasterOrder = "row_major";
  int64_t rasterGroup = 1;
  bool dynamicM = false;
  bool dynamicN = false;
  bool dynamicK = false;
  bool bias = false;
  bool residual = false;
  StringRef activation = "none";
  StringRef output = "f32";
};

static StringRef moduleString(ModuleOp module, StringRef primary,
                              StringRef fallback) {
  if (auto value = module->getAttrOfType<StringAttr>(primary))
    return value.getValue();
  if (auto value = module->getAttrOfType<StringAttr>(fallback))
    return value.getValue();
  return {};
}

// ── ROCM-SPLIT-K-1: the one split-K decider ─────────────────────────────
//
// This is the production authority (Decision #31). The Python predicate
// `rocm_tiling._split_k_required` / `select_split_k` is its declared ORACLE:
// `scheduled_matmul.verify_matmul_projection` recomputes the decision on every
// package and refuses one that disagrees, the same arrangement as the macro
// tile (`rocm_tiling.select_macro_tile`).
//
// Keyed on OCCUPANCY, not K magnitude: split-K exists to put work on units
// that would otherwise idle, so the trigger is "too few workgroups to occupy
// the machine". The target is MEASURED (ROCM-SPLIT-K-1 follow-on, 2026-09-27,
// sync GFX1201-LANES-2026-09-27): a device-clock slice sweep over 16 skinny
// shapes x {f16, bf16} x S in {1..32} on Tajasarus
// (benchmarks/baselines/rocm_split_k_20260927/) found splitting pays well past
// one workgroup per WGP -- 16x768x2048 (48 tiles) gains 2.4x at S=4, and
// 64x512x2048 (128 tiles) 1.8x at S=2 -- while 32x1536x4096 (192 tiles) is
// neutral at S=2 and loses from S=8, and 16x2048x768 / 64x512x2048 lose once
// tiles x S reaches 1024 / 4096. The rule adopted -- chosen because it is
// positive at every measured point, not because it is the peak -- is: total
// workgroups tiles x S at most 256 (8 single-wave workgroups per WGP), S a
// power of two <= 32 (the largest count measured). The reason more
// workgroups than WGPs help is NOT measured (no counters on WSL2); several
// single-wave workgroups can co-reside on a WGP's four SIMDs, which is one
// hypothesis. Mirrors `rocm_tiling._SPLIT_K_TARGET_WORKGROUPS` and
// `SPLIT_K_MAX_SLICES`; the projection check keeps the two equal.
constexpr int64_t kGfx1201SplitKTargetWorkgroups = 256;
constexpr int64_t kSplitKMaxSlices = 32;
// Smallest contraction extent one slice may carry. Measured at its boundary
// on 2026-09-27: K=256 split into 128-wide slices LOSES at every S (0.89-0.92x,
// f16 and bf16), K=512 into two 256-wide slices gains 1.16-1.18x. Slices
// narrower than 256 were positive at larger K (e.g. 64x64x1024 at S=16), so the
// guard is conservative there; it is kept rather than generalized from two
// small-K shapes. Mirrors `rocm_tiling.SPLIT_K_MIN_SLICE_K`.
constexpr int64_t kSplitKMinSliceK = 256;

static void selectGfx1201SplitK(MatmulSchedule &schedule) {
  // Only a static, K-blocked schedule has slice boundaries to align to: a
  // split partitions the macro K tile (ROCM-MACRO-K-TILE-1), and without one
  // there is nothing to partition.
  if (schedule.dynamicM || schedule.dynamicN || schedule.dynamicK ||
      schedule.blockK <= 0 || schedule.macroTileM <= 0 ||
      schedule.macroTileN <= 0)
    return;
  const int64_t tiles =
      ((schedule.m + schedule.macroTileM - 1) / schedule.macroTileM) *
      ((schedule.n + schedule.macroTileN - 1) / schedule.macroTileN);
  // An empty output has nothing to split (and must not divide by zero).
  if (tiles <= 0)
    return;
  // The most slices the workgroup target allows (at least two, or no split
  // is on offer), capped at the largest measured count.
  const int64_t wanted =
      std::min(kSplitKMaxSlices, kGfx1201SplitKTargetWorkgroups / tiles);
  if (wanted < 2)
    return;
  // A power of two, and only as far as every slice stays a whole number of
  // macro K blocks of at least kSplitKMinSliceK. Divisibility is monotone in
  // S, so the first failure ends the search.
  int64_t chosen = 1;
  for (int64_t slices = 2; slices <= wanted; slices *= 2) {
    if (schedule.k % (slices * schedule.blockK) != 0 ||
        schedule.k / slices < kSplitKMinSliceK)
      break;
    chosen = slices;
  }
  // K below two minimum slices is outside the rule's domain (every 16x256x256
  // decode GEMM lands here): no split was ever on offer, so there is no
  // fallback to report. The warning is kept for the case it exists for -- a K
  // large enough to split whose extent does not divide into whole blocks.
  if (chosen == 1 && schedule.k < 2 * kSplitKMinSliceK)
    return;
  if (chosen == 1) {
    schedule.splitKFallback =
        (Twine(tiles) + " output tiles under the " +
         Twine(kGfx1201SplitKTargetWorkgroups) +
         "-workgroup split-K target ask for split-K, but K=" +
         Twine(schedule.k) +
         " has no 2-way split into whole macro K blocks (block_k=" +
         Twine(schedule.blockK) + ") of at least " + Twine(kSplitKMinSliceK))
            .str();
    return;
  }
  schedule.splitK = chosen;
  schedule.splitKReduction = "ordered";
}

// ── ROCM-FP8-BLOCKSCALE-1: the logical W8A8 block-scale contract ─────────
//
// `tessera.scaled_matmul` with e4m3 A [M,K] and B [K,N] and fp32 scales binds
// to one physical contract on gfx1201: operands stay e4m3 into
// V_WMMA_F32_16X16X16_FP8_FP8, every K group of `scale_k` starts an fp32
// partial from zero, and that partial is multiplied by
// `lhs_scale[m, g] * rhs_scale[g, n / scale_n]` before it joins the running
// accumulator. `scale_layout.block = [scale_n, scale_k]` is the weight block
// (the DeepSeek/AITER `block_shape` convention, [128, 128] in the tuned
// configs); the activation scale is per token per K group. Every extent is
// checked here, where the tensor types still exist -- below Schedule the
// scales are raw pointers and nothing could catch a wrong block count.
constexpr StringLiteral kFp8W8A8BlockScaleContract =
    "rocm_fp8_w8a8_blockscale_v1";
constexpr StringLiteral kFp8W8A8BlockScaleNKContract =
    "rocm_fp8_w8a8_blockscale_nk_v1";
constexpr StringLiteral kFp8W8A8BlockScaleFormat = "fp32";
constexpr StringLiteral kMxfp8BlockScaleContract =
    "rocm_mxfp8_e4m3_e8m0_k32_v1";
constexpr StringLiteral kMxfp8BlockScaleNKContract =
    "rocm_mxfp8_e4m3_e8m0_k32_nk_v1";


static LogicalResult deriveFp8W8A8BlockScale(Operation *op,
                                             MatmulSchedule &schedule,
                                             RankedTensorType lhs,
                                             RankedTensorType rhs,
                                             RankedTensorType out,
                                             bool transposedB) {
  const bool e8m0 = schedule.scaleFormat == "e8m0";
  auto refuse = [&](const Twine &why) {
    op->emitError("ROCM_FP8_BLOCKSCALE_CONTRACT: ") << why;
    return failure();
  };
  if (!isa<Float8E4M3FNType>(lhs.getElementType()) ||
      !isa<Float8E4M3FNType>(rhs.getElementType()))
    return refuse("the W8A8 block-scale contract binds e4m3 x e4m3 only");
  // The accumulator is always fp32 (numeric_policy.accum); the OUTPUT storage
  // is the Graph result's element type -- fp32, or bf16 rounded once at the
  // store (GFX1201-PERF-2026-09-27). Anything else has no store epilogue.
  if (!out.getElementType().isF32() && !out.getElementType().isBF16())
    return refuse("the W8A8 block-scale contract stores its fp32 accumulator "
                  "as f32 or rounds it once to bf16");
  if (schedule.dynamicM || schedule.dynamicN || schedule.dynamicK)
    return refuse("the W8A8 block-scale contract requires static M, N and K");
  const int64_t groupK = schedule.scaleBlockK;
  if (groupK <= 0 || (e8m0 && groupK != 32))
    return refuse("E8M0 microscaling requires positive K32 scale groups");
  if (groupK % schedule.tileK != 0)
    return refuse(Twine("scale_k=") + Twine(groupK) +
                  " is not a whole number of 16-wide WMMA K steps");
  auto batchPolicy = op->getAttrOfType<StringAttr>("batching");
  const bool independent = (batchPolicy && batchPolicy.getValue() == "broadcast") ||
      tessera::needsScalarScaledPlane(op);
  if (schedule.k % groupK != 0 && (!independent || schedule.k > INT64_MAX - groupK + 1))
    return refuse(Twine("K=") + Twine(schedule.k) +
                  " is not a whole number of scale groups of " +
                  Twine(groupK) +
                  "; a partial trailing group has no defined scale");
  auto layout = op->getAttrOfType<DictionaryAttr>("scale_layout");
  auto block = layout ? layout.getAs<ArrayAttr>("block") : ArrayAttr();
  auto granularity =
      layout ? layout.getAs<StringAttr>("granularity") : StringAttr();
  auto blockN = block && block.size() == 2
                    ? dyn_cast<IntegerAttr>(block[0])
                    : IntegerAttr();
  if (!granularity || granularity.getValue() != "block" || !blockN ||
      blockN.getInt() <= 0 || (e8m0 && blockN.getInt() != 1))
    return refuse("scale_layout must be granularity=\"block\" with a "
                  "positive block = [scale_n, scale_k]");
  const int64_t groups = (schedule.k - 1) / groupK + 1;
  const int64_t nGroups = (schedule.n + blockN.getInt() - 1) / blockN.getInt();
  auto lhsScale = dyn_cast<RankedTensorType>(op->getOperand(2).getType());
  auto rhsScale = dyn_cast<RankedTensorType>(op->getOperand(3).getType());
  auto batch = op->getAttrOfType<StringAttr>("batching");
  if (batch && batch.getValue() == "broadcast") {
    if (!lhsScale || !rhsScale || !lhsScale.hasStaticShape() ||
        !rhsScale.hasStaticShape() || lhsScale.getRank() < 2 || rhsScale.getRank() < 2)
      return refuse("independent scales require static matrix suffixes");
    lhsScale = RankedTensorType::get(lhsScale.getShape().take_back(2), lhsScale.getElementType());
    rhsScale = RankedTensorType::get(rhsScale.getShape().take_back(2), rhsScale.getElementType());
  }
  if (batch && (batch.getValue() == "shared_rhs_rows" ||
                batch.getValue() == "independent_rhs")) {
    if (!lhsScale || lhsScale.getRank() < 3 || !lhsScale.hasStaticShape())
      return refuse("batched lhs_scale requires static leading batch storage");
    int64_t rows = 1;
    for (int64_t extent : lhsScale.getShape().drop_back()) {
      if (extent <= 0 || rows > INT64_MAX / extent)
        return refuse("batched lhs_scale extents overflow");
      rows *= extent;
    }
    if (batch.getValue() == "independent_rhs")
      rows = lhsScale.getDimSize(lhsScale.getRank() - 2);
    lhsScale = RankedTensorType::get({rows, lhsScale.getDimSize(lhsScale.getRank()-1)}, lhsScale.getElementType());
  }
  if (batch && (batch.getValue() == "independent_rhs" || batch.getValue() == "shared_lhs")) {
    if (!rhsScale || rhsScale.getRank() < 3 || !rhsScale.hasStaticShape())
      return refuse("batched rhs_scale requires static leading batch storage");
    rhsScale = RankedTensorType::get(rhsScale.getShape().take_back(2), rhsScale.getElementType());
  }
  if (!lhsScale || lhsScale.getRank() != 2 ||
      (e8m0 ? !(lhsScale.getElementType().isSignlessInteger(8) ||
                lhsScale.getElementType().isUnsignedInteger(8))
            : !lhsScale.getElementType().isF32()) ||
      lhsScale.getDimSize(0) != schedule.m ||
      lhsScale.getDimSize(1) != groups)
    return refuse(Twine("lhs_scale must use the declared fp32/E8M0 storage [M, K/scale_k] = [") +
                  Twine(schedule.m) + ", " + Twine(groups) + "]");
  if (!rhsScale || rhsScale.getRank() != 2 ||
      (e8m0 ? !(rhsScale.getElementType().isSignlessInteger(8) ||
                rhsScale.getElementType().isUnsignedInteger(8))
            : !rhsScale.getElementType().isF32()) ||
      rhsScale.getDimSize(0) != groups ||
      rhsScale.getDimSize(1) != nGroups)
    return refuse(Twine("rhs_scale must use the declared fp32/E8M0 storage [K/scale_k, ceil(N/scale_n)] "
                        "= [") +
                  Twine(groups) + ", " + Twine(nGroups) + "]");
  // `execution_mode` is a semantic key (Decision #21a): it must be STATED as
  // exact per-block scaling, never inferred from its absence -- the MX forms
  // beside this one require it the same way.
  auto policy = op->getAttrOfType<DictionaryAttr>("numeric_policy");
  auto mode = policy ? policy.getAs<StringAttr>("execution_mode") : StringAttr();
  auto accum = policy ? policy.getAs<StringAttr>("accum") : StringAttr();
  if (e8m0 && (!accum || accum.getValue() != "fp32"))
    return refuse("MXFP8 numeric_policy.accum must explicitly state fp32");
  if (!mode)
    return refuse("numeric_policy.execution_mode must state "
                  "\"exact_per_block\"; the scaling mode is never defaulted");
  if (mode.getValue() != "exact_per_block")
    return refuse(Twine("execution_mode=\"") + mode.getValue() +
                  "\" is not this contract's exact per-block scaling");
  // The weight's memory layout is part of the named contract: below
  // Schedule the operand is a raw pointer, and [K, N] and [N, K] read the
  // same bytes as different matrices.
  schedule.physicalContract =
      e8m0 ? (transposedB ? kMxfp8BlockScaleNKContract : kMxfp8BlockScaleContract)
           : (transposedB ? kFp8W8A8BlockScaleNKContract : kFp8W8A8BlockScaleContract);
  schedule.scaleBlockN = blockN.getInt();
  schedule.output = out.getElementType().isBF16() ? "bf16" : "f32";
  return success();
}

// The W8A8 register panel, selected from the gfx1201 sweep in
// `benchmarks/baselines/gfx1201_fp8_blockscale_20260927/sweep.json` (device
// clock, Tajasarus, [N, K] weight, clean commit):
//
//  * 32x32 when M and N are whole 32s AND that yields at least 256 tiles. It
//    won or came within 2% at every such shape but one (64x6144x2048 24.6 us;
//    256x4096x1024 25.3 vs 25.0 at 32x64; 1024x4096x1024 87.0; 2048^3 152.0).
//    64-wide panels lose -- 64x64 by 2-20x -- because the isolated group
//    partial doubles the live accumulators: 32x32 is 231 VGPRs unspilled,
//    64x32 256 + 54 spilled, 64x64 256 + 337.
//  * Fewer tiles than that leaves the 64 CUs short of waves, and the
//    half-height 16x32 panel doubles the grid: 32x4096x1024 13.7 vs 15.6 us
//    (128 tiles at 32x32); 64x2048x2048 16.0 vs 16.7 (16x64 15.1 was best
//    there, 6% ahead -- not worth a third branch on one shape).
//  * A ragged M under a 32-row panel sends a whole row of tiles down the
//    masked edge path, which is far slower than a narrower interior: M=48
//    took 146.1 us at 32x32 against 25.9 at 16x32; M=100 158.0 against 37.5.
//  * N that is not a whole 32 takes 16 columns for the same edge reason.
//
// Open, not taken: at 4096^3 the 64x32 panel measured 13% faster than 32x32
// (1402 vs 1618 us) and 6% slower at 2048^3. One shape is not a rule.
//
// GFX1201-PERF-2026-09-27 -- the LDS-staged multi-wave body, [N, K] weight
// only (`benchmarks/baselines/gfx1201_fp8_blockscale_lds_20260927/`,
// rule.json, ragged.json, knobs.json: device clock, paired and interleaved).
// Eight waves of 32 rows share one staged K slab of A and the weight, so each
// workgroup fetches its tile once per slab instead of once per wave. It needs
// enough workgroups to cover the RX 9070 XT's 64 CUs: 128x128 (waves 4x2,
// 32x64 each) once that tiling yields >= 64 workgroups, else 128x64 (waves
// 4x2, 32x32 each) if that does, else the register panel. Against the
// register panel it runs at 0.45-0.97x wherever the rule picks it (29
// points); the one-wave panel keeps every point below 64 workgroups, where
// the LDS body's coarser tiles leave CUs idle (N=1024, M=128: 30.6-43.7 us vs
// 20.3). At every whole-M point the rule's choice is within 1.5% of the
// fastest Tessera arm. Single-buffered: double-buffering (1.22-1.48x) and a
// register-staged next slab (1.00-1.24x) both measured slower (knobs.json).
//
// FOUNDATION-BATCH-2-2026-09-27: the CU count is not this rule's to state.
// It comes from one table, `measuredComputeUnits`, which mirrors
// `rocm_target.compute_units` (Python, derived from the measured
// `_DISPATCH_SLOTS` WGP counts); `tests/unit/test_rocm_fp8_blockscale.py`
// fails when the two disagree, and `rocm_fp8_blockscale.lower_blockscale`
// refuses a Schedule whose selection differs from the Python oracle of this
// rule. A part with no measured count keeps the register panel and says so
// (ROCM_FP8_BLOCKSCALE_LDS_NOT_APPLIED): a guessed denominator would turn an
// occupancy rule into a silent wrong answer.
static std::optional<int64_t> measuredComputeUnits(StringRef arch) {
  // Read from the GPU agent's `Compute Unit:` in rocminfo on the box that
  // has the part (2026-09-20); see `rocm_target._DISPATCH_SLOTS`.
  if (arch == "gfx1201")
    return 64; // RX 9070 XT, Tajasarus: 32 WGPs
  if (arch == "gfx1151")
    return 40; // Radeon 8060S, Princess-Luna: 20 WGPs
  return std::nullopt;
}

static void selectFp8W8A8BlockScalePanel(MatmulSchedule &schedule) {
  std::optional<int64_t> computeUnits = measuredComputeUnits(schedule.arch);
  auto tiles = [&](int64_t tm, int64_t tn) {
    return ((schedule.m + tm - 1) / tm) * ((schedule.n + tn - 1) / tn);
  };
  const bool nk =
      schedule.physicalContract == "rocm_fp8_w8a8_blockscale_nk_v1";
  // At least one whole 128-row block: below it the workgroup computes rows
  // that do not exist (M=32 would waste three quarters of every tile).
  //
  // A ragged M (not a whole number of 128-row blocks) follows the same rule
  // as a whole one (FOUNDATION-BATCH-2-2026-09-27,
  // benchmarks/baselines/gfx1201_fp8_blockscale_ragged_20260927/). It took
  // 128x64 until the bounded store stopped costing registers: the masked
  // edge had kept the 32x64-wave 128x128 body at 251 VGPRs against 238
  // whole (a wave per SIMD fewer), and a ragged M ran up to 25% behind its
  // whole-M neighbour on the same grid. With the bounded store testing each
  // row per lane (TileToROCM; 240 VGPRs, no spills), 128x128 measured
  // 0.83-1.08x of 128x64 where this changes the selection, geomean 0.90 over
  // 24 ragged points; it loses at 200x8192x1024 (1.08x) and 600x8192x1024
  // (1.01x) -- recorded, not tuned around.
  if (nk && schedule.m >= 128 && !computeUnits)
    schedule.panelFallback =
        (Twine("no measured compute-unit count for arch \"") + schedule.arch +
         "\", so the LDS-staged W8A8 body's occupancy rule cannot be "
         "evaluated")
            .str();
  // ROCM-FP8-BLOCKSCALE-1, gfx1201 ragged 97..127-row follow-up: the
  // register fallback uses a 16-row panel because M is not 32-aligned. On
  // Tajasarus it took 2.4-3.4x the time of the 128x64 LDS body across the
  // measured N=1024..24576, K=1024..4096 envelope. M=96 (the 32-row
  // register panel) and M=128 (the existing LDS rule) are faster unchanged.
  // Keep this exact-device rule bounded to the measured layout and ranges.
  if (nk && schedule.arch == "gfx1201" && computeUnits &&
      schedule.m > 96 && schedule.m < 128 && schedule.n >= 1024 &&
      schedule.k >= 1024 && schedule.k <= 4096) {
    schedule.staging = "lds";
    schedule.warps = 8;
    schedule.pipelineDepth = 1;
    schedule.macroTileM = 128;
    schedule.macroTileN = 64;
    return;
  }
  // Paired Tajasarus device-clock sweeps at K=1024: 128x64 wins over
  // 128x128 throughout M=192..255, N=8192..10240 (roughly 7-10% at the
  // tested corners). Interior whole-scale-block N points also win, while
  // N=4096/6144, K=1536/2048 and M=300 do not sustain that win. Keep the
  // selector inside the measured short-K, whole-128-column envelope.
  if (nk && schedule.arch == "gfx1201" && computeUnits &&
      schedule.m >= 192 && schedule.m < 256 &&
      schedule.n >= 8192 && schedule.n <= 10240 &&
      schedule.n % 128 == 0 && schedule.k == 1024) {
    schedule.staging = "lds";
    schedule.warps = 8;
    schedule.pipelineDepth = 1;
    schedule.macroTileM = 128;
    schedule.macroTileN = 64;
    return;
  }
  if (nk && schedule.m >= 128 && computeUnits &&
      (tiles(128, 128) >= *computeUnits || tiles(128, 64) >= *computeUnits)) {
    const bool wide = tiles(128, 128) >= *computeUnits;
    schedule.staging = "lds";
    schedule.warps = 8;
    schedule.pipelineDepth = 1;
    schedule.macroTileM = 128;
    schedule.macroTileN = wide ? 128 : 64;
    return;
  }
  constexpr int64_t kMinFullPanelTiles = 256;
  const bool full = schedule.m % 32 == 0 && schedule.n % 32 == 0 &&
                    (schedule.m / 32) * (schedule.n / 32) >= kMinFullPanelTiles;
  schedule.macroTileM = full ? 32 : 16;
  schedule.macroTileN = schedule.n % 32 == 0 ? 32 : 16;
}

//: The schedule as INFERRED from operand/result element types per target.
//: Wrapped below so the declared policy is checked on every exit path.
static FailureOr<MatmulSchedule> getInferredMatmulSchedule(Operation *op) {
  ModuleOp module = op->getParentOfType<ModuleOp>();
  const bool scaledMatmul =
      op->getName().getStringRef() == "tessera.scaled_matmul";
  if (!module || op->getNumOperands() < 2 || op->getNumOperands() > 4 ||
      op->getNumResults() != 1)
    return failure();
  auto lhs = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto rhs = dyn_cast<RankedTensorType>(op->getOperand(1).getType());
  auto out = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  auto batchAttr = op->getAttrOfType<StringAttr>("batching");
  auto batchPhysical = op->getAttrOfType<StringAttr>("physical_contract");
  const bool independentRhs = batchAttr && batchAttr.getValue() == "independent_rhs";
  const bool sharedLhs = batchAttr && batchAttr.getValue() == "shared_lhs";
  const bool rhsBatched = independentRhs || sharedLhs;
  const bool sharedRhsBatch = scaledMatmul && batchAttr &&
      (batchAttr.getValue() == "shared_rhs_rows" || rhsBatched) && batchPhysical &&
      batchPhysical.getValue() == "nvidia_sm120_nvfp4_blockscale_v1";
  const bool typedSharedRows = scaledMatmul && batchAttr &&
      (batchAttr.getValue() == "shared_rhs_rows" || rhsBatched) && !batchPhysical &&
      lhs && isa<Float8E4M3FNType>(lhs.getElementType());
  const bool flattenSharedRows = sharedRhsBatch || typedSharedRows;
  const bool lhsBatched = flattenSharedRows && !sharedLhs;
  auto flag = [&](StringRef name) {
    auto value = op->getAttrOfType<BoolAttr>(name);
    return value && value.getValue();
  };
  const bool nvfp4Contract = scaledMatmul && batchPhysical &&
      batchPhysical.getValue() == "nvidia_sm120_nvfp4_blockscale_v1";
  const bool nvfp4TransposeA = nvfp4Contract && flag("transposeA");
  const bool nvfp4TransposeB = nvfp4Contract && flag("transposeB");
  const bool broadcast = (scaledMatmul && batchAttr &&
      batchAttr.getValue() == "broadcast" && !batchPhysical) ||
      tessera::needsScalarScaledPlane(op);
  SmallVector<RankedTensorType> broadcastTypes;
  RankedTensorType broadcastResult;
  int64_t batchCount = 1, batchRows = 0;
  SmallVector<int64_t> logicalBatchPrefix;
  if (broadcast) {
    for (Value input : op->getOperands())
      broadcastTypes.push_back(dyn_cast<RankedTensorType>(input.getType()));
    if (broadcastTypes.size() != 4 ||
        !tessera::hasExactScaledBroadcastPrefix(broadcastTypes, out))
      return failure();
    broadcastResult = out;
    for (int64_t extent : out.getShape().drop_back(2)) {
      if (batchCount > INT32_MAX / extent) return failure();
      batchCount *= extent;
    }
    batchRows = out.getDimSize(out.getRank() - 2);
    lhs = RankedTensorType::get(lhs.getShape().take_back(2), lhs.getElementType());
    rhs = RankedTensorType::get(rhs.getShape().take_back(2), rhs.getElementType());
    out = RankedTensorType::get(out.getShape().take_back(2), out.getElementType());
  }
  if (flattenSharedRows) {
    int64_t batchRank = out ? out.getRank() - 2 : 0;
    if (!lhs || !rhs || !out || batchRank < 1 ||
        lhs.getRank() != (lhsBatched ? batchRank + 2 : 2) ||
        rhs.getRank() != (rhsBatched ? batchRank + 2 : 2) ||
        !lhs.hasStaticShape() || !rhs.hasStaticShape() || !out.hasStaticShape())
      return failure();
    logicalBatchPrefix.assign(out.getShape().begin(),out.getShape().end()-2);
    batchCount = 1;
    for (int64_t extent : logicalBatchPrefix) {
      if (extent <= 0 || batchCount > INT64_MAX / extent) return failure();
      batchCount *= extent;
    }
    batchRows = lhs.getDimSize((lhsBatched ? batchRank : 0) + (nvfp4TransposeA ? 1 : 0));
    if (batchCount <= 0 || batchRows <= 0 || batchCount > INT64_MAX / batchRows ||
        out.getDimSize(out.getRank() - 2) != batchRows)
      return failure();
    if (rhsBatched) {
      if (rhs.getShape().drop_back(2) != out.getShape().drop_back(2)) return failure();
      rhs = RankedTensorType::get(rhs.getShape().take_back(2), rhs.getElementType());
    }
    // The Schedule counts batch*row launch work while Graph keeps logical ranks.
    // Shared-LHS scheduling synthesizes this row extent only for geometry;
    // target lowering reuses the original rank-two A/scales without replication.
    int64_t batchK = lhs.getDimSize((lhsBatched ? batchRank : 0) + (nvfp4TransposeA ? 0 : 1));
    int64_t physicalRows = typedSharedRows && rhsBatched ? batchRows : batchCount * batchRows;
    SmallVector<int64_t> flattenedShape = nvfp4TransposeA
        ? SmallVector<int64_t>{batchK, physicalRows}
        : SmallVector<int64_t>{physicalRows, batchK};
    lhs = RankedTensorType::get(flattenedShape, lhs.getElementType());
    out = RankedTensorType::get({physicalRows, out.getDimSize(out.getRank() - 1)}, out.getElementType());
  }
  if (!lhs || !rhs || !out || lhs.getRank() != 2 || rhs.getRank() != 2 ||
      out.getRank() != 2)
    return failure();
  if (auto transpose = op->getAttrOfType<BoolAttr>("transposeA");
      transpose && transpose.getValue() && !nvfp4TransposeA && !broadcast)
    return failure();
  // ROCM-FP8-BLOCKSCALE-1: a block-scaled matmul may state its weight as
  // [N, K] (`transposeB`), the layout every W8A8 checkpoint ships and the one
  // whose K is contiguous. Only the W8A8 derivation below admits it; every
  // other form still refuses a transpose.
  bool transposedB = false;
  if (auto transpose = op->getAttrOfType<BoolAttr>("transposeB");
      transpose && transpose.getValue()) {
    if (!nvfp4TransposeB) {
      if (!scaledMatmul || op->getAttrOfType<StringAttr>("physical_contract"))
        return failure();
      transposedB = true;
    }
  }

  MatmulSchedule schedule;
  schedule.typedTransposeA = broadcast && flag("transposeA");
  schedule.broadcastTypes = broadcastTypes;
  schedule.broadcastResult = broadcastResult;
  if (broadcast) {
    schedule.independentBatchRows = batchRows;
    schedule.independentBatchCount = batchCount;
  }
  schedule.nvfp4TransposeA = nvfp4TransposeA;
  schedule.nvfp4TransposeB = nvfp4TransposeB;
  if (rhsBatched || (sharedRhsBatch && nvfp4TransposeA)) {
    schedule.sharedBatchRhs = !rhsBatched;
    schedule.sharedBatchLhs = sharedLhs;
    schedule.independentBatchRows = batchRows;
    schedule.independentBatchCount = batchCount;
  }
  if (auto physical = op->getAttrOfType<StringAttr>("physical_contract")) {
    if (!physical.getValue().empty() &&
        (!scaledMatmul || op->getNumOperands() != 4)) {
      op->emitError("named scaled physical contracts require four-operand tessera.scaled_matmul");
      return failure();
    }
    schedule.physicalContract = physical.getValue();
  }
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  // The module retains its exact frontend target. Matmul schedules use the
  // ROCm family internally only after the explicit chip agrees.
  if (schedule.target == "rocm_gfx1201") {
    if (schedule.arch != "gfx1201")
      return failure();
    schedule.target = "rocm";
  }
  bool nvidia_sm120 = schedule.target == "nvidia_sm120" &&
                      (schedule.arch.empty() || schedule.arch.contains("sm_120"));
  bool rocm_gfx1151 =
      (schedule.target == "rocm" || schedule.target == "rocm_gfx1151") &&
      (schedule.arch.empty() || schedule.arch.contains("gfx1151"));
  bool rocm_gfx1201 = schedule.target == "rocm" && schedule.arch == "gfx1201";
  if (broadcast && !rocm_gfx1201) return failure();
  SmallVector<int64_t> bounds;
  if (auto attr = op->getAttrOfType<ArrayAttr>("shape_bounds")) {
    for (Attribute value : attr) {
      auto integer = dyn_cast<IntegerAttr>(value);
      if (!integer)
        return failure();
      bounds.push_back(integer.getInt());
    }
  }
  auto bounded = [&](int64_t extent, unsigned boundIndex,
                     bool &dynamic) -> FailureOr<int64_t> {
    dynamic = ShapedType::isDynamic(extent);
    if (!dynamic)
      return extent;
    if ((!nvidia_sm120 && !rocm_gfx1151 && !rocm_gfx1201) || bounds.size() != 3 ||
        bounds[boundIndex] <= 0)
      return failure();
    return bounds[boundIndex];
  };
  auto m = bounded(lhs.getDimSize((nvfp4TransposeA || schedule.typedTransposeA) ? 1 : 0), 0, schedule.dynamicM);
  auto n = bounded(rhs.getDimSize(nvfp4TransposeB ? 0 : 1), 1, schedule.dynamicN);
  auto k = bounded(lhs.getDimSize((nvfp4TransposeA || schedule.typedTransposeA) ? 0 : 1), 2, schedule.dynamicK);
  if (failed(m) || failed(n) || failed(k))
    return failure();
  schedule.m = *m;
  schedule.n = *n;
  schedule.k = *k;
  auto compatible = [](int64_t extent, int64_t expected) {
    return ShapedType::isDynamic(extent) || extent == expected;
  };
  const bool nvidiaNvfp4 =
      schedule.physicalContract == "nvidia_sm120_nvfp4_blockscale_v1";
  const bool packedMxfp4 =
      schedule.physicalContract == "rocm_mxfp4_w4a8_exact_v1";
  const bool foldedMxfp4 =
      schedule.physicalContract == "rocm_mxfp4_w4a8_folded_prefill_v1" ||
      schedule.physicalContract == "rocm_mxfp4_w4a8_folded_row_pitched_v1";
  const bool packedFoldedMxfp4 =
      schedule.physicalContract == "rocm_mxfp4_w4a8_packed_folded_prefill_v1";
  const bool foldedFamily = foldedMxfp4 || packedFoldedMxfp4;
  if (schedule.physicalContract == "rocm_mxfp4_w4a8_folded_row_pitched_v1") {
    auto a = foldedInputStorage(op->getOperand(0));
    auto b = foldedInputStorage(op->getOperand(1));
    if (failed(a) || failed(b))
      return failure();
    schedule.aRowStride = a->second;
    schedule.bRowStride = b->second;
  }
  if (foldedFamily || transposedB) {
    n = bounded(rhs.getDimSize(0), 1, schedule.dynamicN);
    if (failed(n))
      return failure();
    schedule.n = *n;
  }
  const bool rhsKCompatible =
      packedMxfp4
          ? compatible(rhs.getDimSize(0), (schedule.k + 1) / 2)
          : compatible(rhs.getDimSize(foldedFamily || transposedB || nvfp4TransposeB ? 1 : 0),
                       packedFoldedMxfp4 ? schedule.k / 2 : schedule.k);
  if (schedule.m <= 0 || schedule.n <= 0 || schedule.k <= 0 ||
      !rhsKCompatible ||
      !compatible(out.getDimSize(0), schedule.m) ||
      !compatible(out.getDimSize(1), schedule.n))
    return failure();

  Type lhsElement = lhs.getElementType();
  Type rhsElement = rhs.getElementType();
  Type outElement = out.getElementType();
  // A transposed weight has a bound layout only under the W8A8 contract. Any
  // other storage would fall into a branch that knows nothing of the
  // transpose and would read [N, K] bytes as [K, N] -- refuse it here.
  if (transposedB && !(isa<Float8E4M3FNType>(lhsElement) &&
                       isa<Float8E4M3FNType>(rhsElement)))
    return failure();
  schedule.bias = bool(op->getAttrOfType<StringAttr>("bias"));
  schedule.residual = bool(op->getAttrOfType<StringAttr>("residual"));
  if (auto activation = op->getAttrOfType<StringAttr>("activation"))
    schedule.activation = activation.getValue();
  if (!llvm::is_contained({"none", "relu", "gelu", "silu"},
                          schedule.activation))
    return failure();
  if ((!scaledMatmul && op->getNumOperands() !=
                           static_cast<unsigned>(2 + schedule.bias +
                                                 schedule.residual)) ||
      (scaledMatmul && (op->getNumOperands() != 4 || schedule.bias ||
                        schedule.residual || schedule.activation != "none")))
    return failure();
  unsigned epilogueOperand = 2;
  if (schedule.bias) {
    auto bias = dyn_cast<RankedTensorType>(
        op->getOperand(epilogueOperand++).getType());
    if (!bias || bias.getRank() != 1 || !bias.getElementType().isF32() ||
        !compatible(bias.getDimSize(0), schedule.n))
      return failure();
  }
  if (schedule.residual) {
    auto residual = dyn_cast<RankedTensorType>(
        op->getOperand(epilogueOperand).getType());
    if (!residual || residual.getRank() != 2 ||
        !residual.getElementType().isF32() ||
        !compatible(residual.getDimSize(0), schedule.m) ||
        !compatible(residual.getDimSize(1), schedule.n))
      return failure();
  }
  if (scaledMatmul) {
    auto layout = op->getAttrOfType<DictionaryAttr>("scale_layout");
    auto granularity = layout ? layout.getAs<StringAttr>("granularity")
                              : StringAttr();
    auto block = layout ? layout.getAs<ArrayAttr>("block") : ArrayAttr();
    auto format = layout ? layout.getAs<StringAttr>("format") : StringAttr();
    if (!block || block.size() != 2 || !format ||
        (nvidiaNvfp4 && (layout.size() != 3 || !granularity ||
                         granularity.getValue() != "block")))
      return failure();
    auto blockK = dyn_cast<IntegerAttr>(block[1]);
    if (!blockK || blockK.getInt() <= 0)
      return failure();
    schedule.scaleBlockK = blockK.getInt();
    schedule.scaleFormat = format.getValue();
  }

  if (packedMxfp4 || foldedFamily) {
    auto lhsScale = dyn_cast<RankedTensorType>(op->getOperand(2).getType());
    auto rhsScale = dyn_cast<RankedTensorType>(op->getOperand(3).getType());
    auto policy = op->getAttrOfType<DictionaryAttr>("numeric_policy");
    auto mode = policy ? policy.getAs<StringAttr>("execution_mode") : StringAttr();
    if (schedule.target != "rocm" || schedule.arch != "gfx1201" ||
        schedule.dynamicM || schedule.dynamicN || schedule.dynamicK ||
        !lhsElement.isUnsignedInteger(8) ||
        !rhsElement.isUnsignedInteger(8) || !outElement.isBF16() ||
        !lhsScale || lhsScale.getRank() != 1 ||
        !lhsScale.getElementType().isF32() ||
        lhsScale.getDimSize(0) != schedule.m || !rhsScale ||
        rhsScale.getRank() != (foldedMxfp4 ? 1 : 2) ||
        !rhsScale.getElementType().isUnsignedInteger(8) ||
        (foldedFamily
             ? (foldedMxfp4
                    ? rhsScale.getDimSize(0) != schedule.n
                    : rhsScale.getDimSize(0) != schedule.k / 32 + 1 ||
                          rhsScale.getDimSize(1) != schedule.n) ||
                   schedule.k % 64 != 0 || schedule.m <= 0 ||
                   (!packedFoldedMxfp4 && schedule.m <= 64) ||
                   schedule.scaleBlockK != schedule.k ||
                   schedule.scaleFormat !=
                       (packedFoldedMxfp4 ? "e8m0_k32_plus_row_reference"
                                          : "e8m0_row_reference") ||
                   !mode || mode.getValue() !=
                                "folded_row_reference_explicit_approximate"
             : rhsScale.getDimSize(0) != schedule.k / 32 ||
                   rhsScale.getDimSize(1) != schedule.n ||
                   schedule.k % 32 != 0 || schedule.scaleBlockK != 32 ||
                   schedule.scaleFormat != "e8m0" || !mode ||
                   mode.getValue() != "exact_per_block"))
      return failure();
  } else if (nvidiaNvfp4) {
    auto lhsScale = dyn_cast<RankedTensorType>(op->getOperand(2).getType());
    auto rhsScale = dyn_cast<RankedTensorType>(op->getOperand(3).getType());
    auto lhsNvfp4 = dyn_cast<Nvfp4Type>(lhsElement);
    auto rhsNvfp4 = dyn_cast<Nvfp4Type>(rhsElement);
    auto policy = op->getAttrOfType<DictionaryAttr>("numeric_policy");
    auto accum = policy ? policy.getAs<StringAttr>("accum") : StringAttr();
    auto mode = policy ? policy.getAs<StringAttr>("execution_mode") : StringAttr();
    if (!nvidia_sm120 || schedule.dynamicM || schedule.dynamicN ||
        schedule.dynamicK || !lhsNvfp4 || !rhsNvfp4 || !outElement.isF32() ||
        !lhsScale || lhsScale.getRank() != (lhsBatched ? int64_t(logicalBatchPrefix.size()) + 2 : 2) ||
        !(lhsScale.getElementType().isUnsignedInteger(8) ||
          lhsScale.getElementType().isSignlessInteger(8)) ||
        (lhsBatched && lhsScale.getShape().drop_back(2) != ArrayRef<int64_t>(logicalBatchPrefix)) ||
        lhsScale.getDimSize((lhsBatched ? logicalBatchPrefix.size() : 0) + (nvfp4TransposeA ? 1 : 0)) != (sharedRhsBatch ? batchRows : schedule.m) ||
        lhsScale.getDimSize((lhsBatched ? logicalBatchPrefix.size() : 0) + (nvfp4TransposeA ? 0 : 1)) != (schedule.k / 16 + (schedule.k % 16 != 0)) ||
        !rhsScale || rhsScale.getRank() != (rhsBatched ? int64_t(logicalBatchPrefix.size()) + 2 : 2) ||
        !(rhsScale.getElementType().isUnsignedInteger(8) ||
          rhsScale.getElementType().isSignlessInteger(8)) ||
        (rhsBatched && rhsScale.getShape().drop_back(2) != ArrayRef<int64_t>(logicalBatchPrefix)) ||
        rhsScale.getDimSize((rhsBatched ? logicalBatchPrefix.size() : 0) + (nvfp4TransposeB ? 1 : 0)) != (schedule.k / 16 + (schedule.k % 16 != 0)) ||
        rhsScale.getDimSize((rhsBatched ? logicalBatchPrefix.size() : 0) + (nvfp4TransposeB ? 0 : 1)) != schedule.n ||
        schedule.scaleBlockK != 16 || schedule.scaleFormat != "ue4m3" ||
        !policy || policy.size() != 2 ||
        !accum || accum.getValue() != "fp32" || !mode ||
        mode.getValue() != "exact_per_block" ||
        schedule.bias || schedule.residual || schedule.activation != "none")
      return failure();
  } else if (!schedule.physicalContract.empty()) {
    return failure();
  }
  bool x86 = schedule.target == "x86" || schedule.arch.contains("avx512") ||
             schedule.arch.contains("zen5");
  // This bounded physical schedule is gfx1151-owned.  The shared macro-tile
  // vocabulary is portable, but gfx1200/gfx1250 must supply their own exact-
  // device schedule and instruction-family profile rather than inheriting it.
  bool rocm = schedule.arch.contains("gfx1151");
  // The fused bias/activation epilogue is admitted on both ROCm chips since
  // 2026-09-17 (GFX1201-PARITY slice 1): Schedule->Tile carries it onto
  // tile.matmul_kernel and the typed Tile->ROCm consumer applies it at the
  // fragment store on each chip's own layout. The residual add stays
  // NVIDIA-owned.
  const bool rocmFusedEpilogue =
      (schedule.arch.contains("gfx1151") || schedule.arch.contains("gfx1201")) &&
      !schedule.residual;
  if ((schedule.bias || schedule.residual || schedule.activation != "none") &&
      !nvidia_sm120 && !rocmFusedEpilogue)
    return failure();
  // Apple GPU has no rank-2 f32 cooperative-matrix GEMM: the shared launch
  // contract is consumed as a batch-1 MPS BMM (apple_gpu_bmm_f32_batch1).  The
  // macro-tile below is a logical default only; the MPS route owns its own
  // tiling, which the Apple package records as an explicit dropped decision.
  bool apple_gpu = schedule.target == "apple_gpu";
  if (x86 && ((lhsElement.isF32() && rhsElement.isF32()) ||
              (lhsElement.isBF16() && rhsElement.isBF16())) && outElement.isF32()) {
    schedule.storage = lhsElement.isBF16() ? "bf16" : "f32";
    schedule.accum = "f32";
    if (schedule.arch.empty())
      schedule.arch = "x86-avx512";
    return schedule;
  }
  if (x86 && lhsElement.isF64() && rhsElement.isF64() && outElement.isF64()) {
    schedule.storage = "f64";
    schedule.accum = "f64";
    schedule.output = "f64";
    if (schedule.arch.empty())
      schedule.arch = "x86-avx512";
    return schedule;
  }
  // A mixed signedness recipe is not a new storage dtype. The builtin
  // tensor element types retain unsigned A and signed/signless B explicitly.
  if (x86 && lhsElement.isUnsignedInteger(8) &&
      (rhsElement.isSignlessInteger(8) || rhsElement.isSignedInteger(8)) &&
      outElement.isSignlessInteger(32)) {
    if (std::max({schedule.m, schedule.n, schedule.k}) > INT32_MAX)
      return failure(); // The VNNI runtime ABI uses signed 32-bit extents.
    schedule.storage = "u8";
    schedule.accum = "i32";
    schedule.output = "i32";
    if (schedule.arch.empty())
      schedule.arch = "x86-avx512";
    return schedule;
  }
  if (apple_gpu && lhsElement.isF32() && rhsElement.isF32() &&
      outElement.isF32()) {
    schedule.storage = "f32";
    schedule.accum = "f32";
    if (schedule.arch.empty())
      schedule.arch = "apple7";
    return schedule;
  }
  if (apple_gpu && lhsElement.isF16() && rhsElement.isF16() &&
      outElement.isF32()) {
    // Apple7+ simdgroup_matrix GEMM: f16 storage, f32 accumulation.  Unlike the
    // f32 batch-1 BMM above, this is compiler-emitted MSL with a device timer,
    // so its promotion is not gated by APPLE-DEVICE-EVENT-1.  The 32x32
    // macro-tile mirrors the proven APPLE-TILE-1 emitter default (a multiple of
    // the 8x8x8 simdgroup fragment); the MSL materializer owns the byte layout.
    schedule.storage = "f16";
    schedule.accum = "f32";
    schedule.macroTileM = 32;
    schedule.macroTileN = 32;
    if (schedule.arch.empty())
      schedule.arch = "apple7";
    return schedule;
  }
  const bool rocmWmmaChip = schedule.target == "rocm" &&
                            (schedule.arch.contains("gfx1151") ||
                             schedule.arch.contains("gfx1201"));
  // gfx1201's shape-selected macro tile. Derived on f16 (typed-route gap
  // packet, 2026-09-18) and, since 2026-09-19, applied to every storage the
  // chip admits: fp8 and the integer pair were left on a hardcoded 1x1 while
  // carrying 2x and 4x f16's ceiling, which measured 3.3x-4.5x slower than
  // this panel on Tajasarus. Mirrored by `scheduled_matmul.rocm_gfx1201_panel`
  // and checked against it by the artifact projection.
  const bool gfx1201StaticPanel =
      !schedule.dynamicM && !schedule.dynamicN && !schedule.dynamicK &&
      schedule.m >= 1024 && schedule.n >= 1024 && schedule.m % 64 == 0 &&
      schedule.n % 64 == 0;

  // ROCM-MACRO-K-TILE-1: the macro K tile, selected from measurement.
  //
  // `k_blocks` had been stated as 1 by every schedule while the descriptor
  // could always carry more and three consumers refused it. Measured on
  // Tajasarus 2026-09-19, register body, kUnroll=1, all arms exact
  // (integer-valued inputs make the fp16 arms exact too, so this sweep needed
  // no tolerance):
  //
  //   blockK=32 vs 16 -- fp16 1024^3 1.21x, fp16 2048^3 1.65x,
  //   fp16 256x4096x256 1.53x, int8 1024^3 1.17x, int8 2048^3 1.14x,
  //   int8 256x4096x256 1.79x. Positive at EVERY measured point.
  //
  // 64 has the higher peaks (fp16 2048^3 1.81x, int8 2048^3 1.54x, int8
  // 256x4096x256 2.56x) and LOSES at int8 1024^3 (0.85x); 128 is a reproduced
  // cliff for int8 at the skinny shape (0.37x, 2.0 TFLOP/s on both runs). So 32
  // is the only value that is a win everywhere with no cliff, and it is the
  // default until a per-shape rule has more than three shapes behind it.
  //
  // Two measurement notes kept because they would otherwise mislead: a 0.60x
  // int8 1024^3 reading at blockK=32 did NOT reproduce (1.17x over nine
  // trials) and is withdrawn; and the 256x4096x256 baseline itself moved
  // 3.3 -> 5.4 TFLOP/s between runs, because ~0.5 GFLOP of work is launch-
  // overhead dominated -- the absolutes at 64 and 128 are stable, the RATIOS at
  // that shape are not.
  //
  // Distinct from `kUnroll`, which stays a measured latency knob: this is the
  // contract a block scale must align to exactly (ROCM-FP8-BLOCKSCALE-1).
  const bool gfx1201 = schedule.arch.contains("gfx1201");
  if (gfx1201 && !schedule.dynamicK && schedule.k >= 64)
    schedule.blockK = 32;
  if (gfx1201 && scaledMatmul) {
    // A Schedule macro K may contain several complete scale groups, but it
    // may never split one. The measured unscaled default is only 32, while
    // valid Graph contracts also carry K64/K128 groups. Align the physical
    // carrier before constructing schedule.matmul; otherwise its verifier
    // correctly rejects the internally inconsistent decision we just made.
    if (schedule.scaleBlockK % schedule.tileK != 0)
      return failure();
    if (schedule.blockK == 0 ||
        schedule.blockK % schedule.scaleBlockK != 0)
      schedule.blockK = schedule.scaleBlockK;
  }
  if (packedMxfp4) {
    schedule.storage = "e4m3_raw_u8";
    schedule.storageB = "e2m1_packed_u8";
    schedule.accum = "f32";
    schedule.output = "bf16";
    schedule.tileK = 16;
    schedule.blockK = 32;
    schedule.macroTileM = 16;
    schedule.macroTileN = 16;
    return schedule;
  }
  if (foldedFamily) {
    schedule.storage = "e4m3_raw_u8";
    schedule.storageB = packedFoldedMxfp4
                            ? "e2m1_fragment_nk2_u8"
                            : "e4m3_folded_nk_u8";
    schedule.accum = "f32";
    schedule.output = "bf16";
    schedule.tileK = 16;
    // One semantic row reference covers the full K reduction. The K64 LDS
    // producer stage is a distinct physical decision in the Target directive.
    schedule.blockK = schedule.k;
    schedule.macroTileM = 256;
    schedule.macroTileN = 64;
    schedule.warps = 8;
    return schedule;
  }
  if (rocmWmmaChip && lhsElement == rhsElement &&
      (lhsElement.isInteger(8) || lhsElement.isInteger(4)) &&
      !lhsElement.isUnsignedInteger() && outElement.isInteger(32) &&
      !schedule.bias && !schedule.residual && schedule.activation == "none") {
    // Integer WMMA storage on both RDNA chips (V_WMMA_I32_16X16X16_IU8 /
    // IU4; RDNA3 ISA 7.9, RDNA4 ISA 7.12), i32 accumulate, no fused epilogue
    // (the epilogue is float-only). int4 rides int8 containers with one
    // logical value per byte, the directive lane's runtime contract.
    // gfx1151 keeps its 2x4 panel, gfx1201 its conservative 1x1
    // (GFX1201-PARITY slice 1b, 2026-09-18).
    schedule.storage = lhsElement.isInteger(8) ? "int8" : "int4";
    schedule.accum = "i32";
    schedule.output = "i32";
    const bool rdna4 = schedule.arch.contains("gfx1201");
    // gfx1151 keeps its committed 2x4 until its own sweep says otherwise;
    // evidence never transfers between the two chips.
    schedule.macroTileM = rdna4 ? (gfx1201StaticPanel ? 64 : 16) : 32;
    schedule.macroTileN = rdna4 ? (gfx1201StaticPanel ? 64 : 16) : 64;
    return schedule;
  }
  // A and B may name different FP8 storages: RDNA4 has the mixed pairs and
  // `resolveFragmentLayout` selects them from the descriptor's two types.
  if (schedule.target == "rocm" && schedule.arch == "gfx1201" &&
      isa<Float8E4M3FNType, Float8E5M2Type>(lhsElement) &&
      isa<Float8E4M3FNType, Float8E5M2Type>(rhsElement) &&
      // ROCM-FP8-BLOCKSCALE-1 may also store its fp32 accumulator as bf16
      // (GFX1201-PERF-2026-09-27); the derivation below checks the rest.
      (outElement.isF32() ||
       (outElement.isBF16() && scaledMatmul &&
        (schedule.scaleFormat == kFp8W8A8BlockScaleFormat ||
         schedule.scaleFormat == "e8m0"))) &&
      !schedule.bias && !schedule.residual && schedule.activation == "none") {
    // OCP FP8 storage on RDNA4 (V_WMMA_F32_16X16X16_{FP8,BF8}_{FP8,BF8},
    // device-audited 2026-09-13); f32 accumulate, 1x1 register tile, no fused
    // epilogue yet (GFX1201-PARITY slice 5).
    schedule.storage = isa<Float8E4M3FNType>(lhsElement) ? "e4m3" : "e5m2";
    schedule.storageB = isa<Float8E4M3FNType>(rhsElement) ? "e4m3" : "e5m2";
    schedule.accum = "f32";
    if (scaledMatmul && schedule.scaleBlockK == 0)
      return failure();
    schedule.macroTileM = gfx1201StaticPanel ? 64 : 16;
    schedule.macroTileN = gfx1201StaticPanel ? 64 : 16;
    if (transposedB && schedule.scaleFormat != kFp8W8A8BlockScaleFormat &&
        schedule.scaleFormat != "e8m0")
      return failure();
    if (scaledMatmul && (schedule.scaleFormat == kFp8W8A8BlockScaleFormat ||
                         schedule.scaleFormat == "e8m0")) {
      // ROCM-FP8-BLOCKSCALE-1: derive (Decision #30) the logical W8A8
      // block-scale contract. fp32 is the scale format this contract names,
      // so an fp32-format scaled fp8 matmul that does not conform is an
      // ERROR, never a silently unbound directive: the scale layout, dtype
      // and group are semantic keys (Decision #21a) -- a wrong one runs and
      // returns the wrong factor on every block.
      if (failed(deriveFp8W8A8BlockScale(op, schedule, lhs, rhs, out,
                                         transposedB)))
        return failure();
      // The isolated scale-group partial doubles the live accumulator
      // fragments, so the unscaled panel does not transfer; the W8A8 panel is
      // selected from its own measurement.
      if (schedule.scaleFormat == "e8m0") {
        // Numerical integration seed, not a transferred FP8 performance rule.
        // Start with one 16x16 wave and an isolated two-panel K32 partial.
        schedule.macroTileM = 16;
        schedule.macroTileN = 16;
        schedule.blockK = 32;
        schedule.warps = 1;
        schedule.staging = "global";
        // gfx1201 MXFP8 candidate: stage one complete K32 semantic group.
        // This is an architecture-owned E8M0 profile, not admission of the
        // measured fp32-scale selector. Exact-device A/B retains K>=1024:
        // wider rows gain 2-3x while K128 loses about 8%. Smaller grids and
        // unmeasured K256/K512 retain the one-wave seed. The image's checked
        // runtime-K contract still admits every positive whole K32 group.
        auto units = measuredComputeUnits(schedule.arch);
        auto tiles = [&](int64_t tm, int64_t tn) {
          return ((schedule.m + tm - 1) / tm) *
                 ((schedule.n + tn - 1) / tn);
        };
        auto module = op->getParentOfType<ModuleOp>();
        auto rawPolicy = module->getAttr("tessera.rocm.mxfp8_schedule");
        if (rawPolicy && !isa<StringAttr>(rawPolicy)) {
          op->emitError("ROCM_FP8_BLOCKSCALE_CONTRACT: MXFP8 schedule policy "
                        "must be a string auto, seed, lds, or lds_k64");
          return failure();
        }
        auto policy = dyn_cast_or_null<StringAttr>(rawPolicy);
        StringRef choice = policy ? policy.getValue() : StringRef("auto");
        if ((choice != "auto" && choice != "seed" && choice != "lds" && choice != "lds_k64") ||
            ((choice == "lds" || choice == "lds_k64") && !transposedB) ||
            (choice == "lds_k64" && (schedule.k < 64 || schedule.k % 64 != 0))) {
          op->emitError("ROCM_FP8_BLOCKSCALE_CONTRACT: MXFP8 schedule policy "
                        "must be auto, seed, lds, or lds_k64; LDS requires NK storage and lds_k64 requires whole K64 slabs");
          return failure();
        }
        // Paired gfx1201 measurements retain a half-CU narrow grid for
        // long K: 32 workgroups fill the RX 9070 XT WGPs. The bounds keep
        // smaller grids, wider panels and unmeasured sizes on prior recipes.
        const bool measuredLongK64 = transposedB && units &&
            schedule.m >= 200 && schedule.m <= 512 &&
            schedule.n >= 512 && schedule.n <= 2048 &&
            schedule.k >= 2560 && schedule.k <= 5120 &&
            schedule.k % 64 == 0 &&
            tiles(128, 64) >= (*units + 1) / 2 &&
            tiles(128, 128) < *units;
        const bool chooseLds = choice == "lds" || choice == "lds_k64" ||
            (choice == "auto" && transposedB && units && schedule.m >= 128 &&
             schedule.k >= 1024 &&
             (tiles(128, 64) >= *units || measuredLongK64));
        if (chooseLds) {
          schedule.macroTileM = 128;
          schedule.macroTileN = choice != "lds_k64" && units && tiles(128, 128) >= *units ? 128 : 64;
          schedule.warps = 8;
          schedule.pipelineDepth = 1;
          schedule.staging = "lds";
          // Explicit experiment: physical K64 slab, two independently scaled
          // K32 partials in ascending group order.
          // Independent forward/reverse gfx1201 packets retain K64 only
          // measured 128x64 panels. Wider panels retain K32; the narrow
          // long-K extension keeps the two independent K32 scales.
          const bool measuredK64 = choice == "auto" &&
              schedule.macroTileN == 64 && schedule.k >= 1024 &&
              (schedule.k <= 2048 || measuredLongK64) && schedule.k % 64 == 0;
          if (choice == "lds_k64" || measuredK64) schedule.blockK = 64;
        }
      } else {
        selectFp8W8A8BlockScalePanel(schedule);
      }
      if (schedule.typedTransposeA || schedule.k % schedule.scaleBlockK != 0) {
        // Column-major A uses the canonical typed fragment gather. No LDS
        // recipe measured for row-major A is transferred to this storage.
        if (auto policy = module->getAttrOfType<StringAttr>("tessera.rocm.mxfp8_schedule");
            policy && policy.getValue() != "auto" && policy.getValue() != "seed")
          return failure();
        schedule.macroTileM = schedule.macroTileN = 16;
        schedule.blockK = schedule.scaleBlockK;
        schedule.warps = schedule.pipelineDepth = 1;
        schedule.staging = "global";
      }
    }
    return schedule;
  }
  if (schedule.target == "rocm" && schedule.arch == "gfx1201" &&
      lhsElement == rhsElement && (lhsElement.isF16() || lhsElement.isBF16()) &&
      outElement.isF32()) {
    // RDNA4 profile on its own evidence (no gfx11 panel inheritance). bf16
    // storage joined f16 on 2026-09-18 (slice 1b): same fragment family,
    // V_WMMA_F32_16X16X16_BF16. The panel follows the typed-route gap
    // packet measured on Tajasarus the same day
    // (benchmarks/baselines/typed_route_gap_20260918/gfx1201.json): the 2x4
    // register panel is 2.1x the 1x1 at 1024^3 and 3.3x at 2048^3, a wash
    // at 512^3 and slower on ragged shapes, so it is selected only for a
    // static, fully tiled problem at 1024 and above. Wall clock on a WSL2
    // host, no counters: a selection input, not a promotion.
    // Per-shape panel (typed-route gap packets, 2026-09-18): the 4x4 panel for
    // every static, fully tiled problem at 1024 and above, the 1x1 otherwise
    // (a wash at 512^3, faster on ragged shapes). The panel axis stops here --
    // 4x8 and 8x8 fall off a VGPR cliff (64.1 -> 15.6 -> 7.4 TFLOP/s at
    // 4096^3) -- so latency hiding, not tile size, carries the rest; the
    // packager picks the K unroll (`scheduled_matmul.rocm_k_unroll`).
    schedule.storage = lhsElement.isBF16() ? "bf16" : "f16";
    schedule.accum = "f32";
    schedule.macroTileM = gfx1201StaticPanel ? 64 : 16;
    schedule.macroTileN = gfx1201StaticPanel ? 64 : 16;
    // ROCM-SPLIT-K-1: f16/bf16 only. The fp8 and integer branches above keep
    // S=1 until they have their own device proof; an i32 workspace would be
    // exact, but "would be" is not evidence.
    selectGfx1201SplitK(schedule);
    return schedule;
  }
  if (rocm && lhsElement == rhsElement &&
      (lhsElement.isF16() || lhsElement.isBF16()) && outElement.isF32()) {
    schedule.storage = lhsElement.isBF16() ? "bf16" : "f16";
    schedule.accum = "f32";
    // gfx1151's committed production GEMM is a 2x4 register-blocked WMMA
    // macro-tile.  Schedule IR carries logical element extents, not the
    // backend's mt/nt spelling, so preserve that decision as 32x64x16 --
    // except in the fully tiled [1024, 2048) band, where the typed 4x4
    // panel recovers the 10% the directive lane's 4x4 had over it
    // (11.2 vs 10.5 TFLOP/s at 1024^3, gfx1151 gap packet 2026-09-18) and
    // loses again at 2048^3 (17.6 vs 21.3).
    const bool band4x4 = !schedule.dynamicM && !schedule.dynamicN &&
                         !schedule.dynamicK && schedule.m >= 1024 &&
                         schedule.n >= 1024 && schedule.m < 2048 &&
                         schedule.n < 2048 && schedule.m % 64 == 0 &&
                         schedule.n % 64 == 0;
    schedule.macroTileM = band4x4 ? 64 : 32;
    schedule.macroTileN = 64;
    if (schedule.arch.empty())
      schedule.arch = "gfx1151";
    return schedule;
  }
  if (nvidiaNvfp4) {
    schedule.storage = "nvfp4";
    schedule.storageB = "nvfp4";
    schedule.accum = "f32";
    schedule.output = "f32";
    schedule.tileM = 16;
    schedule.tileN = 8;
    schedule.tileK = 64;
    schedule.macroTileM = 16;
    schedule.macroTileN = 8;
    schedule.warps = 1;
    if (schedule.arch.empty()) schedule.arch = "sm_120";
    return schedule;
  }
  if (nvidia_sm120 && lhsElement.isInteger(4) && rhsElement.isInteger(4) &&
      outElement.isInteger(32) && !schedule.dynamicM && !schedule.dynamicN &&
      !schedule.dynamicK && !schedule.bias && !schedule.residual &&
      schedule.activation == "none") {
    if (lhs.getEncoding() || rhs.getEncoding() || out.getEncoding()) return failure();
    auto int4Function = op->getParentOfType<func::FuncOp>();
    if (!int4Function || !llvm::hasSingleElement(int4Function.getBody()) ||
        int4Function.getNumArguments() != 2) return failure();
    auto ret = dyn_cast<func::ReturnOp>(int4Function.getBody().front().back());
    if (!ret || ret.getNumOperands() != 1) return failure();
    Value returned = ret.getOperand(0);
    if (auto scheduled = returned.getDefiningOp<schedule::MatmulOp>())
      returned = scheduled.getSubject();
    if (returned != op->getResult(0)) return failure();
    for (NamedAttribute attr : op->getAttrs())
      if (attr.getName().getValue().contains("layout") ||
          attr.getName().getValue().contains("pack") ||
          attr.getName().getValue().contains("stride")) return failure();
    if (auto fn = op->getParentOfType<func::FuncOp>())
      for (unsigned i = 0; i < fn.getNumArguments(); ++i)
        if (fn.getArgAttr(i, "tessera.layout")) return failure();
    schedule.storage = "int4";
    schedule.accum = "int32";
    schedule.output = "i32";
    schedule.tileM = schedule.macroTileM = 16;
    schedule.tileN = schedule.macroTileN = 8;
    schedule.tileK = 32;
    if (schedule.arch.empty()) schedule.arch = "sm_120";
    return schedule;
  }
  if (nvidia_sm120 &&
      ((lhsElement.isF16() && rhsElement.isF16()) ||
       (lhsElement.isBF16() && rhsElement.isBF16())) &&
      (outElement.isF32() || outElement.isF16())) {
    // Consumer Blackwell's owned MMA contract is warp-level m16n8k16 with
    // fp16 storage and fp32 accumulation.  The macro tile remains a launch
    // envelope; Tile/Target lowering owns fragment packing and repetition.
    schedule.storage = lhsElement.isBF16() ? "bf16" : "f16";
    schedule.accum = "f32";
    schedule.output = outElement.isF16() ? "f16" : "f32";
    schedule.tileM = 16;
    schedule.tileN = 8;
    schedule.tileK = 16;
    schedule.macroTileM = 128;
    schedule.macroTileN = 128;
    schedule.warps = 1;
    if (schedule.arch.empty())
      schedule.arch = "sm_120";
    return schedule;
  }
  return failure();
}

// ── NUMPOL-CARRIER-1: the declared accumulator gets a consumer here too ──
//
// The schedule above infers `accum` from the operand/result element types,
// per target. That inference is coherent and it is not the declared contract:
// `numeric_policy.accum` reached this op, was never read, and the inferred
// value won. Same shape as the ROCm WMMA generator, one level up.
//
// `accum` is a semantic key — it decides what the program COMPUTES — so a
// declared accumulator this schedule cannot provide fails closed rather than
// being silently replaced by the inferred one and reported as success
// (Decisions #21a/#29). Every reachable case infers "f32" today, and no
// in-tree program declares anything else, so this changes no existing
// selection or schedule digest.
//
// Not device-proven: the sm_120 typed route this feeds needs the NR2 Pro box,
// which this change was not developed on. What IS proven here is that the
// refusal fires, that a matching declaration passes, and that the emitted IR
// for every existing fixture is unchanged.
static FailureOr<MatmulSchedule> getMatmulSchedule(Operation *op) {
  FailureOr<MatmulSchedule> schedule = getInferredMatmulSchedule(op);
  if (failed(schedule))
    return schedule;
  if (Attribute request = op->getAttr("rhs_storage_order")) {
    auto order = dyn_cast<StringAttr>(request);
    if (!order || (order.getValue() != "row_major" && order.getValue() != "col_major") ||
        schedule->target != "nvidia_sm120" || schedule->arch != "sm_120" ||
        (schedule->storage != "f16" && schedule->storage != "bf16") ||
        (schedule->output != "f32" && schedule->output != "f16") ||
        schedule->tileM != 16 ||
        schedule->tileN != 8 || schedule->tileK != 16) {
      op->emitError("rhs_storage_order requires the SM120 typed view contract");
      return failure();
    }
    schedule->bLayout = order.getValue();
  }
  auto policy = op->getAttrOfType<DictionaryAttr>("numeric_policy");
  if (!policy)
    return schedule;
  auto declaredAttr = policy.getAs<StringAttr>("accum");
  if (!declaredAttr)
    return schedule;
  StringRef declared = declaredAttr.getValue();
  StringRef inferred = schedule->accum;
  // The policy spells dtypes in the Decision #15a vocabulary ("fp32"); the
  // schedule spells them in MLIR's ("f32"). Same fact, two spellings — #32's
  // point that a level may rename an attribute without losing it.
  auto normalize = [](StringRef name) -> StringRef {
    return llvm::StringSwitch<StringRef>(name)
        .Case("fp64", "f64").Case("fp32", "f32").Case("fp16", "f16")
        .Case("int32", "i32").Case("int64", "i64").Case("int16", "i16")
        .Case("int8", "i8")
        .Default(name);
  };
  if (normalize(declared) == normalize(inferred))
    return schedule;
  op->emitError("MATMUL_SCHEDULE_ACCUM_UNSUPPORTED: numeric_policy declares "
                "accum=\"")
      << declared << "\", but the selected " << schedule->target
      << " matmul schedule accumulates in \"" << inferred
      << "\". Refusing rather than substituting: `accum` selects what the "
         "program computes, so honouring the inference here would report "
         "success for a different computation (Decisions #21a/#29).";
  return failure();
}

static std::string scheduleDigest(const MatmulSchedule &schedule) {
  // Stated only when set, so every existing schedule digest is unchanged.
  const std::string scaleN =
      schedule.scaleBlockN > 0
          ? ";scale_n=" + std::to_string(schedule.scaleBlockN)
          : std::string();
  std::string contract =
      (Twine("target=") + schedule.target + ";arch=" + schedule.arch +
       ";M=" + Twine(schedule.m) + ";N=" + Twine(schedule.n) +
       ";K=" + Twine(schedule.k) + ";storage=" + schedule.storage +
       ";storage_b=" + schedule.storageB + ";block_k=" +
       Twine(schedule.blockK) + ";scale_k=" + Twine(schedule.scaleBlockK) +
       ";scale_format=" + schedule.scaleFormat +
       scaleN +
       (schedule.aRowStride > 0
            ? ";lda=" + std::to_string(schedule.aRowStride) +
                  ";ldb=" + std::to_string(schedule.bRowStride)
            : std::string()) +
       ";physical_contract=" + schedule.physicalContract +
       ";accum=" + schedule.accum + ";tile=" + Twine(schedule.tileM) + "x" +
       Twine(schedule.tileN) + "x" + Twine(schedule.tileK) +
       ";macro_tile=" + Twine(schedule.macroTileM) + "x" +
       Twine(schedule.macroTileN) + ";warps=" +
       Twine(schedule.warps) + ";pipeline_depth=" +
       Twine(schedule.pipelineDepth) + ";raster=row_major;group=" +
       Twine(schedule.rasterGroup) + ";epilogue=b" + Twine(schedule.bias) +
       ",a=" + schedule.activation + ",r=" + Twine(schedule.residual) +
       ",out=" + schedule.output + ";dynamic=" +
       Twine(schedule.dynamicM) + Twine(schedule.dynamicN) +
       Twine(schedule.dynamicK))
          .str();
  if (schedule.typedTransposeA) contract += ";typed_transpose_a=1";
  if (schedule.nvfp4TransposeA) contract += ";nvfp4_transpose_a=1";
  if (schedule.nvfp4TransposeB) contract += ";nvfp4_transpose_b=1";
  if (!schedule.broadcastTypes.empty()) {
    contract += ";batching=broadcast;operand_types=";
    llvm::raw_string_ostream stream(contract);
    for (auto type : schedule.broadcastTypes) { type.print(stream); stream << ";"; }
    schedule.broadcastResult.print(stream);
    stream.flush();
  } else if (schedule.independentBatchCount > 0)
    contract += std::string(schedule.sharedBatchLhs ? ";batching=shared_lhs;batch_rows=" : schedule.sharedBatchRhs ? ";batching=shared_rhs_rows;batch_rows=" : ";batching=independent_rhs;batch_rows=") +
        std::to_string(schedule.independentBatchRows) + ";batch_count=" +
        std::to_string(schedule.independentBatchCount);
  // ROCM-SPLIT-K-1: appended only when a split exists, so every unsplit
  // schedule keeps the digest it had before split-K could be expressed.
  if (schedule.splitK > 1)
    contract += (Twine(";split_k=") + Twine(schedule.splitK) +
                 ";split_k_reduction=" + schedule.splitKReduction)
                    .str();
  // ROCM-FP8-BLOCKSCALE-1 large-M body: appended only when set, so every
  // register-panel schedule keeps its digest.
  if (schedule.staging != "global")
    contract += (Twine(";staging=") + schedule.staging).str();
  if (schedule.bLayout != "col_major")
    contract += (Twine(";b_storage_layout=") + schedule.bLayout).str();
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(contract)),
                     /*LowerCase=*/true);
}

struct SemanticKernelSchedule {
  StringRef family;
  StringRef kind;
  StringRef target;
  StringRef arch;
  StringRef storage;
  StringRef accum = "f32";
  StringRef expMode = "accurate";
  StringRef reductionSchedule = "serial";
  double epsilon = 0.0;
  SmallVector<int64_t> inputShape;
  SmallVector<int64_t> outputShape;
  int64_t axis = -1;
  bool keepdims = false;
  int64_t rows = 1;
  int64_t columns = 1;
  int64_t outer = 1;
  int64_t axisExtent = 1;
  int64_t inner = 1;
  int64_t workgroupSize = 1;
};

static StringRef storageName(Type type) {
  if (type.isF16()) return "f16";
  if (type.isBF16()) return "bf16";
  if (type.isF32()) return "f32";
  return {};
}

static FailureOr<SemanticKernelSchedule> getSemanticKernelSchedule(Operation *op) {
  ModuleOp module = op->getParentOfType<ModuleOp>();
  if (!module || op->getNumOperands() != 1 || op->getNumResults() != 1)
    return failure();
  auto input = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto output = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  if (!input || !output || input.getRank() < 1 || !input.hasStaticShape() ||
      !output.hasStaticShape())
    return failure();

  SemanticKernelSchedule schedule;
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  schedule.storage = storageName(input.getElementType());
  schedule.inputShape.assign(input.getShape().begin(), input.getShape().end());
  schedule.outputShape.assign(output.getShape().begin(), output.getShape().end());
  bool x86 = schedule.target == "x86" || schedule.arch.contains("avx512") ||
             schedule.arch.contains("zen5");
  bool rocm = schedule.target == "rocm" &&
              (schedule.arch == "gfx1151" || schedule.arch == "gfx1201");
  // Apple GPU consumes the shared softmax launch tile through its f32 MSL ABI.
  // It has no scheduled reduction consumer yet, so it is admitted for softmax
  // only below.  The launch tile does not prescribe a workgroup for Apple (the
  // delegated MSL route owns its threadgroup), so workgroupSize stays 1.
  bool apple_gpu = schedule.target == "apple_gpu";
  bool nvidia = schedule.target == "nvidia_sm120" && schedule.arch == "sm_120";
  if (nvidia) schedule.expMode = "approx_exp2";
  if (!x86 && !rocm && !apple_gpu && !nvidia)
    return failure();

  StringRef opName = op->getName().getStringRef();
  if (opName == "tessera.relu") {
    if (!nvidia || input != output || input.getRank() != 2 || input.getEncoding() ||
        (schedule.storage != "f16" && schedule.storage != "bf16") ||
        !llvm::all_of(input.getShape(), [](int64_t d) { return d > 0; }))
      return failure();
    for (NamedAttribute attr : op->getAttrs()) {
      if (attr.getName().getValue() == "schedule.artifact_hash") continue;
      if (attr.getName().getValue() == "schedule") {
        auto mode = dyn_cast<StringAttr>(attr.getValue());
        if (!mode || (mode.getValue() != "serial" && mode.getValue() != "flat_128"))
          return failure();
        schedule.reductionSchedule = mode.getValue();
        continue;
      }
      auto effect = dyn_cast<StringAttr>(attr.getValue());
      if (attr.getName().getValue() != "tessera.effect_kind" ||
          !effect || effect.getValue() != "pure") return failure();
    }
    // Match the checked runtime envelope before forming a flat grid or bytes.
    if (input.getDimSize(0) >= (1LL << 31) || input.getDimSize(1) >= (1LL << 31) ||
        input.getDimSize(0) > (1LL << 31) / input.getDimSize(1))
      return failure();
    schedule.family = "activation";
    schedule.kind = "relu";
    schedule.rows = input.getDimSize(0);
    schedule.columns = input.getDimSize(1);
    schedule.workgroupSize = 128;
    return schedule;
  }
  if (opName == "tessera.rmsnorm" || opName == "tessera.rmsnorm_safe" || opName == "tessera.layer_norm") {
    auto eps = op->getAttrOfType<FloatAttr>("eps");
    auto axis = op->getAttrOfType<IntegerAttr>("axis");
    // E2E-REAL-6 x86 (2026-09-28): Zen 5 carries the static f32 unweighted
    // row normalization the retired `x86_native.package_cohort2` served.
    bool gfx1201Norm = rocm && schedule.arch == "gfx1201" &&
                       opName == "tessera.rmsnorm" &&
                       (schedule.storage == "f16" || schedule.storage == "bf16" ||
                        schedule.storage == "f32");
    if ((!nvidia && !x86 && !gfx1201Norm) || (x86 && schedule.storage != "f32") ||
        schedule.storage.empty() || input.getShape() != output.getShape() ||
        input.getElementType() != output.getElementType() ||
        (axis && axis.getInt() != -1 && axis.getInt() != input.getRank() - 1) ||
        op->hasAttr("numeric_policy")) return failure();
    schedule.epsilon = static_cast<float>(eps ? eps.getValueAsDouble() :
        opName == "tessera.rmsnorm_safe" ? 1e-6 : 1e-5);
    if (!std::isfinite(schedule.epsilon) || schedule.epsilon <= 0.0) return failure();
    for (int64_t dim : input.getShape()) if (dim <= 0) return failure();
    schedule.family = "norm";
    schedule.kind = opName == "tessera.layer_norm" ? "layernorm" : "rmsnorm";
    schedule.columns = input.getShape().back();
    for (int64_t dim : input.getShape().drop_back()) schedule.rows *= dim;
    schedule.workgroupSize = rocm ? 256 : nvidia ? 128 : 1;
    // The native Schedule owns this shape decision. Exact SM120 A/B evidence
    // covers the coalesced CTA row schedule; short feature rows retain serial.
    // An explicit schedule remains authoritative for tuning and comparison.
    schedule.reductionSchedule =
        nvidia && schedule.columns >= 256 ? "cooperative_128" : "serial";
    if (auto mode = op->getAttrOfType<StringAttr>("schedule"))
      schedule.reductionSchedule = mode.getValue();
    if (schedule.reductionSchedule != "serial" &&
        (!nvidia || schedule.reductionSchedule != "cooperative_128")) return failure();
    return schedule;
  }
  if (opName == "tessera.softmax") {
    auto axisAttr = op->getAttrOfType<IntegerAttr>("axis");
    if ((axisAttr && axisAttr.getInt() != -1) || input != output ||
        (x86 && schedule.storage != "f32")
        || (nvidia && schedule.storage != "f16" && schedule.storage != "bf16" && schedule.storage != "f32") ||
        (rocm && schedule.storage != "f16" && schedule.storage != "f32") ||
        (apple_gpu && schedule.storage != "f32" && schedule.storage != "f16" && schedule.storage != "bf16"))
      return failure();
    schedule.family = "softmax";
    schedule.rows = 1;
    for (int64_t dim : input.getShape().drop_back()) schedule.rows *= dim;
    schedule.columns = input.getShape().back();
    schedule.workgroupSize = rocm ? 256 : nvidia ? 128 : 1;
    // Native row policy; explicit physical schedules remain authoritative.
    schedule.reductionSchedule =
        nvidia && schedule.columns >= 256 ? "cooperative_128" : "serial";
    if (auto mode = op->getAttrOfType<StringAttr>("schedule"))
      schedule.reductionSchedule = mode.getValue();
    if (schedule.reductionSchedule != "serial" &&
        (!nvidia || schedule.reductionSchedule != "cooperative_128"))
      return failure();
    return schedule;
  }

  if (opName != "tessera.reduce")
    return failure();
  auto axisAttr = op->getAttrOfType<IntegerAttr>("axis");
  int64_t axis = axisAttr ? axisAttr.getInt() : -1;
  if (axis < 0) axis += input.getRank();
  if (axis < 0 || axis >= input.getRank() || !output.getElementType().isF32())
    return failure();
  auto kindAttr = op->getAttrOfType<StringAttr>("kind");
  if (!kindAttr || (kindAttr.getValue() != "sum" &&
                    kindAttr.getValue() != "mean" &&
                    kindAttr.getValue() != "max" && (!nvidia || kindAttr.getValue() != "min")))
    return failure();
  auto keepAttr = op->getAttrOfType<BoolAttr>("keepdims");
  bool keepdims = keepAttr && keepAttr.getValue();
  // E2E-REAL-6 (ROCm unary family, 2026-09-27): gfx1151 reductions admit
  // f16/bf16 storage (f32 output) and keepdims, the envelope the retired
  // Graph-owned `rocm_native.package_reduction` constructor served with
  // gfx1151 device proof. gfx1201 keeps its proved f32 rank-reducing envelope
  // until it has its own device rows (proofs never transfer between the two).
  bool rocmNarrow = rocm && schedule.arch == "gfx1151";
  if (keepdims && !nvidia && !x86 && !rocmNarrow) return failure();
  if (auto mode = op->getAttrOfType<StringAttr>("schedule"))
    schedule.reductionSchedule = mode.getValue();
  if (schedule.reductionSchedule != "serial" &&
      (!nvidia || schedule.reductionSchedule != "cooperative_128")) return failure();
  SmallVector<int64_t> expected(input.getShape().begin(), input.getShape().end());
  if (keepdims) expected[axis] = 1;
  else expected.erase(expected.begin() + axis);
  if (ArrayRef<int64_t>(expected) != output.getShape() ||
      (schedule.storage != "f32" && ((!nvidia && !rocmNarrow) ||
                                     (schedule.storage != "f16" && schedule.storage != "bf16"))) ||
      (x86 && axis != input.getRank() - 1) ||
      // Apple's synthesized reduce kernel gives one thread per row and folds
      // over the trailing extent, so it expresses last-axis reductions only.
      // An interior axis (inner != 1) fails closed rather than being reordered
      // into something the program did not ask for.
      (apple_gpu && axis != input.getRank() - 1))
    return failure();
  schedule.family = "reduce";
  schedule.kind = kindAttr.getValue();
  schedule.axis = axis;
  schedule.keepdims = keepdims;
  for (int64_t dim : input.getShape().take_front(axis)) schedule.outer *= dim;
  schedule.axisExtent = input.getDimSize(axis);
  for (int64_t dim : input.getShape().drop_front(axis + 1)) schedule.inner *= dim;
  schedule.workgroupSize = rocm ? 256 : nvidia ? 128 : 1;
  return schedule;
}

static std::string semanticKernelDigest(const SemanticKernelSchedule &schedule) {
  std::string inputShape;
  std::string outputShape;
  for (int64_t dim : schedule.inputShape)
    inputShape += (inputShape.empty() ? "" : "x") + Twine(dim).str();
  for (int64_t dim : schedule.outputShape)
    outputShape += (outputShape.empty() ? "" : "x") + Twine(dim).str();
  std::string contract =
      (Twine("family=") + schedule.family + ";kind=" + schedule.kind +
       ";target=" + schedule.target + ";arch=" + schedule.arch +
       ";input=" + inputShape + ";output=" + outputShape +
       ";storage=" + schedule.storage + ";accum=" + schedule.accum +
       ";axis=" + Twine(schedule.axis) + ";keepdims=" +
       Twine(schedule.keepdims ? 1 : 0) + ";rows=" + Twine(schedule.rows) +
       ";columns=" + Twine(schedule.columns) + ";outer=" +
       Twine(schedule.outer) + ";axis_extent=" + Twine(schedule.axisExtent) +
       ";inner=" + Twine(schedule.inner) + ";workgroup=" +
       Twine(schedule.workgroupSize) + ";exp=" + schedule.expMode +
       ";ftz=0;schedule=" + schedule.reductionSchedule + ";nan=propagate")
          .str();
  if (schedule.family == "activation")
    contract += schedule.storage == "f16" ? ";zero_mode=positive" : ";zero_mode=preserve";
  if (schedule.family == "norm") {
    contract += ";epsilon_bits=" + Twine(llvm::APFloat(static_cast<float>(schedule.epsilon)).bitcastToAPInt().getZExtValue()).str();
  }
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(contract)),
                     /*LowerCase=*/true);
}

struct FFTSchedule {
  StringRef target;
  StringRef arch;
  StringRef mode;
  StringRef radixPolicy;
  StringRef strategy;
  StringRef algorithm;
  StringRef realTransformPolicy;
  StringRef hermitianLayout;
  StringRef hermitianWeight;
  StringRef normalization;
  StringRef kernelFamily;
  StringRef workspacePolicy;
  StringRef residency;
  StringRef twiddlePolicy;
  SmallVector<int64_t> inputShape;
  SmallVector<int64_t> outputShape;
  SmallVector<int64_t> radixSequence;
  int64_t axis = -1;
  int64_t length = 0;
  int64_t physicalLength = 0;
  int64_t batch = 0;
  bool inverse = false;
  double scale = 1.0;
  int64_t bluesteinM = 0;
  int64_t workspaceElems = 0;
  int64_t workgroupSize = 1;
};

static int64_t nextPowerOfTwo(int64_t value) {
  int64_t result = 1;
  while (result < value &&
         result <= (std::numeric_limits<int64_t>::max() / 2))
    result <<= 1;
  return result;
}

static bool isPowerOfTwo(int64_t value) {
  return value > 0 && (value & (value - 1)) == 0;
}

static std::optional<SmallVector<int64_t>> mixedRadixSequence(int64_t value) {
  SmallVector<int64_t> stages;
  int64_t rest = value;
  while (rest % 4 == 0) { stages.push_back(4); rest /= 4; }
  while (rest % 2 == 0) { stages.push_back(2); rest /= 2; }
  for (int64_t radix = 3; radix <= 17; radix += 2)
    while (rest % radix == 0) {
      stages.push_back(radix);
      rest /= radix;
    }
  if (rest != 1) return std::nullopt;
  return stages;
}

static bool preferX86MixedRadix(int64_t length, ArrayRef<int64_t> stages) {
  if (length <= 8 || isPowerOfTwo(length) || stages.empty()) return false;
  int64_t padded = nextPowerOfTwo(2 * length - 1);
  int64_t log2Padded = 0;
  for (int64_t rest = padded; rest > 1; rest /= 2) ++log2Padded;
  long double directWork = static_cast<long double>(length);
  int64_t radixSum = 0;
  for (int64_t stage : stages) radixSum += stage;
  directWork *= radixSum;
  long double bluesteinWork =
      3.0L * static_cast<long double>(padded) * log2Padded;
  return 5.0L * directWork <= 2.0L * bluesteinWork;
}

static FailureOr<FFTSchedule> getFFTSchedule(Operation *op) {
  ModuleOp module = op->getParentOfType<ModuleOp>();
  if (!module || op->getNumOperands() != 1 || op->getNumResults() != 1)
    return failure();
  auto input = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto output = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  if (!input || !output || input.getRank() < 1 || !input.hasStaticShape() ||
      !output.hasStaticShape() || input.getRank() != output.getRank())
    return failure();

  FFTSchedule schedule;
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  bool x86 = schedule.target == "x86" || schedule.arch.contains("avx512") ||
             schedule.arch.contains("zen5");
  bool rocm = schedule.arch.contains("gfx1151") || schedule.arch.contains("gfx1201");
  bool nvidia = schedule.target == "nvidia_sm120" || schedule.arch == "sm120";
  if (!x86 && !rocm && !nvidia) return failure();
  schedule.radixPolicy = (rocm || nvidia) ? "mixed_radix" : "radix2";
  schedule.algorithm = nvidia ? "cufft_plan_many" :
                       rocm ? "stockham_autosort" : "cooley_tukey_dit";
  schedule.residency = nvidia ? "explicit_caller_workspace_device_plan" :
                       rocm ? "persistent_device_plan" : "host_inplace";
  schedule.twiddlePolicy =
      nvidia ? "cufft_plan_owned" :
      rocm ? "device_sincos_per_butterfly" : "thread_local_cached_f32";
  schedule.kernelFamily =
      nvidia ? "sm120_cufft_workspace_v2" :
      rocm ? (schedule.arch.contains("gfx1201") ? "gfx1201_stockham_bluestein_v6"
                                                : "gfx1151_stockham_bluestein_v6")
           : "zen5_avx512_fft_v4";
  schedule.workgroupSize = (rocm || nvidia) ? 256 : 1;
  schedule.inputShape.assign(input.getShape().begin(), input.getShape().end());
  schedule.outputShape.assign(output.getShape().begin(), output.getShape().end());

  auto axisAttr = op->getAttrOfType<IntegerAttr>("axis");
  schedule.axis = axisAttr ? axisAttr.getInt() : -1;
  if (schedule.axis < 0) schedule.axis += input.getRank();
  if (schedule.axis < 0 || schedule.axis >= input.getRank()) return failure();
  auto norm = op->getAttrOfType<StringAttr>("norm");
  auto normalization = op->getAttrOfType<StringAttr>("normalization");
  schedule.normalization = normalization ? normalization.getValue() :
                                           norm ? norm.getValue() : "backward";
  if (schedule.normalization != "backward" &&
      schedule.normalization != "forward" &&
      schedule.normalization != "ortho")
    return failure();
  auto weight = op->getAttrOfType<StringAttr>("hermitian_weight");
  schedule.hermitianWeight = weight ? weight.getValue() : "none";
  if (schedule.hermitianWeight != "none" &&
      schedule.hermitianWeight != "half_interior" &&
      schedule.hermitianWeight != "double_interior")
    return failure();

  StringRef name = op->getName().getStringRef();
  auto isComplexF32 = [](Type type) {
    auto complex = dyn_cast<ComplexType>(type);
    return complex && complex.getElementType().isF32();
  };
  if (name == "tessera.fft" || name == "tessera.ifft") {
    if (!isComplexF32(input.getElementType()) ||
        !isComplexF32(output.getElementType()))
      return failure();
    schedule.mode = "c2c";
    schedule.inverse = name == "tessera.ifft";
    schedule.length = input.getDimSize(schedule.axis);
    if (input != output) return failure();
  } else if (name == "tessera.rfft") {
    if (!input.getElementType().isF32() ||
        !isComplexF32(output.getElementType()))
      return failure();
    schedule.mode = "r2c";
    schedule.length = input.getDimSize(schedule.axis);
    if (output.getDimSize(schedule.axis) != schedule.length / 2 + 1)
      return failure();
  } else if (name == "tessera.irfft") {
    if (!isComplexF32(input.getElementType()) ||
        !output.getElementType().isF32())
      return failure();
    schedule.mode = "c2r";
    schedule.inverse = true;
    auto lengthAttr = op->getAttrOfType<IntegerAttr>("logical_length");
    if (!lengthAttr) lengthAttr = op->getAttrOfType<IntegerAttr>("n");
    schedule.length =
        lengthAttr ? lengthAttr.getInt() : output.getDimSize(schedule.axis);
    if (output.getDimSize(schedule.axis) != schedule.length ||
        input.getDimSize(schedule.axis) != schedule.length / 2 + 1)
      return failure();
  } else {
    return failure();
  }
  if (auto logicalLength =
          op->getAttrOfType<IntegerAttr>("logical_length")) {
    if (logicalLength.getInt() != schedule.length) return failure();
  }
  if (schedule.length <= 0) return failure();
  for (int64_t dimension = 0; dimension < input.getRank(); ++dimension) {
    if (dimension == schedule.axis) continue;
    if (input.getDimSize(dimension) != output.getDimSize(dimension))
      return failure();
    schedule.batch = schedule.batch == 0
                         ? input.getDimSize(dimension)
                         : schedule.batch * input.getDimSize(dimension);
  }
  if (input.getRank() == 1) schedule.batch = 1;
  schedule.scale = schedule.normalization == "ortho"
                       ? 1.0 / std::sqrt(static_cast<double>(schedule.length))
                   : schedule.normalization == "forward"
                       ? (schedule.inverse ? 1.0
                                           : 1.0 / schedule.length)
                       : (schedule.inverse ? 1.0 / schedule.length : 1.0);

  const bool realMode = schedule.mode == "r2c" || schedule.mode == "c2r";
  const int64_t candidatePhysicalLength =
      realMode && schedule.length % 2 == 0 ? schedule.length / 2
                                           : schedule.length;
  auto candidateStages = mixedRadixSequence(candidatePhysicalLength);
  const bool packedReal = !nvidia &&
      realMode && schedule.length % 2 == 0 &&
      (rocm || isPowerOfTwo(candidatePhysicalLength) ||
       (candidateStages &&
        preferX86MixedRadix(candidatePhysicalLength, *candidateStages)));
  schedule.physicalLength =
      packedReal ? candidatePhysicalLength : schedule.length;
  schedule.realTransformPolicy =
      nvidia && realMode ? "native_cufft_r2c_c2r_v1" :
      packedReal ? "packed_even_n2_hermitian_v1"
                 : realMode ? "full_complex_hermitian_fallback"
                            : "not_applicable";
  schedule.hermitianLayout =
      realMode ? "half_spectrum_nyquist_explicit" : "full_complex";

  if (nvidia) {
    auto stages = mixedRadixSequence(schedule.physicalLength);
    if (stages) {
      schedule.strategy = "mixed_radix";
      schedule.radixSequence = *stages;
      schedule.workspaceElems = schedule.physicalLength;
    } else {
      schedule.strategy = "bluestein";
      schedule.bluesteinM = nextPowerOfTwo(2 * schedule.physicalLength - 1);
      schedule.workspaceElems = schedule.bluesteinM;
    }
    schedule.workspacePolicy = "explicit_caller_owned_cufft_workspace";
  } else if (rocm) {
    auto stages = mixedRadixSequence(schedule.physicalLength);
    if (stages) {
      schedule.strategy = "mixed_radix";
      schedule.radixSequence = *stages;
      schedule.workspaceElems = schedule.physicalLength;
      schedule.workspacePolicy = "persistent_plan_n";
    } else {
      schedule.strategy = "bluestein";
      schedule.bluesteinM = nextPowerOfTwo(2 * schedule.physicalLength - 1);
      schedule.workspaceElems = 4 * schedule.bluesteinM;
      schedule.workspacePolicy = "persistent_plan_4m";
      schedule.twiddlePolicy = "persistent_device_chirp_fft";
    }
    if (schedule.strategy != "bluestein" && schedule.physicalLength <= 1024 &&
        isPowerOfTwo(schedule.physicalLength))
      schedule.residency = packedReal
                               ? "persistent_device_plan_fused_lds_hermitian_batch"
                               : "persistent_device_plan_fused_lds_batch";
  } else {
    auto stages = mixedRadixSequence(schedule.physicalLength);
    if (stages && preferX86MixedRadix(schedule.physicalLength, *stages)) {
      schedule.radixPolicy = "mixed_radix";
      schedule.strategy = "mixed_radix";
      schedule.algorithm = "stockham_autosort";
      schedule.radixSequence = *stages;
      schedule.workspaceElems = 2 * schedule.physicalLength;
      schedule.workspacePolicy = "thread_local_2n";
      schedule.residency = "host_thread_local_ping_pong";
    } else if (isPowerOfTwo(schedule.physicalLength)) {
      schedule.strategy = "radix2";
      for (int64_t rest = schedule.physicalLength; rest > 1; rest /= 2)
        schedule.radixSequence.push_back(2);
      schedule.workspacePolicy = "inplace_no_scratch";
    } else if (schedule.physicalLength <= 8) {
      schedule.strategy = "dft";
      schedule.workspacePolicy = "inplace_no_scratch";
    } else {
      schedule.strategy = "bluestein";
      schedule.bluesteinM = nextPowerOfTwo(2 * schedule.physicalLength - 1);
      schedule.workspaceElems = schedule.bluesteinM;
      schedule.workspacePolicy = "host_temporary_m";
    }
  }
  return schedule;
}

static std::string fftScheduleDigest(const FFTSchedule &schedule) {
  auto shapeText = [](ArrayRef<int64_t> shape) {
    std::string value;
    for (int64_t dim : shape)
      value += (value.empty() ? "" : "x") + Twine(dim).str();
    return value;
  };
  std::string radix;
  for (int64_t stage : schedule.radixSequence)
    radix += (radix.empty() ? "" : ",") + Twine(stage).str();
  std::string contract =
      (Twine("family=fft;target=") + schedule.target + ";arch=" +
       schedule.arch + ";mode=" + schedule.mode + ";input=" +
       shapeText(schedule.inputShape) + ";output=" +
       shapeText(schedule.outputShape) + ";axis=" + Twine(schedule.axis) +
       ";length=" + Twine(schedule.length) + ";batch=" +
       Twine(schedule.batch) + ";physical_length=" +
       Twine(schedule.physicalLength) + ";real_transform_policy=" +
       schedule.realTransformPolicy + ";hermitian_layout=" +
       schedule.hermitianLayout + ";hermitian_weight=" +
       schedule.hermitianWeight + ";inverse=" +
       Twine(schedule.inverse ? 1 : 0) + ";normalization=" +
       schedule.normalization + ";scale=" +
       std::to_string(static_cast<float>(schedule.scale)) +
       ";storage=complex64_interleaved_f32;accum=f32;radix_policy=" +
       schedule.radixPolicy + ";strategy=" + schedule.strategy +
       ";algorithm=" + schedule.algorithm +
       ";radix=" + radix + ";bluestein_m=" +
       Twine(schedule.bluesteinM) + ";workspace=" +
       Twine(schedule.workspaceElems) + ";workspace_policy=" +
       schedule.workspacePolicy + ";residency=" + schedule.residency +
       ";twiddle=interleaved_f32;twiddle_policy=" + schedule.twiddlePolicy +
       ";deterministic=1;kernel=" +
       schedule.kernelFamily + ";workgroup=" + Twine(schedule.workgroupSize))
          .str();
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(contract)),
                     /*LowerCase=*/true);
}

static std::string spectralBackwardTypeSignature(ValueRange values) {
  std::string signature;
  llvm::raw_string_ostream stream(signature);
  llvm::interleave(
      values, stream,
      [&](Value value) { value.getType().print(stream); }, ",");
  stream.flush();
  return signature;
}

// ── ODS-WIRE-2: the Graph->Schedule consumer of `tessera.istft_jvp` ─────
//
// `ISTFTOp::buildTangent` (TangentInterface.cpp) produces this op under
// `--tessera-autodiff-forward`; `JitFn.native_jvp` runs that transform over the
// traced module. Before this arm nothing consumed the product: the native JVP
// plugin re-derived the ISTFT contract from the SOURCE op's Python kwargs, so
// C++ forward AD and the plugin were two authorities for one JVP (#31).
//
// This arm is the production authority for the product's semantic contract.
// It resolves every default (axis, n_fft, output length, centering, storage),
// derives which tangents are active from the IR (a tangent the transform
// materialized as a zero splat is inactive), checks the overlap-add geometry
// against the static result type, and binds all of it into one canonical
// contract string plus its SHA-256 and a matching `schedule.artifact`. The
// plugin (`native_jvp_plugins.istft_jvp_contract_from_paired_ir`) reads that
// contract instead of the kwargs; the kwargs derivation survives only as a
// declared oracle that must agree with it. The physical spectral program
// (`schedule.spectral_program`) is still minted by `lower_scheduled_spectral`
// from these values -- that module is the one spectral-program authority, and
// minting its content-addressed ScheduleObject here too would be a second one.
static bool isZeroSplatConstant(Value value) {
  auto constant = value.getDefiningOp<arith::ConstantOp>();
  if (!constant) return false;
  auto dense = dyn_cast<DenseElementsAttr>(constant.getValue());
  if (!dense || !dense.isSplat()) return false;
  Type element = dense.getElementType();
  auto complex = dyn_cast<ComplexType>(element);
  if (!isa<FloatType>(element) &&
      !(complex && isa<FloatType>(complex.getElementType())))
    return false;
  // All-zero bits: +0.0, or (+0.0, +0.0) for a complex splat. A -0.0 splat
  // reads as active, which only costs a redundant term, never a dropped one.
  return llvm::all_of(dense.getRawData(), [](char byte) { return byte == 0; });
}

static LogicalResult scheduleIstftJvps(ModuleOp mod, OpBuilder &builder) {
  SmallVector<Operation *> products;
  mod.walk([&](Operation *op) {
    if (op->getName().getStringRef() == "tessera.istft_jvp")
      products.push_back(op);
  });
  for (Operation *op : products) {
    auto refuse = [&](const Twine &why) {
      op->emitError("SPECTRAL_JVP_SCHEDULE_REFUSED: tessera.istft_jvp ") << why;
      return failure();
    };
    StringRef configuredTarget = moduleString(mod, "tessera.target", "target");
    StringRef configuredArch = moduleString(mod, "tessera.arch", "arch");
    StringRef target, arch;
    if (configuredTarget == "x86" && (configuredArch == "zen5-avx512" ||
                                      configuredArch == "zen5_avx512")) {
      target = "x86";
      arch = "zen5-avx512";
    } else if (configuredTarget == "rocm" &&
               (configuredArch == "gfx1151" || configuredArch == "gfx1201")) {
      target = "rocm";
      arch = configuredArch;
    } else if (configuredTarget == "nvidia_sm120" &&
               (configuredArch == "sm120" || configuredArch == "sm_120")) {
      target = "nvidia_sm120";
      arch = "sm120";
    } else {
      return refuse(Twine("requires an exact Zen 5 AVX-512, gfx1151, gfx1201 "
                          "or sm120 profile; got target='") +
                    configuredTarget + "' arch='" + configuredArch + "'");
    }
    if (op->getNumOperands() != 4 || op->getNumResults() != 1)
      return refuse("requires (spectrum, window, dspectrum, dwindow) -> tangent");
    auto spectrum = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
    auto window = dyn_cast<RankedTensorType>(op->getOperand(1).getType());
    auto result = dyn_cast<RankedTensorType>(op->getResult(0).getType());
    if (!spectrum || !window || !result || !spectrum.hasStaticShape() ||
        !window.hasStaticShape() || !result.hasStaticShape())
      return refuse("requires static ranked tensors");
    auto complex = dyn_cast<ComplexType>(spectrum.getElementType());
    if (!complex || !complex.getElementType().isF32())
      return refuse("requires a complex<f32> spectrum");
    Type storageElement = window.getElementType();
    StringRef storage = storageElement.isF32()    ? "fp32"
                        : storageElement.isF16()  ? "fp16"
                        : storageElement.isBF16() ? "bf16"
                                                  : "";
    if (storage.empty() || result.getElementType() != storageElement)
      return refuse("requires an f16/bf16/f32 window whose element type the "
                    "tangent shares");
    if (auto policy = op->getAttrOfType<DictionaryAttr>("numeric_policy")) {
      auto declaredStorage = policy.getAs<StringAttr>("storage");
      auto declaredAccum = policy.getAs<StringAttr>("accum");
      if (!declaredStorage || declaredStorage.getValue() != storage ||
          !declaredAccum || declaredAccum.getValue() != "fp32")
        return refuse(Twine("numeric_policy must be {storage=") + storage +
                      ", accum=fp32} for this window");
    }
    int64_t rank = spectrum.getRank();
    auto axisAttr = op->getAttrOfType<IntegerAttr>("axis");
    int64_t axis = axisAttr ? axisAttr.getInt() : -1;
    if (axis < 0) axis += rank;
    if (axis <= 0 || axis >= rank)
      return refuse("requires a frequency axis with a preceding frame axis");
    int64_t windowLength = window.getDimSize(window.getRank() - 1);
    auto lengthAttr = op->getAttrOfType<IntegerAttr>("logical_length");
    int64_t nfft = lengthAttr ? lengthAttr.getInt() : windowLength;
    if (nfft < windowLength)
      return refuse("requires logical_length (n_fft) >= the window length");
    auto hopAttr = op->getAttrOfType<IntegerAttr>("hop");
    if (!hopAttr || hopAttr.getInt() <= 0)
      return refuse("requires an explicit hop > 0");
    int64_t hop = hopAttr.getInt();
    auto boolAttr = [&](StringRef name, bool fallback) {
      auto attr = op->getAttrOfType<BoolAttr>(name);
      return attr ? attr.getValue() : fallback;
    };
    bool center = boolAttr("center", false);
    bool onesided = boolAttr("onesided", true);
    auto normalizationAttr = op->getAttrOfType<StringAttr>("normalization");
    StringRef normalization =
        normalizationAttr ? normalizationAttr.getValue() : "backward";
    if (normalization != "backward" && normalization != "forward" &&
        normalization != "ortho")
      return refuse("normalization must be backward, forward or ortho");
    auto padModeAttr = op->getAttrOfType<StringAttr>("pad_mode");
    if (padModeAttr && padModeAttr.getValue() != "constant")
      return refuse("ISTFT has no pad_mode other than constant");
    int64_t expectedBins = onesided ? nfft / 2 + 1 : nfft;
    if (spectrum.getDimSize(axis) != expectedBins)
      return refuse(Twine("spectrum axis ") + Twine(axis) + " has " +
                    Twine(spectrum.getDimSize(axis)) + " bins; n_fft=" +
                    Twine(nfft) + " requires " + Twine(expectedBins));
    int64_t frameAxis = axis - 1;
    int64_t frames = spectrum.getDimSize(frameAxis);
    int64_t raw = (frames - 1) * hop + nfft;
    int64_t pad = center ? nfft / 2 : 0;
    int64_t available = raw - 2 * pad;
    if (result.getRank() != rank - 1)
      return refuse("tangent rank must drop the frequency axis");
    int64_t outputLength = result.getDimSize(frameAxis);
    if (outputLength <= 0 || outputLength > available)
      return refuse(Twine("output length ") + Twine(outputLength) +
                    " must crop within the " + Twine(available) +
                    " available overlap-add samples");
    if (auto declared = op->getAttrOfType<IntegerAttr>("output_length"))
      if (declared.getInt() != outputLength)
        return refuse("output_length disagrees with the static tangent type");
    for (int64_t dim = 0; dim < rank - 1; ++dim) {
      int64_t source = dim < frameAxis ? dim : dim + 1;
      if (dim == frameAxis) continue;
      if (result.getDimSize(dim) != spectrum.getDimSize(source))
        return refuse("tangent batch dimensions disagree with the spectrum");
    }
    SmallVector<int64_t> active;
    if (!isZeroSplatConstant(op->getOperand(2))) active.push_back(0);
    if (!isZeroSplatConstant(op->getOperand(3))) active.push_back(1);
    if (active.empty())
      return refuse("has no active tangent (both are zero splats)");

    std::string spectrumType, windowType, resultType;
    {
      llvm::raw_string_ostream s(spectrumType), w(windowType), r(resultType);
      spectrum.print(s);
      window.print(w);
      result.print(r);
    }
    std::string activeText;
    for (auto [index, value] : llvm::enumerate(active))
      activeText += (index ? "," : "") + std::to_string(value);
    std::string contract =
        (Twine("schema=tessera.spectral_jvp.v1;kind=tessera.istft;target=") +
         target + ";arch=" + arch + ";spectrum=" + spectrumType +
         ";window=" + windowType + ";tangent=" + resultType +
         ";axis=" + Twine(axis) + ";logical_length=" + Twine(nfft) +
         ";hop=" + Twine(hop) + ";frames=" + Twine(frames) +
         ";center=" + Twine(center ? 1 : 0) +
         ";onesided=" + Twine(onesided ? 1 : 0) +
         ";pad_mode=constant;output_length=" + Twine(outputLength) +
         ";normalization=" + normalization +
         ";spectrum_layout=" +
         (onesided ? "half_spectrum_nyquist_explicit" : "full_complex") +
         ";window_broadcast=trailing_batch_broadcast_v1" +
         ";numeric_storage=" + storage + ";numeric_accum=fp32" +
         ";active_tangents=" + activeText +
         ";mutation_lineage=inputs_immutable_output_fresh_v1")
            .str();
    std::string digest = llvm::toHex(
        llvm::SHA256::hash(llvm::arrayRefFromStringRef(contract)),
        /*LowerCase=*/true);

    // Carry every resolved default forward on the op (Decision #32): a
    // downstream reader sees the values the contract was hashed over.
    op->setAttr("axis", builder.getI64IntegerAttr(axis));
    op->setAttr("logical_length", builder.getI64IntegerAttr(nfft));
    op->setAttr("output_length", builder.getI64IntegerAttr(outputLength));
    op->setAttr("normalization", builder.getStringAttr(normalization));
    op->setAttr("center", builder.getBoolAttr(center));
    op->setAttr("onesided", builder.getBoolAttr(onesided));
    op->setAttr("pad_mode", builder.getStringAttr("constant"));
    // buildTangent copies the ISTFT op's attribute dictionary, which can carry
    // the compound op's "not_applicable" window default; the product's real
    // policy is the trailing-batch broadcast the contract hashes.
    op->setAttr("window_broadcast",
                builder.getStringAttr("trailing_batch_broadcast_v1"));
    op->setAttr("numeric_policy",
                builder.getDictionaryAttr({
                    builder.getNamedAttr("storage", builder.getStringAttr(storage)),
                    builder.getNamedAttr("accum", builder.getStringAttr("fp32")),
                }));
    op->setAttr("schedule.target", builder.getStringAttr(target));
    op->setAttr("schedule.arch", builder.getStringAttr(arch));
    op->setAttr("schedule.frames", builder.getI64IntegerAttr(frames));
    op->setAttr("schedule.active_tangents",
                builder.getDenseI64ArrayAttr(active));
    op->setAttr("schedule.jvp_contract", builder.getStringAttr(contract));
    op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));

    builder.setInsertionPointAfter(op);
    OperationState artifactState(op->getLoc(), "schedule.artifact");
    artifactState.addAttribute("hash", builder.getStringAttr(digest));
    artifactState.addAttribute("arch", builder.getStringAttr(arch));
    artifactState.addAttribute(
        "shape_key",
        builder.getStringAttr("family=spectral_jvp;kind=tessera.istft"));
    artifactState.addAttribute(
        "tile", builder.getDictionaryAttr({builder.getNamedAttr(
                    "output_count", builder.getI64IntegerAttr(1))}));
    artifactState.addAttribute(
        "numeric_policy",
        builder.getStringAttr((Twine("jvp;") + normalization).str()));
    builder.create(artifactState);
  }
  return success();
}

static FailureOr<std::string> spectralBackwardDigest(Operation *op) {
  auto stringAttr = [&](StringRef name) {
    return op->getAttrOfType<StringAttr>(name);
  };
  auto kind = stringAttr("kind");
  auto target = stringAttr("target");
  auto arch = stringAttr("arch");
  auto normalization = stringAttr("normalization");
  auto layout = stringAttr("spectrum_layout");
  auto padMode = stringAttr("pad_mode");
  auto axisPacking = stringAttr("axis_packing");
  auto windowBroadcast = stringAttr("window_broadcast");
  auto lineage = stringAttr("mutation_lineage");
  auto numericPolicy = op->getAttrOfType<DictionaryAttr>("numeric_policy");
  auto numericStorage =
      numericPolicy ? numericPolicy.getAs<StringAttr>("storage") : StringAttr();
  auto numericAccum =
      numericPolicy ? numericPolicy.getAs<StringAttr>("accum") : StringAttr();
  if (!kind || !target || !arch || !normalization || !layout || !padMode ||
      !axisPacking || !windowBroadcast ||
      !lineage || !numericStorage || !numericAccum)
    return failure();
  auto integer = [&](StringRef name, int64_t fallback) {
    auto attr = op->getAttrOfType<IntegerAttr>(name);
    return attr ? attr.getInt() : fallback;
  };
  auto boolean = [&](StringRef name, bool fallback) {
    auto attr = op->getAttrOfType<BoolAttr>(name);
    return attr ? attr.getValue() : fallback;
  };
  auto inputSignature = stringAttr("input_signature");
  auto outputSignature = stringAttr("output_signature");
  std::string inputs = inputSignature
                           ? inputSignature.getValue().str()
                           : spectralBackwardTypeSignature(op->getOperands());
  std::string outputs = outputSignature
                            ? outputSignature.getValue().str()
                            : spectralBackwardTypeSignature(op->getResults());
  std::string contract =
      (Twine("schema=tessera.spectral_backward.v3;kind=") + kind.getValue() +
       ";target=" + target.getValue() + ";arch=" + arch.getValue() +
       ";inputs=" + inputs + ";outputs=" + outputs +
       ";axis=" + Twine(integer("axis", -1)) + ";logical_length=" +
       Twine(integer("logical_length", -1)) + ";normalization=" +
       normalization.getValue() + ";spectrum_layout=" + layout.getValue() +
       ";axis_packing=" + axisPacking.getValue() +
       ";hop=" + Twine(integer("hop", -1)) + ";center=" +
       Twine(boolean("center", false) ? 1 : 0) + ";onesided=" +
       Twine(boolean("onesided", true) ? 1 : 0) + ";pad_mode=" +
       padMode.getValue() + ";output_length=" +
       Twine(integer("output_length", -1)) + ";mutation_lineage=" +
       lineage.getValue() + ";numeric_storage=" + numericStorage.getValue() +
       ";numeric_accum=" + numericAccum.getValue() +
       ";window_broadcast=" + windowBroadcast.getValue())
          .str();
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(contract)),
                     /*LowerCase=*/true);
}

static FailureOr<std::pair<std::string, std::string>>
esLowRankContract(Operation *op, StringRef architecture) {
  if (op->getName().getStringRef() != "tessera.es_low_rank_correction" ||
      op->getNumOperands() != 3 || op->getNumResults() != 1)
    return failure();
  auto x = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto members = dyn_cast<RankedTensorType>(op->getOperand(1).getType());
  auto key = dyn_cast<RankedTensorType>(op->getOperand(2).getType());
  auto result = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  auto outDim = op->getAttrOfType<IntegerAttr>("out_dim");
  auto rank = op->getAttrOfType<IntegerAttr>("rank");
  auto sigma = op->getAttrOfType<FloatAttr>("sigma");
  if (!x || !members || !key || !result || !x.hasStaticShape() ||
      !members.hasStaticShape() || !key.hasStaticShape() ||
      !result.hasStaticShape() || !x.getElementType().isF32() || !outDim ||
      !rank || !sigma)
    return failure();
  int64_t rows = 1;
  for (int64_t dim : x.getShape().drop_front().drop_back()) rows *= dim;
  int64_t epoch = 0;
  if (auto attr = op->getAttrOfType<IntegerAttr>("epoch")) epoch = attr.getInt();
  bool antithetic = true;
  if (auto attr = op->getAttrOfType<BoolAttr>("antithetic"))
    antithetic = attr.getValue();
  StringRef score = "gaussian";
  if (auto attr = op->getAttrOfType<StringAttr>("score")) score = attr.getValue();
  std::string sigmaText = std::to_string(sigma.getValueAsDouble());
  std::string payload =
      (Twine("schema=tessera.es_low_rank_correction.v1;arch=") + architecture +
       ";" +
       "population=" + Twine(x.getDimSize(0)) + ";rows_per_member=" +
       Twine(rows) + ";in_dim=" + Twine(x.getShape().back()) + ";out_dim=" +
       Twine(outDim.getInt()) + ";rank=" + Twine(rank.getInt()) + ";epoch=" +
       Twine(epoch) + ";sigma=" + sigmaText +
       ";antithetic=" + Twine(antithetic ? 1 : 0) + ";score=" + score +
       ";rng=splitmix64-philox4x32-boxmuller;version=1;storage=f32;accum=f32;" +
       "lineage=x/member_ids/key-read-only;correction-fresh")
          .str();
  std::string hash = llvm::toHex(
      llvm::SHA256::hash(llvm::arrayRefFromStringRef(payload)),
      /*LowerCase=*/true);
  return std::make_pair(std::move(payload), std::move(hash));
}

struct AttentionSchedule {
  StringRef target;
  StringRef arch;
  StringRef storage;
  StringRef accum = "f32";
  StringRef outputStorage = "f32";
  SmallVector<int64_t> qShape;
  SmallVector<int64_t> kShape;
  SmallVector<int64_t> vShape;
  SmallVector<int64_t> outputShape;
  int64_t batch;
  int64_t queryHeads;
  int64_t kvHeads;
  int64_t queryRows;
  int64_t keyRows;
  int64_t headDim;
  int64_t valueDim;
  double scale;
  bool causal;
  bool bias = false;
  SmallVector<int64_t> biasShape;
  int64_t windowLeft;
  int64_t windowRight;
  double softcap;
  double dropoutP;
  int64_t dropoutSeed;
  int64_t tileQ;
  int64_t tileKV = 16;
  int64_t workgroupSize;
  StringRef recurrence = "rank4_batch_query_head_kv_online_softmax_v1";
  StringRef backwardLsePolicy;
  StringRef backwardLseSelection;
};

struct DepthAttentionSchedule {
  StringRef target;
  StringRef arch;
  StringRef storage;
  StringRef softmax = "f32";
  StringRef accum = "f32";
  int64_t sourceCount;
  int64_t rows;
  int64_t width;
  double eps;
  int64_t sourceTile;
  int64_t workgroupSize;
  StringRef statisticsRecurrence = "rms_key_online_softmax_stats_v1";
  StringRef mergeRecurrence = "max_shifted_pairwise_merge_v1";
  bool reassociable = true;
};

struct TridiagonalSchedule {
  StringRef target;
  StringRef arch;
  StringRef storage = "f32";
  StringRef accum = "f64";
  int64_t batch;
  int64_t systemSize;
  int64_t workgroupSize;
  StringRef algorithm;
};

static FailureOr<TridiagonalSchedule>
getTridiagonalSchedule(Operation *op) {
  ModuleOp module = op->getParentOfType<ModuleOp>();
  if (!module || op->getName().getStringRef() !=
                     "tessera.tridiagonal_solve" ||
      op->getNumOperands() != 4 || op->getNumResults() != 1)
    return failure();
  auto dl = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto diagonal = dyn_cast<RankedTensorType>(op->getOperand(1).getType());
  auto du = dyn_cast<RankedTensorType>(op->getOperand(2).getType());
  auto rhs = dyn_cast<RankedTensorType>(op->getOperand(3).getType());
  auto output = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  if (!dl || !diagonal || !du || !rhs || !output || !dl.hasStaticShape() ||
      !diagonal.hasStaticShape() || !du.hasStaticShape() ||
      !rhs.hasStaticShape() || !output.hasStaticShape() || dl.getRank() != 1 ||
      diagonal.getRank() != 1 || du.getRank() != 1 || rhs.getRank() < 1 ||
      dl.getShape() != diagonal.getShape() || du.getShape() != diagonal.getShape() ||
      rhs.getShape() != output.getShape() ||
      rhs.getShape().back() != diagonal.getDimSize(0) ||
      dl.getElementType() != diagonal.getElementType() ||
      du.getElementType() != diagonal.getElementType() ||
      rhs.getElementType() != diagonal.getElementType() ||
      output.getElementType() != diagonal.getElementType() ||
      !diagonal.getElementType().isF32())
    return failure();

  TridiagonalSchedule schedule;
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  bool x86 = schedule.target == "x86" &&
             (schedule.arch.contains("avx512") || schedule.arch.contains("zen5"));
  bool rocm = schedule.target == "rocm" &&
              (schedule.arch.contains("gfx1151") || schedule.arch.contains("gfx1201"));
  if (!x86 && !rocm)
    return failure();
  schedule.systemSize = diagonal.getDimSize(0);
  schedule.batch = 1;
  for (int64_t extent : rhs.getShape().drop_back())
    schedule.batch *= extent;
  if (schedule.systemSize <= 0 || schedule.batch <= 0)
    return failure();
  if (rocm && (schedule.systemSize > 256 ||
               !llvm::isPowerOf2_64(schedule.systemSize)))
    return failure();
  schedule.workgroupSize = rocm ? schedule.systemSize : 1;
  schedule.algorithm = rocm ? "cooperative_lds_pcr_v1"
                            : "batch_vector_thomas_v1";
  return schedule;
}

static std::string
tridiagonalScheduleDigest(const TridiagonalSchedule &schedule) {
  std::string payload =
      (Twine("schema=tessera.tridiagonal.schedule.v1;target=") +
       schedule.target + ";arch=" + schedule.arch + ";batch=" +
       Twine(schedule.batch) + ";n=" + Twine(schedule.systemSize) +
       ";storage=" + schedule.storage + ";accum=" + schedule.accum +
       ";algorithm=" + schedule.algorithm + ";workgroup=" +
       Twine(schedule.workgroupSize))
          .str();
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(payload)),
                     /*LowerCase=*/true);
}

struct CoalitionButterflySchedule {
  StringRef target;
  StringRef arch;
  StringRef storage = "f32";
  StringRef accum = "f64";
  int64_t batch;
  int64_t latticeSize;
  int64_t players;
  int64_t half;
  int64_t sign;
  int64_t workgroupSize;
  StringRef stageOrder = "ascending_bit_yates_v1";
};

static FailureOr<CoalitionButterflySchedule>
getCoalitionButterflySchedule(Operation *op) {
  StringRef name = op->getName().getStringRef();
  if (name != "tessera.game_subset_zeta" &&
      name != "tessera.game_subset_mobius" &&
      name != "tessera.game_superset_zeta" &&
      name != "tessera.game_superset_mobius")
    return failure();
  ModuleOp module = op->getParentOfType<ModuleOp>();
  if (!module || op->getNumOperands() != 1 || op->getNumResults() != 1)
    return failure();
  auto input = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto output = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  if (!input || !output || !input.hasStaticShape() || !output.hasStaticShape() ||
      input.getShape() != output.getShape() || input.getRank() < 1 ||
      !input.getElementType().isF32() ||
      input.getElementType() != output.getElementType())
    return failure();
  int64_t size = input.getShape().back();
  if (size <= 0 || !llvm::isPowerOf2_64(size))
    return failure();
  CoalitionButterflySchedule schedule;
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  bool x86 = schedule.target == "x86" &&
             (schedule.arch.contains("avx512") || schedule.arch.contains("zen5"));
  bool rocm = schedule.target == "rocm" &&
              (schedule.arch.contains("gfx1151") || schedule.arch.contains("gfx1201"));
  if (!x86 && !rocm)
    return failure();
  // The physical gfx1151 consumer retains the complete fp64 lattice in LDS.
  // Fail before artifact creation when that state cannot fit in 64 KiB/CU.
  if (rocm && size > (64 * 1024) / static_cast<int64_t>(sizeof(double)))
    return failure();
  schedule.batch = 1;
  for (int64_t extent : input.getShape().drop_back())
    schedule.batch *= extent;
  schedule.latticeSize = size;
  schedule.players = llvm::Log2_64(size);
  schedule.half = name.contains("subset") ? 1 : 0;
  schedule.sign = name.contains("mobius") ? -1 : 1;
  schedule.workgroupSize = rocm ? std::min<int64_t>(256, size) : 1;
  return schedule;
}

static std::string coalitionButterflyDigest(
    const CoalitionButterflySchedule &schedule) {
  std::string payload =
      (Twine("schema=tessera.coalition_butterfly.schedule.v1;target=") +
       schedule.target + ";arch=" + schedule.arch + ";batch=" +
       Twine(schedule.batch) + ";size=" + Twine(schedule.latticeSize) +
       ";players=" + Twine(schedule.players) + ";half=" +
       Twine(schedule.half) + ";sign=" + Twine(schedule.sign) +
       ";storage=" + schedule.storage + ";accum=" + schedule.accum +
       ";stage_order=" + schedule.stageOrder + ";workgroup=" +
       Twine(schedule.workgroupSize))
          .str();
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(payload)),
                     /*LowerCase=*/true);
}

static FailureOr<DepthAttentionSchedule>
getDepthAttentionSchedule(Operation *op) {
  ModuleOp module = op->getParentOfType<ModuleOp>();
  if (!module || op->getName().getStringRef() != "tessera.depth_attn" ||
      op->getNumOperands() != 2 || op->getNumResults() != 1)
    return failure();
  auto query = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto sources = dyn_cast<RankedTensorType>(op->getOperand(1).getType());
  auto output = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  if (!query || !sources || !output || !query.hasStaticShape() ||
      !sources.hasStaticShape() || !output.hasStaticShape() ||
      query.getRank() != 1 || sources.getRank() < 2 ||
      output.getRank() != sources.getRank() - 1 ||
      query.getElementType() != sources.getElementType() ||
      output.getElementType() != sources.getElementType() ||
      query.getDimSize(0) != sources.getShape().back() ||
      output.getShape() != sources.getShape().drop_front())
    return failure();

  DepthAttentionSchedule schedule;
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  bool x86 = schedule.target == "x86" &&
             (schedule.arch.contains("avx512") || schedule.arch.contains("zen5"));
  bool rocm = schedule.target == "rocm" &&
              (schedule.arch.contains("gfx1151") || schedule.arch.contains("gfx1201"));
  if (!x86 && !rocm)
    return failure();
  schedule.storage = storageName(sources.getElementType());
  // Phase 4 freezes a portable all-f32 artifact. Reduced storage becomes a
  // separate evidence-backed contract rather than an implicit target choice.
  if (schedule.storage != "f32")
    return failure();
  auto eps = op->getAttrOfType<FloatAttr>("eps");
  auto policy = op->getAttrOfType<DictionaryAttr>("numeric_policy");
  if (!eps || !eps.getValue().isFinite() || eps.getValueAsDouble() <= 0.0 ||
      !policy)
    return failure();
  auto policyString = [&](StringRef name) -> StringRef {
    auto value = dyn_cast_or_null<StringAttr>(policy.get(name));
    return value ? value.getValue() : StringRef();
  };
  if (policyString("storage") != "fp32" ||
      policyString("softmax") != "fp32" ||
      policyString("accum") != "fp32")
    return failure();
  schedule.sourceCount = sources.getDimSize(0);
  schedule.width = sources.getShape().back();
  schedule.rows = 1;
  for (int64_t dim : sources.getShape().drop_front().drop_back())
    schedule.rows *= dim;
  if (schedule.sourceCount <= 0 || schedule.rows <= 0 || schedule.width <= 0)
    return failure();
  schedule.eps = eps.getValueAsDouble();
  schedule.sourceTile = std::min<int64_t>(schedule.sourceCount, 16);
  schedule.workgroupSize = rocm ? 256 : 1;
  return schedule;
}

static std::string
depthAttentionScheduleDigest(const DepthAttentionSchedule &schedule) {
  std::string payload =
      (Twine("schema=tessera.depth_attention.schedule.v1;target=") +
       schedule.target + ";arch=" + schedule.arch + ";sources=" +
       Twine(schedule.sourceCount) + ";rows=" + Twine(schedule.rows) +
       ";width=" + Twine(schedule.width) + ";storage=" + schedule.storage +
       ";softmax=" + schedule.softmax + ";accum=" + schedule.accum +
       ";eps=" + std::to_string(schedule.eps) + ";source_tile=" +
       Twine(schedule.sourceTile) + ";workgroup=" +
       Twine(schedule.workgroupSize) + ";statistics=" +
       schedule.statisticsRecurrence + ";merge=" + schedule.mergeRecurrence +
       ";reassociable=1")
          .str();
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(payload)),
                     /*LowerCase=*/true);
}

static bool hasAppleRecomputeVJP(Operation *op);

static FailureOr<AttentionSchedule> getAttentionSchedule(Operation *op) {
  ModuleOp module = op->getParentOfType<ModuleOp>();
  if (!module || op->getName().getStringRef() != "tessera.flash_attn" ||
      (op->getNumOperands() != 3 && op->getNumOperands() != 4) ||
      op->getNumResults() != 1)
    return failure();
  auto q = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto k = dyn_cast<RankedTensorType>(op->getOperand(1).getType());
  auto v = dyn_cast<RankedTensorType>(op->getOperand(2).getType());
  auto output = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  if (!q || !k || !v || !output || q.getRank() != 4 || k.getRank() != 4 ||
      v.getRank() != 4 || output.getRank() != 4 || !q.hasStaticShape() ||
      !k.hasStaticShape() || !v.hasStaticShape() || !output.hasStaticShape())
    return failure();

  AttentionSchedule schedule;
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  bool x86 = schedule.target == "x86" &&
             (schedule.arch.contains("avx512") || schedule.arch.contains("zen5"));
  bool rocm = schedule.target == "rocm" && (schedule.arch == "gfx1151" || schedule.arch == "gfx1201");
  // Apple GPU consumes the shared rank-4 FORWARD attention launch tile through
  // its status-returning GQA MSL ABI
  // (tessera_apple_gpu_flash_attn_variant_f32_status).  That ABI is f32-only,
  // takes ONE symmetric window extent, and requires head_dim == value_dim;
  // those bounds are enforced below.  Attention BACKWARD has no Apple scheduled
  // consumer and is gated separately.
  bool apple_gpu = schedule.target == "apple_gpu" && schedule.arch == "apple7";
  bool nvidia = schedule.target == "nvidia_sm120" && schedule.arch == "sm_120";
  if (!x86 && !rocm && !apple_gpu && !nvidia)
    return failure();
  schedule.batch = q.getDimSize(0);
  schedule.queryHeads = q.getDimSize(1);
  schedule.queryRows = q.getDimSize(2);
  schedule.headDim = q.getDimSize(3);
  schedule.kvHeads = k.getDimSize(1);
  schedule.keyRows = k.getDimSize(2);
  schedule.valueDim = v.getDimSize(3);
  if (schedule.batch <= 0 || schedule.queryHeads <= 0 ||
      schedule.kvHeads <= 0 || schedule.queryRows <= 0 ||
      schedule.keyRows <= 0 || schedule.headDim <= 0 ||
      schedule.valueDim <= 0 || schedule.queryHeads % schedule.kvHeads != 0 ||
      k.getDimSize(0) != schedule.batch || v.getDimSize(0) != schedule.batch ||
      v.getDimSize(1) != schedule.kvHeads ||
      k.getDimSize(3) != schedule.headDim ||
      v.getDimSize(2) != schedule.keyRows ||
      output.getShape() !=
          ArrayRef<int64_t>({schedule.batch, schedule.queryHeads,
                             schedule.queryRows, schedule.valueDim}) ||
      (!output.getElementType().isF32() &&
       !(nvidia && output.getElementType() == q.getElementType() &&
         (output.getElementType().isF16() || output.getElementType().isBF16()))))
    return failure();
  schedule.outputStorage = storageName(output.getElementType());
  Type qElement = q.getElementType();
  if (k.getElementType() != qElement || v.getElementType() != qElement)
    return failure();
  schedule.storage = storageName(qElement);
  // Low-precision forward IR is admitted only as the recompute companion of
  // the paired VJP. The standalone Apple forward runtime remains f32-only.
  auto owner = op->getParentOfType<func::FuncOp>();
  auto checkpoint = owner ? owner->getAttrOfType<StringAttr>("tessera.lse_checkpoint") : StringAttr();
  bool appleRecompute = checkpoint && checkpoint.getValue() == "recompute" &&
                        hasAppleRecomputeVJP(op);
  if ((nvidia && schedule.storage != "f16" && schedule.storage != "bf16" && schedule.storage != "f32") ||
      (x86 && schedule.storage != "f32") ||
      (rocm && (schedule.storage != "f16" && schedule.storage != "bf16")) ||
      (rocm && (schedule.headDim != schedule.valueDim ||
                schedule.headDim % 16 != 0)) ||
      // The Apple GQA MSL ABI is f32-only, shares one head/value dim, and
      // rejects D > 256 before submission.
      (apple_gpu && ((schedule.storage != "f32" &&
                     !(appleRecompute && (schedule.storage == "f16" || schedule.storage == "bf16"))) ||
                     schedule.headDim != schedule.valueDim ||
                     schedule.headDim > 256)))
    return failure();
  if (op->getNumOperands() == 4) {
    auto bias = dyn_cast<RankedTensorType>(op->getOperand(3).getType());
    if (!bias || !bias.hasStaticShape() || !bias.getElementType().isF32() || bias.getRank() != 4 ||
        (bias.getDimSize(0) != schedule.batch && !(nvidia && bias.getDimSize(0) == 1)) ||
        (bias.getDimSize(1) != schedule.queryHeads && !(nvidia && bias.getDimSize(1) == 1)) ||
        (bias.getDimSize(2) != schedule.queryRows && !(nvidia && bias.getDimSize(2) == 1)) ||
        (bias.getDimSize(3) != schedule.keyRows && !(nvidia && bias.getDimSize(3) == 1)))
      return failure();
    schedule.bias = true;
    // Any broadcast axis (batch, head, query, key) is carried as the physical
    // bias shape so the kernel indexes the storage that exists.
    if (bias.getDimSize(0) != schedule.batch || bias.getDimSize(1) != schedule.queryHeads ||
        bias.getDimSize(2) != schedule.queryRows || bias.getDimSize(3) != schedule.keyRows)
      schedule.biasShape.assign(bias.getShape().begin(), bias.getShape().end());
  }
  auto scale = op->getAttrOfType<FloatAttr>("scale");
  auto causal = op->getAttrOfType<BoolAttr>("causal");
  auto windowLeft = op->getAttrOfType<IntegerAttr>("window_left");
  auto windowRight = op->getAttrOfType<IntegerAttr>("window_right");
  auto softcap = op->getAttrOfType<FloatAttr>("softcap");
  auto dropoutP = op->getAttrOfType<FloatAttr>("dropout_p");
  auto dropoutSeed = op->getAttrOfType<IntegerAttr>("dropout_seed");
  if (!scale || !scale.getValue().isFinite() ||
      scale.getValueAsDouble() <= 0.0 || !causal || !windowLeft ||
      !windowRight || windowLeft.getInt() < -1 || windowRight.getInt() < -1 ||
      !softcap || !softcap.getValue().isFinite() ||
      softcap.getValueAsDouble() < 0.0 || !dropoutP ||
      !dropoutP.getValue().isFinite() || dropoutP.getValueAsDouble() < 0.0 ||
      dropoutP.getValueAsDouble() >= 1.0 || !dropoutSeed)
    return failure();
  if (x86 && (windowLeft.getInt() != windowRight.getInt() ||
              dropoutP.getValueAsDouble() != 0.0))
    return failure();
  if (rocm && !((windowLeft.getInt() == -1 && windowRight.getInt() == -1) ||
                (causal.getValue() && windowLeft.getInt() >= 0 &&
                 windowRight.getInt() == 0)))
    return failure();
  // Apple's MSL non-causal window is a *symmetric half-window*
  // (window_size/2 per side), which is not the shared window_left/window_right
  // semantics, so a live window would compute a different mask than requested.
  // Bound this slice to the unwindowed contract (causal is still supported) and
  // reject dropout, which the ABI does not carry.  Windowed Apple attention
  // needs its own contract and oracle before admission.
  if (apple_gpu && (windowLeft.getInt() != -1 || windowRight.getInt() != -1 ||
                    dropoutP.getValueAsDouble() != 0.0))
    return failure();
  schedule.scale = static_cast<double>(
      static_cast<float>(scale.getValueAsDouble()));
  schedule.causal = causal.getValue();
  schedule.windowLeft = windowLeft.getInt();
  schedule.windowRight = windowRight.getInt();
  schedule.softcap = static_cast<double>(
      static_cast<float>(softcap.getValueAsDouble()));
  schedule.dropoutP = static_cast<double>(
      static_cast<float>(dropoutP.getValueAsDouble()));
  schedule.dropoutSeed = dropoutSeed.getInt();
  schedule.tileQ = schedule.queryRows;
  schedule.workgroupSize = rocm ? 256 : nvidia ? 128 : 1;
  // Apple's attention backward recomputes m/l per query row and its ABI takes
  // no LSE buffer (APPLE-ATTN-STREAM-1), so it owns an explicit recompute
  // policy rather than inheriting x86's save_lse or the gfx1151 threshold.
  schedule.backwardLsePolicy = nvidia ? "sm120_recompute" : apple_gpu   ? "apple7_recompute"
                               : x86       ? "save_lse"
                                           : schedule.arch == "gfx1201" ? "gfx1201_explicit_lse" : "gfx1151_auto_128";
  schedule.backwardLseSelection =
      (apple_gpu || nvidia || schedule.arch == "gfx1201") ? "recompute"
                : (x86 || schedule.queryRows >= 128) ? "saved" : "recompute";
  schedule.qShape.assign(q.getShape().begin(), q.getShape().end());
  schedule.kShape.assign(k.getShape().begin(), k.getShape().end());
  schedule.vShape.assign(v.getShape().begin(), v.getShape().end());
  schedule.outputShape.assign(output.getShape().begin(), output.getShape().end());
  return schedule;
}

static std::string attentionScheduleDigest(const AttentionSchedule &schedule) {
  auto bits = [](double value) {
    return Twine(llvm::APFloat(static_cast<float>(value)).bitcastToAPInt().getZExtValue()).str();
  };
  std::string contract =
      (Twine("family=attention;target=") + schedule.target +
       ";arch=" + schedule.arch + ";shape=" + Twine(schedule.batch) + "x" +
       Twine(schedule.queryHeads) + "x" + Twine(schedule.kvHeads) + "x" +
       Twine(schedule.queryRows) + "x" + Twine(schedule.keyRows) + "x" +
       Twine(schedule.headDim) + "x" + Twine(schedule.valueDim) +
       ";storage=" + schedule.storage + ";accum=" + schedule.accum +
       ";scale_bits=" + bits(schedule.scale) +
       ";causal=" + Twine(schedule.causal ? 1 : 0) +
       ";bias=" + Twine(schedule.bias ? 1 : 0) +
       ";window=" + Twine(schedule.windowLeft) + ":" +
       Twine(schedule.windowRight) + ";softcap_bits=" +
       bits(schedule.softcap) + ";dropout_bits=" +
       bits(schedule.dropoutP) + ";seed=" +
       Twine(schedule.dropoutSeed) + ";tile=" + Twine(schedule.tileQ) + "x" +
       Twine(schedule.tileKV) + ";workgroup=" +
       Twine(schedule.workgroupSize) + ";recurrence=" + schedule.recurrence +
       ";backward_lse_policy=" + schedule.backwardLsePolicy +
       ";backward_lse_selection=" + schedule.backwardLseSelection)
          .str();
  if (schedule.outputStorage != "f32")
    contract += ";output_storage=" + schedule.outputStorage.str();
  for (int64_t dim : schedule.biasShape) contract += ";bias_dim=" + std::to_string(dim);
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(contract)),
                     /*LowerCase=*/true);
}

struct AttentionBackwardSchedule {
  StringRef target;
  StringRef arch;
  StringRef storage;
  StringRef accum = "f32";
  int64_t batch;
  int64_t queryHeads;
  int64_t kvHeads;
  int64_t queryRows;
  int64_t keyRows;
  int64_t headDim;
  int64_t valueDim;
  double scale;
  bool causal;
  bool bias = false;
  int64_t windowLeft;
  int64_t windowRight;
  double softcap;
  double dropoutP;
  int64_t dropoutSeed;
  int64_t queryBlock;
  int64_t keyBlock;
  int64_t splitCount;
  int64_t workspaceBytes;
  int64_t workgroupSize;
  StringRef recurrence = "tensor_dq_split_dkdv_fixed_reduce_v1";
  StringRef lseCheckpointPolicy;
  StringRef lseCheckpointSelection;
};

static int64_t alignAttentionWorkspace(int64_t value) {
  return ((value + 255) / 256) * 256;
}

static int64_t attentionBackwardWorkspaceBytes(
    const AttentionBackwardSchedule &schedule) {
  int64_t offset = 0;
  auto add = [&](int64_t bytes) {
    offset = alignAttentionWorkspace(offset);
    offset += bytes;
  };
  add(schedule.batch * schedule.queryHeads * schedule.queryRows *
      schedule.valueDim * 4);
  add(schedule.batch * schedule.queryHeads * schedule.queryRows * 4);
  add(schedule.batch * schedule.queryHeads * schedule.queryRows * 4);
  add((schedule.splitCount - 1) * schedule.batch * schedule.kvHeads *
      schedule.keyRows * schedule.headDim * 4);
  add((schedule.splitCount - 1) * schedule.batch * schedule.kvHeads *
      schedule.keyRows * schedule.valueDim * 4);
  return alignAttentionWorkspace(offset);
}

static FailureOr<AttentionBackwardSchedule>
getAttentionBackwardSchedule(Operation *op) {
  ModuleOp module = op->getParentOfType<ModuleOp>();
  if (!module || op->getName().getStringRef() != "tessera_attn.backward" ||
      op->getNumOperands() != 5 || op->getNumResults() != 3)
    return failure();
  auto dO = dyn_cast<RankedTensorType>(op->getOperand(0).getType());
  auto q = dyn_cast<RankedTensorType>(op->getOperand(1).getType());
  auto k = dyn_cast<RankedTensorType>(op->getOperand(2).getType());
  auto v = dyn_cast<RankedTensorType>(op->getOperand(3).getType());
  auto bias = dyn_cast<RankedTensorType>(op->getOperand(4).getType());
  auto dQ = dyn_cast<RankedTensorType>(op->getResult(0).getType());
  auto dK = dyn_cast<RankedTensorType>(op->getResult(1).getType());
  auto dV = dyn_cast<RankedTensorType>(op->getResult(2).getType());
  if (!dO || !q || !k || !v || !bias || !dQ || !dK || !dV ||
      !dO.hasStaticShape() || !q.hasStaticShape() || !k.hasStaticShape() ||
      !v.hasStaticShape() || !bias.hasStaticShape() ||
      !dQ.hasStaticShape() || !dK.hasStaticShape() ||
      !dV.hasStaticShape() ||
      dO.getRank() != 4 || q.getRank() != 4 || k.getRank() != 4 ||
      v.getRank() != 4 || dQ.getRank() != 4 || dK.getRank() != 4 ||
      dV.getRank() != 4)
    return failure();

  AttentionBackwardSchedule schedule;
  schedule.target = moduleString(module, "tessera.target", "target");
  schedule.arch = moduleString(module, "tessera.arch", "arch");
  bool x86 = schedule.target == "x86" &&
             (schedule.arch.contains("avx512") || schedule.arch.contains("zen5"));
  bool rocm = schedule.target == "rocm" && (schedule.arch == "gfx1151" || schedule.arch == "gfx1201");
  // Apple GPU consumes the shared rank-4 BACKWARD launch tile through its
  // status-returning MSL VJP ABI (tessera_apple_gpu_flash_attn_bwd_variant_*
  // _status), which owns dQ / split-dK/dV / fixed-order reduction routes.
  // Same envelope as the Apple forward gate; enforced below.
  bool apple_gpu = schedule.target == "apple_gpu" && schedule.arch == "apple7";
  if (!x86 && !rocm && !apple_gpu)
    return failure();
  schedule.batch = q.getDimSize(0);
  schedule.queryHeads = q.getDimSize(1);
  schedule.queryRows = q.getDimSize(2);
  schedule.headDim = q.getDimSize(3);
  schedule.kvHeads = k.getDimSize(1);
  schedule.keyRows = k.getDimSize(2);
  schedule.valueDim = v.getDimSize(3);
  SmallVector<int64_t, 4> expectedDO{schedule.batch, schedule.queryHeads,
                                     schedule.queryRows, schedule.valueDim};
  if (schedule.batch <= 0 || schedule.queryHeads <= 0 ||
      schedule.kvHeads <= 0 || schedule.queryRows <= 0 ||
      schedule.keyRows <= 0 || schedule.headDim <= 0 ||
      schedule.valueDim <= 0 || schedule.queryHeads % schedule.kvHeads != 0 ||
      k.getDimSize(0) != schedule.batch || v.getDimSize(0) != schedule.batch ||
      v.getDimSize(1) != schedule.kvHeads ||
      k.getDimSize(3) != schedule.headDim ||
      v.getDimSize(2) != schedule.keyRows ||
      dO.getShape() != ArrayRef<int64_t>(expectedDO) ||
      dQ.getShape() != q.getShape() || dK.getShape() != k.getShape() ||
      dV.getShape() != v.getShape() || !dQ.getElementType().isF32() ||
      !dK.getElementType().isF32() || !dV.getElementType().isF32())
    return failure();
  Type storageType = q.getElementType();
  if (dO.getElementType() != storageType || k.getElementType() != storageType ||
      v.getElementType() != storageType)
    return failure();
  schedule.storage = storageName(storageType);
  if ((x86 && schedule.storage != "f32") ||
      (rocm && schedule.storage != "f16" && schedule.storage != "bf16") ||
      (rocm && (schedule.headDim != schedule.valueDim ||
                schedule.headDim % 16 != 0)) ||
      // The Apple VJP ABI shares one head/value dim and rejects D > 256.  It
      // accepts f32/f16/bf16 storage; dQ/dK/dV are always f32, which the
      // shared contract already requires above.
      (apple_gpu && ((schedule.storage != "f32" && schedule.storage != "f16" &&
                      schedule.storage != "bf16") ||
                     schedule.headDim != schedule.valueDim ||
                     schedule.headDim > 256)))
    return failure();
  schedule.bias = bias.getRank() == 4;
  if (schedule.bias) {
    SmallVector<int64_t, 4> expectedBias{
        schedule.batch, schedule.queryHeads, schedule.queryRows,
        schedule.keyRows};
    if (bias.getShape() != ArrayRef<int64_t>(expectedBias))
      return failure();
  }

  auto scale = op->getAttrOfType<FloatAttr>("scale");
  auto causal = op->getAttrOfType<BoolAttr>("causal");
  auto windowLeft = op->getAttrOfType<IntegerAttr>("window_left");
  auto windowRight = op->getAttrOfType<IntegerAttr>("window_right");
  auto softcap = op->getAttrOfType<FloatAttr>("softcap");
  auto dropoutP = op->getAttrOfType<FloatAttr>("dropout_p");
  auto dropoutSeed = op->getAttrOfType<IntegerAttr>("dropout_seed");
  auto queryBlock = op->getAttrOfType<IntegerAttr>("query_block");
  auto keyBlock = op->getAttrOfType<IntegerAttr>("key_block");
  auto splitCount = op->getAttrOfType<IntegerAttr>("split_count");
  if (!scale || !scale.getValue().isFinite() || scale.getValueAsDouble() <= 0.0 ||
      !causal || !windowLeft || !windowRight || windowLeft.getInt() < -1 ||
      windowRight.getInt() < -1 || !softcap || !softcap.getValue().isFinite() ||
      softcap.getValueAsDouble() < 0.0 || !dropoutP ||
      !dropoutP.getValue().isFinite() || dropoutP.getValueAsDouble() < 0.0 ||
      dropoutP.getValueAsDouble() >= 1.0 || !dropoutSeed || !queryBlock ||
      !keyBlock || !splitCount || queryBlock.getInt() <= 0 ||
      keyBlock.getInt() <= 0 || splitCount.getInt() != 2)
    return failure();
  if (x86 && (windowLeft.getInt() != windowRight.getInt() ||
              dropoutP.getValueAsDouble() != 0.0))
    return failure();
  if (rocm && !((windowLeft.getInt() == -1 && windowRight.getInt() == -1) ||
                (causal.getValue() && windowLeft.getInt() >= 0 &&
                 windowRight.getInt() == 0)))
    return failure();
  // Same bound as the Apple forward gate: the MSL non-causal window is a
  // symmetric half-window, not the shared window_left/window_right semantics,
  // so a live window fails closed rather than computing a different mask.
  if (apple_gpu && (windowLeft.getInt() != -1 || windowRight.getInt() != -1 ||
                    dropoutP.getValueAsDouble() != 0.0))
    return failure();
  schedule.scale = static_cast<double>(static_cast<float>(scale.getValueAsDouble()));
  schedule.causal = causal.getValue();
  schedule.windowLeft = windowLeft.getInt();
  schedule.windowRight = windowRight.getInt();
  schedule.softcap = static_cast<double>(static_cast<float>(softcap.getValueAsDouble()));
  schedule.dropoutP = static_cast<double>(static_cast<float>(dropoutP.getValueAsDouble()));
  schedule.dropoutSeed = dropoutSeed.getInt();
  schedule.queryBlock = queryBlock.getInt();
  schedule.keyBlock = keyBlock.getInt();
  schedule.splitCount = splitCount.getInt();
  schedule.workgroupSize = rocm ? 256 : 1;
  // Apple's backward recomputes m/l per query row and its ABI takes no LSE
  // buffer (APPLE-ATTN-STREAM-1), so it declares its own policy rather than
  // inheriting x86's save_lse or the gfx1151 threshold.
  schedule.lseCheckpointPolicy = apple_gpu ? "apple7_recompute"
                                 : x86     ? "save_lse"
                                           : schedule.arch == "gfx1201" ? "gfx1201_explicit_lse" : "gfx1151_auto_128";
  schedule.lseCheckpointSelection =
      (apple_gpu || schedule.arch == "gfx1201") ? "recompute"
      : (x86 || std::max(schedule.queryRows, schedule.keyRows) >= 128)
          ? "saved"
          : "recompute";
  Operation *function = op->getParentOp();
  auto checkpoint = function
      ? function->getAttrOfType<StringAttr>("tessera.lse_checkpoint")
      : StringAttr();
  if (schedule.arch == "gfx1201" && checkpoint &&
      (checkpoint.getValue() == "saved" || checkpoint.getValue() == "recompute"))
    schedule.lseCheckpointSelection = checkpoint.getValue();
  if (!checkpoint || checkpoint.getValue() != schedule.lseCheckpointSelection)
    return failure();
  schedule.workspaceBytes = attentionBackwardWorkspaceBytes(schedule);
  return schedule;
}

// A checkpoint attribute is not a proof of an executable companion. Require
// reciprocal symbol references and validate the actual backward envelope and
// semantic operands before admitting a low-precision Apple forward recipe.
static bool hasAppleRecomputeVJP(Operation *op) {
  auto forward = op->getParentOfType<func::FuncOp>();
  auto module = op->getParentOfType<ModuleOp>();
  if (!forward || !module) return false;
  auto ref = forward->getAttrOfType<FlatSymbolRefAttr>("tessera.vjp");
  auto backward = ref ? module.lookupSymbol<func::FuncOp>(ref.getValue())
                      : func::FuncOp();
  if (!backward || backward == forward) return false;
  auto primal = backward->getAttrOfType<FlatSymbolRefAttr>("tessera.primal");
  if (!primal || primal.getValue() != forward.getSymName()) return false;
  SmallVector<Operation *> candidates;
  backward.walk([&](Operation *candidate) {
    if (candidate->getName().getStringRef() == "tessera_attn.backward")
      candidates.push_back(candidate);
  });
  if (candidates.size() != 1) return false;
  Operation *vjp = candidates.front();
  if (failed(getAttentionBackwardSchedule(vjp)) ||
      forward.getNumArguments() != op->getNumOperands() ||
      backward.getNumArguments() != op->getNumOperands() + 1)
    return false;
  for (unsigned i = 0; i < op->getNumOperands(); ++i) {
    if (op->getOperand(i) != forward.getArgument(i) ||
        vjp->getOperand(i + 1) != backward.getArgument(i + 1) ||
        op->getOperand(i).getType() != vjp->getOperand(i + 1).getType())
      return false;
  }
  if (vjp->getOperand(0) != backward.getArgument(0)) return false;
  // A bias-free forward must pair with the canonical zero-bias VJP form.
  if (op->getNumOperands() == 3) {
    auto zero = vjp->getOperand(4).getDefiningOp<arith::ConstantOp>();
    auto values = zero ? dyn_cast<DenseFPElementsAttr>(zero.getValue())
                       : DenseFPElementsAttr();
    if (!values || !values.isSplat() ||
        !values.getSplatValue<llvm::APFloat>().isZero()) return false;
  }
  for (StringRef name : {"causal", "window_left", "window_right", "dropout_seed"})
    if (!op->getAttr(name) || op->getAttr(name) != vjp->getAttr(name))
      return false;
  for (StringRef name : {"scale", "softcap", "dropout_p"}) {
    auto a = op->getAttrOfType<FloatAttr>(name);
    auto b = vjp->getAttrOfType<FloatAttr>(name);
    if (!a || !b || !a.getValue().isFinite() || !b.getValue().isFinite() ||
        static_cast<float>(a.getValueAsDouble()) !=
            static_cast<float>(b.getValueAsDouble())) return false;
  }
  return true;
}

static std::string
attentionBackwardScheduleDigest(const AttentionBackwardSchedule &schedule) {
  auto bits = [](double value) {
    return Twine(llvm::APFloat(static_cast<float>(value)).bitcastToAPInt().getZExtValue()).str();
  };
  std::string contract =
      (Twine("family=attention_backward;target=") + schedule.target +
       ";arch=" + schedule.arch + ";shape=" + Twine(schedule.batch) + "x" +
       Twine(schedule.queryHeads) + "x" + Twine(schedule.kvHeads) + "x" +
       Twine(schedule.queryRows) + "x" + Twine(schedule.keyRows) + "x" +
       Twine(schedule.headDim) + "x" + Twine(schedule.valueDim) +
       ";storage=" + schedule.storage + ";accum=f32;scale_bits=" +
       bits(schedule.scale) + ";causal=" +
       Twine(schedule.causal ? 1 : 0) + ";bias=" +
       Twine(schedule.bias ? 1 : 0) + ";window=" +
       Twine(schedule.windowLeft) + ":" + Twine(schedule.windowRight) +
       ";softcap_bits=" + bits(schedule.softcap) + ";dropout_bits=" +
       bits(schedule.dropoutP) + ";seed=" +
       Twine(schedule.dropoutSeed) + ";blocks=" +
       Twine(schedule.queryBlock) + "x" + Twine(schedule.keyBlock) +
       ";splits=" + Twine(schedule.splitCount) + ";reduce=0,1;workspace=" +
       Twine(schedule.workspaceBytes) + ";workgroup=" +
       Twine(schedule.workgroupSize) + ";recurrence=" + schedule.recurrence +
       ";lse_policy=" + schedule.lseCheckpointPolicy + ";lse_selection=" +
       schedule.lseCheckpointSelection)
          .str();
  return llvm::toHex(llvm::SHA256::hash(llvm::arrayRefFromStringRef(contract)),
                     /*LowerCase=*/true);
}

struct GraphToSchedulePass
    : public PassWrapper<GraphToSchedulePass, OperationPass<ModuleOp>> {

  MLIR_DEFINE_EXPLICIT_INTERNAL_INLINE_TYPE_ID(GraphToSchedulePass)

  GraphToSchedulePass() = default;
  GraphToSchedulePass(const GraphToSchedulePass &other) : PassWrapper(other) {}
  Option<bool> scaleTransposeWave{*this, "scale-transpose-wave",
      llvm::cl::desc("Use one 32-lane wave per scale-adjoint element"),
      llvm::cl::init(false)};
  Option<bool> scaleTransposeAuto{*this, "scale-transpose-auto",
      llvm::cl::desc("Select a bounded gfx1201 FP8 scale-adjoint recipe from native reduction SSA"),
      llvm::cl::init(false)};
  StringRef getArgument() const override { return "tessera-graph-to-schedule"; }
  StringRef getDescription() const override {
    return "Create a content-addressed mixed-level schedule.matmul SSA edge "
           "for bounded static x86-f32, ROCm-f16/f32, and Apple-GPU-f32 Graph "
           "matmul";
  }

  void getDependentDialects(DialectRegistry &registry) const override {
    registry.insert<attn::TesseraAttnDialect, schedule::ScheduleDialect, gpu::GPUDialect, arith::ArithDialect,
                    scf::SCFDialect, memref::MemRefDialect, vector::VectorDialect>();
  }

  void runOnOperation() override {
    ModuleOp mod = getOperation();
    if (mod->hasAttr("tessera.sparse_policy")) {
      if (failed(scheduleNativeSparse(mod))) signalPassFailure();
      return;
    }
    bool nativeRowSelected = false;
    if (failed(row_region::schedule(mod,nativeRowSelected))) return signalPassFailure();
    if (nativeRowSelected) return;
    bool scaleTransposeSelected = false;
    if (scaleTransposeWave && scaleTransposeAuto) {
      mod.emitError("scale transpose cannot request both explicit wave and automatic schedules");
      return signalPassFailure();
    }
    if (failed(scheduleNativeScaleTranspose(mod, scaleTransposeSelected,
                                           scaleTransposeWave, scaleTransposeAuto)))
      return signalPassFailure();
    if (scaleTransposeSelected) return;
    OpBuilder builder(mod.getContext());
    if (failed(scheduleNativeAbsolute(mod))) return signalPassFailure();
    if (failed(scheduleNativeX86Kernel(mod))) return signalPassFailure();
    if (failed(scheduleNativeROCMMath(mod))) return signalPassFailure();
    if (failed(scheduleNativeResultPermutation(mod))) return signalPassFailure();
    bool jvpSelected=false;
    if (failed(scheduleNativeAttentionJvp(mod,jvpSelected))) return signalPassFailure();
    if (jvpSelected) return;
    bool rowCorrectionSelected = false;
    if (failed(scheduleNativeRowCorrections(mod, rowCorrectionSelected))) return signalPassFailure();
    if (rowCorrectionSelected) return;
    if (failed(importSavedAttentionGraphs(mod)) ||
        failed(scheduleNativeCheckpoints(mod)) ||
        failed(scheduleNativeAttentionRecompute(mod))) return signalPassFailure();
    if (failed(scheduleNativeNVFP4Ingest(mod)) || failed(scheduleNativeMXFP4StorageIngest(mod))) return signalPassFailure();
    if (failed(scheduleNativePagedKV(mod))) return signalPassFailure();
    if (failed(scheduleNativeMoeDispatch(mod))) return signalPassFailure();

    SmallVector<Operation *> tridiagonalSolves;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "tessera.tridiagonal_solve")
        tridiagonalSolves.push_back(op);
    });
    for (Operation *op : tridiagonalSolves) {
      FailureOr<TridiagonalSchedule> selected = getTridiagonalSchedule(op);
      if (failed(selected)) {
        op->emitError(
            "REF-TIER-PHYS-1 requires a static fp32 tridiagonal system on "
            "Zen 5 AVX-512, or a power-of-two N<=256 system on gfx1151/gfx1201");
        return signalPassFailure();
      }
      std::string digest = tridiagonalScheduleDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(), "schedule.tridiagonal_solve");
      state.addOperands(op->getResult(0));
      state.addTypes(op->getResult(0).getType());
      state.addAttribute("artifact_hash", builder.getStringAttr(digest));
      state.addAttribute("arch", builder.getStringAttr(selected->arch));
      state.addAttribute("storage", builder.getStringAttr(selected->storage));
      state.addAttribute("accum", builder.getStringAttr(selected->accum));
      state.addAttribute("batch", builder.getI64IntegerAttr(selected->batch));
      state.addAttribute(
          "system_size", builder.getI64IntegerAttr(selected->systemSize));
      state.addAttribute(
          "workgroup_size", builder.getI64IntegerAttr(selected->workgroupSize));
      state.addAttribute("algorithm", builder.getStringAttr(selected->algorithm));
      Operation *scheduled = builder.create(state);
      for (OpOperand &use :
           llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled)
          use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifact(op->getLoc(), "schedule.artifact");
      artifact.addAttribute("hash", builder.getStringAttr(digest));
      artifact.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifact.addAttribute(
          "shape_key",
          builder.getStringAttr((Twine("family=tridiagonal_solve;batch=") +
                                 Twine(selected->batch) + ";n=" +
                                 Twine(selected->systemSize))
                                    .str()));
      artifact.addAttribute(
          "tile",
          builder.getDictionaryAttr({builder.getNamedAttr(
              "workgroup_size",
              builder.getI64IntegerAttr(selected->workgroupSize))}));
      artifact.addAttribute(
          "numeric_policy",
          builder.getStringAttr((Twine(selected->storage) + "->" +
                                 selected->accum + ";algorithm=" +
                                 selected->algorithm)
                                    .str()));
      builder.create(artifact);
    }

    SmallVector<Operation *> coalitionButterflies;
    mod.walk([&](Operation *op) {
      StringRef name = op->getName().getStringRef();
      if (name == "tessera.game_subset_zeta" ||
          name == "tessera.game_subset_mobius" ||
          name == "tessera.game_superset_zeta" ||
          name == "tessera.game_superset_mobius")
        coalitionButterflies.push_back(op);
    });
    for (Operation *op : coalitionButterflies) {
      FailureOr<CoalitionButterflySchedule> selected =
          getCoalitionButterflySchedule(op);
      if (failed(selected)) {
        op->emitError(
            "REF-TIER-PHYS-1 requires a static power-of-two fp32 coalition "
            "axis on Zen 5 AVX-512, or an axis no larger than the 64 KiB "
            "gfx1151/gfx1201 fp64 LDS envelope");
        return signalPassFailure();
      }
      std::string digest = coalitionButterflyDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(), "schedule.coalition_butterfly");
      state.addOperands(op->getResult(0));
      state.addTypes(op->getResult(0).getType());
      state.addAttribute("artifact_hash", builder.getStringAttr(digest));
      state.addAttribute("arch", builder.getStringAttr(selected->arch));
      state.addAttribute("storage", builder.getStringAttr(selected->storage));
      state.addAttribute("accum", builder.getStringAttr(selected->accum));
      state.addAttribute("batch", builder.getI64IntegerAttr(selected->batch));
      state.addAttribute(
          "lattice_size", builder.getI64IntegerAttr(selected->latticeSize));
      state.addAttribute("players",
                         builder.getI64IntegerAttr(selected->players));
      state.addAttribute("half", builder.getI64IntegerAttr(selected->half));
      state.addAttribute("sign", builder.getI64IntegerAttr(selected->sign));
      state.addAttribute(
          "workgroup_size", builder.getI64IntegerAttr(selected->workgroupSize));
      state.addAttribute("stage_order",
                         builder.getStringAttr(selected->stageOrder));
      Operation *scheduled = builder.create(state);
      for (OpOperand &use :
           llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled)
          use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifact(op->getLoc(), "schedule.artifact");
      artifact.addAttribute("hash", builder.getStringAttr(digest));
      artifact.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifact.addAttribute(
          "shape_key",
          builder.getStringAttr((Twine("family=coalition_butterfly;batch=") +
                                 Twine(selected->batch) + ";size=" +
                                 Twine(selected->latticeSize) + ";half=" +
                                 Twine(selected->half) + ";sign=" +
                                 Twine(selected->sign))
                                    .str()));
      artifact.addAttribute(
          "tile",
          builder.getDictionaryAttr({builder.getNamedAttr(
              "workgroup_size",
              builder.getI64IntegerAttr(selected->workgroupSize))}));
      artifact.addAttribute(
          "numeric_policy",
          builder.getStringAttr((Twine(selected->storage) + "->" +
                                 selected->accum + ";stage_order=" +
                                 selected->stageOrder)
                                    .str()));
      builder.create(artifact);
    }

    SmallVector<Operation *> matmuls;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "tessera.matmul" ||
          op->getName().getStringRef() == "tessera.scaled_matmul")
        matmuls.push_back(op);
    });
    for (auto [instance, op] : llvm::enumerate(matmuls)) {
      // The digest identifies schedule content, while the binding identifies
      // the particular Graph SSA product that owns the artifact lifetime.
      // Equal schedules in one function (e.g. JVP terms) remain distinct.
      auto binding = builder.getStringAttr(
          (Twine("matmul-") + Twine(instance)).str());
      if (op->hasAttr("tessera.canonical_k_step")) {
        op->emitError("E2E-REAL-2 canonical tensor K-step must recover its "
                      "complete logical contraction before Graph->Schedule");
        return signalPassFailure();
      }
      FailureOr<MatmulSchedule> selected = getMatmulSchedule(op);
      if (failed(selected)) {
        op->emitError("E2E-REAL-2 Graph->Schedule requires static rank-2 "
                      "x86 f32/bf16->f32, ROCm f16->f32, NVIDIA f16/bf16->f32 or signed int4->i32, "
                      "or Apple-GPU f32->f32 "
                      "matmul with no transpose");
        return signalPassFailure();
      }
      std::string digest = scheduleDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      op->setAttr("schedule.artifact_binding", binding);
      // A performance fallback may happen, but never silently (#21a).
      if (!selected->splitKFallback.empty())
        op->emitWarning("ROCM_SPLIT_K_NOT_APPLIED: ")
            << selected->splitKFallback
            << "; scheduling the unsplit kernel (ROCM-SPLIT-K-1).";
      if (!selected->panelFallback.empty())
        op->emitWarning("ROCM_FP8_BLOCKSCALE_LDS_NOT_APPLIED: ")
            << selected->panelFallback
            << "; scheduling the register panel (ROCM-FP8-BLOCKSCALE-1).";

      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(), "schedule.matmul");
      state.addOperands(op->getResult(0));
      state.addTypes(op->getResult(0).getType());
      state.addAttribute("artifact_hash", builder.getStringAttr(digest));
      state.addAttribute("artifact_binding", binding);
      state.addAttribute("arch", builder.getStringAttr(selected->arch));
      state.addAttribute("tile_m", builder.getI64IntegerAttr(selected->tileM));
      state.addAttribute("tile_n", builder.getI64IntegerAttr(selected->tileN));
      state.addAttribute("tile_k", builder.getI64IntegerAttr(selected->tileK));
      state.addAttribute("macro_tile_m",
                         builder.getI64IntegerAttr(selected->macroTileM));
      state.addAttribute("macro_tile_n",
                         builder.getI64IntegerAttr(selected->macroTileN));
      state.addAttribute("warps", builder.getI64IntegerAttr(selected->warps));
      state.addAttribute("pipeline_depth",
                         builder.getI64IntegerAttr(selected->pipelineDepth));
      state.addAttribute("storage", builder.getStringAttr(selected->storage));
      state.addAttribute("storage_b", builder.getStringAttr(selected->storageB));
      state.addAttribute("block_k", builder.getI64IntegerAttr(selected->blockK));
      // Stated only when a split exists, so unsplit schedule IR is unchanged.
      if (selected->splitK > 1) {
        state.addAttribute("split_k",
                           builder.getI64IntegerAttr(selected->splitK));
        state.addAttribute("split_k_reduction",
                           builder.getStringAttr(selected->splitKReduction));
      }
      state.addAttribute("scale_k",
                         builder.getI64IntegerAttr(selected->scaleBlockK));
      state.addAttribute("scale_format",
                         builder.getStringAttr(selected->scaleFormat));
      state.addAttribute("physical_contract",
                         builder.getStringAttr(selected->physicalContract));
      if (selected->aRowStride > 0) {
        state.addAttribute("a_row_stride", builder.getI64IntegerAttr(selected->aRowStride));
        state.addAttribute("b_row_stride", builder.getI64IntegerAttr(selected->bRowStride));
      }
      // ROCM-FP8-BLOCKSCALE-1: stated only when the W8A8 contract set it.
      if (selected->scaleBlockN > 0)
        state.addAttribute("scale_n",
                           builder.getI64IntegerAttr(selected->scaleBlockN));
      if (selected->staging != "global")
        state.addAttribute("staging",
                           builder.getStringAttr(selected->staging));
      state.addAttribute("accum", builder.getStringAttr(selected->accum));
      state.addAttribute("bias", builder.getBoolAttr(selected->bias));
      state.addAttribute("activation",
                         builder.getStringAttr(selected->activation));
      state.addAttribute("residual", builder.getBoolAttr(selected->residual));
      state.addAttribute("output", builder.getStringAttr(selected->output));
      if (selected->nvfp4TransposeA || selected->typedTransposeA) state.addAttribute("transposeA", builder.getBoolAttr(true));
      if (selected->nvfp4TransposeB) state.addAttribute("transposeB", builder.getBoolAttr(true));
      state.addAttribute("a_layout", builder.getStringAttr("row_major"));
      state.addAttribute("b_layout", builder.getStringAttr(selected->bLayout));
      state.addAttribute("raster_order",
                         builder.getStringAttr(selected->rasterOrder));
      state.addAttribute("raster_group",
                         builder.getI64IntegerAttr(selected->rasterGroup));
      Operation *scheduled = builder.create(state);
      for (OpOperand &use : llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled)
          use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(digest));
      artifactState.addAttribute("binding", binding);
      artifactState.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifactState.addAttribute(
          "shape_key",
          builder.getStringAttr((Twine("M=") + Twine(selected->m) + ";N=" +
                                 Twine(selected->n) + ";K=" +
                                 Twine(selected->k) + ";dtype=" +
                                 selected->storage)
                                    .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({
                      builder.getNamedAttr(
                          "m", builder.getI64IntegerAttr(selected->tileM)),
                      builder.getNamedAttr(
                          "n", builder.getI64IntegerAttr(selected->tileN)),
                      builder.getNamedAttr(
                          "k", builder.getI64IntegerAttr(selected->tileK)),
                      builder.getNamedAttr(
                          "macro_m",
                          builder.getI64IntegerAttr(selected->macroTileM)),
                      builder.getNamedAttr(
                          "macro_n",
                          builder.getI64IntegerAttr(selected->macroTileN)),
                      builder.getNamedAttr(
                          "warps", builder.getI64IntegerAttr(selected->warps)),
                      builder.getNamedAttr(
                          "pipeline_depth",
                          builder.getI64IntegerAttr(selected->pipelineDepth)),
                  }));
      artifactState.addAttribute(
          "numeric_policy",
          builder.getStringAttr((Twine(selected->storage) + "->" +
                                 selected->accum)
                                    .str()));
      builder.create(artifactState);
    }

    SmallVector<Operation *> semanticKernels;
    mod.walk([&](Operation *op) {
      StringRef name = op->getName().getStringRef();
      bool norm = name == "tessera.rmsnorm" || name == "tessera.rmsnorm_safe" ||
                  name == "tessera.layer_norm";
      StringRef target = moduleString(mod, "tessera.target", "target");
      StringRef architecture = moduleString(mod, "tessera.arch", "arch");
      // x86 normalization is claimed only for an isolated native-package
      // request (the module names its launch bindings); a norm inside any
      // other x86 program passes through unchanged, as before.
      if ((name == "tessera.relu" && target == "nvidia_sm120") ||
          name == "tessera.softmax" || name == "tessera.reduce" ||
          (norm && (target == "nvidia_sm120" ||
                    (target == "rocm" && architecture == "gfx1201" &&
                     name == "tessera.rmsnorm") ||
                    (target == "x86" && mod->hasAttr("tessera.launch_bindings")))))
        semanticKernels.push_back(op);
    });
    for (Operation *op : semanticKernels) {
      FailureOr<SemanticKernelSchedule> selected = getSemanticKernelSchedule(op);
      if (failed(selected)) {
        op->emitError("E2E-REAL-6 Graph->Schedule requires a supported static "
                      "semantic-kernel contract for the selected target");
        return signalPassFailure();
      }
      std::string digest = semanticKernelDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(),
                           selected->family == "activation" ? "schedule.activation" :
                           selected->family == "norm" ? "schedule.norm" :
                           selected->family == "softmax" ? "schedule.softmax"
                                                         : "schedule.reduce");
      state.addOperands(op->getResult(0));
      state.addTypes(op->getResult(0).getType());
      state.addAttribute("artifact_hash", builder.getStringAttr(digest));
      state.addAttribute("arch", builder.getStringAttr(selected->arch));
      state.addAttribute("storage", builder.getStringAttr(selected->storage));
      state.addAttribute("accum", builder.getStringAttr(selected->accum));
      state.addAttribute("axis", builder.getI64IntegerAttr(selected->axis));
      state.addAttribute("workgroup_size",
                         builder.getI64IntegerAttr(selected->workgroupSize));
      if (selected->family == "activation") {
        state.addAttribute("kind", builder.getStringAttr(selected->kind));
        state.addAttribute("schedule", builder.getStringAttr(selected->reductionSchedule));
        state.addAttribute("nan_mode", builder.getStringAttr("propagate"));
        state.addAttribute("zero_mode", builder.getStringAttr(selected->storage == "f16" ? "positive" : "preserve"));
      } else if (selected->family == "norm") {
        state.addAttribute("schedule", builder.getStringAttr(selected->reductionSchedule));
        state.addAttribute("kind", builder.getStringAttr(selected->kind));
        state.addAttribute("epsilon", builder.getF32FloatAttr(selected->epsilon));
      } else if (selected->family == "softmax") {
        if (selected->reductionSchedule != "serial")
          state.addAttribute("schedule", builder.getStringAttr(selected->reductionSchedule));
        state.addAttribute("exp_mode", builder.getStringAttr(selected->expMode));
        state.addAttribute("ftz", builder.getBoolAttr(false));
      } else {
        state.addAttribute("kind", builder.getStringAttr(selected->kind));
        state.addAttribute("keepdims", builder.getBoolAttr(selected->keepdims));
        state.addAttribute("schedule", builder.getStringAttr(selected->reductionSchedule));
        state.addAttribute("nan_mode", builder.getStringAttr("propagate"));
        state.addAttribute("inner_is_one", builder.getBoolAttr(selected->inner == 1));
      }
      Operation *scheduled = builder.create(state);
      for (OpOperand &use : llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled)
          use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(digest));
      artifactState.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifactState.addAttribute(
          "shape_key",
          builder.getStringAttr((Twine("family=") + selected->family +
                                 ";storage=" + selected->storage +
                                 ";axis=" + Twine(selected->axis))
                                    .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({
                      builder.getNamedAttr("workgroup_size",
                                           builder.getI64IntegerAttr(selected->workgroupSize)),
                  }));
      artifactState.addAttribute(
          "numeric_policy",
          builder.getStringAttr((Twine(selected->storage) + "->" + selected->accum)
                                    .str()));
      builder.create(artifactState);
    }

    SmallVector<Operation *> ffts;
    mod.walk([&](Operation *op) {
      StringRef name = op->getName().getStringRef();
      if (name == "tessera.fft" || name == "tessera.ifft" ||
          name == "tessera.rfft" || name == "tessera.irfft")
        ffts.push_back(op);
    });
    for (Operation *op : ffts) {
      FailureOr<FFTSchedule> selected = getFFTSchedule(op);
      if (failed(selected)) {
        op->emitError(
            "E2E-REAL-FFT Graph->Schedule requires a static f32-pair FFT on "
            "Zen 5, gfx1151, or exact sm120 with an explicit supported "
            "spectral contract");
        return signalPassFailure();
      }
      std::string digest = fftScheduleDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(), "schedule.fft");
      state.addOperands(op->getResult(0));
      state.addTypes(op->getResult(0).getType());
      state.addAttribute("artifact_hash", builder.getStringAttr(digest));
      state.addAttribute("arch", builder.getStringAttr(selected->arch));
      state.addAttribute("mode", builder.getStringAttr(selected->mode));
      state.addAttribute("axis", builder.getI64IntegerAttr(selected->axis));
      state.addAttribute("length", builder.getI64IntegerAttr(selected->length));
      state.addAttribute("physical_length",
                         builder.getI64IntegerAttr(selected->physicalLength));
      state.addAttribute("batch", builder.getI64IntegerAttr(selected->batch));
      state.addAttribute("real_transform_policy",
                         builder.getStringAttr(selected->realTransformPolicy));
      state.addAttribute("hermitian_layout",
                         builder.getStringAttr(selected->hermitianLayout));
      state.addAttribute("hermitian_weight",
                         builder.getStringAttr(selected->hermitianWeight));
      state.addAttribute("inverse", builder.getBoolAttr(selected->inverse));
      state.addAttribute("normalization",
                         builder.getStringAttr(selected->normalization));
      state.addAttribute("scale", builder.getF32FloatAttr(selected->scale));
      state.addAttribute("storage",
                         builder.getStringAttr("complex64_interleaved_f32"));
      state.addAttribute("accum", builder.getStringAttr("f32"));
      state.addAttribute("radix_policy",
                         builder.getStringAttr(selected->radixPolicy));
      state.addAttribute("strategy", builder.getStringAttr(selected->strategy));
      state.addAttribute("algorithm", builder.getStringAttr(selected->algorithm));
      state.addAttribute("radix_sequence",
                         builder.getDenseI64ArrayAttr(selected->radixSequence));
      state.addAttribute("bluestein_m",
                         builder.getI64IntegerAttr(selected->bluesteinM));
      state.addAttribute("workspace_elems",
                         builder.getI64IntegerAttr(selected->workspaceElems));
      state.addAttribute("workspace_policy",
                         builder.getStringAttr(selected->workspacePolicy));
      state.addAttribute("residency", builder.getStringAttr(selected->residency));
      state.addAttribute("twiddle_layout",
                         builder.getStringAttr("interleaved_f32"));
      state.addAttribute("twiddle_policy",
                         builder.getStringAttr(selected->twiddlePolicy));
      state.addAttribute("deterministic", builder.getBoolAttr(true));
      state.addAttribute("kernel_family",
                         builder.getStringAttr(selected->kernelFamily));
      state.addAttribute("workgroup_size",
                         builder.getI64IntegerAttr(selected->workgroupSize));
      Operation *scheduled = builder.create(state);
      for (OpOperand &use : llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled)
          use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(digest));
      artifactState.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifactState.addAttribute(
          "shape_key",
          builder.getStringAttr(
              (Twine("family=fft;mode=") + selected->mode + ";batch=" +
               Twine(selected->batch) + ";length=" + Twine(selected->length))
                  .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({
                      builder.getNamedAttr(
                          "workgroup_size",
                          builder.getI64IntegerAttr(selected->workgroupSize)),
                      builder.getNamedAttr(
                          "workspace_elems",
                          builder.getI64IntegerAttr(selected->workspaceElems)),
                      builder.getNamedAttr(
                          "algorithm",
                          builder.getStringAttr(selected->algorithm)),
                      builder.getNamedAttr(
                          "workspace_policy",
                          builder.getStringAttr(selected->workspacePolicy)),
                      builder.getNamedAttr(
                          "residency",
                          builder.getStringAttr(selected->residency)),
                      builder.getNamedAttr(
                          "twiddle_policy",
                          builder.getStringAttr(selected->twiddlePolicy)),
                  }));
      artifactState.addAttribute(
          "numeric_policy",
          builder.getStringAttr(
              (Twine("complex64_interleaved_f32->f32;") +
               selected->strategy + ";" + selected->normalization)
                  .str()));
      builder.create(artifactState);
    }

    SmallVector<Operation *> spectralBackwards;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "tessera.spectral_backward")
        spectralBackwards.push_back(op);
    });
    for (Operation *op : spectralBackwards) {
      ModuleOp module = op->getParentOfType<ModuleOp>();
      StringRef configuredTarget = moduleString(module, "tessera.target", "target");
      StringRef configuredArch = moduleString(module, "tessera.arch", "arch");
      const bool x86 = configuredTarget == "x86" ||
                       configuredArch.contains("avx512") ||
                       configuredArch.contains("zen5");
      const bool rocm = configuredArch.contains("gfx1151") ||
                        configuredArch.contains("gfx1201");
      if (!x86 && !rocm) {
        op->emitError(
            "AD-TSOL-SPECTRAL-1 compound adjoints require an exact Zen 5, gfx1151 or gfx1201 profile");
        return signalPassFailure();
      }
      for (Type type : op->getOperandTypes()) {
        auto tensor = dyn_cast<RankedTensorType>(type);
        if (!tensor || !tensor.hasStaticShape()) {
          op->emitError("compound spectral adjoint scheduling requires static tensors");
          return signalPassFailure();
        }
      }
      op->setAttr("target", builder.getStringAttr(x86 ? "x86" : "rocm"));
      op->setAttr("arch", builder.getStringAttr(
                              x86 ? "zen5-avx512"
                                  : configuredArch.contains("gfx1201") ? "gfx1201"
                                                                        : "gfx1151"));
      op->setAttr("mutation_lineage",
                  builder.getStringAttr("inputs_immutable_outputs_fresh_v1"));
      if (!op->hasAttr("normalization"))
        op->setAttr("normalization", builder.getStringAttr("backward"));
      if (!op->hasAttr("spectrum_layout"))
        op->setAttr("spectrum_layout",
                    builder.getStringAttr(
                        op->getAttrOfType<StringAttr>("kind").getValue() ==
                                "tessera.spectral_filter"
                            ? "full_complex"
                            : "half_spectrum_nyquist_explicit"));
      if (!op->hasAttr("center"))
        op->setAttr("center", builder.getBoolAttr(false));
      if (!op->hasAttr("onesided"))
        op->setAttr("onesided", builder.getBoolAttr(true));
      if (!op->hasAttr("pad_mode"))
        op->setAttr("pad_mode", builder.getStringAttr("constant"));
      if (!op->hasAttr("axis_packing"))
        op->setAttr("axis_packing",
                    builder.getStringAttr("native_runtime_stride_descriptor_v1"));
      if (!op->hasAttr("window_broadcast")) {
        StringRef kind = op->getAttrOfType<StringAttr>("kind").getValue();
        op->setAttr("window_broadcast", builder.getStringAttr(
            kind == "tessera.stft" || kind == "tessera.istft"
                ? "trailing_batch_broadcast_v1"
                : "not_applicable"));
      }
      if (!op->hasAttr("numeric_policy")) {
        StringRef storage = "fp32";
        auto kind = op->getAttrOfType<StringAttr>("kind").getValue();
        unsigned storageOperand = kind == "tessera.istft" ? 2 : 1;
        if (storageOperand < op->getNumOperands()) {
          auto tensor = dyn_cast<RankedTensorType>(
              op->getOperand(storageOperand).getType());
          if (tensor) {
            Type element = tensor.getElementType();
            if (element.isF16()) storage = "fp16";
            else if (element.isBF16()) storage = "bf16";
          }
        }
        op->setAttr(
            "numeric_policy",
            builder.getDictionaryAttr({
                builder.getNamedAttr("storage", builder.getStringAttr(storage)),
                builder.getNamedAttr("accum", builder.getStringAttr("fp32")),
            }));
      }
      auto numericPolicy =
          op->getAttrOfType<DictionaryAttr>("numeric_policy");
      auto numericStorage = numericPolicy
                                ? numericPolicy.getAs<StringAttr>("storage")
                                : StringAttr();
      auto numericAccum = numericPolicy
                              ? numericPolicy.getAs<StringAttr>("accum")
                              : StringAttr();
      if (!numericStorage || !numericAccum ||
          (numericStorage.getValue() != "fp16" &&
           numericStorage.getValue() != "bf16" &&
           numericStorage.getValue() != "fp32") ||
          numericAccum.getValue() != "fp32") {
        op->emitError(
            "NUMERIC_POLICY_ACCUM_UNREALIZABLE: spectral butterfly chains "
            "require explicit fp16/bf16/fp32 storage with fp32 accumulation");
        return signalPassFailure();
      }
      op->setAttr(
          "input_signature",
          builder.getStringAttr(spectralBackwardTypeSignature(op->getOperands())));
      op->setAttr(
          "output_signature",
          builder.getStringAttr(spectralBackwardTypeSignature(op->getResults())));
      FailureOr<std::string> digest = spectralBackwardDigest(op);
      if (failed(digest)) {
        op->emitError("compound spectral adjoint has an incomplete semantic contract");
        return signalPassFailure();
      }
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(*digest));
      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(), "schedule.spectral_backward");
      state.addOperands(op->getResults());
      state.addTypes(op->getResultTypes());
      state.addAttribute("artifact_hash", builder.getStringAttr(*digest));
      for (StringRef name : {"target", "arch", "kind", "axis",
                             "logical_length", "normalization",
                             "spectrum_layout", "hop", "center", "onesided",
                             "pad_mode", "axis_packing", "window_broadcast", "output_length",
                             "input_signature", "output_signature",
                             "mutation_lineage", "numeric_policy"})
        if (Attribute attr = op->getAttr(name)) state.addAttribute(name, attr);
      Operation *scheduled = builder.create(state);
      for (auto [original, replacement] :
           llvm::zip(op->getResults(), scheduled->getResults()))
        for (OpOperand &use : llvm::make_early_inc_range(original.getUses()))
          if (use.getOwner() != scheduled) use.set(replacement);

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(*digest));
      artifactState.addAttribute("arch", op->getAttr("arch"));
      artifactState.addAttribute(
          "shape_key",
          builder.getStringAttr((Twine("family=spectral_backward;kind=") +
                                 op->getAttrOfType<StringAttr>("kind").getValue())
                                    .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({builder.getNamedAttr(
                      "output_count",
                      builder.getI64IntegerAttr(op->getNumResults()))}));
      artifactState.addAttribute(
          "numeric_policy",
          builder.getStringAttr((Twine("adjoint;") +
                                 op->getAttrOfType<StringAttr>("normalization")
                                     .getValue())
                                    .str()));
      builder.create(artifactState);
    }

    if (failed(scheduleIstftJvps(mod, builder))) return signalPassFailure();

    SmallVector<Operation *> esCorrections;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "tessera.es_low_rank_correction")
        esCorrections.push_back(op);
    });
    for (Operation *op : esCorrections) {
      ModuleOp module = op->getParentOfType<ModuleOp>();
      StringRef configuredArch = moduleString(module, "tessera.arch", "arch");
      if (configuredArch != "gfx1151" && configuredArch != "gfx1201" &&
          configuredArch != "zen5-avx512") {
        op->emitError("EGGROLL W2 is fail-closed outside exact gfx1151, gfx1201 and Zen 5 AVX-512 profiles");
        return signalPassFailure();
      }
      FailureOr<std::pair<std::string, std::string>> contract =
          esLowRankContract(op, configuredArch);
      if (failed(contract)) {
        op->emitError("EGGROLL W2 requires static f32 rank-1 Graph operands");
        return signalPassFailure();
      }
      auto x = cast<RankedTensorType>(op->getOperand(0).getType());
      int64_t rows = 1;
      for (int64_t dim : x.getShape().drop_front().drop_back()) rows *= dim;
      auto integer = [&](StringRef name, int64_t fallback) {
        auto attr = op->getAttrOfType<IntegerAttr>(name);
        return attr ? attr.getInt() : fallback;
      };
      auto boolean = [&](StringRef name, bool fallback) {
        auto attr = op->getAttrOfType<BoolAttr>(name);
        return attr ? attr.getValue() : fallback;
      };
      op->setAttr("schedule.artifact_hash",
                  builder.getStringAttr(contract->second));
      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(), "schedule.es_low_rank_correction");
      state.addOperands(op->getResult(0));
      state.addTypes(op->getResult(0).getType());
      state.addAttribute("artifact_hash", builder.getStringAttr(contract->second));
      state.addAttribute("lineage_payload", builder.getStringAttr(contract->first));
      state.addAttribute("arch", builder.getStringAttr(configuredArch));
      state.addAttribute("population", builder.getI64IntegerAttr(x.getDimSize(0)));
      state.addAttribute("rows_per_member", builder.getI64IntegerAttr(rows));
      state.addAttribute("in_dim", builder.getI64IntegerAttr(x.getShape().back()));
      state.addAttribute("out_dim",
                         builder.getI64IntegerAttr(integer("out_dim", -1)));
      state.addAttribute("rank", builder.getI64IntegerAttr(integer("rank", -1)));
      state.addAttribute("epoch", builder.getI64IntegerAttr(integer("epoch", 0)));
      state.addAttribute("sigma", builder.getF32FloatAttr(
          static_cast<float>(op->getAttrOfType<FloatAttr>("sigma")
                                 .getValueAsDouble())));
      state.addAttribute("antithetic",
                         builder.getBoolAttr(boolean("antithetic", true)));
      state.addAttribute("score", builder.getStringAttr("gaussian"));
      state.addAttribute("rng_algorithm", builder.getStringAttr(
          "splitmix64-philox4x32-boxmuller"));
      state.addAttribute("rng_version", builder.getI64IntegerAttr(1));
      state.addAttribute("storage", builder.getStringAttr("f32"));
      state.addAttribute("accum", builder.getStringAttr("f32"));
      state.addAttribute("workgroup_size", builder.getI64IntegerAttr(
          configuredArch.starts_with("gfx") ? 256 : 1));
      Operation *scheduled = builder.create(state);
      for (OpOperand &use :
           llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled) use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(contract->second));
      artifactState.addAttribute("arch", builder.getStringAttr(configuredArch));
      artifactState.addAttribute(
          "shape_key", builder.getStringAttr(
              (Twine("family=es_low_rank_correction;p=") +
               Twine(x.getDimSize(0)) + ";in=" + Twine(x.getShape().back()) +
               ";out=" + Twine(integer("out_dim", -1)) + ";rank=1")
                  .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({
                      builder.getNamedAttr(
                          "workgroup_size",
                          builder.getI64IntegerAttr(
                              configuredArch.starts_with("gfx") ? 256 : 1)),
                      builder.getNamedAttr("rng_version",
                                           builder.getI64IntegerAttr(1)),
                  }));
      artifactState.addAttribute(
          "numeric_policy", builder.getStringAttr("f32->f32;rank1"));
      builder.create(artifactState);
    }

    SmallVector<Operation *> depthAttentions;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "tessera.depth_attn")
        depthAttentions.push_back(op);
    });
    for (Operation *op : depthAttentions) {
      FailureOr<DepthAttentionSchedule> selected =
          getDepthAttentionSchedule(op);
      if (failed(selected)) {
        op->emitError(
            "BLOCK-ATTNRES-1 Graph->Schedule requires a static all-f32 "
            "depth-attention contract on gfx1151/gfx1201 or Zen 5 AVX-512");
        return signalPassFailure();
      }
      std::string digest = depthAttentionScheduleDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      builder.setInsertionPointAfter(op);
      auto scheduledOp = builder.create<schedule::DepthAttentionOp>(
          op->getLoc(), op->getResult(0).getType(), op->getResult(0),
          builder.getStringAttr(digest), builder.getStringAttr(selected->arch),
          builder.getStringAttr(selected->storage),
          builder.getStringAttr(selected->softmax),
          builder.getStringAttr(selected->accum),
          builder.getF64FloatAttr(selected->eps),
          builder.getI64IntegerAttr(selected->sourceCount),
          builder.getI64IntegerAttr(selected->rows),
          builder.getI64IntegerAttr(selected->width),
          builder.getI64IntegerAttr(selected->sourceTile),
          builder.getI64IntegerAttr(selected->workgroupSize),
          builder.getStringAttr(selected->statisticsRecurrence),
          builder.getStringAttr(selected->mergeRecurrence),
          builder.getBoolAttr(selected->reassociable));
      Operation *scheduled = scheduledOp.getOperation();
      for (OpOperand &use :
           llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled)
          use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(digest));
      artifactState.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifactState.addAttribute(
          "shape_key",
          builder.getStringAttr(
              (Twine("family=depth_attention;sources=") +
               Twine(selected->sourceCount) + ";rows=" +
               Twine(selected->rows) + ";width=" + Twine(selected->width) +
               ";storage=" + selected->storage)
                  .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({
                      builder.getNamedAttr(
                          "source_tile",
                          builder.getI64IntegerAttr(selected->sourceTile)),
                      builder.getNamedAttr(
                          "workgroup_size",
                          builder.getI64IntegerAttr(selected->workgroupSize)),
                  }));
      artifactState.addAttribute(
          "numeric_policy",
          builder.getStringAttr(
              (Twine(selected->storage) + "->" + selected->softmax + "->" +
               selected->accum + ";eps=" + std::to_string(selected->eps) +
               ";merge=" + selected->mergeRecurrence)
                  .str()));
      builder.create(artifactState);
    }

    SmallVector<Operation *> attentions;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "tessera.flash_attn")
        attentions.push_back(op);
    });
    for (Operation *op : attentions) {
      FailureOr<AttentionSchedule> selected = getAttentionSchedule(op);
      if (failed(selected)) {
        op->emitError(
            "E2E-REAL-5A Graph->Schedule requires a supported static rank-4 "
            "Zen 5 f32 or gfx1151 f16/bf16 attention contract");
        return signalPassFailure();
      }
      std::string digest = attentionScheduleDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      builder.setInsertionPointAfter(op);
      auto scheduledOp = builder.create<schedule::AttentionOp>(
          op->getLoc(), op->getResult(0).getType(), op->getResult(0),
          builder.getStringAttr(digest), builder.getStringAttr(selected->arch),
          builder.getStringAttr(selected->storage),
          builder.getStringAttr(selected->accum),
          builder.getF32FloatAttr(selected->scale),
          builder.getBoolAttr(selected->causal),
          builder.getBoolAttr(selected->bias),
          builder.getI64IntegerAttr(selected->windowLeft),
          builder.getI64IntegerAttr(selected->windowRight),
          builder.getF32FloatAttr(selected->softcap),
          builder.getF32FloatAttr(selected->dropoutP),
          builder.getI64IntegerAttr(selected->dropoutSeed),
          builder.getI64IntegerAttr(selected->tileQ),
          builder.getI64IntegerAttr(selected->tileKV),
          builder.getI64IntegerAttr(selected->workgroupSize),
          builder.getStringAttr(selected->recurrence),
          builder.getStringAttr(selected->backwardLsePolicy),
          builder.getStringAttr(selected->backwardLseSelection));
      Operation *scheduled = scheduledOp.getOperation();
      if (selected->outputStorage != "f32")
        scheduled->setAttr("output_storage", builder.getStringAttr(selected->outputStorage));
      if (!selected->biasShape.empty())
        scheduled->setAttr("bias_shape", builder.getDenseI64ArrayAttr(selected->biasShape));
      for (OpOperand &use : llvm::make_early_inc_range(op->getResult(0).getUses()))
        if (use.getOwner() != scheduled)
          use.set(scheduled->getResult(0));

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(digest));
      artifactState.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifactState.addAttribute(
          "shape_key",
          builder.getStringAttr(
              (Twine("family=attention;B=") + Twine(selected->batch) +
               ";Hq=" + Twine(selected->queryHeads) +
               ";Hkv=" + Twine(selected->kvHeads) +
               ";Sq=" + Twine(selected->queryRows) +
               ";Sk=" + Twine(selected->keyRows) +
               ";D=" + Twine(selected->headDim) +
               ";Dv=" + Twine(selected->valueDim) +
               ";storage=" + selected->storage)
                  .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({
                      builder.getNamedAttr(
                          "tile_q", builder.getI64IntegerAttr(selected->tileQ)),
                      builder.getNamedAttr(
                          "tile_kv", builder.getI64IntegerAttr(selected->tileKV)),
                      builder.getNamedAttr(
                          "workgroup_size",
                          builder.getI64IntegerAttr(selected->workgroupSize)),
                  }));
      artifactState.addAttribute(
          "numeric_policy",
          builder.getStringAttr(
              (Twine(selected->storage) + "->" + selected->accum +
               ";backward_lse=" + selected->backwardLsePolicy + ":" +
               selected->backwardLseSelection)
                  .str()));
      builder.create(artifactState);
    }

    SmallVector<Operation *> attentionBackwards;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "tessera_attn.backward")
        attentionBackwards.push_back(op);
    });
    for (Operation *op : attentionBackwards) {
      FailureOr<AttentionBackwardSchedule> selected =
          getAttentionBackwardSchedule(op);
      if (failed(selected)) {
        op->emitError(
            "E2E-REAL-5B Graph->Schedule requires the canonical static "
            "tensor-valued Zen 5 f32 or gfx1151 f16/bf16 attention VJP");
        return signalPassFailure();
      }
      std::string digest = attentionBackwardScheduleDigest(*selected);
      op->setAttr("schedule.artifact_hash", builder.getStringAttr(digest));
      builder.setInsertionPointAfter(op);
      OperationState state(op->getLoc(), "schedule.attention_backward");
      state.addOperands(op->getResults());
      state.addTypes(op->getResultTypes());
      state.addAttribute("artifact_hash", builder.getStringAttr(digest));
      state.addAttribute("arch", builder.getStringAttr(selected->arch));
      state.addAttribute("storage", builder.getStringAttr(selected->storage));
      state.addAttribute("accum", builder.getStringAttr(selected->accum));
      state.addAttribute("scale", builder.getF32FloatAttr(selected->scale));
      state.addAttribute("causal", builder.getBoolAttr(selected->causal));
      state.addAttribute("bias", builder.getBoolAttr(selected->bias));
      state.addAttribute("window_left",
                         builder.getI64IntegerAttr(selected->windowLeft));
      state.addAttribute("window_right",
                         builder.getI64IntegerAttr(selected->windowRight));
      state.addAttribute("softcap", builder.getF32FloatAttr(selected->softcap));
      state.addAttribute("dropout_p",
                         builder.getF32FloatAttr(selected->dropoutP));
      state.addAttribute("dropout_seed",
                         builder.getI64IntegerAttr(selected->dropoutSeed));
      state.addAttribute("query_block",
                         builder.getI64IntegerAttr(selected->queryBlock));
      state.addAttribute("key_block",
                         builder.getI64IntegerAttr(selected->keyBlock));
      state.addAttribute("split_count",
                         builder.getI64IntegerAttr(selected->splitCount));
      state.addAttribute("reduction_order",
                         builder.getDenseI64ArrayAttr({0, 1}));
      state.addAttribute("workspace_bytes",
                         builder.getI64IntegerAttr(selected->workspaceBytes));
      state.addAttribute("workgroup_size",
                         builder.getI64IntegerAttr(selected->workgroupSize));
      state.addAttribute("recurrence",
                         builder.getStringAttr(selected->recurrence));
      state.addAttribute(
          "lse_checkpoint_policy",
          builder.getStringAttr(selected->lseCheckpointPolicy));
      state.addAttribute(
          "lse_checkpoint_selection",
          builder.getStringAttr(selected->lseCheckpointSelection));
      Operation *scheduled = builder.create(state);
      for (auto [source, replacement] :
           llvm::zip_equal(op->getResults(), scheduled->getResults()))
        for (OpOperand &use : llvm::make_early_inc_range(source.getUses()))
          if (use.getOwner() != scheduled)
            use.set(replacement);

      builder.setInsertionPointAfter(scheduled);
      OperationState artifactState(op->getLoc(), "schedule.artifact");
      artifactState.addAttribute("hash", builder.getStringAttr(digest));
      artifactState.addAttribute("arch", builder.getStringAttr(selected->arch));
      artifactState.addAttribute(
          "shape_key",
          builder.getStringAttr(
              (Twine("family=attention_backward;B=") +
               Twine(selected->batch) + ";Hq=" +
               Twine(selected->queryHeads) + ";Hkv=" +
               Twine(selected->kvHeads) + ";Sq=" +
               Twine(selected->queryRows) + ";Sk=" +
               Twine(selected->keyRows) + ";D=" +
               Twine(selected->headDim) + ";Dv=" +
               Twine(selected->valueDim) + ";storage=" + selected->storage)
                  .str()));
      artifactState.addAttribute(
          "tile", builder.getDictionaryAttr({
                      builder.getNamedAttr(
                          "query_block",
                          builder.getI64IntegerAttr(selected->queryBlock)),
                      builder.getNamedAttr(
                          "key_block",
                          builder.getI64IntegerAttr(selected->keyBlock)),
                      builder.getNamedAttr(
                          "split_count",
                          builder.getI64IntegerAttr(selected->splitCount)),
                      builder.getNamedAttr(
                          "workspace_bytes",
                          builder.getI64IntegerAttr(selected->workspaceBytes)),
                      builder.getNamedAttr(
                          "workgroup_size",
                          builder.getI64IntegerAttr(selected->workgroupSize)),
                  }));
      artifactState.addAttribute(
          "numeric_policy",
          builder.getStringAttr(
              (Twine(selected->storage) + "->f32;lse=" +
               selected->lseCheckpointPolicy + ":" +
               selected->lseCheckpointSelection)
                  .str()));
      builder.create(artifactState);
    }
  }
};
} // anonymous namespace

// ---------------------------------------------------------------------------
// Schedule -> Tile — consume the mixed-level scheduled Graph matmul atomically.
// ---------------------------------------------------------------------------

namespace {
struct ScheduleToTilePass
    : public PassWrapper<ScheduleToTilePass, OperationPass<ModuleOp>> {

  MLIR_DEFINE_EXPLICIT_INTERNAL_INLINE_TYPE_ID(ScheduleToTilePass)

  ScheduleToTilePass() = default;
  ScheduleToTilePass(const ScheduleToTilePass &other) : PassWrapper(other) {}
  Option<std::string> ssdGPU{*this, "ssd-gpu", llvm::cl::desc("Cooperative SSD GPU backend (nvidia or rocm)"), llvm::cl::init("")};
  StringRef getArgument() const override { return "tessera-schedule-to-tile"; }
  StringRef getDescription() const override {
    return "Revalidate registered content-addressed Schedule decisions against "
           "retained Graph producers, emit launch-level Tile carriers, and lower "
           "the shared SSD recurrence to structured tensor loops";
  }

  void getDependentDialects(DialectRegistry &registry) const override {
    registry.insert<gpu::GPUDialect, arith::ArithDialect, bufferization::BufferizationDialect,
                    func::FuncDialect, LLVM::LLVMDialect, memref::MemRefDialect,
                    NVVM::NVVMDialect, scf::SCFDialect, math::MathDialect,
                    schedule::ScheduleDialect, tensor::TensorDialect>();
    registerTesseraDialects(registry);
    tile::registerTileDialect(registry);
#ifdef TESSERA_HAVE_NVIDIA_TARGET_IR
    registry.insert<tessera::nvidia::TesseraNVIDIADialect>();
#endif
  }

  void runOnOperation() override {
    ModuleOp mod = getOperation();
    if (!ssdGPU.empty()) {
      if (failed(lowerCooperativeSSD(mod, ssdGPU))) signalPassFailure();
      return;
    }
    bool nativeRowSelected = false;
    if (failed(row_region::lower(mod,nativeRowSelected))) return signalPassFailure();
    if (nativeRowSelected) return;
    bool scaleTransposeSelected = false;
    if (failed(lowerNativeScaleTranspose(mod, scaleTransposeSelected))) return signalPassFailure();
    if (scaleTransposeSelected) return;
    OpBuilder builder(mod.getContext());
    SmallVector<schedule::SparseMMAOp> sparseFragments;
    mod.walk([&](schedule::SparseMMAOp op) { sparseFragments.push_back(op); });
    for (auto op : sparseFragments) {
      builder.setInsertionPoint(op);
      OperationState state(op.getLoc(), "tile.sparse_mma");
      state.addOperands(op->getOperands());
      state.addTypes(op->getResultTypes());
      state.addAttributes(op->getAttrs());
      Operation *lowered = builder.create(state);
      op->getResult(0).replaceAllUsesWith(lowered->getResult(0));
      op.erase();
    }
    if (failed(lowerNativeAbsolute(mod))) return signalPassFailure();
    if (failed(lowerNativeX86Kernel(mod))) return signalPassFailure();
    if (failed(lowerNativeROCMMath(mod))) return signalPassFailure();
    if (failed(lowerNativeResultPermutation(mod))) return signalPassFailure();
    bool jvpSelected=false;
    if (failed(lowerNativeAttentionJvp(mod,jvpSelected))) return signalPassFailure();
    if (jvpSelected) return;
    bool rowCorrectionSelected = false;
    if (failed(lowerNativeRowCorrections(mod, rowCorrectionSelected))) return signalPassFailure();
    if (rowCorrectionSelected) return;
    if (failed(lowerNativeAttentionRecompute(mod)) ||
        failed(lowerNativeCheckpoints(mod))) return signalPassFailure();
    if (failed(lowerNativeNVFP4Ingest(mod)) || failed(lowerNativeMXFP4StorageIngest(mod))) return signalPassFailure();
    if (failed(lowerNativePagedKV(mod))) return signalPassFailure();
    if (failed(lowerNativeMoeDispatch(mod))) return signalPassFailure();
    if (failed(lowerNativeSSD(mod))) return signalPassFailure();

    SmallVector<Operation *> scheduledTridiagonalSolves;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "schedule.tridiagonal_solve")
        scheduledTridiagonalSolves.push_back(op);
    });
    for (Operation *scheduled : scheduledTridiagonalSolves) {
      Operation *graph = scheduled->getOperand(0).getDefiningOp();
      FailureOr<TridiagonalSchedule> selected =
          graph ? getTridiagonalSchedule(graph)
                : FailureOr<TridiagonalSchedule>(failure());
      auto hash = scheduled->getAttrOfType<StringAttr>("artifact_hash");
      auto arch = scheduled->getAttrOfType<StringAttr>("arch");
      auto storage = scheduled->getAttrOfType<StringAttr>("storage");
      auto accum = scheduled->getAttrOfType<StringAttr>("accum");
      auto batch = scheduled->getAttrOfType<IntegerAttr>("batch");
      auto systemSize = scheduled->getAttrOfType<IntegerAttr>("system_size");
      auto workgroup = scheduled->getAttrOfType<IntegerAttr>("workgroup_size");
      auto algorithm = scheduled->getAttrOfType<StringAttr>("algorithm");
      if (!graph || failed(selected) || !hash || !arch || !storage || !accum ||
          !batch || !systemSize || !workgroup || !algorithm ||
          tridiagonalScheduleDigest(*selected) != hash.getValue() ||
          arch.getValue() != selected->arch ||
          storage.getValue() != selected->storage ||
          accum.getValue() != selected->accum ||
          batch.getInt() != selected->batch ||
          systemSize.getInt() != selected->systemSize ||
          workgroup.getInt() != selected->workgroupSize ||
          algorithm.getValue() != selected->algorithm) {
        scheduled->emitError(
            "tridiagonal Schedule contract was altered or lost its Graph subject");
        return signalPassFailure();
      }
      auto graphHash =
          graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == hash.getValue())
          matchingArtifacts.push_back(artifact);
      });
      if (!graphHash || graphHash.getValue() != hash.getValue() ||
          matchingArtifacts.size() != 1) {
        scheduled->emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }

      Location loc = scheduled->getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto type = cast<RankedTensorType>(tensor.getType());
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer =
            builder.create<bufferization::ToBufferOp>(loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      SmallVector<Value> operands;
      for (Value value : graph->getOperands())
        operands.push_back(toPointer(value));
      auto outputType = cast<RankedTensorType>(graph->getResult(0).getType());
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      Value outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, outputBuffer);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      operands.push_back(
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger));
      operands.push_back(builder.create<arith::ConstantIntOp>(
          loc, selected->batch, 64));
      operands.push_back(builder.create<arith::ConstantIntOp>(
          loc, selected->systemSize, 64));
      OperationState kernel(loc, "tile.tridiagonal_solve_kernel");
      kernel.addOperands(operands);
      kernel.addAttribute("arch", arch);
      kernel.addAttribute("storage", storage);
      kernel.addAttribute("accum", accum);
      kernel.addAttribute("algorithm", algorithm);
      kernel.addAttribute("workgroup_size", workgroup);
      kernel.addAttribute("tessera.schedule_hash", hash);
      builder.create(kernel);
      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outputType, outputBuffer);
      scheduled->getResult(0).replaceAllUsesWith(result);
      scheduled->erase();
      if (graph->use_empty())
        graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<Operation *> scheduledButterflies;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "schedule.coalition_butterfly")
        scheduledButterflies.push_back(op);
    });
    for (Operation *scheduled : scheduledButterflies) {
      Operation *graph = scheduled->getOperand(0).getDefiningOp();
      FailureOr<CoalitionButterflySchedule> selected =
          graph ? getCoalitionButterflySchedule(graph)
                : FailureOr<CoalitionButterflySchedule>(failure());
      auto hash = scheduled->getAttrOfType<StringAttr>("artifact_hash");
      auto arch = scheduled->getAttrOfType<StringAttr>("arch");
      auto storage = scheduled->getAttrOfType<StringAttr>("storage");
      auto accum = scheduled->getAttrOfType<StringAttr>("accum");
      auto batch = scheduled->getAttrOfType<IntegerAttr>("batch");
      auto latticeSize = scheduled->getAttrOfType<IntegerAttr>("lattice_size");
      auto players = scheduled->getAttrOfType<IntegerAttr>("players");
      auto half = scheduled->getAttrOfType<IntegerAttr>("half");
      auto sign = scheduled->getAttrOfType<IntegerAttr>("sign");
      auto workgroup = scheduled->getAttrOfType<IntegerAttr>("workgroup_size");
      auto stageOrder = scheduled->getAttrOfType<StringAttr>("stage_order");
      if (!graph || failed(selected) || !hash || !arch || !storage || !accum ||
          !batch || !latticeSize || !players || !half || !sign || !workgroup ||
          !stageOrder || coalitionButterflyDigest(*selected) != hash.getValue() ||
          arch.getValue() != selected->arch ||
          storage.getValue() != selected->storage ||
          accum.getValue() != selected->accum || batch.getInt() != selected->batch ||
          latticeSize.getInt() != selected->latticeSize ||
          players.getInt() != selected->players || half.getInt() != selected->half ||
          sign.getInt() != selected->sign ||
          workgroup.getInt() != selected->workgroupSize ||
          stageOrder.getValue() != selected->stageOrder) {
        scheduled->emitError(
            "coalition butterfly Schedule contract was altered or lost its Graph subject");
        return signalPassFailure();
      }
      auto graphHash =
          graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == hash.getValue())
          matchingArtifacts.push_back(artifact);
      });
      if (!graphHash || graphHash.getValue() != hash.getValue() ||
          matchingArtifacts.size() != 1) {
        scheduled->emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }
      Location loc = scheduled->getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto inputType = cast<RankedTensorType>(graph->getOperand(0).getType());
      auto inputMemref =
          MemRefType::get(inputType.getShape(), inputType.getElementType());
      Value inputBuffer = builder.create<bufferization::ToBufferOp>(
          loc, inputMemref, graph->getOperand(0));
      Value inputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, inputBuffer);
      Value inputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), inputIndex);
      Value inputPointer =
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, inputInteger);
      auto outputType = cast<RankedTensorType>(graph->getResult(0).getType());
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      Value outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, outputBuffer);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      Value outputPointer =
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger);
      Value batchValue = builder.create<arith::ConstantIntOp>(
          loc, selected->batch, 64);
      Value sizeValue = builder.create<arith::ConstantIntOp>(
          loc, selected->latticeSize, 64);
      OperationState kernel(loc, "tile.coalition_butterfly_kernel");
      kernel.addOperands(
          {inputPointer, outputPointer, batchValue, sizeValue});
      kernel.addAttribute("arch", arch);
      kernel.addAttribute("storage", storage);
      kernel.addAttribute("accum", accum);
      kernel.addAttribute("players", players);
      kernel.addAttribute("half", half);
      kernel.addAttribute("sign", sign);
      kernel.addAttribute("workgroup_size", workgroup);
      kernel.addAttribute("stage_order", stageOrder);
      kernel.addAttribute("tessera.schedule_hash", hash);
      builder.create(kernel);
      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outputType, outputBuffer);
      scheduled->getResult(0).replaceAllUsesWith(result);
      scheduled->erase();
      if (graph->use_empty())
        graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::MatmulOp> scheduledMatmuls;
    mod.walk([&](schedule::MatmulOp op) { scheduledMatmuls.push_back(op); });
    // A Graph-facing tensor function is not a CUDA launch ABI.  The canonical
    // SM120 consumer therefore emits one sibling LLVM kernel with the proven
    // A/B/D/M/N/K ABI, then removes the now-consumed tensor wrapper once all
    // schedule records have been checked.  Other backends retain their
    // existing in-function carriers.
    SmallVector<func::FuncOp> consumedNvidiaGraphFunctions;
    for (schedule::MatmulOp scheduled : scheduledMatmuls) {
      Operation *graph = scheduled.getSubject().getDefiningOp();
      if (!graph ||
          (graph->getName().getStringRef() != "tessera.matmul" &&
           graph->getName().getStringRef() != "tessera.scaled_matmul") ||
          graph->getNumOperands() < 2 || graph->getNumOperands() > 4 ||
          graph->getNumResults() != 1) {
        scheduled.emitError(
            "E2E-REAL-2 requires subject to be the retained Graph matmul result");
        return signalPassFailure();
      }
      auto selected = getMatmulSchedule(graph);
      if (failed(selected) || scheduleDigest(*selected) != scheduled.getArtifactHash()) {
        scheduled.emitError(
            "scheduled decision does not match the retained Graph matmul contract");
        return signalPassFailure();
      }
      auto orientationMatches = [&](StringRef name, bool expected) {
        Attribute attr = scheduled->getAttr(name);
        if (!attr) return !expected;
        auto value = dyn_cast<BoolAttr>(attr);
        return value && value.getValue() == expected;
      };
      auto strideMatches = [&](StringRef key, int64_t expected) {
        auto attr = scheduled->getAttrOfType<IntegerAttr>(key);
        return expected == 0 ? !scheduled->hasAttr(key) : attr && attr.getInt() == expected;
      };
      if (!strideMatches("a_row_stride", selected->aRowStride) ||
          !strideMatches("b_row_stride", selected->bRowStride) ||
          scheduled.getTileMAttr().getInt() != selected->tileM ||
          scheduled.getTileNAttr().getInt() != selected->tileN ||
          scheduled.getTileKAttr().getInt() != selected->tileK ||
          scheduled.getMacroTileMAttr().getInt() != selected->macroTileM ||
          scheduled.getMacroTileNAttr().getInt() != selected->macroTileN ||
          scheduled.getWarpsAttr().getInt() != selected->warps ||
          scheduled.getPipelineDepthAttr().getInt() != selected->pipelineDepth ||
          scheduled.getStorage() != selected->storage ||
          scheduled.getStorageB() != selected->storageB ||
          scheduled.getBlockK() != selected->blockK ||
          scheduled.getSplitK() != selected->splitK ||
          scheduled.getSplitKReduction() != selected->splitKReduction ||
          scheduled.getScaleK() != selected->scaleBlockK ||
          scheduled.getScaleFormat() != selected->scaleFormat ||
          scheduled.getPhysicalContract() != selected->physicalContract ||
          scheduled.getScaleN() != selected->scaleBlockN ||
          scheduled.getStaging() != selected->staging ||
          scheduled.getAccum() != selected->accum ||
          scheduled.getBias() != selected->bias ||
          scheduled.getActivation() != selected->activation ||
          scheduled.getResidual() != selected->residual ||
          scheduled.getOutput() != selected->output ||
          scheduled.getArch() != selected->arch ||
          !orientationMatches("transposeA", selected->nvfp4TransposeA || selected->typedTransposeA) ||
          !orientationMatches("transposeB", selected->nvfp4TransposeB) ||
          scheduled.getALayout() != "row_major" ||
          scheduled.getBLayout() != selected->bLayout ||
          scheduled.getRasterOrder() != selected->rasterOrder ||
          scheduled.getRasterGroupAttr().getInt() != selected->rasterGroup) {
        scheduled.emitError("scheduled tile or numeric policy was altered after hashing");
        return signalPassFailure();
      }
      auto graphDigest = graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      Attribute rawBinding = scheduled->getAttr("artifact_binding");
      Attribute rawGraphBinding = graph->getAttr("schedule.artifact_binding");
      auto binding = dyn_cast_or_null<StringAttr>(rawBinding);
      // Legacy single-product carriers have no binding. A mixed or malformed
      // triple must not fall back to an unscoped content-hash lookup.
      if ((rawBinding || rawGraphBinding) &&
          (!binding || binding.getValue().empty() ||
           rawGraphBinding != binding)) {
        scheduled.emitError("matmul artifact binding does not match its Graph subject");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash() &&
            artifact->getAttr("binding") == rawBinding)
          matchingArtifacts.push_back(artifact);
      });
      if (!graphDigest || graphDigest.getValue() != scheduled.getArtifactHash() ||
          matchingArtifacts.size() != 1) {
        scheduled.emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();

      if (selected->target == "nvidia_sm120") {
        // Dynamic non-int4 schedules emit a registered Target IR boundary.
        // The pass declares that dialect up front when the NVIDIA component is
        // linked; loading a dialect here is forbidden during pass execution.
        if (selected->storage != "int4" &&
            !getContext().getLoadedDialect("tessera_nvidia")) {
          scheduled.emitError(
              "SM120 scheduled matmul requires the registered NVIDIA Target IR dialect");
          return signalPassFailure();
        }
        auto graphFunction = scheduled->getParentOfType<func::FuncOp>();
        if (!graphFunction) {
          scheduled.emitError("SM120 scheduled matmul requires a Graph func wrapper");
          return signalPassFailure();
        }
        // The explicit scheduled route uses the conservative crossover from
        // the retained SuperBear pruning packet: cases below 67.1M FLOPs are
        // tied, regress, or fail the low-variance gate; all measured 67.1M+
        // cases are low-variance wins. This is not a global selector promotion
        // (WSL cannot supply that authority); it prevents the canonical route
        // from choosing an unproven crossover.
        const __int128 sm120Work = static_cast<__int128>(2) * selected->m *
                                   selected->n * selected->k;
        const bool dynamicSm120 = selected->dynamicM || selected->dynamicN ||
                                  selected->dynamicK;
        const bool macroSm120Producer =
            selected->bLayout == "col_major" &&
            selected->m >= 32 && selected->n >= 32 &&
            selected->k >= 16 &&
            (selected->storage == "f16" || selected->storage == "bf16") &&
            selected->accum == "f32" &&
            sm120Work >= 67108864;
        const bool fusedEpilogue = selected->bias || selected->residual ||
                                   selected->activation != "none";
        const bool typedSm120Producer =
            selected->m > 0 && selected->n > 0 && selected->k > 0 &&
            selected->tileM == 16 && selected->tileN == 8 &&
            selected->tileK == 16 &&
            (selected->storage == "f16" || selected->storage == "bf16") &&
            selected->accum == "f32" &&
            (selected->output == "f32" || selected->output == "f16");
        const bool useMacroSm120Producer =
            macroSm120Producer && selected->k % 8 == 0 && !fusedEpilogue &&
            selected->output == "f32";
        // The bridge derives CTA geometry from this symbol suffix. A typed
        // tail uses 16x8 tiles even when its workload exceeds the macro cutoff.
        const bool macroKernelGeometry =
            macroSm120Producer && (useMacroSm120Producer || !typedSm120Producer);
        std::string epilogueSuffix;
        if (fusedEpilogue || selected->output == "f16")
          epilogueSuffix =
              (Twine("_fused_") + selected->storage + "_" +
               selected->activation + "_b" + Twine(selected->bias) + "_r" +
               Twine(selected->residual) +
               (selected->output == "f16" ? "_outf16" : ""))
                  .str();
        std::string kernelName =
            (graphFunction.getName() + epilogueSuffix +
             (dynamicSm120 && selected->bLayout == "row_major" ? "_row_rhs" : "") +
             (macroKernelGeometry ? "_macro_kernel" : "_kernel"))
                .str();
        if (selected->storage == "int4") kernelName = "tessera_tile_matmul_int4";
        if (selected->storage == "nvfp4") kernelName = "tessera_tile_matmul_nvfp4";
        if (selected->independentBatchCount > 0) kernelName = "tessera_tile_matmul_nvfp4_batched";
        if (SymbolTable::lookupSymbolIn(mod, kernelName)) {
          scheduled.emitError("SM120 scheduled matmul kernel symbol already exists");
          return signalPassFailure();
        }

        auto pointerType = LLVM::LLVMPointerType::get(&getContext());
        auto i64 = builder.getI64Type();
        SmallVector<Type> kernelInputs{pointerType, pointerType};
        const bool nvfp4 = selected->storage == "nvfp4";
        if (nvfp4) kernelInputs.append({pointerType, pointerType});
        if (selected->bias)
          kernelInputs.push_back(pointerType);
        if (selected->residual)
          kernelInputs.push_back(pointerType);
        kernelInputs.append({pointerType, i64, i64, i64});
        if (selected->independentBatchCount > 0) kernelInputs.append({i64, i64});
        if (dynamicSm120)
          kernelInputs.append({i64, i64, i64});
        auto kernelType = LLVM::LLVMFunctionType::get(
            LLVM::LLVMVoidType::get(&getContext()), kernelInputs, false);
        OpBuilder moduleBuilder(mod.getBody(), mod.getBody()->end());
        auto kernelFunction =
            LLVM::LLVMFuncOp::create(moduleBuilder, loc, kernelName, kernelType);
        kernelFunction->setAttr("nvvm.kernel", UnitAttr::get(&getContext()));
        Block *entry = kernelFunction.addEntryBlock(moduleBuilder);
        OpBuilder kernelBuilder(entry, entry->begin());
        auto mma = tile::TileMmaDescAttr::get(
            &getContext(), "auto", selected->tileM, selected->tileN,
            selected->tileK, selected->storage,
            selected->storageB.empty() ? selected->storage : selected->storageB,
            selected->accum, "row_major", "col_major",
            // ROCM-MACRO-K-TILE-1: kBlocks = blockK / instruction K. The
            // schedule states the K block; this is where it becomes the
            // descriptor field the generator reads.
            selected->blockK > 0 && selected->tileK > 0
                ? std::max<int64_t>(selected->blockK / selected->tileK, 1)
                : 1,
            nvfp4 ? 0 : selected->scaleBlockK,
            nvfp4 ? StringRef() : selected->scaleFormat);
        auto epilogue = tile::TileEpilogueAttr::get(
            &getContext(), selected->bias, selected->activation,
            selected->output);
        // Static tails retain their exact leading dimensions in tile.memory.
        // Logical bounds on the input views zero-fill incomplete MMA panels;
        // a bounded output store writes only the logical M/N envelope.
        const bool boundedStaticOutput =
            !dynamicSm120 && (selected->m % 16 != 0 || selected->n % 8 != 0);
        const bool boundedStaticInputs =
            boundedStaticOutput || (!dynamicSm120 && selected->k % 16 != 0);
        if (useMacroSm120Producer) {
          // NVIDIA owns this physical reuse boundary. One 128-thread CTA
          // computes a 32x32 output tile: four warps own 2x2 16x16 quadrants,
          // and each warp emits two adjacent m16n8 MMA tiles. A[32,16] and
          // B[16,32] are staged once per K panel and protected by CTA barriers.
          OperationState macroState(loc, "tessera_nvidia.macro_cta_matmul");
          macroState.addOperands(entry->getArguments());
          macroState.addAttribute("arch", kernelBuilder.getStringAttr("sm_120"));
          macroState.addAttribute("cta_m", kernelBuilder.getI64IntegerAttr(32));
          macroState.addAttribute("cta_n", kernelBuilder.getI64IntegerAttr(32));
          macroState.addAttribute("tile_m", kernelBuilder.getI64IntegerAttr(16));
          macroState.addAttribute("tile_n", kernelBuilder.getI64IntegerAttr(8));
          macroState.addAttribute("tile_k", kernelBuilder.getI64IntegerAttr(16));
          macroState.addAttribute("warps", kernelBuilder.getI64IntegerAttr(4));
          macroState.addAttribute(
              "warp_ownership",
              kernelBuilder.getStringAttr("quadrant_2x2_two_n_tiles"));
          macroState.addAttribute(
              "storage", kernelBuilder.getStringAttr(selected->storage));
          macroState.addAttribute(
              "accum", kernelBuilder.getStringAttr(selected->accum));
          macroState.addAttribute(
              "staging",
              kernelBuilder.getStringAttr(
                  dynamicSm120 ? "masked_scalar_shared_ab_16bit"
                               : "cp_async_shared_ab_16bit"));
          macroState.addAttribute("stages",
                                  kernelBuilder.getI64IntegerAttr(
                                      dynamicSm120 ? 1 : 2));
          macroState.addAttribute(
              "completion",
              kernelBuilder.getStringAttr(
                  dynamicSm120 ? "cta_barrier"
                               : "wait_group_0_cta_barrier"));
          macroState.addAttribute(
              "bounds", kernelBuilder.getStringAttr("zero_fill_mnk_tail"));
          macroState.addAttribute(
              "grid_order", kernelBuilder.getStringAttr("column_major_xy"));
          macroState.addAttribute(
              "tessera.schedule_hash",
              kernelBuilder.getStringAttr(scheduled.getArtifactHash()));
          macroState.addAttribute(
              "tessera.macro_tile_m",
              kernelBuilder.getI64IntegerAttr(selected->macroTileM));
          macroState.addAttribute(
              "tessera.macro_tile_n",
              kernelBuilder.getI64IntegerAttr(selected->macroTileN));
          kernelBuilder.create(macroState);
        } else if (typedSm120Producer) {
          // Canonical m16n8k16 schedules retain tensor-to-buffer provenance
          // through bounded pointer-backed views and typed fragment carries.
          // Macro CTA schedules use their separate shared-panel producer.
          auto tileType = tile::TileValueType::get(&getContext());
          auto typedMma = tile::TileMmaDescAttr::get(
              &getContext(), "mma_sync", selected->tileM, selected->tileN,
              selected->tileK, selected->storage,
            selected->storageB.empty() ? selected->storage : selected->storageB,
              selected->accum, "row_major", "col_major",
            // ROCM-MACRO-K-TILE-1: kBlocks = blockK / instruction K. The
            // schedule states the K block; this is where it becomes the
            // descriptor field the generator reads.
            selected->blockK > 0 && selected->tileK > 0
                ? std::max<int64_t>(selected->blockK / selected->tileK, 1)
                : 1,
            selected->scaleBlockK, selected->scaleFormat);
          SmallVector<StringAttr> laneReg{kernelBuilder.getStringAttr("laneid"),
                                          kernelBuilder.getStringAttr("reg")};
          auto aLayout = tile::TileLayoutAttr::get(
              &getContext(), {16, 16}, {16, 1}, laneReg, {}, {}, {}, 0,
              tile::TileSwizzleAttr());
          auto bLayout = tile::TileLayoutAttr::get(
              &getContext(), {16, 8}, {8, 1}, laneReg, {}, {}, {}, 0,
              tile::TileSwizzleAttr());
          auto aMemory = tile::TileMemoryLayoutAttr::get(
              &getContext(), "gmem", "row_major", dynamicSm120 ? 0 : selected->k);
          auto bMemory = tile::TileMemoryLayoutAttr::get(
              &getContext(), "gmem", selected->bLayout,
              dynamicSm120 ? 0 : (selected->bLayout == "row_major" ? selected->n : selected->k));
          auto dMemory = tile::TileMemoryLayoutAttr::get(
              &getContext(), "gmem", "row_major", dynamicSm120 ? 0 : selected->n);
          auto composed = [&](ArrayRef<int64_t> shape, ArrayRef<int64_t> strides) {
            auto leaf = [&](int64_t value) -> Attribute {
              return kernelBuilder.getI64IntegerAttr(value);
            };
            auto singleton = [&](int64_t value) {
              return kernelBuilder.getArrayAttr({leaf(value)});
            };
            auto basis = kernelBuilder.getArrayAttr({
                kernelBuilder.getArrayAttr({singleton(shape[0]), singleton(1)}),
                kernelBuilder.getArrayAttr({singleton(shape[1]), singleton(1)}),
            });
            return tile::TileComposedLayoutAttr::get(
                &getContext(), kernelBuilder.getArrayAttr({leaf(shape[0]), leaf(shape[1])}),
                kernelBuilder.getArrayAttr({leaf(strides[0]), leaf(strides[1])}),
                basis, {0, 0});
          };
          auto zero = arith::ConstantIntOp::create(kernelBuilder, loc, 0, 64);
          // The launch ABI uses ceil(N/8) by ceil(M/16) output tiles.  Carry the
          // resulting logical origins into the shared views/materializations;
          // the physical packer may then use only the proven linear base plus
          // its fixed per-lane fragment coordinates.
          OperationState coordinateState(
              loc, "tessera_nvidia.block_coordinate");
          coordinateState.addTypes({i64, i64});
          coordinateState.addAttribute(
              "arch", kernelBuilder.getStringAttr("sm_120"));
          coordinateState.addAttribute(
              "tile_m", kernelBuilder.getI64IntegerAttr(16));
          coordinateState.addAttribute(
              "tile_n", kernelBuilder.getI64IntegerAttr(8));
          coordinateState.addAttribute(
              "grid_order",
              kernelBuilder.getStringAttr("column_major_xy"));
          Operation *coordinates = kernelBuilder.create(coordinateState);
          Value rowBase = coordinates->getResult(0);
          Value colBase = coordinates->getResult(1);
          auto materialize = [&](tile::TileComposedLayoutAttr layout,
                                 ValueRange values) {
            OperationState state(loc, "tile.materialize_composed_layout");
            state.addOperands(values); state.addTypes(i64);
            state.addAttribute("layout", layout);
            return kernelBuilder.create(state)->getResult(0);
          };
          auto view = [&](Value base, Value linear, Value row, Value col,
                          Value rowBound, Value colBound, Value leadingDim,
                          tile::TileLayoutAttr layout,
                          tile::TileMemoryLayoutAttr memory) {
            OperationState state(loc, "tile.view");
            state.addOperands({base, linear, row, col});
            if (dynamicSm120)
              state.addOperands({rowBound, colBound, leadingDim});
            else if (boundedStaticInputs)
              state.addOperands({rowBound, colBound});
            state.addTypes(tileType);
            state.addAttribute("tile.layout", layout); state.addAttribute("tile.memory", memory);
            state.addAttribute("tile.linear_base", kernelBuilder.getUnitAttr());
            return kernelBuilder.create(state)->getResult(0);
          };
          // NUMPOL-CARRIER-1: the fragment type's accumulator FOLLOWS the
          // schedule rather than restating it. `selected->accum` sat two
          // lines away from `selected->storage` and was ignored while the
          // literal "f32" was written three times — one fact, four copies,
          // and only the copies were reachable from the declared policy.
          // Every case selects "f32" today, so this is bit-identical; what it
          // removes is the place a future non-f32 schedule would silently
          // disagree with its own fragment types.
          auto aType = tile::FragmentType::get(&getContext(), 16, 8, 16, selected->storage, selected->accum, "a", "row_major", "mma_sync");
          auto bType = tile::FragmentType::get(&getContext(), 16, 8, 16, selected->storage, selected->accum, "b", "col_major", "mma_sync");
          auto cType = tile::FragmentType::get(&getContext(), 16, 8, 16, selected->accum, selected->accum, "acc", "row_major", "mma_sync");
          auto pack = [&](Value source, Type type, StringRef role) {
            OperationState state(loc, "tile.fragment_pack"); state.addOperands(source); state.addTypes(type);
            state.addAttribute("role", kernelBuilder.getStringAttr(role)); state.addAttribute("mma", typedMma);
            if (role == "b" && selected->bLayout == "row_major")
              state.addAttribute("transpose", kernelBuilder.getUnitAttr());
            return kernelBuilder.create(state)->getResult(0);
          };
          OperationState zeroState(loc, "tile.fragment_zero"); zeroState.addTypes(cType);
          zeroState.addAttribute("role", kernelBuilder.getStringAttr("acc")); zeroState.addAttribute("mma", typedMma);
          Value c = kernelBuilder.create(zeroState)->getResult(0);
          unsigned dIndex = 2 + unsigned(selected->bias) +
                            unsigned(selected->residual);
          Value runtimeM = entry->getArgument(dIndex + 1);
          Value runtimeN = entry->getArgument(dIndex + 2);
          Value runtimeK = entry->getArgument(dIndex + 3);
          Value lda = dynamicSm120 ? entry->getArgument(dIndex + 4)
                                   : Value(arith::ConstantIntOp::create(kernelBuilder, loc, selected->k, 64));
          Value ldb = dynamicSm120 ? entry->getArgument(dIndex + 5)
                                   : Value(arith::ConstantIntOp::create(kernelBuilder, loc, selected->k, 64));
          Value ldd = dynamicSm120 ? entry->getArgument(dIndex + 6)
                                   : Value(arith::ConstantIntOp::create(kernelBuilder, loc, selected->n, 64));
          auto dynamicComposed = [&](bool columnMajor) {
            auto leaf = [&](int64_t value) -> Attribute {
              return kernelBuilder.getI64IntegerAttr(value);
            };
            auto singleton = [&](int64_t value) {
              return kernelBuilder.getArrayAttr({leaf(value)});
            };
            auto basis = kernelBuilder.getArrayAttr({
                kernelBuilder.getArrayAttr({singleton(-1), singleton(1)}),
                kernelBuilder.getArrayAttr({singleton(-1), singleton(1)}),
            });
            SmallVector<Attribute> outerStride = columnMajor
                ? SmallVector<Attribute>{singleton(1), singleton(-1)}
                : SmallVector<Attribute>{singleton(-1), singleton(1)};
            return tile::TileComposedLayoutAttr::get(
                &getContext(), kernelBuilder.getArrayAttr({singleton(-1), singleton(-1)}),
                kernelBuilder.getArrayAttr(outerStride),
                basis, {0, 0});
          };
          Value kLimit = dynamicSm120
              ? runtimeK
              : Value(arith::ConstantIntOp::create(kernelBuilder, loc, selected->k, 64));
          Value kStep = arith::ConstantIntOp::create(kernelBuilder, loc, 16, 64);
          auto kLoop = scf::ForOp::create(kernelBuilder, loc, zero, kLimit, kStep,
                                          ValueRange{c});
          {
            OpBuilder::InsertionGuard loopGuard(kernelBuilder);
            kernelBuilder.setInsertionPointToStart(kLoop.getBody());
            Value panel = kLoop.getInductionVar();
            Value carry = kLoop.getRegionIterArgs().front();
            auto aComposed = dynamicSm120
                ? dynamicComposed(false)
                : composed({selected->m, selected->k}, {selected->k, 1});
            auto bComposed = dynamicSm120
                ? dynamicComposed(selected->bLayout == "col_major")
                : (selected->bLayout == "row_major"
                    ? composed({selected->k, selected->n}, {selected->n, 1})
                    : composed({selected->k, selected->n}, {1, selected->k}));
            SmallVector<Value> aMaterialize{rowBase, panel};
            SmallVector<Value> bMaterialize{panel, colBase};
            if (dynamicSm120) {
              // Canonical dynamic-leaf order is outer shapes, outer strides,
              // then basis shapes.  The basis extents repeat the logical
              // bounds intentionally: mixed-radix identity is `coord % dim`,
              // never the old accidental `coord % 1` zero map.
              aMaterialize.append(
                  {runtimeM, runtimeK, lda, runtimeM, runtimeK});
              bMaterialize.append(
                  {runtimeK, runtimeN, ldb, runtimeK, runtimeN});
            }
            Value aTile = view(entry->getArgument(0),
                materialize(aComposed, aMaterialize), rowBase, panel,
                runtimeM, runtimeK, lda, aLayout, aMemory);
            Value bTile = view(entry->getArgument(1),
                materialize(bComposed, bMaterialize), panel, colBase,
                runtimeK, runtimeN, ldb, bLayout, bMemory);
            Value a = pack(aTile, aType, "a");
            Value b = pack(bTile, bType, "b");
            OperationState mmaState(loc, "tile.mma"); mmaState.addOperands({a, b, carry}); mmaState.addTypes(cType);
            mmaState.addAttribute("mma", typedMma); mmaState.addAttribute("tessera.schedule_hash", kernelBuilder.getStringAttr(scheduled.getArtifactHash()));
            mmaState.addAttribute("tessera.macro_tile_m", kernelBuilder.getI64IntegerAttr(selected->macroTileM));
            mmaState.addAttribute("tessera.macro_tile_n", kernelBuilder.getI64IntegerAttr(selected->macroTileN));
            Value next = kernelBuilder.create(mmaState)->getResult(0);
            scf::YieldOp::create(kernelBuilder, loc, next);
          }
          kernelBuilder.setInsertionPointAfter(kLoop);
          Value result = kLoop.getResult(0);
          OperationState unpackState(loc, "tile.fragment_unpack"); unpackState.addOperands(result); unpackState.addTypes(tileType);
          unpackState.addAttribute("tile.layout", bLayout); unpackState.addAttribute("mma", typedMma);
          Value outTile = kernelBuilder.create(unpackState)->getResult(0);
          OperationState storeState(loc, "tile.store");
          storeState.addOperands({outTile, entry->getArgument(dIndex), rowBase, colBase});
          if (dynamicSm120)
            storeState.addOperands({runtimeM, runtimeN, ldd});
          else if (boundedStaticOutput)
            storeState.addOperands({runtimeM, runtimeN});
          if (fusedEpilogue || selected->output == "f16") {
            storeState.addAttribute("tile.epilogue", epilogue);
            if (selected->bias)
              storeState.addOperands(entry->getArgument(2));
            if (selected->residual) {
              storeState.addOperands(entry->getArgument(2 + unsigned(selected->bias)));
              storeState.addAttribute("tile.residual", kernelBuilder.getBoolAttr(true));
              storeState.addAttribute("tile.epilogue_order",
                  kernelBuilder.getStringAttr("matmul_bias_activation_residual"));
            }
          }
          storeState.addAttribute("tile.layout", bLayout); storeState.addAttribute("tile.memory", dMemory);
          kernelBuilder.create(storeState);
        } else {
        OperationState kernelState(loc, "tile.matmul_kernel");
        kernelState.addOperands(entry->getArguments());
        kernelState.addAttribute("mma", mma);
        kernelState.addAttribute("epilogue", epilogue);
        if (selected->independentBatchCount > 0)
          kernelState.addAttribute("batching", kernelBuilder.getStringAttr(selected->sharedBatchLhs ? "shared_lhs" : selected->sharedBatchRhs ? "shared_rhs_rows" : "independent_rhs"));
        if (selected->storage == "nvfp4") {
          if (selected->nvfp4TransposeA) kernelState.addAttribute("transposeA", kernelBuilder.getBoolAttr(true));
          if (selected->nvfp4TransposeB) kernelState.addAttribute("transposeB", kernelBuilder.getBoolAttr(true));
          kernelState.addAttribute("tessera.storage_packed",
                                   kernelBuilder.getBoolAttr(true));
          kernelState.addAttribute("tessera.storage_container",
                                   kernelBuilder.getStringAttr("int8"));
          kernelState.addAttribute(
              "tessera.storage_pack",
              tile::TilePackedFormatAttr::get(
                  &getContext(), "nvfp4", "int8", 4, 2, "format_defined",
                  "nv_e2m1", "low_to_high"));
          kernelState.addAttribute("tessera.scale_vector_size",
                                   kernelBuilder.getI64IntegerAttr(16));
          kernelState.addAttribute("physical_contract",
                                   kernelBuilder.getStringAttr(
                                       "nvidia_sm120_nvfp4_blockscale_v1"));
        }
        if (selected->storage == "int4") {
          kernelState.addAttribute("tessera.storage_packed", kernelBuilder.getBoolAttr(true));
          kernelState.addAttribute("tessera.storage_container", kernelBuilder.getStringAttr("int8"));
          kernelState.addAttribute("tessera.storage_pack", tile::TilePackedFormatAttr::get(
              &getContext(), "int4", "int8", 4, 2, "signed_twos_complement",
              "twos_complement", "low_to_high"));
          auto format = tile::TilePackedFormatAttr::get(&getContext(), "int4", "int8", 4, 2,
              "signed_twos_complement", "twos_complement", "low_to_high");
          auto noScale = tile::TileScaleLayoutAttr::get(&getContext(), "none", 0, -1, "none", 0, 1, 0);
          kernelState.addAttribute("tessera.a_packed_view", tile::TilePackedPhysicalViewAttr::get(
              &getContext(), format, 1, {(selected->k + 1) / 2, 1}, 1, 0, noScale));
          kernelState.addAttribute("tessera.b_packed_view", tile::TilePackedPhysicalViewAttr::get(
              &getContext(), format, 0, {selected->n, 1}, 1, 0, noScale));
          kernelState.addAttribute("tessera.packing_axes", kernelBuilder.getDenseI64ArrayAttr({1, 0}));
          kernelState.addAttribute("tessera.packed_shapes", kernelBuilder.getDenseI64ArrayAttr(
              {selected->m, (selected->k + 1) / 2, (selected->k + 1) / 2, selected->n}));
        }
        kernelState.addAttribute(
            "warps", kernelBuilder.getI64IntegerAttr(
                         macroSm120Producer ? 4 : selected->warps));
        kernelState.addAttribute(
            "staging", kernelBuilder.getStringAttr(
                           macroSm120Producer ? "shared" : "global"));
        if (selected->residual) {
          kernelState.addAttribute("residual", kernelBuilder.getBoolAttr(true));
          kernelState.addAttribute(
              "epilogue_order",
              kernelBuilder.getStringAttr(
                  "matmul_bias_activation_residual"));
        }
        // A 16-byte cp.async vector may start at every row only when the
        // packed row stride is a multiple of eight 16-bit elements.  Ragged
        // K remains a valid macro-CTA case, but uses the masked scalar staging
        // path so alignment is a proof obligation rather than an assumption.
        if (macroSm120Producer && selected->k % 8 == 0) {
          kernelState.addAttribute("tessera.vectorized_shared_panel",
                                   kernelBuilder.getBoolAttr(true));
          kernelState.addAttribute("tessera.async_shared_panel",
                                   kernelBuilder.getBoolAttr(true));
        }
        kernelState.addAttribute(
            "numeric_policy",
            kernelBuilder.getDictionaryAttr({
                kernelBuilder.getNamedAttr("storage",
                                            kernelBuilder.getStringAttr(selected->storage)),
                kernelBuilder.getNamedAttr("accum",
                                            kernelBuilder.getStringAttr(selected->accum)),
            }));
        kernelState.addAttribute("tessera.canonical_k_loop",
                                 kernelBuilder.getBoolAttr(true));
        kernelState.addAttribute("tessera.tile_m",
                                 kernelBuilder.getI64IntegerAttr(selected->tileM));
        kernelState.addAttribute("tessera.tile_n",
                                 kernelBuilder.getI64IntegerAttr(selected->tileN));
        kernelState.addAttribute("tessera.tile_k",
                                 kernelBuilder.getI64IntegerAttr(selected->tileK));
        kernelState.addAttribute("tessera.macro_tile_m",
                                 kernelBuilder.getI64IntegerAttr(selected->macroTileM));
        kernelState.addAttribute("tessera.macro_tile_n",
                                 kernelBuilder.getI64IntegerAttr(selected->macroTileN));
        kernelState.addAttribute("tessera.pipeline_depth",
                                 kernelBuilder.getI64IntegerAttr(selected->pipelineDepth));
        kernelState.addAttribute("tessera.raster_order",
                                 kernelBuilder.getStringAttr(selected->rasterOrder));
        kernelState.addAttribute("tessera.raster_group",
                                 kernelBuilder.getI64IntegerAttr(selected->rasterGroup));
        kernelState.addAttribute("tessera.schedule_hash",
                                 kernelBuilder.getStringAttr(scheduled.getArtifactHash()));
        kernelBuilder.create(kernelState);
        }
        LLVM::ReturnOp::create(kernelBuilder, loc, ValueRange{});

        scheduled.getScheduled().replaceAllUsesWith(graph->getResult(0));
        scheduled.erase();
        for (schedule::ArtifactOp artifact : matchingArtifacts)
          artifact.erase();
        if (!llvm::is_contained(consumedNvidiaGraphFunctions, graphFunction))
          consumedNvidiaGraphFunctions.push_back(graphFunction);
        continue;
      }

      auto lhsType = cast<RankedTensorType>(graph->getOperand(0).getType());
      auto rhsType = cast<RankedTensorType>(graph->getOperand(1).getType());
      auto outType = cast<RankedTensorType>(graph->getResult(0).getType());
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor, RankedTensorType type) {
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer =
            builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer)
            .getResult();
      };
      Value lhsStorage = graph->getOperand(0), rhsStorage = graph->getOperand(1);
      if (selected->aRowStride > 0) {
        lhsStorage = foldedInputStorage(lhsStorage)->first;
        rhsStorage = foldedInputStorage(rhsStorage)->first;
      }
      Value a = toPointer(lhsStorage, cast<RankedTensorType>(lhsStorage.getType()));
      Value b = toPointer(rhsStorage, cast<RankedTensorType>(rhsStorage.getType()));
      Value lhsScalePointer, rhsScalePointer;
      if (selected->scaleBlockK > 0) {
        auto lhsScaleType = cast<RankedTensorType>(graph->getOperand(2).getType());
        auto rhsScaleType = cast<RankedTensorType>(graph->getOperand(3).getType());
        lhsScalePointer = toPointer(graph->getOperand(2), lhsScaleType);
        rhsScalePointer = toPointer(graph->getOperand(3), rhsScaleType);
      }
      // The fused epilogue is part of the launch contract on every native
      // target, not only NVIDIA: the Graph op's third operand is the per-column
      // bias (A/B/bias ABI order), carried as the kernel's third pointer.
      Value biasPointer;
      if (selected->bias) {
        auto biasType = cast<RankedTensorType>(graph->getOperand(2).getType());
        biasPointer = toPointer(graph->getOperand(2), biasType);
      }
      auto outputMemref =
          MemRefType::get(outType.getShape(), outType.getElementType());
      Value runtimeMIndex, runtimeNIndex, runtimeKIndex;
      if (selected->dynamicM)
        runtimeMIndex = builder.create<tensor::DimOp>(loc, graph->getOperand(0), 0);
      if (selected->dynamicN)
        runtimeNIndex = builder.create<tensor::DimOp>(loc, graph->getOperand(1), 1);
      if (selected->dynamicK)
        runtimeKIndex = builder.create<tensor::DimOp>(loc, graph->getOperand(0), 1);
      SmallVector<Value> outputDynamicSizes;
      if (outType.isDynamicDim(0))
        outputDynamicSizes.push_back(runtimeMIndex);
      if (outType.isDynamicDim(1))
        outputDynamicSizes.push_back(runtimeNIndex);
      Value output = builder.create<memref::AllocOp>(
          loc, outputMemref, outputDynamicSizes);
      Value outputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, output);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      Value d = builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger);
      auto extentI64 = [&](bool dynamic, Value runtimeIndex, int64_t bound) {
        if (dynamic)
          return Value(builder.create<arith::IndexCastOp>(
              loc, builder.getI64Type(), runtimeIndex));
        return Value(builder.create<arith::ConstantIntOp>(loc, bound, 64));
      };
      Value m = extentI64(selected->dynamicM, runtimeMIndex, selected->m);
      Value n = extentI64(selected->dynamicN, runtimeNIndex, selected->n);
      Value k = extentI64(selected->dynamicK, runtimeKIndex, selected->k);

      StringRef family = selected->target == "rocm" ? "wmma" : "auto";
      auto mma = tile::TileMmaDescAttr::get(
          &getContext(), family, selected->tileM, selected->tileN,
          selected->tileK, selected->storage == "u8" ? "u8" : selected->storage,
          // B's own storage when the schedule named one. The x86 u8 x i8
          // recipe was already a mixed pair here; RDNA4's FP8 pairs are the
          // second, and now they come from the schedule rather than a special
          // case.
          selected->storage == "u8" ? "i8"
          : selected->storageB.empty() ? selected->storage
                                       : selected->storageB,
          selected->accum, "row_major", "col_major",
          // ROCM-MACRO-K-TILE-1: kBlocks = blockK / instruction K. The
          // schedule states the K block; this is where it becomes the
          // descriptor field the generator reads.
          selected->blockK > 0 && selected->tileK > 0
              ? std::max<int64_t>(selected->blockK / selected->tileK, 1)
              : 1,
          selected->scaleBlockK, selected->scaleFormat);
      auto epilogue = tile::TileEpilogueAttr::get(
          &getContext(), selected->bias, selected->activation,
          selected->scaleBlockK > 0 ? selected->output : selected->accum);

      const bool nvfp4 = selected->storage == "nvfp4";
      OperationState kernelState(
          loc, selected->scaleBlockK > 0 && !nvfp4
                   ? "tile.scaled_matmul_kernel"
                   : "tile.matmul_kernel");
      if (selected->scaleBlockK > 0)
        kernelState.addOperands(
            {a, b, lhsScalePointer, rhsScalePointer, d, m, n, k});
      else if (biasPointer)
        kernelState.addOperands({a, b, biasPointer, d, m, n, k});
      else
        kernelState.addOperands({a, b, d, m, n, k});
      if (selected->aRowStride > 0) {
        kernelState.addOperands({
            builder.create<arith::ConstantIntOp>(loc, selected->aRowStride, 64),
            builder.create<arith::ConstantIntOp>(loc, selected->bRowStride, 64)});
        kernelState.addAttribute("a_row_stride", builder.getI64IntegerAttr(selected->aRowStride));
        kernelState.addAttribute("b_row_stride", builder.getI64IntegerAttr(selected->bRowStride));
      }
      if (selected->target == "rocm" && selected->independentBatchCount > 0) {
        kernelState.addAttribute("batching", builder.getStringAttr(
            !selected->broadcastTypes.empty() ? "broadcast" :
            selected->sharedBatchLhs ? "shared_lhs" : "independent_rhs"));
        if (!selected->broadcastTypes.empty()) {
          SmallVector<Attribute> types;
          for (auto type : selected->broadcastTypes) types.push_back(TypeAttr::get(type));
          kernelState.addAttribute("batch_operands", builder.getArrayAttr(types));
          kernelState.addAttribute("batch_result", TypeAttr::get(selected->broadcastResult));
        }
        kernelState.addAttribute("batch_count", builder.getI64IntegerAttr(selected->independentBatchCount));
      }
      if (selected->typedTransposeA)
        kernelState.addAttribute("transposeA", builder.getBoolAttr(true));
      kernelState.addAttribute("mma", mma);
      kernelState.addAttribute("epilogue", epilogue);
      kernelState.addAttribute("warps",
                               builder.getI64IntegerAttr(selected->warps));
      // "lds" only for the W8A8 LDS-staged body the Schedule selected.
      kernelState.addAttribute("staging",
                               builder.getStringAttr(selected->staging));
      if (nvfp4) {
        auto packed = tile::TilePackedFormatAttr::get(
            &getContext(), "nvfp4", "int8", 4, 2, "format_defined",
            "nv_e2m1", "low_to_high");
        kernelState.addAttribute("tessera.storage_packed",
                                 builder.getBoolAttr(true));
        kernelState.addAttribute("tessera.storage_container",
                                 builder.getStringAttr("int8"));
        kernelState.addAttribute("tessera.storage_pack", packed);
        kernelState.addAttribute("tessera.scale_vector_size",
                                 builder.getI64IntegerAttr(16));
        kernelState.addAttribute("physical_contract",
                                 builder.getStringAttr(selected->physicalContract));
      }
      if (selected->scaleBlockK > 0 && !nvfp4) {
        const bool foldedMxfp4 =
            selected->physicalContract == "rocm_mxfp4_w4a8_folded_row_pitched_v1" ||
            selected->physicalContract == "rocm_mxfp4_w4a8_folded_prefill_v1" ||
            selected->physicalContract ==
                "rocm_mxfp4_w4a8_packed_folded_prefill_v1";
        kernelState.addAttribute(
            "partial_accumulator",
            builder.getDictionaryAttr({
                builder.getNamedAttr(
                    "scope", builder.getStringAttr(
                                 foldedMxfp4 ? "full_k" : "scale_group")),
                builder.getNamedAttr("init", builder.getStringAttr("zero")),
                builder.getNamedAttr(
                    "combine",
                    builder.getStringAttr(
                        foldedMxfp4 ? "row_reference_after_full_k"
                                     : "scale_outer_product_then_add")),
                builder.getNamedAttr(
                    "instruction_steps",
                    builder.getI64IntegerAttr(selected->scaleBlockK /
                                              selected->tileK)),
                builder.getNamedAttr(
                    "schedule_scope", builder.getStringAttr(
                                          foldedMxfp4 ? "k_stage"
                                                       : "scale_group")),
                builder.getNamedAttr("cross_step_motion",
                                     builder.getStringAttr("forbid")),
            }));
        if (!selected->physicalContract.empty())
          kernelState.addAttribute(
              "physical_contract",
              builder.getStringAttr(selected->physicalContract));
        // ROCM-FP8-BLOCKSCALE-1: the B scale's N block reaches the kernel,
        // which is the only place that indexes it.
        if (selected->scaleBlockN > 0)
          kernelState.addAttribute(
              "tessera.scale_block_n",
              builder.getI64IntegerAttr(selected->scaleBlockN));
        // The Target-IR directive is a package boundary rather than a hint.
        // Keep its problem extents self-contained for both logical inspection
        // and the exact physical package. Zero remains the existing sentinel
        // for a runtime-supplied dynamic extent; the gfx1201 physical contract
        // verifier deliberately admits only positive static values.
        kernelState.addAttribute("tessera.problem_m",
                                 builder.getI64IntegerAttr(selected->m));
        kernelState.addAttribute("tessera.problem_n",
                                 builder.getI64IntegerAttr(selected->n));
        kernelState.addAttribute("tessera.problem_k",
                                 builder.getI64IntegerAttr(selected->k));
      }
      SmallVector<NamedAttribute> numericPolicy = {
          builder.getNamedAttr("storage",
                               builder.getStringAttr(selected->storage)),
          builder.getNamedAttr("accum",
                               builder.getStringAttr(selected->accum)),
      };
      if (!selected->physicalContract.empty())
        numericPolicy.push_back(builder.getNamedAttr(
            "execution_mode",
            builder.getStringAttr(
                (selected->physicalContract ==
                     "rocm_mxfp4_w4a8_folded_row_pitched_v1" ||
                 selected->physicalContract ==
                     "rocm_mxfp4_w4a8_folded_prefill_v1" ||
                 selected->physicalContract ==
                     "rocm_mxfp4_w4a8_packed_folded_prefill_v1")
                    ? "folded_row_reference_explicit_approximate"
                    : "exact_per_block")));
      kernelState.addAttribute("numeric_policy",
                               builder.getDictionaryAttr(numericPolicy));
      kernelState.addAttribute("tessera.canonical_k_loop",
                               builder.getBoolAttr(true));
      kernelState.addAttribute("tessera.tile_m",
                               builder.getI64IntegerAttr(selected->tileM));
      kernelState.addAttribute("tessera.tile_n",
                               builder.getI64IntegerAttr(selected->tileN));
      kernelState.addAttribute("tessera.tile_k",
                               builder.getI64IntegerAttr(selected->tileK));
      kernelState.addAttribute(
          "tessera.macro_tile_m",
          builder.getI64IntegerAttr(selected->macroTileM));
      kernelState.addAttribute(
          "tessera.macro_tile_n",
          builder.getI64IntegerAttr(selected->macroTileN));
      kernelState.addAttribute("tessera.pipeline_depth",
                               builder.getI64IntegerAttr(selected->pipelineDepth));
      kernelState.addAttribute("tessera.raster_order",
                               builder.getStringAttr(selected->rasterOrder));
      kernelState.addAttribute("tessera.raster_group",
                               builder.getI64IntegerAttr(selected->rasterGroup));
      kernelState.addAttribute("tessera.schedule_hash",
                               builder.getStringAttr(scheduled.getArtifactHash()));
      // ROCM-SPLIT-K-1: the split and its reduction order reach the Tile
      // launch op as a pair. The epilogue attribute above still states the
      // PROGRAM's epilogue; a split consumer applies it once, in the ordered
      // reduction, never per slice.
      if (selected->splitK > 1) {
        kernelState.addAttribute("tessera.split_k",
                                 builder.getI64IntegerAttr(selected->splitK));
        kernelState.addAttribute(
            "tessera.split_k_reduction",
            builder.getStringAttr(selected->splitKReduction));
      }
      builder.create(kernelState);

      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outType, output);
      scheduled.getScheduled().replaceAllUsesWith(result);
      scheduled.erase();
      SmallVector<Operation *> consumedViews;
      if (selected->aRowStride > 0)
        for (Value value : graph->getOperands().take_front(2)) {
          Operation *view = value.getDefiningOp();
          if (view && !llvm::is_contained(consumedViews, view))
            consumedViews.push_back(view);
        }
      if (graph->use_empty())
        graph->erase();
      // The kernel now reads the parent storage. Retire only consumed, dead
      // view producers; retain any view still used by another Graph consumer.
      for (Operation *view : consumedViews)
        if (view->use_empty())
          view->erase();

      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }
    if (!consumedNvidiaGraphFunctions.empty()) {
      // Graph layout metadata is consumed when ScheduleToTile replaces the
      // Graph function with a kernel whose physical layout is carried by
      // tile.layout on its views, fragments, and stores. Record that
      // whole-module consumption for the metadata boundary verifier.
      SmallVector<NamedAttribute> dropped;
      if (auto existing = mod->getAttrOfType<DictionaryAttr>(
              "tessera.lowering.dropped")) {
        for (NamedAttribute entry : existing) {
          if (entry.getName().strref() == "layout") {
            auto reason = dyn_cast<StringAttr>(entry.getValue());
            if (!reason || reason.getValue() != "consumed_by_pass") {
              mod.emitError("ScheduleToTile cannot replace the existing layout metadata drop reason");
              return signalPassFailure();
            }
            continue;
          }
          dropped.push_back(entry);
        }
      }
      dropped.push_back(builder.getNamedAttr(
          "layout", builder.getStringAttr("consumed_by_pass")));
      mod->setAttr("tessera.lowering.dropped",
                   builder.getDictionaryAttr(dropped));
    }
    for (func::FuncOp graphFunction : consumedNvidiaGraphFunctions)
      graphFunction.erase();

    SmallVector<Operation *> scheduledKernels;
    mod.walk([&](Operation *op) {
      StringRef name = op->getName().getStringRef();
      if (name == "schedule.activation" || name == "schedule.softmax" || name == "schedule.reduce" || name == "schedule.norm")
        scheduledKernels.push_back(op);
    });
    for (Operation *scheduled : scheduledKernels) {
      bool isActivation = scheduled->getName().getStringRef() == "schedule.activation";
      bool isNorm = scheduled->getName().getStringRef() == "schedule.norm";
      bool isSoftmax = scheduled->getName().getStringRef() == "schedule.softmax";
      Operation *graph = scheduled->getOperand(0).getDefiningOp();
      if (!graph || graph->getNumOperands() != 1 || graph->getNumResults() != 1) {
        scheduled->emitError(
            "E2E-REAL-5 requires the retained Graph semantic-kernel result");
        return signalPassFailure();
      }
      auto selected = getSemanticKernelSchedule(graph);
      auto hash = scheduled->getAttrOfType<StringAttr>("artifact_hash");
      if (failed(selected) || !hash || semanticKernelDigest(*selected) != hash.getValue() ||
          (isActivation && selected->family != "activation") ||
          (isSoftmax && selected->family != "softmax") ||
          (isNorm && selected->family != "norm") ||
          (!isActivation && !isSoftmax && !isNorm && selected->family != "reduce")) {
        scheduled->emitError(
            "scheduled decision does not match the retained Graph kernel contract");
        return signalPassFailure();
      }
      auto attrString = [&](StringRef name) -> StringRef {
        if (auto attr = scheduled->getAttrOfType<StringAttr>(name)) return attr.getValue();
        return {};
      };
      auto attrInt = [&](StringRef name) -> std::optional<int64_t> {
        if (auto attr = scheduled->getAttrOfType<IntegerAttr>(name)) return attr.getInt();
        return std::nullopt;
      };
      auto attrBool = [&](StringRef name) -> std::optional<bool> {
        if (auto attr = scheduled->getAttrOfType<BoolAttr>(name)) return attr.getValue();
        return std::nullopt;
      };
      bool altered = attrString("arch") != selected->arch ||
                     attrString("storage") != selected->storage ||
                     attrString("accum") != selected->accum ||
                     attrInt("axis") != selected->axis ||
                     attrInt("workgroup_size") != selected->workgroupSize;
      if (isActivation) {
        altered = altered || attrString("kind") != "relu" ||
                  attrString("schedule") != selected->reductionSchedule || attrString("nan_mode") != "propagate" ||
                  attrString("zero_mode") != (selected->storage == "f16" ? "positive" : "preserve");
      } else if (isNorm) {
        auto eps = scheduled->getAttrOfType<FloatAttr>("epsilon");
        altered = altered || attrString("kind") != selected->kind ||
                  attrString("schedule") != selected->reductionSchedule ||
                  !eps || eps.getValueAsDouble() != selected->epsilon;
      } else if (isSoftmax)
        altered = altered || attrString("exp_mode") != selected->expMode ||
                  attrBool("ftz") != false ||
                  (attrString("schedule").empty() ? StringRef("serial") :
                   attrString("schedule")) != selected->reductionSchedule;
      else
        altered = altered || attrString("kind") != selected->kind ||
                  attrBool("keepdims") != selected->keepdims ||
                  attrString("schedule") != selected->reductionSchedule ||
                  attrString("nan_mode") != "propagate" ||
                  attrBool("inner_is_one") != (selected->inner == 1);
      if (altered) {
        scheduled->emitError(
            "scheduled semantic-kernel policy was altered after hashing");
        return signalPassFailure();
      }
      auto graphDigest = graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == hash.getValue()) matchingArtifacts.push_back(artifact);
      });
      if (!graphDigest || graphDigest.getValue() != hash.getValue() ||
          matchingArtifacts.size() != 1) {
        scheduled->emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }

      if (selected->target == "nvidia_sm120") {
        auto function = graph->getParentOfType<func::FuncOp>();
        if (!function || !llvm::hasSingleElement(function.getBody()) ||
            function.getNumArguments() != 1 || function.getNumResults() != 1 ||
            function.getBody().front().getOperations().size() != 4 ||
            graph->getOperand(0) != function.getArgument(0)) {
          scheduled->emitError("NVIDIA scheduled kernel requires one isolated unary function");
          return signalPassFailure();
        }
        auto ret = dyn_cast<func::ReturnOp>(function.getBody().front().back());
        if (!ret || ret.getNumOperands() != 1 ||
            ret.getOperand(0) != scheduled->getResult(0)) {
          scheduled->emitError("NVIDIA scheduled kernel must be the function result");
          return signalPassFailure();
        }
        // Preserve the established runtime launch symbols and serial schedule.
        std::string name = isActivation ? (Twine("tessera_tile_activation_relu_") + selected->storage + (selected->reductionSchedule == "flat_128" ? "_flat_128_" : "_") + hash.getValue().take_front(10)).str() : isNorm ? (Twine("tessera_tile_norm_") + selected->kind + "_" + selected->storage + (selected->reductionSchedule == "serial" ? "_" : "_cooperative_128_") + hash.getValue().take_front(10)).str() : isSoftmax ? (Twine("tessera_tile_softmax_") + selected->storage +
            (selected->reductionSchedule == "serial" ? "" : "_cooperative_128")).str() :
            (Twine("tessera_tile_reduce_") + selected->kind + "_" + selected->storage + "_" + selected->reductionSchedule).str();
        if (SymbolTable::lookupSymbolIn(mod, name)) {
          scheduled->emitError("NVIDIA scheduled kernel symbol already exists");
          return signalPassFailure();
        }
        Location loc = scheduled->getLoc();
        auto ptr = LLVM::LLVMPointerType::get(&getContext());
        auto i64 = builder.getI64Type();
        SmallVector<Type> inputs{ptr, ptr, i64, i64};
        if (!isActivation && !isSoftmax && !isNorm) inputs.push_back(i64);
        auto type = LLVM::LLVMFunctionType::get(
            LLVM::LLVMVoidType::get(&getContext()), inputs, false);
        OpBuilder mb(mod.getBody(), mod.getBody()->end());
        auto kernel = LLVM::LLVMFuncOp::create(mb, loc, name, type);
        kernel->setAttr("nvvm.kernel", mb.getUnitAttr());
        Block *entry = kernel.addEntryBlock(mb);
        OpBuilder kb(entry, entry->begin());
        OperationState state(loc, isActivation ? "tile.activation_kernel" : isNorm ? "tile.norm_kernel" : isSoftmax ? "tile.softmax_kernel" : "tile.reduce_kernel");
        state.addOperands(entry->getArguments());
        if (isNorm) state.addOperands(kb.create<arith::ConstantOp>(loc, kb.getF32FloatAttr(selected->epsilon)).getResult());
        for (StringRef key : {"storage", "accum", "axis"})
          state.addAttribute(key, scheduled->getAttr(key));
        if (isActivation) {
          for (StringRef key : {"kind", "schedule", "nan_mode", "zero_mode"})
            state.addAttribute(key, scheduled->getAttr(key));
        } else if (isNorm) {
          state.addAttribute("schedule", scheduled->getAttr("schedule"));
          state.addAttribute("kind", scheduled->getAttr("kind"));
          state.addAttribute("affine", kb.getBoolAttr(false));
          state.addAttribute("tessera.norm_epsilon", kb.getF32FloatAttr(selected->epsilon));
        } else if (isSoftmax) {
          if (scheduled->hasAttr("schedule"))
            state.addAttribute("schedule", scheduled->getAttr("schedule"));
          for (StringRef key : {"exp_mode", "ftz"})
            state.addAttribute(key, scheduled->getAttr(key));
        } else {
          for (StringRef key : {"kind", "keepdims", "schedule", "nan_mode", "inner_is_one"})
            state.addAttribute(key, scheduled->getAttr(key));
        }
        state.addAttribute("tessera.workgroup_size", kb.getI64IntegerAttr(128));
        state.addAttribute("tessera.schedule_hash", hash);
        kb.create(state);
        LLVM::ReturnOp::create(kb, loc, ValueRange{});
        // The isolated wrapper contains only the consumed Graph/Schedule pair,
        // its durable artifact and return. No executable sibling is discarded.
        function.erase();
        continue;
      }

      auto inputType = cast<RankedTensorType>(graph->getOperand(0).getType());
      auto outputType = cast<RankedTensorType>(graph->getResult(0).getType());
      Location loc = scheduled->getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto inputMemref = MemRefType::get(inputType.getShape(), inputType.getElementType());
      Value inputBuffer = builder.create<bufferization::ToBufferOp>(
          loc, inputMemref, graph->getOperand(0));
      Value inputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, inputBuffer);
      Value inputInteger =
          builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), inputIndex);
      Value inputPointer =
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, inputInteger);
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      Value outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, outputBuffer);
      Value outputInteger =
          builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), outputIndex);
      Value outputPointer =
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger);

      OperationState kernelState(
          loc, isNorm ? "tile.norm_kernel"
                      : isSoftmax ? "tile.softmax_kernel" : "tile.reduce_kernel");
      if (isNorm) {
        // x86 (E2E-REAL-6): the unweighted row-normalization ABI takes
        // (x, o, rows, cols, eps) with the epsilon the Schedule hashed.
        Value rows = builder.create<arith::ConstantIntOp>(loc, selected->rows, 64);
        Value columns =
            builder.create<arith::ConstantIntOp>(loc, selected->columns, 64);
        Value epsilon = builder.create<arith::ConstantOp>(
            loc, builder.getF32FloatAttr(selected->epsilon));
        kernelState.addOperands({inputPointer, outputPointer, rows, columns, epsilon});
        kernelState.addAttribute("kind", builder.getStringAttr(selected->kind));
        kernelState.addAttribute("storage", builder.getStringAttr(selected->storage));
        kernelState.addAttribute("accum", builder.getStringAttr(selected->accum));
        kernelState.addAttribute("axis", builder.getI64IntegerAttr(-1));
        kernelState.addAttribute("affine", builder.getBoolAttr(false));
      } else if (isSoftmax) {
        Value rows = builder.create<arith::ConstantIntOp>(loc, selected->rows, 64);
        Value columns =
            builder.create<arith::ConstantIntOp>(loc, selected->columns, 64);
        kernelState.addOperands({inputPointer, outputPointer, rows, columns});
        kernelState.addAttribute("storage", builder.getStringAttr(selected->storage));
        kernelState.addAttribute("accum", builder.getStringAttr(selected->accum));
        kernelState.addAttribute("axis", builder.getI64IntegerAttr(-1));
        kernelState.addAttribute("exp_mode", builder.getStringAttr("accurate"));
        kernelState.addAttribute("ftz", builder.getBoolAttr(false));
      } else {
        Value outer = builder.create<arith::ConstantIntOp>(loc, selected->outer, 64);
        Value extent =
            builder.create<arith::ConstantIntOp>(loc, selected->axisExtent, 64);
        Value inner = builder.create<arith::ConstantIntOp>(loc, selected->inner, 64);
        kernelState.addOperands(
            {inputPointer, outputPointer, outer, extent, inner});
        kernelState.addAttribute("storage", builder.getStringAttr(selected->storage));
        kernelState.addAttribute("accum", builder.getStringAttr(selected->accum));
        kernelState.addAttribute("kind", builder.getStringAttr(selected->kind));
        kernelState.addAttribute("axis", builder.getI64IntegerAttr(selected->axis));
        kernelState.addAttribute("keepdims", builder.getBoolAttr(selected->keepdims));
        kernelState.addAttribute("schedule", builder.getStringAttr("serial"));
        kernelState.addAttribute("nan_mode", builder.getStringAttr("propagate"));
        kernelState.addAttribute("inner_is_one",
                                 builder.getBoolAttr(selected->inner == 1));
      }
      kernelState.addAttribute("tessera.workgroup_size",
                               builder.getI64IntegerAttr(selected->workgroupSize));
      kernelState.addAttribute("tessera.schedule_hash", hash);
      builder.create(kernelState);

      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outputType, outputBuffer);
      scheduled->getResult(0).replaceAllUsesWith(result);
      scheduled->erase();
      if (graph->use_empty()) graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts) artifact.erase();
    }

    SmallVector<Operation *> scheduledSpectralBackwards;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "schedule.spectral_backward")
        scheduledSpectralBackwards.push_back(op);
    });
    for (Operation *scheduled : scheduledSpectralBackwards) {
      auto hash = scheduled->getAttrOfType<StringAttr>("artifact_hash");
      FailureOr<std::string> derived = spectralBackwardDigest(scheduled);
      if (failed(derived) || !hash || *derived != hash.getValue()) {
        scheduled->emitError(
            "scheduled spectral adjoint policy was altered after hashing");
        return signalPassFailure();
      }
      if (scheduled->getNumOperands() == 0) {
        scheduled->emitError("requires retained Graph spectral adjoint results");
        return signalPassFailure();
      }
      Operation *graph = scheduled->getOperand(0).getDefiningOp();
      if (!graph || graph->getName().getStringRef() !=
                        "tessera.spectral_backward") {
        scheduled->emitError("requires the retained Graph spectral adjoint");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == hash.getValue())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled->emitError("requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }

      Location loc = scheduled->getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto tensorPointer = [&](Value tensor) -> FailureOr<Value> {
        auto type = dyn_cast<RankedTensorType>(tensor.getType());
        if (!type || !type.hasStaticShape()) return failure();
        auto memref = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer =
            builder.create<bufferization::ToBufferOp>(loc, memref, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer)
            .getResult();
      };
      SmallVector<Value> launchOperands;
      for (Value input : graph->getOperands()) {
        FailureOr<Value> pointer = tensorPointer(input);
        if (failed(pointer)) {
          scheduled->emitError("requires static ranked adjoint inputs");
          return signalPassFailure();
        }
        launchOperands.push_back(*pointer);
      }
      SmallVector<Value> outputBuffers;
      for (Type type : scheduled->getResultTypes()) {
        auto tensor = dyn_cast<RankedTensorType>(type);
        if (!tensor || !tensor.hasStaticShape()) {
          scheduled->emitError("requires static ranked gradient outputs");
          return signalPassFailure();
        }
        auto memref = MemRefType::get(tensor.getShape(), tensor.getElementType());
        Value buffer = builder.create<memref::AllocOp>(loc, memref);
        outputBuffers.push_back(buffer);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        launchOperands.push_back(
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer));
      }

      OperationState kernelState(loc, "tile.spectral_backward_kernel");
      kernelState.addOperands(launchOperands);
      kernelState.addAttribute(
          "input_count", builder.getI64IntegerAttr(graph->getNumOperands()));
      kernelState.addAttribute(
          "output_count", builder.getI64IntegerAttr(scheduled->getNumResults()));
      for (StringRef name : {"target", "arch", "kind", "axis",
                             "logical_length", "normalization",
                             "spectrum_layout", "hop", "center", "onesided",
                             "pad_mode", "axis_packing", "window_broadcast", "output_length",
                             "input_signature", "output_signature",
                             "mutation_lineage", "numeric_policy"})
        if (Attribute attr = scheduled->getAttr(name))
          kernelState.addAttribute(name, attr);
      auto kindAttr = scheduled->getAttrOfType<StringAttr>("kind");
      auto axisAttr = scheduled->getAttrOfType<IntegerAttr>("axis");
      if (!kindAttr || !axisAttr) {
        scheduled->emitError(
            "native compound adjoints require explicit kind and axis");
        return signalPassFailure();
      }
      StringRef kind = kindAttr.getValue();
      auto ranked = [](Type type) { return dyn_cast<RankedTensorType>(type); };
      auto dyType = ranked(graph->getOperand(0).getType());
      auto inputType = ranked(graph->getOperand(1).getType());
      auto parameterType = ranked(graph->getOperand(2).getType());
      if (!dyType || !inputType || !parameterType) {
        scheduled->emitError(
            "native compound adjoints require static ranked operands");
        return signalPassFailure();
      }
      int64_t axis = axisAttr.getInt();
      if (axis < 0) axis += inputType.getRank();
      if ((kind == "tessera.spectral_filter" ||
           kind == "tessera.spectral_conv") &&
          axis != inputType.getRank() - 1) {
        scheduled->emitError("initial native compound adjoints require the last axis");
        return signalPassFailure();
      }
      auto isRealStorage = [](Type type) {
        return type.isF32() || type.isF16() || type.isBF16();
      };
      auto storageName = [&](Type type) -> StringRef {
        if (type.isF16()) return "f16";
        if (type.isBF16()) return "bf16";
        return "f32";
      };
      if (kind == "tessera.spectral_filter") {
        if (dyType.getRank() != inputType.getRank() ||
            inputType.getRank() != parameterType.getRank()) {
          scheduled->emitError(
              "native spectral-filter adjoint requires equal-rank operands");
          return signalPassFailure();
        }
        auto complex = dyn_cast<ComplexType>(inputType.getElementType());
        if (!complex || !complex.getElementType().isF32() ||
            inputType != parameterType || inputType != dyType) {
          scheduled->emitError("native spectral-filter adjoint requires identical complex<f32> tensors");
          return signalPassFailure();
        }
        kernelState.addAttribute(
            "elements", builder.getI64IntegerAttr(inputType.getNumElements()));
      } else if (kind == "tessera.spectral_conv") {
        if (dyType.getRank() != inputType.getRank() ||
            inputType.getRank() != parameterType.getRank()) {
          scheduled->emitError(
              "native spectral-conv adjoint requires equal-rank operands");
          return signalPassFailure();
        }
        int64_t inputLength = inputType.getDimSize(axis);
        int64_t parameterLength = parameterType.getDimSize(axis);
        int64_t cotangentLength = dyType.getDimSize(axis);
        int64_t batch = inputType.getNumElements() / inputLength;
        if (!inputType.getElementType().isF32() ||
            !parameterType.getElementType().isF32() ||
            !dyType.getElementType().isF32() ||
            cotangentLength != inputLength + parameterLength - 1 ||
            parameterType.getNumElements() / parameterLength != batch ||
            dyType.getNumElements() / cotangentLength != batch) {
          scheduled->emitError("native spectral-conv adjoint requires unbroadcast batched f32 full convolution");
          return signalPassFailure();
        }
        auto logicalLengthAttr =
            scheduled->getAttrOfType<IntegerAttr>("logical_length");
        auto normalizationAttr =
            scheduled->getAttrOfType<StringAttr>("normalization");
        if (!logicalLengthAttr || logicalLengthAttr.getInt() <= 0 ||
            !normalizationAttr) {
          scheduled->emitError(
              "native spectral-conv adjoint requires logical_length and normalization");
          return signalPassFailure();
        }
        int64_t logicalLength = logicalLengthAttr.getInt();
        StringRef normalization = normalizationAttr.getValue();
        double scale = normalization == "forward"
                           ? 1.0 / logicalLength
                           : normalization == "ortho"
                                 ? 1.0 / std::sqrt(double(logicalLength))
                                 : 1.0;
        kernelState.addAttribute("batch", builder.getI64IntegerAttr(batch));
        kernelState.addAttribute(
            "cotangent_length", builder.getI64IntegerAttr(cotangentLength));
        kernelState.addAttribute(
            "input_length", builder.getI64IntegerAttr(inputLength));
        kernelState.addAttribute(
            "parameter_length", builder.getI64IntegerAttr(parameterLength));
        kernelState.addAttribute(
            "normalization_scale", builder.getF32FloatAttr(scale));
      } else if (kind == "tessera.stft") {
        auto dyComplex = dyn_cast<ComplexType>(dyType.getElementType());
        auto logicalLengthAttr =
            scheduled->getAttrOfType<IntegerAttr>("logical_length");
        auto hopAttr = scheduled->getAttrOfType<IntegerAttr>("hop");
        auto normalizationAttr =
            scheduled->getAttrOfType<StringAttr>("normalization");
        auto centerAttr = scheduled->getAttrOfType<BoolAttr>("center");
        auto padModeAttr = scheduled->getAttrOfType<StringAttr>("pad_mode");
        auto onesidedAttr = scheduled->getAttrOfType<BoolAttr>("onesided");
        auto spectrumLayoutAttr =
            scheduled->getAttrOfType<StringAttr>("spectrum_layout");
        if (!dyComplex || !dyComplex.getElementType().isF32() ||
            !isRealStorage(inputType.getElementType()) ||
            inputType.getElementType() != parameterType.getElementType() ||
            parameterType.getRank() < 1 ||
            dyType.getRank() != inputType.getRank() + 1 ||
            !logicalLengthAttr || !hopAttr || !normalizationAttr ||
            !centerAttr || !padModeAttr || !onesidedAttr ||
            !spectrumLayoutAttr) {
          scheduled->emitError(
              "native STFT adjoint requires complex<f32> cotangents and "
              "matching f16/bf16/f32 signal/window storage");
          return signalPassFailure();
        }
        int64_t n = logicalLengthAttr.getInt();
        int64_t windowLength = parameterType.getDimSize(parameterType.getRank() - 1);
        int64_t hop = hopAttr.getInt();
        int64_t samples = inputType.getDimSize(axis);
        int64_t frames = dyType.getDimSize(axis);
        int64_t bins = dyType.getDimSize(axis + 1);
        int64_t batch = inputType.getNumElements() / samples;
        int64_t outer = 1, inner = 1;
        for (int64_t dim = 0; dim < axis; ++dim)
          outer *= inputType.getDimSize(dim);
        for (int64_t dim = axis + 1; dim < inputType.getRank(); ++dim)
          inner *= inputType.getDimSize(dim);
        int64_t pad = centerAttr.getValue() ? n / 2 : 0;
        int64_t framedSamples = std::max(samples + 2 * pad, n);
        int64_t expectedBins = onesidedAttr.getValue() ? n / 2 + 1 : n;
        StringRef expectedLayout = onesidedAttr.getValue()
                                       ? "half_spectrum_nyquist_explicit"
                                       : "full_complex";
        bool validPadMode = padModeAttr.getValue() == "constant" ||
                            padModeAttr.getValue() == "reflect";
        if (n <= 0 || windowLength <= 0 || windowLength > n || hop <= 0 ||
            bins != expectedBins || spectrumLayoutAttr.getValue() != expectedLayout ||
            frames != (framedSamples - n) / hop + 1 || !validPadMode ||
            (centerAttr.getValue() && padModeAttr.getValue() == "reflect" &&
             samples <= pad) ||
            dyType.getNumElements() != batch * frames * bins) {
          scheduled->emitError(
              "native STFT adjoint framing disagrees with the bounded policy");
          return signalPassFailure();
        }
        StringRef normalization = normalizationAttr.getValue();
        double scale = normalization == "forward"
                           ? 1.0 / n
                           : normalization == "ortho"
                                 ? 1.0 / std::sqrt(double(n))
                                 : 1.0;
        kernelState.addAttribute("batch", builder.getI64IntegerAttr(batch));
        kernelState.addAttribute("outer", builder.getI64IntegerAttr(outer));
        kernelState.addAttribute("inner", builder.getI64IntegerAttr(inner));
        kernelState.addAttribute("input_length",
                                 builder.getI64IntegerAttr(samples));
        kernelState.addAttribute("parameter_length",
                                 builder.getI64IntegerAttr(windowLength));
        kernelState.addAttribute("frames", builder.getI64IntegerAttr(frames));
        kernelState.addAttribute("bins", builder.getI64IntegerAttr(bins));
        kernelState.addAttribute(
            "storage",
            builder.getStringAttr(storageName(inputType.getElementType())));
        kernelState.addAttribute(
            "normalization_scale", builder.getF32FloatAttr(scale));
      } else if (kind == "tessera.istft") {
        auto inputComplex = dyn_cast<ComplexType>(inputType.getElementType());
        auto logicalLengthAttr =
            scheduled->getAttrOfType<IntegerAttr>("logical_length");
        auto hopAttr = scheduled->getAttrOfType<IntegerAttr>("hop");
        auto normalizationAttr =
            scheduled->getAttrOfType<StringAttr>("normalization");
        auto centerAttr = scheduled->getAttrOfType<BoolAttr>("center");
        auto outputLengthAttr =
            scheduled->getAttrOfType<IntegerAttr>("output_length");
        auto onesidedAttr = scheduled->getAttrOfType<BoolAttr>("onesided");
        auto spectrumLayoutAttr =
            scheduled->getAttrOfType<StringAttr>("spectrum_layout");
        if (!inputComplex || !inputComplex.getElementType().isF32() ||
            !isRealStorage(parameterType.getElementType()) ||
            dyType.getElementType() != parameterType.getElementType() ||
            parameterType.getRank() < 1 ||
            inputType.getRank() != dyType.getRank() + 1 ||
            !logicalLengthAttr || !hopAttr || !normalizationAttr ||
            !centerAttr || !outputLengthAttr || !onesidedAttr ||
            !spectrumLayoutAttr) {
          scheduled->emitError(
              "native ISTFT adjoint requires complex<f32> spectra and "
              "matching f16/bf16/f32 cotangent/window storage");
          return signalPassFailure();
        }
        int64_t n = logicalLengthAttr.getInt();
        int64_t windowLength = parameterType.getDimSize(parameterType.getRank() - 1);
        int64_t hop = hopAttr.getInt();
        int64_t frameAxis = axis - 1;
        int64_t frames = inputType.getDimSize(frameAxis);
        int64_t bins = inputType.getDimSize(axis);
        int64_t samples = dyType.getDimSize(frameAxis);
        int64_t batch = dyType.getNumElements() / samples;
        int64_t outer = 1, inner = 1;
        for (int64_t dim = 0; dim < axis - 1; ++dim)
          outer *= inputType.getDimSize(dim);
        for (int64_t dim = axis + 1; dim < inputType.getRank(); ++dim)
          inner *= inputType.getDimSize(dim);
        int64_t rawSamples = (frames - 1) * hop + n;
        int64_t trim = centerAttr.getValue() ? n / 2 : 0;
        int64_t available = rawSamples - 2 * trim;
        int64_t outputLength = outputLengthAttr.getInt();
        int64_t expectedBins = onesidedAttr.getValue() ? n / 2 + 1 : n;
        StringRef expectedLayout = onesidedAttr.getValue()
                                       ? "half_spectrum_nyquist_explicit"
                                       : "full_complex";
        if (n <= 0 || windowLength <= 0 || windowLength > n || hop <= 0 ||
            bins != expectedBins || spectrumLayoutAttr.getValue() != expectedLayout ||
            samples != outputLength || outputLength <= 0 ||
            outputLength > available ||
            inputType.getNumElements() != batch * frames * bins) {
          scheduled->emitError(
              "native ISTFT adjoint overlap-add disagrees with the bounded policy");
          return signalPassFailure();
        }
        StringRef normalization = normalizationAttr.getValue();
        double scale = normalization == "backward"
                           ? 1.0 / n
                           : normalization == "ortho"
                                 ? 1.0 / std::sqrt(double(n))
                                 : 1.0;
        kernelState.addAttribute("batch", builder.getI64IntegerAttr(batch));
        kernelState.addAttribute("outer", builder.getI64IntegerAttr(outer));
        kernelState.addAttribute("inner", builder.getI64IntegerAttr(inner));
        kernelState.addAttribute("cotangent_length",
                                 builder.getI64IntegerAttr(samples));
        kernelState.addAttribute("raw_length",
                                 builder.getI64IntegerAttr(rawSamples));
        kernelState.addAttribute("parameter_length",
                                 builder.getI64IntegerAttr(windowLength));
        kernelState.addAttribute("frames", builder.getI64IntegerAttr(frames));
        kernelState.addAttribute("bins", builder.getI64IntegerAttr(bins));
        kernelState.addAttribute(
            "storage",
            builder.getStringAttr(storageName(parameterType.getElementType())));
        kernelState.addAttribute(
            "normalization_scale", builder.getF32FloatAttr(scale));
      } else {
        scheduled->emitError(
            "compound spectral adjoint kind has no native package");
        return signalPassFailure();
      }
      kernelState.addAttribute("tessera.schedule_hash", hash);
      builder.create(kernelState);

      for (auto [result, buffer, type] :
           llvm::zip(scheduled->getResults(), outputBuffers,
                     scheduled->getResultTypes())) {
        Value tensor = builder.create<bufferization::ToTensorOp>(
            loc, cast<RankedTensorType>(type), buffer);
        result.replaceAllUsesWith(tensor);
      }
      scheduled->erase();
      if (graph->use_empty()) graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts) artifact.erase();
    }

    SmallVector<Operation *> scheduledSpectralPrograms;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "schedule.spectral_program")
        scheduledSpectralPrograms.push_back(op);
    });
    for (Operation *scheduled : scheduledSpectralPrograms) {
      auto hash = scheduled->getAttrOfType<StringAttr>("artifact_hash");
      auto scheduleDigest =
          mod->getAttrOfType<StringAttr>("tessera.schedule_digest");
      if (!hash || !scheduleDigest || hash.getValue().size() != 64 ||
          hash.getValue() != scheduleDigest.getValue()) {
        scheduled->emitError(
            "scheduled spectral program requires the module Schedule Object digest");
        return signalPassFailure();
      }
      // Matching digest strings alone do NOT bind the attributes this pass
      // then consumes: a cached or hand-edited program could keep both
      // digests and still change workspace_bytes or native_entry, which the
      // native launch would use (PR #626 review). Re-verify every consumed
      // policy value against the semantic payload the producer carried.
      auto semantic =
          mod->getAttrOfType<StringAttr>("tessera.spectral_semantic");
      auto schedulePayload =
          mod->getAttrOfType<StringAttr>("tessera.schedule_payload");
      if (!semantic || semantic.getValue().empty() || !schedulePayload ||
          schedulePayload.getValue().empty()) {
        scheduled->emitError(
            "scheduled spectral program requires the module "
            "tessera.spectral_semantic and tessera.schedule_payload "
            "preimages to verify consumed policy");
        return signalPassFailure();
      }
      // Verify the identity CHAIN, so the attributes and the declaration
      // that vouches for them cannot be co-edited:
      //   sha256(schedule_payload) == tessera.schedule_digest, and that
      //   payload names object_id "spectral:<sha256(spectral_semantic)>".
      // Breaking any link changes a hash.
      auto hexDigest = [](StringRef text) {
        llvm::SHA256 hasher;
        hasher.update(text);
        return llvm::toHex(hasher.final(), /*LowerCase=*/true);
      };
      if (hexDigest(schedulePayload.getValue()) != scheduleDigest.getValue()) {
        scheduled->emitError(
            "tessera.schedule_payload does not hash to the module Schedule "
            "Object digest; the carried schedule is not the one addressed");
        return signalPassFailure();
      }
      std::string expectedObjectId =
          ("spectral:" + hexDigest(semantic.getValue()));
      if (!schedulePayload.getValue().contains(expectedObjectId)) {
        scheduled->emitError(
            "tessera.spectral_semantic does not hash to the object_id inside "
            "the digest-bound schedule payload; the declared policy is not "
            "the one the schedule identity covers");
        return signalPassFailure();
      }
      auto payloadField = [&](StringRef field) -> StringRef {
        StringRef payload = semantic.getValue();
        size_t at = payload.find((field + "=").str());
        while (at != StringRef::npos && at != 0 && payload[at - 1] != ';')
          at = payload.find((field + "=").str(), at + 1);
        if (at == StringRef::npos) return StringRef();
        StringRef rest = payload.drop_front(at + field.size() + 1);
        size_t end = rest.find(';');
        return end == StringRef::npos ? rest : rest.take_front(end);
      };
      auto requireMatches = [&](StringRef field, const Twine &actual) -> bool {
        StringRef declared = payloadField(field);
        if (declared.empty() || declared != actual.str()) {
          scheduled->emitError("scheduled spectral program attribute '")
              << field << "' is " << actual
              << ", which disagrees with the carried semantic payload ('"
              << declared << "'); the digest does not cover a changed policy";
          return false;
        }
        return true;
      };
      if (auto workspaceAttr =
              scheduled->getAttrOfType<IntegerAttr>("workspace_bytes")) {
        if (!requireMatches("workspace_bytes",
                            Twine(workspaceAttr.getInt())))
          return signalPassFailure();
      }
      if (auto entryAttr =
              scheduled->getAttrOfType<StringAttr>("native_entry")) {
        if (!requireMatches("native_entry", entryAttr.getValue()))
          return signalPassFailure();
      }
      if (auto normalizationAttr =
              scheduled->getAttrOfType<StringAttr>("normalization")) {
        if (!requireMatches("normalization", normalizationAttr.getValue()))
          return signalPassFailure();
      }
      if (auto transformAttr =
              scheduled->getAttrOfType<IntegerAttr>("transform_length")) {
        if (!requireMatches("n_fft", Twine(transformAttr.getInt())))
          return signalPassFailure();
      }
      if (auto onesidedAttr = scheduled->getAttrOfType<BoolAttr>("onesided")) {
        if (!requireMatches("onesided", Twine(onesidedAttr.getValue() ? 1 : 0)))
          return signalPassFailure();
      }
      if (auto broadcastAttr =
              scheduled->getAttrOfType<StringAttr>("window_broadcast")) {
        if (!requireMatches("window_broadcast", broadcastAttr.getValue()))
          return signalPassFailure();
      }
      auto numericPolicy =
          scheduled->getAttrOfType<DictionaryAttr>("numeric_policy");
      auto numericStorage =
          numericPolicy ? numericPolicy.getAs<StringAttr>("storage") : nullptr;
      auto numericAccum =
          numericPolicy ? numericPolicy.getAs<StringAttr>("accum") : nullptr;
      auto storage = scheduled->getAttrOfType<StringAttr>("storage");
      StringRef expectedStorage =
          storage && storage.getValue() == "f16" ? "fp16" :
          storage && storage.getValue() == "bf16" ? "bf16" : "fp32";
      if (!numericStorage || !numericAccum ||
          numericStorage.getValue() != expectedStorage ||
          numericAccum.getValue() != "fp32" ||
          !requireMatches("numeric_storage", numericStorage.getValue()) ||
          !requireMatches("numeric_accum", numericAccum.getValue())) {
        scheduled->emitError(
            "NUMERIC_POLICY_ACCUM_UNREALIZABLE: scheduled spectral program "
            "requires storage-matched numeric_policy and fp32 accumulation");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == hash.getValue())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled->emitError(
            "requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }
      auto outputType = dyn_cast<RankedTensorType>(scheduled->getResult(0).getType());
      if (!outputType || !outputType.hasStaticShape()) {
        scheduled->emitError("requires a static ranked output tensor");
        return signalPassFailure();
      }

      Location loc = scheduled->getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      SmallVector<Value> launchOperands;
      for (Value subject : scheduled->getOperands()) {
        auto inputType = dyn_cast<RankedTensorType>(subject.getType());
        if (!inputType || !inputType.hasStaticShape()) {
          scheduled->emitError("requires static ranked input tensors");
          return signalPassFailure();
        }
        auto memref = MemRefType::get(inputType.getShape(), inputType.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(loc, memref, subject);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer =
            builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), index);
        launchOperands.push_back(
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer));
      }
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      Value outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, outputBuffer);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      launchOperands.push_back(
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger));
      auto workspace = scheduled->getAttrOfType<IntegerAttr>("workspace_bytes");
      launchOperands.push_back(builder.create<arith::ConstantIntOp>(
          loc, workspace.getInt(), 64));

      OperationState kernelState(loc, "tile.spectral_program_kernel");
      kernelState.addOperands(launchOperands);
      kernelState.addAttribute(
          "input_count",
          builder.getI64IntegerAttr(scheduled->getNumOperands()));
      for (StringRef name :
           {"target", "arch", "kind", "input_shapes", "input_signature",
            "shape_bounds", "template_digest", "shape_policy",
            "storage", "abi_storage", "storage_conversion", "axis_packing",
            "normalization", "numeric_policy",
            "complex_layout", "accumulation", "workspace_policy", "fusion_topology",
            "mutation_lineage", "native_entry", "child_fft_digests",
            "pad_mode", "window_broadcast"})
        kernelState.addAttribute(name, scheduled->getAttr(name));
      for (StringRef name : {"output_shape", "axis", "dct_type", "padding", "crop",
                             "transform_length", "window_length", "hop", "frames",
                             "output_length", "workspace_bytes"})
        kernelState.addAttribute(name, scheduled->getAttr(name));
      kernelState.addAttribute("center", scheduled->getAttr("center"));
      kernelState.addAttribute("onesided", scheduled->getAttr("onesided"));
      kernelState.addAttribute(
          "tessera.workgroup_size",
          scheduled->getAttr("workgroup_size"));
      kernelState.addAttribute("tessera.schedule_hash", hash);
      builder.create(kernelState);

      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outputType, outputBuffer);
      scheduled->getResult(0).replaceAllUsesWith(result);
      scheduled->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts) artifact.erase();
    }

    SmallVector<Operation *> scheduledFFTs;
    mod.walk([&](Operation *op) {
      if (op->getName().getStringRef() == "schedule.fft")
        scheduledFFTs.push_back(op);
    });
    for (Operation *scheduled : scheduledFFTs) {
      Operation *graph = scheduled->getOperand(0).getDefiningOp();
      if (!graph) {
        scheduled->emitError("requires the retained Graph FFT result");
        return signalPassFailure();
      }
      FailureOr<FFTSchedule> selected = getFFTSchedule(graph);
      auto hash = scheduled->getAttrOfType<StringAttr>("artifact_hash");
      if (failed(selected) || !hash ||
          fftScheduleDigest(*selected) != hash.getValue()) {
        scheduled->emitError(
            "scheduled FFT decision does not match the retained Graph contract");
        return signalPassFailure();
      }
      auto stringAttr = [&](StringRef name) -> StringRef {
        auto attr = scheduled->getAttrOfType<StringAttr>(name);
        return attr ? attr.getValue() : StringRef();
      };
      auto intAttr = [&](StringRef name) -> std::optional<int64_t> {
        auto attr = scheduled->getAttrOfType<IntegerAttr>(name);
        return attr ? std::optional<int64_t>(attr.getInt()) : std::nullopt;
      };
      auto boolAttr = [&](StringRef name) -> std::optional<bool> {
        auto attr = scheduled->getAttrOfType<BoolAttr>(name);
        return attr ? std::optional<bool>(attr.getValue()) : std::nullopt;
      };
      auto sequence =
          scheduled->getAttrOfType<DenseI64ArrayAttr>("radix_sequence");
      bool altered =
          stringAttr("arch") != selected->arch ||
          stringAttr("mode") != selected->mode ||
          intAttr("axis") != selected->axis ||
          intAttr("length") != selected->length ||
          intAttr("physical_length") != selected->physicalLength ||
          intAttr("batch") != selected->batch ||
          stringAttr("real_transform_policy") !=
              selected->realTransformPolicy ||
          stringAttr("hermitian_layout") != selected->hermitianLayout ||
          stringAttr("hermitian_weight") != selected->hermitianWeight ||
          boolAttr("inverse") != selected->inverse ||
          stringAttr("normalization") != selected->normalization ||
          stringAttr("storage") != "complex64_interleaved_f32" ||
          stringAttr("accum") != "f32" ||
          stringAttr("radix_policy") != selected->radixPolicy ||
          stringAttr("strategy") != selected->strategy || !sequence ||
          stringAttr("algorithm") != selected->algorithm ||
          ArrayRef<int64_t>(sequence.asArrayRef()) !=
              ArrayRef<int64_t>(selected->radixSequence) ||
          intAttr("bluestein_m") != selected->bluesteinM ||
          intAttr("workspace_elems") != selected->workspaceElems ||
          stringAttr("workspace_policy") != selected->workspacePolicy ||
          stringAttr("residency") != selected->residency ||
          stringAttr("twiddle_layout") != "interleaved_f32" ||
          stringAttr("twiddle_policy") != selected->twiddlePolicy ||
          boolAttr("deterministic") != true ||
          stringAttr("kernel_family") != selected->kernelFamily ||
          intAttr("workgroup_size") != selected->workgroupSize;
      if (altered) {
        scheduled->emitError("scheduled FFT policy was altered after hashing");
        return signalPassFailure();
      }
      auto graphDigest =
          graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == hash.getValue())
          matchingArtifacts.push_back(artifact);
      });
      if (!graphDigest || graphDigest.getValue() != hash.getValue() ||
          matchingArtifacts.size() != 1) {
        scheduled->emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }

      Location loc = scheduled->getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto inputType = cast<RankedTensorType>(graph->getOperand(0).getType());
      auto inputMemref =
          MemRefType::get(inputType.getShape(), inputType.getElementType());
      Value inputBuffer = builder.create<bufferization::ToBufferOp>(
          loc, inputMemref, graph->getOperand(0));
      Value inputIndex = builder.create<memref::ExtractAlignedPointerAsIndexOp>(
          loc, inputBuffer);
      Value inputInteger =
          builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), inputIndex);
      Value inputPointer =
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, inputInteger);
      auto outputType = cast<RankedTensorType>(graph->getResult(0).getType());
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      Value outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex = builder.create<memref::ExtractAlignedPointerAsIndexOp>(
          loc, outputBuffer);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      Value outputPointer =
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger);
      Value batch =
          builder.create<arith::ConstantIntOp>(loc, selected->batch, 64);
      Value length =
          builder.create<arith::ConstantIntOp>(loc, selected->length, 64);

      OperationState kernelState(loc, "tile.fft_kernel");
      kernelState.addOperands({inputPointer, outputPointer, batch, length});
      kernelState.addAttribute("mode", builder.getStringAttr(selected->mode));
      kernelState.addAttribute("axis", builder.getI64IntegerAttr(selected->axis));
      kernelState.addAttribute("length",
                               builder.getI64IntegerAttr(selected->length));
      kernelState.addAttribute("physical_length",
                               builder.getI64IntegerAttr(selected->physicalLength));
      kernelState.addAttribute("batch",
                               builder.getI64IntegerAttr(selected->batch));
      kernelState.addAttribute(
          "real_transform_policy",
          builder.getStringAttr(selected->realTransformPolicy));
      kernelState.addAttribute("hermitian_layout",
                               builder.getStringAttr(selected->hermitianLayout));
      kernelState.addAttribute("hermitian_weight",
                               builder.getStringAttr(selected->hermitianWeight));
      kernelState.addAttribute("inverse", builder.getBoolAttr(selected->inverse));
      kernelState.addAttribute("normalization",
                               builder.getStringAttr(selected->normalization));
      kernelState.addAttribute("scale", builder.getF32FloatAttr(selected->scale));
      kernelState.addAttribute("storage",
                               builder.getStringAttr("complex64_interleaved_f32"));
      kernelState.addAttribute("accum", builder.getStringAttr("f32"));
      kernelState.addAttribute("radix_policy",
                               builder.getStringAttr(selected->radixPolicy));
      kernelState.addAttribute("strategy",
                               builder.getStringAttr(selected->strategy));
      kernelState.addAttribute("algorithm",
                               builder.getStringAttr(selected->algorithm));
      kernelState.addAttribute("radix_sequence",
                               builder.getDenseI64ArrayAttr(selected->radixSequence));
      kernelState.addAttribute("bluestein_m",
                               builder.getI64IntegerAttr(selected->bluesteinM));
      kernelState.addAttribute("workspace_elems",
                               builder.getI64IntegerAttr(selected->workspaceElems));
      kernelState.addAttribute("workspace_policy",
                               builder.getStringAttr(selected->workspacePolicy));
      kernelState.addAttribute("residency",
                               builder.getStringAttr(selected->residency));
      kernelState.addAttribute("twiddle_layout",
                               builder.getStringAttr("interleaved_f32"));
      kernelState.addAttribute("twiddle_policy",
                               builder.getStringAttr(selected->twiddlePolicy));
      kernelState.addAttribute("deterministic", builder.getBoolAttr(true));
      kernelState.addAttribute("kernel_family",
                               builder.getStringAttr(selected->kernelFamily));
      kernelState.addAttribute(
          "tessera.workgroup_size",
          builder.getI64IntegerAttr(selected->workgroupSize));
      kernelState.addAttribute("tessera.schedule_hash", hash);
      builder.create(kernelState);

      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outputType, outputBuffer);
      scheduled->getResult(0).replaceAllUsesWith(result);
      scheduled->erase();
      if (graph->use_empty()) graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts) artifact.erase();
    }

    SmallVector<schedule::DepthAttentionOp> scheduledDepthAttentions;
    mod.walk([&](schedule::DepthAttentionOp op) {
      scheduledDepthAttentions.push_back(op);
    });
    for (schedule::DepthAttentionOp scheduled : scheduledDepthAttentions) {
      Operation *graph = scheduled.getSubject().getDefiningOp();
      if (!graph || graph->getName().getStringRef() != "tessera.depth_attn") {
        scheduled.emitError(
            "BLOCK-ATTNRES-1 requires the retained Graph depth-attention result");
        return signalPassFailure();
      }
      FailureOr<DepthAttentionSchedule> selected =
          getDepthAttentionSchedule(graph);
      if (failed(selected) || depthAttentionScheduleDigest(*selected) !=
                                  scheduled.getArtifactHash()) {
        scheduled.emitError(
            "scheduled decision does not match the retained Graph depth-attention contract");
        return signalPassFailure();
      }
      bool altered =
          scheduled.getArch() != selected->arch ||
          scheduled.getStorage() != selected->storage ||
          scheduled.getSoftmax() != selected->softmax ||
          scheduled.getAccum() != selected->accum ||
          scheduled.getEps().convertToDouble() != selected->eps ||
          static_cast<int64_t>(scheduled.getSourceCount()) !=
              selected->sourceCount ||
          static_cast<int64_t>(scheduled.getRows()) != selected->rows ||
          static_cast<int64_t>(scheduled.getWidth()) != selected->width ||
          static_cast<int64_t>(scheduled.getSourceTile()) !=
              selected->sourceTile ||
          static_cast<int64_t>(scheduled.getWorkgroupSize()) !=
              selected->workgroupSize ||
          scheduled.getStatisticsRecurrence() !=
              selected->statisticsRecurrence ||
          scheduled.getMergeRecurrence() != selected->mergeRecurrence ||
          scheduled.getReassociable() != selected->reassociable;
      if (altered) {
        scheduled.emitError(
            "scheduled depth-attention policy was altered after hashing");
        return signalPassFailure();
      }
      auto graphDigest =
          graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (!graphDigest ||
          graphDigest.getValue() != scheduled.getArtifactHash() ||
          matchingArtifacts.size() != 1) {
        scheduled.emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto type = cast<RankedTensorType>(tensor.getType());
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      SmallVector<Value> operands = {toPointer(graph->getOperand(0)),
                                     toPointer(graph->getOperand(1))};
      auto outputType = cast<RankedTensorType>(graph->getResult(0).getType());
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      Value outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, outputBuffer);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      operands.push_back(
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger));
      for (int64_t extent :
           {selected->sourceCount, selected->rows, selected->width})
        operands.push_back(
            builder.create<arith::ConstantIntOp>(loc, extent, 64));

      OperationState kernelState(loc, "tile.depth_attention_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute("storage",
                               builder.getStringAttr(selected->storage));
      kernelState.addAttribute("arch", builder.getStringAttr(selected->arch));
      kernelState.addAttribute("softmax",
                               builder.getStringAttr(selected->softmax));
      kernelState.addAttribute("accum",
                               builder.getStringAttr(selected->accum));
      kernelState.addAttribute("eps",
                               builder.getF64FloatAttr(selected->eps));
      kernelState.addAttribute(
          "source_tile", builder.getI64IntegerAttr(selected->sourceTile));
      kernelState.addAttribute(
          "tessera.workgroup_size",
          builder.getI64IntegerAttr(selected->workgroupSize));
      kernelState.addAttribute(
          "statistics_recurrence",
          builder.getStringAttr(selected->statisticsRecurrence));
      kernelState.addAttribute(
          "merge_recurrence",
          builder.getStringAttr(selected->mergeRecurrence));
      kernelState.addAttribute("reassociable",
                               builder.getBoolAttr(selected->reassociable));
      kernelState.addAttribute(
          "tessera.schedule_hash",
          builder.getStringAttr(scheduled.getArtifactHash()));
      builder.create(kernelState);

      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outputType, outputBuffer);
      scheduled.getScheduled().replaceAllUsesWith(result);
      scheduled.erase();
      if (graph->use_empty())
        graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::AttentionOp> scheduledAttentions;
    mod.walk([&](schedule::AttentionOp op) {
      scheduledAttentions.push_back(op);
    });
    for (schedule::AttentionOp scheduled : scheduledAttentions) {
      Operation *graph = scheduled.getSubject().getDefiningOp();
      if (!graph || graph->getName().getStringRef() != "tessera.flash_attn") {
        scheduled.emitError(
            "E2E-REAL-5A requires the retained Graph attention result");
        return signalPassFailure();
      }
      FailureOr<AttentionSchedule> selected = getAttentionSchedule(graph);
      if (failed(selected) ||
          attentionScheduleDigest(*selected) != scheduled.getArtifactHash()) {
        scheduled.emitError(
            "scheduled decision does not match the retained Graph attention contract");
        return signalPassFailure();
      }
      bool altered =
          scheduled.getArch() != selected->arch ||
          scheduled.getStorage() != selected->storage ||
          scheduled.getAccum() != selected->accum ||
          scheduled.getScale().convertToDouble() != selected->scale ||
          scheduled.getCausal() != selected->causal ||
          scheduled.getBias() != selected->bias ||
          static_cast<int64_t>(scheduled.getWindowLeft()) !=
              selected->windowLeft ||
          static_cast<int64_t>(scheduled.getWindowRight()) !=
              selected->windowRight ||
          scheduled.getSoftcap().convertToDouble() != selected->softcap ||
          scheduled.getDropoutP().convertToDouble() != selected->dropoutP ||
          static_cast<int64_t>(scheduled.getDropoutSeed()) !=
              selected->dropoutSeed ||
          static_cast<int64_t>(scheduled.getTileQ()) != selected->tileQ ||
          static_cast<int64_t>(scheduled.getTileKv()) != selected->tileKV ||
          static_cast<int64_t>(scheduled.getWorkgroupSize()) !=
              selected->workgroupSize ||
          scheduled.getRecurrence() != selected->recurrence ||
          scheduled.getBackwardLsePolicy() != selected->backwardLsePolicy ||
          scheduled.getBackwardLseSelection() !=
              selected->backwardLseSelection;
      auto outputStorage = scheduled->getAttrOfType<StringAttr>("output_storage");
      altered |= selected->outputStorage == "f32" ? scheduled->hasAttr("output_storage") :
          (!outputStorage || outputStorage.getValue() != selected->outputStorage);
      auto biasShape = scheduled->getAttrOfType<DenseI64ArrayAttr>("bias_shape");
      altered |= selected->biasShape.empty() ? scheduled->hasAttr("bias_shape") :
          (!biasShape || biasShape.asArrayRef() != ArrayRef<int64_t>(selected->biasShape));
      if (altered) {
        scheduled.emitError(
            "scheduled attention policy was altered after hashing");
        return signalPassFailure();
      }
      auto graphDigest =
          graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (!graphDigest || graphDigest.getValue() != scheduled.getArtifactHash() ||
          matchingArtifacts.size() != 1) {
        scheduled.emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      SmallVector<Value> operands;
      Value outputBuffer;
      func::FuncOp nativeGraph;
      LLVM::LLVMFuncOp nativeKernel;
      if (selected->target == "nvidia_sm120") {
        nativeGraph = graph->getParentOfType<func::FuncOp>();
        if (!nativeGraph || !llvm::hasSingleElement(nativeGraph.getBody()) ||
            nativeGraph.getNumArguments() != graph->getNumOperands() ||
            nativeGraph.getNumResults() != 1 ||
            nativeGraph.getBody().front().getOperations().size() != 4) {
          scheduled.emitError("NVIDIA scheduled attention requires one isolated function");
          return signalPassFailure();
        }
        llvm::SmallDenseSet<unsigned, 4> inputRoles;
        for (Value operand : graph->getOperands()) {
          auto argument = dyn_cast<BlockArgument>(operand);
          if (!argument || argument.getOwner() != &nativeGraph.getBody().front() ||
              !inputRoles.insert(argument.getArgNumber()).second) {
            scheduled.emitError("NVIDIA scheduled attention requires distinct function argument operands");
            return signalPassFailure();
          }
        }
        auto ret = dyn_cast<func::ReturnOp>(nativeGraph.getBody().front().back());
        if (!ret || ret.getNumOperands() != 1 || ret.getOperand(0) != scheduled.getScheduled()) {
          scheduled.emitError("NVIDIA scheduled attention must be the function result");
          return signalPassFailure();
        }
        std::string outputSuffix = selected->outputStorage == "f32" ? "" :
            (Twine("out_") + selected->outputStorage + "_").str();
        std::string name = (Twine("tessera_tile_attention_") + selected->storage + "_" +
            (selected->causal ? "causal_" : "full_") + outputSuffix +
            scheduled.getArtifactHash().take_front(10)).str();
        if (SymbolTable::lookupSymbolIn(mod, name)) {
          scheduled.emitError("NVIDIA scheduled attention symbol already exists");
          return signalPassFailure();
        }
        SmallVector<Type> inputs(4 + (selected->bias ? 1 : 0), pointerType);
        inputs.append(7, builder.getI64Type());
        auto type = LLVM::LLVMFunctionType::get(LLVM::LLVMVoidType::get(&getContext()), inputs, false);
        OpBuilder mb(mod.getBody(), mod.getBody()->end());
        nativeKernel = LLVM::LLVMFuncOp::create(mb, loc, name, type);
        nativeKernel->setAttr("nvvm.kernel", mb.getUnitAttr());
        Block *entry = nativeKernel.addEntryBlock(mb);
        builder.setInsertionPointToStart(entry);
        operands.assign(entry->getArguments().begin(), entry->getArguments().end());
      } else {
      auto toPointer = [&](Value tensor) -> Value {
        auto type = cast<RankedTensorType>(tensor.getType());
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer =
            builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      operands.push_back(toPointer(graph->getOperand(0)));
      operands.push_back(toPointer(graph->getOperand(1)));
      operands.push_back(toPointer(graph->getOperand(2)));
      if (selected->bias)
        operands.push_back(toPointer(graph->getOperand(3)));

      auto outputType = cast<RankedTensorType>(graph->getResult(0).getType());
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex =
          builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, outputBuffer);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      operands.push_back(
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger));
      for (int64_t dimension :
           {selected->batch, selected->queryHeads, selected->kvHeads,
            selected->queryRows, selected->keyRows, selected->headDim,
            selected->valueDim})
        operands.push_back(
            builder.create<arith::ConstantIntOp>(loc, dimension, 64));

      }
      OperationState kernelState(loc, "tile.attention_kernel");
      kernelState.addOperands(operands);
      if (selected->outputStorage != "f32")
        kernelState.addAttribute("output_storage", builder.getStringAttr(selected->outputStorage));
      kernelState.addAttribute("storage",
                               builder.getStringAttr(selected->storage));
      kernelState.addAttribute("accum", builder.getStringAttr(selected->accum));
      kernelState.addAttribute("scale", builder.getF32FloatAttr(selected->scale));
      kernelState.addAttribute("causal", builder.getBoolAttr(selected->causal));
      kernelState.addAttribute("bias", builder.getBoolAttr(selected->bias));
      if (!selected->biasShape.empty())
        kernelState.addAttribute("bias_shape", builder.getDenseI64ArrayAttr(selected->biasShape));
      kernelState.addAttribute("window_left",
                               builder.getI64IntegerAttr(selected->windowLeft));
      kernelState.addAttribute("window_right",
                               builder.getI64IntegerAttr(selected->windowRight));
      kernelState.addAttribute("softcap",
                               builder.getF32FloatAttr(selected->softcap));
      kernelState.addAttribute("dropout_p",
                               builder.getF32FloatAttr(selected->dropoutP));
      kernelState.addAttribute("dropout_seed",
                               builder.getI64IntegerAttr(selected->dropoutSeed));
      kernelState.addAttribute("head_dim",
                               builder.getI64IntegerAttr(selected->headDim));
      kernelState.addAttribute("value_dim",
                               builder.getI64IntegerAttr(selected->valueDim));
      kernelState.addAttribute(
          "gqa", builder.getBoolAttr(selected->queryHeads != selected->kvHeads));
      kernelState.addAttribute("tessera.tile_q",
                               builder.getI64IntegerAttr(selected->tileQ));
      kernelState.addAttribute("tessera.tile_kv",
                               builder.getI64IntegerAttr(selected->tileKV));
      kernelState.addAttribute(
          "tessera.workgroup_size",
          builder.getI64IntegerAttr(selected->workgroupSize));
      kernelState.addAttribute("tessera.attention_recurrence",
                               builder.getStringAttr(selected->recurrence));
      kernelState.addAttribute(
          "tessera.backward_lse_policy",
          builder.getStringAttr(selected->backwardLsePolicy));
      kernelState.addAttribute(
          "tessera.backward_lse_selection",
          builder.getStringAttr(selected->backwardLseSelection));
      kernelState.addAttribute("tessera.schedule_hash",
                               builder.getStringAttr(scheduled.getArtifactHash()));
      if (nativeKernel) kernelState.addAttribute("lse_checkpoint", builder.getStringAttr("recompute"));
      builder.create(kernelState);
      if (nativeKernel) {
        LLVM::ReturnOp::create(builder, loc, ValueRange{});
        nativeGraph.erase();
        continue;
      }

      Value result = builder.create<bufferization::ToTensorOp>(
          loc, cast<RankedTensorType>(graph->getResult(0).getType()), outputBuffer);
      scheduled.getScheduled().replaceAllUsesWith(result);
      scheduled.erase();
      if (graph->use_empty())
        graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::AttentionBackwardOp> scheduledBackwards;
    mod.walk([&](schedule::AttentionBackwardOp op) {
      scheduledBackwards.push_back(op);
    });
    for (schedule::AttentionBackwardOp scheduled : scheduledBackwards) {
      Operation *scheduledOperation = scheduled.getOperation();
      Operation *graph = scheduledOperation->getOperand(0).getDefiningOp();
      if (!graph || graph->getName().getStringRef() !=
                        "tessera_attn.backward" ||
          graph->getNumOperands() != 5 || graph->getNumResults() != 3 ||
          scheduledOperation->getOperand(1).getDefiningOp() != graph ||
          scheduledOperation->getOperand(2).getDefiningOp() != graph) {
        scheduled.emitError(
            "E2E-REAL-5B requires all dQ/dK/dV subjects from one retained "
            "canonical Graph attention backward op");
        return signalPassFailure();
      }
      FailureOr<AttentionBackwardSchedule> selected =
          getAttentionBackwardSchedule(graph);
      auto artifactHash =
          scheduledOperation->getAttrOfType<StringAttr>("artifact_hash");
      if (failed(selected) || !artifactHash ||
          attentionBackwardScheduleDigest(*selected) !=
              artifactHash.getValue()) {
        scheduled.emitError(
            "scheduled decision does not match the retained attention "
            "backward contract");
        return signalPassFailure();
      }
      auto stringAttr = [&](StringRef name) -> StringRef {
        auto attr = scheduledOperation->getAttrOfType<StringAttr>(name);
        return attr ? attr.getValue() : StringRef();
      };
      auto integerAttr = [&](StringRef name) -> std::optional<int64_t> {
        auto attr = scheduledOperation->getAttrOfType<IntegerAttr>(name);
        if (!attr)
          return std::nullopt;
        return attr.getInt();
      };
      auto floatAttr = [&](StringRef name) -> std::optional<double> {
        auto attr = scheduledOperation->getAttrOfType<FloatAttr>(name);
        if (!attr)
          return std::nullopt;
        return attr.getValueAsDouble();
      };
      auto boolAttr = [&](StringRef name) -> std::optional<bool> {
        auto attr = scheduledOperation->getAttrOfType<BoolAttr>(name);
        if (!attr)
          return std::nullopt;
        return attr.getValue();
      };
      auto reductionOrder = scheduledOperation->getAttrOfType<DenseI64ArrayAttr>(
          "reduction_order");
      bool altered =
          stringAttr("arch") != selected->arch ||
          stringAttr("storage") != selected->storage ||
          stringAttr("accum") != selected->accum ||
          floatAttr("scale") != selected->scale ||
          boolAttr("causal") != selected->causal ||
          boolAttr("bias") != selected->bias ||
          integerAttr("window_left") != selected->windowLeft ||
          integerAttr("window_right") != selected->windowRight ||
          floatAttr("softcap") != selected->softcap ||
          floatAttr("dropout_p") != selected->dropoutP ||
          integerAttr("dropout_seed") != selected->dropoutSeed ||
          integerAttr("query_block") != selected->queryBlock ||
          integerAttr("key_block") != selected->keyBlock ||
          integerAttr("split_count") != selected->splitCount ||
          !reductionOrder || reductionOrder.size() != 2 ||
          reductionOrder[0] != 0 || reductionOrder[1] != 1 ||
          integerAttr("workspace_bytes") != selected->workspaceBytes ||
          integerAttr("workgroup_size") != selected->workgroupSize ||
          stringAttr("recurrence") != selected->recurrence ||
          stringAttr("lse_checkpoint_policy") !=
              selected->lseCheckpointPolicy ||
          stringAttr("lse_checkpoint_selection") !=
              selected->lseCheckpointSelection;
      if (altered) {
        scheduled.emitError(
            "scheduled attention backward policy was altered after hashing");
        return signalPassFailure();
      }
      auto graphDigest =
          graph->getAttrOfType<StringAttr>("schedule.artifact_hash");
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == artifactHash.getValue())
          matchingArtifacts.push_back(artifact);
      });
      if (!graphDigest || graphDigest.getValue() != artifactHash.getValue() ||
          matchingArtifacts.size() != 1) {
        scheduled.emitError(
            "requires exactly one matching Graph hash and schedule.artifact");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto type = cast<RankedTensorType>(tensor.getType());
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer =
            builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      auto allocatePointer = [&](RankedTensorType type) {
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<memref::AllocOp>(loc, memrefType);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer =
            builder.create<arith::IndexCastOp>(loc, builder.getI64Type(), index);
        Value pointer =
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
        return std::make_pair(buffer, pointer);
      };
      SmallVector<Value> operands;
      for (Value input : graph->getOperands().take_front(4))
        operands.push_back(toPointer(input));
      if (selected->bias)
        operands.push_back(toPointer(graph->getOperand(4)));
      if (selected->lseCheckpointSelection == "saved") {
        auto lseType = RankedTensorType::get(
            {selected->batch, selected->queryHeads, selected->queryRows},
            builder.getF32Type());
        operands.push_back(allocatePointer(lseType).second);
      }

      SmallVector<Value> outputBuffers;
      for (Type resultType : graph->getResultTypes()) {
        auto [buffer, pointer] =
            allocatePointer(cast<RankedTensorType>(resultType));
        outputBuffers.push_back(buffer);
        operands.push_back(pointer);
      }
      for (int64_t dimension :
           {selected->batch, selected->queryHeads, selected->kvHeads,
            selected->queryRows, selected->keyRows, selected->headDim,
            selected->valueDim})
        operands.push_back(
            builder.create<arith::ConstantIntOp>(loc, dimension, 64));

      OperationState kernelState(loc, "tile.attention_backward_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute("storage",
                               builder.getStringAttr(selected->storage));
      kernelState.addAttribute("accum", builder.getStringAttr("f32"));
      kernelState.addAttribute("scale", builder.getF32FloatAttr(selected->scale));
      kernelState.addAttribute("causal", builder.getBoolAttr(selected->causal));
      kernelState.addAttribute("bias", builder.getBoolAttr(selected->bias));
      kernelState.addAttribute("window_left",
                               builder.getI64IntegerAttr(selected->windowLeft));
      kernelState.addAttribute("window_right",
                               builder.getI64IntegerAttr(selected->windowRight));
      kernelState.addAttribute("softcap",
                               builder.getF32FloatAttr(selected->softcap));
      kernelState.addAttribute("dropout_p",
                               builder.getF32FloatAttr(selected->dropoutP));
      kernelState.addAttribute("dropout_seed",
                               builder.getI64IntegerAttr(selected->dropoutSeed));
      kernelState.addAttribute("head_dim",
                               builder.getI64IntegerAttr(selected->headDim));
      kernelState.addAttribute("value_dim",
                               builder.getI64IntegerAttr(selected->valueDim));
      kernelState.addAttribute(
          "gqa", builder.getBoolAttr(selected->queryHeads != selected->kvHeads));
      kernelState.addAttribute("lse_checkpoint",
                               builder.getStringAttr(
                                   selected->lseCheckpointSelection));
      kernelState.addAttribute("route",
                               builder.getStringAttr(
                                   "deterministic_split_reduced"));
      kernelState.addAttribute("deterministic", builder.getBoolAttr(true));
      kernelState.addAttribute(
          "workspace_bytes",
          builder.getI64IntegerAttr(selected->workspaceBytes));
      kernelState.addAttribute("workspace_owner",
                               builder.getStringAttr("program_launch"));
      kernelState.addAttribute("split_count",
                               builder.getI64IntegerAttr(selected->splitCount));
      kernelState.addAttribute("reduction_order",
                               builder.getDenseI64ArrayAttr({0, 1}));
      kernelState.addAttribute("query_block",
                               builder.getI64IntegerAttr(selected->queryBlock));
      kernelState.addAttribute("key_block",
                               builder.getI64IntegerAttr(selected->keyBlock));
      kernelState.addAttribute(
          "loop_order",
          builder.getStrArrayAttr({"forward", "pre", "dkdv_split",
                                   "dkdv_reduce", "dq"}));
      kernelState.addAttribute(
          "tessera.attention_backward_recurrence",
          builder.getStringAttr(selected->recurrence));
      kernelState.addAttribute(
          "tessera.lse_checkpoint_policy",
          builder.getStringAttr(selected->lseCheckpointPolicy));
      kernelState.addAttribute(
          "tessera.workgroup_size",
          builder.getI64IntegerAttr(selected->workgroupSize));
      kernelState.addAttribute("tessera.schedule_hash", artifactHash);
      builder.create(kernelState);

      for (auto [result, buffer, resultType] :
           llvm::zip_equal(scheduledOperation->getResults(), outputBuffers,
                           graph->getResultTypes())) {
        Value tensor = builder.create<bufferization::ToTensorOp>(
            loc, cast<RankedTensorType>(resultType), buffer);
        result.replaceAllUsesWith(tensor);
      }
      scheduled.erase();
      if (graph->use_empty())
        graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::ESLowRankCorrectionOp> scheduledES;
    mod.walk([&](schedule::ESLowRankCorrectionOp op) {
      scheduledES.push_back(op);
    });
    for (schedule::ESLowRankCorrectionOp scheduled : scheduledES) {
      std::string payloadHash = llvm::toHex(
          llvm::SHA256::hash(
              llvm::arrayRefFromStringRef(scheduled.getLineagePayload())),
          /*LowerCase=*/true);
      if (payloadHash != scheduled.getArtifactHash()) {
        scheduled.emitError("ES lineage payload does not match artifact_hash");
        return signalPassFailure();
      }
      Operation *graph = scheduled.getSubject().getDefiningOp();
      if (!graph || graph->getName().getStringRef() !=
                        "tessera.es_low_rank_correction" ||
          graph->getNumOperands() != 3) {
        scheduled.emitError("requires the retained Graph ES correction");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled.emitError("requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }
      auto outputType =
          dyn_cast<RankedTensorType>(scheduled.getScheduled().getType());
      if (!outputType || !outputType.hasStaticShape() ||
          !outputType.getElementType().isF32()) {
        scheduled.emitError("initial ES lowering requires a static f32 result");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> FailureOr<Value> {
        auto type = dyn_cast<RankedTensorType>(tensor.getType());
        if (!type || !type.hasStaticShape()) return failure();
        auto memref = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(loc, memref, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer)
            .getResult();
      };
      SmallVector<Value> operands;
      for (Value input : graph->getOperands()) {
        FailureOr<Value> pointer = toPointer(input);
        if (failed(pointer)) {
          scheduled.emitError("requires static ranked x/member/key inputs");
          return signalPassFailure();
        }
        operands.push_back(*pointer);
      }
      auto outputMemref =
          MemRefType::get(outputType.getShape(), outputType.getElementType());
      Value outputBuffer = builder.create<memref::AllocOp>(loc, outputMemref);
      Value outputIndex = builder.create<memref::ExtractAlignedPointerAsIndexOp>(
          loc, outputBuffer);
      Value outputInteger = builder.create<arith::IndexCastOp>(
          loc, builder.getI64Type(), outputIndex);
      operands.push_back(
          builder.create<LLVM::IntToPtrOp>(loc, pointerType, outputInteger));
      for (int64_t dimension :
           {scheduled.getPopulation(), scheduled.getRowsPerMember(),
            scheduled.getInDim(), scheduled.getOutDim()})
        operands.push_back(
            builder.create<arith::ConstantIntOp>(loc, dimension, 64));

      OperationState kernelState(loc, "tile.es_low_rank_correction_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute("population", scheduled.getPopulationAttr());
      kernelState.addAttribute("rows_per_member",
                               scheduled.getRowsPerMemberAttr());
      kernelState.addAttribute("in_dim", scheduled.getInDimAttr());
      kernelState.addAttribute("out_dim", scheduled.getOutDimAttr());
      for (StringRef name : {"arch", "rank", "epoch", "sigma", "antithetic",
                             "score", "rng_algorithm", "rng_version", "storage",
                             "accum"})
        kernelState.addAttribute(name, scheduled->getAttr(name));
      kernelState.addAttribute("tessera.workgroup_size",
                               scheduled.getWorkgroupSizeAttr());
      kernelState.addAttribute("tessera.schedule_hash",
                               scheduled.getArtifactHashAttr());
      builder.create(kernelState);

      Value result = builder.create<bufferization::ToTensorOp>(
          loc, outputType, outputBuffer);
      scheduled.getScheduled().replaceAllUsesWith(result);
      scheduled.erase();
      if (graph->use_empty()) graph->erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts) artifact.erase();
    }

    SmallVector<schedule::SolverIFTOp> scheduledIFTs;
    mod.walk([&](schedule::SolverIFTOp op) { scheduledIFTs.push_back(op); });
    for (schedule::SolverIFTOp scheduled : scheduledIFTs) {
      std::string payloadHash = llvm::toHex(
          llvm::SHA256::hash(
              llvm::arrayRefFromStringRef(scheduled.getLineagePayload())),
          /*LowerCase=*/true);
      if (payloadHash != scheduled.getArtifactHash()) {
        scheduled.emitError("solver IFT lineage payload does not match artifact_hash");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled.emitError("requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }
      auto tensorType =
          dyn_cast<RankedTensorType>(scheduled.getParameter().getType());
      if (!tensorType || !tensorType.hasStaticShape() ||
          !tensorType.getElementType().isF32()) {
        scheduled.emitError("initial solver IFT lowering requires static f32 tensors");
        return signalPassFailure();
      }
      if (scheduled.getSolution().getType() != tensorType ||
          scheduled.getCotangent().getType() != tensorType) {
        scheduled.emitError("solver IFT operands must have one static f32 type");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto memrefType = MemRefType::get(
            tensorType.getShape(), tensorType.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      auto allocatePointer = [&]() {
        auto memrefType = MemRefType::get(
            tensorType.getShape(), tensorType.getElementType());
        Value buffer = builder.create<memref::AllocOp>(loc, memrefType);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        Value pointer =
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
        return std::make_pair(buffer, pointer);
      };

      SmallVector<Value> operands;
      for (Value input : {scheduled.getParameter(), scheduled.getSolution(),
                          scheduled.getCotangent()})
        operands.push_back(toPointer(input));
      SmallVector<Value> outputBuffers;
      for (int i = 0; i < 3; ++i) {
        auto [buffer, pointer] = allocatePointer();
        outputBuffers.push_back(buffer);
        operands.push_back(pointer);
      }
      operands.push_back(builder.create<arith::ConstantIntOp>(
          loc, tensorType.getNumElements(), 64));

      OperationState kernelState(loc, "tile.solver_ift_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute("arch", scheduled.getArchAttr());
      kernelState.addAttribute("residual_model",
                               scheduled.getResidualModelAttr());
      kernelState.addAttribute("residual_digest",
                               scheduled.getResidualDigestAttr());
      kernelState.addAttribute("linear_solver",
                               scheduled.getLinearSolverAttr());
      kernelState.addAttribute("product_mode",
                               scheduled.getProductModeAttr());
      kernelState.addAttribute("transpose", scheduled.getTransposeAttr());
      kernelState.addAttribute("wrt", scheduled.getWrtAttr());
      kernelState.addAttribute("adjoint_scale",
                               scheduled.getAdjointScaleAttr());
      kernelState.addAttribute("storage", scheduled.getStorageAttr());
      kernelState.addAttribute("accum", scheduled.getAccumAttr());
      kernelState.addAttribute("tessera.workgroup_size",
                               scheduled.getWorkgroupSizeAttr());
      kernelState.addAttribute("tessera.schedule_hash",
                               scheduled.getArtifactHashAttr());
      builder.create(kernelState);

      for (auto [result, buffer] :
           llvm::zip_equal(scheduled.getResults(), outputBuffers)) {
        Value tensor = builder.create<bufferization::ToTensorOp>(
            loc, tensorType, buffer);
        result.replaceAllUsesWith(tensor);
      }
      scheduled.erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::LionVJPOp> scheduledLions;
    mod.walk([&](schedule::LionVJPOp op) { scheduledLions.push_back(op); });
    for (schedule::LionVJPOp scheduled : scheduledLions) {
      std::string payloadHash = llvm::toHex(
          llvm::SHA256::hash(
              llvm::arrayRefFromStringRef(scheduled.getLineagePayload())),
          /*LowerCase=*/true);
      if (payloadHash != scheduled.getArtifactHash()) {
        scheduled.emitError(
            "Lion VJP lineage payload does not match artifact_hash");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled.emitError(
            "requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }
      auto tensorType = dyn_cast<RankedTensorType>(scheduled.getParameter().getType());
      if (!tensorType || !tensorType.hasStaticShape() ||
          !tensorType.getElementType().isF32()) {
        scheduled.emitError("initial Lion VJP lowering requires static f32 tensors");
        return signalPassFailure();
      }
      for (Value input : {scheduled.getGradient(), scheduled.getMoment(),
                          scheduled.getDparameter(), scheduled.getDmoment()}) {
        if (input.getType() != tensorType) {
          scheduled.emitError("Lion VJP inputs must have one static f32 type");
          return signalPassFailure();
        }
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto memrefType = MemRefType::get(
            tensorType.getShape(), tensorType.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      auto allocatePointer = [&]() {
        auto memrefType = MemRefType::get(
            tensorType.getShape(), tensorType.getElementType());
        Value buffer = builder.create<memref::AllocOp>(loc, memrefType);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        Value pointer =
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
        return std::make_pair(buffer, pointer);
      };

      SmallVector<Value> operands;
      for (Value input : {scheduled.getParameter(), scheduled.getGradient(),
                          scheduled.getMoment(), scheduled.getDparameter(),
                          scheduled.getDmoment()})
        operands.push_back(toPointer(input));
      SmallVector<Value> outputBuffers;
      for (int i = 0; i < 3; ++i) {
        auto [buffer, pointer] = allocatePointer();
        outputBuffers.push_back(buffer);
        operands.push_back(pointer);
      }
      int64_t elements = tensorType.getNumElements();
      operands.push_back(
          builder.create<arith::ConstantIntOp>(loc, elements, 64));

      OperationState kernelState(loc, "tile.training_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute("family", builder.getStringAttr("lion_vjp"));
      kernelState.addAttribute("storage", builder.getStringAttr("f32"));
      kernelState.addAttribute("arch", scheduled.getArchAttr());
      kernelState.addAttribute("learning_rate", scheduled.getLearningRateAttr());
      kernelState.addAttribute("beta2", scheduled.getBeta2Attr());
      kernelState.addAttribute("weight_decay", scheduled.getWeightDecayAttr());
      kernelState.addAttribute("derivative_policy",
                               scheduled.getDerivativePolicyAttr());
      kernelState.addAttribute("mutation_mode", scheduled.getMutationModeAttr());
      kernelState.addAttribute("alias_policy", scheduled.getAliasPolicyAttr());
      kernelState.addAttribute("state_transition",
                               scheduled.getStateTransitionAttr());
      kernelState.addAttribute("ordered_writes", scheduled.getOrderedWritesAttr());
      kernelState.addAttribute("tessera.workgroup_size",
                               scheduled.getWorkgroupSizeAttr());
      kernelState.addAttribute("tessera.schedule_hash",
                               scheduled.getArtifactHashAttr());
      builder.create(kernelState);

      for (auto [result, buffer] :
           llvm::zip_equal(scheduled.getResults(), outputBuffers)) {
        Value tensor = builder.create<bufferization::ToTensorOp>(
            loc, tensorType, buffer);
        result.replaceAllUsesWith(tensor);
      }
      scheduled.erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::OptimizerVJPOp> scheduledOptimizers;
    mod.walk([&](schedule::OptimizerVJPOp op) {
      scheduledOptimizers.push_back(op);
    });
    for (schedule::OptimizerVJPOp scheduled : scheduledOptimizers) {
      std::string payloadHash = llvm::toHex(
          llvm::SHA256::hash(
              llvm::arrayRefFromStringRef(scheduled.getLineagePayload())),
          /*LowerCase=*/true);
      if (payloadHash != scheduled.getArtifactHash()) {
        scheduled.emitError(
            "optimizer VJP lineage payload does not match artifact_hash");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled.emitError("requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }
      auto tensorType =
          dyn_cast<RankedTensorType>(scheduled.getInputs().front().getType());
      if (!tensorType || !tensorType.hasStaticShape() ||
          !tensorType.getElementType().isF32()) {
        scheduled.emitError(
            "initial optimizer VJP lowering requires static f32 tensors");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto memrefType =
            MemRefType::get(tensorType.getShape(), tensorType.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      auto allocatePointer = [&]() {
        auto memrefType =
            MemRefType::get(tensorType.getShape(), tensorType.getElementType());
        Value buffer = builder.create<memref::AllocOp>(loc, memrefType);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        Value pointer =
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
        return std::make_pair(buffer, pointer);
      };

      SmallVector<Value> operands;
      for (Value input : scheduled.getInputs())
        operands.push_back(toPointer(input));
      SmallVector<Value> outputBuffers;
      for (Type ignored : scheduled.getResultTypes()) {
        (void)ignored;
        auto [buffer, pointer] = allocatePointer();
        outputBuffers.push_back(buffer);
        operands.push_back(pointer);
      }
      operands.push_back(builder.create<arith::ConstantIntOp>(
          loc, tensorType.getNumElements(), 64));

      OperationState kernelState(loc, "tile.training_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute("family", builder.getStringAttr("optimizer_vjp"));
      kernelState.addAttribute("optimizer", scheduled.getOptimizerAttr());
      kernelState.addAttribute("storage", builder.getStringAttr("f32"));
      kernelState.addAttribute("arch", scheduled.getArchAttr());
      kernelState.addAttribute("learning_rate", scheduled.getLearningRateAttr());
      kernelState.addAttribute("beta1", scheduled.getBeta1Attr());
      kernelState.addAttribute("beta2", scheduled.getBeta2Attr());
      kernelState.addAttribute("epsilon", scheduled.getEpsilonAttr());
      kernelState.addAttribute("momentum", scheduled.getMomentumAttr());
      kernelState.addAttribute("weight_decay", scheduled.getWeightDecayAttr());
      kernelState.addAttribute("step", scheduled.getStepAttr());
      kernelState.addAttribute("nesterov", scheduled.getNesterovAttr());
      kernelState.addAttribute("mutation_mode", scheduled.getMutationModeAttr());
      kernelState.addAttribute("alias_policy", scheduled.getAliasPolicyAttr());
      kernelState.addAttribute("state_transition",
                               scheduled.getStateTransitionAttr());
      kernelState.addAttribute("ordered_writes",
                               scheduled.getOrderedWritesAttr());
      kernelState.addAttribute("tessera.workgroup_size",
                               scheduled.getWorkgroupSizeAttr());
      kernelState.addAttribute("tessera.schedule_hash",
                               scheduled.getArtifactHashAttr());
      builder.create(kernelState);

      for (auto [result, buffer] :
           llvm::zip_equal(scheduled.getResults(), outputBuffers)) {
        Value tensor = builder.create<bufferization::ToTensorOp>(
            loc, tensorType, buffer);
        result.replaceAllUsesWith(tensor);
      }
      scheduled.erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::AdafactorVJPOp> scheduledAdafactors;
    mod.walk([&](schedule::AdafactorVJPOp op) {
      scheduledAdafactors.push_back(op);
    });
    for (schedule::AdafactorVJPOp scheduled : scheduledAdafactors) {
      std::string payloadHash = llvm::toHex(
          llvm::SHA256::hash(
              llvm::arrayRefFromStringRef(scheduled.getLineagePayload())),
          /*LowerCase=*/true);
      if (payloadHash != scheduled.getArtifactHash()) {
        scheduled.emitError(
            "Adafactor VJP lineage payload does not match artifact_hash");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled.emitError(
            "requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }
      auto parameterType =
          dyn_cast<RankedTensorType>(scheduled.getInputs()[0].getType());
      if (!parameterType || !parameterType.hasStaticShape() ||
          !parameterType.getElementType().isF32()) {
        scheduled.emitError(
            "initial Adafactor VJP lowering requires static f32 tensors");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto type = cast<RankedTensorType>(tensor.getType());
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      auto allocatePointer = [&](RankedTensorType type) {
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<memref::AllocOp>(loc, memrefType);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        Value pointer =
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
        return std::make_pair(buffer, pointer);
      };

      SmallVector<Value> operands;
      for (Value input : scheduled.getInputs())
        operands.push_back(toPointer(input));
      SmallVector<Value> outputBuffers;
      for (Type resultType : scheduled.getResultTypes()) {
        auto [buffer, pointer] =
            allocatePointer(cast<RankedTensorType>(resultType));
        outputBuffers.push_back(buffer);
        operands.push_back(pointer);
      }
      if (scheduled.getTopology() == "factored") {
        int64_t columns = parameterType.getShape().back();
        int64_t rows = parameterType.getNumElements() / columns;
        operands.push_back(
            builder.create<arith::ConstantIntOp>(loc, rows, 64));
        operands.push_back(
            builder.create<arith::ConstantIntOp>(loc, columns, 64));
      } else {
        operands.push_back(builder.create<arith::ConstantIntOp>(
            loc, parameterType.getNumElements(), 64));
      }

      OperationState kernelState(loc, "tile.training_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute("family",
                               builder.getStringAttr("adafactor_vjp"));
      kernelState.addAttribute("topology", scheduled.getTopologyAttr());
      kernelState.addAttribute("storage", builder.getStringAttr("f32"));
      kernelState.addAttribute("arch", scheduled.getArchAttr());
      kernelState.addAttribute("learning_rate", scheduled.getLearningRateAttr());
      kernelState.addAttribute("beta2", scheduled.getBeta2Attr());
      kernelState.addAttribute("epsilon", scheduled.getEpsilonAttr());
      kernelState.addAttribute("mutation_mode", scheduled.getMutationModeAttr());
      kernelState.addAttribute("alias_policy", scheduled.getAliasPolicyAttr());
      kernelState.addAttribute("state_transition",
                               scheduled.getStateTransitionAttr());
      kernelState.addAttribute("ordered_writes", scheduled.getOrderedWritesAttr());
      kernelState.addAttribute("tessera.workgroup_size",
                               scheduled.getWorkgroupSizeAttr());
      kernelState.addAttribute("tessera.schedule_hash",
                               scheduled.getArtifactHashAttr());
      builder.create(kernelState);

      for (auto [result, buffer, type] : llvm::zip_equal(
               scheduled.getResults(), outputBuffers,
               scheduled.getResultTypes())) {
        Value tensor = builder.create<bufferization::ToTensorOp>(
            loc, cast<RankedTensorType>(type), buffer);
        result.replaceAllUsesWith(tensor);
      }
      scheduled.erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }

    SmallVector<schedule::SequenceMixerBackwardOp> scheduledMixers;
    mod.walk([&](schedule::SequenceMixerBackwardOp op) {
      scheduledMixers.push_back(op);
    });
    for (schedule::SequenceMixerBackwardOp scheduled : scheduledMixers) {
      std::string payloadHash = llvm::toHex(
          llvm::SHA256::hash(
              llvm::arrayRefFromStringRef(scheduled.getLineagePayload())),
          /*LowerCase=*/true);
      if (payloadHash != scheduled.getArtifactHash()) {
        scheduled.emitError(
            "sequence-mixer lineage payload does not match artifact_hash");
        return signalPassFailure();
      }
      SmallVector<schedule::ArtifactOp> matchingArtifacts;
      mod.walk([&](schedule::ArtifactOp artifact) {
        if (artifact.getHash() == scheduled.getArtifactHash())
          matchingArtifacts.push_back(artifact);
      });
      if (matchingArtifacts.size() != 1) {
        scheduled.emitError("requires exactly one matching schedule.artifact");
        return signalPassFailure();
      }
      auto qType = dyn_cast<RankedTensorType>(scheduled.getQ().getType());
      auto vType = dyn_cast<RankedTensorType>(scheduled.getV().getType());
      if (!qType || !vType || !qType.hasStaticShape() ||
          !vType.hasStaticShape() || !qType.getElementType().isF32() ||
          !vType.getElementType().isF32()) {
        scheduled.emitError(
            "initial sequence-mixer lowering requires static f32 tensors");
        return signalPassFailure();
      }

      Location loc = scheduled.getLoc();
      builder.setInsertionPoint(scheduled);
      auto pointerType = LLVM::LLVMPointerType::get(&getContext());
      auto toPointer = [&](Value tensor) -> Value {
        auto type = cast<RankedTensorType>(tensor.getType());
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<bufferization::ToBufferOp>(
            loc, memrefType, tensor);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        return builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
      };
      auto allocatePointer = [&](RankedTensorType type) {
        auto memrefType = MemRefType::get(type.getShape(), type.getElementType());
        Value buffer = builder.create<memref::AllocOp>(loc, memrefType);
        Value index =
            builder.create<memref::ExtractAlignedPointerAsIndexOp>(loc, buffer);
        Value integer = builder.create<arith::IndexCastOp>(
            loc, builder.getI64Type(), index);
        Value pointer =
            builder.create<LLVM::IntToPtrOp>(loc, pointerType, integer);
        return std::make_pair(buffer, pointer);
      };

      SmallVector<Value> operands;
      for (Value input : {scheduled.getQ(), scheduled.getK(), scheduled.getV(),
                          scheduled.getGate(), scheduled.getBeta(),
                          scheduled.getDecay(), scheduled.getDy()})
        operands.push_back(toPointer(input));
      SmallVector<Value> outputBuffers;
      for (Type resultType : scheduled.getResultTypes()) {
        auto [buffer, pointer] =
            allocatePointer(cast<RankedTensorType>(resultType));
        outputBuffers.push_back(buffer);
        operands.push_back(pointer);
      }
      for (int64_t dimension : {qType.getShape()[0], qType.getShape()[1],
                                qType.getShape()[2], qType.getShape()[3],
                                vType.getShape()[3]})
        operands.push_back(
            builder.create<arith::ConstantIntOp>(loc, dimension, 64));

      OperationState kernelState(loc, "tile.training_kernel");
      kernelState.addOperands(operands);
      kernelState.addAttribute(
          "family", builder.getStringAttr("sequence_mixer_backward"));
      kernelState.addAttribute("mixer_family", scheduled.getFamilyAttr());
      kernelState.addAttribute("storage", builder.getStringAttr("f32"));
      kernelState.addAttribute("arch", scheduled.getArchAttr());
      kernelState.addAttribute("erase", scheduled.getEraseAttr());
      kernelState.addAttribute("chunk_size", scheduled.getChunkSizeAttr());
      kernelState.addAttribute("parallel_chunks",
                               scheduled.getParallelChunksAttr());
      kernelState.addAttribute("mutation_mode", scheduled.getMutationModeAttr());
      kernelState.addAttribute("alias_policy", scheduled.getAliasPolicyAttr());
      kernelState.addAttribute("workspace_owner",
                               scheduled.getWorkspaceOwnerAttr());
      kernelState.addAttribute("phase_order", scheduled.getPhaseOrderAttr());
      kernelState.addAttribute("tessera.workgroup_size",
                               scheduled.getWorkgroupSizeAttr());
      kernelState.addAttribute("tessera.schedule_hash",
                               scheduled.getArtifactHashAttr());
      builder.create(kernelState);

      for (auto [result, buffer, type] : llvm::zip_equal(
               scheduled.getResults(), outputBuffers,
               scheduled.getResultTypes())) {
        Value tensor = builder.create<bufferization::ToTensorOp>(
            loc, cast<RankedTensorType>(type), buffer);
        result.replaceAllUsesWith(tensor);
      }
      scheduled.erase();
      for (schedule::ArtifactOp artifact : matchingArtifacts)
        artifact.erase();
    }
  }
};
} // anonymous namespace

// ---------------------------------------------------------------------------
// Factory functions
// ---------------------------------------------------------------------------

std::unique_ptr<mlir::Pass> createPMV11VerifierPass() {
  return std::make_unique<PMV11VerifierPass>();
}

LogicalResult normalizeSM120MatmulEntryNames(ModuleOp mod) {
  auto target = mod->getAttrOfType<StringAttr>("tessera.target");
  auto arch = mod->getAttrOfType<StringAttr>("tessera.arch");
  if (!target || target.getValue() != "nvidia_sm120" ||
      !arch || arch.getValue() != "sm_120")
    return mod.emitError("[TILE_IR_LOWERING] SM120 Schedule delegation requires "
                         "explicit nvidia_sm120 target and sm_120 architecture");
  SymbolTable symbols(mod);
  SmallVector<func::FuncOp> entries;
  mod.walk([&](Operation *op) {
    if (op->getName().getStringRef() == "tessera.matmul" &&
        !op->hasAttr("tessera.canonical_k_step")) {
      auto fn = op->getParentOfType<func::FuncOp>();
      if (fn && !llvm::is_contained(entries, fn))
        entries.push_back(fn);
    }
  });
  constexpr llvm::StringLiteral prefix = "nvidia_sm120_scheduled_matmul_";
  for (func::FuncOp fn : entries) {
    if (fn.getName().starts_with(prefix))
      continue;
    std::string name = (prefix + fn.getName()).str();
    if (failed(symbols.rename(fn, name)))
      return fn.emitError("[TILE_IR_LOWERING] SM120 entry namespace collision");
  }
  return success();
}

std::unique_ptr<mlir::Pass> createGraphToSchedulePass() {
  return std::make_unique<GraphToSchedulePass>();
}

std::unique_ptr<mlir::Pass> createScheduleToTilePass() {
  return std::make_unique<ScheduleToTilePass>();
}

// ---------------------------------------------------------------------------
// Pipeline builders (called from the tessera-opt driver)
// ---------------------------------------------------------------------------

void buildPMV11VerifyPipeline(OpPassManager &pm) {
  pm.addPass(createPMV11VerifierPass());
  pm.addPass(mlir::createCSEPass());          // expose duplicate ops
  pm.addPass(mlir::createCanonicalizerPass()); // fold trivial patterns
}

void buildPMV11LegalizePipeline(OpPassManager &pm) {
  pm.addPass(createPMV11VerifierPass());    // validate before transforms
  pm.addPass(createGraphToSchedulePass());
  pm.addPass(createScheduleToTilePass());
  pm.addPass(mlir::createCanonicalizerPass());
}

// Register all passes so tessera-opt --help shows them.
void registerPMV11Passes() {
  PassRegistration<PMV11VerifierPass>();
  PassRegistration<GraphToSchedulePass>();
  PassRegistration<ScheduleToTilePass>();

  // Pipelines
  PassPipelineRegistration<>(
      "tessera-pm-verify-pipeline",
      "Verify all Programming Model v1.1 ops",
      [](OpPassManager &pm) { buildPMV11VerifyPipeline(pm); });

  PassPipelineRegistration<>(
      "tessera-pm-legalize-pipeline",
      "Bounded static matmul Graph -> Schedule -> launch Tile lowering",
      [](OpPassManager &pm) { buildPMV11LegalizePipeline(pm); });
}

} // namespace tessera
