"""Matched native-owner diagnostic; not a public @jit latency benchmark."""
import argparse
import hashlib
import json
import os
from pathlib import Path
from statistics import median
import subprocess
import time

import numpy as np

from tessera.compiler.emit.nvidia_cuda import NvidiaDeviceSession
from tests.device.nvidia import test_prepared_attention_row_owner as helpers


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--batches",type=int,default=8)
    parser.add_argument("--reps",type=int,default=5)
    args=parser.parse_args()
    if args.batches<4 or args.reps<1:raise ValueError("at least four interleaved batches and one repetition required")
    helpers.require_device()
    root=Path(helpers.__file__).resolve().parents[3]
    files=["src/compiler/programming_model/lib/NativeAttentionRowCorrection.h",
           "src/compiler/codegen/tessera_gpu_backend_NVIDIA/runtime/cuda/attention_jvp_prepared.cpp",
           "src/compiler/codegen/tessera_gpu_backend_NVIDIA/runtime/cuda/tessera_nvidia_ptx_launch.h",
           "tests/device/nvidia/test_prepared_attention_row_owner.py"]
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    provider=Path(os.environ["TESSERA_NVIDIA_PTX_LAUNCH_LIB"])
    before={name:digest(root/name) for name in files}
    provider_hash=digest(provider)
    gpu=subprocess.check_output(["/usr/lib/wsl/lib/nvidia-smi","--query-gpu=name,uuid,compute_cap,driver_version","--format=csv,noheader"],text=True).strip()
    rows=[]
    for storage in ("f16","bf16"):
        for dims in ((1,2,1,3,5,4,3),(1,4,2,1,129,8,6),(1,4,2,7,129,8,6),(1,4,2,17,129,32,24)):
            inputs,expected=helpers.values(storage,True,True,True,seed=9124,dims=dims)
            active=(0,1,2,3)
            old_images=helpers.images(storage,True,True,True,active,128,dims,True)
            new_images=helpers.images(storage,True,True,True,active,128,dims,False)
            assert old_images[0]==new_images[0], "forward image must be bit-identical"
            with NvidiaDeviceSession():
                old=new=None
                try:
                    old=helpers.RowOwner(storage,True,True,True,active,dims=dims,legacy=True)
                    new=helpers.RowOwner(storage,True,True,True,active,dims=dims)
                    controls=old.invoke(inputs,expected)[0]
                    candidate=new.invoke(inputs,expected)[0]
                    for a,b,oracle in zip(controls,candidate,expected,strict=True):
                        helpers.compare(a,oracle);helpers.compare(b,oracle)
                        np.testing.assert_array_equal(a,b)
                    for _ in range(3):
                        old.invoke(inputs,expected);new.invoke(inputs,expected)
                    samples={"inline":[],"row_prepass":[]}
                    for batch in range(args.batches):
                        order=("inline","row_prepass") if batch%2==0 else ("row_prepass","inline")
                        for name in order:
                            owner=old if name=="inline" else new
                            for rep in range(args.reps):
                                start=time.perf_counter_ns()
                                outputs,times,status=owner.invoke(inputs,expected)
                                elapsed=(time.perf_counter_ns()-start)/1e6
                                assert status==0
                                window=owner.window()
                                # Numerical checking and the extra window query
                                # are outside the completed-call wall interval.
                                for actual,oracle in zip(outputs,expected,strict=True):helpers.compare(actual,oracle)
                                stages=[float(times[2]),0.0,float(times[3])] if name=="inline" else list(map(float,times[2:5]))
                                samples[name].append(dict(batch=batch,rep=rep,order=list(order),
                                    forward_ms=stages[0],row_ms=stages[1],backward_ms=stages[2],
                                    native_device_window_ms=window,diagnostic_owner_completed_call_ms=elapsed))
                    medians={name:{key:median(s[key] for s in arm) for key in (
                        "forward_ms","row_ms","backward_ms","native_device_window_ms","diagnostic_owner_completed_call_ms")}
                        for name,arm in samples.items()}
                    rows.append(dict(storage=storage,output_storage="f32",bias=True,lse_cotangent=True,
                        shape=list(dims),active=list(active),threads=128,correctness="FP64_and_bitwise_before_timing; FP64_every_sample",samples=samples,medians=medians,
                        device_ratio_inline_over_prepass=medians["inline"]["native_device_window_ms"]/medians["row_prepass"]["native_device_window_ms"],
                        completed_call_ratio_inline_over_prepass=medians["inline"]["diagnostic_owner_completed_call_ms"]/medians["row_prepass"]["diagnostic_owner_completed_call_ms"],
                        row_workspace_bytes=new.info()[0],
                        images={name:[None if image is None else dict(entry=image[0],sha256=hashlib.sha256(image[1]).hexdigest()) for image in arm]
                                for name,arm in (("inline",old_images),("row_prepass",new_images))}))
                    print(storage,dims,rows[-1]["device_ratio_inline_over_prepass"],rows[-1]["completed_call_ratio_inline_over_prepass"],flush=True)
                finally:
                    if new is not None:new.close()
                    if old is not None:old.close()
    assert before=={name:digest(root/name) for name in files}
    assert provider_hash==digest(provider)
    packet=dict(schema="tessera.native_attention_row_owner_diagnostic.v1",scope="native C++ prepared owner only; public frontend portable-program integration and default admission remain open",device=gpu,
        source_commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),source_sha256=before,
        provider_path=str(provider),provider_sha256=provider_hash,
        timing_domains={"native_device_window_ms":"same CUDA event interval from forward start through backward stop in the native C++ owner; includes inter-stage native launch gaps",
            "diagnostic_owner_completed_call_ms":"Python test-harness argument/output allocation and ctypes call through native snapshot/upload/three-stage-or-inline execution/readback/completion; compiler, numerical checks and window query excluded; not public @jit latency",
            "forward_ms,row_ms,backward_ms":"individual native CUDA event stage windows; row=0 for inline"},
        methodology=dict(batches=args.batches,reps=args.reps,warmup=3,interleaving="AB/BA alternating batches",matched_inputs="identical stored half roots, FP32 bias/dO/dLSE",shared_forward="bit-identical PTX"),rows=rows)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(packet,indent=2,allow_nan=False)+"\n")


if __name__=="__main__":main()
