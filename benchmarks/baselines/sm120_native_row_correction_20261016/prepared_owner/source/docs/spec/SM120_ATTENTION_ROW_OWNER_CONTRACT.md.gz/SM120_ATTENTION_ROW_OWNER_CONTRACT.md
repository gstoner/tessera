# SM120 prepared attention row-residual owner

Owner: E2E-REAL-6 / AD-RESIDUAL-EVAL-1 / FRONTEND-IR-MEDIUM-1.
Synchronization: SM120-NATIVE-ROW-CORRECTION-20261016.

## Scope

This additive native C ABI owns forward, FP32 row correction and backward images
produced through the original Graph/native AD -> Schedule -> Tile -> NVIDIA/LLVM
route. It initially admits static compact FP16/BF16 QKV, matching half or FP32
dO, optional physical FP32 broadcast bias and optional FP32 dLSE seed. The row
producer computes ordered FP32 probability-weighted dot(dO,V) minus that seed.
The consumer uses the explicit residual and never subtracts the seed twice.

The native owner is executable and tested directly. Its public Python program
packaging, portable schema and original frontend replay integration remain open.
Existing VJP v1/v2 and JVP schema 5 bounded / schema 6 static are unchanged.

## Private frame

| Slot | Role | Physical storage |
| --- | --- | --- |
| 0–2 | Q, K, V snapshots | FP16 or BF16 |
| 3 | Forward O | Matching half or FP32 |
| 4 | Saved natural-log LSE | FP32 |
| 5 | dO snapshot | O storage |
| 6 | Optional bias snapshot | FP32 |
| 7–9 | Active dQ, dK, dV | QKV storage |
| 10 | Active physical dBias | FP32 |
| 11 | Optional dLSE snapshot | FP32 |
| 12 | Row correction | FP32, absent for dV-only activity |

One checked aligned device arena and pinned host staging frame remain owned
until close. Root snapshots and all stages share one private nonblocking stream.
Resident roots require producer streams, matching context, alignment and allocation
capacity; private arena aliases are rejected. Native events order pending producer
writes before snapshots. Errors drain queued work before storage is reused or freed.
Output copies complete before return. Fork and context-generation guards remain.

## Additive entry points

`tessera_nvidia_attention_vjp_rows_prepare` accepts three image/size/entry triples,
seven logical dimensions, physical bias extents, frontend permutation, requested
physical gradient order and storage/seed policies. Compiler-generated symbols
encode storage, bias, seed, activity and block geometry. Actual compiled parameter
widths, offsets and exact count are checked using the CUDA driver. The producer
uses 32 threads; the consumer uses its sealed 64/128-thread geometry.

For exactly dV-only activity, preparation requires the row image triple to be
absent. No row module, row allocation or row launch is required. Its verified
consumer does not read the row argument. `rows_info` returns logical row bytes
and stage count without exposing private addresses.

`rows_invoke` and `rows_invoke_resident_ordered` require an explicit timing output
capacity. With a nonnull timing pointer the capacity must be exactly four floats:

1. forward event window;
2. row producer event window, zero when elided;
3. backward event window;
4. complete native device interval from forward start through backward stop.

A null pointer with capacity zero suppresses timing output. Wrong capacities and
mixed old/new invoke interfaces refuse before output writes. The legacy invoke
still writes only its original two floats. `last_device_window` can query the
same complete interval for either reverse ABI after a successful completed call;
it refuses before a completed invocation. Thus inline and prepass comparisons
use the same device interval definition without widening legacy timing buffers.

## Evidence and remaining gates

Direct owning RTX5070 proof covers changed inputs, half/F32 dO, bias/seed variants,
requested gradient order, compact geometry, pending producer streams, value-only
elision, timing sentinels and an actual compiled parameter-count mismatch.
Existing public reverse and shared JVP/VJP stream-isolation proof checks provider
compatibility. The diagnostic native-owner A/B uses identical stored inputs and
bit-identical forward PTX, alternating arm order, correctness checks outside the
wall timing interval and separate stage/device/completed-call scopes. This is not
a public @jit latency measurement and does not promote a global default.

Complete all-member image/source-pair/policy provenance, strict new portable
program validation, original frontend replay, output generations and public-call
benchmarking remain required before route selection and the consolidated PR.

Evidence: benchmarks/baselines/sm120_native_row_correction_20261016/prepared_owner/README.md.
