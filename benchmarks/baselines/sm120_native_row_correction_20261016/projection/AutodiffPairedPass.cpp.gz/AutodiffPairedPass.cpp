//===- AutodiffPairedPass.cpp - Paired forward/backward autodiff --*- C++ -*-===//
//
// Phase 2 of docs/audit/compiler/AUTODIFF_UNIFICATION_PLAN.md. Where the
// in-place `--tessera-autodiff` pass fuses the backward into the forward
// function's return (a bootstrap), this pass emits the **paired-program model**:
//
//   forward(inputs) -> (primals, explicit residuals...)
//   @f__bwd(inputs, out_cotangents..., residuals...)
//                   -> input_cotangents
//
// This is the deterministic forward/backward/residual ABI the rest of the plan
// (runtime binding in Phase 4, per-op-family expansion in Phase 5, distributed +
// accelerator promotion in Phase 6) keys off. It is verifiable independently of
// Python tape state — a lit fixture checks the backward signature + body.
//
// RECOMPUTE_ALL remains the default. SAVE regions append typed, named residual
// values to the paired ABI; backward must consume those values and cannot
// silently relabel SAVE/HYBRID as recomputation. The backward still clones the
// forward cone for unsaved intermediates (CSE later collapses redundant work).
// This is not a toy default: the shipped ROCm gfx1151
// flash-attention backward lane (`_execute_rocm_compiled_flash_attn_bwd`) takes
// `(dO, Q, K, V)` and likewise *recomputes* the softmax rather than saving the
// logsumexp. SAVE currently carries scan state tapes, branch identity, and
// executed while trip counts; scan-form HYBRID performs bounded replay from
// the nearest explicitly retained checkpoint.
//
// The paired backward is an **ABI, not an implementation**: a hand-emitted
// backward kernel (ROCm WMMA flash-attn bwd) satisfies the same
// `@f__bwd(inputs, out_cotangents) -> input_cotangents` contract and is a
// first-class arbiter candidate (Decision #28). This pass is the compiler-
// generated implementation of that contract.
//
//===----------------------------------------------------------------------===//

#include "tessera/Dialect/Attn/AttnDialect.h"
#include "mlir/Dialect/Arith/IR/Arith.h"
#include "mlir/Dialect/ControlFlow/IR/ControlFlowOps.h"
#include "mlir/Dialect/Func/IR/FuncOps.h"
#include "mlir/Dialect/Linalg/IR/Linalg.h"
#include "mlir/Dialect/SCF/IR/SCF.h"
#include "mlir/Dialect/Tensor/IR/Tensor.h"
#include "mlir/IR/Builders.h"
#include "mlir/IR/IRMapping.h"
#include "mlir/IR/Matchers.h"
#include "mlir/IR/TypeUtilities.h"
#include "Tessera/Dialect/Tile/TileDialect.h"
#include "mlir/Pass/Pass.h"
#include "mlir/Pass/PassManager.h"
#include "llvm/ADT/StringExtras.h"
#include "llvm/Support/SHA256.h"
#include "llvm/ADT/DenseMap.h"
#include "llvm/ADT/SmallPtrSet.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/STLExtras.h"

#include <algorithm>
#include <functional>

#include "Tessera/IR/TesseraOps.h"
#include "Tessera/Transforms/GraphDataflow.h"
#include "Tessera/Transforms/Passes.h"
#include "llvm/Support/JSON.h"
#include "Tessera/Transforms/LoopBodyYield.h"
#include "Tessera/Transforms/RegionAdjointInterface.h"
#include "Tessera/Transforms/SemanticEffects.h"

#include "mlir/Dialect/GPU/IR/GPUDialect.h"
#include "mlir/Dialect/LLVMIR/LLVMDialect.h"
#include "mlir/Dialect/MemRef/IR/MemRef.h"
#include "mlir/Dialect/Math/IR/Math.h"
#include "NativeStorageJVP.h"
#include "NativeScaledMatmulProgram.h"
#include "NativeAttentionProjection.h"
#include "../../compiler/ir/AttentionADContract.h"

namespace tessera {

namespace {
// A gather generator is deliberately narrower than an arbitrary tensor.generate:
// index-only arithmetic followed by one scalar read from an enclosing tensor.
static mlir::tensor::ExtractOp gatherRead(mlir::Operation *op) {
  using namespace mlir;
  auto generate = dyn_cast<tensor::GenerateOp>(op);
  if (!generate || !llvm::hasSingleElement(generate.getBody())) return {};
  auto &body = generate.getBody().front();
  auto yield = dyn_cast<tensor::YieldOp>(body.getTerminator());
  if (!yield || yield->getNumOperands() != 1) return {};
  auto read = yield->getOperand(0).getDefiningOp<tensor::ExtractOp>();
  if (!read || read->getBlock() != &body ||
      !isa<FloatType>(read.getType()) ||
      generate->isAncestor(read.getTensor().getParentRegion()->getParentOp())) return {};
  for (Operation &nested : body.without_terminator()) {
    if (&nested == read.getOperation()) continue;
    if (nested.getName().getDialectNamespace() != "arith" || nested.getNumRegions() ||
        !llvm::all_of(nested.getResultTypes(), [](Type t) { return t.isIndex() || t.isInteger(); }))
      return {};
  }
  return read;
}


constexpr const char *kAutodiffMarker = "tessera.autodiff";

using CotangentMap = llvm::DenseMap<mlir::Value, mlir::Value>;
bool hasStochasticEffect(mlir::Operation *op) {
  return getRegisteredSemanticEffect(op) == SemanticEffectLevel::Random;
}

// W4-EFFECTS-1 slice E2. A stochastic op used to be rejected wholesale, which
// conflated two unrelated questions: whether the draw can be REPLAYED, and
// whether it can be DIFFERENTIATED. They are now separate, and each refusal
// says which one failed.
//
// Admission requires a recorded product of class `keyed_rng` (the E1 carrier,
// `python/tessera/compiler/recorded_product.py`). The product is what makes
// replay a function of recorded data: the S4 generator is counter-based, so a
// keyed draw is a pure function of its key. An op with no product stays
// closed — absence is not permission.
constexpr const char *kRecordedProductClass =
    "tessera.recorded_product.effect_class";
constexpr const char *kRecordedProductDigest =
    "tessera.recorded_product.digest";

// Reject a product we cannot VERIFY. Checking the class string and the
// digest's length would admit any hand-written 64-character value — the
// gate's own positive fixture used "1111…" and was accepted — so a corrupted
// or fabricated carrier could walk through the fail-closed reproducibility
// check (PR #630 review). The carrier is therefore validated as a CHAIN:
//   sha256(payload) == digest, and the payload says it belongs to THIS op,
//   in this class, under the schema this compiler understands.
// Breaking any link changes a hash, so a product cannot be pasted between
// operations or edited in place.
bool carriesKeyedRngProduct(mlir::Operation *op) {
  return tessera::carriesVerifiedRecordedProduct(op, "keyed_rng");
}

// Diagnose precisely why a stochastic op cannot enter the region. Returns
// true when the op is admitted.
bool admitStochasticOp(mlir::Operation *op) {
  if (!hasStochasticEffect(op))
    return true;
  auto cls = op->getAttrOfType<mlir::StringAttr>(kRecordedProductClass);
  if (!cls) {
    op->emitError()
        << "AUTODIFF_STOCHASTIC_NO_PRODUCT: stochastic op " << op->getName()
        << " carries no recorded product, so its replay is not a function of "
           "recorded data. A keyed draw must carry a `keyed_rng` product "
           "(W4-EFFECTS-1 E1); an ambient or generator-stateful draw has no "
           "product and stays fail-closed";
    return false;
  }
  if (cls.getValue() != "keyed_rng") {
    op->emitError()
        << "AUTODIFF_STOCHASTIC_UNKEYED: stochastic op " << op->getName()
        << " carries a '" << cls.getValue()
        << "' product, which does not establish reproducibility for a draw; "
           "only `keyed_rng` does";
    return false;
  }
  std::string failure = tessera::recordedProductFailure(op, "keyed_rng");
  if (!failure.empty()) {
    op->emitError() << "AUTODIFF_STOCHASTIC_NO_PRODUCT: stochastic op "
                    << op->getName() << " " << failure;
    return false;
  }
  return true;
}

void eraseStopGradientBarriers(mlir::func::FuncOp func) {
  llvm::SmallVector<mlir::Operation *> barriers;
  func.walk([&](mlir::Operation *op) {
    if (op->getName().getStringRef() == "tessera.stop_gradient")
      barriers.push_back(op);
  });
  for (mlir::Operation *op : barriers) {
    if (op->getNumOperands() == 1 && op->getNumResults() == 1) {
      op->getResult(0).replaceAllUsesWith(op->getOperand(0));
      op->erase();
    }
  }
}

static mlir::FailureOr<mlir::RankedTensorType>
getResidualTapeType(mlir::Type stateType, int64_t slots) {
  if (slots <= 0)
    return mlir::failure();
  if (auto ranked = mlir::dyn_cast<mlir::RankedTensorType>(stateType)) {
    llvm::SmallVector<int64_t> shape{slots};
    llvm::append_range(shape, ranked.getShape());
    return mlir::RankedTensorType::get(shape, ranked.getElementType(),
                                       ranked.getEncoding());
  }
  if (stateType.isIntOrIndexOrFloat())
    return mlir::RankedTensorType::get({slots}, stateType);
  return mlir::failure();
}

using SavedSlotShapeEnvelopes =
    llvm::DenseMap<unsigned, llvm::SmallVector<int64_t>>;

// Dynamic saved values need two independent facts: a maximum allocation
// envelope and the actual extent at each retained checkpoint.  The former is
// carried by these three flat, total attributes; the latter is materialized as
// a shape tape beside the data tape below.  Indices address the primal loop
// iter-argument ABI, so mixed scalar/static/dynamic state cannot be confused by
// ordinal compression.
static mlir::FailureOr<SavedSlotShapeEnvelopes>
readSavedSlotShapeEnvelopes(mlir::Operation *owner, mlir::TypeRange stateTypes,
                            bool requireEveryDynamic) {
  auto indices = owner->getAttrOfType<mlir::DenseI64ArrayAttr>(
      "tessera.autodiff.saved_slot_shape_envelope_indices");
  auto ranks = owner->getAttrOfType<mlir::DenseI64ArrayAttr>(
      "tessera.autodiff.saved_slot_shape_envelope_ranks");
  auto flatBounds = owner->getAttrOfType<mlir::DenseI64ArrayAttr>(
      "tessera.autodiff.saved_slot_shape_envelope_bounds");
  if (!indices && !ranks && !flatBounds) {
    if (requireEveryDynamic && llvm::any_of(stateTypes, [](mlir::Type type) {
          auto ranked = mlir::dyn_cast<mlir::RankedTensorType>(type);
          return ranked && !ranked.hasStaticShape();
        }))
      return mlir::failure();
    return SavedSlotShapeEnvelopes{};
  }
  if (!indices || !ranks || !flatBounds || indices.size() != ranks.size())
    return mlir::failure();

  SavedSlotShapeEnvelopes envelopes;
  size_t boundOffset = 0;
  const size_t flatBoundCount = static_cast<size_t>(flatBounds.size());
  for (auto [entry, rawIndex] : llvm::enumerate(indices.asArrayRef())) {
    int64_t rawRank = ranks[entry];
    if (rawIndex < 0 || rawIndex >= static_cast<int64_t>(stateTypes.size()) ||
        rawRank <= 0 ||
        boundOffset + static_cast<size_t>(rawRank) > flatBoundCount ||
        envelopes.contains(static_cast<unsigned>(rawIndex)))
      return mlir::failure();
    auto ranked = mlir::dyn_cast<mlir::RankedTensorType>(
        stateTypes[static_cast<unsigned>(rawIndex)]);
    if (!ranked || ranked.hasStaticShape() || ranked.getRank() != rawRank)
      return mlir::failure();
    llvm::SmallVector<int64_t> bounds;
    for (int64_t dim = 0; dim < rawRank; ++dim) {
      int64_t bound = flatBounds[boundOffset++];
      int64_t staticExtent = ranked.getDimSize(dim);
      if (bound <= 0 ||
          (!mlir::ShapedType::isDynamic(staticExtent) &&
           bound != staticExtent))
        return mlir::failure();
      bounds.push_back(bound);
    }
    envelopes.try_emplace(static_cast<unsigned>(rawIndex), std::move(bounds));
  }
  if (boundOffset != flatBoundCount)
    return mlir::failure();
  if (requireEveryDynamic)
    for (auto [index, type] : llvm::enumerate(stateTypes)) {
      auto ranked = mlir::dyn_cast<mlir::RankedTensorType>(type);
      if (ranked && !ranked.hasStaticShape() && !envelopes.contains(index))
        return mlir::failure();
    }
  return envelopes;
}

static llvm::SmallVector<mlir::Value>
getDynamicTensorSizes(mlir::OpBuilder &builder, mlir::Location loc,
                      mlir::Value source,
                      mlir::RankedTensorType sourceType) {
  llvm::SmallVector<mlir::Value> sizes;
  for (int64_t dim = 0; dim < sourceType.getRank(); ++dim)
    if (sourceType.isDynamicDim(dim))
      sizes.push_back(
          mlir::tensor::DimOp::create(builder, loc, source, dim));
  return sizes;
}

static mlir::FailureOr<mlir::Value>
buildInactiveResidualZero(mlir::OpBuilder &builder, mlir::Location loc,
                          mlir::Type type) {
  mlir::Type elementType = mlir::getElementTypeOrSelf(type);
  if (!llvm::isa<mlir::FloatType>(elementType))
    return mlir::failure();
  mlir::TypedAttr zero = mlir::FloatAttr::get(elementType, 0.0);
  if (auto shaped = mlir::dyn_cast<mlir::ShapedType>(type)) {
    if (shaped.hasStaticShape())
      return mlir::arith::ConstantOp::create(
                 builder, loc, mlir::DenseElementsAttr::get(shaped, zero))
          .getResult();
    auto ranked = mlir::dyn_cast<mlir::RankedTensorType>(shaped);
    if (!ranked)
      return mlir::failure();
    // The inactive branch has no trustworthy runtime extents for a value that
    // exists only in the taken branch.  A zero-extent tensor is a type-correct,
    // initialized sentinel for every dynamic dimension.  Predicate replay
    // guarantees this value is never selected by the pullback.
    llvm::SmallVector<mlir::Value> dynamicSizes;
    for (int64_t dim : ranked.getShape())
      if (mlir::ShapedType::isDynamic(dim))
        dynamicSizes.push_back(
            mlir::arith::ConstantIndexOp::create(builder, loc, 0));
    mlir::Value empty = mlir::tensor::EmptyOp::create(
        builder, loc, ranked.getShape(), ranked.getElementType(),
        dynamicSizes);
    mlir::Value zeroValue =
        mlir::arith::ConstantOp::create(builder, loc, zero);
    return mlir::linalg::FillOp::create(builder, loc,
                                        mlir::ValueRange{zeroValue},
                                        mlir::ValueRange{empty})
        .getResult(0);
  }
  return mlir::arith::ConstantOp::create(builder, loc, zero).getResult();
}

static llvm::SmallVector<mlir::Value>
collectBranchResidualCandidates(mlir::Region &region) {
  llvm::SmallVector<mlir::Value> candidates;
  for (mlir::Operation &nested : region.front().without_terminator())
    for (mlir::Value result : nested.getResults())
      if (llvm::isa<mlir::FloatType>(
              mlir::getElementTypeOrSelf(result.getType())))
        candidates.push_back(result);
  return candidates;
}

// Prefer the compact canonical scf.if form for a verified acyclic diamond.
// Remaining bounded multi-block graphs are handled by the general state-machine
// structurizer below; unbounded/effectful graphs still fail closed.
static mlir::LogicalResult structurizeNativeDiamonds(
    mlir::func::FuncOp function) {
  llvm::SmallVector<mlir::scf::ExecuteRegionOp> regions;
  // Collect innermost regions first: structurizing an outer execute_region
  // erases its original body and would otherwise invalidate queued nested ops.
  function.walk<mlir::WalkOrder::PostOrder>(
      [&](mlir::scf::ExecuteRegionOp region) {
        if (!region.getRegion().hasOneBlock())
          regions.push_back(region);
      });
  for (mlir::scf::ExecuteRegionOp execute : regions) {
    mlir::Region &region = execute.getRegion();
    if (region.getBlocks().size() != 4)
      continue;
    mlir::Block &entry = region.front();
    auto branch = mlir::dyn_cast<mlir::cf::CondBranchOp>(
        entry.getTerminator());
    if (!branch || branch.getTrueDest() == branch.getFalseDest())
      continue;
    mlir::Block *thenBlock = branch.getTrueDest();
    mlir::Block *elseBlock = branch.getFalseDest();
    auto thenExit = mlir::dyn_cast<mlir::cf::BranchOp>(
        thenBlock->getTerminator());
    auto elseExit = mlir::dyn_cast<mlir::cf::BranchOp>(
        elseBlock->getTerminator());
    if (!thenExit || !elseExit || thenExit.getDest() != elseExit.getDest())
      continue;
    if (thenBlock->getNumArguments() !=
            branch.getTrueDestOperands().size() ||
        elseBlock->getNumArguments() !=
            branch.getFalseDestOperands().size())
      continue;
    mlir::Block *merge = thenExit.getDest();
    if (merge == &entry || merge == thenBlock || merge == elseBlock ||
        thenExit.getDestOperands().size() != merge->getNumArguments() ||
        elseExit.getDestOperands().size() != merge->getNumArguments())
      continue;
    auto finalYield =
        mlir::dyn_cast<mlir::scf::YieldOp>(merge->getTerminator());
    if (!finalYield || finalYield.getNumOperands() != execute.getNumResults())
      continue;

    mlir::OpBuilder builder(execute);
    mlir::IRMapping entryMapping;
    for (mlir::Operation &source : entry.without_terminator())
      builder.clone(source, entryMapping);
    mlir::Value condition =
        entryMapping.lookupOrDefault(branch.getCondition());
    llvm::SmallVector<mlir::Type> mergeTypes(merge->getArgumentTypes().begin(),
                                             merge->getArgumentTypes().end());
    auto replacement = mlir::scf::IfOp::create(
        builder, execute.getLoc(), mergeTypes, condition, true);
    for (mlir::NamedAttribute attr : execute->getAttrs())
      if (attr.getName().getValue().starts_with("tessera."))
        replacement->setAttr(attr.getName(), attr.getValue());
    replacement->setAttr("tessera.autodiff.native_multiblock_structurized",
                         builder.getBoolAttr(true));

    auto cloneArm = [&](mlir::Block *source, mlir::Block *destination,
                        mlir::ValueRange incoming,
                        mlir::cf::BranchOp exit) -> mlir::LogicalResult {
      if (source->getNumArguments() != incoming.size())
        return mlir::failure();
      mlir::OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(destination);
      mlir::IRMapping mapping(entryMapping);
      for (auto [argument, value] :
           llvm::zip_equal(source->getArguments(), incoming))
        mapping.map(argument, entryMapping.lookupOrDefault(value));
      for (mlir::Operation &nested : source->without_terminator())
        builder.clone(nested, mapping);
      llvm::SmallVector<mlir::Value> yields;
      for (mlir::Value value : exit.getDestOperands())
        yields.push_back(mapping.lookupOrDefault(value));
      mlir::scf::YieldOp::create(builder, execute.getLoc(), yields);
      return mlir::success();
    };
    if (mlir::failed(cloneArm(thenBlock, replacement.thenBlock(),
                              branch.getTrueDestOperands(), thenExit)) ||
        mlir::failed(cloneArm(elseBlock, replacement.elseBlock(),
                              branch.getFalseDestOperands(), elseExit))) {
      replacement.erase();
      return mlir::failure();
    }

    builder.setInsertionPointAfter(replacement);
    mlir::IRMapping mergeMapping(entryMapping);
    for (auto [argument, value] :
         llvm::zip_equal(merge->getArguments(), replacement.getResults()))
      mergeMapping.map(argument, value);
    for (mlir::Operation &source : merge->without_terminator())
      builder.clone(source, mergeMapping);
    llvm::SmallVector<mlir::Value> results;
    for (mlir::Value value : finalYield.getOperands())
      results.push_back(mergeMapping.lookupOrDefault(value));
    execute->replaceAllUsesWith(results);
    execute.erase();
  }
  return mlir::success();
}

static mlir::FailureOr<mlir::Value>
buildCFGStateSentinel(mlir::OpBuilder &builder, mlir::Location loc,
                      mlir::Type type) {
  if (type.isIndex())
    return mlir::arith::ConstantIndexOp::create(builder, loc, 0).getResult();
  mlir::Type elementType = mlir::getElementTypeOrSelf(type);
  mlir::TypedAttr zero;
  if (auto floatType = mlir::dyn_cast<mlir::FloatType>(elementType))
    zero = mlir::FloatAttr::get(floatType, 0.0);
  else if (auto integerType = mlir::dyn_cast<mlir::IntegerType>(elementType))
    zero = mlir::IntegerAttr::get(integerType, 0);
  else
    return mlir::failure();
  if (auto shaped = mlir::dyn_cast<mlir::ShapedType>(type)) {
    auto ranked = mlir::dyn_cast<mlir::RankedTensorType>(shaped);
    if (!ranked)
      return mlir::failure();
    if (ranked.hasStaticShape())
      return mlir::arith::ConstantOp::create(
                 builder, loc, mlir::DenseElementsAttr::get(ranked, zero))
          .getResult();
    llvm::SmallVector<mlir::Value> dynamicSizes;
    for (int64_t dim : ranked.getShape())
      if (mlir::ShapedType::isDynamic(dim))
        dynamicSizes.push_back(
            mlir::arith::ConstantIndexOp::create(builder, loc, 0));
    mlir::Value empty = mlir::tensor::EmptyOp::create(
        builder, loc, ranked.getShape(), ranked.getElementType(),
        dynamicSizes);
    // A dynamic state-machine slot is read only after its owning CFG edge has
    // assigned it. Keeping this zero-extent sentinel uninitialized avoids a
    // synthetic active linalg region; PC/done dispatch proves it unobservable.
    return empty;
  }
  return mlir::arith::ConstantOp::create(builder, loc, zero).getResult();
}

static bool isReplayableCFGBodyOperation(mlir::Operation &operation) {
  if (operation.hasTrait<mlir::OpTrait::IsTerminator>())
    return true;
  if (operation.getNumRegions() == 0) {
    // Same admission as the structured region walk, from the same verifier —
    // a keyed draw admissible in an scf.if body must be admissible in a
    // structurized CFG body, or W4's family would depend on which of the two
    // replayability walks happened to see it (#31).
    if (getRegisteredSemanticEffect(&operation) == SemanticEffectLevel::Random &&
        carriesVerifiedRecordedProduct(&operation, "keyed_rng"))
      return true;
    return getRegisteredSemanticEffect(&operation) == SemanticEffectLevel::Pure;
  }
  if (!llvm::isa<mlir::scf::IfOp, mlir::scf::ForOp, mlir::scf::WhileOp>(
          operation))
    return false;
  for (mlir::Region &nestedRegion : operation.getRegions()) {
    if (!nestedRegion.hasOneBlock())
      return false;
    for (mlir::Operation &nested : nestedRegion.front())
      if (!isReplayableCFGBodyOperation(nested))
        return false;
  }
  return true;
}

// Lower any bounded, pure multi-block execute_region into one canonical SCF
// state machine.  Program-counter dispatch treats reducible and irreducible
// CFGs uniformly; a required maximum-step bound makes cycles total and keeps
// reverse replay finite.  Each block argument owns a distinct typed state slot,
// so mixed tensor shapes/dtypes never alias merely because their types match.
static mlir::LogicalResult structurizeBoundedNativeCFGs(
    mlir::func::FuncOp function) {
  // Imported native source may carry its CFG directly in the function body.
  // Normalize that representation into the same bounded state-machine input;
  // do not demand a frontend-manufactured execute_region wrapper.
  if (!function.getBody().empty() && !function.getBody().hasOneBlock()) {
    auto bound=function->getAttrOfType<mlir::IntegerAttr>("tessera.structured_cfg.max_steps");
    auto digest=function->getAttrOfType<mlir::StringAttr>("tessera.structured_cfg.digest");
    if (!bound || bound.getInt()<=0 || bound.getInt()>1'000'000 ||
        !digest || digest.getValue().size()!=64)
      return function.emitError("native function CFG requires a bounded step count and CFG identity");
    mlir::Region original;
    original.takeBody(function.getBody());
    auto *entry=function.addEntryBlock();
    mlir::OpBuilder builder=mlir::OpBuilder::atBlockBegin(entry);
    auto execute=mlir::scf::ExecuteRegionOp::create(builder,function.getLoc(),function.getResultTypes());
    execute.getRegion().takeBody(original);
    auto &oldEntry=execute.getRegion().front();
    for (auto [oldArg,newArg]:llvm::zip_equal(oldEntry.getArguments(),entry->getArguments()))
      oldArg.replaceAllUsesWith(newArg);
    oldEntry.eraseArguments(0,oldEntry.getNumArguments());
    for (auto name:{"tessera.structured_cfg.max_steps","tessera.structured_cfg.digest",
                    "tessera.autodiff.checkpoint_policy",
                    "tessera.autodiff.saved_slot_shape_envelope_indices",
                    "tessera.autodiff.saved_slot_shape_envelope_ranks",
                    "tessera.autodiff.saved_slot_shape_envelope_bounds"})
      if (auto attr=function->getAttr(name)) execute->setAttr(name,attr);
    for (auto &block:execute.getRegion()) {
      if (auto ret=mlir::dyn_cast<mlir::func::ReturnOp>(block.getTerminator())) {
        mlir::OpBuilder at(ret);
        mlir::scf::YieldOp::create(at,ret.getLoc(),ret.getOperands());
        ret.erase();
      }
    }
    mlir::func::ReturnOp::create(builder,function.getLoc(),execute.getResults());
  }
  llvm::SmallVector<mlir::scf::ExecuteRegionOp> regions;
  function.walk<mlir::WalkOrder::PostOrder>(
      [&](mlir::scf::ExecuteRegionOp region) {
        if (!region.getRegion().hasOneBlock())
          regions.push_back(region);
      });
  for (mlir::scf::ExecuteRegionOp execute : regions) {
    mlir::Region &region = execute.getRegion();
    auto maxSteps = execute->getAttrOfType<mlir::IntegerAttr>(
        "tessera.structured_cfg.max_steps");
    auto cfgDigest = execute->getAttrOfType<mlir::StringAttr>(
        "tessera.structured_cfg.digest");
    if (!maxSteps || maxSteps.getInt() <= 0 || maxSteps.getInt() > 1'000'000 ||
        !cfgDigest || cfgDigest.getValue().size() != 64) {
      execute.emitError()
          << "general native CFG requires a positive bounded "
             "tessera.structured_cfg.max_steps and SHA-256 CFG identity";
      return mlir::failure();
    }
    if (region.empty() || region.front().getNumArguments() != 0) {
      execute.emitError()
          << "general native CFG requires an argument-free entry block";
      return mlir::failure();
    }
    auto checkpointPolicy = execute->getAttrOfType<mlir::StringAttr>(
        "tessera.autodiff.checkpoint_policy");
    const bool retainsState =
        checkpointPolicy && (checkpointPolicy.getValue() == "save" ||
                             checkpointPolicy.getValue() == "hybrid");
    llvm::SmallVector<mlir::Block *> blocks;
    llvm::DenseMap<mlir::Block *, unsigned> blockOrdinals;
    llvm::DenseMap<mlir::BlockArgument, unsigned> argumentSlots;
    llvm::DenseMap<mlir::Value, unsigned> valueSlots;
    llvm::SmallVector<mlir::Type> slotTypes;
    for (mlir::Block &block : region) {
      blockOrdinals.try_emplace(&block, blocks.size());
      blocks.push_back(&block);
      for (mlir::BlockArgument argument : block.getArguments()) {
        argumentSlots.try_emplace(argument, slotTypes.size());
        slotTypes.push_back(argument.getType());
      }
      for (mlir::Operation &nested : block.without_terminator()) {
        if (!isReplayableCFGBodyOperation(nested)) {
          execute.emitError()
              << "general native CFG state-machine replay requires pure, "
                 "canonical structured block operations";
          return mlir::failure();
        }
      }
      mlir::Operation *terminator = block.getTerminator();
      if (!llvm::isa<mlir::cf::BranchOp, mlir::cf::CondBranchOp, mlir::cf::SwitchOp,
                     mlir::scf::YieldOp>(terminator)) {
        execute.emitError()
            << "general native CFG supports cf.br, cf.cond_br, cf.switch, and scf.yield "
               "terminators";
        return mlir::failure();
      }
      if (auto yield = mlir::dyn_cast<mlir::scf::YieldOp>(terminator);
          yield && yield->getNumOperands() != execute.getNumResults()) {
        execute.emitError() << "native CFG yield/result cardinality mismatch";
        return mlir::failure();
      }
    }
    // CFG SSA permits dominating definitions to be used across blocks without
    // edge operands. Those values also need persistent state-machine slots.
    for (mlir::Block *block : blocks) {
      for (mlir::Operation &op : block->without_terminator()) {
        for (mlir::Value value : op.getResults()) {
          bool crossesBlock = llvm::any_of(value.getUsers(), [&](mlir::Operation *user) {
            while (user && user->getParentRegion() != &region)
              user = user->getParentOp();
            return user && user->getBlock() != block;
          });
          if (crossesBlock) {
            valueSlots.try_emplace(value, slotTypes.size());
            slotTypes.push_back(value.getType());
          }
        }
      }
    }
    llvm::SmallVector<mlir::Type> envelopeStateTypes{
        mlir::IndexType::get(execute.getContext()),
        mlir::IntegerType::get(execute.getContext(), 1)};
    llvm::append_range(envelopeStateTypes, slotTypes);
    llvm::append_range(envelopeStateTypes, execute.getResultTypes());
    auto shapeEnvelopes = readSavedSlotShapeEnvelopes(
        execute, mlir::TypeRange(envelopeStateTypes), retainsState);
    if (mlir::failed(shapeEnvelopes)) {
      execute.emitError()
          << "saved native CFG dynamic state requires total, positive per-slot "
             "shape-envelope indices/ranks/bounds matching the state ABI";
      return mlir::failure();
    }

    auto validateEdge = [&](mlir::Block *target,
                            mlir::ValueRange values) -> mlir::LogicalResult {
      if (!blockOrdinals.contains(target) ||
          target->getNumArguments() != values.size())
        return mlir::failure();
      for (auto [argument, value] :
           llvm::zip_equal(target->getArguments(), values))
        if (argument.getType() != value.getType())
          return mlir::failure();
      return mlir::success();
    };
    for (mlir::Block *block : blocks) {
      if (auto branch =
              mlir::dyn_cast<mlir::cf::BranchOp>(block->getTerminator())) {
        if (mlir::failed(
                validateEdge(branch.getDest(), branch.getDestOperands()))) {
          execute.emitError() << "native CFG has an invalid cf.br edge ABI";
          return mlir::failure();
        }
      } else if (auto branch = mlir::dyn_cast<mlir::cf::CondBranchOp>(
                     block->getTerminator())) {
        if (mlir::failed(validateEdge(branch.getTrueDest(),
                                      branch.getTrueDestOperands())) ||
            mlir::failed(validateEdge(branch.getFalseDest(),
                                      branch.getFalseDestOperands()))) {
          execute.emitError()
              << "native CFG has an invalid cf.cond_br edge ABI";
          return mlir::failure();
        }
      } else if (auto branch = mlir::dyn_cast<mlir::cf::SwitchOp>(block->getTerminator())) {
        if (mlir::failed(validateEdge(branch.getDefaultDestination(), branch.getDefaultOperands()))) {
          execute.emitError() << "native CFG has an invalid cf.switch default edge ABI";
          return mlir::failure();
        }
        for (auto [index, target] : llvm::enumerate(branch.getCaseDestinations())) {
          if (mlir::failed(validateEdge(target, branch.getCaseOperands(index)))) {
            execute.emitError() << "native CFG has an invalid cf.switch case edge ABI";
            return mlir::failure();
          }
        }
      }
    }

    mlir::OpBuilder builder(execute);
    mlir::Location loc = execute.getLoc();
    mlir::Value zero =
        mlir::arith::ConstantIndexOp::create(builder, loc, 0);
    mlir::Value one =
        mlir::arith::ConstantIndexOp::create(builder, loc, 1);
    mlir::Value upper = mlir::arith::ConstantIndexOp::create(
        builder, loc, maxSteps.getInt());
    mlir::Value initialDone = mlir::arith::ConstantIntOp::create(
        builder, loc, 0, 1);
    llvm::SmallVector<mlir::Value> initialState{zero, initialDone};
    for (mlir::Type type : slotTypes) {
      auto sentinel = buildCFGStateSentinel(builder, loc, type);
      if (mlir::failed(sentinel)) {
        execute.emitError()
            << "native CFG block state requires scalar or ranked-tensor "
               "integer/float types";
        return mlir::failure();
      }
      initialState.push_back(*sentinel);
    }
    for (mlir::Type type : execute.getResultTypes()) {
      auto sentinel = buildCFGStateSentinel(builder, loc, type);
      if (mlir::failed(sentinel)) {
        execute.emitError()
            << "native CFG results require scalar or ranked-tensor "
               "integer/float types";
        return mlir::failure();
      }
      initialState.push_back(*sentinel);
    }
    llvm::SmallVector<mlir::Type> stateTypes;
    for (mlir::Value value : initialState)
      stateTypes.push_back(value.getType());
    const unsigned slotBase = 2;
    const unsigned resultBase = slotBase + slotTypes.size();

    auto stateMachine = mlir::scf::ForOp::create(
        builder, loc, zero, upper, one, initialState);
    for (mlir::NamedAttribute attr : execute->getAttrs())
      if (attr.getName().getValue().starts_with("tessera."))
        stateMachine->setAttr(attr.getName(), attr.getValue());
    stateMachine->setAttr("tessera.autodiff.native_multiblock_structurized",
                          builder.getBoolAttr(true));
    stateMachine->setAttr("tessera.structured_cfg.execution",
                          builder.getStringAttr("bounded_state_machine_v1"));

    using StateBuilder = std::function<mlir::FailureOr<
        llvm::SmallVector<mlir::Value>>(mlir::Block *, mlir::ValueRange)>;
    StateBuilder executeBlock;
    executeBlock = [&](mlir::Block *block, mlir::ValueRange state)
        -> mlir::FailureOr<llvm::SmallVector<mlir::Value>> {
      mlir::IRMapping mapping;
      for (auto [argument, slot] : argumentSlots)
        mapping.map(argument, state[slotBase + slot]);
      for (auto [value, slot] : valueSlots)
        if (value.getDefiningOp()->getBlock() != block)
          mapping.map(value, state[slotBase + slot]);
      for (mlir::Operation &nested : block->without_terminator())
        builder.clone(nested, mapping);
      llvm::SmallVector<mlir::Value> updatedState(state.begin(), state.end());
      for (auto [value, slot] : valueSlots)
        if (value.getDefiningOp()->getBlock() == block)
          updatedState[slotBase + slot] = mapping.lookup(value);

      auto edgeState = [&](mlir::Block *target,
                           mlir::ValueRange operands) {
        llvm::SmallVector<mlir::Value> next(updatedState.begin(), updatedState.end());
        next[0] = mlir::arith::ConstantIndexOp::create(
            builder, loc, blockOrdinals.lookup(target));
        next[1] = mlir::arith::ConstantIntOp::create(
            builder, loc, 0, 1);
        for (auto [argument, value] :
             llvm::zip_equal(target->getArguments(), operands))
          next[slotBase + argumentSlots.lookup(argument)] =
              mapping.lookupOrDefault(value);
        return next;
      };
      if (auto branch =
              mlir::dyn_cast<mlir::cf::BranchOp>(block->getTerminator()))
        return edgeState(branch.getDest(), branch.getDestOperands());
      if (auto branch = mlir::dyn_cast<mlir::cf::CondBranchOp>(
              block->getTerminator())) {
        auto select = mlir::scf::IfOp::create(
            builder, loc, stateTypes,
            mapping.lookupOrDefault(branch.getCondition()), true);
        {
          mlir::OpBuilder::InsertionGuard guard(builder);
          builder.setInsertionPointToStart(select.thenBlock());
          llvm::SmallVector<mlir::Value> next = edgeState(
              branch.getTrueDest(), branch.getTrueDestOperands());
          mlir::scf::YieldOp::create(builder, loc, next);
        }
        {
          mlir::OpBuilder::InsertionGuard guard(builder);
          builder.setInsertionPointToStart(select.elseBlock());
          llvm::SmallVector<mlir::Value> next = edgeState(
              branch.getFalseDest(), branch.getFalseDestOperands());
          mlir::scf::YieldOp::create(builder, loc, next);
        }
        return llvm::SmallVector<mlir::Value>(select.getResults().begin(),
                                               select.getResults().end());
      }
      if (auto branch = mlir::dyn_cast<mlir::cf::SwitchOp>(block->getTerminator())) {
        llvm::SmallVector<llvm::APInt> cases;
        if (auto values = branch.getCaseValues())
          llvm::append_range(cases, values->getValues<llvm::APInt>());
        std::function<llvm::SmallVector<mlir::Value>(unsigned)> choose;
        choose = [&](unsigned ordinal) -> llvm::SmallVector<mlir::Value> {
          if (ordinal == cases.size())
            return edgeState(branch.getDefaultDestination(), branch.getDefaultOperands());
          auto value = mlir::arith::ConstantOp::create(builder, loc,
              builder.getIntegerAttr(branch.getFlag().getType(), cases[ordinal]));
          auto matches = mlir::arith::CmpIOp::create(builder, loc,
              mlir::arith::CmpIPredicate::eq, mapping.lookupOrDefault(branch.getFlag()), value);
          auto select = mlir::scf::IfOp::create(builder, loc, stateTypes, matches, true);
          {
            mlir::OpBuilder::InsertionGuard guard(builder);
            builder.setInsertionPointToStart(select.thenBlock());
            auto next = edgeState(branch.getCaseDestinations()[ordinal], branch.getCaseOperands(ordinal));
            mlir::scf::YieldOp::create(builder, loc, next);
          }
          {
            mlir::OpBuilder::InsertionGuard guard(builder);
            builder.setInsertionPointToStart(select.elseBlock());
            auto next = choose(ordinal + 1);
            mlir::scf::YieldOp::create(builder, loc, next);
          }
          return llvm::SmallVector<mlir::Value>(select.getResults().begin(), select.getResults().end());
        };
        return choose(0);
      }
      auto yield =
          mlir::cast<mlir::scf::YieldOp>(block->getTerminator());
      llvm::SmallVector<mlir::Value> next(updatedState.begin(), updatedState.end());
      next[1] = mlir::arith::ConstantIntOp::create(
          builder, loc, 1, 1);
      for (auto [ordinal, value] : llvm::enumerate(yield.getOperands()))
        next[resultBase + ordinal] = mapping.lookupOrDefault(value);
      return next;
    };

    {
      mlir::OpBuilder::InsertionGuard loopGuard(builder);
      builder.setInsertionPointToStart(stateMachine.getBody());
      mlir::Value notDone = mlir::arith::CmpIOp::create(
          builder, loc, mlir::arith::CmpIPredicate::eq,
          stateMachine.getRegionIterArg(1), initialDone);
      auto active = mlir::scf::IfOp::create(
          builder, loc, stateTypes, notDone, true);
      {
        mlir::OpBuilder::InsertionGuard activeGuard(builder);
        builder.setInsertionPointToStart(active.thenBlock());
        mlir::ValueRange state = stateMachine.getRegionIterArgs();
        std::function<mlir::FailureOr<llvm::SmallVector<mlir::Value>>(
            unsigned)> dispatch;
        dispatch = [&](unsigned ordinal)
            -> mlir::FailureOr<llvm::SmallVector<mlir::Value>> {
          mlir::Value ordinalValue = mlir::arith::ConstantIndexOp::create(
              builder, loc, ordinal);
          mlir::Value selected = mlir::arith::CmpIOp::create(
              builder, loc, mlir::arith::CmpIPredicate::eq, state.front(),
              ordinalValue);
          auto select = mlir::scf::IfOp::create(builder, loc, stateTypes,
                                                selected, true);
          {
            mlir::OpBuilder::InsertionGuard selectGuard(builder);
            builder.setInsertionPointToStart(select.thenBlock());
            auto next = executeBlock(blocks[ordinal], state);
            if (mlir::failed(next))
              return mlir::failure();
            mlir::scf::YieldOp::create(builder, loc, *next);
          }
          {
            mlir::OpBuilder::InsertionGuard selectGuard(builder);
            builder.setInsertionPointToStart(select.elseBlock());
            llvm::SmallVector<mlir::Value> next;
            if (ordinal + 1 < blocks.size()) {
              auto nested = dispatch(ordinal + 1);
              if (mlir::failed(nested))
                return mlir::failure();
              next = std::move(*nested);
            } else {
              next.assign(state.begin(), state.end());
            }
            mlir::scf::YieldOp::create(builder, loc, next);
          }
          return llvm::SmallVector<mlir::Value>(select.getResults().begin(),
                                                 select.getResults().end());
        };
        auto dispatched = dispatch(0);
        if (mlir::failed(dispatched)) {
          stateMachine.erase();
          return mlir::failure();
        }
        mlir::scf::YieldOp::create(builder, loc, *dispatched);
      }
      {
        mlir::OpBuilder::InsertionGuard activeGuard(builder);
        builder.setInsertionPointToStart(active.elseBlock());
        mlir::scf::YieldOp::create(builder, loc,
                                   stateMachine.getRegionIterArgs());
      }
      llvm::SmallVector<mlir::Value> activeResults(active.getResults().begin(),
                                                    active.getResults().end());
      closeBodyWithYield(builder, loc, stateMachine.getBody(), activeResults);
    }

    builder.setInsertionPointAfter(stateMachine);
    mlir::cf::AssertOp::create(
        builder, loc, stateMachine.getResult(1),
        builder.getStringAttr("bounded native CFG exhausted max_steps"));
    llvm::SmallVector<mlir::Value> results;
    for (unsigned ordinal = 0; ordinal < execute.getNumResults(); ++ordinal)
      results.push_back(stateMachine.getResult(resultBase + ordinal));
    execute->replaceAllUsesWith(results);
    execute.erase();
  }
  return mlir::success();
}

// A selected SAVE/HYBRID scf.if exposes every differentiable branch-local SSA
// value as a typed result.  The untaken branch yields inert zero placeholders;
// the predicate residual guarantees its placeholders are never consumed by the
// pullback. Dynamic residuals use initialized zero-extent sentinels in the
// untaken branch; their runtime shape is deliberately not fabricated from an
// unrelated branch value.
static mlir::LogicalResult materializeIfResiduals(
    mlir::func::FuncOp function) {
  llvm::SmallVector<mlir::scf::IfOp> branches;
  function.getBody().walk([&](mlir::scf::IfOp ifOp) {
    auto policy = ifOp->getAttrOfType<mlir::StringAttr>(
        "tessera.autodiff.checkpoint_policy");
    if (policy && (policy.getValue() == "save" ||
                   policy.getValue() == "hybrid") &&
        !ifOp->hasAttr("tessera.autodiff.residual_materialized"))
      branches.push_back(ifOp);
  });
  for (mlir::scf::IfOp ifOp : branches) {
    if (ifOp.getElseRegion().empty() || !ifOp.getThenRegion().hasOneBlock() ||
        !ifOp.getElseRegion().hasOneBlock()) {
      ifOp.emitError() << "saved scf.if requires single-block then/else regions";
      return mlir::failure();
    }
    llvm::SmallVector<mlir::Value> thenValues =
        collectBranchResidualCandidates(ifOp.getThenRegion());
    llvm::SmallVector<mlir::Value> elseValues =
        collectBranchResidualCandidates(ifOp.getElseRegion());
    if (thenValues.empty() && elseValues.empty()) {
      ifOp.emitError() << "saved scf.if has no differentiable branch-local SSA";
      return mlir::failure();
    }
    llvm::SmallVector<mlir::Type> resultTypes(ifOp.getResultTypes().begin(),
                                              ifOp.getResultTypes().end());
    for (mlir::Value value : thenValues)
      resultTypes.push_back(value.getType());
    for (mlir::Value value : elseValues)
      resultTypes.push_back(value.getType());

    mlir::OpBuilder builder(ifOp);
    auto replacement = mlir::scf::IfOp::create(
        builder, ifOp.getLoc(), resultTypes, ifOp.getCondition(), true);
    replacement->setAttrs(ifOp->getAttrs());
    auto cloneBranch = [&](mlir::Region &source, mlir::Block *destination,
                           llvm::ArrayRef<mlir::Value> activeValues,
                           llvm::ArrayRef<mlir::Value> inactiveValues,
                           bool activeIsThen) -> mlir::LogicalResult {
      mlir::OpBuilder::InsertionGuard guard(builder);
      builder.setInsertionPointToStart(destination);
      mlir::IRMapping mapping;
      for (mlir::Operation &nested : source.front().without_terminator())
        builder.clone(nested, mapping);
      auto oldYield = mlir::cast<mlir::scf::YieldOp>(
          source.front().getTerminator());
      llvm::SmallVector<mlir::Value> yields;
      for (mlir::Value value : oldYield.getOperands())
        yields.push_back(mapping.lookupOrDefault(value));
      auto appendActive = [&]() {
        for (mlir::Value value : activeValues)
          yields.push_back(mapping.lookupOrDefault(value));
      };
      auto appendInactive = [&]() -> mlir::LogicalResult {
        for (mlir::Value value : inactiveValues) {
          auto zero =
              buildInactiveResidualZero(builder, ifOp.getLoc(), value.getType());
          if (mlir::failed(zero)) {
            ifOp.emitError()
                << "saved scf.if requires ranked-tensor or scalar branch "
                   "residuals";
            return mlir::failure();
          }
          yields.push_back(*zero);
        }
        return mlir::success();
      };
      if (activeIsThen) {
        appendActive();
        if (mlir::failed(appendInactive()))
          return mlir::failure();
      } else {
        if (mlir::failed(appendInactive()))
          return mlir::failure();
        appendActive();
      }
      mlir::scf::YieldOp::create(builder, ifOp.getLoc(), yields);
      return mlir::success();
    };
    if (mlir::failed(cloneBranch(ifOp.getThenRegion(), replacement.thenBlock(),
                                 thenValues, elseValues, true)) ||
        mlir::failed(cloneBranch(ifOp.getElseRegion(), replacement.elseBlock(),
                                 elseValues, thenValues, false))) {
      replacement.erase();
      return mlir::failure();
    }
    unsigned primalCount = ifOp.getNumResults();
    for (auto [oldResult, newResult] : llvm::zip_equal(
             ifOp.getResults(), replacement.getResults().take_front(primalCount)))
      oldResult.replaceAllUsesWith(newResult);
    llvm::SmallVector<int64_t> residualIndices;
    for (unsigned index = primalCount; index < replacement.getNumResults();
         ++index)
      residualIndices.push_back(index);
    replacement->setAttr("tessera.autodiff.residual_materialized",
                         builder.getBoolAttr(true));
    replacement->setAttr("tessera.autodiff.residual_owner",
                         builder.getStringAttr("scf_if"));
    replacement->setAttr("tessera.autodiff.residual_result_indices",
                         builder.getDenseI64ArrayAttr(residualIndices));
    replacement->setAttr("tessera.autodiff.then_saved_count",
                         builder.getI64IntegerAttr(thenValues.size()));
    replacement->setAttr("tessera.autodiff.else_saved_count",
                         builder.getI64IntegerAttr(elseValues.size()));
    ifOp.erase();
  }
  return mlir::success();
}

// SAVE for the canonical bounded scf.while records every differentiable
// predecessor state at its executed ordinal. HYBRID records only the declared
// interior states; reverse mode selects the nearest predecessor and performs a
// bounded replay. Neither policy silently falls back to whole-prefix replay.
static mlir::LogicalResult materializeWhileResiduals(
    mlir::func::FuncOp function) {
  llvm::SmallVector<mlir::scf::WhileOp> loops;
  function.getBody().walk([&](mlir::scf::WhileOp whileOp) {
    auto policy = whileOp->getAttrOfType<mlir::StringAttr>(
        "tessera.autodiff.checkpoint_policy");
    if (policy && (policy.getValue() == "save" ||
                   policy.getValue() == "hybrid") &&
        !whileOp->hasAttr("tessera.autodiff.residual_materialized"))
      loops.push_back(whileOp);
  });
  for (mlir::scf::WhileOp whileOp : loops) {
    auto policy = whileOp->getAttrOfType<mlir::StringAttr>(
        "tessera.autodiff.checkpoint_policy");
    const bool hybrid = policy.getValue() == "hybrid";
    auto maxIters = whileOp->getAttrOfType<mlir::IntegerAttr>(
        "tessera.autodiff.max_iters");
    if (!maxIters || maxIters.getInt() <= 0 ||
        !whileOp.getBefore().hasOneBlock() ||
        !whileOp.getAfter().hasOneBlock() || whileOp.getInits().empty() ||
        !llvm::isa<mlir::IndexType>(whileOp.getInits().front().getType())) {
      whileOp.emitError()
          << "saved scf.while requires max_iters and canonical counted state";
      return mlir::failure();
    }
    auto oldCondition = mlir::dyn_cast<mlir::scf::ConditionOp>(
        whileOp.getBefore().front().getTerminator());
    auto oldYield = mlir::dyn_cast<mlir::scf::YieldOp>(
        whileOp.getAfter().front().getTerminator());
    const int64_t primalBodyOpCount = static_cast<int64_t>(
        std::distance(whileOp.getAfter().front().begin(),
                      whileOp.getAfter().front().getTerminator()->getIterator()));
    if (!oldCondition || !oldYield ||
        oldCondition.getArgs().size() != whileOp.getInits().size() ||
        oldYield.getNumOperands() != whileOp.getInits().size()) {
      whileOp.emitError() << "saved scf.while has non-canonical region ABI";
      return mlir::failure();
    }

    auto checkpoints = whileOp->getAttrOfType<mlir::DenseI64ArrayAttr>(
        "tessera.autodiff.checkpoint_indices");
    llvm::ArrayRef<int64_t> checkpointIndices;
    if (hybrid) {
      if (!checkpoints || checkpoints.empty()) {
        whileOp.emitError()
            << "HYBRID scf.while requires explicit checkpoint_indices";
        return mlir::failure();
      }
      checkpointIndices = checkpoints.asArrayRef();
      if (!llvm::is_sorted(checkpointIndices) ||
          std::adjacent_find(checkpointIndices.begin(),
                             checkpointIndices.end()) !=
              checkpointIndices.end() ||
          llvm::any_of(checkpointIndices, [&](int64_t checkpoint) {
            return checkpoint <= 0 || checkpoint >= maxIters.getInt();
          })) {
        whileOp.emitError()
            << "HYBRID scf.while checkpoints must be sorted, unique, and "
               "inside (0, max_iters)";
        return mlir::failure();
      }
    }
    const int64_t tapeSlots =
        hybrid ? static_cast<int64_t>(checkpointIndices.size())
               : maxIters.getInt();

    llvm::SmallVector<unsigned> stateIndices;
    llvm::SmallVector<mlir::RankedTensorType> tapeTypes;
    llvm::SmallVector<mlir::Value> tapeInits;
    mlir::OpBuilder builder(whileOp);
    // The tape's dynamic extents come from the loop INIT, while insertState
    // slices with the current iteration's extent — scf.while lets a
    // `tensor<?xf32>` state yield any extent, so a growing state writes an
    // out-of-bounds slice. The generic_for path demands a declared shape
    // envelope for exactly this reason; until while carries one, refuse rather
    // than emit the unguarded insert (Decision #21a). Decided before any IR is
    // built so a refusal leaves no partial tape behind.
    for (mlir::Value init : whileOp.getInits()) {
      if (!llvm::isa<mlir::FloatType>(
              mlir::getElementTypeOrSelf(init.getType())))
        continue;
      auto shaped = llvm::dyn_cast<mlir::ShapedType>(init.getType());
      if (shaped && !shaped.hasStaticShape()) {
        whileOp.emitError()
            << "AUTODIFF_WHILE_DYNAMIC_STATE: saved scf.while state "
            << init.getType()
            << " has a dynamic extent; the residual tape is sized from the "
               "loop init and cannot bound an extent that varies across "
               "iterations";
        return mlir::failure();
      }
    }
    for (auto [index, init] : llvm::enumerate(whileOp.getInits())) {
      if (!llvm::isa<mlir::FloatType>(
              mlir::getElementTypeOrSelf(init.getType())))
        continue;
      auto tapeType = getResidualTapeType(init.getType(), tapeSlots);
      if (mlir::failed(tapeType)) {
        whileOp.emitError()
            << "saved scf.while requires ranked-tensor differentiable state";
        return mlir::failure();
      }
      auto stateType = mlir::cast<mlir::RankedTensorType>(init.getType());
      stateIndices.push_back(index);
      tapeTypes.push_back(*tapeType);
      tapeInits.push_back(mlir::tensor::EmptyOp::create(
          builder, whileOp.getLoc(), tapeType->getShape(),
          tapeType->getElementType(),
          getDynamicTensorSizes(builder, whileOp.getLoc(), init, stateType)));
    }
    if (stateIndices.empty() ||
        stateIndices.size() + 1 != whileOp.getInits().size()) {
      whileOp.emitError()
          << "saved scf.while requires every non-counter state to be a "
             "differentiable ranked tensor";
      return mlir::failure();
    }

    llvm::SmallVector<mlir::Value> inits(whileOp.getInits().begin(),
                                         whileOp.getInits().end());
    llvm::append_range(inits, tapeInits);
    llvm::SmallVector<mlir::Type> stateTypes;
    for (mlir::Value init : inits)
      stateTypes.push_back(init.getType());
    auto replacement = mlir::scf::WhileOp::create(
        builder, whileOp.getLoc(), stateTypes, inits);
    replacement->setAttrs(whileOp->getAttrs());

    llvm::SmallVector<mlir::Location> locations(stateTypes.size(),
                                                whileOp.getLoc());
    {
      mlir::OpBuilder::InsertionGuard guard(builder);
      mlir::Block *before = builder.createBlock(&replacement.getBefore());
      before->addArguments(stateTypes, locations);
      builder.setInsertionPointToStart(before);
      mlir::IRMapping mapping;
      for (auto [source, destination] : llvm::zip_equal(
               whileOp.getBefore().front().getArguments(),
               before->getArguments().take_front(whileOp.getInits().size())))
        mapping.map(source, destination);
      for (mlir::Operation &nested :
           whileOp.getBefore().front().without_terminator())
        builder.clone(nested, mapping);
      llvm::SmallVector<mlir::Value> forwarded;
      for (mlir::Value value : oldCondition.getArgs())
        forwarded.push_back(mapping.lookupOrDefault(value));
      llvm::append_range(
          forwarded,
          before->getArguments().drop_front(whileOp.getInits().size()));
      mlir::scf::ConditionOp::create(
          builder, whileOp.getLoc(),
          mapping.lookupOrDefault(oldCondition.getCondition()), forwarded);
    }
    {
      mlir::OpBuilder::InsertionGuard guard(builder);
      mlir::Block *after = builder.createBlock(&replacement.getAfter());
      after->addArguments(stateTypes, locations);
      builder.setInsertionPointToStart(after);
      mlir::IRMapping mapping;
      for (auto [source, destination] : llvm::zip_equal(
               whileOp.getAfter().front().getArguments(),
               after->getArguments().take_front(whileOp.getInits().size())))
        mapping.map(source, destination);
      for (mlir::Operation &nested :
           whileOp.getAfter().front().without_terminator())
        builder.clone(nested, mapping);
      llvm::SmallVector<mlir::Value> yields;
      for (mlir::Value value : oldYield.getOperands())
        yields.push_back(mapping.lookupOrDefault(value));
      mlir::Value ordinal = after->getArgument(0);
      for (auto [tapeOrdinal, stateIndex] : llvm::enumerate(stateIndices)) {
        mlir::Value predecessor = after->getArgument(stateIndex);
        mlir::Value successor = yields[stateIndex];
        mlir::Value tape = after->getArgument(whileOp.getInits().size() +
                                              tapeOrdinal);
        auto stateType =
            mlir::cast<mlir::RankedTensorType>(predecessor.getType());
        auto insertState = [&](mlir::Value source, mlir::Value destination,
                               mlir::OpFoldResult slot) {
          llvm::SmallVector<mlir::OpFoldResult> offsets{slot};
          llvm::SmallVector<mlir::OpFoldResult> sizes{
              builder.getIndexAttr(1)};
          llvm::SmallVector<mlir::OpFoldResult> strides(
              stateType.getRank() + 1, builder.getIndexAttr(1));
          for (auto [dimIndex, dim] : llvm::enumerate(stateType.getShape())) {
            offsets.push_back(builder.getIndexAttr(0));
            sizes.push_back(mlir::ShapedType::isDynamic(dim)
                                ? mlir::OpFoldResult(
                                      mlir::tensor::DimOp::create(
                                          builder, whileOp.getLoc(), source,
                                          dimIndex)
                                          .getResult())
                                : mlir::OpFoldResult(
                                      builder.getIndexAttr(dim)));
          }
          return mlir::tensor::InsertSliceOp::create(
              builder, whileOp.getLoc(), source, destination, offsets, sizes,
              strides);
        };
        if (!hybrid) {
          yields.push_back(insertState(predecessor, tape, ordinal));
          continue;
        }
        mlir::Value nextOrdinal = yields.front();
        for (auto [slot, checkpoint] :
             llvm::enumerate(checkpointIndices)) {
          mlir::Value checkpointValue = mlir::arith::ConstantIndexOp::create(
              builder, whileOp.getLoc(), checkpoint);
          mlir::Value retain = mlir::arith::CmpIOp::create(
              builder, whileOp.getLoc(), mlir::arith::CmpIPredicate::eq,
              nextOrdinal, checkpointValue);
          auto retainIf = mlir::scf::IfOp::create(
              builder, whileOp.getLoc(), mlir::TypeRange{tape.getType()},
              retain, true);
          {
            mlir::OpBuilder::InsertionGuard retainGuard(builder);
            builder.setInsertionPointToStart(retainIf.thenBlock());
            mlir::Value retained = insertState(
                successor, tape,
                builder.getIndexAttr(static_cast<int64_t>(slot)));
            mlir::scf::YieldOp::create(builder, whileOp.getLoc(), retained);
          }
          {
            mlir::OpBuilder::InsertionGuard retainGuard(builder);
            builder.setInsertionPointToStart(retainIf.elseBlock());
            mlir::scf::YieldOp::create(builder, whileOp.getLoc(), tape);
          }
          tape = retainIf.getResult(0);
        }
        yields.push_back(tape);
      }
      mlir::scf::YieldOp::create(builder, whileOp.getLoc(), yields);
    }

    unsigned primalCount = whileOp.getNumResults();
    for (auto [oldResult, newResult] : llvm::zip_equal(
             whileOp.getResults(),
             replacement.getResults().take_front(primalCount)))
      oldResult.replaceAllUsesWith(newResult);
    llvm::SmallVector<int64_t> resultIndices;
    for (unsigned index = primalCount; index < replacement.getNumResults();
         ++index)
      resultIndices.push_back(index);
    llvm::SmallVector<int64_t> primalIndices(stateIndices.begin(),
                                             stateIndices.end());
    replacement->setAttr("tessera.autodiff.residual_materialized",
                         builder.getBoolAttr(true));
    replacement->setAttr("tessera.autodiff.residual_owner",
                         builder.getStringAttr("scf_while"));
    replacement->setAttr("tessera.autodiff.residual_result_indices",
                         builder.getDenseI64ArrayAttr(resultIndices));
    replacement->setAttr("tessera.autodiff.residual_primal_iter_arg_indices",
                         builder.getDenseI64ArrayAttr(primalIndices));
    replacement->setAttr("tessera.autodiff.residual_primal_op_count",
                         builder.getI64IntegerAttr(primalBodyOpCount));
    whileOp.erase();
  }
  return mlir::success();
}

// Materialize the generic counted-loop residual contract before activity
// analysis. Every replay-relevant scalar or ranked-tensor slot receives its
// own typed tape. This includes program counters, completion bits, and integer
// counters: they do not acquire analytical cotangents, but HYBRID suffix replay
// must restart from their checkpoint values rather than from final state. The
// explicit state-index map keeps mixed state lossless and makes unknown storage
// fail closed.
static void eraseStaticallyEmptyLoops(mlir::func::FuncOp function) {
  // SAVE has no residual allocation for a body that never executes. Do this
  // before tape sizing, including empty loops nested inside active regions.
  function.walk<mlir::WalkOrder::PostOrder>([](mlir::scf::ForOp loop) {
    llvm::APInt lb,ub,step;
    if (loop->hasAttr("unsignedCmp") ||
        !mlir::matchPattern(loop.getLowerBound(),mlir::m_ConstantInt(&lb)) ||
        !mlir::matchPattern(loop.getUpperBound(),mlir::m_ConstantInt(&ub)) ||
        !mlir::matchPattern(loop.getStep(),mlir::m_ConstantInt(&step)) ||
        !step.isStrictlyPositive() || lb.slt(ub)) return;
    loop->replaceAllUsesWith(loop.getInitArgs());
    loop.erase();
  });
}

static mlir::LogicalResult materializeGenericForResiduals(
    mlir::func::FuncOp function) {
  llvm::SmallVector<mlir::scf::ForOp> loops;
  function.getBody().walk([&](mlir::scf::ForOp loop) {
    auto policy = loop->getAttrOfType<mlir::StringAttr>(
        "tessera.autodiff.checkpoint_policy");
    if (policy && (policy.getValue() == "save" ||
                   policy.getValue() == "hybrid") &&
        !loop->hasAttr("tessera.autodiff.residual_materialized"))
      loops.push_back(loop);
  });
  for (mlir::scf::ForOp loop : loops) {
    llvm::APInt lbValue, ubValue, stepValue;
    if (!mlir::matchPattern(loop.getLowerBound(),
                            mlir::m_ConstantInt(&lbValue)) ||
        !mlir::matchPattern(loop.getUpperBound(),
                            mlir::m_ConstantInt(&ubValue)) ||
        !mlir::matchPattern(loop.getStep(),
                            mlir::m_ConstantInt(&stepValue)) ||
        !stepValue.isStrictlyPositive() ||
        ubValue.getSExtValue() <= lbValue.getSExtValue()) {
      loop.emitError() << "generic saved scf.for requires positive static "
                          "bounds and step";
      return mlir::failure();
    }
    int64_t span = ubValue.getSExtValue() - lbValue.getSExtValue();
    int64_t step = stepValue.getSExtValue();
    int64_t trip = (span + step - 1) / step;
    auto checkpoints = loop->getAttrOfType<mlir::DenseI64ArrayAttr>(
        "tessera.autodiff.checkpoint_indices");
    if (!checkpoints || checkpoints.empty()) {
      loop.emitError() << "generic saved scf.for requires checkpoint_indices";
      return mlir::failure();
    }
    llvm::ArrayRef<int64_t> indices = checkpoints.asArrayRef();
    if (!llvm::is_sorted(indices) ||
        std::adjacent_find(indices.begin(), indices.end()) != indices.end() ||
        llvm::any_of(indices,
                     [trip](int64_t index) { return index <= 0 || index >= trip; })) {
      loop.emitError() << "generic scf.for checkpoints must be sorted, unique, "
                          "interior ordinals";
      return mlir::failure();
    }
    auto policy = loop->getAttrOfType<mlir::StringAttr>(
        "tessera.autodiff.checkpoint_policy");
    if ((policy.getValue() == "save" &&
         indices.size() != static_cast<size_t>(trip - 1)) ||
        (policy.getValue() == "hybrid" &&
         indices.size() >= static_cast<size_t>(trip - 1))) {
      loop.emitError() << "generic scf.for checkpoint cardinality disagrees "
                          "with its policy";
      return mlir::failure();
    }

    llvm::SmallVector<unsigned> tapedStateIndices;
    llvm::SmallVector<mlir::RankedTensorType> tapeTypes;
    llvm::SmallVector<mlir::Value> tapeInits;
    llvm::SmallVector<int64_t> shapeTapeOrdinals;
    llvm::SmallVector<mlir::RankedTensorType> shapeTapeTypes;
    llvm::SmallVector<mlir::Value> shapeTapeInits;
    mlir::OpBuilder builder(loop);
    llvm::SmallVector<mlir::Type> primalStateTypes;
    for (mlir::Value init : loop.getInitArgs())
      primalStateTypes.push_back(init.getType());
    auto shapeEnvelopes = readSavedSlotShapeEnvelopes(
        loop, mlir::TypeRange(primalStateTypes), /*requireEveryDynamic=*/true);
    if (mlir::failed(shapeEnvelopes)) {
      loop.emitError()
          << "generic saved scf.for dynamic state requires total, positive "
             "per-slot shape-envelope indices/ranks/bounds";
      return mlir::failure();
    }
    for (auto [stateIndex, init] : llvm::enumerate(loop.getInitArgs())) {
      auto tapeType = getResidualTapeType(init.getType(), indices.size());
      if (mlir::failed(tapeType)) {
        loop.emitError() << "generic saved scf.for cannot materialize state "
                         << stateIndex << " with type " << init.getType();
        return mlir::failure();
      }
      tapedStateIndices.push_back(stateIndex);
      auto stateType =
          mlir::dyn_cast<mlir::RankedTensorType>(init.getType());
      auto envelope = shapeEnvelopes->find(stateIndex);
      if (stateType && !stateType.hasStaticShape()) {
        if (envelope == shapeEnvelopes->end()) {
          loop.emitError() << "dynamic saved state " << stateIndex
                           << " has no shape envelope";
          return mlir::failure();
        }
        llvm::SmallVector<int64_t> boundedShape{
            static_cast<int64_t>(indices.size())};
        llvm::append_range(boundedShape, envelope->second);
        tapeType = mlir::RankedTensorType::get(
            boundedShape, stateType.getElementType(), stateType.getEncoding());
        shapeTapeOrdinals.push_back(shapeTapeTypes.size());
        shapeTapeTypes.push_back(mlir::RankedTensorType::get(
            {static_cast<int64_t>(indices.size()), stateType.getRank()},
            builder.getIndexType()));
        shapeTapeInits.push_back(mlir::tensor::EmptyOp::create(
            builder, loop.getLoc(), shapeTapeTypes.back().getShape(),
            builder.getIndexType()));
      } else {
        shapeTapeOrdinals.push_back(-1);
      }
      tapeTypes.push_back(*tapeType);
      llvm::SmallVector<mlir::Value> dynamicSizes;
      if (stateType && stateType.hasStaticShape())
        dynamicSizes =
            getDynamicTensorSizes(builder, loop.getLoc(), init, stateType);
      tapeInits.push_back(mlir::tensor::EmptyOp::create(
          builder, loop.getLoc(), tapeType->getShape(),
          tapeType->getElementType(), dynamicSizes));
    }
    llvm::SmallVector<mlir::Value> inits(loop.getInitArgs().begin(),
                                         loop.getInitArgs().end());
    llvm::append_range(inits, tapeInits);
    llvm::append_range(inits, shapeTapeInits);
    auto replacement = mlir::scf::ForOp::create(
        builder, loop.getLoc(), loop.getLowerBound(), loop.getUpperBound(),
        loop.getStep(), inits);
    replacement->setAttrs(loop->getAttrs());
    mlir::Block &oldBody = loop.getRegion().front();
    mlir::Block &newBody = replacement.getRegion().front();
    mlir::IRMapping mapping;
    mapping.map(loop.getInductionVar(), replacement.getInductionVar());
    for (auto [source, destination] : llvm::zip_equal(
             loop.getRegionIterArgs().take_front(loop.getNumResults()),
             replacement.getRegionIterArgs().take_front(loop.getNumResults())))
      mapping.map(source, destination);
    builder.setInsertionPointToStart(&newBody);
    for (mlir::Operation &source : oldBody.without_terminator())
      builder.clone(source, mapping);
    auto oldYield = mlir::cast<mlir::scf::YieldOp>(oldBody.getTerminator());
    llvm::SmallVector<mlir::Value> yields;
    for (mlir::Value value : oldYield.getOperands())
      yields.push_back(mapping.lookupOrDefault(value));
    llvm::SmallVector<mlir::Value> shapeTapeValues;
    for (unsigned shapeOrdinal = 0; shapeOrdinal < shapeTapeTypes.size();
         ++shapeOrdinal)
      shapeTapeValues.push_back(replacement.getRegionIterArg(
          loop.getNumResults() + tapeTypes.size() + shapeOrdinal));
    for (auto [tapeOrdinal, tapeType] : llvm::enumerate(tapeTypes)) {
      unsigned stateIndex = tapedStateIndices[tapeOrdinal];
      mlir::Value tape = replacement.getRegionIterArg(
          loop.getNumResults() + tapeOrdinal);
      auto stateType = mlir::dyn_cast<mlir::RankedTensorType>(
          loop.getInitArgs()[stateIndex].getType());
      int64_t shapeOrdinal = shapeTapeOrdinals[tapeOrdinal];
      mlir::Value shapeTape =
          shapeOrdinal >= 0 ? shapeTapeValues[shapeOrdinal] : mlir::Value{};
      for (auto [slot, checkpoint] : llvm::enumerate(indices)) {
        mlir::Value retainIv = mlir::arith::ConstantIndexOp::create(
            builder, loop.getLoc(),
            lbValue.getSExtValue() + (checkpoint - 1) * step);
        mlir::Value retain = mlir::arith::CmpIOp::create(
            builder, loop.getLoc(), mlir::arith::CmpIPredicate::eq,
            replacement.getInductionVar(), retainIv);
        llvm::SmallVector<mlir::Type> retainedTypes{tapeType};
        if (shapeTape)
          retainedTypes.push_back(shapeTape.getType());
        auto retainIf = mlir::scf::IfOp::create(
            builder, loop.getLoc(), retainedTypes, retain, true);
        {
          mlir::OpBuilder::InsertionGuard guard(builder);
          builder.setInsertionPointToStart(retainIf.thenBlock());
          mlir::Value retained;
          if (stateType) {
            llvm::SmallVector<mlir::OpFoldResult> offsets{
                builder.getIndexAttr(static_cast<int64_t>(slot))};
            llvm::SmallVector<mlir::OpFoldResult> sizes{builder.getIndexAttr(1)};
            llvm::SmallVector<mlir::OpFoldResult> strides(
                stateType.getRank() + 1, builder.getIndexAttr(1));
            for (auto [dimIndex, dim] :
                 llvm::enumerate(stateType.getShape())) {
              offsets.push_back(builder.getIndexAttr(0));
              if (mlir::ShapedType::isDynamic(dim)) {
                mlir::Value actual = mlir::tensor::DimOp::create(
                    builder, loop.getLoc(), yields[stateIndex], dimIndex);
                int64_t bound =
                    shapeEnvelopes->lookup(stateIndex)[dimIndex];
                mlir::Value boundValue =
                    mlir::arith::ConstantIndexOp::create(
                        builder, loop.getLoc(), bound);
                mlir::Value withinEnvelope = mlir::arith::CmpIOp::create(
                    builder, loop.getLoc(),
                    mlir::arith::CmpIPredicate::ule, actual, boundValue);
                auto assertion = mlir::cf::AssertOp::create(
                    builder, loop.getLoc(), withinEnvelope,
                    builder.getStringAttr(
                        "saved dynamic state exceeds its slot envelope"));
                assertion->setAttr("tessera.autodiff.replay_safe_guard",
                                   builder.getBoolAttr(true));
                sizes.push_back(mlir::OpFoldResult(actual));
              } else {
                sizes.push_back(mlir::OpFoldResult(
                    builder.getIndexAttr(dim)));
              }
            }
            retained = mlir::tensor::InsertSliceOp::create(
                builder, loop.getLoc(), yields[stateIndex], tape, offsets,
                sizes, strides);
          } else {
            mlir::Value slotIndex = mlir::arith::ConstantIndexOp::create(
                builder, loop.getLoc(), static_cast<int64_t>(slot));
            retained = mlir::tensor::InsertOp::create(
                builder, loop.getLoc(), yields[stateIndex], tape, slotIndex);
          }
          llvm::SmallVector<mlir::Value> retainedValues{retained};
          if (shapeTape) {
            mlir::Value retainedShape = shapeTape;
            mlir::Value slotValue = mlir::arith::ConstantIndexOp::create(
                builder, loop.getLoc(), static_cast<int64_t>(slot));
            for (int64_t dimIndex = 0; dimIndex < stateType.getRank();
                 ++dimIndex) {
              mlir::Value dimValue = mlir::tensor::DimOp::create(
                  builder, loop.getLoc(), yields[stateIndex], dimIndex);
              mlir::Value dimOrdinal = mlir::arith::ConstantIndexOp::create(
                  builder, loop.getLoc(), dimIndex);
              retainedShape = mlir::tensor::InsertOp::create(
                  builder, loop.getLoc(), dimValue, retainedShape,
                  mlir::ValueRange{slotValue, dimOrdinal});
            }
            retainedValues.push_back(retainedShape);
          }
          mlir::scf::YieldOp::create(builder, loop.getLoc(), retainedValues);
        }
        {
          mlir::OpBuilder::InsertionGuard guard(builder);
          builder.setInsertionPointToStart(retainIf.elseBlock());
          llvm::SmallVector<mlir::Value> retainedValues{tape};
          if (shapeTape)
            retainedValues.push_back(shapeTape);
          mlir::scf::YieldOp::create(builder, loop.getLoc(), retainedValues);
        }
        tape = retainIf.getResult(0);
        if (shapeTape)
          shapeTape = retainIf.getResult(1);
      }
      yields.push_back(tape);
      if (shapeOrdinal >= 0)
        shapeTapeValues[shapeOrdinal] = shapeTape;
    }
    llvm::append_range(yields, shapeTapeValues);
    mlir::scf::YieldOp::create(builder, loop.getLoc(), yields);
    unsigned primalCount = loop.getNumResults();
    for (auto [oldResult, newResult] : llvm::zip_equal(
             loop.getResults(), replacement.getResults().take_front(primalCount)))
      oldResult.replaceAllUsesWith(newResult);
    llvm::SmallVector<int64_t> resultIndices, primalIndices;
    for (auto [tapeOrdinal, stateIndex] :
         llvm::enumerate(tapedStateIndices)) {
      resultIndices.push_back(primalCount + tapeOrdinal);
      primalIndices.push_back(stateIndex);
    }
    for (unsigned shapeOrdinal = 0; shapeOrdinal < shapeTapeTypes.size();
         ++shapeOrdinal)
      resultIndices.push_back(primalCount + tapeTypes.size() + shapeOrdinal);
    llvm::SmallVector<int64_t> shapeResidualOrdinals;
    for (int64_t shapeOrdinal : shapeTapeOrdinals)
      shapeResidualOrdinals.push_back(
          shapeOrdinal < 0
              ? -1
              : static_cast<int64_t>(tapeTypes.size()) + shapeOrdinal);
    replacement->setAttr("tessera.autodiff.residual_materialized",
                         builder.getBoolAttr(true));
    replacement->setAttr("tessera.autodiff.residual_owner",
                         builder.getStringAttr("generic_for"));
    replacement->setAttr("tessera.autodiff.residual_result_indices",
                         builder.getDenseI64ArrayAttr(resultIndices));
    replacement->setAttr("tessera.autodiff.residual_primal_iter_arg_indices",
                         builder.getDenseI64ArrayAttr(primalIndices));
    replacement->setAttr("tessera.autodiff.residual_shape_tape_ordinals",
                         builder.getDenseI64ArrayAttr(shapeResidualOrdinals));
    loop.erase();
  }
  return mlir::success();
}

/// Accumulate `g` into `cotan[v]` (float → addf, integer → addi). Shared shape
/// with AutodiffPass.cpp; kept local so the two passes stay independent.
void accumulateCotangent(mlir::OpBuilder &builder, CotangentMap &cotan,
                         mlir::Value v, mlir::Value g) {
  if (!g)
    return;
  auto it = cotan.find(v);
  if (it == cotan.end()) {
    cotan[v] = g;
    return;
  }
  auto loc = g.getLoc();
  mlir::Type elemTy = mlir::getElementTypeOrSelf(g.getType());
  mlir::Value sum =
      llvm::isa<mlir::FloatType>(elemTy)
          ? builder.create<mlir::arith::AddFOp>(loc, it->second, g).getResult()
          : builder.create<mlir::arith::AddIOp>(loc, it->second, g).getResult();
  cotan[v] = sum;
}

// A pure counted while is exactly a for loop. Normalize only the proven
// zero-origin/unit-step form for the physical tape consumer, retaining the
// selected checkpoint policy. Data-dependent termination is not approximated.
static void normalizeCountedTapeWhiles(mlir::func::FuncOp fn) {
  using namespace mlir;
  llvm::SmallVector<scf::WhileOp> loops;
  fn.walk([&](scf::WhileOp loop) { loops.push_back(loop); });
  for (auto loop : loops) {
    if (!loop.getBefore().hasOneBlock() || !loop.getAfter().hasOneBlock() ||
        loop.getInits().empty() || !loop.getInits()[0].getType().isIndex()) continue;
    auto &before=loop.getBefore().front();
    auto &after=loop.getAfter().front();
    auto condition=dyn_cast<scf::ConditionOp>(before.getTerminator());
    auto yield=dyn_cast<scf::YieldOp>(after.getTerminator());
    if (!condition || !yield || before.getOperations().size()!=2 ||
        condition.getArgs()!=before.getArguments() ||
        yield->getNumOperands()!=loop.getInits().size()) continue;
    auto cmp=condition.getCondition().getDefiningOp<arith::CmpIOp>();
    auto inc=yield->getOperand(0).getDefiningOp<arith::AddIOp>();
    if (!cmp || cmp.getPredicate()!=arith::CmpIPredicate::slt ||
        cmp.getLhs()!=before.getArgument(0) || !inc || inc.getLhs()!=after.getArgument(0)) continue;
    llvm::APInt lo,hi,step;
    if (!matchPattern(loop.getInits()[0],m_ConstantInt(&lo)) ||
        !matchPattern(cmp.getRhs(),m_ConstantInt(&hi)) ||
        !matchPattern(inc.getRhs(),m_ConstantInt(&step)) ||
        !lo.isZero() || !step.isOne() || !hi.isSignedIntN(64)) continue;
    int64_t trip=hi.getSExtValue();
    auto maximum=loop->getAttrOfType<IntegerAttr>("tessera.autodiff.max_iters");
    if (trip<2 || trip>1024 || !maximum || !maximum.getValue().isSignedIntN(64) || maximum.getInt()<trip) continue;
    // The upper bound and step must dominate the new for, not merely be
    // constants constructed inside the old while regions.
    OpBuilder builder(loop);
    auto upper=arith::ConstantIndexOp::create(builder,loop.getLoc(),trip);
    auto one=arith::ConstantIndexOp::create(builder,loop.getLoc(),1);
    auto replacement=scf::ForOp::create(builder,loop.getLoc(),loop.getInits()[0],upper,one,
                                        loop.getInits().drop_front());
    replacement->setAttrs(loop->getAttrs());
    auto policy=loop->getAttrOfType<StringAttr>("tessera.autodiff.checkpoint_policy");
    if (policy && policy.getValue()=="save") {
      llvm::SmallVector<int64_t> checkpoints;
      for (int64_t i=1;i<trip;++i) checkpoints.push_back(i);
      replacement->setAttr("tessera.autodiff.checkpoint_indices",builder.getDenseI64ArrayAttr(checkpoints));
    }
    IRMapping mapping;
    mapping.map(after.getArgument(0),replacement.getInductionVar());
    for (auto [oldArg,newArg] : llvm::zip(after.getArguments().drop_front(),replacement.getRegionIterArgs()))
      mapping.map(oldArg,newArg);
    builder.setInsertionPointToStart(replacement.getBody());
    for (auto &op : after.without_terminator()) builder.clone(op,mapping);
    llvm::SmallVector<Value> results;
    for (auto value : yield.getOperands().drop_front()) results.push_back(mapping.lookupOrDefault(value));
    // For loops with iter_args have no implicit terminator in this builder.
    if (auto *term=replacement.getBody()->empty() ? nullptr : &replacement.getBody()->back();
        term && isa<scf::YieldOp>(term)) term->erase();
    builder.setInsertionPointToEnd(replacement.getBody());
    scf::YieldOp::create(builder,loop.getLoc(),results);
    loop.getResult(0).replaceAllUsesWith(upper);
    for (auto [oldResult,newResult] : llvm::zip(loop.getResults().drop_front(),replacement.getResults()))
      oldResult.replaceAllUsesWith(newResult);
    loop.erase();
  }
}

// Preserve a genuinely data-dependent exit by freezing the complete carried
// state once the condition is false. A syntactic i<cap conjunct and a unit
// increment prove termination; max_iters alone is never such a proof.
static void normalizeDataDependentTapeWhiles(mlir::func::FuncOp fn) {
  using namespace mlir;
  fn.walk<WalkOrder::PostOrder>([&](scf::WhileOp loop) {
    if (!loop.getBefore().hasOneBlock() || !loop.getAfter().hasOneBlock() ||
        loop.getInits().empty() || !loop.getInits()[0].getType().isIndex()) return;
    auto &before=loop.getBefore().front(); auto &after=loop.getAfter().front();
    auto condition=dyn_cast<scf::ConditionOp>(before.getTerminator());
    auto yield=dyn_cast<scf::YieldOp>(after.getTerminator());
    if (!condition || !yield || condition.getArgs()!=before.getArguments() ||
        yield->getNumOperands()!=loop.getInits().size()) return;
    for (auto &op:before.without_terminator()) if (!isReplayableCFGBodyOperation(op)) return;
    auto inc=yield->getOperand(0).getDefiningOp<arith::AddIOp>();
    APInt initial,step;
    if (!inc || inc.getLhs()!=after.getArgument(0) ||
        !matchPattern(loop.getInits()[0],m_ConstantInt(&initial)) || !initial.isSignedIntN(64) ||
        !matchPattern(inc.getRhs(),m_ConstantInt(&step)) || !step.isSignedIntN(64)) return;
    // Prove a finite iteration capacity from constants rather than requiring
    // the source counter to be the synthetic zero-origin unit-step tape index.
    int64_t start=initial.getSExtValue(), stride=step.getSExtValue();
    if (start<0 || start>1024 || stride<=0 || stride>1024) return;
    std::function<std::optional<int64_t>(Value)> cap=[&](Value v)->std::optional<int64_t> {
      if (auto andOp=v.getDefiningOp<arith::AndIOp>()) {
        auto lhs=cap(andOp.getLhs()); return lhs ? lhs : cap(andOp.getRhs());
      }
      // The frontend short-circuits its bounded condition through scf.if.
      // A false else arm proves that a true result implies the guard. Do
      // not accept an arbitrary else value or infer a bound from metadata.
      if (auto branch=v.getDefiningOp<scf::IfOp>()) {
        if (branch.getNumResults()!=1 || !branch.getElseRegion().hasOneBlock()) return std::nullopt;
        auto yield=dyn_cast<scf::YieldOp>(branch.getElseRegion().front().getTerminator());
        APInt fallback;
        if (!yield || yield->getNumOperands()!=1 ||
            !matchPattern(yield->getOperand(0),m_ConstantInt(&fallback)) || !fallback.isZero()) return std::nullopt;
        return cap(branch.getCondition());
      }
      if (auto select=v.getDefiningOp<arith::SelectOp>()) {
        APInt fallback;
        if (!matchPattern(select.getFalseValue(),m_ConstantInt(&fallback)) || !fallback.isZero()) return std::nullopt;
        return cap(select.getCondition());
      }
      auto cmp=v.getDefiningOp<arith::CmpIOp>(); APInt bound;
      if (!cmp || (cmp.getPredicate()!=arith::CmpIPredicate::slt &&
                   cmp.getPredicate()!=arith::CmpIPredicate::sle) ||
          cmp.getLhs()!=before.getArgument(0) ||
          !matchPattern(cmp.getRhs(),m_ConstantInt(&bound)) || !bound.isSignedIntN(64)) return std::nullopt;
      int64_t end=bound.getSExtValue();
      if (end<0 || end>1024) return std::nullopt;
      if (cmp.getPredicate()==arith::CmpIPredicate::sle) ++end;
      int64_t n=end<=start ? 0 : (end-start+stride-1)/stride;
      return n>=2 && n<=1024 ? std::optional<int64_t>(n) : std::nullopt;
    };
    auto count=cap(condition.getCondition());
    if (!count) return;
    auto maximum=loop->getAttrOfType<IntegerAttr>("tessera.autodiff.max_iters");
    if (!maximum || !maximum.getValue().isSignedIntN(64) || maximum.getInt()<*count) return;
    OpBuilder b(loop); auto loc=loop.getLoc();
    auto zero=arith::ConstantIndexOp::create(b,loc,0);
    auto one=arith::ConstantIndexOp::create(b,loc,1);
    auto upper=arith::ConstantIndexOp::create(b,loc,*count);
    auto replacement=scf::ForOp::create(b,loc,zero,upper,one,loop.getInits());
    replacement->setAttrs(loop->getAttrs());
    auto policy=loop->getAttrOfType<StringAttr>("tessera.autodiff.checkpoint_policy");
    if (policy && policy.getValue()=="save") {
      SmallVector<int64_t> checkpoints;
      for (int64_t i=1;i<*count;++i) checkpoints.push_back(i);
      replacement->setAttr("tessera.autodiff.checkpoint_indices",b.getDenseI64ArrayAttr(checkpoints));
    }
    b.setInsertionPointToStart(replacement.getBody());
    IRMapping mapping;
    for (auto [a,v]:llvm::zip(before.getArguments(),replacement.getRegionIterArgs())) mapping.map(a,v);
    for (auto &op:before.without_terminator()) b.clone(op,mapping);
    auto branch=scf::IfOp::create(b,loc,loop.getResultTypes(),mapping.lookupOrDefault(condition.getCondition()),true);
    b.setInsertionPointToStart(&branch.getThenRegion().front());
    for (auto [a,v]:llvm::zip(after.getArguments(),replacement.getRegionIterArgs())) mapping.map(a,v);
    for (auto &op:after.without_terminator()) b.clone(op,mapping);
    SmallVector<Value> next;
    for (Value v:yield.getOperands()) next.push_back(mapping.lookupOrDefault(v));
    scf::YieldOp::create(b,loc,next);
    b.setInsertionPointToStart(&branch.getElseRegion().front());
    scf::YieldOp::create(b,loc,replacement.getRegionIterArgs());
    b.setInsertionPointToEnd(replacement.getBody());
    scf::YieldOp::create(b,loc,branch.getResults());
    loop.replaceAllUsesWith(replacement.getResults());
    loop.erase();
  });
}

class AutodiffPairedPass
    : public mlir::PassWrapper<AutodiffPairedPass,
                               mlir::OperationPass<mlir::ModuleOp>> {
public:
  MLIR_DEFINE_EXPLICIT_INTERNAL_INLINE_TYPE_ID(AutodiffPairedPass)
  AutodiffPairedPass() = default;
  AutodiffPairedPass(const AutodiffPairedPass &other) : PassWrapper(other) {}
  mlir::Pass::Option<bool> exportScaledTranspose{*this, "export-scaled-transpose",
      llvm::cl::desc("Export native typed scale-adjoint regions and their SSA lifetimes"),
      llvm::cl::init(false)};
  mlir::Pass::Option<int64_t> selectScaledTransposeMember{*this, "select-scaled-transpose-member",
      llvm::cl::desc("Project one actual native scale-adjoint member"), llvm::cl::init(-1)};
  mlir::Pass::Option<bool> normalizeCountedWhile{*this, "normalize-counted-while",
      llvm::cl::desc("Normalize proven counted whiles for persistent tensor products"), llvm::cl::init(false)};
  mlir::Pass::Option<bool> normalizeDataWhile{*this, "normalize-data-while",
      llvm::cl::desc("Normalize SSA-bounded pure data-dependent whiles to persistent state machines"), llvm::cl::init(false)};
  mlir::Pass::Option<bool> boxProductScalars{*this, "box-product-scalars",
      llvm::cl::desc("Store exported predicate and index residuals as rank-zero i8/i64 tensors"), llvm::cl::init(false)};

  mlir::Pass::Option<bool> emitStorageChild{*this, "emit-storage-child",
      llvm::cl::desc("Generate a bounded native primal/VJP child"), llvm::cl::init(false)};

  mlir::Pass::Option<std::string> checkpointProduct{*this, "checkpoint-product",
      llvm::cl::desc("Export one isolated generated attention forward/backward/row-correction checkpoint"), llvm::cl::init("")};

  mlir::Pass::Option<bool> pruneCheckpointGradients{*this, "prune-checkpoint-gradients",
      llvm::cl::desc("Skip unrequested checkpoint gradient computations, retaining zero-filled ABI outputs"),
      llvm::cl::init(false)};

  mlir::Pass::Option<bool> compactCheckpointGradients{*this, "compact-checkpoint-gradients",
      llvm::cl::desc("Export a compact requested-gradient physical checkpoint ABI"),
      llvm::cl::init(false)};

  mlir::Pass::Option<std::string> compactCheckpointLaunch{*this, "compact-checkpoint-launch",
      llvm::cl::desc("Compact checkpoint launch layout: packed_v1 or logical_v1"),
      llvm::cl::init("packed_v1")};

  mlir::Pass::Option<unsigned> compactCheckpointThreads{*this, "compact-checkpoint-threads",
      llvm::cl::desc("Compact checkpoint block threads: 64 or 128"),
      llvm::cl::init(128)};

  mlir::Pass::Option<std::string> exportProduct{*this, "export-product",
      llvm::cl::desc("Export a typed generated forward/backward product without scalarizing residual tapes"), llvm::cl::init("")};

  llvm::StringRef getArgument() const final {
    return "tessera-autodiff-paired";
  }
  llvm::StringRef getDescription() const final {
    return "Paired forward/backward autodiff — emits @f__bwd(inputs, "
           "out_cotangents) -> input_cotangents (recompute-all residual "
           "policy). Phase 2 of AUTODIFF_UNIFICATION_PLAN.md.";
  }
  void getDependentDialects(mlir::DialectRegistry &registry) const override {
    registry.insert<tessera::attn::TesseraAttnDialect>();
    // `emit-storage-child` creates tile ops for the native storage child. Not
    // declaring the dialect here was the third instance of the 2026-09-16
    // class: green on every NDEBUG driver, and on the assertions-ON driver
    // "Loading a dialect (tile) while in a multi-threaded execution context"
    // (Tajasarus, `test_native_storage_generation`, 2026-09-17).
    registry.insert<tessera::tile::TesseraTileDialect>();
    registry.insert<mlir::arith::ArithDialect, mlir::cf::ControlFlowDialect,
                    mlir::func::FuncDialect, mlir::linalg::LinalgDialect,
                    mlir::scf::SCFDialect, mlir::tensor::TensorDialect, mlir::gpu::GPUDialect,
                    mlir::LLVM::LLVMDialect, mlir::memref::MemRefDialect, mlir::math::MathDialect>();
  }

  void runOnOperation() override {
    auto module = getOperation();
    // A bounded symbol-body control_scan already has a proven lowering to one
    // scf.for whose body is inlined and whose stacked stream uses exact tensor
    // slice transposes. Run that normalization as part of paired reverse mode
    // when a reverse-marked function needs it, so callers do not have to know
    // a pass-order workaround. Payload, dynamic, and malformed forms remain
    // unlowered and reach the named fail-closed diagnostic below.
    bool needsStructuredScan = false;
    module.walk([&](mlir::func::FuncOp fn) {
      auto marker = fn->getAttrOfType<mlir::StringAttr>(kAutodiffMarker);
      if (!marker || marker.getValue() != "reverse" ||
          fn->hasAttr("tessera.autodiff.role"))
        return;
      fn.walk([&](mlir::Operation *op) {
        needsStructuredScan |=
            op->getName().getStringRef() == "tessera.control_scan";
      });
    });
    if (needsStructuredScan) {
      mlir::OpPassManager normalization("builtin.module");
      normalization.addPass(createLowerControlFlowToSCFPass());
      if (mlir::failed(runPipeline(normalization, module))) {
        module.emitError(
            "AUTODIFF_CONTROL_SCAN_UNSUPPORTED: bounded control_scan "
            "normalization failed before paired reverse mode");
        return signalPassFailure();
      }
    }
    llvm::SmallVector<mlir::func::FuncOp> targets;
    module.walk([&](mlir::func::FuncOp fn) {
      auto marker = fn->getAttrOfType<mlir::StringAttr>(kAutodiffMarker);
      // Skip functions we already produced (role=backward) or that aren't marked.
      if (marker && marker.getValue() == "reverse" &&
          !fn->hasAttr("tessera.autodiff.role"))
        targets.push_back(fn);
    });
    // A function that already has its partner is not a *fresh* reverse request.
    // Leaving an existing partner alone is right for a plain re-pairing run
    // (2026-09-16: before that, one unpaired function dragged every paired one
    // back through the pass and MLIR rejected the second definition). But a
    // product request — native VJP storage child, typed export, checkpoint — asks
    // this pass to derive something from a pairing it is about to perform, and
    // there is nothing to derive it from when the pairing already happened.
    // Before the partner-skip, such a replay failed loudly because MLIR rejected
    // the duplicate; afterwards it exited 0 having emitted no product at all.
    // CI cannot see either outcome: its unit lane has no tessera-opt, so the test
    // that covers this skips there.
    const bool wantsProduct =
        emitStorageChild || exportScaledTranspose || !exportProduct.empty() || !checkpointProduct.empty();
    if (wantsProduct) {
      for (auto fn : targets)
        if (module.lookupSymbol<mlir::func::FuncOp>((fn.getName() + "__bwd").str())) {
          module.emitError("autodiff product request needs a fresh reverse pairing: @")
              << fn.getName() << " already has its partner @" << fn.getName()
              << "__bwd, so there is no pairing left for this pass to derive the "
                 "product from; request the product on the unpaired module";
          return signalPassFailure();
        }
    }
    if (!exportProduct.empty() && (emitStorageChild || !checkpointProduct.empty() || targets.size()!=1 ||
        (exportProduct!="forward" && exportProduct!="backward"))) {
      module.emitError("typed product export requires one fresh reverse request and one forward/backward role");
      return signalPassFailure();
    }
    if ((compactCheckpointThreads != 64 && compactCheckpointThreads != 128) ||
        (!compactCheckpointGradients && compactCheckpointThreads != 128)) {
      module.emitError("compact checkpoint threads require 64 or 128 in a compact gradient export");
      return signalPassFailure();
    }
    if (compactCheckpointLaunch != "packed_v1" && compactCheckpointLaunch != "logical_v1") {
      module.emitError("compact checkpoint launch requires packed_v1 or logical_v1");
      return signalPassFailure();
    }
    if (!compactCheckpointGradients && compactCheckpointLaunch != "packed_v1") {
      module.emitError("compact checkpoint launch requires compact gradient export");
      return signalPassFailure();
    }
    if (compactCheckpointGradients && (!pruneCheckpointGradients || checkpointProduct != "backward")) {
      module.emitError("compact checkpoint outputs require pruned backward checkpoint export");
      return signalPassFailure();
    }
    if (pruneCheckpointGradients && checkpointProduct.empty()) {
      module.emitError("checkpoint gradient pruning requires a checkpoint product export");
      return signalPassFailure();
    }
    if (!checkpointProduct.empty() && (emitStorageChild || targets.size() != 1 ||
        (checkpointProduct != "forward" && checkpointProduct != "backward" &&
         checkpointProduct != "row_correction"))) {
      module.emitError("checkpoint product requires one fresh reverse request and forward/backward/row_correction role");
      return signalPassFailure();
    }
    if (emitStorageChild && targets.size() != 1) {
      module.emitError("native VJP requires exactly one fresh reverse request");
      return signalPassFailure();
    }
    if (normalizeCountedWhile)
      for (auto fn : targets) normalizeCountedTapeWhiles(fn);
    if (normalizeDataWhile)
      for (auto fn : targets) normalizeDataDependentTapeWhiles(fn);
    if (module->hasAttr("tessera.attention_sequence_bounds")) {
      if (targets.size()!=1 || checkpointProduct.empty() ||
          failed(projectBoundedAttentionEntry(module,targets.front())))
        return signalPassFailure();
    }
    for (auto fn : targets)
      if (failed(buildBackward(fn)))
        return signalPassFailure();
    if (!exportProduct.empty() && failed(exportTypedProduct(module,exportProduct)))
      return signalPassFailure();
    if (exportScaledTranspose) {
      if (emitStorageChild || !exportProduct.empty() || !checkpointProduct.empty() ||
          targets.size() != 1 || selectScaledTransposeMember < -1) {
        module.emitError("scaled transpose export conflicts with another product export");
        return signalPassFailure();
      }
      if (failed(emitNativeScaledMatmulProgram(module, false, true)) ||
          (selectScaledTransposeMember >= 0 &&
           failed(projectNativeScaledMatmulMember(module, selectScaledTransposeMember))))
        return signalPassFailure();
    } else if (selectScaledTransposeMember != -1) {
      module.emitError("scaled transpose member selection requires program export");
      return signalPassFailure();
    }
    if (emitStorageChild && failed(emitNativeStorageJVP(module, true))) signalPassFailure();
    if (!checkpointProduct.empty() && failed(exportCheckpoint(module, checkpointProduct))) signalPassFailure();
  }

private:

  mlir::LogicalResult exportTypedProduct(mlir::ModuleOp module, llvm::StringRef role) {
    llvm::SmallVector<mlir::func::FuncOp> functions;
    mlir::func::FuncOp backward;
    for (auto fn:module.getOps<mlir::func::FuncOp>()) {
      functions.push_back(fn);
      if (auto attr=fn->getAttrOfType<mlir::StringAttr>("tessera.autodiff.role"); attr && attr.getValue()=="backward") backward=fn;
    }
    if (functions.size()!=2 || !backward)
      return module.emitError("typed product export requires an isolated generated pair");
    auto ref=backward->getAttrOfType<mlir::FlatSymbolRefAttr>("tessera.autodiff.forward");
    auto forward=ref ? module.lookupSymbol<mlir::func::FuncOp>(ref.getValue()) : mlir::func::FuncOp();
    if (!forward || forward==backward) return module.emitError("typed product export lost its forward owner");
    bool calls=false;
    module.walk([&](mlir::func::CallOp){calls=true;});
    if (calls) return module.emitError("typed product export requires inlined symbol dependencies");
    auto residuals=forward->getAttrOfType<mlir::ArrayAttr>("tessera.autodiff.residual_sources");
    unsigned residualCount=residuals ? residuals.size() : 0;
    if (residualCount>forward.getNumResults() || backward.getNumArguments()!=forward.getNumArguments()+forward.getNumResults())
      return module.emitError("typed product residual ABI disagrees");
    unsigned primalCount=forward.getNumResults()-residualCount;
    for (unsigned i=0;i<residualCount;++i)
      if (forward.getResultTypes()[primalCount+i]!=backward.getArgumentTypes()[forward.getNumArguments()+primalCount+i])
        return module.emitError("typed product residual type disagrees");
    // The paired differentiator owns logical scalar residuals. The physical
    // export owns their lossless storage projection, never Python text surgery.
    // Only residual positions are boxed; public differentiable inputs retain
    // their original ABI. Both exports derive the same complete pair lineage.
    if (boxProductScalars) {
      using namespace mlir;
      for (unsigned i=0;i<residualCount;++i) {
        unsigned resultIndex=primalCount+i;
        Type type=forward.getResultTypes()[resultIndex];
        auto logicalTensor=dyn_cast<RankedTensorType>(type);
        Type logicalElement=logicalTensor ? logicalTensor.getElementType() : type;
        if (!logicalElement.isIndex() && !logicalElement.isInteger(1)) continue;
        OpBuilder b(module.getContext());
        auto element=logicalElement.isIndex() ? b.getI64Type() : b.getI8Type();
        auto storage=RankedTensorType::get(logicalTensor ? logicalTensor.getShape() : ArrayRef<int64_t>{},element);
        auto ret=cast<func::ReturnOp>(forward.getBody().front().getTerminator());
        b.setInsertionPoint(ret);
        Value value=ret.getOperand(resultIndex);
        Type castType=logicalTensor ? Type(storage) : Type(element);
        if (logicalElement.isIndex()) value=arith::IndexCastOp::create(b,ret.getLoc(),castType,value);
        else value=arith::ExtUIOp::create(b,ret.getLoc(),castType,value);
        if (!logicalTensor) value=tensor::FromElementsOp::create(b,ret.getLoc(),storage,ValueRange{value});
        ret->setOperand(resultIndex,value);
        SmallVector<Type> results(forward.getResultTypes());
        results[resultIndex]=storage;
        forward.setType(b.getFunctionType(forward.getArgumentTypes(),results));
        unsigned argumentIndex=forward.getNumArguments()+resultIndex;
        auto argument=backward.getArgument(argumentIndex);
        argument.setType(storage);
        b.setInsertionPointToStart(&backward.getBody().front());
        Value scalar=argument;
        Operation *first=nullptr;
        if (!logicalTensor) {
          scalar=tensor::ExtractOp::create(b,backward.getLoc(),argument,ValueRange{});
          first=scalar.getDefiningOp();
        }
        if (logicalElement.isIndex()) scalar=arith::IndexCastOp::create(b,backward.getLoc(),type,scalar);
        else scalar=arith::TruncIOp::create(b,backward.getLoc(),type,scalar);
        if (!first) first=scalar.getDefiningOp();
        argument.replaceAllUsesExcept(scalar,first);
        SmallVector<Type> arguments(backward.getArgumentTypes());
        arguments[argumentIndex]=storage;
        backward.setType(b.getFunctionType(arguments,backward.getResultTypes()));
      }
    }
    std::string lineage; llvm::raw_string_ostream lineOS(lineage); module.print(lineOS); lineOS.flush();
    auto selected=role=="forward" ? forward : backward;
    llvm::json::Array args,results,sources;
    auto typeText=[](mlir::Type type){std::string text; llvm::raw_string_ostream os(text);type.print(os);os.flush();return text;};
    for (auto t:selected.getArgumentTypes()) args.push_back(typeText(t));
    for (auto t:selected.getResultTypes()) results.push_back(typeText(t));
    if (residuals) for (auto attr:residuals) {
      auto text=mlir::dyn_cast<mlir::StringAttr>(attr);
      if (!text) return module.emitError("typed product residual source must be a string");
      sources.push_back(text.getValue().str());
    }
    llvm::json::Object abi{{"schema",1},{"role",role.str()},{"entry",selected.getName().str()},
      {"inputs",std::move(args)},{"results",std::move(results)},
      {"primal_inputs",int64_t(forward.getNumArguments())},{"primal_results",int64_t(primalCount)},
      {"residual_sources",std::move(sources)}};
    std::string json; llvm::raw_string_ostream jsonOS(json);jsonOS<<llvm::json::Value(std::move(abi));jsonOS.flush();
    // The complete pair remains in lineage. The executable export has no
    // dangling cross-product symbol attributes and retains every nested region.
    selected->removeAttr("tessera.autodiff.forward");
    selected->removeAttr("tessera.autodiff.backward");
    selected->removeAttr("tessera.autodiff.paired");
    (role=="forward" ? backward : forward).erase();
    mlir::Builder b(module.getContext());
    // A product is not a request. The backward already carries
    // role="backward", which is what this pass keys on to leave a function it
    // produced alone; the forward product kept only the `tessera.autodiff =
    // "reverse"` *request* marker, so any later pipeline that runs this pass --
    // the JIT runs it unconditionally -- differentiated the exported forward a
    // second time, re-materialized its residual tapes on top of the first
    // materialization, and handed the caller a function whose ABI no longer
    // matched the product contract it had just read. On every host with the
    // native x86 JIT that was a segfault at the first invoke, recorded for a
    // day as a bufferization defect in the shape-varying carry
    // (AUTODIFF-SHAPE-WHILE-FORWARD-2026-09-17); the carry was never at fault.
    selected->setAttr("tessera.autodiff.role",b.getStringAttr(role));
    // Forward inputs and backward residuals belong to the persistent frame.
    // Bufferization must not reuse their storage for mutable intermediates.
    for (unsigned i=0;i<selected.getNumArguments();++i)
      selected.setArgAttr(i,"bufferization.writable",b.getBoolAttr(false));
    module->setAttr("tessera.autodiff.product_abi",b.getStringAttr(json));
    module->setAttr("tessera.autodiff.product_pair",b.getStringAttr(lineage));
    return mlir::success();
  }

  mlir::LogicalResult exportRowCorrectionCheckpoint(
      mlir::ModuleOp module, mlir::Operation *backward,
      llvm::ArrayRef<mlir::func::FuncOp> functions,
      llvm::ArrayRef<int64_t> frontendArgumentIndices,
      llvm::ArrayRef<int64_t> gradientActivity) {
    // Project the actual generated AD residual product. The source pair remains
    // the lineage witness; the rounded saved O is not a correction input.
    auto seedAttr = backward->getAttrOfType<mlir::BoolAttr>("lse_cotangent");
    bool seeded = seedAttr && seedAttr.getValue();
    bool bias = backward->getNumOperands() == 7 + unsigned(seeded);
    auto query = mlir::dyn_cast<mlir::RankedTensorType>(backward->getOperand(1).getType());
    if (!query || (!query.getElementType().isF16() && !query.getElementType().isBF16()) ||
        llvm::any_of(backward->getOperandTypes(), [](mlir::Type type) {
          auto tensor = mlir::dyn_cast<mlir::RankedTensorType>(type);
          return !tensor || !tensor.hasStaticShape();
        }))
      return backward->emitError("row correction export requires static half checkpoint inputs");
    llvm::SmallVector<mlir::Type> argumentTypes;
    for (auto [index, operand] : llvm::enumerate(backward->getOperands())) {
      if (index == 4) continue; // saved rounded O is not in this derivative sum
      argumentTypes.push_back(operand.getType());
    }
    mlir::Type rowType = backward->getOperand(5 + unsigned(bias)).getType();
    std::string lineage; llvm::raw_string_ostream stream(lineage);
    module.print(stream); stream.flush();
    mlir::OpBuilder builder(module.getContext());
    builder.setInsertionPointToEnd(module.getBody());
    auto fn = mlir::func::FuncOp::create(builder, backward->getLoc(),
        "attention_row_correction_checkpoint",
        builder.getFunctionType(argumentTypes, llvm::ArrayRef<mlir::Type>{rowType}));
    auto *block = fn.addEntryBlock();
    builder.setInsertionPointToStart(block);
    mlir::OperationState state(backward->getLoc(), "tessera_attn.checkpoint_row_correction");
    state.addOperands(block->getArguments());
    state.addTypes(rowType);
    state.addAttribute("scale", backward->getAttr("scale"));
    state.addAttribute("causal", backward->getAttr("causal"));
    state.addAttribute("bias", builder.getBoolAttr(bias));
    state.addAttribute("lse_cotangent", builder.getBoolAttr(seeded));
    auto *product = builder.create(state);
    mlir::func::ReturnOp::create(builder, backward->getLoc(), product->getResults());
    llvm::SmallVector<mlir::Attribute> args;
    llvm::SmallVector<llvm::StringRef> names{"dO", "q", "k", "v"};
    if (bias) names.push_back("bias");
    names.push_back("lse");
    if (seeded) names.push_back("row_seed");
    for (auto name : names) args.push_back(builder.getStringAttr(name));
    fn->setAttr("tessera.argument_bindings", builder.getArrayAttr(args));
    fn->setAttr("tessera.result_bindings", builder.getArrayAttr({builder.getStringAttr("row_correction")}));
    if (!gradientActivity.empty())
      fn->setAttr("tessera.row_correction_gradient_activity", builder.getDenseI64ArrayAttr(gradientActivity));
    // Keep attributes attached to the actual residual arguments. Primal
    // argument properties remain authoritative in the original forward map,
    // even when the generated backward has not copied those properties.
    auto originalBackward = backward->getParentOfType<mlir::func::FuncOp>();
    unsigned argumentIndex = 0;
    for (auto [index, operand] : llvm::enumerate(backward->getOperands())) {
      if (index == 4) continue;
      auto argument = mlir::cast<mlir::BlockArgument>(operand);
      if (auto attrs = originalBackward.getArgAttrDict(argument.getArgNumber()))
        for (auto attr : attrs)
          fn.setArgAttr(argumentIndex, attr.getName().strref(), attr.getValue());
      ++argumentIndex;
    }
    for (auto original : functions) {
      if (original.getBody().front().front().getName().getStringRef() !=
          "tessera_attn.checkpoint_forward") continue;
      for (unsigned role = 0; role < frontendArgumentIndices.size(); ++role)
        if (auto attrs = original.getArgAttrDict(frontendArgumentIndices[role]))
          for (auto attr : attrs)
            fn.setArgAttr(1 + role, attr.getName().strref(), attr.getValue());
    }
    for (unsigned i = 0; i < fn.getNumArguments(); ++i)
      fn.setArgAttr(i, "bufferization.writable", builder.getBoolAttr(false));
    for (auto old : functions) old.erase();
    module->setAttr("tessera.attention_argument_indices", builder.getDenseI64ArrayAttr(frontendArgumentIndices));
    module->setAttr("tessera.attention_ad_pair", builder.getStringAttr(lineage));
    return mlir::success();
  }

  mlir::LogicalResult exportCheckpoint(mlir::ModuleOp module, llvm::StringRef role) {
    llvm::SmallVector<mlir::func::FuncOp> functions;
    mlir::Operation *selected = nullptr;
    unsigned forwards = 0, backwards = 0;
    llvm::SmallVector<int64_t> frontendArgumentIndices, gradientActivity, requestedArguments;
    bool hasActivityRequest = false;
    for (auto fn : module.getOps<mlir::func::FuncOp>()) {
      functions.push_back(fn);
      if (!fn.getBody().hasOneBlock() || fn.getBody().front().getOperations().size() != 2)
        return fn.emitError("checkpoint export requires isolated generated attention products");
      auto *op = &fn.getBody().front().front();
      auto name = op->getName().getStringRef();
      bool forward = name == "tessera_attn.checkpoint_forward";
      bool backward = name == "tessera_attn.checkpoint_backward";
      if (!forward && !backward) return fn.emitError("checkpoint export found another product family");
      forwards += forward; backwards += backward;
      if ((role == "forward" && forward) ||
          ((role == "backward" || role == "row_correction") && backward)) selected = op;
      auto ret = mlir::dyn_cast<mlir::func::ReturnOp>(fn.getBody().front().back());
      if (!ret) return fn.emitError("checkpoint return roles disagree");
      if (forward) {
        llvm::SmallDenseSet<unsigned> seenArguments;
        if (fn.getNumArguments() != op->getNumOperands())
          return fn.emitError("checkpoint export requires one entry argument per input role");
        for (auto value : op->getOperands()) {
          auto arg = mlir::dyn_cast<mlir::BlockArgument>(value);
          if (!arg || arg.getOwner() != &fn.getBody().front() ||
              !seenArguments.insert(arg.getArgNumber()).second)
            return fn.emitError("checkpoint input roles require distinct entry arguments");
          frontendArgumentIndices.push_back(arg.getArgNumber());
        }
        if (pruneCheckpointGradients) {
          if (auto requestAttr = fn->getAttr("tessera.autodiff.wrt_indices")) {
            auto request = mlir::dyn_cast<mlir::ArrayAttr>(requestAttr);
            llvm::SmallDenseSet<int64_t> seen;
            if (!request || request.empty())
              return fn.emitError("checkpoint gradient request requires nonempty input indices");
            for (auto attr : request) {
              auto index = mlir::dyn_cast<mlir::IntegerAttr>(attr);
              if (!index || index.getInt() < 0 ||
                  index.getInt() >= fn.getNumArguments() ||
                  !seen.insert(index.getInt()).second)
                return fn.emitError("checkpoint gradient request requires unique in-range input indices");
              requestedArguments.push_back(index.getInt());
            }
            hasActivityRequest = true;
          }
        }
        // Paired AD appends the saved forward output and LSE after the
        // user-visible output. The package boundary still exports the two
        // checkpoint results, with the output residual aliasing result 0.
        unsigned visible = ret.getNumOperands() >= 2 ? ret.getNumOperands() - 2 : 0;
        if ((visible != 1 && visible != 2) || op->getNumResults() != 2 ||
            ret.getOperand(0) != op->getResult(0) ||
            (visible == 2 && ret.getOperand(1) != op->getResult(1)) ||
            ret.getOperand(visible) != op->getResult(0) ||
            ret.getOperand(visible + 1) != op->getResult(1))
          return fn.emitError("checkpoint forward output/LSE residual roles disagree");
      } else {
        // Reverse activity may select/reorder Q/K/V cotangents. The native
        // checkpoint still exports the complete physical gradient product;
        // the frontend selects requested results without rebuilding AD IR.
        llvm::SmallDenseSet<mlir::Value> returned;
        if (ret.getNumOperands() == 0 || ret.getNumOperands() > op->getNumResults())
          return fn.emitError("checkpoint return roles disagree");
        for (auto value : ret.getOperands())
          if (!llvm::is_contained(op->getResults(), value) ||
              !returned.insert(value).second)
            return fn.emitError("checkpoint return roles disagree");
      }
      for (auto operand : op->getOperands()) {
        auto arg = mlir::dyn_cast<mlir::BlockArgument>(operand);
        if (!arg || arg.getOwner() != &fn.getBody().front()) return fn.emitError("checkpoint operands must be entry arguments");
      }
    }
    if (functions.size() != 2 || forwards != 1 || backwards != 1 || !selected)
      return module.emitError("checkpoint export requires exactly one generated forward/backward pair");
    if (pruneCheckpointGradients && (role == "backward" || role == "row_correction")) {
      if (frontendArgumentIndices.size() != selected->getNumResults())
        return selected->emitError("checkpoint gradient roles disagree with forward input roles");
      for (int64_t index : frontendArgumentIndices)
        gradientActivity.push_back(!hasActivityRequest ||
                                   llvm::is_contained(requestedArguments, index));
    }
    if (role == "row_correction")
      return exportRowCorrectionCheckpoint(module, selected, functions,
                                           frontendArgumentIndices, gradientActivity);
    std::string lineage; llvm::raw_string_ostream stream(lineage); module.print(stream); stream.flush();
    mlir::OpBuilder builder(module.getContext());
    builder.setInsertionPointToEnd(module.getBody());
    auto fn = mlir::func::FuncOp::create(builder, selected->getLoc(),
        ("attention_" + role + "_checkpoint").str(),
        builder.getFunctionType(selected->getOperandTypes(), selected->getResultTypes()));
    auto *block = fn.addEntryBlock();
    builder.setInsertionPointToStart(block);
    mlir::IRMapping mapping;
    for (auto [operand, arg] : llvm::zip(selected->getOperands(), block->getArguments())) mapping.map(operand, arg);
    auto *product = builder.clone(*selected, mapping);
    mlir::func::ReturnOp::create(builder, selected->getLoc(), product->getResults());
    llvm::SmallVector<mlir::Attribute> args, results;
    llvm::SmallVector<llvm::StringRef> argumentNames = role == "forward" ?
        llvm::SmallVector<llvm::StringRef>{"q", "k", "v"} : llvm::SmallVector<llvm::StringRef>{"dO", "q", "k", "v", "output", "lse"};
    llvm::SmallVector<llvm::StringRef> resultNames = role == "forward" ?
        llvm::SmallVector<llvm::StringRef>{"output", "lse"} : llvm::SmallVector<llvm::StringRef>{"dq", "dk", "dv"};
    auto seedAttr = selected->getAttrOfType<mlir::BoolAttr>("lse_cotangent");
    bool seeded = role == "backward" && seedAttr && seedAttr.getValue();
    bool bias = selected->getNumOperands() - unsigned(seeded) == (role == "forward" ? 4u : 7u);
    if (bias) argumentNames.insert(argumentNames.begin() + (role == "forward" ? 3 : 5), "bias");
    if (seeded) argumentNames.push_back("row_seed");
    if (role == "backward" && selected->getNumResults() == 4) resultNames.push_back("dbias");
    for (auto name : argumentNames) args.push_back(builder.getStringAttr(name));
    for (auto name : resultNames) results.push_back(builder.getStringAttr(name));
    fn->setAttr("tessera.argument_bindings", builder.getArrayAttr(args));
    fn->setAttr("tessera.result_bindings", builder.getArrayAttr(results));
    if (pruneCheckpointGradients && role == "backward")
      fn->setAttr("tessera.checkpoint_gradient_activity",
                  builder.getDenseI64ArrayAttr(gradientActivity));
    if (compactCheckpointGradients) {
      fn->setAttr("tessera.checkpoint_gradient_output", builder.getStringAttr("compact_v1"));
      fn->setAttr("tessera.checkpoint_gradient_launch", builder.getStringAttr(compactCheckpointLaunch));
      fn->setAttr("tessera.checkpoint_gradient_threads", builder.getI64IntegerAttr(compactCheckpointThreads));
    }
    for (auto old : functions) old.erase();
    module->setAttr("tessera.attention_argument_indices", builder.getDenseI64ArrayAttr(frontendArgumentIndices));
    module->setAttr("tessera.attention_ad_pair", builder.getStringAttr(lineage));
    return mlir::success();
  }

  llvm::DenseMap<mlir::Operation *, llvm::SmallVector<mlir::Value>>
      explicitRegionResiduals;

  mlir::LogicalResult buildBackward(mlir::func::FuncOp fwd) {
    explicitRegionResiduals.clear();
    auto module = fwd->getParentOfType<mlir::ModuleOp>();
    mlir::MLIRContext *ctx = &getContext();

    if (fwd.getBody().empty()) {
      fwd.emitError() << "[AUTODIFF_PAIRED] cannot differentiate a declaration";
      return mlir::failure();
    }
    if (mlir::failed(structurizeNativeDiamonds(fwd)) ||
        mlir::failed(structurizeBoundedNativeCFGs(fwd)))
      return mlir::failure();
    eraseStaticallyEmptyLoops(fwd);
    if (mlir::failed(materializeIfResiduals(fwd)) ||
        mlir::failed(materializeWhileResiduals(fwd)) ||
        mlir::failed(materializeGenericForResiduals(fwd)))
      return mlir::failure();
    mlir::Block &fwdBlock = fwd.getBody().front();

    auto returnOp = mlir::dyn_cast<mlir::func::ReturnOp>(fwdBlock.getTerminator());
    if (!returnOp) {
      fwd.emitError() << "[AUTODIFF_PAIRED] forward has no return terminator";
      return mlir::failure();
    }
    GraphDataflowAnalysis dataflow(fwd);
    if (mlir::failed(dataflow.run())) {
      fwd.emitError()
          << "[AUTODIFF_PAIRED] Graph IR dataflow analysis failed";
      return mlir::failure();
    }
    GraphDataflowAnalysis::ActiveOpSet activeOps =
        dataflow.computeActivity(returnOp.getOperands());

    // Collect only the backward-reachable forward cone. Inactive side
    // computations and inactive nested regions are neither cloned nor rejected.
    llvm::SmallVector<mlir::Operation *> forwardOps;
    for (mlir::Operation &opRef : fwdBlock) {
      mlir::Operation *op = &opRef;
      if (mlir::isa<mlir::func::ReturnOp>(op))
        continue;
      op->setAttr("tessera.autodiff.activity",
                  mlir::StringAttr::get(ctx, activeOps.contains(op)
                                                ? "active"
                                                : "inactive"));
      if (!activeOps.contains(op))
        continue;
      if (op->getNumRegions() != 0 &&
          !RegionAdjointInterface::supports(op) && !gatherRead(op)) {
        op->emitError() << "[AUTODIFF_NESTED_REGION] active paired reverse-mode "
                           "path contains unsupported nested-region op ('"
                        << op->getName().getStringRef() << "')";
        return mlir::failure();
      }
      if (auto policy = op->getAttrOfType<mlir::StringAttr>(
              "tessera.autodiff.checkpoint_policy");
          policy && policy.getValue() != "recompute_all") {
        auto materialized = op->getAttrOfType<mlir::BoolAttr>(
            "tessera.autodiff.residual_materialized");
        if ((policy.getValue() != "save" && policy.getValue() != "hybrid") ||
            !materialized ||
            !materialized.getValue()) {
          op->emitError()
              << "paired reverse-mode cannot consume checkpoint policy '"
              << policy.getValue()
              << "' until its explicit residual operands/results have been "
                 "materialized";
          return mlir::failure();
        }
      }
      // Replayability and differentiability are separate questions, and a
      // refusal now says which one failed (W4-EFFECTS-1 E2).
      if (!admitStochasticOp(op))
        return mlir::failure();
      forwardOps.push_back(op);
    }

    // Backward signature: (forward inputs..., out_cotangents...) ->
    // (input_cotangents...). One out-cotangent per forward result; the input
    // cotangent types mirror the forward argument types.
    llvm::SmallVector<mlir::Type> fwdInTypes(fwd.getArgumentTypes().begin(),
                                             fwd.getArgumentTypes().end());
    llvm::SmallVector<mlir::Type> fwdResTypes(
        fwd.getResultTypes().begin(), fwd.getResultTypes().end());

    llvm::DenseMap<mlir::Operation *, mlir::Operation *> attentionForwards;
    llvm::SmallVector<mlir::Value> forwardResiduals;
    llvm::SmallVector<mlir::Attribute> residualSources;
    bool hasHybridResidual = false;
    llvm::DenseMap<mlir::Operation *, llvm::SmallVector<mlir::Value>>
        residualValues;
    for (mlir::Operation *op : forwardOps) {
      if (auto checkpointPolicy = op->getAttrOfType<mlir::StringAttr>(
              "tessera.autodiff.checkpoint_policy"))
        hasHybridResidual |= checkpointPolicy.getValue() == "hybrid";
      auto materialized = op->getAttrOfType<mlir::BoolAttr>(
          "tessera.autodiff.residual_materialized");
      llvm::SmallVector<mlir::Value> values;
      if (op->getName().getStringRef() == "tessera.flash_attn" && denseAttentionAD(op, true, true, true, true)) {
        mlir::OpBuilder attentionBuilder(op);
        auto saved = attentionCheckpoint(attentionBuilder, op, false, op->getOperands());
        if (!saved) return mlir::failure();
        attentionForwards.try_emplace(op, saved);
        values.push_back(saved->getResult(0));
        values.push_back(saved->getResult(1));
        residualSources.push_back(
            mlir::StringAttr::get(ctx, "tessera.flash_attn:output"));
        residualSources.push_back(
            mlir::StringAttr::get(ctx, "tessera.flash_attn:lse"));
      } else if (materialized && materialized.getValue()) {
        auto indices = op->getAttrOfType<mlir::DenseI64ArrayAttr>(
            "tessera.autodiff.residual_result_indices");
        if (!indices || indices.empty()) {
          op->emitError()
              << "materialized region residual has no result indices";
          return mlir::failure();
        }
        auto owner = op->getAttrOfType<mlir::StringAttr>(
            "tessera.autodiff.residual_owner");
        if (owner && owner.getValue() == "scf_if") {
          auto ifOp = mlir::dyn_cast<mlir::scf::IfOp>(op);
          if (!ifOp) {
            op->emitError() << "scf_if residual owner requires scf.if";
            return mlir::failure();
          }
          values.push_back(ifOp.getCondition());
          residualSources.push_back(
              mlir::StringAttr::get(ctx, "scf.if:predicate"));
        } else if (owner && owner.getValue() == "scf_while") {
          auto whileOp = mlir::dyn_cast<mlir::scf::WhileOp>(op);
          if (!whileOp || whileOp.getNumResults() == 0 ||
              !llvm::isa<mlir::IndexType>(whileOp.getResult(0).getType())) {
            op->emitError()
                << "scf_while residual owner requires counted scf.while";
            return mlir::failure();
          }
          values.push_back(whileOp.getResult(0));
          residualSources.push_back(
              mlir::StringAttr::get(ctx, "scf.while:trip_count"));
        }
        for (auto [residualOrdinal, index] :
             llvm::enumerate(indices.asArrayRef())) {
          if (index < 0 || index >= op->getNumResults()) {
            op->emitError() << "region residual result index " << index
                            << " is outside the operation result range";
            return mlir::failure();
          }
          values.push_back(op->getResult(index));
          residualSources.push_back(mlir::StringAttr::get(
              ctx, owner && owner.getValue() == "scf_if"
                       ? ("scf.if:branch_value:" +
                          llvm::Twine(residualOrdinal))
                             .str()
                       : owner && owner.getValue() == "scf_while"
                             ? ("scf.while:state_tape:" +
                                llvm::Twine(residualOrdinal))
                                   .str()
                       : owner ? (owner.getValue() + ":state_tape" +
                            (indices.size() == 1
                                 ? llvm::Twine()
                                 : ":" + llvm::Twine(residualOrdinal)))
                               .str()
                         : (op->getName().getStringRef() + ":result:" +
                            llvm::Twine(index))
                               .str()));
        }
      } else if (auto ifOp = mlir::dyn_cast<mlir::scf::IfOp>(op)) {
        values.push_back(ifOp.getCondition());
        residualSources.push_back(
            mlir::StringAttr::get(ctx, "scf.if:predicate"));
      } else if (auto whileOp = mlir::dyn_cast<mlir::scf::WhileOp>(op)) {
        // Canonical bounded while result zero is the exact number of executed
        // body iterations.  Expose it rather than trusting backward replay to
        // rediscover a data-dependent path.
        values.push_back(whileOp.getResult(0));
        residualSources.push_back(
            mlir::StringAttr::get(ctx, "scf.while:trip_count"));
      }
      if (!values.empty()) {
        llvm::append_range(forwardResiduals, values);
        residualValues.try_emplace(op, std::move(values));
      }
    }

    if (!forwardResiduals.empty()) {
      llvm::SmallVector<mlir::Type> publicResultTypes(fwdResTypes);
      for (mlir::Value residual : forwardResiduals)
        publicResultTypes.push_back(residual.getType());
      fwd.setType(mlir::FunctionType::get(ctx, fwdInTypes, publicResultTypes));
      returnOp->insertOperands(returnOp.getNumOperands(), forwardResiduals);
    }

    llvm::SmallVector<mlir::Type> bwdInTypes(fwdInTypes);
    for (mlir::Type rt : fwdResTypes)
      bwdInTypes.push_back(rt);
    for (mlir::Value residual : forwardResiduals)
      bwdInTypes.push_back(residual.getType());
    // Input cotangents mirror the input types (one per forward argument).
    llvm::SmallVector<mlir::Type> bwdResTypes(fwdInTypes);

    mlir::OpBuilder builder(ctx);
    llvm::StringRef pairedResidualPolicy =
        forwardResiduals.empty()
            ? "recompute_all"
            : hasHybridResidual ? "hybrid" : "save";
    builder.setInsertionPointToEnd(module.getBody());
    auto bwdName = (fwd.getName() + "__bwd").str();
    // A module may already carry a partner for this function — written by
    // hand (the HVP rows) or by an earlier run of this pass on a module that
    // is being re-lowered. Pairing it again would emit a second definition
    // and MLIR would reject the module ("redefinition of symbol named
    // '<f>__bwd'"), so an existing partner is left alone (2026-09-16; before
    // this, a driver could only decide module-wide and a single unpaired
    // function dragged every paired one back through the pass).
    if (module.lookupSymbol<mlir::func::FuncOp>(bwdName))
      return mlir::success();
    auto bwdType = builder.getFunctionType(bwdInTypes, bwdResTypes);
    auto bwd = builder.create<mlir::func::FuncOp>(fwd.getLoc(), bwdName, bwdType);
    bwd->setAttr("tessera.autodiff.role", builder.getStringAttr("backward"));
    bwd->setAttr("tessera.autodiff.forward",
                 mlir::FlatSymbolRefAttr::get(ctx, fwd.getName()));
    bwd->setAttr("tessera.autodiff.residual_policy",
                 builder.getStringAttr(pairedResidualPolicy));
    if (!residualSources.empty())
      bwd->setAttr("tessera.autodiff.residual_sources",
                   builder.getArrayAttr(residualSources));

    mlir::Block *bwdBlock = bwd.addEntryBlock();
    builder.setInsertionPointToStart(bwdBlock);

    unsigned nIn = fwd.getNumArguments();
    unsigned nRes = fwdResTypes.size();

    // Map forward SSA values into the backward function: forward argument i →
    // backward argument i (the recompute-all residual = the forward inputs).
    mlir::IRMapping map;
    for (unsigned i = 0; i < nIn; ++i)
      map.map(fwd.getArgument(i), bwdBlock->getArgument(i));

    // Recompute the forward ops inside the backward body (clones), so each
    // adjoint's `getX()` resolves to a value that lives in this function.
    llvm::SmallVector<mlir::Operation *> clones;
    llvm::SmallPtrSet<mlir::Operation *, 8> inactiveScaledResiduals;
    auto requestedRoles = fwd->getAttrOfType<mlir::ArrayAttr>(
        "tessera.autodiff.wrt_indices");
    // Native scaled export has an explicit requested-gradient signature.
    // An encoded primal independent of those inputs remains a recomputed
    // coefficient; it does not owe an adjoint for its discrete code storage.
    llvm::DenseMap<mlir::Value, bool> requestedDependencyCache;
    std::function<bool(mlir::Value)> dependsOnRequested = [&](mlir::Value value) {
      auto cached = requestedDependencyCache.find(value);
      if (cached != requestedDependencyCache.end()) return cached->second;
      if (auto arg = mlir::dyn_cast<mlir::BlockArgument>(value)) {
        if (arg.getOwner() != &fwdBlock) return true; // region capture: conservative
        return llvm::any_of(requestedRoles, [&](mlir::Attribute role) {
          auto index = mlir::dyn_cast<mlir::IntegerAttr>(role);
          return !index || index.getInt() == arg.getArgNumber();
        });
      }
      auto *producer = value.getDefiningOp();
      if (!producer || producer->getNumRegions()) return true;
      bool dependent = llvm::any_of(producer->getOperands(), dependsOnRequested);
      requestedDependencyCache[value] = dependent;
      return dependent;
    };
    unsigned residualArgument = nIn + nRes;
    for (mlir::Operation *op : forwardOps) {
      // Recompute-all can preserve a stopped primal only when its operand is
      // already a backward argument.  Recomputing an inactive producer cone
      // here would be wrong for stateful or stochastic producers; a future
      // saved-residual policy can lift this restriction explicitly.
      if (op->getName().getStringRef() == "tessera.stop_gradient" &&
          !map.contains(op->getOperand(0))) {
        op->emitError()
            << "AUTODIFF_STOP_GRADIENT_RESIDUAL_REQUIRED: paired "
               "recompute-all cannot preserve a stopped intermediate; save "
               "the stopped primal as an explicit residual";
        return mlir::failure();
      }
      mlir::Operation *clone = builder.clone(*op, map);
      clones.push_back(clone);
      if (exportScaledTranspose && requestedRoles && !requestedRoles.empty() &&
          (mlir::isa<tessera::ScaledMatmulOp>(op) ||
           tessera::isNativeScaledWideningCast(op)) &&
          !llvm::any_of(op->getOperands(), dependsOnRequested))
        inactiveScaledResiduals.insert(clone);
      auto residualIt = residualValues.find(op);
      if (residualIt != residualValues.end()) {
        llvm::SmallVector<mlir::Value> values;
        for ([[maybe_unused]] mlir::Value residual : residualIt->second)
          values.push_back(bwdBlock->getArgument(residualArgument++));
        explicitRegionResiduals.try_emplace(clone, std::move(values));
      }
    }

    // Seed cotangents: forward result j ↦ backward out-cotangent argument
    // (nIn + j). The clone of the op producing that result carries the seed.
    CotangentMap cotan;
    for (unsigned j = 0; j < nRes; ++j) {
      mlir::Value fwdRes = returnOp.getOperand(j);
      mlir::Value cloneRes = map.lookupOrNull(fwdRes);
      if (!cloneRes) {
        // A forward result that is itself an argument (identity return): route
        // the cotangent straight to that input slot.
        if (auto ba = llvm::dyn_cast<mlir::BlockArgument>(fwdRes))
          accumulateCotangent(builder, cotan, bwdBlock->getArgument(ba.getArgNumber()),
                              bwdBlock->getArgument(nIn + j));
        continue;
      }
      accumulateCotangent(builder, cotan, cloneRes, bwdBlock->getArgument(nIn + j));
    }

    // Reverse walk the clones.
    for (auto it = clones.rbegin(); it != clones.rend(); ++it) {
      mlir::Operation *op = *it;
      llvm::SmallVector<mlir::Value> outCotans;
      bool any = false;
      for (mlir::Value r : op->getResults()) {
        mlir::Value c = cotan.lookup(r);
        outCotans.push_back(c);
        if (c)
          any = true;
      }
      if (!any) {
        if (op->use_empty() &&
            getRegisteredSemanticEffect(op) == SemanticEffectLevel::Pure)
          op->erase();
        continue;
      }

      auto residualOwner = op->getAttrOfType<mlir::StringAttr>(
          "tessera.autodiff.residual_owner");
      bool eraseSavedPrimal =
          explicitRegionResiduals.contains(op) && op->use_empty() &&
          residualOwner &&
          (residualOwner.getValue() == "scf_if" ||
           residualOwner.getValue() == "scf_while");
      if (!inactiveScaledResiduals.contains(op) &&
          failed(differentiateOperation(op, outCotans, builder, cotan)))
        return mlir::failure();
      // Re-check emptiness: differentiateOperation can create a use of this
      // clone that did not exist when the decision was latched. A dynamically
      // shaped state with no cotangent seed makes buildZeroLike emit a
      // zeros_like taking the clone's result, and erasing under that live use
      // is a dangling reference on the fleet's NDEBUG builds.
      if ((eraseSavedPrimal || op->getName().getStringRef() == "tessera.flash_attn") && op->use_empty())
        op->erase();
    }

    // Return input cotangents (zero-splat for inputs off the gradient path so
    // the signature is total and the buffer binding in Phase 4 is uniform).
    llvm::SmallVector<mlir::Value> results;
    for (unsigned i = 0; i < nIn; ++i) {
      mlir::Value g = cotan.lookup(bwdBlock->getArgument(i));
      if (!g) {
        mlir::Type ty = fwdInTypes[i];
        mlir::Value zero;
        if (auto shaped = llvm::dyn_cast<mlir::ShapedType>(ty)) {
          auto elem = shaped.getElementType();
          mlir::TypedAttr z =
              llvm::isa<mlir::FloatType>(elem)
                  ? (mlir::TypedAttr)mlir::FloatAttr::get(elem, 0.0)
                  : (mlir::TypedAttr)mlir::IntegerAttr::get(elem, 0);
          if (exportScaledTranspose && mlir::isa<mlir::IntegerType>(elem) &&
              !mlir::cast<mlir::IntegerType>(elem).isSignless()) {
            // arith.constant forbids signed/unsigned integer storage. These
            // inactive slots keep the paired signature total and are removed
            // by the checked requested-gradient native projection.
            mlir::OperationState state(fwd.getLoc(), "tessera.custom_adjoint_call");
            state.addOperands(bwdBlock->getArgument(i));
            state.addTypes(ty);
            state.addAttribute("name", builder.getStringAttr("zeros_like"));
            zero = builder.create(state)->getResult(0);
          } else if (shaped.hasStaticShape()) {
            zero = builder.create<mlir::arith::ConstantOp>(
                fwd.getLoc(), mlir::DenseElementsAttr::get(shaped, z));
          } else {
            // A dynamically shaped input still owes the caller a total
            // signature, but `DenseElementsAttr` cannot splat an unknown
            // extent -- asking it to is an assertion under an
            // assertions-enabled MLIR and undefined behavior under NDEBUG.
            // The backward function carries the primal in argument slot `i`,
            // so take the runtime extents from it rather than fabricating a
            // shape or silently dropping the result.
            auto ranked = llvm::dyn_cast<mlir::RankedTensorType>(shaped);
            if (!ranked) {
              fwd.emitError()
                  << "autodiff: cannot synthesize a zero cotangent for "
                     "unranked input "
                  << i << " of type " << ty;
              return mlir::failure();
            }
            mlir::Value primal = bwdBlock->getArgument(i);
            llvm::SmallVector<mlir::Value> dynamicSizes =
                getDynamicTensorSizes(builder, fwd.getLoc(), primal, ranked);
            // Carry the input's encoding onto the empty tensor. The backward
            // function still declares the original (possibly encoded) input
            // type as this slot's result, so an unencoded `tensor.empty` --
            // and the `linalg.fill` derived from it -- would make func.return
            // verification fail. The static-shape branch above preserves the
            // encoding implicitly through the full-typed DenseElementsAttr;
            // this overload defaults it to {}, so pass it explicitly.
            mlir::Value empty = mlir::tensor::EmptyOp::create(
                builder, fwd.getLoc(), ranked.getShape(),
                ranked.getElementType(), dynamicSizes, ranked.getEncoding());
            mlir::Value scalarZero =
                mlir::arith::ConstantOp::create(builder, fwd.getLoc(), z);
            zero = mlir::linalg::FillOp::create(builder, fwd.getLoc(),
                                                mlir::ValueRange{scalarZero},
                                                mlir::ValueRange{empty})
                       .getResult(0);
          }
        } else {
          zero = builder.create<mlir::arith::ConstantOp>(
              fwd.getLoc(), builder.getZeroAttr(ty));
        }
        g = zero;
      }
      results.push_back(g);
    }
    builder.create<mlir::func::ReturnOp>(fwd.getLoc(), results);

    // Link the forward to its paired backward (residuals empty under
    // recompute-all — the forward stays primals-only).
    fwd->setAttr("tessera.autodiff.paired",
                 mlir::FlatSymbolRefAttr::get(ctx, bwdName));
    fwd->setAttr("tessera.autodiff.residual_policy",
                 builder.getStringAttr(pairedResidualPolicy));
    if (!residualSources.empty())
      fwd->setAttr("tessera.autodiff.residual_sources",
                   builder.getArrayAttr(residualSources));
    // Replace forward primals only after building the derivative cone: its
    // original SSA values key activity and cotangent maps during construction.
    for (auto [original, saved] : attentionForwards) {
      for (unsigned i = 0; i < original->getNumResults(); ++i)
        original->getResult(i).replaceAllUsesWith(saved->getResult(i));
      original->erase();
    }
    eraseStopGradientBarriers(bwd);
    eraseStopGradientBarriers(fwd);
    return mlir::success();
  }

  mlir::Value buildZeroLike(mlir::OpBuilder &builder, mlir::Value primal) {
    mlir::Type type = primal.getType();
    mlir::Type elementType = mlir::getElementTypeOrSelf(type);
    mlir::TypedAttr zero = llvm::isa<mlir::FloatType>(elementType)
                               ? mlir::TypedAttr(
                                     mlir::FloatAttr::get(elementType, 0.0))
                               : mlir::TypedAttr(
                                     mlir::IntegerAttr::get(elementType, 0));
    if (auto shaped = llvm::dyn_cast<mlir::ShapedType>(type);
        shaped && shaped.hasStaticShape()) {
      return builder
          .create<mlir::arith::ConstantOp>(
              primal.getLoc(), mlir::DenseElementsAttr::get(shaped, zero))
          .getResult();
    }
    if (!llvm::isa<mlir::ShapedType>(type))
      return builder
          .create<mlir::arith::ConstantOp>(primal.getLoc(), zero)
          .getResult();

    mlir::OperationState state(primal.getLoc(),
                               "tessera.custom_adjoint_call");
    state.addOperands(primal);
    state.addTypes(type);
    state.addAttribute("name", builder.getStringAttr("zeros_like"));
    return builder.create(state)->getResult(0);
  }

  mlir::LogicalResult buildRegionPullback(
      mlir::Region &region, mlir::ValueRange outputCotangents,
      mlir::ValueRange blockArgumentValues,
      llvm::ArrayRef<mlir::Value> captures,
      const llvm::DenseMap<mlir::Value, mlir::Value> &savedValues,
      mlir::OpBuilder &builder,
      llvm::SmallVectorImpl<mlir::Value> &blockArgumentCotangents,
      llvm::SmallVectorImpl<mlir::Value> &captureCotangents) {
    if (!region.hasOneBlock() ||
        region.front().getNumArguments() != blockArgumentValues.size())
      return mlir::failure();
    auto yield = mlir::dyn_cast<mlir::scf::YieldOp>(
        region.front().getTerminator());
    if (!yield || yield->getNumOperands() != outputCotangents.size())
      return mlir::failure();

    mlir::IRMapping mapping;
    for (auto [argument, value] : llvm::zip_equal(
             region.front().getArguments(), blockArgumentValues))
      mapping.map(argument, value);
    for (mlir::Value capture : captures)
      mapping.map(capture, capture);
    // Pre-map saved branch-local SSA so downstream clones consume the residual
    // rather than the recomputed value.  We still create the defining clone so
    // its registered derivative model remains the source of the pullback; any
    // primal-result uses emitted by that model are redirected to the residual
    // below and the now-dead pure clone is erased.
    for (const auto &entry : savedValues)
      mapping.map(entry.first, entry.second);
    llvm::SmallVector<mlir::Operation *> clones;
    llvm::DenseMap<mlir::Value, mlir::Value> cloneResultToSaved;
    for (mlir::Operation &source : region.front().without_terminator()) {
      mlir::Operation *clone = builder.clone(source, mapping);
      clones.push_back(clone);
      for (auto [sourceResult, cloneResult] :
           llvm::zip_equal(source.getResults(), clone->getResults()))
        if (mlir::Value saved = savedValues.lookup(sourceResult)) {
          cloneResultToSaved.try_emplace(cloneResult, saved);
          mapping.map(sourceResult, saved);
        }
    }

    CotangentMap cotangents;
    for (auto [yielded, seed] :
         llvm::zip_equal(yield.getOperands(), outputCotangents))
      // Discrete loop/branch state needs replay storage, not a cotangent.
      // Generic region ABIs use typed zero placeholders for these positions.
      if (seed && mlir::isa<mlir::FloatType>(mlir::getElementTypeOrSelf(yielded.getType())))
        accumulateCotangent(builder, cotangents,
                            mapping.lookupOrDefault(yielded), seed);

    for (mlir::Operation *clone : llvm::reverse(clones)) {
      llvm::SmallVector<mlir::Value> resultCotangents;
      bool active = false;
      for (mlir::Value result : clone->getResults()) {
        mlir::Value key = cloneResultToSaved.lookup(result);
        mlir::Value cotangent = cotangents.lookup(key ? key : result);
        resultCotangents.push_back(cotangent);
        active |= static_cast<bool>(cotangent);
      }
      if (!active && clone->use_empty() &&
          getRegisteredSemanticEffect(clone) == SemanticEffectLevel::Pure) {
        clone->erase();
        continue;
      }
      if (active) {
        // Nested replay constructs its own residual results. Forward these to
        // the region model just as the top-level backward ABI forwards saved
        // residual arguments; the primal result alone is not a state tape.
        auto materialized = clone->getAttrOfType<mlir::BoolAttr>(
            "tessera.autodiff.residual_materialized");
        if (materialized && materialized.getValue()) {
          auto indices = clone->getAttrOfType<mlir::DenseI64ArrayAttr>(
              "tessera.autodiff.residual_result_indices");
          if (!indices || indices.empty())
            return mlir::failure();
          llvm::SmallVector<mlir::Value> residuals;
          if (auto ifOp = mlir::dyn_cast<mlir::scf::IfOp>(clone))
            residuals.push_back(ifOp.getCondition());
          else if (auto whileOp = mlir::dyn_cast<mlir::scf::WhileOp>(clone))
            residuals.push_back(whileOp.getResult(0));
          for (int64_t index : indices.asArrayRef()) {
            if (index < 0 || index >= clone->getNumResults())
              return mlir::failure();
            mlir::Value result = clone->getResult(index);
            mlir::Value saved = cloneResultToSaved.lookup(result);
            residuals.push_back(saved ? saved : result);
          }
          explicitRegionResiduals[clone] = std::move(residuals);
        }
        auto differentiated = differentiateOperation(
            clone, resultCotangents, builder, cotangents);
        explicitRegionResiduals.erase(clone);
        if (failed(differentiated))
          return mlir::failure();
      }
      bool allResultsSaved = clone->getNumResults() != 0;
      for (mlir::Value result : clone->getResults()) {
        mlir::Value saved = cloneResultToSaved.lookup(result);
        allResultsSaved &= static_cast<bool>(saved);
        if (saved)
          result.replaceAllUsesWith(saved);
      }
      if (allResultsSaved && clone->use_empty() &&
          getRegisteredSemanticEffect(clone) == SemanticEffectLevel::Pure)
        clone->erase();
    }

    for (auto [argument, value] : llvm::zip_equal(
             region.front().getArguments(), blockArgumentValues)) {
      if (!llvm::isa<mlir::FloatType>(
              mlir::getElementTypeOrSelf(argument.getType()))) {
        blockArgumentCotangents.push_back({});
        continue;
      }
      mlir::Value cotangent = cotangents.lookup(value);
      blockArgumentCotangents.push_back(
          cotangent ? cotangent : buildZeroLike(builder, value));
    }
    for (mlir::Value capture : captures) {
      mlir::Value cotangent = cotangents.lookup(capture);
      captureCotangents.push_back(cotangent ? cotangent
                                            : buildZeroLike(builder, capture));
    }
    return mlir::success();
  }

  mlir::LogicalResult differentiateOperation(
      mlir::Operation *op, mlir::ValueRange outputCotangents,
      mlir::OpBuilder &builder, CotangentMap &cotangents) {
    if (auto read = gatherRead(op)) {
      using namespace mlir;
      auto generate = cast<tensor::GenerateOp>(op);
      if (outputCotangents.size() != 1 || !outputCotangents.front()) return failure();
      Value seed = outputCotangents.front();
      auto loc = op->getLoc();
      auto type = cast<RankedTensorType>(generate.getType());
      SmallVector<Value> sizes, indices;
      unsigned dynamicIndex = 0;
      for (int64_t axis = 0; axis < type.getRank(); ++axis) {
        Value size = type.isDynamicDim(axis) ? generate.getDynamicExtents()[dynamicIndex++] :
            arith::ConstantIndexOp::create(builder, loc, type.getDimSize(axis)).getResult();
        sizes.push_back(size);
        Value actual = tensor::DimOp::create(builder, loc, seed, axis);
        Value equal = arith::CmpIOp::create(builder, loc, arith::CmpIPredicate::eq, actual, size);
        cf::AssertOp::create(builder, loc, equal, builder.getStringAttr("gather cotangent shape mismatch"));
      }
      Value zero = arith::ConstantIndexOp::create(builder, loc, 0);
      Value one = arith::ConstantIndexOp::create(builder, loc, 1);
      std::function<Value(unsigned, Value)> scatter = [&](unsigned axis, Value dest) -> Value {
        if (axis == sizes.size()) {
          IRMapping mapping;
          mapping.map(generate.getBody().front().getArguments(), indices);
          for (Operation &nested : generate.getBody().front().without_terminator()) {
            if (&nested == read.getOperation()) continue;
            builder.clone(nested, mapping);
          }
          SmallVector<Value> coordinates;
          for (Value index : read.getIndices()) coordinates.push_back(mapping.lookupOrDefault(index));
          Value old = tensor::ExtractOp::create(builder, loc, dest, coordinates);
          Value incoming = tensor::ExtractOp::create(builder, loc, seed, indices);
          Value sum = arith::AddFOp::create(builder, loc, old, incoming);
          return tensor::InsertOp::create(builder, loc, sum, dest, coordinates);
        }
        auto loop = scf::ForOp::create(builder, loc, zero, sizes[axis], one, ValueRange{dest});
        {
          OpBuilder::InsertionGuard guard(builder);
          builder.setInsertionPointToStart(loop.getBody());
          indices.push_back(loop.getInductionVar());
          Value updated = scatter(axis + 1, loop.getRegionIterArgs().front());
          indices.pop_back();
          scf::YieldOp::create(builder, loc, updated);
        }
        return loop.getResult(0);
      };
      Value result = scatter(0, buildZeroLike(builder, read.getTensor()));
      accumulateCotangent(builder, cotangents, read.getTensor(), result);
      return success();
    }
    if (op->getNumRegions() != 0) {
      if (!RegionAdjointInterface::supports(op) && !gatherRead(op)) {
        op->emitError() << "[AUTODIFF_NESTED_REGION] no registered "
                           "RegionAdjointInterface model for "
                        << op->getName();
        return mlir::failure();
      }
      llvm::SmallVector<RegionCotangent> regionCotangents;
      auto callback = [&](mlir::Region &region, mlir::ValueRange seeds,
                          mlir::ValueRange blockArgumentValues,
                          llvm::ArrayRef<mlir::Value> captures,
                          const llvm::DenseMap<mlir::Value, mlir::Value>
                              &savedValues,
                          mlir::OpBuilder &nestedBuilder,
                          llvm::SmallVectorImpl<mlir::Value> &blockResults,
                          llvm::SmallVectorImpl<mlir::Value> &results) {
        return buildRegionPullback(region, seeds, blockArgumentValues,
                                   captures, savedValues, nestedBuilder,
                                   blockResults,
                                   results);
      };
      mlir::ValueRange residuals;
      auto residualIt = explicitRegionResiduals.find(op);
      if (residualIt != explicitRegionResiduals.end())
        residuals = residualIt->second;
      if (failed(RegionAdjointInterface::buildAdjoint(
              op, builder, outputCotangents, residuals, callback,
              regionCotangents))) {
        op->emitError() << "[AUTODIFF_REGION_ADJOINT] structured pullback "
                           "construction failed";
        return mlir::failure();
      }
      for (const RegionCotangent &entry : regionCotangents)
        accumulateCotangent(builder, cotangents, entry.primal,
                            entry.cotangent);
      return mlir::success();
    }

    // These tensor slice operations are introduced by control_scan lowering.
    // Keep their linear transpose here instead of teaching the Tessera
    // operation interface about foreign-dialect operations.  extract_slice^T
    // scatters into a zero source; insert_slice^T gathers the overwritten
    // source region and masks that region out of the destination cotangent.
    if (auto extract = mlir::dyn_cast<mlir::tensor::ExtractSliceOp>(op)) {
      if (outputCotangents.size() != 1 || !outputCotangents.front())
        return mlir::failure();
      // Runtime cotangent descriptors must agree with the slice shape before
      // scattering. Matching dynamic tensor types do not prove equal extents.
      auto seedType = mlir::cast<mlir::RankedTensorType>(outputCotangents.front().getType());
      if (!seedType.hasStaticShape() && seedType.getRank() == extract.getSourceType().getRank()) {
        auto sizes = extract.getMixedSizes();
        for (int64_t i = 0; i < seedType.getRank(); ++i) {
          mlir::Value expected;
          if (auto value = mlir::dyn_cast<mlir::Value>(sizes[i])) expected = value;
          else expected = mlir::arith::ConstantIndexOp::create(builder, op->getLoc(),
              mlir::cast<mlir::IntegerAttr>(mlir::cast<mlir::Attribute>(sizes[i])).getInt());
          auto actual = mlir::tensor::DimOp::create(builder, op->getLoc(), outputCotangents.front(), i);
          auto equal = mlir::arith::CmpIOp::create(builder, op->getLoc(), mlir::arith::CmpIPredicate::eq, actual, expected);
          mlir::cf::AssertOp::create(builder, op->getLoc(), equal,
              builder.getStringAttr("slice cotangent shape mismatch"));
        }
      }
      mlir::Value sourceZero = buildZeroLike(builder, extract.getSource());
      mlir::Value sourceCotangent =
          mlir::tensor::InsertSliceOp::create(
              builder, op->getLoc(), outputCotangents.front(), sourceZero,
              extract.getMixedOffsets(), extract.getMixedSizes(),
              extract.getMixedStrides());
      accumulateCotangent(builder, cotangents, extract.getSource(),
                          sourceCotangent);
      return mlir::success();
    }
    if (auto insert = mlir::dyn_cast<mlir::tensor::InsertSliceOp>(op)) {
      if (outputCotangents.size() != 1 || !outputCotangents.front())
        return mlir::failure();
      mlir::Value sourceCotangent =
          mlir::tensor::ExtractSliceOp::create(
              builder, op->getLoc(), insert.getSourceType(),
              outputCotangents.front(), insert.getMixedOffsets(),
              insert.getMixedSizes(), insert.getMixedStrides());
      mlir::Value sourceZero = buildZeroLike(builder, insert.getSource());
      mlir::Value destinationCotangent =
          mlir::tensor::InsertSliceOp::create(
              builder, op->getLoc(), sourceZero, outputCotangents.front(),
              insert.getMixedOffsets(), insert.getMixedSizes(),
              insert.getMixedStrides());
      accumulateCotangent(builder, cotangents, insert.getSource(),
                          sourceCotangent);
      accumulateCotangent(builder, cotangents, insert.getDest(),
                          destinationCotangent);
      return mlir::success();
    }

    // tensor.empty carries allocation shape, not mathematical data.  Its
    // operands are index-valued extents and therefore have no cotangent.  The
    // contents become differentiable only after a subsequent insert/fill op;
    // treating the allocation itself as an unknown differentiable operation
    // incorrectly rejects dynamically shaped residual/state buffers.
    if (mlir::isa<mlir::tensor::EmptyOp>(op))
      return mlir::success();

    // The same reasoning, generalised: an op that neither consumes nor produces
    // a floating-point value is not a differentiable variable, so there is no
    // cotangent to propagate through it and nothing to refuse. Index and integer
    // arithmetic is how a shape-varying program carries its extents, and
    // demanding an adjoint for it rejected exactly those programs —
    // `arith.index_cast` on the extent of a dynamically shaped tape stopped
    // reverse mode with AUTODIFF_OP_NOT_DIFFERENTIABLE on every host that runs
    // the native x86 JIT (three tests, red on both Zen 5 boxes, and invisible to
    // CI, which has no such lane).
    //
    // Deliberately a property of the *types*, not a list of op names: a list
    // would have to grow every time a shape computation used one more integer
    // op, and each omission reads as "this op is not differentiable" when the
    // truth is that no gradient was ever flowing there.
    {
      // Complex counts. A first cut asked only `isa<FloatType>` and silently
      // skipped every `tensor<Nxcomplex<f32>>` FFT transpose — six oracle
      // comparisons, and the gradient was dropped rather than refused, which is
      // the failure this rule exists to avoid making.
      std::function<bool(mlir::Type)> carriesFloat = [&](mlir::Type type) -> bool {
        if (auto shaped = mlir::dyn_cast<mlir::ShapedType>(type))
          return carriesFloat(shaped.getElementType());
        if (auto complexTy = mlir::dyn_cast<mlir::ComplexType>(type))
          return carriesFloat(complexTy.getElementType());
        return mlir::isa<mlir::FloatType>(type);
      };
      const bool anyFloat =
          llvm::any_of(op->getOperandTypes(), carriesFloat) ||
          llvm::any_of(op->getResultTypes(), carriesFloat);
      if (!anyFloat) return mlir::success();
    }

    // `arith.select` is linear in its two value operands for a fixed condition,
    // which makes its transpose exact: the branch that was taken receives the
    // whole cotangent and the other receives zero. The condition is a predicate,
    // not a differentiable variable, so it receives none.
    //
    // This is a real gap rather than a missing declaration: `select` is how a
    // lowered program spells every branch — a recovered switch edge, a clamped
    // Huber kink, a masked manifold step — so reverse mode over any of them
    // stopped here. Implemented in this pass and not on the op, because the op
    // is upstream `arith` and there is no external-model registration in this
    // tree to hang an interface on.
    if (auto select = mlir::dyn_cast<mlir::arith::SelectOp>(op)) {
      if (outputCotangents.size() != 1 || !outputCotangents.front())
        return mlir::success();
      mlir::Value cotangent = outputCotangents.front();
      mlir::Value zero = buildZeroLike(builder, select.getTrueValue());
      mlir::Value trueCotangent = mlir::arith::SelectOp::create(
          builder, op->getLoc(), select.getCondition(), cotangent, zero);
      mlir::Value falseCotangent = mlir::arith::SelectOp::create(
          builder, op->getLoc(), select.getCondition(), zero, cotangent);
      accumulateCotangent(builder, cotangents, select.getTrueValue(),
                          trueCotangent);
      accumulateCotangent(builder, cotangents, select.getFalseValue(),
                          falseCotangent);
      return mlir::success();
    }

    llvm::SmallVector<mlir::Value> inputCotangents;
    auto savedAttention = explicitRegionResiduals.find(op);
    if (op->getName().getStringRef() == "tessera.flash_attn" &&
        savedAttention != explicitRegionResiduals.end()) {
      if (!denseAttentionAD(op, true, true, true, true) || savedAttention->second.size() != 2 ||
          outputCotangents.size() != op->getNumResults()) return mlir::failure();
      auto outputSeed = outputCotangents[0] ? outputCotangents[0] : buildZeroLike(builder, op->getResult(0));
      llvm::SmallVector<mlir::Value> args{outputSeed, op->getOperand(0),
          op->getOperand(1), op->getOperand(2), savedAttention->second[0],
          savedAttention->second[1]};
      if (op->getNumOperands() == 4) args.insert(args.end() - 1, op->getOperand(3));
      if (op->getNumResults() == 2)
        args.push_back(outputCotangents[1] ? outputCotangents[1] : buildZeroLike(builder, op->getResult(1)));
      auto backward = attentionCheckpoint(builder, op, true, args);
      if (!backward) return mlir::failure();
      llvm::append_range(inputCotangents, backward->getResults());
    } else if (auto adjoint = mlir::dyn_cast<AdjointInterface>(op)) {
      if (!adjoint.isDifferentiable()) {
        op->emitError() << "[AUTODIFF_PAIRED] op " << op->getName()
                        << " declares AdjointInterface but isDifferentiable() "
                           "is false";
        return mlir::failure();
      }
      inputCotangents = adjoint.buildAdjoint(builder, outputCotangents);
    } else if (auto linear =
                   mlir::dyn_cast<LinearTransposeInterface>(op)) {
      inputCotangents =
          linear.buildLinearTranspose(builder, outputCotangents);
      for (auto [index, cotangent] : llvm::enumerate(inputCotangents)) {
        if (cotangent && !linear.isLinearInOperand(index)) {
          op->emitError()
              << "[AUTODIFF_PAIRED] LinearTransposeInterface produced a "
                 "cotangent for non-linear operand "
              << index;
          return mlir::failure();
        }
      }
    } else {
      // W4 / queue order 2 — `tessera.control_scan` is the fourth control
      // primitive and the only one with no reverse rule. The generic message
      // above is true of it and unhelpful: it says an interface is missing
      // without saying that the interface is the WRONG HOME for this op.
      //
      // The mathematics is settled and was verified against central
      // differences (max abs error 4.7e-10 on a nonlinear body): for
      // (c_{t+1}, y_t) = body(c_t, x_t), the reverse recurrence is
      //
      //     (cbar_t, xbar_t) = body_vjp(c_t, x_t; cbar_{t+1}, ybar_t)
      //
      // run for t = T-1 .. 0 — so **the adjoint of a scan is a scan**, over
      // reversed t, carrying cbar and consuming (c_t, x_t, ybar_t).
      //
      // What blocks it is structural, not mathematical. Building that reverse
      // scan needs two things `AdjointInterface::buildAdjoint` may not create:
      // a companion function for the BODY's vjp (`@body__bwd`, which the
      // paired pass itself generates), and a residual tape of the
      // intermediate carries c_0..c_{T-1}, which the forward scan does not
      // stack. buildAdjoint receives only an OpBuilder positioned at the
      // forward op and is contractually limited to emitting ops. So scan's
      // reverse rule belongs beside the scf region handling in this pass,
      // where companion functions and residual policies already live — not on
      // the op interface. Saying that here is what stops the next reader
      // implementing it in the wrong place.
      if (op->getName().getStringRef() == "tessera.control_scan") {
        // `CODE: ` and not `[CODE] `: the registry's C++ scanner matches an
        // ALL_CAPS code followed by a colon inside a string literal, so the
        // bracketed spelling used by this file's UNREGISTERED codes would
        // leave a registered one invisible to the drift gate.
        auto diag = op->emitError(
            "AUTODIFF_CONTROL_SCAN_UNSUPPORTED: unnormalized "
            "tessera.control_scan is outside the bounded reverse envelope");
        diag.attachNote()
            << "The adjoint of a scan is a scan over reversed t, carrying the "
               "carry cotangent and consuming (carry_t, x_t, ybar_t). It "
               "needs the body's paired backward and a residual tape of the "
               "intermediate carries, which the forward scan does not stack — "
               "so it belongs in this pass beside the scf region handling, "
               "not in AdjointInterface::buildAdjoint, which may only emit "
               "ops at the forward site.";
        diag.attachNote()
            << "The carry tape is the SAVE/RECOMPUTE/HYBRID choice this pass "
               "already models for regions: T x |carry| saved, or the forward "
               "scan replayed.";
        return mlir::failure();
      }
      if (op->getNumOperands() > 0) {
        op->emitError() << "[AUTODIFF_OP_NOT_DIFFERENTIABLE] op "
                        << op->getName()
                        << " is on the gradient path but implements neither "
                           "AdjointInterface nor LinearTransposeInterface";
        return mlir::failure();
      }
      return mlir::success();
    }
    if (inputCotangents.size() != op->getNumOperands()) {
      op->emitError() << "[AUTODIFF_PAIRED] derivative interface returned "
                      << inputCotangents.size() << " cotangents, expected "
                      << op->getNumOperands();
      return mlir::failure();
    }
    for (auto [operand, cotangent] :
         llvm::zip_equal(op->getOperands(), inputCotangents))
      accumulateCotangent(builder, cotangents, operand, cotangent);
    return mlir::success();
  }
};

}  // namespace

std::unique_ptr<mlir::Pass> createAutodiffPairedPass() {
  return std::make_unique<AutodiffPairedPass>();
}

}  // namespace tessera
