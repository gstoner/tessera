"""Matched original frontend/native-owner A/B. Run without competing GPU jobs."""
import argparse
import ctypes as ct
import hashlib
import json
import os
from pathlib import Path
from statistics import median
import subprocess
import time

import ml_dtypes
import numpy as np
import tessera as ts
from tessera import runtime as rt
from tessera.compiler.prepared_attention_vjp import clear_prepared,prepared
from tests.device.nvidia.test_public_typed_attention_vjp import function
from tests.device.nvidia.test_saved_lse_half_backward_kernel import compare,reference


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    assert rt._nvidia_device_name()=="sm_120"
    gpu=subprocess.check_output(["/usr/lib/wsl/lib/nvidia-smi","--query-gpu=name,uuid,compute_cap,driver_version","--format=csv,noheader"],text=True).strip()
    root=Path(__import__("tessera.compiler.native_attention_rows",fromlist=["__file__"]).__file__).resolve().parents[3]
    paths=["python/tessera/compiler/"+name+".py" for name in ("native_attention_rows","native_attention_vjp_artifact","native_attention_program","native_attention_vjp_runtime","prepared_attention_vjp")]
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    source={name:sha(root/name) for name in paths}
    provider=Path(os.environ["TESSERA_NVIDIA_PTX_LAUNCH_LIB"]);provider_hash=sha(provider)
    rows=[]
    prior=os.environ.get("TESSERA_NVIDIA_ATTENTION_ROW_CORRECTION")
    try:
        for storage in ("float16","bfloat16"):
            dtype=np.dtype(np.float16 if storage=="float16" else ml_dtypes.bfloat16)
            for dims in ((1,2,1,3,5,4,3),(1,4,2,1,129,8,6),(1,4,2,7,129,8,6),(1,4,2,17,129,32,24)):
                b,hq,hkv,sq,sk,d,dv=dims;rng=np.random.default_rng(20261016)
                values={name:rng.normal(0,.3,shape).astype(dtype) for name,shape in {
                    "q":(b,hq,sq,d),"k":(b,hkv,sk,d),"v":(b,hkv,sk,dv)}.items()}
                values["bias"]=rng.normal(0,.1,(1,hq,1,sk)).astype(np.float32)
                do=rng.normal(0,.2,(b,hq,sq,dv)).astype(dtype)
                seed=rng.normal(0,.2,(b,hq,sq)).astype(np.float32)
                _,oracles=reference(values["q"],values["k"],values["v"],do,values["bias"],seed)
                expected=tuple(oracles[i] for i in (3,2,1,0))
                functions={};owners={};samples={"inline":[],"prepass":[]};proofs={};initial={}
                try:
                    for policy in ("inline","prepass"):
                        os.environ["TESSERA_NVIDIA_ATTENTION_ROW_CORRECTION"]=policy
                        fn=ts.jit(target="nvidia_sm120",autodiff="reverse",wrt=("bias","v","k","q"))(function(True,True))
                        functions[policy]=fn
                        first=fn.native_backward(**values,out_cotangents=(do,seed));initial[policy]=first
                        for actual,oracle in zip(first,expected,strict=True):compare(actual,oracle)
                        artifact=fn.native_backward_runtime_artifact();owner=prepared(artifact.metadata);owners[policy]=owner
                        window=owner._library().tessera_nvidia_attention_vjp_last_device_window
                        window.argtypes=[ct.c_uint64,ct.POINTER(ct.c_float)];window.restype=ct.c_int
                        program=owner.program;members=getattr(program,"members",(program.pair.forward,program.pair.backward))
                        proofs[policy]=dict(program_digest=artifact.metadata["program_digest"],artifact_hash=artifact.artifact_hash,
                            compiler_path=fn.last_backward_execution["compiler_path"],
                            source_graph_ir_digest=fn.last_backward_execution["source_graph_ir_digest"],
                            members=[dict(image_digest=x.image.image_digest,entry=x.descriptor.entry_symbol,
                                schedule_digest=x.descriptor.provenance["schedule_digest"],tile_ir_digest=x.descriptor.provenance["tile_ir_digest"]) for x in members])
                        for _ in range(3):fn.native_backward(**values,out_cotangents=(do,seed))
                    assert owners["inline"].program.pair.forward.image.payload==owners["prepass"].program.pair.forward.image.payload
                    for a,bvalue in zip(initial["inline"],initial["prepass"],strict=True):np.testing.assert_array_equal(a,bvalue)
                    for batch in range(8):
                        order=("inline","prepass") if batch%2==0 else ("prepass","inline")
                        for policy in order:
                            os.environ["TESSERA_NVIDIA_ATTENTION_ROW_CORRECTION"]=policy
                            fn=functions[policy];owner=owners[policy]
                            for rep in range(5):
                                start=time.perf_counter_ns()
                                outputs=fn.native_backward(**values,out_cotangents=(do,seed))
                                wall=(time.perf_counter_ns()-start)/1e6
                                native=ct.c_float()
                                assert owner._library().tessera_nvidia_attention_vjp_last_device_window(owner.handle,ct.byref(native))==0
                                times=owner.last_device_ms
                                stage=[times[0],0.,times[1]] if policy=="inline" else list(times[:3])
                                for actual,oracle in zip(outputs,expected,strict=True):compare(actual,oracle)
                                samples[policy].append(dict(batch=batch,rep=rep,order=list(order),
                                    public_completed_call_ms=wall,device_window_ms=native.value,
                                    forward_ms=stage[0],row_ms=stage[1],backward_ms=stage[2]))
                    medians={policy:{key:median(s[key] for s in arm) for key in (
                        "public_completed_call_ms","device_window_ms","forward_ms","row_ms","backward_ms")}
                        for policy,arm in samples.items()}
                    row=dict(storage=storage,shape=list(dims),dO_storage=storage,bias=True,lse_cotangent=True,
                        correctness="FP64 and bitwise arms before timing; FP64 outside every sample",proofs=proofs,
                        samples=samples,medians=medians,
                        public_ratio_inline_over_prepass=medians["inline"]["public_completed_call_ms"]/medians["prepass"]["public_completed_call_ms"],
                        device_ratio_inline_over_prepass=medians["inline"]["device_window_ms"]/medians["prepass"]["device_window_ms"])
                    rows.append(row)
                    print(storage,dims,row["device_ratio_inline_over_prepass"],row["public_ratio_inline_over_prepass"],flush=True)
                finally:
                    for fn in functions.values():fn.close_native_storage()
                    clear_prepared()
        assert source=={name:sha(root/name) for name in paths}
        assert provider_hash==sha(provider)
        packet=dict(schema="tessera.public_attention_row_program_ab.v1",device=gpu,
            source_commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),source_sha256=source,
            provider_path=str(provider),provider_sha256=provider_hash,
            methodology=dict(batches=8,reps=5,warmup=3,interleaving="AB/BA alternating batches",matched_values=True,
                shared_forward_ptx=True,timing_output="legacy two / prepass four floats enabled"),
            timing_domains=dict(public_completed_call_ms="original @jit native_backward, warm frontend/cached compiler/runtime dispatch/native snapshot/stages/readback/completion; cold compile, oracle checks and extra window query excluded",
                device_window_ms="same native CUDA event interval from forward start to backward stop, including native inter-stage gaps",
                stages="individual native CUDA event stage windows"),rows=rows)
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(packet,indent=2,allow_nan=False)+"\n")
    finally:
        if prior is None:os.environ.pop("TESSERA_NVIDIA_ATTENTION_ROW_CORRECTION",None)
        else:os.environ["TESSERA_NVIDIA_ATTENTION_ROW_CORRECTION"]=prior


if __name__=="__main__":main()
