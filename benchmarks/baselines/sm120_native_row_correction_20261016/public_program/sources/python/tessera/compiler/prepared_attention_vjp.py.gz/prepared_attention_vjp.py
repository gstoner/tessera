"""Native synchronous saved-LSE reverse owner, imported once per product pin."""
from __future__ import annotations

import ctypes as ct
from collections import OrderedDict
import os
import threading

_PROCESS = os.getpid()
_CACHE_LIMIT = 24
_cache: OrderedDict[tuple[threading.Thread, str, str], PreparedAttentionVJP] = OrderedDict()
_lock = threading.RLock()


class PreparedAttentionVJP:
    def __init__(self, metadata):
        from .native_attention_program import NativeAttentionVJPProgram
        from .typed_attention_backward import vjp_checkpoint_shapes as checkpoint_shapes
        self.identity = (metadata["program_digest"], metadata["program_json"])
        self.program = NativeAttentionVJPProgram.from_json(
            metadata["program_json"], expected_digest=metadata["program_digest"]
        )
        self.row_program=getattr(self.program,"row_program",False)
        if self.row_program:
            from .native_attention_rows import validate_program
            dims,physical=validate_program(self.program)
        else:
            dims, physical = checkpoint_shapes(self.program.pair)
        self.dims = dims
        b, hq, _, sq, sk, _, _ = dims
        provenance = self.program.pair.forward.descriptor.provenance
        self.bias_shape = (tuple(provenance.get("bias_shape", ())) or (b, hq, sq, sk)) if provenance.get("bias") else None
        physical_inputs = (*physical[:3], *((self.bias_shape,) if self.bias_shape else ()))
        frontend = [None] * len(physical_inputs)
        for role, index in enumerate(self.program.input_indices):
            frontend[index] = physical_inputs[role]
        import numpy as np
        self.storage = provenance["storage"]
        self.output_storage = provenance["output"]
        self.seeded = self.program.pair.backward.descriptor.provenance.get("lse_cotangent", False)
        types = {"f32": np.dtype("float32"), "f16": np.dtype("float16")}
        if "bf16" in (self.storage, self.output_storage):
            from ml_dtypes import bfloat16
            types["bf16"] = np.dtype(bfloat16)
        role_dtypes = (types[self.storage],)*3 + ((types["f32"],) if self.bias_shape else ())
        frontend_dtypes = [None]*len(frontend)
        for role, index in enumerate(self.program.input_indices):
            frontend_dtypes[index] = role_dtypes[role]
        self.dtypes = (*frontend_dtypes, types[self.output_storage], *((types["f32"],) if self.seeded else ()))
        self.names = tuple(f"primal_{i}" for i in range(len(frontend))) + ("cotangent",) + (("lse_cotangent",) if self.seeded else ())
        self.shapes = (*frontend, physical[3], *((physical[4],) if self.seeded else ()))
        self.output_shapes = tuple(physical_inputs[i] for i in self.program.active)
        self.output_dtypes = tuple(role_dtypes[i] for i in self.program.active)
        self.handle = 0
        self.closed = False
        self.pid = os.getpid()
        self.lock = threading.RLock()
        self.lib: ct.CDLL | None = None
        self.last_device_ms = None

    def _library(self) -> ct.CDLL:
        lib = self.lib
        if lib is None:
            raise RuntimeError("native prepared reverse runtime has not been initialized")
        return lib

    def _check(self, status):
        if status:
            reason = self._library().tessera_nvidia_attention_vjp_last_error()
            raise RuntimeError(reason.decode() if reason else "native prepared reverse failed")

    def _prepare(self):
        from tessera.runtime import _load_nvidia_ptx_launch
        lib = _load_nvidia_ptx_launch()
        if lib is None:
            raise RuntimeError("native PTX runtime unavailable")
        self.lib = lib
        P, S, I, U, L = ct.c_void_p, ct.c_size_t, ct.c_int, ct.c_uint64, ct.c_int64
        lib.tessera_nvidia_attention_vjp_prepare.argtypes = [
            P, S, ct.c_char_p, P, S, ct.c_char_p,
            ct.POINTER(L), ct.POINTER(L), ct.POINTER(I), ct.POINTER(I), S, ct.POINTER(U),
        ]
        lib.tessera_nvidia_attention_vjp_prepare.restype = I
        lib.tessera_nvidia_attention_vjp_invoke.argtypes = [
            U, ct.POINTER(P), ct.POINTER(S), S, ct.POINTER(P), ct.POINTER(S), S, ct.POINTER(ct.c_float),
        ]
        lib.tessera_nvidia_attention_vjp_invoke.restype = I
        lib.tessera_nvidia_attention_vjp_close.argtypes = [U]
        lib.tessera_nvidia_attention_vjp_close.restype = I
        lib.tessera_nvidia_attention_vjp_last_error.argtypes = []
        lib.tessera_nvidia_attention_vjp_last_error.restype = ct.c_char_p
        program = self.program
        if program.program_digest != self.identity[0]:
            raise ValueError("prepared reverse differs from pinned identity")
        forward, backward = program.pair.forward, program.pair.backward
        fimage = ct.create_string_buffer(forward.image.payload)
        bimage = ct.create_string_buffer(backward.image.payload)
        dims = (L * 7)(*self.dims)
        bias = (L * 4)(*self.bias_shape) if self.bias_shape else None
        mapping = (I * len(program.input_indices))(*program.input_indices)
        roles = (I * len(program.active))(*program.active)
        handle = U()
        arguments = (fimage, len(forward.image.payload), forward.descriptor.entry_symbol.encode(),
                     bimage, len(backward.image.payload), backward.descriptor.entry_symbol.encode(),
                     dims, bias, mapping, roles, len(program.active))
        if self.row_program:
            prepare=getattr(lib,"tessera_nvidia_attention_vjp_rows_prepare",None)
            if prepare is None:
                raise RuntimeError("row reverse requires the versioned native rows owner")
            correction=program.correction
            row_image=ct.create_string_buffer(correction.image.payload) if correction is not None else None
            row_arguments=(row_image,len(correction.image.payload),correction.descriptor.entry_symbol.encode()) if correction is not None else (None,0,None)
            prepare.argtypes=[P,S,ct.c_char_p]*3+[ct.POINTER(L),ct.POINTER(L),ct.POINTER(I),ct.POINTER(I),S,I,I,I,ct.POINTER(U)]
            prepare.restype=I
            codes={"f16":2,"bf16":3,"f32":1}
            status=prepare(*arguments[:6],*row_arguments,*arguments[6:],codes[self.storage],codes[self.output_storage],int(self.seeded),ct.byref(handle))
        elif self.storage != "f32" or self.seeded:
            prepare = getattr(lib, "tessera_nvidia_attention_vjp_prepare_typed", None)
            if prepare is None:
                raise RuntimeError("typed native reverse requires the versioned typed preparation symbol")
            prepare.argtypes = lib.tessera_nvidia_attention_vjp_prepare.argtypes[:-1] + [I, I, I, ct.POINTER(U)]
            prepare.restype = I
            codes = {"f32": 1, "f16": 2, "bf16": 3}
            status = prepare(*arguments, codes[self.storage], codes[self.output_storage], int(self.seeded), ct.byref(handle))
        else:
            status = lib.tessera_nvidia_attention_vjp_prepare(*arguments, ct.byref(handle))
        self._check(status)
        self.handle = handle.value

    def invoke(self, metadata, args):
        import numpy as np
        if self.pid != os.getpid():
            raise ValueError("prepared reverse cannot cross fork")
        with self.lock:
            if self.closed:
                raise ValueError("prepared reverse is closed")
            self.last_device_ms = None
            if (metadata["program_digest"], metadata["program_json"]) != self.identity:
                raise ValueError("prepared reverse differs from pinned identity")
            if tuple(metadata.get("arg_names", ())) != self.names or len(args) != len(self.shapes):
                raise ValueError("attention VJP launch names/arity differ from native contract")
            resident=any(hasattr(value,"__cuda_array_interface__") for value in args)
            if resident:
                from .resident_nvidia_tensor import cuda_frontend_specs
                if not all(hasattr(value,"__cuda_array_interface__") for value in args):
                    raise ValueError("attention VJP requires all resident roots or all host roots")
                specs=cuda_frontend_specs(args,ranks=(3,4))
                if any(dtype!=wanted or shape!=expected
                       for (shape,dtype),expected,wanted in zip(specs,self.shapes,self.dtypes,strict=True)):
                    raise ValueError("attention VJP resident storage differs from native contract")
                values=tuple(args)
            else:
                values = tuple(np.asarray(x) for x in args)
                if any(x.dtype != dtype or x.shape != shape
                       for x, shape, dtype in zip(values, self.shapes, self.dtypes, strict=True)):
                    raise ValueError("attention VJP host storage differs from native contract")
                values = tuple(np.ascontiguousarray(x) for x in values)
            if not self.handle:
                self._prepare()
            outputs = tuple(np.empty(shape, dtype) for shape, dtype in zip(self.output_shapes, self.output_dtypes, strict=True))
            if resident:
                import math
                interfaces=tuple(value.__cuda_array_interface__ for value in values)
                pointers=(ct.c_void_p*len(values))(*(item["data"][0] for item in interfaces))
                sizes=(ct.c_size_t*len(values))(*(math.prod(shape)*dtype.itemsize for shape,dtype in specs))
                streams=(ct.c_uint64*len(values))(*(item["stream"] for item in interfaces))
            else:
                pointers = (ct.c_void_p * len(values))(*(x.ctypes.data for x in values))
                sizes = (ct.c_size_t * len(values))(*(x.nbytes for x in values))
            destinations = (ct.c_void_p * len(outputs))(*(x.ctypes.data for x in outputs))
            lengths = (ct.c_size_t * len(outputs))(*(x.nbytes for x in outputs))
            times = (ct.c_float * (4 if self.row_program else 2))()
            if resident:
                try:
                    invoke=getattr(self._library(),"tessera_nvidia_attention_vjp_rows_invoke_resident_ordered" if self.row_program else "tessera_nvidia_attention_vjp_invoke_resident_ordered")
                except AttributeError as exc:
                    raise RuntimeError("native attention runtime lacks ordered resident VJP ABI") from exc
                invoke.argtypes=[ct.c_uint64,ct.POINTER(ct.c_void_p),ct.POINTER(ct.c_size_t),ct.c_size_t,
                                 ct.POINTER(ct.c_uint64),ct.c_size_t,ct.POINTER(ct.c_void_p),
                                 ct.POINTER(ct.c_size_t),ct.c_size_t,ct.POINTER(ct.c_float)]
                if self.row_program:invoke.argtypes+=[ct.c_size_t]
                invoke.restype=ct.c_int
                tail=(len(times),) if self.row_program else ()
                self._check(invoke(self.handle,pointers,sizes,len(values),streams,len(values),
                                   destinations,lengths,len(outputs),times,*tail))
            else:
                invoke=getattr(self._library(),"tessera_nvidia_attention_vjp_rows_invoke" if self.row_program else "tessera_nvidia_attention_vjp_invoke")
                if self.row_program:
                    invoke.argtypes=self._library().tessera_nvidia_attention_vjp_invoke.argtypes+[ct.c_size_t]
                    invoke.restype=ct.c_int
                tail=(len(times),) if self.row_program else ()
                self._check(invoke(self.handle,pointers,sizes,len(values),destinations,lengths,len(outputs),times,*tail))
            self.last_device_ms = tuple(times)
            return outputs

    def close(self):
        if self.pid != os.getpid():
            raise ValueError("prepared reverse cannot cross fork")
        with self.lock:
            if self.closed:
                return
            if self.handle:
                self._check(self._library().tessera_nvidia_attention_vjp_close(self.handle))
            self.handle = 0
            self.closed = True


def prepared(metadata):
    if os.getpid() != _PROCESS:
        raise ValueError("prepared reverse service cannot cross fork")
    key = (threading.current_thread(), metadata["program_digest"], metadata["program_json"])
    with _lock:
        owner = _cache.get(key)
        if owner is None or owner.closed:
            owner = PreparedAttentionVJP(metadata)
            _cache[key] = owner
        _cache.move_to_end(key)
        while len(_cache) > _CACHE_LIMIT:
            _, retired = _cache.popitem(last=False)
            retired.close()
        return owner


def clear_prepared():
    if os.getpid() != _PROCESS:
        raise ValueError("prepared reverse service cannot cross fork")
    with _lock:
        while _cache:
            _, owner = _cache.popitem()
            owner.close()


def execute(metadata, args):
    return prepared(metadata).invoke(metadata, args)


def _forget_inherited():
    global _cache, _lock
    _cache = OrderedDict()
    _lock = threading.RLock()


if hasattr(os, "register_at_fork"):
    os.register_at_fork(after_in_child=_forget_inherited)
