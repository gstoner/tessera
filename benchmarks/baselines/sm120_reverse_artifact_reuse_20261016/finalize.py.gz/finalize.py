"""Freeze completed gates without changing the measured production source."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

r=Path('/home/angstorms/scratch/sm120-relu-producer-20261014')
w=Path('/home/angstorms/scratch/sm120-reverse-artifact-reuse-20261016')
p=r/'benchmarks/baselines/sm120_reverse_artifact_reuse_20261016'

def xml_result(name):
    cases=list(ET.parse(w/(name+'.xml')).iter('testcase'))
    assert cases, name
    failures=[x.attrib for x in cases if x.find('failure') is not None or x.find('error') is not None]
    assert not failures,(name,failures[:3])
    skipped=[x for x in cases if x.find('skipped') is not None]
    return dict(cases=len(cases),passed=len(cases)-len(skipped),skipped=len(skipped),failures=0), cases

unit,_=xml_result('required-unit')
route,_=xml_result('compiler-route');assert route['passed']==1061 and not route['skipped']
primary,primary_cases=xml_result('device')
prepared,prepared_cases=xml_result('device-prepared');assert prepared['passed']==10 and not prepared['skipped']
key=lambda x:(x.attrib.get('classname'),x.attrib.get('name'))
initial_skipped={key(x) for x in primary_cases if x.find('skipped') is not None}
rerun_passed={key(x) for x in prepared_cases}
assert initial_skipped==rerun_passed,(initial_skipped,rerun_passed)
assert primary['passed']==174
witness=json.loads((w/'public-audit-witness.json').read_text())
assert len(witness['lanes'])==12 and all(x['returncode']==0 for x in witness['lanes']),witness
assert 'every selected proof test executed' in (w/'compiler-route.log').read_text()
assert 'Code graph updated.' in (w/'graph-update.log').read_text()
for frozen,current in [('candidate_adapter.py.gz','python/tessera/compiler/native_attention_vjp_runtime.py'),
                       ('recorder.py.gz','benchmarks/nvidia/benchmark_reverse_artifact_reuse.py'),
                       ('ownership_tests.py.gz','tests/unit/test_native_attention_vjp_artifact_reuse.py')]:
    assert gzip.decompress((p/frozen).read_bytes())==(r/current).read_bytes(),current
from benchmarks.nvidia.record_typed_attention_backward import source_snapshot
now=source_snapshot()
measured=json.loads(gzip.decompress((p/'adapter-ab.json.gz').read_bytes()))['source_before']
assert not now['status'], now['status']
assert now['tools']==measured['tools'] and now['source_tree']==measured['source_tree']
assert not subprocess.check_output(['git','diff',measured['commit'],'--','python/tessera','src'],text=True)
report=dict(measured_source=measured['commit'],gate_source_before_docs=witness['head'],
            source_after_gates=now,unit=unit,compiler_route=route,
            device_primary=primary,device_explicit_proof_switch_rerun=prepared,
            device_unique_passes=184,audits=witness,
            scope='Production adapter, recorder, ownership regressions and native src unchanged from measured c0e991af9e. Required unit invocation began at 61c9aa9ee5; only the E2E Latest documentation pointer changed to 2f4d8b4b4b while it ran. Final focused documentation gates cover that change. Interrupted broader unit run is not completion evidence.')
(p/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
for name in ('required-unit.log','required-unit.xml','compiler-route.log','compiler-route.xml',
             'device.log','device.xml','device-prepared.log','device-prepared.xml',
             'public-audit-witness.json','generated-write.log','graph-update.log','lint.log','typing-final.log'):
    (p/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
for row in witness['lanes']:
    name='public-audit-'+row['lane']+'.log'
    (p/(name+'.gz')).write_bytes(gzip.compress((w/name).read_bytes(),mtime=0))
readme=p/'README.md';s=readme.read_text()
s=s.replace('Owning-device public reverse and broader validation are recorded separately as\nthey complete; the benchmark alone does not close integration coverage.',
 f'''Owning-device validation executes 184 unique cases: 174 passed in the first
run; its ten explicit-proof-switch skips all pass in the targeted rerun with
TESSERA_NVIDIA_DEVICE_PROOF=1. No skipped case is counted as execution evidence.
This covers typed/F32 host/resident reverse, changed inputs, producer ordering,
retained outputs, native guards and serialized replay.

The required CI unit selector passes {unit['passed']:,} cases ({unit['skipped']:,} expected host-lane
skips). The production compiler-route lane passes 1,061 cases with zero skips,
and ci_require_executed passes. All twelve audit lanes, focused Ruff and zero-error
mypy gates pass. AST graph update completes without semantic API calls.
The initial broad unit invocation was deliberately interrupted and is excluded
from completion evidence. The initial audit pointer failure was corrected;
validation.json records source scope and the documentation-only continuation.
The benchmark and these bounded checks do not close the five-slice program.''')
readme.write_text(s)
path=r/'docs/audit/backend/nvidia/todo.md';s=path.read_text().replace(
 'RTX5070 warm public reverse has twelve same-image numerical/timing rows; broader\nowning-device integration validation is in progress. Native row-correction reuse\nand the wider five-slice program remain open.',
 f'''RTX5070 warm public reverse has twelve same-image numerical/timing rows and
184 unique owning-device cases passed across the primary run and explicit-switch
rerun. {unit['passed']:,} required unit cases and 1,061 zero-skip compiler-route cases
pass; all twelve audit lanes pass. Native row-correction reuse and the wider
five-slice program remain open.''')
path.write_text(s)
path=r/'docs/audit/compiler/INTEGRATED_COMPILER_LOG.md';s=path.read_text().replace(
 'Remaining: broader integration/CI gates and native row-correction producer reuse;',
 f'''Validation: 184 unique RTX5070 cases pass across primary and explicit-switch
rerun; {unit['passed']:,} required unit cases pass ({unit['skipped']:,} host-lane skips), 1,061
compiler-route cases pass with zero skips and all twelve audit lanes pass.
The measured production source is unchanged; validation.json retains scope.
Remaining: publication CI/review and native row-correction producer reuse;''')
path.write_text(s)
manifest=json.loads((p/'manifest.json').read_text())
manifest['sha256']={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(p.iterdir()) if q.name!='manifest.json'}
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(unit=unit,route=route,device_unique=184,audit_lanes=12),indent=2))
