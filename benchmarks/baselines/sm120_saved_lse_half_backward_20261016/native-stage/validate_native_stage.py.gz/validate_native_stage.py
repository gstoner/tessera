from pathlib import Path
import hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET
w=Path('/home/angstorms/scratch/sm120-attention-half-ad-20261016')
def snapshot():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'source_tree':subprocess.check_output(['git','rev-parse','HEAD:src'],text=True).strip(),
 'status':subprocess.check_output(['git','status','--porcelain'],text=True).splitlines(),
 'tools':{k:hashlib.sha256(Path(os.environ[k]).read_bytes()).hexdigest() for k in ('TESSERA_OPT','TESSERA_NVIDIA_OPT','TESSERA_NVIDIA_PTX_LAUNCH_LIB')},
 'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
before=snapshot();assert not before['status'],before['status']
probe=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,compute_cap','--format=csv,noheader'],text=True).strip()
assert 'RTX 5070' in probe and probe.split(',')[2].strip()=='12.0'
(w/'native-stage-before.json').write_text(json.dumps({'source':before,'device':probe},indent=2)+'\n')
lanes={
 'native-focused':['tests/unit/test_saved_lse_half_backward.py','tests/unit/test_saved_lse_storage_contract.py','tests/unit/test_native_attention_ad_products.py','tests/unit/test_saved_lse_storage_packet.py','tests/unit/test_diagnostic_code_registry.py','tests/unit/test_pass_metadata.py','tests/unit/test_operator_registry_foundation.py','tests/unit/test_tensor_attributes_dtype_audit.py','tests/unit/test_canonical_dtype.py','tests/unit/test_audit_docs.py'],
 'native-device':['tests/device/nvidia/test_saved_lse_half_backward_kernel.py','tests/device/nvidia/test_saved_lse_storage.py','tests/device/nvidia/test_lse_checkpoint_native.py']}
rows=[]
for name,files in lanes.items():
 command=[sys.executable,'-m','pytest',*files,'-q','--junitxml='+str(w/(name+'.xml'))]
 with (w/(name+'.log')).open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 cases=list(ET.parse(w/(name+'.xml')).iter('testcase'))
 row={'lane':name,'command':command,'returncode':result.returncode,'cases':len(cases),'skips':sum(x.find('skipped') is not None for x in cases),'failures':sum(x.find('failure') is not None or x.find('error') is not None for x in cases)}
 rows.append(row);print(json.dumps(row),flush=True)
 if result.returncode or row['failures'] or row['skips']:break
final=snapshot();(w/'native-stage-witness.json').write_text(json.dumps({'scope':'native compiler and direct kernel stage; public typed backward ABI/owner remains open','source_before':before,'source_after':final,'unchanged':before==final,'device':probe,'lanes':rows},indent=2)+'\n')
assert before==final
assert len(rows)==len(lanes) and all(x['returncode']==0 and x['failures']==0 and x['skips']==0 for x in rows)
