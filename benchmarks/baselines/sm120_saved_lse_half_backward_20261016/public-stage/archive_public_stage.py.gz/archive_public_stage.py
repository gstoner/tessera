from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
w=Path("/home/angstorms/scratch/sm120-attention-half-ad-20261016")
r=Path.cwd();dest=r/"benchmarks/baselines/sm120_saved_lse_half_backward_20261016/public-stage"
proof=json.loads((w/"public-stage-witness.json").read_text())
audit=json.loads((w/"public-audit-witness.json").read_text())
assert proof["unchanged"] and not proof["source_before"]["status"]
assert len(proof["lanes"])==6 and all(x["returncode"]==0 for x in proof["lanes"])
assert len(audit["lanes"])==12 and all(x["returncode"]==0 for x in audit["lanes"])
assert audit["head"]==proof["source_before"]["head"]
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==audit["head"]
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
dest.mkdir(parents=True,exist_ok=False)
shutil.copytree(w/"benchmark",dest/"benchmark")
files=["public-stage-before.json","public-stage-witness.json","public-audit-witness.json","validate_public_stage.py","validate_public_audit.py","archive_public_stage.py","public-freeze-gates.xml","public-freeze-gates.log","public-final-generated-docs.log","public-final-graphify.log"]
files += ["public-stage-phase1-witness.json", "resume_public_stage.py", "attempt2-public-audit-witness.json", "attempt2-public-audit-coverage-evidence.log", "public-graphify-result.json", "run_public_graph.py", "public-fixture-fix.xml", "public-fixture-fix.log", "public-fix-build.log", "public-fix-focused.xml", "public-fix-focused.log", "public-fix-typing.log", "public-fix-generated-docs.log", "public-fix-graphify.log", "optional-dependency-before.log", "provider-typed-build.log", "attempt1-public-audit-witness.json", "attempt1-public-audit-surface-benchmarks.log"]
files += [x["lane"]+".log" for x in proof["lanes"]]
files += [x["lane"]+".xml" for x in proof["lanes"] if "cases" in x]
files += ["public-audit-"+x["lane"]+".log" for x in audit["lanes"]]
for name in files:
 raw=(w/name).read_bytes();(dest/(name+".gz")).write_bytes(gzip.compress(raw,mtime=0))
sourcefiles=subprocess.check_output(["git","diff","--name-only","origin/main","HEAD","--","src","python","tests","benchmarks/nvidia/record_typed_attention_backward.py"],text=True).splitlines()
source={"commit":audit["head"],"files":{}}
for name in sourcefiles:
 raw=(r/name).read_bytes();sha=hashlib.sha256(raw).hexdigest()
 archive="source/"+sha+".gz";target=dest/archive;target.parent.mkdir(exist_ok=True)
 if not target.exists():target.write_bytes(gzip.compress(raw,mtime=0))
 source["files"][name]={"sha256":sha,"bytes":len(raw),"archive":archive}
(dest/"source-archive.json").write_text(json.dumps(source,indent=2)+"\n")
manifest={}
for path in sorted(dest.rglob("*")):
 if path.is_file():
  raw=path.read_bytes();entry={"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
  if path.suffix==".gz":
   original=gzip.decompress(raw);entry.update(decoded_sha256=hashlib.sha256(original).hexdigest(),decoded_bytes=len(original))
  manifest[str(path.relative_to(dest))]=entry
(dest/"compression-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({"files":len(manifest),"source_files":len(sourcefiles),"source":audit["head"]}))
