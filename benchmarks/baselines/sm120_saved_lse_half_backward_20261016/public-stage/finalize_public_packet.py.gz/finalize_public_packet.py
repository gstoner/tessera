from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,sys
w=Path("/home/angstorms/scratch/sm120-attention-half-ad-20261016")
r=Path.cwd()
proof=json.loads((w/"public-stage-witness.json").read_text())
audit=json.loads((w/"public-audit-witness.json").read_text())
assert proof["unchanged"] and not proof["source_before"]["status"]
assert len(proof["lanes"])==6 and all(x["returncode"]==0 for x in proof["lanes"])
assert len(audit["lanes"])==12 and all(x["returncode"]==0 for x in audit["lanes"])
assert proof["source_before"]["head"]==audit["head"]
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==audit["head"]
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
subprocess.run([sys.executable,str(w/"archive_public_stage.py")],check=True)
dest=r/"benchmarks/baselines/sm120_saved_lse_half_backward_20261016/public-stage"
shutil.copy2(w/"test_typed_attention_backward_packet.py",r/"tests/unit/test_typed_attention_backward_packet.py")
head=audit["head"];lanes={x["lane"]:x for x in proof["lanes"]}
u=lanes["public-final-unit"];c=lanes["public-final-compiler-route"];d=lanes["public-final-device"]
assert d["cases"]==339 and d["skips"]==d["failures"]==c["skips"]==c["failures"]==0
benchmark=json.loads((dest/"benchmark/index.json").read_text())
assert len(benchmark["rows"])==32 and not benchmark["diagnostic"]
assert benchmark["source_before"]==benchmark["source_after"]
assert benchmark["source_before"]["commit"]==head
assert len(json.loads((dest/"benchmark/fresh-replay.json").read_text())["rows"])==32
summary=(f"Frozen {head[:10]} passes {u['cases']-u['skips']:,} non-slow unit cases ({u['skips']:,} skipped), "
 f"{c['cases']:,} required production compiler-route cases and {d['cases']} owning RTX5070 cases. "
 "Both compiler-route and device proof lanes have zero skips/failures; source/tool/provider witnesses remain unchanged. "
 "All twelve audit lanes pass. Thirty-two matched stored-value characterization rows and thirty-two fresh compiler-absent portable replays pass numerical checks.")
rows=[]
for storage in ("f16","bf16","fp32_matched_quantized_control"):
 selected=[x for x in benchmark["rows"] if x["execution_storage"]==storage]
 def span(lane,metric):
  values=[x["lanes"][lane][metric+"_median_ms"] for x in selected]
  return f"{min(values):.4f}–{max(values):.4f}"
 error=max(v for x in selected for lane in x["lanes"].values() for v in lane["max_abs_error"].values())
 rows.append(f"| {storage} | {len(selected)} | {span('host','public_completed_call')} | {span('resident','public_completed_call')} | {span('resident','native_forward_event')} | {span('resident','native_backward_event')} | {error:.3g} |")
text=(w/"public-stage-README-draft.md").read_text()
start=text.index("This packet must be populated")
end=text.index("## Contract",start)
text=text[:start]+summary+"\n\nThe source archive preserves measured bytes independently of future checkout edits. The earlier native-stage packet retains its separate9b2159e655 compiler/kernel scope. Required CI/review and publication remain pending.\n\n"+text[end:]
text=text.replace("Insert final counts only from final raw JUnit and witnesses, not from separate\npre-freeze partial runs. Retain the optional-dependency counterexample and its", "Counts above come from the final raw JUnit and witnesses. The packet retains the optional-dependency counterexample and its")
text=text.replace("Fill final source-bound timing ranges and numerical errors from the new packet.\nThe earlier95986 characterization found costly typed row correction; retain\nthat obligation if confirmed. Investigate native shared per-row correction\nrather than sacrificing precision or reconstructing arithmetic in Python.", """All ranges below are milliseconds across individual profile medians. They are not pooled distributions, paired causal speedups or kernel-only timings.

| Storage | Rows | Host public call | Resident public call | Resident forward event | Resident backward event | Maximum absolute error |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
"""+"\n".join(rows)+"\n\nTyped row correction remains a native optimization obligation. The source-attribution record identifies repeated per-output rowStats work; its reuse multiplicities are not hardware counts or expected speedups. A shared native per-row producer remains a design candidate requiring numerical and interleaved timing proof.\n")
(dest/"README.md").write_text(text)
root_index=dest.parent/"README.md"
root_index.write_text("# SM120 typed saved-LSE reverse — 2026-10-16\n\nOwner: E2E-REAL-6 / FRONTEND-IR-MEDIUM-1 / AD-RESIDUAL-EVAL-1.\nSync: SM120-SAVED-LSE-HALF-BACKWARD-20261016.\n\n[Native compiler/kernel stage](native-stage/README.md) freezes 9b2159e655 with 639 focused and 167 owning cases. That direct-driver stage retains its own source scope.\n\n[Frozen public owner proof](public-stage/README.md): "+summary+"\n\nStatic half reverse uses typed Graph/AD/Schedule/Tile/NVIDIA/LLVM-PTX, checked native ownership, FP32 correction and VJP v2. Half capture/JVP/dynamic/composed/storage/mask and performance envelopes remain open. Required CI/review and publication are pending; no aggregate five-slice closure is claimed.\n")
for name in ("row-correction-source-attribution.json","row-correction-native-prepass-design.md"):
 shutil.copy2(w/name,dest/name)
(dest/"finalize_public_packet.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
manifest=json.loads((dest/"compression-manifest.json").read_text())
for path in (dest/"README.md",dest/"row-correction-source-attribution.json",dest/"row-correction-native-prepass-design.md",dest/"finalize_public_packet.py.gz"):
 raw=path.read_bytes();entry=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
 if path.suffix==".gz":
  decoded=gzip.decompress(raw);entry.update(decoded_sha256=hashlib.sha256(decoded).hexdigest(),decoded_bytes=len(decoded))
 manifest[str(path.relative_to(dest))]=entry
(dest/"compression-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
common=("## SM120-SAVED-LSE-HALF-BACKWARD-20261016 — typed public reverse owner\n\n"
 "Owner: E2E-REAL-6 / FRONTEND-IR-MEDIUM-1 / AD-RESIDUAL-EVAL-1.\n"
 "Synchronization key: SM120-SAVED-LSE-HALF-BACKWARD-20261016.\n\n"+summary+"\n\n"
 "Original half Graph -> native reverse AD -> checkpoint Schedule/Tile -> NVIDIA/LLVM-PTX now executes through the checked static public owner. Per-role dtype/width, producer streams, snapshots, output generations and requested subsets are checked. Half VJP v2 is additive; FP32 v1 and JVP5/6 meanings are unchanged. FP32 probability-based correction preserves the numerical contract independently of rounded half O. Optional ml_dtypes is required only for BF16 roles; precise bias-gradient storage refusal is restored.\n\n"
 "Evidence: benchmarks/baselines/sm120_saved_lse_half_backward_20261016/public-stage/README.md. Earlier9b2159e655 native-stage receipts keep their original scope. CI/review and publication remain pending.\n\n")
for backend in ("apple","nvidia","rocm","x86"):
 p=r/f"docs/audit/backend/{backend}/todo.md";t=p.read_text();start=t.index("## SM120-SAVED-LSE-HALF-BACKWARD-20261016")
 end=t.find("\n## ",start+4);assert end>start
 if backend=="nvidia":
  outcome="Parity validated for static typed public reverse on RTX5070. Half explicit GPU-generation capture, dynamic/composed public reverse, half JVP, mixed/pitched storage, resident results and wider masks remain follow-ups. Typed row-correction performance requires a native producer/consumer optimization loop. No overall five-slice closure or default schedule promotion is claimed."
 else:
  outcome=f"Follow-up required for {backend} physical integration: half reverse admission remains SM120-specific, and the typed CUDA owner does not implement this backend. Its existing storage/runtime consumers and physical schedules are unchanged. No NVIDIA execution or timing evidence transfers to {backend}."
 p.write_text(t[:start]+common+outcome+"\n\n"+t[end:])
p=r/"docs/audit/compiler/FIVE_SLICE_STATUS_20261007.md";t=p.read_text();start=t.index("## Typed native/public reverse candidate")
end=t.index("\n## Native saved-LSE storage integration",start)
t=t[:start]+"## Static typed public reverse proof — 2026-10-16\n\n"+summary+"\n\n"+"Original half Graph"+common.split("Original half Graph",1)[1]+"\nThe frozen half public owner extends the static ordinary reverse envelope. Half capture generations, dynamic/composed public reverse, half JVP, mixed/pitched roots, resident results and wider masks/performance remain open. All five aggregate requirement rows remain open.\n"+t[end:]
rows=t.splitlines()
in_current=False
for i,line in enumerate(rows):
 if line.startswith("The original five requirements remain open as an aggregate."):in_current=True
 if line.startswith("The historical red full-unit"):in_current=False
 if not in_current:continue
 if line.startswith("| NVIDIA saved-LSE forward |"):
  rows[i]=line.replace("and half-storage AD.","and half JVP/capture/dynamic AD.")
 if line.startswith("| NVIDIA attention backward |"):
  cells=line.split("|")
  cells[2]+=" Static typed/F32 public owner, binding and textual cases add 172 checks within 339 combined owning-device cases; see sm120_saved_lse_half_backward_20261016/public-stage. "
  cells[3]+=" Half GPU-generation capture and typed dynamic public reverse remain open. "
  rows[i]="|".join(cells)
p.write_text("\n".join(rows)+"\n")
p=r/"docs/spec/SM120_TYPED_ATTENTION_BACKWARD_CONTRACT.md";t=p.read_text()
t=t.replace("Status: static typed public owner candidate; final validation and publication remain open.","Status: static typed public owner has frozen validation; required CI/review and publication remain pending.")
t=t.replace("compact host roots or all-CUDA\nroots", "compact host roots or CUDA Array Interface\nroots")
t=t.replace("Final source-bound receipts remain active.",summary+" Evidence: benchmarks/baselines/sm120_saved_lse_half_backward_20261016/public-stage/README.md.")
t=t.replace("Final isolated measurements, full unit/compiler-route gates and CI/\nreview are still required before publication.","Frozen isolated measurements, full unit/compiler-route and audit gates are recorded. Required CI/review and publication remain pending.")
p.write_text(t)
p=r/"docs/audit/compiler/INTEGRATED_COMPILER_LOG.md";t=p.read_text()
old="Public candidate checks passed 96 half, 48 FP32 compatibility, twelve rejection/recovery and sixteen textual FP32-primary cases; final clean-source timing and broad gates remain pending."
assert old in t;t=t.replace(old,summary,1)
t=t.replace("Finish isolated matched-input timing, fresh compiler-absent replay and final validation before publishing.","Required CI/review and publication remain pending; native row-correction reuse remains an independent optimization obligation.",1)
p.write_text(t)
print(summary)
