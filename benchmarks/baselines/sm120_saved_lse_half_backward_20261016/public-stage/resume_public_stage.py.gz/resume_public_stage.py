from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
w=Path("/home/angstorms/scratch/sm120-attention-half-ad-20261016")
prior_bytes=(w/"public-stage-phase1-witness.json").read_bytes()
prior=json.loads(prior_bytes)
def snapshot():
 return {"head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"source_tree":subprocess.check_output(["git","rev-parse","HEAD:src"],text=True).strip(),"status":subprocess.check_output(["git","status","--porcelain"],text=True).splitlines(),"tools":{k:hashlib.sha256(Path(os.environ[k]).read_bytes()).hexdigest() for k in ("TESSERA_OPT","TESSERA_NVIDIA_OPT","TESSERA_NVIDIA_PTX_LAUNCH_LIB")},"runner_sha256":hashlib.sha256((w/"validate_public_stage.py").read_bytes()).hexdigest()}
before=snapshot();assert prior["unchanged"] and prior["source_before"]==prior["source_after"]==before
assert len(prior["lanes"])==3 and all(x["returncode"]==0 for x in prior["lanes"])
helper_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
rows=[dict(x,executing_helper="validate_public_stage.py",helper_sha256=before["runner_sha256"]) for x in prior["lanes"]]
new=[]
def lane(name,command,env=None,junit=False):
 started=time.time();print("Starting "+name,flush=True)
 with (w/(name+".log")).open("w") as out:
  result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,env=env)
 row=dict(lane=name,command=command,returncode=result.returncode,elapsed_seconds=time.time()-started,executing_helper="resume_public_stage.py",helper_sha256=helper_sha)
 if junit:
  cases=list(ET.parse(w/(name+".xml")).iter("testcase"))
  row.update(cases=len(cases),skips=sum(x.find("skipped") is not None for x in cases),failures=sum(x.find("failure") is not None or x.find("error") is not None for x in cases))
 rows.append(row);new.append(name);print(json.dumps(row),flush=True)
 assert result.returncode==0 and row.get("skips",0)==row.get("failures",0)==0,row
try:
 subprocess.run([sys.executable,str(w/"validate_public_audit.py"),"--resume"],check=True)
 graph=json.loads((w/"public-graphify-result.json").read_text());assert graph["returncode"]==0 and graph["head_before"]==graph["head_after"]==before["head"]
 lane("public-benchmark",[sys.executable,"-m","benchmarks.nvidia.record_typed_attention_backward","--output",str(w/"benchmark")])
 doc=json.loads((w/"benchmark/index.json").read_text());assert len(doc["rows"])==32 and not doc["diagnostic"]
 env=os.environ.copy();env.update(TESSERA_OPT="/missing/typed-proof/tessera-opt",TESSERA_NVIDIA_OPT="/missing/typed-proof/tessera-nvidia-opt")
 lane("public-fresh-replay",[sys.executable,"-m","benchmarks.nvidia.record_typed_attention_backward","--replay",str(w/"benchmark/index.json")],env=env)
 files=["tests/device/nvidia/test_public_typed_attention_vjp.py","tests/device/nvidia/test_saved_lse_half_backward_kernel.py","tests/device/nvidia/test_saved_lse_storage.py","tests/device/nvidia/test_lse_checkpoint_native.py"]
 lane("public-final-device",[sys.executable,"-m","pytest",*files,"-q","--junitxml="+str(w/"public-final-device.xml")],junit=True)
finally:
 after=snapshot()
 witness=dict(prior,source_after=after,unchanged=before==after,lanes=rows,continuations=[dict(source_before=before,source_after=after,executing_helper="resume_public_stage.py",helper_sha256=helper_sha,prior_witness_sha256=hashlib.sha256(prior_bytes).hexdigest(),prior_lanes=[x["lane"] for x in prior["lanes"]],new_lanes=new)])
 (w/"public-stage-witness.json").write_text(json.dumps(witness,indent=2)+"\n")
 assert before==after
