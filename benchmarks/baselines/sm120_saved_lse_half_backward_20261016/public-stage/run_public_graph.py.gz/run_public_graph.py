from pathlib import Path
import json,subprocess
w=Path("/home/angstorms/scratch/sm120-attention-half-ad-20261016")
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
with (w/"public-final-graphify.log").open("w") as out:
 result=subprocess.run(["graphify","update","."],stdout=out,stderr=subprocess.STDOUT)
after=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
(w/"public-graphify-result.json").write_text(json.dumps(dict(head_before=head,head_after=after,returncode=result.returncode),indent=2)+"\n")
assert result.returncode==0 and head==after
