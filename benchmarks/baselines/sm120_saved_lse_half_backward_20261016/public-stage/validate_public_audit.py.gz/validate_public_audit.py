from pathlib import Path
import json,os,subprocess,sys,time
w=Path("/home/angstorms/scratch/sm120-attention-half-ad-20261016")
commands=[("lint",[sys.executable,"-m","ruff","check","python/tessera/"]),
 ("typing",["bash","scripts/mypy_ratchet.sh"]),
 ("plan",[sys.executable,"scripts/check_compiler_plan.py","--base","origin/main"]),
 ("generated-drift",["bash","scripts/check_generated_docs.sh"]),
 ("coverage-evidence",[sys.executable,"scripts/coverage_evidence.py","--output",str(w/"coverage-evidence")]),
 ("public-claims",[sys.executable,"-m","tessera.compiler.audit","claim_lint"])]
commands += [("surface-"+s,[sys.executable,"-m","tessera.cli.surface_audit","--surface="+s,"--check"]) for s in ("examples","benchmarks","research","tools","tests")]
commands += [("surface-claims",[sys.executable,"-m","tessera.cli.claim_lint","--check"])]
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
env=os.environ.copy();env["MYPY"]=sys.executable+" -m mypy"
rows=[]
if "--resume" in sys.argv:
 previous=json.loads((w/"public-audit-witness.json").read_text())
 assert previous["head"]==head
 rows=[row for row in previous["lanes"] if row["returncode"]==0]
 completed={row["lane"] for row in rows}
 commands=[pair for pair in commands if pair[0] not in completed]
for name,command in commands:
 started=time.time();print("Starting audit "+name,flush=True)
 with (w/("public-audit-"+name+".log")).open("w") as out:
  r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,env=env)
 row=dict(lane=name,command=command,returncode=r.returncode,elapsed_seconds=time.time()-started)
 rows.append(row);print(json.dumps(row),flush=True)
 (w/"public-audit-witness.json").write_text(json.dumps(dict(head=head,lanes=rows),indent=2)+"\n")
 if r.returncode:raise RuntimeError("audit failed: "+name)
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==head
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
