from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
w=Path("/home/angstorms/scratch/sm120-attention-half-ad-20261016")
def snapshot():
 return {"head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"source_tree":subprocess.check_output(["git","rev-parse","HEAD:src"],text=True).strip(),"status":subprocess.check_output(["git","status","--porcelain"],text=True).splitlines(),"tools":{k:hashlib.sha256(Path(os.environ[k]).read_bytes()).hexdigest() for k in ("TESSERA_OPT","TESSERA_NVIDIA_OPT","TESSERA_NVIDIA_PTX_LAUNCH_LIB")},"runner_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
before=snapshot();assert not before["status"],before
probe=subprocess.check_output(["nvidia-smi","--query-gpu=name,uuid,compute_cap,driver_version","--format=csv,noheader"],text=True).strip()
assert "RTX 5070" in probe and probe.split(",")[2].strip()=="12.0",probe
(w/"public-stage-before.json").write_text(json.dumps({"source":before,"device":probe},indent=2)+"\n")
rows=[]
def lane(name,command,env=None,junit=False,zero_skips=False):
 started=time.time();print("Starting "+name,flush=True)
 with (w/(name+".log")).open("w") as out:
  result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,env=env)
 row={"lane":name,"command":command,"returncode":result.returncode,"elapsed_seconds":time.time()-started}
 if junit and (w/(name+".xml")).exists():
  cases=list(ET.parse(w/(name+".xml")).iter("testcase"))
  row.update(cases=len(cases),skips=sum(x.find("skipped") is not None for x in cases),failures=sum(x.find("failure") is not None or x.find("error") is not None for x in cases))
 rows.append(row);print(json.dumps(row),flush=True)
 if result.returncode or row.get("failures",0) or (zero_skips and row.get("skips",0)):
  raise RuntimeError("validation lane failed: "+name)
try:
 selectors={"public-final-unit":"not slow and not performance and not compiler_route and not hardware_apple_gpu and not hardware_nvidia and not hardware_rocm and not hardware_amx and not hardware_avx512","public-final-compiler-route":"compiler_route and not hardware_apple_gpu and not hardware_nvidia and not hardware_rocm and not hardware_amx and not hardware_avx512"}
 for name,selection in selectors.items():
  lane(name,[sys.executable,"-m","pytest","tests/unit","-q","-m",selection,"-n","4","--timeout=180","--junitxml="+str(w/(name+".xml"))],junit=True,zero_skips="compiler-route" in name)
 lane("public-route-executed",[sys.executable,"scripts/ci_require_executed.py",str(w/"public-final-compiler-route.xml")])
 subprocess.run([sys.executable,str(w/"validate_public_audit.py")],check=True)
 graph=json.loads((w/"public-graphify-result.json").read_text())
 assert graph["returncode"]==0 and graph["head_before"]==graph["head_after"]==before["head"]
 lane("public-benchmark",[sys.executable,"-m","benchmarks.nvidia.record_typed_attention_backward","--output",str(w/"benchmark")])
 doc=json.loads((w/"benchmark/index.json").read_text());assert len(doc["rows"])==32 and not doc["diagnostic"]
 replay_env=os.environ.copy();replay_env.update(TESSERA_OPT="/missing/typed-proof/tessera-opt",TESSERA_NVIDIA_OPT="/missing/typed-proof/tessera-nvidia-opt")
 lane("public-fresh-replay",[sys.executable,"-m","benchmarks.nvidia.record_typed_attention_backward","--replay",str(w/"benchmark/index.json")],env=replay_env)
 files=["tests/device/nvidia/test_public_typed_attention_vjp.py","tests/device/nvidia/test_saved_lse_half_backward_kernel.py","tests/device/nvidia/test_saved_lse_storage.py","tests/device/nvidia/test_lse_checkpoint_native.py"]
 lane("public-final-device",[sys.executable,"-m","pytest",*files,"-q","--junitxml="+str(w/"public-final-device.xml")],junit=True,zero_skips=True)
finally:
 after=snapshot()
 (w/"public-stage-witness.json").write_text(json.dumps({"scope":"static typed public reverse owner; broader five-slice goal remains open","source_before":before,"source_after":after,"unchanged":before==after,"device":probe,"lanes":rows},indent=2)+"\n")
 assert before==after,(before,after)
