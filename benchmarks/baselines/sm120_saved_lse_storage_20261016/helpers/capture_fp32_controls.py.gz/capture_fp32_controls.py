"""Capture FP32 control images and numerical receipts before/after storage changes."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import subprocess

import numpy as np
import tessera as ts
from tests.device.nvidia.test_saved_lse_storage import (
    saved, saved_open, saved_bias, saved_bias_open, reference, compare)
from tessera import runtime as rt

parser=argparse.ArgumentParser()
parser.add_argument("--output",type=Path,required=True)
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def source():
 return {"commit":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
  "status":subprocess.check_output(["git","status","--porcelain"],text=True).splitlines(),
  "src_tree":subprocess.check_output(["git","rev-parse","HEAD:src"],text=True).strip(),
  "tools":{name:sha(Path(os.environ[name]).read_bytes()) for name in (
    "TESSERA_OPT","TESSERA_NVIDIA_OPT","TESSERA_NVIDIA_PTX_LAUNCH_LIB")},
  "helper_sha256":sha(Path(__file__).read_bytes())}
before=source()
assert not before["status"]
assert rt._nvidia_device_name()=="sm_120"
probe=subprocess.check_output(["/usr/lib/wsl/lib/nvidia-smi",
 "--query-gpu=name,uuid,compute_cap","--format=csv,noheader"],text=True).strip()
rows=[]
for causal in (False,True):
 for bias in ("none","broadcast","dense"):
  for sk in (5,129):
   rng=np.random.default_rng(20261016)
   values={name:rng.normal(0,.2,shape).astype(np.float32) for name,shape in {
     "q":(1,2,3,4),"k":(1,1,sk,4),"v":(1,1,sk,3)}.items()}
   if bias!="none":
    shape=(1,2,1,1) if bias=="broadcast" else (1,2,3,sk)
    values["bias"]=rng.normal(0,.1,shape).astype(np.float32)
   function=(saved_bias if causal else saved_bias_open) if bias!="none" else (
     saved if causal else saved_open)
   fn=ts.jit(target="nvidia_sm120")(function)
   try:
    pair=fn(**values)
    assert fn._native_prepared_attention_calls
    expected=reference(values,causal)
    compare(pair,expected,np.dtype("float32"))
    owner=next(iter(fn._native_prepared_attention_calls.values()))
    artifact=owner.artifact
    label=f"c{int(causal)}-{bias}-sk{sk}"
    raw=artifact.to_json().encode()
    (args.output/(label+".json.gz")).write_bytes(gzip.compress(raw,mtime=0))
    rows.append({"case":label,"artifact":label+".json.gz","artifact_hash":artifact.artifact_hash,
     "entry":artifact.launch_descriptor.entry_symbol,"abi":artifact.launch_descriptor.abi_id,
     "tile_sha256":sha(artifact.tile_ir.encode()),"target_sha256":sha(artifact.target_ir.encode()),
     "ptx_sha256":sha(artifact.native_image.payload),
     "max_abs_error":[float(np.max(np.abs(a.astype(np.float64)-e)))
                      for a,e in zip(pair,expected,strict=True)]})
   finally:fn.close_native_storage()
after=source()
assert before==after
(args.output/"index.json").write_text(json.dumps({"source_before":before,"source_after":after,
 "device":probe,"rows":rows},indent=2)+"\n")
print(json.dumps({"device":probe,"cases":len(rows),"source":before["commit"]}))

