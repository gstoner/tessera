"""Numerical replay of explicitly authored half-input, FP32-output saved checkpoints."""
import json
from pathlib import Path
import ml_dtypes
import numpy as np
from tessera import runtime as rt
from tessera.compiler import nvidia_native as native, scheduled_checkpoint as checkpoint
from tessera.compiler.scheduled_matmul import find_tessera_opt, run_tessera_opt
from tests.unit.test_saved_lse_storage_contract import module
from tests.device.nvidia.test_saved_lse_storage import reference, compare

assert rt._nvidia_device_name() == "sm_120"
rows=[]
for storage in ("f16", "bf16"):
 for bias in (None, "1x2x1x1", "1x2x3x5"):
  for causal in (False, True):
   graph=module(storage=storage,output="f32",bias=bias,public=False).replace(
       "causal = true", "causal = "+str(causal).lower())
   tool=find_tessera_opt()
   schedule=run_tessera_opt(tool,graph,"--tessera-graph-to-schedule")
   tile=run_tessera_opt(tool,schedule,"--tessera-schedule-to-tile")
   scheduled=checkpoint._decode_checkpoint(graph,schedule,tile,backward=False)
   package=native.package_scheduled_checkpoint(scheduled,pipeline_name="tessera-nvidia-pipeline-sm120")
   artifact=rt.RuntimeArtifact(target_ir=package.target_ir,native_image=package.image,
       launch_descriptor=package.descriptor,metadata={"target":"nvidia_sm120"})
   artifact=rt.RuntimeArtifact.from_json(artifact.to_json())
   rng=np.random.default_rng(20261016)
   dtype=np.float16 if storage=="f16" else ml_dtypes.bfloat16
   values={name:rng.normal(0,.2,shape).astype(dtype) for name,shape in {
       "q":(1,2,3,4),"k":(1,1,5,4),"v":(1,1,5,3)}.items()}
   if bias: values["bias"]=rng.normal(0,.1,tuple(map(int,bias.split("x")))).astype(np.float32)
   expected=reference(values,causal)
   output=(np.full((1,2,3,3),37,np.float32),np.full((1,2,3),37,np.float32))
   args={**values,"o":output[0],"lse":output[1]}
   args.update(zip(("B","Hq","Hkv","Sq","Sk","D","Dv"),(1,2,1,3,5,4,3),strict=True))
   if bias and bias!="1x2x3x5":
    args.update(zip(("BiasB","BiasH","BiasQ","BiasK"),values["bias"].shape,strict=True))
   result=rt.launch(artifact,args)
   assert result["ok"] and result["execution_kind"]=="native_gpu",result
   compare(output,expected,np.dtype("float32"))
   rows.append({"storage":storage,"output":"f32","bias":bias,"causal":causal,
       "entry":package.descriptor.entry_symbol,"abi":package.descriptor.abi_id,
       "max_abs_error":[float(np.max(np.abs(a.astype(np.float64)-e))) for a,e in zip(output,expected,strict=True)]})
Path("/home/angstorms/scratch/sm120-saved-lse-storage-20261016/fp32-output.json").write_text(json.dumps(rows,indent=2)+"\n")
print(f"{len(rows)} authored half-input, FP32-output native numerical cases passed")
