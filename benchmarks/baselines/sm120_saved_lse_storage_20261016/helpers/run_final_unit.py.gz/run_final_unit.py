from pathlib import Path
import json
import subprocess
from benchmarks.nvidia.record_saved_lse_storage import source
work=Path("/home/angstorms/scratch/sm120-saved-lse-storage-20261016")
before=source()
assert not before["status"], before
command=["python","-m","pytest","tests/unit","-q","-m",
    "not slow and not performance and not compiler_route and not hardware_apple_gpu and not hardware_nvidia and not hardware_rocm and not hardware_amx and not hardware_avx512",
    "-n","8","--timeout=180","--junitxml="+str(work/"unit-final.xml")]
with (work/"unit-final.log").open("w") as log:
 result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
after=source()
(work/"unit-final-witness.json").write_text(json.dumps({
    "command":command,"source_before":before,"source_after":after,"exit_code":result.returncode,
    "unchanged":before==after},indent=2)+"\n")
assert before==after
raise SystemExit(result.returncode)
