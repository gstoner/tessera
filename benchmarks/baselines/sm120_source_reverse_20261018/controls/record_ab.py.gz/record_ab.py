import gzip,hashlib,importlib.util,json,statistics,sys,time
from pathlib import Path
import numpy as np
import tessera as ts
from benchmarks.nvidia.active_source_jvp_reference import product,product_reversed
from benchmarks.nvidia.benchmark_source_reverse import inputs,reference,_check,_snapshot,_device
from tessera.compiler import nvidia_source_reverse_runtime as runtime
from tessera.compiler import native_vjp_composites as composites

snapshot=json.loads(gzip.decompress(Path("../public-reverse-control-source.json.gz").read_bytes()))
control_path=Path("../source_reverse_composites_control.py")
control_path.write_text(snapshot["python/tessera/compiler/native_vjp_composites.py"])
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path)
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
old_runtime=load("tessera.compiler._source_reverse_runtime_control",Path("../source_reverse_runtime_control.py"))
old_composites=load("tessera.compiler._source_reverse_composites_control",control_path)
# Both arms must borrow the same live program; a separate control registry
# would introduce module loading that was absent from the measured baseline.
old_runtime._live=runtime._live;old_runtime._lock=runtime._lock;old_runtime._pid=runtime._pid
candidate_runtime=runtime.execute;candidate_composite=composites.execute_native_vjp_composite
def mode(arm):
 runtime.execute=old_runtime.execute if arm=="control" else candidate_runtime
 composites.execute_native_vjp_composite=old_composites.execute_native_vjp_composite if arm=="control" else candidate_composite

before=_snapshot();rows=[]
try:
 for shape in ((17,19,35),(64,64,128),(128,128,512)):
  for storage in ("f16","bf16"):
   for permuted in (False,True):
    roots=inputs(shape,storage,permuted,18_281+sum(shape))
    expected,budget=reference(roots,permuted)
    fn=ts.jit(target="nvidia_sm120",autodiff="reverse",wrt=("a",))(product_reversed if permuted else product)
    try:
     mode("candidate");_check(fn.native_backward(*roots[:2],out_cotangents=roots[2]),expected,budget,roots[int(permuted)].dtype)
     owner=next(iter(fn._native_prepared_vjp_calls.values()));handle=owner.handle;images=owner.receipt["image_digests"]
     samples={arm:[] for arm in ("control","candidate")};native={arm:[] for arm in samples}
     certificates=set()
     for arm in samples:
      mode(arm)
      for _ in range(5):fn.native_backward(*roots[:2],out_cotangents=roots[2])
     for round_index in range(2):
      for sample in range(7):
       order=("control","candidate") if (round_index+sample)%2==0 else ("candidate","control")
       for arm in order:
        mode(arm)
        actual=fn.native_backward(*roots[:2],out_cotangents=roots[2]);_check(actual,expected,budget,roots[int(permuted)].dtype)
        certificates.add(fn.last_backward_execution["execution_certificate_digest"])
        start=time.perf_counter()
        for _ in range(20):fn.native_backward(*roots[:2],out_cotangents=roots[2])
        samples[arm].append((time.perf_counter()-start)*1000/20)
        _,timing=owner.profile(roots,repeats=32,captured=True)
        native[arm].append(timing)
        assert len(fn._native_prepared_vjp_calls)==1 and owner.handle==handle and owner.receipt["image_digests"]==images
     assert len(certificates)==1,"control/candidate compiled contract or receipt changed"
     med={arm:statistics.median(values) for arm,values in samples.items()}
     rows.append(dict(shape_mnk=list(shape),storage=storage,permuted=permuted,
                      correctness="both_arms_passed_independent_oracle_before_timing",
                      samples_ms=samples,median_ms=med,control_over_candidate=med["control"]/med["candidate"],
                      native_captured=native,same_native_owner_and_images=True,image_digests=images,
                      execution_certificate_digest=next(iter(certificates))))
     print(shape,storage,permuted,med,med["control"]/med["candidate"],flush=True)
    finally:mode("candidate");fn.close_native_storage()
finally:mode("candidate")
after=_snapshot();assert before==after
packet=dict(schema="tessera.nvidia.source_reverse_metadata_ab.v1",device=_device(),
 source_before=before,source_after=after,
 control_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path("../source_reverse_runtime_control.py"),control_path)},
 method=dict(rounds=2,samples_per_round=7,repetitions=20,native_repetitions=32,
             order="counterbalanced arms; identical live owner, images, roots and execution certificate",
             scope="public metadata/projection overhead only; no kernel speedup claim"),rows=rows)
Path("../public-reverse-metadata-ab.json").write_text(json.dumps(packet,indent=2)+"\n")
