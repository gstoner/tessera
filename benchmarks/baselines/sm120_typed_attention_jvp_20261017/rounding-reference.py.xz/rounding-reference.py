from pathlib import Path
import json
import numpy as np
import ml_dtypes

def primal(q,k,v,bias,causal):
    kk=np.repeat(k,2,axis=1);vv=np.repeat(v,2,axis=1)
    scores=(q@kk.swapaxes(-1,-2))*.25+bias
    if causal:
        allowed=np.arange(5)[None,:]<=np.arange(3)[:,None]+2
        scores=np.where(allowed,scores,-np.inf)
    shift=np.max(scores,axis=-1,keepdims=True)
    ex=np.exp(scores-shift);den=ex.sum(axis=-1,keepdims=True)
    p=ex/den
    return p@vv,(shift+np.log(den))[...,0],p

rows=[]
for name,dtype in [('fp16',np.float16),('bf16',ml_dtypes.bfloat16)]:
    mismatch=0;maximum=0.;fdmax=0.;count=0
    for seed in range(12):
      rng=np.random.default_rng(2026101700+seed)
      q,k,v=[rng.normal(0,1.2,s).astype(dtype).astype(np.float64) for s in [(1,4,3,16),(1,2,5,16),(1,2,5,8)]]
      dq,dk,dv=[rng.normal(0,.4,s).astype(dtype).astype(np.float64) for s in [q.shape,k.shape,v.shape]]
      bias=rng.normal(0,.2,(1,4,1,5)).astype(np.float32).astype(np.float64)
      db=rng.normal(0,.2,bias.shape).astype(np.float32).astype(np.float64)
      for causal in [False,True]:
        o,lse,p=primal(q,k,v,bias,causal)
        ds=.25*(dq@np.repeat(k,2,axis=1).swapaxes(-1,-2)+q@np.repeat(dk,2,axis=1).swapaxes(-1,-2))+db
        moment=np.sum(p*ds,axis=-1)
        product=(p*ds)@np.repeat(v,2,axis=1)+p@np.repeat(dv,2,axis=1)
        exact=product-o*moment[...,None]
        rounded=product-o.astype(dtype).astype(np.float64)*moment[...,None]
        epsilon=1e-5
        plus=primal(q+epsilon*dq,k+epsilon*dk,v+epsilon*dv,bias+epsilon*db,causal)
        minus=primal(q-epsilon*dq,k-epsilon*dk,v-epsilon*dv,bias-epsilon*db,causal)
        fd=(plus[0]-minus[0])/(2*epsilon);fdlse=(plus[1]-minus[1])/(2*epsilon)
        error=max(float(np.max(np.abs(fd-exact))),float(np.max(np.abs(fdlse-moment))))
        assert error<1e-8,error
        fdmax=max(fdmax,error);maximum=max(maximum,float(np.max(np.abs(rounded-exact))))
        mismatch+=int(np.count_nonzero(exact.astype(dtype).view(np.uint16)!=rounded.astype(dtype).view(np.uint16)))
        count+=exact.size
    assert mismatch>0
    rows.append(dict(storage=name,cases=24,elements=count,stored_tangent_bit_mismatches=mismatch,max_pre_store_abs_error=maximum,max_finite_difference_error=fdmax))
result=dict(rows=rows,scope='Independent CPU float64 calculus check only; no native half-JVP admission or GPU proof',conclusion='Rounded forward O is not an adequate half-JVP correction residual. Accumulate the FP32 weighted-value moment from the same probabilities, or retain an unrounded compatible residual; preserve existing FP32 native image behavior.')
Path(__file__).with_name('rounding-moment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
