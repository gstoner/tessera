from .trainer import MGRPOTrainer, MGRPOConfig
