import torch, torch.nn as nn
from einops import rearrange
from ..ops.rope import apply_rope

try:
    import tessera as tsr  # optional; if present, we can dispatch to Tessera kernels
    HAVE_TESSERA = True
except Exception:
    HAVE_TESSERA = False

class TesseraAttention(nn.Module):
    def __init__(self, hidden_size: int, num_heads: int, num_kv_heads: int, rope_cache_fn=None, dropout_p: float=0.0):
        super().__init__()
        assert hidden_size % num_heads == 0
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = hidden_size // num_heads
        self.dropout_p = dropout_p
        self.qkv = nn.Linear(hidden_size, hidden_size + 2 * (self.head_dim * num_kv_heads), bias=False)
        self.proj = nn.Linear(hidden_size, hidden_size, bias=False)
        self.rope_cache_fn = rope_cache_fn

    def forward(self, x, rope_cos=None, rope_sin=None, attn_mask=None):
        B, T, C = x.shape
        qkv = self.qkv(x)
        q, k, v = torch.split(qkv, [self.hidden_size, self.head_dim * self.num_kv_heads, self.head_dim * self.num_kv_heads], dim=-1)
        q = rearrange(q, "b t (h d) -> b t h d", h=self.num_heads, d=self.head_dim)
        k = rearrange(k, "b t (h d) -> b t h d", h=self.num_kv_heads, d=self.head_dim)
        v = rearrange(v, "b t (h d) -> b t h d", h=self.num_kv_heads, d=self.head_dim)

        if rope_cos is not None and rope_sin is not None:
            q = apply_rope(q, rope_cos[:, :T], rope_sin[:, :T])
            k = apply_rope(k, rope_cos[:, :T], rope_sin[:, :T])

        # If Tessera attention kernel is present, prefer it.
        if HAVE_TESSERA and hasattr(tsr, "ops") and hasattr(tsr.ops, "flash_attention"):
            out = tsr.ops.flash_attention(q, k, v, causal=True, dropout_p=self.dropout_p)  # expected shape (B, T, H, Dh)
            out = rearrange(out, "b t h d -> b t (h d)")
        else:
            # Reference scaled dot-product attention in PyTorch
            # Expand kv heads to match query heads via repeat (GQA)
            if self.num_kv_heads == 1:
                k = k.repeat_interleave(self.num_heads, dim=2)
                v = v.repeat_interleave(self.num_heads, dim=2)
            else:
                reps = self.num_heads // self.num_kv_heads
                k = k.repeat_interleave(reps, dim=2)
                v = v.repeat_interleave(reps, dim=2)
            scores = torch.einsum("b t h d, b s h d -> b h t s", q, k) / (self.head_dim ** 0.5)
            if attn_mask is not None:
                scores = scores + attn_mask  # mask should be large negative on disallowed positions
            causal = torch.triu(torch.ones(T, T, device=x.device), diagonal=1).bool()
            scores.masked_fill_(causal, float("-inf"))
            attn = torch.softmax(scores, dim=-1)
            out = torch.einsum("b h t s, b s h d -> b t h d", attn, v)
            out = rearrange(out, "b t h d -> b t (h d)")
        return self.proj(out)
