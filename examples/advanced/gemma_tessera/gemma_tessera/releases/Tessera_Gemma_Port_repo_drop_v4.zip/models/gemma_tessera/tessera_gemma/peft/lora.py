
import torch
import torch.nn as nn
from typing import Optional, Dict, Any, Iterable, Tuple

class LoRALinear(nn.Module):
    """
    Drop-in wrapper for nn.Linear with LoRA adapters.
    W_eff = W + scale * (A @ B)  where A: (in, r), B: (r, out), scale = alpha / r
    """
    def __init__(self, base: nn.Linear, rank: int = 8, alpha: float = 16.0, dropout: float = 0.0, fan_in_fan_out: bool = False):
        super().__init__()
        self.base = base
        self.rank = int(rank)
        self.alpha = float(alpha)
        self.dropout_p = float(dropout)
        self.fan_in_fan_out = fan_in_fan_out

        in_f, out_f = base.in_features, base.out_features
        self.lora_A = nn.Parameter(torch.zeros(in_f, self.rank, device=base.weight.device, dtype=base.weight.dtype))
        self.lora_B = nn.Parameter(torch.zeros(self.rank, out_f, device=base.weight.device, dtype=base.weight.dtype))

        # Kaiming init for A and zero for B is common
        nn.init.kaiming_uniform_(self.lora_A, a=5**0.5)
        nn.init.zeros_(self.lora_B)

        self.scaling = self.alpha / max(1, self.rank)
        self.dropout = nn.Dropout(self.dropout_p) if self.dropout_p > 0 else nn.Identity()
        self.merged = False

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.merged:
            return self.base(x)
        x_d = self.dropout(x)
        # base projection
        y = self.base(x)
        # lora contribution
        if self.fan_in_fan_out:
            # if weight is transposed layout semantics (rare for Linear), adjust shapes accordingly
            # but in PyTorch Linear, weight is (out, in) by default; we keep fan_in_fan_out=False for standard case
            raise NotImplementedError("fan_in_fan_out=True not supported in this simple wrapper")
        delta = x_d @ self.lora_A @ self.lora_B
        return y + self.scaling * delta

    def merge(self) -> None:
        if self.merged:
            return
        with torch.no_grad():
            self.base.weight.add_((self.lora_A @ self.lora_B).T * self.scaling)
        self.merged = True

    def unmerge(self) -> None:
        if not self.merged:
            return
        with torch.no_grad():
            self.base.weight.sub_((self.lora_A @ self.lora_B).T * self.scaling)
        self.merged = False

def _wrap_linear(module: nn.Module, name_filter: Optional[Iterable[str]], rank: int, alpha: float, dropout: float) -> int:
    """
    Replace selected nn.Linear submodules with LoRALinear wrappers. Returns count of wrapped layers.
    If name_filter is None, wrap all eligible linears.
    """
    count = 0
    for name, child in list(module.named_children()):
        count += _wrap_linear(child, name_filter, rank, alpha, dropout)
        if isinstance(child, nn.Linear):
            if name_filter is None or any(p in name for p in name_filter):
                setattr(module, name, LoRALinear(child, rank=rank, alpha=alpha, dropout=dropout))
                count += 1
    return count

def apply_lora(model: nn.Module, *, patterns: Optional[Iterable[str]] = ("qkv","proj","wi","wo","lm_head"), rank: int = 8, alpha: float = 16.0, dropout: float = 0.0) -> int:
    """
    Apply LoRA wrappers to Linear layers whose module names contain any of `patterns`.
    Returns number of wrapped modules.
    """
    return _wrap_linear(model, patterns, rank, alpha, dropout)

def lora_state_dict(model: nn.Module) -> Dict[str, torch.Tensor]:
    """
    Collect only LoRA parameters from the model into a flat state dict.
    Keys include full module path + lora_A/lora_B.
    """
    out: Dict[str, torch.Tensor] = {}
    for name, mod in model.named_modules():
        if isinstance(mod, LoRALinear):
            out[f"{name}.lora_A"] = mod.lora_A.detach().clone()
            out[f"{name}.lora_B"] = mod.lora_B.detach().clone()
    return out

def load_lora_state_dict(model: nn.Module, state: Dict[str, torch.Tensor]) -> None:
    """
    Load LoRA parameters into matching wrappers by name.
    """
    for name, mod in model.named_modules():
        if isinstance(mod, LoRALinear):
            a_name = f"{name}.lora_A"
            b_name = f"{name}.lora_B"
            if a_name in state and b_name in state:
                with torch.no_grad():
                    mod.lora_A.copy_(state[a_name].to(mod.lora_A.dtype).to(mod.lora_A.device))
                    mod.lora_B.copy_(state[b_name].to(mod.lora_B.dtype).to(mod.lora_B.device))

def merge_lora(model: nn.Module) -> int:
    c = 0
    for m in model.modules():
        if isinstance(m, LoRALinear):
            m.merge(); c += 1
    return c

def unmerge_lora(model: nn.Module) -> int:
    c = 0
    for m in model.modules():
        if isinstance(m, LoRALinear):
            m.unmerge(); c += 1
    return c
