# Tessera PDDL‑Instruct (v1)

This folder integrates Logical CoT instruction‑tuned symbolic planning into Tessera.

- See `docs/` for design and prompts.
- Build with your existing `tessera-opt` by registering the passes in `passes/` (stubs included).
- Try the examples in `examples/domains/*`.
